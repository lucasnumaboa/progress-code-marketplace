# Origem

Skill de especialista empacotada para o marketplace do Progress Code (id `swan-hiring-intake-brief`).

- Repositório: https://github.com/swan-gtm/gtm-skills
- Caminho: `skills/justin-blij/hiring-intake-brief`
- Autor: Justin Blij / Swan (biblioteca Swan; autoria registrada em `author.md`, copiado do repositório)
- Detentor do copyright no arquivo de licença: Swan
- Licença: MIT (texto completo em `LICENSE`, copiado de `LICENSE` no repositório)
- Commit: `eb0026f469f90645e1a64168d08a3e0afb59ee12` (baixado em 2026-11-22)

## Arquivos incluídos

- `SKILL.md` (de `skills/justin-blij/hiring-intake-brief/SKILL.md`)
- `references/brief-rubric.md` (de `skills/justin-blij/hiring-intake-brief/references/brief-rubric.md`)
- `references/hireability-check.md` (de `skills/justin-blij/hiring-intake-brief/references/hireability-check.md`)
- `references/intake-question-bank.md` (de `skills/justin-blij/hiring-intake-brief/references/intake-question-bank.md`)
- `references/pitch-builder.md` (de `skills/justin-blij/hiring-intake-brief/references/pitch-builder.md`)
- `references/process-contract.md` (de `skills/justin-blij/hiring-intake-brief/references/process-contract.md`)
- `references/setup-customization-checklist.md` (de `skills/justin-blij/hiring-intake-brief/references/setup-customization-checklist.md`)
- `references/worked-example.md` (de `skills/justin-blij/hiring-intake-brief/references/worked-example.md`)
- `author.md` (de `skills/justin-blij/author.md`)

## Mudanças feitas

1. Frontmatter: `name:` trocado de `hiring-intake-brief` para `swan-hiring-intake-brief` (a descrição foi mantida).

O texto do especialista foi mantido em inglês, sem tradução.

A biblioteca swan-gtm/gtm-skills é MIT (LICENSE "Copyright (c) 2026 Swan"; CONTRIBUTING: "Contributions are MIT-licensed"). O crédito ao autor de cada skill é mantido pelo `author.md`.

---
name: preparar-dados-powerbi
description: Prepara dados no formato certo (tabelas longas, chaves consistentes) para Power BI ou tabela dinâmica do Excel, com medidas DAX básicas e critério para escolher entre os dois. Use quando o usuário pedir "preparar essa base para o Power BI", "criar uma medida DAX", "montar uma tabela dinâmica", "por que meu Power BI não está somando certo".
argument-hint: [dados de origem] [o que o relatório precisa mostrar]
---

# Relatórios em Power BI / tabela dinâmica do Excel

## Quando usar tabela dinâmica do Excel vs. Power BI
- **Tabela dinâmica do Excel**: análise pontual, poucos milhares de linhas, quem vai usar já trabalha em Excel e não
  precisa de atualização automática de fonte nem de compartilhar um dashboard interativo.
- **Power BI**: dados de múltiplas fontes, precisa atualizar automaticamente, o relatório vai ser compartilhado
  como dashboard interativo para várias pessoas, ou o volume de dados é grande demais para o Excel processar bem.
Esta skill **não instala nem abre o Power BI Desktop** (aplicativo separado que precisa já estar instalado) — o
que ela cobre é como preparar os dados de origem e as medidas para funcionarem bem quando o usuário abrir no
Power BI (ou no Excel) por conta própria.

## Passo 1 — Formato "tabela longa" (o erro mais comum vem daqui)
Ferramentas de análise (Power BI, tabela dinâmica) trabalham melhor com dados no formato **longo** (uma linha por
observação), não **largo** (uma coluna por mês/categoria):
```
ERRADO (largo):          CERTO (longo):
Produto | Jan | Fev      Produto | Mes | Valor
A       | 100 | 120      A       | Jan | 100
B       | 80  | 90       A       | Fev | 120
                          B       | Jan | 80
                          B       | Fev | 90
```
Se os dados de origem vierem largos (comum em planilhas feitas para leitura humana), transforme antes de carregar:
```python
df_longo = df.melt(id_vars=["Produto"], var_name="Mes", value_name="Valor")
```

## Passo 2 — Modelo de dados: tabela fato + tabelas dimensão
Para relatórios com mais de uma fonte (vendas + cadastro de produto + calendário), separe em:
- **Tabela fato**: uma linha por evento/transação (venda, com quantidade e valor).
- **Tabelas dimensão**: cadastro de produto, cliente, calendário — cada uma com uma chave única que a fato
  referencia. Isso evita repetir nome de produto/cliente em cada linha da fato (redundância que infla o arquivo e
  complica manutenção) e é o modelo que o Power BI espera (modelo estrela).

## Passo 3 — Medidas DAX básicas (Power BI)
```dax
Total Vendas = SUM(Vendas[Valor])
Vendas Mes Anterior = CALCULATE([Total Vendas], DATEADD('Calendario'[Data], -1, MONTH))
% Crescimento = DIVIDE([Total Vendas] - [Vendas Mes Anterior], [Vendas Mes Anterior])
```
`DIVIDE` em vez de `/` puro evita erro de divisão por zero (retorna `BLANK()` em vez de quebrar o visual inteiro).
`DATEADD` exige uma tabela de calendário marcada como "Tabela de Datas" no modelo — sem isso, funções de
inteligência de tempo (mês anterior, ano anterior, acumulado) não funcionam direito.

## Passo 4 — Tabela dinâmica do Excel (alternativa mais simples)
```
Inserir → Tabela Dinâmica → escolher o intervalo/tabela → arrastar campos para Linhas/Colunas/Valores.
```
Para "% do total" e "comparação com período anterior" sem DAX, use Configuração de Campo de Valor → Mostrar Valores
Como → `% do Total Geral` / `% da Diferença de`.

## Regras
- Nunca entregue dados no formato largo para quem vai montar um Power BI/tabela dinâmica sem avisar — é a causa
  mais comum de "não consigo somar por mês" nesse tipo de relatório.
- Sempre confirme se existe uma tabela de calendário completa (sem buracos de data) antes de propor medidas de
  inteligência de tempo — buraco de data quebra silenciosamente o acumulado.
- `SUM`/`COUNT` direto numa coluna com valores nulos/texto misturado dá erro ou resultado incompleto — confira o
  tipo de dado da coluna antes de propor a medida.

## Arquivos desta skill
Nenhum script fixo — os trechos acima cobrem os casos mais comuns; adapte ao modelo de dados real do usuário.

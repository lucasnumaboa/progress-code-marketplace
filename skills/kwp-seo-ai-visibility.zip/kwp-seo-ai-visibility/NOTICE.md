# Origem e mudanças

- **Repositório:** https://github.com/anthropics/knowledge-work-plugins
- **Caminho no repositório:** `small-business/skills/seo-ai-visibility`
- **Autor:** Anthropic
- **Licença:** Apache-2.0 (texto em `LICENSE`)
- **Commit usado:** `0e0fcacddcc892eb92a1b7873ff9d68159c47571`
- **Arquivos copiados:** `SKILL.md`, `reference/ai_visibility.md`, `reference/audit_checklist.md`, `reference/catalog_refresh.md`, `reference/content_rewrite.md`, `reference/gotchas.md`

## Mudanças feitas

- no cabeçalho (frontmatter), `name:` passou de `seo-ai-visibility` para `kwp-seo-ai-visibility`; a descrição ficou igual
- removida a seção "Using a tool that isn't listed", que oferece a skill `build-connector` do Claude Cowork (conectores de outro produto)
- nenhuma outra alteração no texto do especialista (mantido em inglês)

## Observações

- o plugin `small-business` não tem LICENSE próprio; vale o LICENSE (Apache-2.0) da raiz do repositório, copiado aqui

Empacotada para o marketplace do Progress Code em 2026-11-22.

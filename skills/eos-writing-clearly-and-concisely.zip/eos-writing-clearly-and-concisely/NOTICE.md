# Origem e mudanças

- **Repositório:** https://github.com/obra/the-elements-of-style
- **Caminho no repositório:** `skills/writing-clearly-and-concisely`
- **Autor:** William Strunk Jr. (texto de 1918) e Jesse Vincent (empacotamento)
- **Licença:** Domínio público (texto em `LICENSE`)
- **Commit usado:** `05fc4f0d2b97b7c042dd9949ad658568e4a1324e`
- **Arquivos copiados:** `SKILL.md`, `elements-of-style.md`

## Mudanças feitas

- no cabeçalho (frontmatter), `name:` passou de `writing-clearly-and-concisely` para `eos-writing-clearly-and-concisely`; a descrição ficou igual
- nenhuma outra alteração no texto do especialista (mantido em inglês)

## Observações

- o repositório não tem arquivo LICENSE; o README declara "License: Public Domain" para *The Elements of Style* (1918), de William Strunk Jr. O SKILL.md escrito por Jesse Vincent está coberto só por essa declaração do README (ver o arquivo LICENSE desta pasta)

Empacotada para o marketplace do Progress Code em 2026-11-22.

import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { Subject, Subscription, debounceTime, distinctUntilChanged, forkJoin, of } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import * as XLSX from 'xlsx';

import {
  PoBreadcrumb,
  PoDialogService,
  PoModalAction,
  PoModalComponent,
  PoNotificationService,
  PoPageAction,
  PoSelectOption,
  PoTableColumn
} from '@po-ui/ng-components';

import { TotvsScheduleExecutionService } from 'dts-backoffice-util';

import { ConsolidacaoPlanilhasService } from './consolidacao-planilhas.service';
import {
  AdTitulo,
  ClienteAgrupado,
  ContadoresApi,
  Planilha,
  ProgressoProcessamento,
  StatusPlanilha
} from './models/planilha.model';

/**
 * Nome do programa RPW cadastrado no Datasul.
 * Ajuste conforme o registro em: Administração → RPW → Programas.
 *
 * programName    : código do menu cadastrado no Datasul
 * externalName   : caminho externo do programa (máx. 24 caracteres)
 * programVersion : versão do programa no formato Datasul
 */
const RPW_PROGRAM_NAME = 'importa-tit-acr-rpw';
const RPW_EXTERNAL_NAME = 'importa-tit-acr-rpw';   // máx. 24 chars
const RPW_PROGRAM_VERSION = '1.00.00.001';

/** Acima deste nº de registros a importação é feita via RPW (background). */
const LIMITE_RPW_IMPORT = 1000;
/** Programa RPW que processa a planilha (importa do CSV na pasta). */
const RPW_IMPORT_PROGRAM = 'esp/importa-plan-tit-acr-rpw.w';
const RPW_IMPORT_PROCESS_ID = 'importa-plan-tit-acr-rpw';

/** Intervalo de monitoramento do job RPW via followUp (ms) */
const RPW_MONITOR_INTERVAL_MS = 3000;

type TabAtiva = 'todas' | 'processadas' | 'pendentes' | 'comErro';
type TabModalDetalhe = 'titulos' | 'grupoAd';

/** Quantidade de registros por página — equilibra UX e memória */
const ITENS_POR_PAGINA = 50;

/** Quantidade máxima de títulos carregados de uma vez dentro do modal de detalhes */
const ITENS_POR_PAGINA_DETALHE = 500;

/**
 * Valor sentinela da opção "Todas empresas" no filtro de empresa. O backend
 * (codEmpresa = "*") ignora o filtro por estabelecimento e traz todos os
 * estabelecimentos de todas as empresas.
 */
const EMPRESA_TODAS = '*';

@Component({
  selector: 'app-consolidacao-planilhas',
  templateUrl: './consolidacao-planilhas.component.html',
  styleUrls: ['./consolidacao-planilhas.component.scss']
})
export class ConsolidacaoPlanilhasComponent implements OnInit, OnDestroy {

  @ViewChild('modalImportacao', { static: true }) modalImportacao!: PoModalComponent;
  @ViewChild('modalDetalhe', { static: true }) modalDetalhe!: PoModalComponent;
  @ViewChild('modalTituloDetalhe', { static: true }) modalTituloDetalhe!: PoModalComponent;
  @ViewChild('modalRpwPendentes', { static: true }) modalRpwPendentes!: PoModalComponent;
  @ViewChild('modalRelatorio', { static: true }) modalRelatorio!: PoModalComponent;
  @ViewChild('modalRpwImport', { static: true }) modalRpwImport!: PoModalComponent;
  @ViewChild('modalTitulosGrupo', { static: true }) modalTitulosGrupo!: PoModalComponent;

  servidorRpwPendentes = '';
  totalPendentes = 0;

  // ── Importação via RPW (planilhas grandes, > LIMITE_RPW_IMPORT registros) ──
  servidorRpwImport = '';
  servidoresRpwImport: PoSelectOption[] = [];
  /** CSV da planilha montado no upload, gravado na pasta do RPW ao confirmar. */
  private csvImportacaoRpw = '';
  totalRegistrosRpwImport = 0;

  get acaoPrimariaRpwImport(): PoModalAction {
    return {
      label: 'Executar',
      action: () => this.executarImportRpw(),
      disabled: !this.servidorRpwImport
    };
  }

  get acaoSecundariaRpwImport(): PoModalAction {
    return {
      label: 'Cancelar',
      action: () => {
        this.modalRpwImport.close();
        this.etapaModal = 'formulario';
      }
    };
  }

  get acaoPrimariaRpwPendentes(): PoModalAction {
    return {
      label: 'Executar',
      action: () => this.executarRpwPendentes(),
      disabled: !this.servidorRpwPendentes
    };
  }

  get acaoSecundariaRpwPendentes(): PoModalAction {
    return {
      label: 'Cancelar',
      action: () => this.fecharModalRpwPendentes()
    };
  }

  // ─────────────────────────────────────────────
  // Modal de Relatório
  // ─────────────────────────────────────────────

  relatorioCnpjIni = '';
  relatorioCnpjFim = 'zzzzzzzzzzzzzzzzzzzz';
  relatorioEstabIni = '';
  relatorioEstabFim = 'zzzzz';
  relatorioSerieIni = '';
  relatorioSerieFim = 'zzzzz';
  relatorioTituloIni = '';
  relatorioTituloFim = 'zzzzzzzzz';

  /** Filtro de situacao do relatorio (vazio = todas). */
  relatorioSituacao = '';
  readonly opcoesSituacaoRelatorio = [
    { label: 'Todas',      value: '' },
    { label: 'Pendente',   value: 'Pendente' },
    { label: 'Processado', value: 'Importado' },
    { label: 'Com Erro',   value: 'Erro' }
  ];

  /** Filtro de tipo de implantação do relatório (parcial / total / ambos). */
  relatorioImplantacao = 'ambos';
  readonly opcoesImplantacaoRelatorio = [
    { label: 'Ambos',   value: 'ambos' },
    { label: 'Total',   value: 'total' },
    { label: 'Parcial', value: 'parcial' }
  ];

  /** Flag do relatório: traz apenas os títulos de liquidação por lote. */
  relatorioApenasLote = false;

  get acaoPrimariaRelatorio(): PoModalAction {
    return {
      label: 'Executar',
      action: () => this.executarRelatorio()
    };
  }

  get acaoSecundariaRelatorio(): PoModalAction {
    return {
      label: 'Cancelar',
      action: () => this.fecharModalRelatorio()
    };
  }

  abrirModalRelatorio(): void {
    this.modalRelatorio.open();
  }

  fecharModalRelatorio(): void {
    this.modalRelatorio.close();
  }

  executarRelatorio(): void {
    this.fecharModalRelatorio();
    this.bloquearTela = true;
    this.textoLoading = 'Gerando relatório...';

    const params = {
      cnpjIni: this.relatorioCnpjIni,
      cnpjFim: this.relatorioCnpjFim,
      estabIni: this.relatorioEstabIni,
      estabFim: this.relatorioEstabFim,
      serieIni: this.relatorioSerieIni,
      serieFim: this.relatorioSerieFim,
      tituloIni: this.relatorioTituloIni,
      tituloFim: this.relatorioTituloFim,
      situacao: this.relatorioSituacao,
      implantacao: this.relatorioImplantacao,
      apenasLote: this.relatorioApenasLote
    };

    localStorage.setItem('filtroRelatorioAcr', JSON.stringify(params));

    this.service.executarRelatorio(params).subscribe({
      next: (res) => {
        this.bloquearTela = false;

        if (res && res.base64Data) {
          try {
            const byteCharacters = atob(res.base64Data);
            const byteNumbers = new Array(byteCharacters.length);
            for (let i = 0; i < byteCharacters.length; i++) {
              byteNumbers[i] = byteCharacters.charCodeAt(i);
            }
            const byteArray = new Uint8Array(byteNumbers);
            const blob = new Blob([byteArray], { type: 'application/vnd.ms-excel' });

            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = res.fileName || 'Relatorio_ACR.xls';
            document.body.appendChild(a);
            a.click();
            window.URL.revokeObjectURL(url);
            document.body.removeChild(a);

            this.notification.success('Download do relatório iniciado com sucesso!');
          } catch (e) {
            console.error('Erro ao processar arquivo base64', e);
            this.notification.warning('Relatório gerado, mas ocorreu um erro ao baixar o arquivo.');
          }
        } else {
          const msg = res && res.message ? res.message : 'Relatório gerado com sucesso!';
          this.notification.success(msg);
        }
      },
      error: (err) => {
        this.bloquearTela = false;
        const errMsg = err?.error?.error || err?.message || 'Erro ao gerar relatório no backend.';
        this.notification.error(`Erro: ${errMsg}`);
      }
    });
  }

  // ─────────────────────────────────────────────
  // Configuração da página
  // ─────────────────────────────────────────────

  readonly pageTitle = 'Consolidação de Planilhas Títulos ACR';

  readonly breadcrumb: PoBreadcrumb = {
    items: [
      { label: 'Início', link: '/' },
      { label: 'Consolidação de Títulos ACR' }
    ]
  };

  readonly pageActions: PoPageAction[] = [
    {
      label: 'Atualizar',
      icon: 'po-icon-refresh',
      action: () => this.carregarClientes()
    },
    {
      label: 'Importar Documentos',
      icon: 'po-icon-upload',
      action: () => this.abrirModalImportacao()
    }
  ];

  // ─────────────────────────────────────────────
  // Filtros
  // ─────────────────────────────────────────────

  /**
   * Nenhuma empresa vem pré-selecionada: a tela só carrega dados depois
   * que o usuário escolhe uma empresa explicitamente (ver `onEmpresaChange`).
   */
  empresaSelecionada = '';
  empresas: PoSelectOption[] = [];

  filtroDataIni = '';
  filtroDataFim = '';
  filtroCnpj = '';

  // ─────────────────────────────────────────────
  // Busca por CGC / nome do emitente
  // ─────────────────────────────────────────────

  termoBusca = '';
  private buscaSubject = new Subject<string>();
  private buscaSubscription: Subscription | null = null;

  // ─────────────────────────────────────────────
  // Tabs de status (contadores via API — server-side)
  // ─────────────────────────────────────────────

  tabAtiva: TabAtiva = 'pendentes';

  /** Contadores por status — total de títulos (não de clientes) por situação */
  contadores: ContadoresApi = { todas: 0, pendentes: 0, processadas: 0, comErro: 0 };

  private recalcularContadores(): void {
    if (!this.empresaSelecionada) {
      this.contadores = { todas: 0, pendentes: 0, processadas: 0, comErro: 0 };
      return;
    }
    this.service.obterContadores(this.empresaSelecionada).subscribe({
      next: (c) => {
        this.contadores = c;
      },
      error: () => { /* silently ignore */ }
    });
  }

  // ─────────────────────────────────────────────
  // Paginação server-side
  // ─────────────────────────────────────────────

  carregando = false;
  carregandoMais = false;
  paginaAtual = 1;
  totalItens = 0;
  temMais = false;

  bloquearTela = false;
  textoLoading = 'Aguarde...';

  /** Clientes agrupados por CGC — uma linha por cliente na grid principal */
  clientes: ClienteAgrupado[] = [];

  itensSelecionados: ClienteAgrupado[] = [];
  todosSelecionados = false;

  /** Array principal exibido na grid, após filtro de aba */
  clientesFiltrados: ClienteAgrupado[] = [];

  /**
   * Recalcula listas e aplica filtragem da aba ativa.
   * Deve ser chamado sempre que `clientes` for alterada.
   */
  private recalcularListas(): void {
    this.recalcularContadores();
    this.aplicarFiltroTab();
  }

  /** Atualiza `clientesFiltrados` — server-side, sem filtro local */
  private aplicarFiltroTab(): void {
    this.clientesFiltrados = [...this.clientes];
    this.atualizarStatusSelecionarTodos();
  }

  /**
   * Colunas do grid principal — variam conforme a aba ativa.
   * Materializada (em vez de getter) e recalculada apenas em `onTabChange`/
   * `ngOnInit`: um getter ligado a `[p-columns]` recriaria o array a cada
   * ciclo de detecção de mudanças, o que faz a po-table reprocessar
   * colunas/observers indefinidamente e trava a tela.
   */
  colunasClientes: PoTableColumn[] = [];

  private montarColunasClientes(): void {
    // Colunas de ação (botões via cellTemplate — ver <ng-template
    // p-table-cell-template> no HTML): "Títulos" (azul, abre a aba Títulos
    // com os documentos que têm título vinculado) e "AD" (verde, desabilitado
    // quando o cliente não tem adiantamento, abre a aba Grupo AD). Ficam no
    // FINAL da linha, depois de todas as informações.
    const colunasAcoes: PoTableColumn[] = [
      { property: 'detalhesLabel', label: 'Títulos', type: 'cellTemplate', width: '9%' },
      { property: 'adLabel', label: 'AD', type: 'cellTemplate', width: '8%' },
      { property: 'grupoLabel', label: 'Tít do Gr Empresarial', type: 'cellTemplate', width: '13%' }
    ];

    const base: PoTableColumn[] = [
      { property: 'nomeEmit', label: 'Cliente', width: '20%' },
      { property: 'cgc', label: 'CNPJ/CPF', width: '14%' }
    ];

    const colunasDetalhadas: PoTableColumn[] = this.tabAtiva === 'todas' ? [] : [
      { property: 'dataImportacao', label: 'Data Import.', type: 'date', width: '11%' },
      { property: 'valorEmAberto', label: 'Valor em Aberto', type: 'currency', format: 'BRL', width: '13%' },
      { property: 'valorEmAbertoAd', label: 'Valor em Aberto AD', type: 'currency', format: 'BRL', width: '13%' },
      { property: 'valor', label: 'Valor extrato', type: 'currency', format: 'BRL', width: '12%' }
    ];

    this.colunasClientes = [...base, ...colunasDetalhadas, ...colunasAcoes];
  }

  // ─────────────────────────────────────────────
  // Progresso de processamento (ações em lote da tabela)
  // ─────────────────────────────────────────────

  processando = false;
  progresso: ProgressoProcessamento | null = null;
  private pollingSubscription: Subscription | null = null;

  // ─────────────────────────────────────────────
  // Modal de importação — fluxo RPW via dts-backoffice-util
  // ─────────────────────────────────────────────

  /** Empresa selecionada para importação (businessParam para o RPW) */
  empresaImportacao = '';

  /**
   * Tipo de liquidação da importação selecionado no modal.
   *   'ad'   → Liquidação e geração de AD (rotina atual, já em produção)
   *   'lote' → Liquidação por lote (fluxo ainda a ser definido no backend)
   */
  tipoLiquidacao: 'ad' | 'lote' = 'ad';

  readonly opcoesTipoLiquidacao = [
    { label: 'Liquidação e geração de AD', value: 'ad' },
    { label: 'Liquidação por lote', value: 'lote' }
  ];

  /**
   * Flag "Se encontrar título a menor liquida parcial". Enviado ao backend na
   * importação; gravado no fim de `cod_arq_origem` (após o último "|") como
   * "YES"/"NO". A regra de negócio deste flag ainda será definida.
   */
  liquidaParcial = false;

  /**
   * Identificador do lote (ddmmaahhmmss) gerado na importação por lote.
   * Vincula todos os títulos da mesma carga; gravado no cod_arq_origem
   * pelo backend como "Lote:<numLoteImport>". Vazio quando não é por lote.
   */
  numLoteImport = '';

  /** Caminho do arquivo no servidor (businessParam para o RPW) */
  caminhoArquivo = '';

  /**
   * Estado do fluxo da modal:
   *   formulario → aguardando → concluido | erro
   *
   * O componente <app-totvs-schedule-execution> gerencia internamente
   * a seleção do servidor RPW e o envio do job — ao confirmar, emite
   * (endExecution) que avança para 'aguardando'.
   */
  etapaModal: 'formulario' | 'aguardando' | 'processando' | 'concluido' | 'erro' = 'formulario';

  // Variáveis para importação fatiada
  totalRegistrosImportacao = 0;
  registrosProcessados = 0;
  percentualImportacao = 0;
  statusProcessamento = '';

  // ─────────────────────────────────────────────
  // Modal de detalhes do cliente (Títulos / Grupo AD)
  // ─────────────────────────────────────────────

  clienteDetalhe: ClienteAgrupado | null = null;
  modalTabDetalhe: TabModalDetalhe = 'titulos';
  carregandoDetalhe = false;

  /** Títulos do cliente exibidos na aba "Títulos" do modal */
  titulosDetalhe: Planilha[] = [];

  /** Títulos marcados (checkbox) na aba "Títulos" — para processar/excluir em lote */
  titulosSelecionados: Planilha[] = [];

  /** Títulos AD (adiantamento) com saldo disponível, exibidos na aba "Grupo AD" */
  adTitulosDetalhe: AdTitulo[] = [];
  adSelecionados: AdTitulo[] = [];

  readonly colunasTitulosDetalhe: PoTableColumn[] = [
    { property: 'codEstab', label: 'Cod Estab', width: '10%' },
    { property: 'codEspecDocto', label: 'Espécie', width: '10%' },
    { property: 'codSerDocto', label: 'Série', width: '8%' },
    { property: 'codTitAcr', label: 'Nro Docto', width: '14%' },
    { property: 'codParcela', label: 'Parcela', width: '8%' },
    { property: 'valRecebido', label: 'Valor', type: 'currency', format: 'BRL', width: '15%' },
    {
      property: 'tipoLiquidacao', label: 'Liquidação', type: 'label', width: '11%',
      labels: [
        { value: 'integral', color: 'color-11', label: 'Integral' },
        { value: 'parcial', color: 'color-08', label: 'Parcial' }
      ]
    },
    { property: 'numLote', label: 'Lote', width: '12%' },
    {
      property: 'indSitImportacao', label: 'Situação', type: 'label', width: '13%',
      labels: [
        { value: 'Pendente', color: 'color-08', label: 'Pendente' },
        { value: 'Importado', color: 'color-11', label: 'Processado' },
        { value: 'Erro', color: 'color-07', label: 'Com Erro' },
        { value: 'Processando', color: 'color-01', label: 'Processando' }
      ]
    }
  ];

  readonly colunasAdDetalhe: PoTableColumn[] = [
    { property: 'codEstab', label: 'Estab.', width: '9%' },
    { property: 'codTitAcr', label: 'Nro Adiantamento', width: '16%' },
    { property: 'datEmisDocto', label: 'Data', type: 'date', width: '12%' },
    { property: 'valSdoTitAcr', label: 'Valor', type: 'currency', format: 'BRL', width: '14%' },
    {
      property: 'status', label: 'Situação', type: 'label', width: '14%',
      labels: [
        { value: 'Pendente', color: 'color-08', label: 'Pendente' },
        { value: 'Importado', color: 'color-11', label: 'Processado' },
        { value: 'Erro', color: 'color-07', label: 'Com Erro' },
        { value: 'Processando', color: 'color-01', label: 'Processando' }
      ]
    },
    { property: 'observacoes', label: 'Observações', width: '35%' }
  ];

  /**
   * Total da aba Títulos. Se houver seleção, soma apenas os selecionados;
   * caso contrário, soma todos os títulos exibidos.
   */
  get totalTitulosDetalhe(): number {
    const base = this.titulosSelecionados.length > 0 ? this.titulosSelecionados : this.titulosDetalhe;
    return base.reduce((soma, t) => soma + (t.valRecebido ?? 0), 0);
  }

  get titulosTotalSelecionado(): boolean {
    return this.titulosSelecionados.length > 0;
  }

  /**
   * Total da aba Grupo AD. Se houver seleção, soma apenas os selecionados;
   * caso contrário, soma todos os adiantamentos exibidos.
   */
  get totalAdDetalhe(): number {
    const base = this.adSelecionados.length > 0 ? this.adSelecionados : this.adTitulosDetalhe;
    return base.reduce((soma, a) => soma + (a.valSdoTitAcr ?? 0), 0);
  }

  get adTotalSelecionado(): boolean {
    return this.adSelecionados.length > 0;
  }

  readonly acaoFecharDetalhe: PoModalAction = {
    label: 'Fechar',
    action: () => this.fecharDetalhes()
  };

  /** Item (título ou AD) selecionado para exibição no modal de detalhes individual. */
  tituloDetalheItem: any = null;

  /** Ações da tabela de títulos (referência estável — não recriar no template). */
  readonly acoesTitulosDetalhe = [
    { label: 'Detalhes', icon: 'po-icon-info', action: (titulo: Planilha) => this.abrirDetalheTitulo(titulo) },
    { label: 'Eliminar', icon: 'po-icon-delete', type: 'danger', action: (titulo: Planilha) => this.eliminarTituloDetalhe(titulo) }
  ];

  /** Ações da tabela de AD (Detalhes do adiantamento). */
  readonly acoesAdDetalhe = [
    { label: 'Detalhes', icon: 'po-icon-info', action: (ad: AdTitulo) => this.abrirDetalheTitulo(ad) }
  ];

  readonly acaoFecharTituloDetalhe: PoModalAction = {
    label: 'Fechar',
    action: () => this.modalTituloDetalhe.close()
  };

  /** Abre o modal com os detalhes de um título específico (botão "Detalhes" da linha). */
  abrirDetalheTitulo(titulo: any): void {
    this.tituloDetalheItem = titulo;
    this.modalTituloDetalhe.open();
  }

  // ─────────────────────────────────────────────
  // Títulos do Grupo Empresarial (troca de vínculo)
  // ─────────────────────────────────────────────

  clienteGrupo: any = null;
  titulosGrupo: any[] = [];
  titulosGrupoFiltrados: any[] = [];
  pendentesGrupo: any[] = [];
  filtroGrupo = '';
  pendenteSelecionadoGrupo: any = null;
  tituloGrupoSelecionado: any = null;
  carregandoGrupo = false;

  readonly colunasTitulosGrupo: PoTableColumn[] = [
    { property: 'cnpj', label: 'CNPJ', width: '16%' },
    { property: 'codEstab', label: 'Estab', width: '8%' },
    { property: 'codSerDocto', label: 'Série', width: '8%' },
    { property: 'codTitAcr', label: 'Título', width: '13%' },
    { property: 'codParcela', label: 'Parc', width: '7%' },
    { property: 'codEspecDocto', label: 'Espéc', width: '8%' },
    { property: 'valSdoTitAcr', label: 'Vlr aberto', type: 'currency', format: 'BRL', width: '15%' },
    { property: 'datVencto', label: 'Vencto', type: 'date', width: '12%' }
  ];

  readonly colunasPendentesGrupo: PoTableColumn[] = [
    { property: 'codEstab', label: 'Estab', width: '13%' },
    { property: 'codEspecDocto', label: 'Espéc', width: '13%' },
    { property: 'codTitAcr', label: 'Título', width: '24%' },
    { property: 'codParcela', label: 'Parc', width: '10%' },
    { property: 'valRecebido', label: 'Valor', type: 'currency', format: 'BRL', width: '22%' }
  ];

  readonly acaoFecharTitulosGrupo: PoModalAction = {
    label: 'Fechar',
    action: () => this.modalTitulosGrupo.close()
  };

  /** Botão "Tít do Gr Empresarial" só habilita se o cliente tem título ou AD. */
  podeVerGrupo(cliente: any): boolean {
    return !!(cliente && (cliente.temTitulo || cliente.temAd));
  }

  /** Abre o modal e faz a varredura dos títulos em aberto do grupo empresarial. */
  abrirTitulosGrupo(cliente: any): void {
    this.clienteGrupo = cliente;
    this.filtroGrupo = '';
    this.titulosGrupo = [];
    this.titulosGrupoFiltrados = [];
    this.pendentesGrupo = [];
    this.pendenteSelecionadoGrupo = null;
    this.tituloGrupoSelecionado = null;
    this.carregandoGrupo = true;
    this.modalTitulosGrupo.open();

    this.service.listarTitulosGrupo(cliente.cgc).subscribe({
      next: (items) => {
        this.titulosGrupo = items || [];
        this.filtrarGrupo();
        this.carregandoGrupo = false;
      },
      error: () => {
        this.carregandoGrupo = false;
        this.notification.error('Erro ao carregar os títulos do grupo empresarial.');
      }
    });
    this.carregarPendentesGrupo();
  }

  /** Carrega os títulos/ADs PENDENTES do cliente (lado direito). Busca todos os
   *  registros do cliente (mesma chamada do Detalhes) e filtra Pendente no front,
   *  independentemente da aba ativa na grid. */
  carregarPendentesGrupo(): void {
    if (!this.clienteGrupo) return;
    this.service.listarPlanilhas({
      pagina: 1,
      itensPorPagina: 500,
      empresa: this.empresaSelecionada,
      cgc: this.clienteGrupo.cgc
    }).subscribe({
      next: (resp) => {
        this.pendentesGrupo = (resp.items || []).filter(
          t => t.indSitImportacao === 'Pendente' && !!t.codTitAcr
        );
        // Re-filtra a esquerda para ocultar os títulos já vinculados à direita.
        this.filtrarGrupo();
      },
      error: () => { this.pendentesGrupo = []; }
    });
  }

  /** Título do grupo (esquerda) já vinculado a um pendente (direita)? */
  private tituloEmUso(t: any): boolean {
    return this.pendentesGrupo.some(p =>
      String(p.codEstab) === String(t.codEstab) &&
      String(p.codEspecDocto) === String(t.codEspecDocto) &&
      String(p.codSerDocto) === String(t.codSerDocto) &&
      String(p.codTitAcr) === String(t.codTitAcr) &&
      String(p.codParcela) === String(t.codParcela)
    );
  }

  /** Filtra a lista de títulos do grupo por título, estabel., série ou valor. */
  filtrarGrupo(): void {
    const f = (this.filtroGrupo || '').trim().toLowerCase();
    // Oculta os títulos já vinculados a um pendente (lado direito).
    const disponiveis = this.titulosGrupo.filter(t => !this.tituloEmUso(t));
    if (!f) { this.titulosGrupoFiltrados = disponiveis; return; }
    this.titulosGrupoFiltrados = disponiveis.filter(t =>
      String(t.codTitAcr || '').toLowerCase().includes(f) ||
      String(t.codEstab || '').toLowerCase().includes(f) ||
      String(t.codSerDocto || '').toLowerCase().includes(f) ||
      String(t.valSdoTitAcr ?? '').toString().includes(f)
    );
  }

  /** Habilita "Trocar vínculo": exatamente 1 pendente (direita) e ≥1 título (esquerda). */
  get podeTrocar(): boolean {
    const nFonte = (this.pendentesGrupo || []).filter((p: any) => p.$selected).length;
    const nAlvos = (this.titulosGrupoFiltrados || []).filter((t: any) => t.$selected).length;
    return nFonte === 1 && nAlvos >= 1;
  }

  /** Avisa a distribuição (integral / parcial / AD do excedente) e efetiva. */
  trocarVinculoGrupo(): void {
    const fonte = (this.pendentesGrupo || []).find((p: any) => p.$selected);
    const alvos = (this.titulosGrupoFiltrados || []).filter((t: any) => t.$selected);
    if (!fonte || alvos.length === 0) {
      this.notification.warning('Selecione 1 pendente (direita) e ao menos 1 título do grupo (esquerda).');
      return;
    }
    const pago = (Number(fonte.valRecebido) || 0) + (Number(fonte.valJuros) || 0) + (Number(fonte.valMulta) || 0);
    const somaDevido = alvos.reduce((s: number, t: any) => s + (Number(t.valDevido) || 0), 0);
    const fmt = (v: number) => 'R$ ' + v.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    let msg = '';
    if (pago >= somaDevido - 0.005) {
      const ad = pago - somaDevido;
      msg = `O valor pago (${fmt(pago)}) cobre os ${alvos.length} título(s) selecionado(s): serão liquidados integral`
          + (ad > 0.005 ? ` e o excedente de ${fmt(ad)} será gerado como AD` : '') + '. Confirmar?';
    } else {
      msg = `O valor pago (${fmt(pago)}) não cobre o total selecionado (${fmt(somaDevido)}). `
          + `Os títulos serão liquidados por ordem de vencimento (integral enquanto o valor cobrir e parcial/acerto no último). Confirmar?`;
    }
    this.dialog.confirm({
      title: 'Distribuir pagamento',
      message: msg,
      confirm: () => this.confirmarTrocaGrupo(fonte, alvos)
    });
  }

  private confirmarTrocaGrupo(fonte: any, alvos: any[]): void {
    const body = {
      cgc: fonte.cgc,
      estabAtual: fonte.codEstab, especAtual: fonte.codEspecDocto, serieAtual: fonte.codSerDocto,
      tituloAtual: fonte.codTitAcr, parcelaAtual: fonte.codParcela,
      valRecebido: Number(fonte.valRecebido) || 0,
      titulos: alvos.map((t: any) => ({
        estab: t.codEstab, espec: t.codEspecDocto, serie: t.codSerDocto,
        titulo: t.codTitAcr, parcela: t.codParcela
      }))
    };
    this.carregandoGrupo = true;
    this.service.trocarVinculo(body).subscribe({
      next: (resp: any) => {
        this.carregandoGrupo = false;
        if (resp && resp.success === false) {
          this.notification.error(resp.message || 'Não foi possível distribuir o pagamento.');
          return;
        }
        this.notification.success(resp?.message || 'Pagamento distribuído.');
        this.carregarTitulosGrupo();
        this.carregarPendentesGrupo();
      },
      error: (err) => {
        this.carregandoGrupo = false;
        this.notification.error(this.extrairMensagemErro(err, 'Erro ao distribuir o pagamento.'));
      }
    });
  }

  /** Recarrega os títulos em aberto do grupo (após uma distribuição). */
  private carregarTitulosGrupo(): void {
    if (!this.clienteGrupo) return;
    this.service.listarTitulosGrupo(this.clienteGrupo.cgc).subscribe({
      next: (items) => { this.titulosGrupo = items || []; this.filtrarGrupo(); },
      error: () => { /* silencioso */ }
    });
  }

  /**
   * Abre o modal de detalhes do cliente já na aba desejada:
   * 'titulos' (coluna Detalhes) ou 'grupoAd' (coluna AD).
   */
  abrirDetalhes(cliente: ClienteAgrupado, tab: TabModalDetalhe = 'titulos'): void {
    this.clienteDetalhe = cliente;
    this.modalTabDetalhe = tab;
    this.titulosDetalhe = [];
    this.titulosSelecionados = [];
    this.adTitulosDetalhe = [];
    this.adSelecionados = [];
    this.carregandoDetalhe = true;
    this.carregarTitulosDetalhe();
    this.carregarAdDetalhe();
    this.modalDetalhe.open();
  }

  private carregarTitulosDetalhe(): void {
    if (!this.clienteDetalhe) return;

    // Respeita a aba ativa na grid principal (ex.: aberto a partir de
    // "Pendente" só deve trazer títulos Pendente). Na aba "Todas" o status
    // fica indefinido e traz todos os títulos do cliente.
    this.service.listarPlanilhas({
      pagina: 1,
      itensPorPagina: ITENS_POR_PAGINA_DETALHE,
      empresa: this.empresaSelecionada,
      cgc: this.clienteDetalhe.cgc,
      status: this.tabParaStatus(this.tabAtiva)
    }).subscribe({
      next: (resp) => {
        // Aba "Títulos" traz apenas documentos com título vinculado — ou
        // seja, o complemento das regras de AD: título preenchido e espécie
        // diferente de "AD". Os registros de AD ficam só na aba Grupo AD.
        this.titulosDetalhe = resp.items.filter(t => !!t.codTitAcr && t.codEspecDocto !== 'AD');
        this.titulosSelecionados = [];
        this.carregandoDetalhe = false;
      },
      error: () => {
        this.carregandoDetalhe = false;
        this.notification.error('Erro ao carregar os títulos do cliente.');
      }
    });
  }

  private carregarAdDetalhe(): void {
    if (!this.clienteDetalhe) return;

    // Respeita a aba ativa da grid principal (ex.: aberto a partir de
    // "Pendente" só traz adiantamentos Pendente). Na aba "Todas" o status
    // fica indefinido e traz todos os adiantamentos do cliente.
    this.service.listarAdCliente(this.clienteDetalhe.cgc, this.tabParaStatus(this.tabAtiva)).subscribe({
      next: (itens) => {
        this.adTitulosDetalhe = itens;
      },
      error: () => {
        this.notification.warning('Não foi possível carregar os adiantamentos (Grupo AD) do cliente.');
      }
    });
  }

  onTabModalDetalheChange(tab: TabModalDetalhe): void {
    this.modalTabDetalhe = tab;
  }

  /**
   * Extrai a mensagem de erro real devolvida pelo backend Datasul (que
   * embrulha o corpo em formatos diferentes conforme a rota). Cai para o
   * status HTTP quando não consegue reconhecer o corpo, para nunca deixar
   * o usuário "sem saber qual erro deu".
   */
  private extrairMensagemErro(err: any, padrao: string): string {
    try {
      const body = typeof err?.error === 'string' ? JSON.parse(err.error) : err?.error;
      const msg = body?.error || body?.response?.error || body?.message || body?.response?.message;
      if (msg) return msg;
    } catch { /* corpo não é JSON — usa fallback abaixo */ }

    if (err?.status) {
      return `${padrao} (HTTP ${err.status}${err.statusText ? ' - ' + err.statusText : ''})`;
    }
    return padrao;
  }

  eliminarTituloDetalhe(titulo: Planilha): void {
    this.dialog.confirm({
      title: 'Confirmar exclusão',
      message: `Deseja excluir o título ${titulo.codTitAcr} / parcela ${titulo.codParcela}?`,
      literals: { confirm: 'Excluir', cancel: 'Cancelar' },
      confirm: () => {
        this.service.deletarTitulo(titulo).subscribe({
          next: () => {
            this.notification.success(`Título ${titulo.codTitAcr} excluído.`);
            this.titulosDetalhe = this.titulosDetalhe.filter(t => t.id !== titulo.id);
          },
          error: (err) => {
            this.notification.error(this.extrairMensagemErro(err, 'Erro ao excluir título.'));
          }
        });
      }
    });
  }

  // ── Seleção (checkbox) na aba Títulos do modal ──────────────────

  onTituloSelecionado(item: Planilha): void {
    if (!this.titulosSelecionados.find(t => t.id === item.id)) {
      this.titulosSelecionados = [...this.titulosSelecionados, item];
    }
  }

  onTituloDeselecionado(item: Planilha): void {
    this.titulosSelecionados = this.titulosSelecionados.filter(t => t.id !== item.id);
  }

  onTodosTitulosSelecionados(): void {
    this.titulosSelecionados = [...this.titulosDetalhe];
  }

  onTodosTitulosDeselecionados(): void {
    this.titulosSelecionados = [];
  }

  /**
   * Processa apenas os títulos marcados (checkbox). Envia o CGC do cliente
   * + as chaves compostas selecionadas (`idsSel`, array de strings); o
   * backend restringe a baixa a esses títulos. Sem seleção, o botão fica
   * desabilitado.
   */
  processarTitulosSelecionados(): void {
    if (!this.clienteDetalhe || this.titulosSelecionados.length === 0) return;

    // Se algum título selecionado é de importação por lote, processa por lote:
    // o backend agrupa os selecionados por estabelecimento, cria um lote no
    // Datasul por estab e grava a referência criada de volta em cada título.
    if (this.titulosSelecionados.some(t => t.isLote)) {
      this.processarLoteSelecionados(this.titulosSelecionados.map(t => t.id));
      return;
    }
    this.processarPorIds(this.titulosSelecionados.map(t => t.id), this.titulosSelecionados.length);
  }

  /**
   * Processa liquidação por lote dos títulos selecionados: o backend agrupa por
   * estabelecimento, cria um lote de liquidação por estab e grava a referência
   * gerada de volta em cada título (para exibir no modal).
   */
  private processarLoteSelecionados(idsSel: string[]): void {
    if (idsSel.length === 0) return;
    this.processando = true;
    this.bloquearTela = true;
    this.textoLoading = 'Processando liquidação por lote...';

    this.service.processarLote(idsSel).subscribe({
      next: (resp: any) => {
        if (resp && resp.success === false) {
          this.notification.warning(resp.message || 'Liquidação por lote não efetivada.');
        } else {
          this.notification.success(resp?.message || 'Liquidação por lote efetivada.');
        }
        this.processando = false;
        this.bloquearTela = false;
        this.titulosSelecionados = [];
        this.adSelecionados = [];
        this.carregandoDetalhe = true;
        this.carregarTitulosDetalhe();
        this.carregarAdDetalhe();
      },
      error: (err) => {
        this.processando = false;
        this.bloquearTela = false;
        this.notification.error(this.extrairMensagemErro(err, 'Erro ao processar a liquidação por lote.'));
      }
    });
  }

  /** Chamada compartilhada de processamento por lista de ids compostos. */
  private processarPorIds(idsSel: string[], qtd: number): void {
    if (!this.clienteDetalhe || idsSel.length === 0) return;

    this.processando = true;
    this.bloquearTela = true;
    this.textoLoading = `Processando ${qtd} título(s)...`;

    this.service.processarSelecionados([this.clienteDetalhe.cgc], idsSel).subscribe({
      next: () => {
        this.notification.success('Títulos enviados para processamento.');
        this.processando = false;
        this.bloquearTela = false;
        this.titulosSelecionados = [];
        this.adSelecionados = [];
        this.carregandoDetalhe = true;
        this.carregarTitulosDetalhe();
        this.carregarAdDetalhe();
      },
      error: (err) => {
        this.processando = false;
        this.bloquearTela = false;
        this.notification.error(this.extrairMensagemErro(err, 'Erro ao processar os títulos selecionados.'));
      }
    });
  }

  /** Exclui os títulos marcados (checkbox) em lote, após confirmação. */
  excluirTitulosSelecionados(): void {
    if (this.titulosSelecionados.length === 0) return;

    const ids = this.titulosSelecionados.map(t => t.id);
    this.dialog.confirm({
      title: 'Confirmar exclusão',
      message: `Deseja excluir ${ids.length} título(s) selecionado(s)?`,
      literals: { confirm: 'Excluir', cancel: 'Cancelar' },
      confirm: () => {
        this.bloquearTela = true;
        this.textoLoading = 'Removendo títulos...';
        this.service.removerSelecionados(ids).subscribe({
          next: () => {
            this.bloquearTela = false;
            this.notification.success(`${ids.length} título(s) removido(s).`);
            const removidos = new Set(ids);
            this.titulosDetalhe = this.titulosDetalhe.filter(t => !removidos.has(t.id));
            this.titulosSelecionados = [];
          },
          error: (err) => {
            this.bloquearTela = false;
            this.notification.error(this.extrairMensagemErro(err, 'Erro ao remover os títulos selecionados.'));
          }
        });
      }
    });
  }

  /**
   * Processa os adiantamentos (AD) marcados. Usa a mesma rotina do
   * "Processar Selecionados" dos títulos (envia as chaves via `idsSel`);
   * como esses registros têm série/título em branco, o backend cria o AD
   * ao processá-los.
   */
  processarAdSelecionados(): void {
    if (!this.clienteDetalhe || this.adSelecionados.length === 0) return;
    this.processarPorIds(
      this.adSelecionados.map(a => a.id!).filter(id => !!id),
      this.adSelecionados.length
    );
  }

  /** Exclui os adiantamentos (AD) marcados em lote, após confirmação. */
  excluirAdSelecionados(): void {
    if (this.adSelecionados.length === 0) return;

    const ids = this.adSelecionados.map(a => a.id!).filter(id => !!id);
    this.dialog.confirm({
      title: 'Confirmar exclusão',
      message: `Deseja excluir ${ids.length} adiantamento(s) selecionado(s)?`,
      literals: { confirm: 'Excluir', cancel: 'Cancelar' },
      confirm: () => {
        this.bloquearTela = true;
        this.textoLoading = 'Removendo adiantamentos...';
        this.service.removerSelecionados(ids).subscribe({
          next: () => {
            this.bloquearTela = false;
            this.notification.success(`${ids.length} adiantamento(s) removido(s).`);
            this.adSelecionados = [];
            this.carregarAdDetalhe();
            this.carregarTitulosDetalhe();
          },
          error: (err) => {
            this.bloquearTela = false;
            this.notification.error(this.extrairMensagemErro(err, 'Erro ao remover os adiantamentos selecionados.'));
          }
        });
      }
    });
  }

  onAdSelecionado(item: AdTitulo): void {
    if (!this.adSelecionados.find(i => i.id === item.id)) {
      this.adSelecionados = [...this.adSelecionados, item];
    }
  }

  onAdDeselecionado(item: AdTitulo): void {
    this.adSelecionados = this.adSelecionados.filter(i => i.id !== item.id);
  }

  onTodosAdSelecionados(): void {
    this.adSelecionados = [...this.adTitulosDetalhe];
  }

  onTodosAdDeselecionados(): void {
    this.adSelecionados = [];
  }

  fecharDetalhes(): void {
    this.modalDetalhe.close();
    this.clienteDetalhe = null;
    this.titulosDetalhe = [];
    this.titulosSelecionados = [];
    this.adTitulosDetalhe = [];
    this.adSelecionados = [];
    this.carregarClientes();
  }

  // ─────────────────────────────────────────────

  constructor(
    private readonly service: ConsolidacaoPlanilhasService,
    private readonly notification: PoNotificationService,
    private readonly dialog: PoDialogService,
    public readonly rpwService: TotvsScheduleExecutionService
  ) { }

  ngOnInit(): void {
    this.montarColunasClientes();
    this.carregarFiltrosRelatorioLocalStorage();
    this.buscaSubscription = this.buscaSubject.pipe(
      debounceTime(400),
      distinctUntilChanged()
    ).subscribe(() => this.carregarClientes());

    // Sem empresa selecionada não há o que carregar — ver `onEmpresaChange`.
    this.carregarEmpresas();
  }

  ngOnDestroy(): void {
    this.pararPolling();
    this.buscaSubscription?.unsubscribe();
  }

  onBuscaChange(termo: string): void {
    this.termoBusca = termo;
    this.buscaSubject.next(termo);
  }

  limparBusca(): void {
    this.termoBusca = '';
    this.carregarClientes();
  }

  // ─────────────────────────────────────────────
  // Carregamento de dados
  // ─────────────────────────────────────────────

  carregarEmpresas(): void {
    this.service.listarEmpresas().subscribe({
      next: (lista) => {
        // 1ª opção "Todas empresas" (traz todos os estabelecimentos de todas
        // as empresas); demais no formato "nome_abrev - cod_empresa".
        // A página abre com empresaSelecionada = '' (nada carregado) até o
        // usuário escolher uma opção.
        this.empresas = [
          { value: EMPRESA_TODAS, label: 'Todas empresas' },
          ...lista.map(e => ({ value: e.codEmpresa, label: `${e.codEmpresa} - ${e.descricao}` }))
        ];
      },
      error: () => this.notification.warning('Não foi possível carregar a lista de empresas.')
    });
  }

  carregarClientes(resetarPagina = true): void {
    if (!this.empresaSelecionada) {
      this.clientes = [];
      this.clientesFiltrados = [];
      this.totalItens = 0;
      this.temMais = false;
      this.carregando = false;
      this.carregandoMais = false;
      return;
    }

    if (resetarPagina) {
      this.paginaAtual = 1;
      this.clientes = [];
      this.limparSelecao();
    }

    this.carregando = true;

    const termo = this.termoBusca.trim();
    const ehCgc = termo.length > 0 && /^[\d.\-\/]+$/.test(termo);

    // Envia filtro de status da tab ativa + filtros avançados
    const statusTab = this.tabParaStatus(this.tabAtiva);

    this.service.listarClientes({
      pagina: this.paginaAtual,
      itensPorPagina: ITENS_POR_PAGINA,
      empresa: this.empresaSelecionada || undefined,
      status: statusTab,
      cgc: this.filtroCnpj || (ehCgc ? termo : undefined),
      nomeEmit: !ehCgc && termo ? termo : undefined,
      dataIni: this.filtroDataIni || undefined,
      dataFim: this.filtroDataFim || undefined
    }).subscribe({
      next: (resp) => {
        this.clientes = resetarPagina ? resp.items : [...this.clientes, ...resp.items];
        this.totalItens = resp.totalItens;
        this.temMais = resp.hasNext;
        this.carregando = false;
        this.carregandoMais = false;
        this.recalcularListas();
      },
      error: () => {
        this.notification.error('Erro ao carregar os clientes. Verifique a conexão com a API.');
        this.carregando = false;
        this.carregandoMais = false;
      }
    });
  }

  /** Chamado pelo botão "Carregar mais" da po-table */
  carregarMais(): void {
    if (!this.temMais || this.carregandoMais) return;
    this.carregandoMais = true;
    this.paginaAtual++;
    this.carregarClientes(false);
  }

  // ─────────────────────────────────────────────
  // Tabs
  // ─────────────────────────────────────────────

  onTabChange(tab: TabAtiva): void {
    this.tabAtiva = tab;
    this.montarColunasClientes();
    this.carregarClientes();
  }

  private tabParaStatus(tab: TabAtiva): StatusPlanilha | undefined {
    const mapa: Partial<Record<TabAtiva, StatusPlanilha>> = {
      processadas: 'Importado',
      pendentes: 'Pendente',
      comErro: 'Erro'
    };
    return mapa[tab];
  }

  // ─────────────────────────────────────────────
  // Filtro de empresa
  // ─────────────────────────────────────────────

  onEmpresaChange(empresa: string): void {
    this.empresaSelecionada = empresa;

    // Zera imediatamente ao trocar de empresa, para nunca mostrar na tela
    // registros/contadores da empresa anterior enquanto a nova busca roda.
    this.clientes = [];
    this.clientesFiltrados = [];
    this.totalItens = 0;
    this.temMais = false;
    this.paginaAtual = 1;
    this.contadores = { todas: 0, pendentes: 0, processadas: 0, comErro: 0 };
    this.limparSelecao();

    this.carregarClientes();
  }

  // ─────────────────────────────────────────────
  // Drawer de filtros avançados
  // ─────────────────────────────────────────────

  drawerFiltrosAberto = false;

  abrirDrawerFiltros(): void {
    this.drawerFiltrosAberto = true;
  }

  fecharDrawerFiltros(): void {
    this.drawerFiltrosAberto = false;
  }

  carregarFiltrosRelatorioLocalStorage(): void {
    const salvo = localStorage.getItem('filtroRelatorioAcr');
    if (salvo) {
      try {
        const filtros = JSON.parse(salvo);
        if (filtros.cnpjIni !== undefined) this.relatorioCnpjIni = filtros.cnpjIni;
        if (filtros.cnpjFim !== undefined) this.relatorioCnpjFim = filtros.cnpjFim;
        if (filtros.estabIni !== undefined) this.relatorioEstabIni = filtros.estabIni;
        if (filtros.estabFim !== undefined) this.relatorioEstabFim = filtros.estabFim;
        if (filtros.serieIni !== undefined) this.relatorioSerieIni = filtros.serieIni;
        if (filtros.serieFim !== undefined) this.relatorioSerieFim = filtros.serieFim;
        if (filtros.tituloIni !== undefined) this.relatorioTituloIni = filtros.tituloIni;
        if (filtros.tituloFim !== undefined) this.relatorioTituloFim = filtros.tituloFim;
        if (filtros.situacao !== undefined) this.relatorioSituacao = filtros.situacao;
        if (filtros.implantacao !== undefined) this.relatorioImplantacao = filtros.implantacao;
        if (filtros.apenasLote !== undefined) this.relatorioApenasLote = filtros.apenasLote;
      } catch (e) {
        console.error('Erro ao ler filtro salvo', e);
      }
    }
  }

  aplicarFiltrosEFechar(): void {
    this.drawerFiltrosAberto = false;
    this.carregarClientes();
  }

  aplicarFiltros(): void {
    this.carregarClientes();
  }

  limparFiltros(): void {
    this.filtroDataIni = '';
    this.filtroDataFim = '';
    this.filtroCnpj = '';
    this.carregarClientes();
  }

  /**
   * Quando a data de início é alterada, limpa a data fim
   * caso ela seja anterior à nova data início.
   */
  onDataIniChange(novaDataIni: string | Date): void {
    if (this.filtroDataFim && this.filtroDataIni) {
      const ini = new Date(this.filtroDataIni);
      const fim = new Date(this.filtroDataFim);
      if (fim < ini) {
        this.filtroDataFim = '';
      }
    }
  }

  // ─────────────────────────────────────────────
  // Paginação
  // ─────────────────────────────────────────────

  get totalPaginas(): number {
    return Math.max(1, Math.ceil(this.totalItens / ITENS_POR_PAGINA));
  }

  get paginasVisiveis(): number[] {
    const total = this.totalPaginas;
    const atual = this.paginaAtual;
    const paginas: number[] = [];
    const range = 2; // Mostra 2 páginas antes e depois da atual

    let inicio = Math.max(1, atual - range);
    let fim = Math.min(total, atual + range);

    // Garante pelo menos 5 botões quando possível
    if (fim - inicio < range * 2) {
      if (inicio === 1) fim = Math.min(total, inicio + range * 2);
      else if (fim === total) inicio = Math.max(1, fim - range * 2);
    }

    for (let i = inicio; i <= fim; i++) paginas.push(i);
    return paginas;
  }

  irParaPagina(pagina: number): void {
    if (pagina < 1 || pagina > this.totalPaginas || pagina === this.paginaAtual) return;
    this.paginaAtual = pagina;
    this.clientes = [];
    this.limparSelecao();
    this.carregarClientes(false);
  }

  // ─────────────────────────────────────────────
  // Seleção na tabela
  // ─────────────────────────────────────────────

  onItemSelecionado(item: ClienteAgrupado): void {
    if (!this.itensSelecionados.find(i => i.id === item.id)) {
      this.itensSelecionados = [...this.itensSelecionados, item];
    }
    this.atualizarStatusSelecionarTodos();
  }

  onItemDeselecionado(item: ClienteAgrupado): void {
    this.itensSelecionados = this.itensSelecionados.filter(i => i.id !== item.id);
    this.atualizarStatusSelecionarTodos();
  }

  onTodosSelecionadosPelaTabela(): void {
    this.clientesFiltrados.forEach(c => c.$selected = true);
    this.itensSelecionados = [...this.clientesFiltrados];
    this.todosSelecionados = true;
  }

  onTodosDeselecionadosPelaTabela(): void {
    this.clientesFiltrados.forEach(c => c.$selected = false);
    this.itensSelecionados = [];
    this.todosSelecionados = false;
  }

  onSelecionarTodos(selecionado: boolean): void {
    this.todosSelecionados = selecionado;
    this.clientesFiltrados.forEach(c => (c.$selected = selecionado));
    this.itensSelecionados = selecionado ? [...this.clientesFiltrados] : [];
  }

  private atualizarStatusSelecionarTodos(): void {
    if (this.clientesFiltrados.length === 0) {
      this.todosSelecionados = false;
      return;
    }
    this.todosSelecionados = this.clientesFiltrados.every(c =>
      this.itensSelecionados.some(sel => sel.id === c.id)
    );
  }

  private limparSelecao(): void {
    this.itensSelecionados = [];
    this.todosSelecionados = false;
    this.clientes.forEach(c => (c.$selected = false));
  }

  // ─────────────────────────────────────────────
  // Ações em lote
  // ─────────────────────────────────────────────

  processarSelecionados(): void {
    const cgcs = [...new Set(this.itensSelecionados.map(c => c.cgc))];
    this.processando = true;
    this.bloquearTela = true;
    this.textoLoading = 'Processando registros...';
    this.progresso = {
      ids: cgcs,
      totalRegistros: this.itensSelecionados.reduce((soma, c) => soma + c.qtdTitulos, 0),
      processados: 0,
      comErro: 0,
      status: 'processando',
      percentual: 0,
      mensagem: 'Iniciando processamento...'
    };

    this.service.processarSelecionados(cgcs).subscribe({
      next: () => {
        this.notification.success(`Enviado para processamento.`);
        this.processando = false;
        this.progresso = null;
        this.bloquearTela = false;
        this.carregarClientes();
      },
      error: (err) => {
        this.processando = false;
        this.progresso = null;
        this.bloquearTela = false;
        this.notification.error(this.extrairMensagemErro(err, 'Erro ao processar selecionados.'));
      }
    });
  }

  processarTodosPendentes(): void {
    const total = this.contadores.pendentes + this.contadores.comErro;
    if (total === 0) {
      this.notification.warning('Não há registros pendentes ou com erro para processar.');
      return;
    }

    this.totalPendentes = total;

    this.dialog.confirm({
      title: 'Processar Todos',
      message: `Deseja criar uma execução via RPW?`,
      literals: { confirm: 'Sim', cancel: 'Não' },
      confirm: () => {
        this.servidorRpwPendentes = '';
        this.carregarServidoresRpw(() => this.modalRpwPendentes.open());
      },
      cancel: () => {
        this.executarProcessamentoTodosPendentesNormal(total);
      }
    });
  }

  fecharModalRpwPendentes(): void {
    this.modalRpwPendentes.close();
  }

  private addZero(num: number): string {
    return num < 10 ? `0${num}` : num.toString();
  }

  executarRpwPendentes(): void {
    if (!this.servidorRpwPendentes) {
       this.notification.warning('Selecione um servidor RPW.');
       return;
    }

    const date = new Date();
    date.setMinutes(date.getMinutes() + 10);

    const dateStr = `${date.getFullYear()}-${this.addZero(date.getMonth() + 1)}-${this.addZero(date.getDate())}`;
    const timeStr = `${this.addZero(date.getHours())}:${this.addZero(date.getMinutes())}`;
    const firstExecution = `${dateStr}T${timeStr}:00.000Z`;

    const jsonObject: any = {
      status: 'active',
      processID: 'importa-tit-acr-rpw',
      recurrent: false,
      firstExecution: firstExecution,
      executionParameter: {
         parametros: [
           { chave: 'rpwServer', valor: this.servidorRpwPendentes },
           { chave: 'RPW_PROGRAM', valor: 'esp/importa-tit-acr-rpw.w' },
           { chave: 'RPW_PRG_EMS5', valor: 'no' },
           { chave: 'RPW_PRG_ESTILO', valor: 0 },
           { chave: 'RPW_PRG_VERS', valor: '1.00.00.001' }
         ]
      }
    };

    this.rpwService.createExecution(jsonObject, true).subscribe({
      next: (response: any) => {
         this.notification.success(`Foi criado pedido de execução`);
         this.fecharModalRpwPendentes();

         this.executarProcessamentoTodosPendentesNormal(this.totalPendentes);
      },
      error: () => {
         this.notification.error('Erro ao criar pedido de execução.');
         this.fecharModalRpwPendentes();
      }
    });
  }

  executarProcessamentoTodosPendentesNormal(total: number): void {
    this.processando = true;
    this.bloquearTela = true;
    this.textoLoading = 'Processando todos os registros pendentes e com erro...';
    this.progresso = {
      ids: [],
      totalRegistros: total,
      processados: 0,
      comErro: 0,
      status: 'processando',
      percentual: 0,
      mensagem: 'Iniciando processamento de todos os pendentes...'
    };

    this.service.processarTodosPendentes().subscribe({
      next: () => {
        this.notification.success('Todos os registros pendentes foram enviados para processamento.');
        this.processando = false;
        this.progresso = null;
        this.bloquearTela = false;
        this.carregarClientes();
      },
      error: (err) => {
        this.processando = false;
        this.progresso = null;
        this.bloquearTela = false;
        this.notification.error(this.extrairMensagemErro(err, 'Erro ao processar registros.'));
      }
    });
  }

  /**
   * Remove todos os títulos dos clientes selecionados.
   * Não existe endpoint de remoção em lote por CGC — por isso primeiro
   * busca os IDs de título de cada cliente selecionado, depois chama o
   * endpoint de remoção em lote existente (por IDs) uma única vez.
   */
  removerSelecionados(): void {
    if (this.itensSelecionados.length === 0) return;

    this.bloquearTela = true;
    this.textoLoading = 'Removendo registros...';

    const buscasPorCliente = this.itensSelecionados.map(cliente =>
      this.service.listarPlanilhas({
        pagina: 1,
        itensPorPagina: ITENS_POR_PAGINA_DETALHE,
        empresa: this.empresaSelecionada,
        cgc: cliente.cgc
      }).pipe(
        map(resp => resp.items.map(t => t.id)),
        catchError(() => of([] as string[]))
      )
    );

    forkJoin(buscasPorCliente).subscribe({
      next: (listasDeIds) => {
        const ids = listasDeIds.flat();
        if (ids.length === 0) {
          this.bloquearTela = false;
          this.notification.warning('Nenhum título encontrado para os clientes selecionados.');
          return;
        }

        this.service.removerSelecionados(ids).subscribe({
          next: () => {
            this.bloquearTela = false;
            this.notification.success(`${ids.length} título(s) removido(s) com sucesso.`);
            this.carregarClientes();
          },
          error: (err) => {
            this.bloquearTela = false;
            this.notification.error(this.extrairMensagemErro(err, 'Erro ao remover selecionados.'));
          }
        });
      },
      error: () => {
        this.bloquearTela = false;
        this.notification.error('Erro ao buscar os títulos dos clientes selecionados.');
      }
    });
  }

  /**
   * Remove TODOS os documentos pendentes e com erro (nao mexe nos ja
   * importados). Espelha o "Processar Todos Pendentes": pede confirmacao e,
   * se sim, chama o endpoint de remocao em lote com { removerTodos: true }.
   */
  removerTodos(): void {
    const total = this.contadores.pendentes + this.contadores.comErro;
    if (total === 0) {
      this.notification.warning('Não há registros pendentes ou com erro para remover.');
      return;
    }

    this.dialog.confirm({
      title: 'Remover Todos',
      message: 'Ao remover todos serão removidos os documentos pendentes e com erro, deseja remover?',
      literals: { confirm: 'Sim', cancel: 'Não' },
      confirm: () => {
        this.bloquearTela = true;
        this.textoLoading = 'Removendo todos os registros pendentes e com erro...';
        this.service.removerTodos().subscribe({
          next: () => {
            this.bloquearTela = false;
            this.notification.success('Registros pendentes e com erro removidos com sucesso.');
            this.carregarClientes();
          },
          error: (err) => {
            this.bloquearTela = false;
            this.notification.error(this.extrairMensagemErro(err, 'Erro ao remover todos os registros.'));
          }
        });
      }
    });
  }

  // ─────────────────────────────────────────────
  // Polling de progresso
  // ─────────────────────────────────────────────

  private pararPolling(): void {
    this.pollingSubscription?.unsubscribe();
    this.pollingSubscription = null;
  }

  // ─────────────────────────────────────────────
  // Modal de importação — fluxo RPW (dts-backoffice-util)
  // ─────────────────────────────────────────────

  readonly acaoFecharImportacao: PoModalAction = {
    label: 'Fechar',
    action: () => this.modalImportacao.close()
  };

  abrirModalImportacao(): void {
    this.empresaImportacao = this.empresaSelecionada;
    this.tipoLiquidacao = 'ad';
    this.liquidaParcial = false;
    this.numLoteImport = '';
    this.etapaModal = 'formulario';
    this.totalRegistrosImportacao = 0;
    this.registrosProcessados = 0;
    this.percentualImportacao = 0;
    this.statusProcessamento = '';
    this.modalImportacao.open();
  }

  fecharModal(): void {
    this.carregarClientes();
    this.etapaModal = 'formulario';
  }

  gerandoRelatorio = false;
  resultadosImportacao: any[] = [];

  baixarRelatorio(): void {
    if (this.gerandoRelatorio) return;
    this.gerandoRelatorio = true;

    if (!this.resultadosImportacao || this.resultadosImportacao.length === 0) {
      this.notification.warning('Nenhum resultado de importação disponível.');
      this.gerandoRelatorio = false;
      return;
    }

    // Gerar Excel no browser usando XLSX.js com os resultados acumulados
    const dadosExcel = this.resultadosImportacao.map((r: any) => ({
      'CGC/CPF': r.cgc || '',
      'Estab': r.estab || '',
      'Lote': r.lote || '',
      'Especie': r.especie || '',
      'Serie': r.serie || '',
      'Titulo': r.titulo || '',
      'Parcela': r.parcela || '',
      'Valor': (r.valor != null && r.valor !== '') ? Number(r.valor).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : '',
      'Observacao': r.observacao || '',
      'Situacao': r.situacao || '',
      'Mensagem': r.mensagem || ''
    }));

    const ws = XLSX.utils.json_to_sheet(dadosExcel);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Resultado da Importacao');

    // Auto-ajustar largura das colunas
    const colWidths = Object.keys(dadosExcel[0]).map(key => ({
      wch: Math.max(key.length + 2, ...dadosExcel.map((r: any) => String(r[key] || '').length + 2))
    }));
    ws['!cols'] = colWidths;

    XLSX.writeFile(wb, 'resultado_importacao.xlsx');
    this.notification.success(`Relatório gerado com ${this.resultadosImportacao.length} registros.`);
    this.gerandoRelatorio = false;
  }

  /**
   * Layout esperado da planilha de baixa (0-based). Cada coluna precisa estar
   * exatamente nesta posição — a validação é feita ANTES de importar.
   */
  private readonly layoutImportacao: { idx: number; nome: string; rotulo: string }[] = [
    { idx: 0,  nome: 'empresa',          rotulo: 'empresa' },
    { idx: 1,  nome: 'data_geracao',     rotulo: 'data_geracao' },
    { idx: 2,  nome: 'cnpj',             rotulo: 'cnpj' },
    { idx: 3,  nome: 'estabelecimento',  rotulo: 'estabelecimento' },
    { idx: 4,  nome: 'especie',          rotulo: 'especie' },
    { idx: 5,  nome: 'serie',            rotulo: 'serie' },
    { idx: 6,  nome: 'titulo',           rotulo: 'titulo' },
    { idx: 7,  nome: 'parcela',          rotulo: 'parcela' },
    { idx: 8,  nome: 'portador',         rotulo: 'portador' },
    { idx: 9,  nome: 'carteira',         rotulo: 'carteira' },
    { idx: 10, nome: 'vl_recebido',      rotulo: 'vl_recebido' },
    { idx: 11, nome: 'juros',            rotulo: 'juros' },
    { idx: 12, nome: 'multa',            rotulo: 'multa' },
    { idx: 13, nome: 'desconto',         rotulo: 'desconto' },
    { idx: 14, nome: 'abatimento',       rotulo: 'abatimento' },
    { idx: 15, nome: 'status',           rotulo: 'status' }
  ];

  /** Converte índice 0-based em letra de coluna (0→A, 1→B, ...). */
  private letraColuna(idx: number): string {
    let s = '';
    let n = idx;
    do { s = String.fromCharCode(65 + (n % 26)) + s; n = Math.floor(n / 26) - 1; } while (n >= 0);
    return s;
  }

  /**
   * Valida o cabeçalho da planilha contra `layoutImportacao`. Retorna a lista
   * de mensagens de erro (vazia se o layout estiver correto). Normaliza o
   * cabeçalho (minúsculas, sem acento, espaços → "_") antes de comparar.
   */
  private validarLayoutImportacao(header: any[]): string[] {
    const norm = (v: any) => String(v ?? '')
      .trim()
      .toLowerCase()
      .normalize('NFD').replace(/[̀-ͯ]/g, '')
      .replace(/[\s\-\/]+/g, '_');
    const erros: string[] = [];
    for (const c of this.layoutImportacao) {
      if (norm(header[c.idx]) !== c.nome) {
        const letra = this.letraColuna(c.idx);
        erros.push(`Coluna "${c.rotulo}" não identificada. A coluna "${c.rotulo}" deve ser a coluna ${letra}.`);
      }
    }
    return erros;
  }

  onFileChange(files: any): void {
    const file = files && files.length > 0 ? files[0] : files;
    const rawFile = file.rawFile || file;

    if (!rawFile) return;

    // Importação por lote: gera um identificador único (ddmmaahhmmss) que
    // vincula todos os títulos desta carga. O backend grava esse valor no
    // cod_arq_origem ("Lote:<id>") de cada título importado.
    this.numLoteImport = this.tipoLiquidacao === 'lote' ? this.gerarNumeroLote() : '';

    this.etapaModal = 'processando';
    this.statusProcessamento = 'Lendo arquivo localmente...';
    this.resultadosImportacao = []; // Limpar resultados anteriores

    const reader = new FileReader();
    reader.onload = (e: any) => {
      try {
        const data = e.target.result;
        const workbook = XLSX.read(data, { type: 'binary', cellDates: true });
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];

        const jsonData: any[][] = XLSX.utils.sheet_to_json(worksheet, { header: 1, raw: false, dateNF: 'DD/MM/YYYY', defval: '' });

        // Validação do layout: cada coluna precisa estar na posição esperada.
        const header = (jsonData[0] || []) as any[];
        const errosLayout = this.validarLayoutImportacao(header);
        if (errosLayout.length > 0) {
          this.notification.error('Layout da planilha inválido. ' + errosLayout.join(' '));
          this.etapaModal = 'formulario';
          return;
        }

        // Data (col B) "." → "/" e formatação das colunas de valor (pt-BR).
        // Colunas de valor (0-based): 10 vl_recebido, 11 juros, 12 multa, 13 desconto, 14 abatimento.
        const colunasValor = [10, 11, 12, 13, 14];
        for (let r = 1; r < jsonData.length; r++) {
          const row = jsonData[r];
          // Data (col B): se veio como Date do Excel, formata dd/MM/yyyy (evita a
          // inversão dia/mês quando o Excel devolve mm/dd). Se veio texto, troca "." por "/".
          const rawData = row[1];
          if (rawData instanceof Date && !isNaN(rawData.getTime())) {
            const dd = String(rawData.getDate()).padStart(2, '0');
            const mm = String(rawData.getMonth() + 1).padStart(2, '0');
            row[1] = `${dd}/${mm}/${rawData.getFullYear()}`;
          } else if (rawData != null && rawData !== '') {
            row[1] = String(rawData).replace(/\./g, '/');
          }
          for (const colIdx of colunasValor) {
            if (row[colIdx] != null && row[colIdx] !== '') {
              const num = this.parseValorMonetario(String(row[colIdx]));
              if (!isNaN(num)) {
                row[colIdx] = num.toLocaleString('pt-BR', {
                  useGrouping: false,
                  minimumFractionDigits: 2,
                  maximumFractionDigits: 2
                });
              }
            }
          }
        }

        if (jsonData.length > 1) {
          jsonData.shift(); // Remove cabeçalho

          // Planilha grande (> LIMITE_RPW_IMPORT): processa via RPW em background.
          if (jsonData.length > LIMITE_RPW_IMPORT) {
            this.prepararImportacaoRpw(jsonData);
            return;
          }

          this.totalRegistrosImportacao = jsonData.length;
          this.registrosProcessados = 0;
          this.percentualImportacao = 0;
          this.statusProcessamento = 'Enviando lotes para o servidor...';

          this.enviarLotesImportacao(jsonData);
        } else {
          this.notification.error('Arquivo vazio ou formato inválido.');
          this.etapaModal = 'formulario';
        }
      } catch (err) {
        this.notification.error('Erro ao ler a planilha Excel.');
        this.etapaModal = 'formulario';
      }
    };
    reader.readAsBinaryString(rawFile);
  }

  /**
   * Planilha com mais de LIMITE_RPW_IMPORT registros: monta o CSV das linhas,
   * carrega os servidores RPW ativos e abre o modal para o usuario escolher o
   * servidor. Ao confirmar, o CSV é gravado na pasta do RPW e o processamento
   * roda em background.
   */
  private prepararImportacaoRpw(rows: any[][]): void {
    this.totalRegistrosRpwImport = rows.length;

    // Monta o CSV preservando a ordem das colunas (delimitador ";"); remove
    // ";" e quebras de linha das celulas para nao quebrar o layout.
    this.csvImportacaoRpw = rows
      .map(row => (row || [])
        .map(cell => String(cell ?? '').replace(/[;\r\n]/g, ' '))
        .join(';'))
      .join('\n');

    this.servidorRpwImport = '';

    this.carregarServidoresRpw(
      () => {
        this.modalImportacao.close();
        this.modalRpwImport.open();
      },
      () => { this.etapaModal = 'formulario'; }
    );
  }

  /**
   * Carrega os servidores RPW ativos (endpoint /rpwServidores) para os selects
   * dos modais de RPW: import de planilha grande e "Processar Todos Pendentes".
   */
  private carregarServidoresRpw(onOk: () => void, onError?: () => void): void {
    this.servidoresRpwImport = [];
    this.service.listarRpwServidores().subscribe({
      next: (resp) => {
        this.servidoresRpwImport = (resp.items || []).map((s: any) => ({
          value: s.codServidExec,
          label: `${s.codServidExec}${s.tipoFila ? ' - ' + s.tipoFila : ''}${s.descricao ? ' (' + s.descricao + ')' : ''}`
        }));
        if (this.servidoresRpwImport.length === 0) {
          this.notification.warning('Nenhum servidor RPW ativo encontrado.');
        }
        onOk();
      },
      error: (err) => {
        this.notification.error(this.extrairMensagemErro(err, 'Erro ao carregar os servidores RPW.'));
        if (onError) onError();
      }
    });
  }

  /**
   * Confirma o import via RPW: grava o CSV na pasta do RPW e, se ok, cria o
   * pedido de execução. Se a cópia falhar, mostra o erro e não cria o pedido.
   */
  executarImportRpw(): void {
    if (!this.servidorRpwImport) {
      this.notification.warning('Selecione um servidor RPW.');
      return;
    }
    if (!this.csvImportacaoRpw) {
      this.notification.error('Nenhum conteúdo de planilha para enviar.');
      return;
    }

    this.bloquearTela = true;
    this.textoLoading = 'Enviando planilha para a pasta do RPW...';

    this.service.importarRpw(this.csvImportacaoRpw, this.servidorRpwImport).subscribe({
      next: () => this.criarExecucaoImportRpw(),
      error: (err) => {
        this.bloquearTela = false;
        this.notification.error(this.extrairMensagemErro(err, 'Erro ao copiar a planilha para a pasta do RPW.'));
      }
    });
  }

  private criarExecucaoImportRpw(): void {
    const date = new Date();
    date.setMinutes(date.getMinutes() + 10);
    const dateStr = `${date.getFullYear()}-${this.addZero(date.getMonth() + 1)}-${this.addZero(date.getDate())}`;
    const timeStr = `${this.addZero(date.getHours())}:${this.addZero(date.getMinutes())}`;
    const firstExecution = `${dateStr}T${timeStr}:00.000Z`;

    const jsonObject: any = {
      status: 'active',
      processID: RPW_IMPORT_PROCESS_ID,
      recurrent: false,
      firstExecution: firstExecution,
      executionParameter: {
        parametros: [
          { chave: 'rpwServer', valor: this.servidorRpwImport },
          { chave: 'RPW_PROGRAM', valor: RPW_IMPORT_PROGRAM },
          { chave: 'RPW_PRG_EMS5', valor: 'no' },
          { chave: 'RPW_PRG_ESTILO', valor: 0 },
          { chave: 'RPW_PRG_VERS', valor: '1.00.00.001' }
        ]
      }
    };

    this.rpwService.createExecution(jsonObject, true).subscribe({
      next: () => {
        this.bloquearTela = false;
        this.modalRpwImport.close();
        this.csvImportacaoRpw = '';
        this.etapaModal = 'formulario';
        this.notification.success('Planilha enviada para processamento via RPW.');
      },
      error: () => {
        this.bloquearTela = false;
        this.notification.error('Planilha copiada, mas houve erro ao criar o pedido de execução RPW.');
      }
    });
  }

  /**
   * Converte um valor monetário vindo da planilha para number. Com
   * `raw:false`, o XLSX pode devolver o valor formatado como "1,250.00"
   * (US: vírgula=milhar, ponto=decimal) ou "1.250,00" (BR: ponto=milhar,
   * vírgula=decimal). O separador decimal é o ÚLTIMO "." ou "," encontrado;
   * os demais são milhar e são removidos. Isso evita o bug de
   * parseFloat("1,250.00") === 1 (que quebrava na vírgula e perdia o milhar).
   */
  private parseValorMonetario(valor: string): number {
    const s = valor.trim().replace(/R\$/gi, '').replace(/\s/g, '');
    if (s === '') return NaN;

    const posDecimal = Math.max(s.lastIndexOf(','), s.lastIndexOf('.'));
    if (posDecimal === -1) {
      return parseFloat(s);
    }

    const parteInteira = s.substring(0, posDecimal).replace(/[.,]/g, '');
    const parteDecimal = s.substring(posDecimal + 1);
    return parseFloat(parteInteira + '.' + parteDecimal);
  }

  /** Gera o identificador do lote no formato ddmmaahhmmss (dia/mês/ano/hora/min/seg). */
  /** Gera o identificador do lote: ddmmaa + 4 caracteres aleatórios (a-z). Ex.: "110726abcd". */
  private gerarNumeroLote(): string {
    const d = new Date();
    const p = (n: number) => n.toString().padStart(2, '0');
    const ddmmaa = p(d.getDate()) + p(d.getMonth() + 1) + p(d.getFullYear() % 100);
    let rand = '';
    for (let i = 0; i < 4; i++) {
      rand += String.fromCharCode(97 + Math.floor(Math.random() * 26));
    }
    return ddmmaa + rand;
  }

  private enviarLotesImportacao(dados: any[][]): void {
    const TAMANHO_LOTE = 50;
    let indice = 0;

    const enviarProximoLote = () => {
      if (indice >= dados.length) {
        this.statusProcessamento = 'Finalizando...';
        this.etapaModal = 'concluido';
        this.percentualImportacao = 100;
        return;
      }

      const lote = dados.slice(indice, indice + TAMANHO_LOTE);

      this.service.importarLote(lote, this.empresaImportacao, this.liquidaParcial, this.numLoteImport).subscribe({
        next: (resp: any) => {
          // Acumular resultados do lote - buscar em múltiplos wrappers possíveis
          let resultados: any[] = [];
          if (resp?.resultados) {
            resultados = resp.resultados;
          } else if (resp?.data?.resultados) {
            resultados = resp.data.resultados;
          } else if (resp?.root?.resultados) {
            resultados = resp.root.resultados;
          } else if (typeof resp === 'string') {
            try {
              const parsed = JSON.parse(resp);
              resultados = parsed?.resultados || [];
            } catch (e) { /* ignora */ }
          }

          if (resultados && resultados.length > 0) {
            this.resultadosImportacao = this.resultadosImportacao.concat(resultados);
          }

          indice += TAMANHO_LOTE;
          this.registrosProcessados = Math.min(indice, dados.length);
          this.percentualImportacao = Math.floor((this.registrosProcessados / this.totalRegistrosImportacao) * 100);
          this.statusProcessamento = `Processando... ${this.registrosProcessados} de ${this.totalRegistrosImportacao} linhas`;
          enviarProximoLote();
        },
        error: () => {
          this.notification.error('Erro ao enviar lote para o servidor.');
          this.etapaModal = 'erro';
        }
      });
    };

    enviarProximoLote();
  }

  // ─────────────────────────────────────────────
  // Helpers de template
  // ─────────────────────────────────────────────

  get semDados(): boolean {
    return !this.carregando && this.clientesFiltrados.length === 0;
  }

  get labelSelecionados(): string {
    const n = this.itensSelecionados.length;
    return `${n.toLocaleString('pt-BR')} ${n === 1 ? 'cliente selecionado' : 'clientes selecionados'}`;
  }

  get labelTotalRegistros(): string {
    const n = this.clientesFiltrados.length;
    return `${n.toLocaleString('pt-BR')} ${n === 1 ? 'cliente encontrado' : 'clientes encontrados'}`;
  }

  get percentualProgresso(): number {
    return this.progresso?.percentual ?? 0;
  }

  /** Formata valor numérico como moeda BRL (R$ 1.234,56) — seguro para null/undefined */
  formatarMoeda(valor: number | null | undefined): string {
    return (valor ?? 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  }
}

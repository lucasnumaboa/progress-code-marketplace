/**
 * Interceptor de Autenticação — TOTVS Datasul
 *
 * Coloque este arquivo em: src/app/shared/auth.interceptor.ts
 * (ou em src/app/core/interceptors/auth.interceptor.ts)
 *
 * Registre no AppModule (ou no módulo raiz) via:
 *   providers: [
 *     { provide: HTTP_INTERCEPTORS, useClass: DatasulAuthInterceptor, multi: true }
 *   ]
 *
 * O Datasul armazena o JWT de sessão em localStorage com a chave 'access_token'.
 * Se o seu ambiente usar outra chave, ajuste TOKEN_KEY abaixo.
 */

/**
 * Interceptor de Autenticação — TOTVS Datasul
 *
 * Injeta o token JWT do Datasul em todas as requisições HTTP.
 * A chave 'token-service.token' é a utilizada pelo Datasul no localStorage.
 *
 * Também extrai o login do usuário logado a partir do JWT e o disponibiliza
 * via propriedade estática `DatasulAuthInterceptor.usuarioLogado`.
 *
 * Não faz redirect manual de login: quando a app roda dentro do portal
 * Datasul, a sessão é gerenciada pelo próprio portal — em caso de expiração,
 * o Datasul faz o redirect para login automaticamente via SSO.
 */

import { Injectable } from '@angular/core';
import {
  HttpInterceptor,
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpErrorResponse
} from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

/** Chave usada pelo Datasul para armazenar o JWT no localStorage */
const TOKEN_KEY = 'token-service.token';

@Injectable()
export class DatasulAuthInterceptor implements HttpInterceptor {

  /**
   * Login do usuário logado no Datasul (ex: 'lcsoliveira').
   * Acessível de qualquer lugar via `DatasulAuthInterceptor.usuarioLogado`.
   * O Datasul armazena o login em sessionStorage com a chave 'username'.
   */
  static usuarioLogado: string = sessionStorage.getItem('username') || '';

  intercept(req: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> {
    const raw   = localStorage.getItem(TOKEN_KEY);
    const token = this.extrairAccessToken(raw);

    // Atualiza o login do usuário caso ainda não tenha sido carregado
    if (!DatasulAuthInterceptor.usuarioLogado) {
      DatasulAuthInterceptor.usuarioLogado = sessionStorage.getItem('username') || '';
    }

    const authReq = token
      ? req.clone({ headers: req.headers.set('Authorization', `Bearer ${token}`) })
      : req;

    return next.handle(authReq).pipe(
      catchError((error: HttpErrorResponse) => {
        return throwError(() => error);
      })
    );
  }

  /**
   * O Datasul armazena um objeto JSON em 'token-service.token', no formato:
   *   { "access_token": "eyJ...", "token_type": "Bearer", ... }
   *
   * Extrai apenas o `access_token` para montar o header Authorization.
   */
  private extrairAccessToken(raw: string | null): string | null {
    if (!raw) return null;
    try {
      const parsed = JSON.parse(raw);
      return parsed?.access_token ?? null;
    } catch {
      // Se não for JSON, assume que já é o token direto
      return raw;
    }
  }
}

import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, interval, map, switchMap, takeWhile } from 'rxjs';

import { DatasulAuthInterceptor } from './auth.interceptor';

import { AppConfigService } from './src/app/app-config.service';
import {
  Planilha,
  Empresa,
  LoteRequest,
  LoteRequestProcessar,
  ApiResponse,
  StatusPlanilha,
  PaginacaoParams,
  PaginacaoResponse,
  ContadoresApi,
  ProgressoProcessamento,
  ClientesPaginacaoResponse,
  AdTitulo
} from './models/planilha.model';

/** Intervalo de polling do progresso das ações em lote (ms) */
const POLLING_INTERVAL_MS = 3000;

@Injectable({
  providedIn: 'root'
})
export class ConsolidacaoPlanilhasService {

  private get API_BASE(): string { return this.config.apiBase; }

  constructor(private http: HttpClient, private config: AppConfigService) { }

  // ─────────────────────────────────────────────
  // Empresas
  // ─────────────────────────────────────────────

  listarEmpresas(): Observable<Empresa[]> {
    // Traz só as empresas em que o usuário logado tem acesso no ACR
    // (implantar/liquidar/gerar AD) — filtro feito no backend por usuário.
    const codUsuario = DatasulAuthInterceptor.usuarioLogado;
    let params = new HttpParams();
    if (codUsuario) params = params.set('codUsuario', codUsuario);
    return this.http.get<{ items: Empresa[] }>(`${this.API_BASE}/empresas`, { params }).pipe(
      map(resp => resp.items ?? [])
    );
  }

  // ─────────────────────────────────────────────
  // Contadores (server-side — evita carregar 300 mil registros)
  // ─────────────────────────────────────────────

  /**
   * Retorna apenas os contadores por status, sem trazer os registros.
   * Endpoint Progress: GET /contadores?empresa={codigo}
   */
  obterContadores(empresa?: string): Observable<ContadoresApi> {
    let params = new HttpParams();
    if (empresa) params = params.set('codEmpresa', empresa);
    return this.http.get<ContadoresApi>(`${this.API_BASE}/contadores`, { params });
  }

  // ─────────────────────────────────────────────
  // Planilhas — paginação server-side obrigatória
  // ─────────────────────────────────────────────

  /**
   * Lista planilhas de forma paginada.
   * Com 300 mil+ registros, nunca carregar tudo de uma vez.
   *
   * Endpoint Progress: GET /listar?empresa=&status=&pagina=&itensPorPagina=
   */
  listarPlanilhas(params: PaginacaoParams): Observable<PaginacaoResponse> {
    let httpParams = new HttpParams()
      .set('pagina', params.pagina.toString())
      .set('itensPorPagina', params.itensPorPagina.toString());

    if (params.empresa) httpParams = httpParams.set('codEmpresa', params.empresa);
    if (params.status) httpParams = httpParams.set('indSitImportacao', params.status);
    if (params.cgc) httpParams = httpParams.set('cgc', params.cgc);
    if (params.nomeEmit) httpParams = httpParams.set('nomeEmit', params.nomeEmit);
    if (params.dataIni) httpParams = httpParams.set('dataIni', params.dataIni);
    if (params.dataFim) httpParams = httpParams.set('dataFim', params.dataFim);
    if (params.codTitAcr) httpParams = httpParams.set('codTitAcr', params.codTitAcr);
    if (params.codEstab) httpParams = httpParams.set('codEstab', params.codEstab);
    if (params.codSerDocto) httpParams = httpParams.set('codSerDocto', params.codSerDocto);

    return this.http.get<PaginacaoResponse>(`${this.API_BASE}`, { params: httpParams }).pipe(
      map(resp => ({
        ...resp,
        items: resp.items.map((item: any) => ({
          ...item,
          // Chave composta gerada no frontend — a API não retorna um campo `id`.
          // Inclui `valRecebido` porque é parte do índice único real da tabela
          // (estitacri_id): registros "sem título" (erro de importação, todos os
          // campos de chave vazios) só se distinguem pelo valor.
          id: `${item.cgc}|${item.codEstab}|${item.codEspecDocto}|${item.codSerDocto}|${item.codTitAcr}|${item.codParcela}|${item.valRecebido}`
        }))
      }))
    );
  }

  // ─────────────────────────────────────────────
  // Clientes agrupados (tela principal) — GET /clientes
  // ─────────────────────────────────────────────

  /**
   * Lista clientes agrupados por CGC, com os totais somados por cliente
   * (valor dos títulos importados e valor em aberto do es_tit_acr_abrt).
   * Endpoint server-side paginado — mesmo motivo de `listarPlanilhas`.
   */
  listarClientes(params: PaginacaoParams): Observable<ClientesPaginacaoResponse> {
    let httpParams = new HttpParams()
      .set('pagina', params.pagina.toString())
      .set('itensPorPagina', params.itensPorPagina.toString());

    if (params.empresa) httpParams = httpParams.set('codEmpresa', params.empresa);
    if (params.status) httpParams = httpParams.set('indSitImportacao', params.status);
    if (params.cgc) httpParams = httpParams.set('cgc', params.cgc);
    if (params.nomeEmit) httpParams = httpParams.set('nomeEmit', params.nomeEmit);
    if (params.dataIni) httpParams = httpParams.set('dataIni', params.dataIni);
    if (params.dataFim) httpParams = httpParams.set('dataFim', params.dataFim);

    return this.http.get<ClientesPaginacaoResponse>(`${this.API_BASE}/clientes`, { params: httpParams }).pipe(
      map(resp => ({
        ...resp,
        // `detalhesLabel`/`adLabel` alimentam as colunas type:'link' da po-table —
        // sem um valor de texto na propriedade, o link é renderizado vazio.
        items: resp.items.map((item: any) => ({
          ...item,
          id: item.cgc,
          detalhesLabel: 'Detalhes',
          adLabel: 'AD',
          grupoLabel: 'Tít do Gr Empresarial'
        }))
      }))
    );
  }

  /**
   * Lista os títulos de Adiantamento (AD) com saldo disponível para um
   * cliente — usado na aba "Grupo AD" do modal de detalhes.
   */
  listarAdCliente(cgc: string, status?: StatusPlanilha): Observable<AdTitulo[]> {
    let params = new HttpParams().set('cgc', cgc);
    if (status) params = params.set('indSitImportacao', status);
    return this.http.get<{ items: AdTitulo[] }>(`${this.API_BASE}/clientes-ad`, { params }).pipe(
      map(resp => (resp.items ?? []).map(item => ({
        ...item,
        // Mesma chave composta dos títulos (cgc|estab|espec|serie|titulo|parcela|val),
        // para reaproveitar processar/remover por `idsSel`.
        id: `${cgc}|${item.codEstab}|${item.codEspecDocto}|${item.codSerDocto}|${item.codTitAcr}|${item.codParcela}|${item.valSdoTitAcr}`
      })))
    );
  }

  // ─────────────────────────────────────────────
  // Ações em lote (tabela)
  // ─────────────────────────────────────────────

  /**
   * Processa em lote os títulos Pendente/Erro dos CGCs informados.
   *
   * @param idsSel Quando informado, restringe o processamento apenas aos
   * títulos cujas chaves compostas (`id`) estão na lista — usado pelo
   * "Processar Selecionados" do modal. Enviado como array de STRINGS (mesmo
   * formato de `cgcs`), porque o framework REST do Datasul não entrega
   * arrays de objetos ao BO. Sem `idsSel`, processa todos os Pendente/Erro
   * dos CGCs (comportamento do "Processar Selecionados" da tela inicial).
   */
  processarSelecionados(cgcs: string[], idsSel?: string[]): Observable<ApiResponse> {
    const codUsuario = DatasulAuthInterceptor.usuarioLogado;
    const body: any = { cgcs, codUsuario };
    if (idsSel && idsSel.length) body.idsSel = idsSel;
    return this.http.post<ApiResponse>(`${this.API_BASE}/processar`, body);
  }

  // ─────────────────────────────────────────────
  // Relatório
  // ─────────────────────────────────────────────

  executarRelatorio(params: any): Observable<any> {
    return this.http.post<any>(`${this.API_BASE}/gerarRelatorio`, params);
  }

  /**
   * Processa a liquidação por lote dos títulos selecionados. O backend agrupa
   * por estabelecimento, cria um lote de liquidação por estab no Datasul e
   * grava a referência gerada de volta em cada título.
   */
  processarLote(idsSel: string[]): Observable<ApiResponse> {
    const codUsuario = DatasulAuthInterceptor.usuarioLogado;
    return this.http.post<ApiResponse>(`${this.API_BASE}/processar`, { idsSel, processarLote: true, codUsuario });
  }

  processarTodosPendentes(): Observable<ApiResponse> {
    const codUsuario = DatasulAuthInterceptor.usuarioLogado;
    return this.http.post<ApiResponse>(`${this.API_BASE}/processar`, { processarTodos: true, codUsuario });
  }

  removerSelecionados(ids: string[]): Observable<ApiResponse> {
    return this.http.post<ApiResponse>(`${this.API_BASE}/remover`, { ids } as LoteRequest);
  }

  /** Remove todos os documentos Pendente/Erro (nao mexe nos ja Importados). */
  removerTodos(): Observable<ApiResponse> {
    return this.http.post<ApiResponse>(`${this.API_BASE}/remover`, { removerTodos: true });
  }

  /** Lista os servidores RPW ativos (com o tipo de fila) para o import via RPW. */
  listarRpwServidores(): Observable<{ items: any[] }> {
    return this.http.get<{ items: any[] }>(`${this.API_BASE}/rpwServidores`);
  }

  /**
   * Grava o CSV da planilha na pasta do RPW (parametro importa-cr-rpw) para
   * processamento em background. Retorna o caminho gravado ou erro.
   */
  importarRpw(conteudo: string, servidor: string): Observable<any> {
    return this.http.post<any>(`${this.API_BASE}/importarRpw`, { conteudo, servidor });
  }

  deletarTitulo(titulo: Planilha): Observable<ApiResponse> {
    const params = new HttpParams()
      .set('cgc', titulo.cgc)
      .set('codEstab', titulo.codEstab)
      .set('codEspecDocto', titulo.codEspecDocto)
      .set('codSerDocto', titulo.codSerDocto)
      .set('codTitAcr', titulo.codTitAcr)
      .set('codParcela', titulo.codParcela)
      // Desambigua registros "sem título" (chave vazia, ex.: erro de importação
      // sem correspondência): esses só se distinguem pelo valor na tabela.
      .set('valRecebido', String(titulo.valRecebido ?? ''));
    return this.http.delete<ApiResponse>(`${this.API_BASE}`, { params });
  }

  // ─────────────────────────────────────────────
  // Polling de progresso das ações em lote
  // ─────────────────────────────────────────────

  acompanharProgresso(ids: string[]): Observable<ProgressoProcessamento> {
    const idsParam = ids.join(',');
    return interval(POLLING_INTERVAL_MS).pipe(
      switchMap(() =>
        this.http.get<ProgressoProcessamento>(`${this.API_BASE}/progresso`, {
          params: new HttpParams().set('ids', idsParam)
        })
      ),
      takeWhile(prog => prog.status === 'processando', true)
    );
  }

  // ─────────────────────────────────────────────
  // Importação Direta em Tela
  // ─────────────────────────────────────────────

  importarLote(lote: any[][], empresa?: string, liquidaParcial: boolean = false, numLote: string = ''): Observable<ApiResponse> {
    const codUsuario = DatasulAuthInterceptor.usuarioLogado;
    const body = { lote, empresa, codUsuario, liquidaParcial, numLote };
    return this.http.post<ApiResponse>(`${this.API_BASE}/importarLote`, body);
  }

  gerarRelatorioExcel(): Observable<any> {
    return this.http.post<any>(`${this.API_BASE}/gerarRelatorio`, {});
  }

  /**
   * Lista os títulos em aberto do GRUPO EMPRESARIAL (CNPJ exato + raiz de 8
   * dígitos) do cliente — usado no modal "Tít do Gr Empresarial".
   */
  listarTitulosGrupo(cgc: string): Observable<any[]> {
    const params = new HttpParams().set('cgc', cgc);
    return this.http.get<{ items: any[] }>(`${this.API_BASE}/titulos-grupo`, { params }).pipe(
      map(resp => (resp.items ?? []).map(item => ({
        ...item,
        id: `${item.codEstab}|${item.codEspecDocto}|${item.codSerDocto}|${item.codTitAcr}|${item.codParcela}|${item.valSdoTitAcr}`
      })))
    );
  }

  /**
   * Re-aponta (troca) o título vinculado de um registro pendente para outro
   * título do grupo. Retorna o preview da operação (integral/acerto/ad) e o valor.
   */
  trocarVinculo(body: any): Observable<ApiResponse> {
    const codUsuario = DatasulAuthInterceptor.usuarioLogado;
    return this.http.post<ApiResponse>(`${this.API_BASE}/trocarVinculo`, { ...body, codUsuario });
  }
}

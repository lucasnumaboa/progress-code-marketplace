# Consolidação de Planilhas — Componente Angular + PO-UI

Componente Angular para importação e gestão de planilhas (CSV / Excel) integrado
ao backend **Progress 4GL (OpenEdge REST)** na arquitetura **TOTVS Datasul**.

---

## Estrutura de arquivos

```
consolidacao-planilhas/
├── models/
│   └── planilha.model.ts              ← Interfaces TypeScript
├── consolidacao-planilhas.module.ts   ← Módulo Angular
├── consolidacao-planilhas.component.ts   ← Lógica do componente
├── consolidacao-planilhas.component.html ← Template PO-UI
├── consolidacao-planilhas.component.scss ← Estilos
└── consolidacao-planilhas.service.ts  ← Chamadas à API Progress
```

---

## Pré-requisitos

| Dependência | Versão recomendada |
|---|---|
| Angular | 15 – 17 |
| `@po-ui/ng-components` | ≥ 17.x |
| `@po-ui/style` | ≥ 17.x |
| Node.js | ≥ 18 |

### Instalar PO-UI (caso ainda não esteja no projeto)

```bash
ng add @po-ui/ng-components
```

---

## Configuração da API Progress 4GL

Abra `consolidacao-planilhas.service.ts` e altere a constante `API_BASE`:

```typescript
// Exemplo desenvolvimento local (OpenEdge PASOE)
private readonly API_BASE = 'http://localhost:8810/web/api/consolidacao-planilhas';

// Exemplo produção Datasul
private readonly API_BASE = 'https://seu-servidor.empresa.com/web/api/consolidacao-planilhas';
```

### Endpoints esperados no Progress 4GL

| Método | Rota | Descrição |
|--------|------|-----------|
| `GET` | `/empresas` | Lista empresas `[{ codigo, nome }]` |
| `GET` | `/listar?empresa=&status=` | Lista planilhas importadas |
| `POST` | `/upload` (multipart) | Recebe arquivo + campo `empresa` |
| `POST` | `/processar` | Processa lote `{ ids: string[] }` |
| `POST` | `/remover` | Remove lote `{ ids: string[] }` |

#### Exemplo de resposta esperada — `/listar`

```json
[
  {
    "id": "0001",
    "nomeArquivo": "consolidado_jan_2025.csv",
    "codigoEmpresa": "01",
    "empresa": "01 - Empresa Principal",
    "dataImportacao": "2025-01-15T09:30:00",
    "status": "pendente",
    "totalRegistros": 150,
    "registrosOk": 0,
    "registrosErro": 0
  }
]
```

#### Status possíveis

| Valor | Cor na tabela | Descrição |
|-------|--------------|-----------|
| `pendente` | Amarelo | Arquivo importado, aguardando processamento |
| `processada` | Verde | Processamento concluído com sucesso |
| `erro` | Vermelho | Erros encontrados durante o processamento |

---

## Como integrar ao seu projeto Datasul

### 1. Importe o módulo no seu `AppModule` ou módulo de rota

```typescript
import { ConsolidacaoPlanilhasModule } from './consolidacao-planilhas/consolidacao-planilhas.module';

@NgModule({
  imports: [
    // ...outros módulos
    ConsolidacaoPlanilhasModule
  ]
})
export class AppModule { }
```

### 2. Use o selector na sua rota ou página pai

```html
<app-consolidacao-planilhas></app-consolidacao-planilhas>
```

### 3. Configurar rota (opcional)

```typescript
// app-routing.module.ts
{
  path: 'consolidacao-planilhas',
  component: ConsolidacaoPlanilhasComponent
}
```

---

## Funcionalidades implementadas

- Filtro por empresa via `po-select`
- Tabs de status com contadores: Todas / Processadas / Pendentes / Com Erro
- Tabela `po-table` com seleção múltipla e ações por linha
- Checkbox "Selecionar todos" com barra de ações em lote
- Ações em lote: **Processar**, **Revisar**, **Remover**
- Estado vazio com botão de importação (`po-empty-state`)
- Modal de importação com `po-upload` (drag & drop, CSV/Excel, até 10 MB)
- Integração com API Progress 4GL via `HttpClient`
- Notificações de feedback com `PoNotificationService`
- Loading overlay durante chamadas à API

---

## Adaptações comuns

### Proxy para desenvolvimento (Angular CLI)

Crie `proxy.conf.json` na raiz do projeto para evitar CORS:

```json
{
  "/api": {
    "target": "http://localhost:8810",
    "changeOrigin": true,
    "secure": false
  }
}
```

E em `angular.json`, na seção `serve > options`:

```json
"proxyConfig": "proxy.conf.json"
```

### Autenticação Datasul (token JWT)

Se a API exige token, adicione um `HttpInterceptor`:

```typescript
// auth.interceptor.ts
intercept(req: HttpRequest<any>, next: HttpHandler) {
  const token = localStorage.getItem('datasul_token');
  const authReq = req.clone({
    headers: req.headers.set('Authorization', `Bearer ${token}`)
  });
  return next.handle(authReq);
}
```

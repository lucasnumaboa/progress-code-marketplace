/**
 * scripts/build-war.js
 *
 * Empacota o output do Angular (dist/) como arquivo WAR para
 * implantação no Tomcat do ambiente TOTVS Datasul.
 *
 * Estrutura obrigatória do WAR:
 *   /                   → conteúdo web (index.html, js, css, assets/)
 *   /WEB-INF/web.xml    → descritor de implantação (copiado pelo angular.json)
 *   /META-INF/MANIFEST.MF → obrigatório pela especificação JAR/WAR
 *
 * Estratégia de empacotamento (em ordem de preferência):
 *   1. jar  (JDK) — se disponível no PATH
 *   2. zip  (nativo macOS / Linux) — fallback sem dependências extras
 *
 * Uso:
 *   npm run build:war
 *
 * Resultado:
 *   consolidacao-planilhas.war  (na raiz do projeto)
 */

const { execSync, spawnSync } = require('child_process');
const fs   = require('fs');
const path = require('path');

// ── Configuração ──────────────────────────────────────────────────────────────

const pkg      = require('../package.json');
const APP_NAME = pkg.name;
const DIST_DIR = path.resolve(__dirname, '..', 'dist', APP_NAME);
const WAR_FILE = path.resolve(__dirname, '..', `${APP_NAME}.war`);

// ── Validação do build ────────────────────────────────────────────────────────

if (!fs.existsSync(DIST_DIR)) {
  console.error(`\n[build-war] Pasta de build não encontrada: ${DIST_DIR}`);
  console.error('[build-war] Execute primeiro: npm run build:prod\n');
  process.exit(1);
}

// ── Cria META-INF/MANIFEST.MF (obrigatório pela spec JAR/WAR) ────────────────

const metaInfDir  = path.join(DIST_DIR, 'META-INF');
const manifestFile = path.join(metaInfDir, 'MANIFEST.MF');

if (!fs.existsSync(metaInfDir)) {
  fs.mkdirSync(metaInfDir, { recursive: true });
}

const now = new Date().toISOString();
fs.writeFileSync(
  manifestFile,
  [
    'Manifest-Version: 1.0',
    `Created-By: build-war.js (${pkg.name} v${pkg.version})`,
    `Build-Time: ${now}`,
    '',   // linha em branco obrigatória ao final do MANIFEST.MF
  ].join('\r\n'),
  'utf8'
);

console.log(`\n[build-war] META-INF/MANIFEST.MF criado em: ${manifestFile}`);

// ── Detecta ferramenta disponível ────────────────────────────────────────────

function comandoFuncional(cmd, args) {
  // Executa o comando de verdade — descarta stub do macOS que retorna exit 1
  const r = spawnSync(cmd, args, { stdio: 'pipe', encoding: 'utf8' });
  return r.status === 0 && !r.stderr?.toLowerCase().includes('unable to locate');
}

const temJar = comandoFuncional('jar', ['--version']);
const temZip = comandoFuncional('zip', ['--version']);

if (!temJar && !temZip) {
  console.error('\n[build-war] Nenhuma ferramenta de empacotamento encontrada.');
  console.error('[build-war] Instale o JDK (jar) ou o utilitário zip.\n');
  process.exit(1);
}

// ── Empacotamento ─────────────────────────────────────────────────────────────

if (fs.existsSync(WAR_FILE)) fs.rmSync(WAR_FILE);

console.log(`[build-war] Origem : ${DIST_DIR}`);
console.log(`[build-war] Destino: ${WAR_FILE}`);

if (temJar) {
  console.log('[build-war] Ferramenta: jar (JDK)\n');
  execSync(`jar -cvf "${WAR_FILE}" -C "${DIST_DIR}" .`, { stdio: 'inherit' });
} else {
  console.log('[build-war] Ferramenta: zip (fallback)\n');
  // zip exige que seja executado dentro da pasta de origem
  execSync(`zip -r "${WAR_FILE}" .`, { cwd: DIST_DIR, stdio: 'inherit' });
}

// ── Resultado ─────────────────────────────────────────────────────────────────

const sizeMb = (fs.statSync(WAR_FILE).size / 1_048_576).toFixed(2);
console.log(`\n[build-war] WAR gerado com sucesso!`);
console.log(`[build-war] Arquivo : ${WAR_FILE}`);
console.log(`[build-war] Tamanho : ${sizeMb} MB`);
console.log(`[build-war] Deploy  : copie para $TOMCAT_HOME/webapps/\n`);
console.log('[build-war] Estrutura do WAR:');
console.log('  /index.html');
console.log('  /META-INF/MANIFEST.MF   ← obrigatório');
console.log('  /WEB-INF/web.xml        ← descritor');
console.log('  /assets/app-config.json ← config de URLs (editável sem rebuild)');
console.log('  /assets/...             ← demais assets');
console.log('  /*.js, /*.css           ← bundles Angular\n');

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';

interface AppConfig {
  apiBase: string;
  rpwBase: string;
}

/**
 * Carregado via APP_INITIALIZER antes do bootstrap da aplicação.
 * Lê src/assets/app-config.json em runtime — sem necessidade de rebuild
 * ao trocar o endereço do PASOE entre ambientes (homologação, produção, etc.).
 *
 * O sysadmin edita apenas o arquivo no servidor Tomcat:
 *   $TOMCAT_HOME/webapps/consolidacao-planilhas/assets/app-config.json
 */
@Injectable({ providedIn: 'root' })
export class AppConfigService {

  private config: AppConfig = {
    apiBase: '/api/esp/v1/importaTituloAcr',
    rpwBase: '/api/cdp/v1'
  };

  constructor(private http: HttpClient) {}

  load(): Promise<void> {
    return firstValueFrom(
      this.http.get<AppConfig>('assets/app-config.json')
    )
    .then(cfg => { this.config = cfg; })
    .catch(() => {
      console.warn('[AppConfig] app-config.json não encontrado — usando valores padrão.');
    });
  }

  get apiBase(): string { return this.config.apiBase; }
  get rpwBase(): string { return this.config.rpwBase; }
}

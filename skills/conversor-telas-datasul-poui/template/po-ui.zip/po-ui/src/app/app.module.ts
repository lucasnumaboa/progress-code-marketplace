import { APP_INITIALIZER, LOCALE_ID, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule } from '@angular/common/http';
import { PoThemeModule, PoThemeService, PoThemeTypeEnum } from '@po-ui/ng-components';

import localePt from '@angular/common/locales/pt';
import { registerLocaleData } from '@angular/common';

registerLocaleData(localePt, 'pt-BR');

import { AppConfigService } from './app-config.service';
import { totvsDataSulTheme } from './theme/totvs-datasul.theme';
import { ConsolidacaoPlanilhasModule } from '../../consolidacao-planilhas.module';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

function initConfig(config: AppConfigService) {
  return () => config.load();
}

function initTheme(poTheme: PoThemeService) {
  return () => {
    const temaArmazenado = poTheme.getThemeActive();
    const tipoAtivo = temaArmazenado?.active ?? PoThemeTypeEnum.light;
    poTheme.setTheme(totvsDataSulTheme, tipoAtivo);
  };
}

@NgModule({
  declarations: [AppComponent],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    HttpClientModule,
    PoThemeModule,
    AppRoutingModule,
    ConsolidacaoPlanilhasModule
  ],
  providers: [
    // Locale pt-BR para formatação de moeda e números
    { provide: LOCALE_ID, useValue: 'pt-BR' },
    // 1º — carrega app-config.json antes de tudo
    {
      provide: APP_INITIALIZER,
      useFactory: initConfig,
      deps: [AppConfigService],
      multi: true
    },
    // 2º — aplica o tema TOTVS Datasul
    {
      provide: APP_INITIALIZER,
      useFactory: initTheme,
      deps: [PoThemeService],
      multi: true
    },
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }

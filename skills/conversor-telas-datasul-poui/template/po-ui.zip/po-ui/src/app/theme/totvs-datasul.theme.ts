import { PoTheme, PoThemeTypeEnum } from '@po-ui/ng-components';

/**
 * Tema TOTVS Datasul para PO-UI 17.
 *
 * Paleta baseada na identidade visual do TOTVS Datasul:
 *   • Brand 01 — azul primário Datasul
 *   • Brand 02 — laranja TOTVS (cor da marca)
 *   • Brand 03 — amarelo neutro (calendário / destaques)
 *
 * Aplicar via PoThemeService.setTheme(totvsDataSulTheme, PoThemeTypeEnum.light)
 * no AppComponent.ngOnInit().
 */
export const totvsDataSulTheme: PoTheme = {
  name: 'totvs-datasul',

  type: {
    light: {
      color: {
        brand: {
          // ── Azul primário Datasul ─────────────────────────────────────────
          '01': {
            lightest: '#E5F2FA',
            lighter:  '#A1D4F0',
            light:    '#4AAEE3',
            base:     '#0079B5',
            dark:     '#005F8F',
            darker:   '#003B5C',
            darkest:  '#001E30'
          },
          // ── Laranja TOTVS (ações secundárias, badges, destaques) ─────────
          '02': { base: '#F26522' },
          // ── Amarelo neutro (calendário, seleções de range) ───────────────
          '03': { base: '#FFD464' }
        },
        action: {
          default:  'var(--color-brand-01-base)',
          hover:    'var(--color-brand-01-dark)',
          pressed:  'var(--color-brand-01-darker)',
          disabled: 'var(--color-neutral-light-30)',
          focus:    'var(--color-brand-01-darkest)'
        },
        // ── Neutros: obrigatório para geração do ícone do po-select ─────────
        neutral: {
          light: {
            '00': '#ffffff',
            '05': '#fbfbfb',
            '10': '#eceeee',
            '20': '#dadedf',
            '30': '#b6bdbf'
          },
          mid: {
            '40': '#9da7a9',
            '60': '#6e7c7f'
          },
          dark: {
            '70': '#4a5c60',
            '80': '#2c3739',
            '90': '#1d2426',
            '95': '#0b0e0e'
          }
        }
      }
    },

    dark: {
      color: {
        brand: {
          '01': {
            lightest: '#001E30',
            lighter:  '#003B5C',
            light:    '#005F8F',
            base:     '#4AAEE3',
            dark:     '#A1D4F0',
            darker:   '#C8E8F7',
            darkest:  '#E5F2FA'
          },
          '02': { base: '#F59151' },
          '03': { base: '#FFE08A' }
        },
        action: {
          default:  'var(--color-brand-01-base)',
          hover:    'var(--color-brand-01-dark)',
          pressed:  'var(--color-brand-01-darker)',
          disabled: 'var(--color-neutral-light-30)',
          focus:    'var(--color-brand-01-darkest)'
        },
        neutral: {
          light: {
            '00': '#1a1a1a',
            '05': '#202020',
            '10': '#2c2c2c',
            '20': '#3a3a3a',
            '30': '#555555'
          },
          mid: {
            '40': '#777777',
            '60': '#999999'
          },
          dark: {
            '70': '#bbbbbb',
            '80': '#d0d0d0',
            '90': '#e5e5e5',
            '95': '#f5f5f5'
          }
        }
      }
    }
  },

  active: PoThemeTypeEnum.light
};

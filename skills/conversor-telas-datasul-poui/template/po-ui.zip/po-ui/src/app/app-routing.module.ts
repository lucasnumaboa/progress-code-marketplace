import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { ConsolidacaoPlanilhasComponent } from '../../consolidacao-planilhas.component';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'consolidacao-planilhas',
    pathMatch: 'full'
  },
  {
    path: 'consolidacao-planilhas',
    component: ConsolidacaoPlanilhasComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

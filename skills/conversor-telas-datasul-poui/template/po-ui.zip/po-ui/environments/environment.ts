/**
 * Ambiente: DESENVOLVIMENTO LOCAL
 *
 * Coloque este arquivo em: src/environments/environment.ts
 *
 * Para rodar localmente com proxy para o PASOE:
 *   ng serve --proxy-config proxy.conf.json
 */
export const environment = {
  production: false,

  /**
   * URL base da API Progress 4GL (PASOE) — endpoints customizados.
   * O proxy do Angular CLI redireciona /api → PASOE local.
   */
  apiBase: '/consolidacao-planilhas',

  /**
   * URL base dos endpoints nativos RPW do TOTVS Datasul.
   * Em desenvolvimento, o proxy redireciona /rpw → PASOE local.
   * Endpoint padrão Datasul: /api/cdp/v1
   */
  rpwBase: '/rpw/api/cdp/v1',

  /**
   * Endereço do servidor PASOE para o proxy de desenvolvimento.
   */
  pasoeHost: 'http://localhost:33003',
};

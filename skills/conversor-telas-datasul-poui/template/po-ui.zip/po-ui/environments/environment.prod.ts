/**
 * Ambiente: PRODUÇÃO — Tomcat TOTVS Datasul
 *
 * Coloque este arquivo em: src/environments/environment.prod.ts
 *
 * Build de produção:
 *   ng build --configuration=production --base-href=/consolidacao-planilhas/
 *
 * O Angular substitui environment.ts por este arquivo automaticamente
 * durante o build de produção (fileReplacements no angular.json).
 */
export const environment = {
  production: true,

  /**
   * URL base da API Progress 4GL (endpoints customizados de planilhas).
   * Em produção, aponta direto para o PASOE via caminho relativo no Tomcat.
   */
  apiBase: 'http://10.0.211.12:31003/api/esp/v1/importaTituloAcr',

  /**
   * URL base dos endpoints nativos RPW do TOTVS Datasul.
   * O Datasul expõe o RPW em /api/cdp/v1 via PASOE.
   * Ajuste conforme a versão e configuração do seu servidor.
   *
   * Exemplos comuns:
   *   Datasul 12.1.x → /api/cdp/v1
   *   Datasul 12.2.x → /api/cdp/v1  (manteve o mesmo path)
   */
  rpwBase: 'http://10.0.211.12:31003/api',
};

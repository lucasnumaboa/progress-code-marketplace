/*
    Cria��o de Adiantamento (AD) via Mock - ACR Datasul
    API: prgfin/acr/acr900zi.py
*/

/* 1. IMPORTA��O DOS INCLUDES DA SUA BASE */
{utp/ut-buffers-ems2.i}
{utp/ut-glob.i}
{acr/esacr086rp.i}
{acr/esacr054.i}

/* 2. VARI�VEIS DO PROGRAMA */
DEFINE VARIABLE h-acr900zi    AS HANDLE  NO-UNDO.
DEFINE VARIABLE c-cod-refer   AS CHAR    FORMAT "x(10)" NO-UNDO.
DEFINE VARIABLE c-titulo      AS CHAR    FORMAT "x(16)" NO-UNDO.
DEFINE VARIABLE i-num-seq     AS INTEGER INITIAL 0 NO-UNDO.

/* DADOS EXTRA�DOS DO PRINT DO USU�RIO */
DEFINE VARIABLE c-estab       AS CHAR    INITIAL "001" NO-UNDO. 
DEFINE VARIABLE i-cliente     AS INTEGER INITIAL 171739 NO-UNDO.

/* Limpeza preventiva das tabelas */
EMPTY TEMP-TABLE tt_integr_acr_lote_impl.
EMPTY TEMP-TABLE tt_integr_acr_item_lote_impl_9.
EMPTY TEMP-TABLE tt_integr_acr_repres_comis_2.
EMPTY TEMP-TABLE tt_integr_acr_aprop_relacto_2b.
EMPTY TEMP-TABLE tt_params_generic_api.
EMPTY TEMP-TABLE tt_integr_acr_relacto_pend_aux.
EMPTY TEMP-TABLE tt_log_erros_atualiz. 
EMPTY TEMP-TABLE tt_integr_acr_aprop_ctbl_pend. /* Tabela de contabilidade caso a API exija */

/* 3. GERA��O DE REFER�NCIA E T�TULO �NICOS */
ASSIGN c-cod-refer = "IMP" + STRING(TIME).
ASSIGN c-titulo    = "MOCK" + STRING(TIME). /* Ex: MOCK45821 */
ASSIGN i-num-seq   = i-num-seq + 1.

/* 4. PREPARA��O DOS DADOS DO T�TULO */

/* A. CRIA O CABE�ALHO DO LOTE (Pai) */
CREATE tt_integr_acr_lote_impl.
ASSIGN 
    tt_integr_acr_lote_impl.tta_cod_estab            = c-estab
    tt_integr_acr_lote_impl.tta_cod_refer            = c-cod-refer
    tt_integr_acr_lote_impl.tta_dat_transacao        = TODAY
    tt_integr_acr_lote_impl.tta_ind_tip_espec_docto  = ''
    tt_integr_acr_lote_impl.tta_ind_tip_cobr_acr     = 'Normal'.

/* B. CRIA O ITEM/T�TULO (Filho) - Usando dados do print */
CREATE tt_integr_acr_item_lote_impl_9.
ASSIGN 
    tt_integr_acr_item_lote_impl_9.ttv_rec_lote_impl_tit_acr        = RECID(tt_integr_acr_lote_impl)
    tt_integr_acr_item_lote_impl_9.ttv_rec_item_lote_impl_tit_acr   = RECID(tt_integr_acr_item_lote_impl_9)
    
    tt_integr_acr_item_lote_impl_9.tta_num_seq_refer        = i-num-seq
    tt_integr_acr_item_lote_impl_9.tta_cdn_cliente          = i-cliente 
    tt_integr_acr_item_lote_impl_9.tta_cod_espec_docto      = "AD"            /* Print: Esp�cie AD */
    tt_integr_acr_item_lote_impl_9.tta_cod_ser_docto        = ""              /* Print: S�rie Branca */
    tt_integr_acr_item_lote_impl_9.tta_cod_tit_acr          = c-titulo        /* T�tulo Din�mico */
    tt_integr_acr_item_lote_impl_9.tta_cod_tit_acr_bco      = ""
    tt_integr_acr_item_lote_impl_9.tta_cod_parcela          = "01"
    tt_integr_acr_item_lote_impl_9.tta_cod_portador         = "341"           /* Print: Port 341 */
    tt_integr_acr_item_lote_impl_9.tta_cod_cart_bcia        = "SIM"           /* Print: Cart SIM */
    tt_integr_acr_item_lote_impl_9.tta_cod_indic_econ       = "Real"          
    tt_integr_acr_item_lote_impl_9.tta_dat_vencto_tit_acr   = TODAY
    tt_integr_acr_item_lote_impl_9.tta_dat_emis_docto       = TODAY
    tt_integr_acr_item_lote_impl_9.tta_val_tit_acr          = 150.50          /* Valor teste */
    tt_integr_acr_item_lote_impl_9.tta_des_text_histor      = "Adiantamento MOCK gerado para teste"
    tt_integr_acr_item_lote_impl_9.tta_ind_tip_espec_docto  = "Antecipa��o"   /* <--- REGRA OBRIGAT�RIA PARA 'AD' */
    tt_integr_acr_item_lote_impl_9.tta_ind_sit_tit_acr      = "Normal"
    tt_integr_acr_item_lote_impl_9.tta_ind_sit_bcia_tit_acr = "1"
    tt_integr_acr_item_lote_impl_9.tta_ind_ender_cobr       = "1"
    tt_integr_acr_item_lote_impl_9.tta_val_cotac_indic_econ = 1.

/* C. DADOS CONT�BEIS PENDENTES (Exig�ncia comum para AD) */
CREATE tt_integr_acr_aprop_ctbl_pend.
ASSIGN 
    tt_integr_acr_aprop_ctbl_pend.ttv_rec_item_lote_impl_tit_acr = RECID(tt_integr_acr_item_lote_impl_9)
    tt_integr_acr_aprop_ctbl_pend.tta_cod_unid_negoc             = '99'
    tt_integr_acr_aprop_ctbl_pend.tta_val_aprop_ctbl             = tt_integr_acr_item_lote_impl_9.tta_val_tit_acr.

/* 5. CHAMADA DA API E EXECU��O */
IF NOT VALID-HANDLE(h-acr900zi) THEN
    RUN prgfin/acr/acr900zi.py PERSISTENT SET h-acr900zi.

RUN pi_main_code_integr_acr_new_13 IN h-acr900zi 
    (INPUT 11,                                       
     INPUT 'MOCK',                                   
     INPUT YES,                                      
     INPUT YES,                                      
     INPUT TABLE tt_integr_acr_repres_comis_2,
     INPUT-OUTPUT TABLE tt_integr_acr_item_lote_impl_9,
     INPUT TABLE tt_integr_acr_aprop_relacto_2b,
     INPUT-OUTPUT TABLE tt_params_generic_api,
     INPUT TABLE tt_integr_acr_relacto_pend_aux).

IF VALID-HANDLE(h-acr900zi) THEN DO:
    DELETE PROCEDURE h-acr900zi.
    ASSIGN h-acr900zi = ?.
END.

/* 6. VERIFICA��O DE ERROS DA API */
IF CAN-FIND(FIRST tt_log_erros_atualiz) THEN DO:
    FOR EACH tt_log_erros_atualiz:
        MESSAGE "ERRO DE NEG�CIO DA API:" SKIP(1)
                "C�digo: " tt_log_erros_atualiz.ttv_num_mensagem SKIP
                "Motivo: " tt_log_erros_atualiz.ttv_des_msg_erro SKIP
                "Ajuda: "  tt_log_erros_atualiz.ttv_des_msg_ajuda
            VIEW-AS ALERT-BOX ERROR.
    END.
    RETURN. 
END.

/* 7. VERIFICA��O F�SICA NO BANCO DE DADOS */
FIND FIRST tit_acr NO-LOCK
     WHERE tit_acr.cod_estab       = c-estab       
       AND tit_acr.cod_espec_docto = "AD"
       AND tit_acr.cod_ser_docto   = ""
       AND tit_acr.cod_tit_acr     = c-titulo
       AND tit_acr.cod_parcela     = "01" NO-ERROR.

IF AVAIL tit_acr THEN DO:
    MESSAGE "SUCESSO ABSOLUTO!" SKIP(1)
            "O Adiantamento (AD) foi efetivado fisicamente no banco." SKIP(1)
            "Estabelecimento: " tit_acr.cod_estab SKIP
            "Cliente: "     tit_acr.cdn_cliente SKIP
            "T�tulo: "      tit_acr.cod_tit_acr SKIP
            "Valor: R$ "    tit_acr.val_origin_tit_acr
        VIEW-AS ALERT-BOX INFO.
END.
ELSE DO:
    MESSAGE "O t�tulo n�o foi encontrado e nenhum erro foi retornado."
        VIEW-AS ALERT-BOX WARNING.
END.

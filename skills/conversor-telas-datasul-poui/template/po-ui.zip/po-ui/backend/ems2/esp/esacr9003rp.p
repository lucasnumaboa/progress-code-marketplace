/**********************************************************************************
** Programa.: ESACR9003RP.P
** Descricao: Executa a baixa dos titulos importados por alteracao de valor a menor
** Alteracao: 23/04/2025 - 3.00.00.000 - Decio M.S. - versao inicial
**********************************************************************************/
{utp/ut-glob.i}
{method/dbotterr.i}

/* include de controle de vers�o */
{include/i-prgvrs.i ESACR9003RP 3.00.00.000}
/* defini��o das temp-tables para recebimento de par�metros */

define temp-table tt-param
    field destino           as integer
    field arq-destino       as char
    field arq-entrada       as char
    field todos             as integer
    field usuario           as char
    field data-exec         as date
    field hora-exec         as integer
    FIELD dat_transacao     AS DATE
    FIELD cod_portador      AS CHAR
    FIELD cod_cart_bcia     AS CHAR
    FIELD cod_cta_ctbl      AS CHAR.

def temp-table tt-raw-digita
    field raw-digita	as raw.
/* recebimento de par�metros */
def input parameter raw-param as raw no-undo.
def input parameter TABLE for tt-raw-digita.

/* --- Temp tables para a API -------------------------------------------------------*/
def temp-table tt_alter_tit_acr_base_5 no-undo
    field tta_cod_estab                    as character format "x(3)" label "Estabelecimento" column-label "Estab"
    field tta_num_id_tit_acr               as integer format "9999999999" initial 0 label "Token Cta Receber" column-label "Token Cta Receber"
    field tta_dat_transacao                as date format "99/99/9999" initial today label "Data Transa��o" column-label "Dat Transac"
    field tta_cod_refer                    as character format "x(10)" label "Refer�ncia" column-label "Refer�ncia"
    field ttv_cod_motiv_movto_tit_acr_imp  as character format "x(8)" label "Motivo Impl" column-label "Motivo Movimento"
    field tta_val_sdo_tit_acr              as decimal format ">>>,>>>,>>9.99" decimals 2 initial 0 label "Saldo T�tulo" column-label "Saldo T�tulo"
    field ttv_cod_motiv_movto_tit_acr_alt  as character format "x(8)" label "Motivo Alter" column-label "Motivo Movimento"
    field ttv_ind_motiv_acerto_val         as character format "X(12)" initial "Altera��o" label "Motivo Acerto Valor" column-label "Motivo Acerto Valor"
    field tta_cod_portador                 as character format "x(5)" label "Portador" column-label "Portador"
    field tta_cod_cart_bcia                as character format "x(3)" label "Carteira" column-label "Carteira"
    field tta_val_despes_bcia              as decimal format "->>>,>>>,>>9.99" decimals 2 initial 0 label "Vl Desp Banc" column-label "Vl Desp Banc"
    field tta_cod_agenc_cobr_bcia          as character format "x(10)" label "Ag�ncia Cobran�a" column-label "Ag�ncia Cobr"
    field tta_cod_tit_acr_bco              as character format "x(20)" label "Num T�tulo Banco" column-label "Num T�tulo Banco"
    field tta_dat_emis_docto               as date format "99/99/9999" initial today label "Data  Emiss�o" column-label "Dt Emiss�o"
    field tta_dat_vencto_tit_acr           as date format "99/99/9999" initial ? label "Vencimento" column-label "Vencimento"
    field tta_dat_prev_liquidac            as date format "99/99/9999" initial ? label "Prev Liquida��o" column-label "Prev Liquida��o"
    field tta_dat_fluxo_tit_acr            as date format "99/99/9999" initial ? label "Fluxo" column-label "Fluxo"
    field tta_ind_sit_tit_acr              as character format "X(13)" initial "Normal" label "Situa��o T�tulo" column-label "Situa��o T�tulo"
    field tta_cod_cond_cobr                as character format "x(8)" label "Condi��o Cobran�a" column-label "Cond Cobran�a"
    field tta_log_tip_cr_perda_dedut_tit   as logical format "Sim/N�o" initial no label "Credito com Garantia" column-label "Cred Garant"
    field tta_dat_abat_tit_acr             as date format "99/99/9999" initial ? label "Abat" column-label "Abat"
    field tta_val_perc_abat_acr            as decimal format ">>9.9999" decimals 4 initial 0 label "Perc Abatimento" column-label "Abatimento"
    field tta_val_abat_tit_acr             as decimal format ">>>>,>>>,>>9.99" decimals 2 initial 0 label "Vl Abatimento" column-label "Vl Abatimento"
    field tta_dat_desconto                 as date format "99/99/9999" initial ? label "Data Desconto" column-label "Dt Descto"
    field tta_val_perc_desc                as decimal format ">9.9999" decimals 4 initial 0 label "Percentual Desconto" column-label "Perc Descto"
    field tta_val_desc_tit_acr             as decimal format ">>>>,>>>,>>9.99" decimals 2 initial 0 label "Vl Desc" column-label "Vl Desc"
    field tta_qtd_dias_carenc_juros_acr    as decimal format ">>9" initial 0 label "Dias Carenc Juros" column-label "Dias Juros"
    field tta_val_perc_juros_dia_atraso    as decimal format ">9.999999" decimals 6 initial 00.00 label "Perc Jur Dia Atraso" column-label "Perc Dia"
    field tta_qtd_dias_carenc_multa_acr    as decimal format ">>9" initial 0 label "Dias Carenc Multa" column-label "Dias Carenc Multa"
    field tta_val_perc_multa_atraso        as decimal format ">9.99" decimals 2 initial 00.00 label "Perc Multa Atraso" column-label "Multa Atr"
    field ttv_cod_portador_mov             as character format "x(5)" label "Portador Movto" column-label "Portador Movto"
    field tta_ind_tip_cobr_acr             as character format "X(10)" initial "Normal" label "Tipo Cobran�a" column-label "Tipo Cobran�a"
    field tta_ind_ender_cobr               as character format "X(15)" initial "Cliente" label "Endere�o Cobran�a" column-label "Endere�o Cobran�a"
    field tta_nom_abrev_contat             as character format "x(15)" label "Abreviado Contato" column-label "Abreviado Contato"
    field tta_val_liq_tit_acr              as decimal format ">>>,>>>,>>9.99" decimals 2 initial 0 label "Vl L�quido" column-label "Vl L�quido"
    field tta_cod_instruc_bcia_1_movto     as character format "x(4)" label "Instr Banc ria 1" column-label "Instr Banc 1"
    field tta_cod_instruc_bcia_2_movto     as character format "x(4)" label "Instr Banc ria 2" column-label "Instr Banc 2"
    field tta_log_tit_acr_destndo          as logical format "Sim/N�o" initial no label "Destinado" column-label "Destinado"
    field tta_cod_histor_padr              as character format "x(8)" label "Hist�rico Padr�o" column-label "Hist�rico Padr�o"
    field ttv_des_text_histor              as character format "x(2000)" label "Hist�rico" column-label "Hist�rico"
    field tta_des_obs_cobr                 as character format "x(40)" label "Obs Cobran�a" column-label "Obs Cobran�a"
    field ttv_wgh_lista                    as widget-handle extent 26 format ">>>>>>9"
    field tta_num_seq_tit_acr              as integer format ">>>9" initial 0 label "Sequ�ncia" column-label "Sequ�ncia"
    field ttv_cod_estab_planilha           as character format "x(3)"
    field ttv_num_planilha_vendor          as integer format ">>>,>>>,>>9" initial 0 label "Planilha Vendor" column-label "Planilha Vendor"
    field ttv_cod_cond_pagto_vendor        as character format "x(3)" initial "0" label "Condi��o Pagto" column-label "Condi��o Pagto"
    field ttv_val_cotac_tax_vendor_clien   as decimal format ">>9.9999999999" decimals 10 label "Taxa Vendor Cliente" column-label "Taxa Vendor Cliente"
    field ttv_dat_base_fechto_vendor       as date format "99/99/9999" initial today label "Data Base" column-label "Data Base"
    field ttv_qti_dias_carenc_fechto       as Integer format "->>9" label "Dias Car�ncia" column-label "Dias Car�ncia"
    field ttv_log_assume_tax_bco           as logical format "Sim/N�o" initial no label "Assume Taxa Banco" column-label "Assume Taxa Banco"
    field ttv_log_vendor                   as logical format "Sim/N�o" initial no
    field tta_val_cr_pis                   as decimal format ">>>,>>>,>>9.99" decimals 2 initial 0 label "Valor Cred PIS/PASEP" column-label "Vl Cred PIS/PASEP"
    field tta_val_cr_cofins                as decimal format ">>>,>>>,>>9.99" decimals 2 initial 0 label "Valor Cr�dito COFINS" column-label "Credito COFINS"
    field tta_val_cr_csll                  as decimal format ">>>,>>>,>>9.99" decimals 2 initial 0 label "Valor Cr�dito CSLL" column-label "Credito CSLL"
    field tta_val_base_calc_impto          as decimal format ">>>,>>>,>>9.99" decimals 2 initial 0 label "Base Calculo Impto" column-label "Base Calculo Impto"
    field tta_log_retenc_impto_impl        as logical format "Sim/N�o" initial no label "Ret Imposto Impl" column-label "Ret Imposto Impl"
    field tta_cdn_repres                   as Integer format ">>>,>>9" initial 0 label "Representante" column-label "Representante"
    field tta_cod_proces_export            as character format "x(12)" label "Processo Exporta��o" column-label "Processo Exporta��o"
    field ttv_log_estorn_impto_retid       as logical format "Sim/N�o" initial yes
    index tt_id                            is primary unique
          tta_cod_estab                    ascending
          tta_num_id_tit_acr               ascending
          tta_dat_transacao                ascending
          tta_num_seq_tit_acr              ascending.
          
def temp-table tt_alter_tit_acr_cheq no-undo
    field tta_cod_estab                    as character format "x(5)" label "Estabelecimento" column-label "Estab"
    field tta_num_id_tit_acr               as integer format "9999999999" initial 0 label "Token Cta Receber" column-label "Token Cta Receber"
    field tta_cod_banco                    as character format "x(8)" label "Banco" column-label "Banco"
    field tta_cod_agenc_bcia               as character format "x(10)" label "Ag�ncia Banc ria" column-label "Ag�ncia Banc ria"
    field tta_cod_cta_corren_bco           as character format "x(20)" label "Conta Corrente Banco" column-label "Conta Corrente Banco"
    field tta_num_cheque                   as integer format ">>>>,>>>,>>9" initial ? label "Num Cheque" column-label "Num Cheque"
    field tta_dat_emis_cheq                as date format "99/99/9999" initial ? label "Data Emiss�o" column-label "Dt Emiss"
    field tta_dat_prev_apres_cheq_acr      as date format "99/99/9999" initial ? label "Previs�o Apresent" column-label "Previs�o Apresent"
    field tta_dat_prev_cr_cheq_acr         as date format "99/99/9999" initial ? label "Previs�o Cr�dito" column-label "Previs�o Cr�dito"
    field tta_cod_id_feder                 as character format "x(20)" initial ? label "ID Federal" column-label "ID Federal"
    field tta_nom_emit                     as character format "x(40)" label "Nome Emitente" column-label "Nome Emitente"
    field tta_nom_cidad_emit               as character format "x(30)" label "Cidade Emitente" column-label "Cidade Emitente"
    field tta_log_cheq_terc                as logical format "Sim/N�o" initial no label "Cheque Terceiro" column-label "Cheque Terceiro"
    field tta_cod_usuar_cheq_acr_terc      as character format "x(12)" label "Usu rio" column-label "Usu rio"
    field tta_ind_dest_cheq_acr            as character format "X(15)" initial "Dep�sito" label "Destino Cheque" column-label "Destino Cheque"
    index tt_id                            is primary unique
          tta_cod_estab                    ascending
          tta_num_id_tit_acr               ascending
          tta_cod_banco                    ascending
          tta_cod_agenc_bcia               ascending
          tta_cod_cta_corren_bco           ascending
          tta_num_cheque                   ascending.

def temp-table tt_alter_tit_acr_cobr_espec_2 no-undo
    field tta_cod_estab                    as character format "x(5)" label "Estabelecimento" column-label "Estab"
    field tta_num_id_tit_acr               as integer format "9999999999" initial 0 label "Token Cta Receber" column-label "Token Cta Receber"
    field tta_num_seq_tit_acr              as integer format ">>>9" initial 0 label "Sequ�ncia" column-label "Sequ�ncia"
    field tta_num_id_cobr_especial_acr     as integer format "99999999" initial 0 label "Token Cobr Especial" column-label "Token Cobr Especial"
    field tta_val_tit_acr                  as decimal format ">>>,>>>,>>9.99" decimals 2 initial 0 label "Valor" column-label "Valor"
    field tta_cod_portador                 as character format "x(5)" label "Portador" column-label "Portador"
    field tta_cod_cart_bcia                as character format "x(3)" label "Carteira" column-label "Carteira"
    field tta_cod_cartcred                 as character format "x(20)" label "C�digo Cart�o" column-label "C�digo Cart�o"
    field tta_cod_autoriz_cartao_cr        as character format "x(6)" label "C�d Pr�-Autoriza��o" column-label "C�d Pr�-Autoriza��o"
    field tta_cod_mes_ano_valid_cartao     as character format "XX/XXXX" label "Validade Cart�o" column-label "Validade Cart�o"
    field tta_dat_compra_cartao_cr         as date format "99/99/9999" initial ? label "Data Efetiv Venda" column-label "Data Efetiv Venda"
    field tta_cod_banco                    as character format "x(8)" label "Banco" column-label "Banco"
    field tta_cod_agenc_bcia               as character format "x(10)" label "Ag�ncia Banc ria" column-label "Ag�ncia Banc ria"
    field tta_cod_cta_corren_bco           as character format "x(20)" label "Conta Corrente Banco" column-label "Conta Corrente Banco"
    field tta_cod_digito_cta_corren        as character format "x(2)" label "D�gito Cta Corrente" column-label "D�gito Cta Corrente"
    field tta_num_ddd_localid_conces       as integer format "999" initial 0 label "DDD" column-label "DDD"
    field tta_num_prefix_localid_conces    as integer format ">>>9" initial 0 label "Prefixo" column-label "Prefixo"
    field tta_num_milhar_localid_conces    as integer format "9999" initial 0 label "Milhar" column-label "Milhar"
    field tta_des_text_histor              as character format "x(2000)" label "Hist�rico" column-label "Hist�rico"
    field ttv_log_alter_tip_cobr_acr       as logical format "Sim/N�o" initial no label "Alter Tip Cobr" column-label "Alter Tip Cobr"
    field tta_ind_sit_tit_cobr_especial    as character format "X(15)" label "Situa��o T�tulo" column-label "Situa��o T�tulo"
    field ttv_cod_comprov_vda              as character format "x(12)" label "Comprovante Venda" column-label "Comprovante Venda"
    field ttv_num_parc_cartcred            as integer format ">9" label "Quantidade Parcelas" column-label "Quantidade Parcelas"
    field ttv_val_tot_sdo_tit_acr          as decimal format ">>>,>>>,>>9.99" decimals 2 initial 0 label "Val Total Parcelas" column-label "Val Total Parcelas"
    field tta_cod_autoriz_bco_emissor      as character format "x(6)" label "Autorizacao Venda" column-label "Autorizacao Venda"
    field tta_cod_lote_origin              as character format "x(7)" label "Lote OrigVenda" column-label "Lote OrigVenda"
    index tt_id                            is primary unique
          tta_cod_estab                    ascending
          tta_num_id_tit_acr               ascending
          tta_num_seq_tit_acr              ascending.          

def temp-table tt_alter_tit_acr_comis_1 no-undo
    field tta_cod_empresa                  as character format "x(3)" label "Empresa" column-label "Empresa"
&IF "{&emsfin_version}" >= "" AND "{&emsfin_version}" < "5.07A" &THEN
    field tta_cod_estab                    as character format "x(3)" label "Estabelecimento" column-label "Estab"
&ENDIF
&IF "{&emsfin_version}" >= "5.07A" AND "{&emsfin_version}" < "9.99" &THEN
    field tta_cod_estab                    as Character format "x(5)" label "Estabelecimento" column-label "Estab"
&ENDIF
    field tta_num_id_tit_acr               as integer format "9999999999" initial 0 label "Token Cta Receber" column-label "Token Cta Receber"
    field ttv_num_tip_operac               as integer format ">9" column-label "Tipo  Opera��o"
    field tta_cdn_repres                   as Integer format ">>>,>>9" initial 0 label "Representante" column-label "Representante"
&IF "{&emsfin_version}" >= "" AND "{&emsfin_version}" < "5.08" &THEN
    field tta_val_perc_comis_repres        as decimal format ">>9.99" decimals 2 initial 0 label "% Comiss�o" column-label "% Comiss�o"
&ENDIF
&IF "{&emsfin_version}" >= "5.08" AND "{&emsfin_version}" < "9.99" &THEN
    field tta_val_perc_comis_repres        as decimal format ">>9.9999" decimals 4 initial 0 label "% Comiss�o" column-label "% Comiss�o"
&ENDIF
    field tta_val_perc_comis_repres_emis   as decimal format ">>9.99" decimals 2 initial 0 label "% Comis Emiss�o" column-label "% Comis Emiss�o"
    field tta_val_perc_comis_abat          as decimal format ">>9.99" decimals 2 initial 0 label "% Comis Abatimento" column-label "% Comis Abatimento"
    field tta_val_perc_comis_desc          as decimal format ">>9.99" decimals 2 initial 0 label "% Comis Desconto" column-label "% Comis Desconto"
    field tta_val_perc_comis_juros         as decimal format ">>9.99" decimals 2 initial 0 label "% Comis Juros" column-label "% Comis Juros"
    field tta_val_perc_comis_multa         as decimal format ">>9.99" decimals 2 initial 0 label "% Comis Multa" column-label "% Comis Multa"
    field tta_val_perc_comis_acerto_val    as decimal format ">>9.99" decimals 2 initial 0 label "% Comis AVA" column-label "% Comis AVA"
    field tta_log_comis_repres_proporc     as logical format "Sim/N�o" initial no label "Comis Proporcional" column-label "Comis Propor"
    field tta_ind_tip_comis                as character format "X(15)" initial "Valor Bruto" label "Tipo Comiss�o" column-label "Tipo Comiss�o"
    field ttv_ind_tip_comis_ext            as character format "X(15)" initial "Nenhum" label "Tipo de Comiss�o" column-label "Tipo de Comiss�o"
    field ttv_ind_liber_pagto_comis        as character format "X(20)" initial "Nenhum" label "Lib Pagto Comis" column-label "Lib Comis"
    field ttv_ind_sit_comis_ext            as character format "X(10)" initial "Nenhum" label "Sit Comis Ext" column-label "Sit Comis Ext"
    field tta_val_base_calc_impto          as decimal format ">>>,>>>,>>9.99" decimals 2 initial 0 label "Base Calculo Impto" column-label "Base Calculo Impto"
    index tt_id                            is primary unique
          tta_cod_empresa                  ascending
          tta_cod_estab                    ascending
          tta_num_id_tit_acr               ascending
          tta_cdn_repres                   ascending
    index tt_relac_tit_acr               
          tta_cod_estab                    ascending
          tta_num_id_tit_acr               ascending.

def temp-table tt_alter_tit_acr_impto_retid_2 no-undo
    field tta_cod_estab                    as character format "x(5)" label "Estabelecimento" column-label "Estab"
    field tta_num_id_tit_acr               as integer format "9999999999" initial 0 label "Token Cta Receber" column-label "Token Cta Receber"
    field tta_cod_pais                     as character format "x(3)" label "Pa�s" column-label "Pa�s"
    field tta_cod_unid_federac             as character format "x(3)" label "Unidade Federa��o" column-label "UF"
    field tta_cod_imposto                  as character format "x(5)" label "Imposto" column-label "Imposto"
    field tta_cod_classif_impto            as character format "x(05)" initial "00000" label "Class Imposto" column-label "Class Imposto"
    field tta_num_impto_refer_tit_acr      as integer format ">>>>>9" initial 0 label "Impto Refer" column-label "Impto Refer"
    field ttv_num_tip_operac               as integer format ">9" column-label "Tipo  Opera��o"
    field tta_val_aliq_impto               as decimal format ">9.99" decimals 2 INITIAL 0.00 label "Al�quota" column-label "Aliq"
    field tta_val_rendto_tribut            as decimal format ">,>>>,>>>,>>9.99" decimals 2 initial 0 label "Rendto Tribut vel" column-label "Vl Rendto Tribut"
    index tt_id                            is primary unique
          tta_cod_estab                    ascending
          tta_num_id_tit_acr               ascending
          tta_cod_pais                     ascending
          tta_cod_unid_federac             ascending
          tta_cod_imposto                  ascending
          tta_cod_classif_impto            ascending
          tta_num_impto_refer_tit_acr      ascending.          

def temp-table tt_alter_tit_acr_iva no-undo
    field tta_cod_estab                    as character format "x(5)" label "Estabelecimento" column-label "Estab"
    field tta_num_id_tit_acr               as integer format "9999999999" initial 0 label "Token Cta Receber" column-label "Token Cta Receber"
    field tta_cod_refer                    as character format "x(10)" label "Refer�ncia" column-label "Refer�ncia"
    field tta_num_seq_refer                as integer format ">>>9" initial 0 label "Sequ�ncia" column-label "Seq"
    field tta_cod_pais                     as character format "x(3)" label "Pa�s" column-label "Pa�s"
    field tta_cod_unid_federac             as character format "x(3)" label "Unidade Federa��o" column-label "UF"
    field tta_cod_imposto                  as character format "x(5)" label "Imposto" column-label "Imposto"
    field tta_cod_classif_impto            as character format "x(05)" initial "00000" label "Class Imposto" column-label "Class Imposto"
    field tta_num_seq                      as integer format ">>>,>>9" initial 0 label "Sequ�ncia" column-label "NumSeq"
    field ttv_num_tip_operac               as integer format ">9"
    field tta_val_rendto_tribut            as decimal format ">,>>>,>>>,>>9.99" decimals 2 initial 0 label "Rendto Tribut vel" column-label "Vl Rendto Tribut"
    field tta_val_aliq_impto               as decimal format ">9.99" decimals 2 INITIAL 0.00 label "Al�quota" column-label "Aliq"
    field tta_val_imposto                  as decimal format ">,>>>,>>>,>>9.99" decimals 2 initial 0 label "Valor Imposto" column-label "Vl Imposto"
    index tt_id                            is primary unique
          tta_cod_estab                    ascending
          tta_num_id_tit_acr               ascending
          tta_cod_pais                     ascending
          tta_cod_unid_federac             ascending
          tta_cod_imposto                  ascending
          tta_cod_classif_impto            ascending
          tta_num_seq                      ascending.          

def temp-table tt_alter_tit_acr_ped_vda no-undo
    field tta_cod_estab                    as character format "x(5)" label "Estabelecimento" column-label "Estab"
    field tta_num_id_tit_acr               as integer format "9999999999" initial 0 label "Token Cta Receber" column-label "Token Cta Receber"
    field ttv_num_tip_operac               as integer format ">9"
    field tta_cod_ped_vda                  as character format "x(15)" label "Pedido Venda" column-label "Pedido Venda"
    field tta_cod_ped_vda_repres           as character format "x(30)" label "Pedido Repres" column-label "Pedido Repres"
    field tta_val_perc_particip_ped_vda    as decimal format ">>9.99" decimals 2 initial 0 label "Particip Ped Vda" column-label "Particip"
    field tta_des_ped_vda                  as character format "x(40)" label "Pedido Venda" column-label "Pedido Venda"
    index tt_id                            is primary unique
          tta_cod_estab                    ascending
          tta_num_id_tit_acr               ascending
          tta_cod_ped_vda                  ascending.          

def temp-table tt_alter_tit_acr_rateio no-undo
    field tta_cod_estab                    as character format "x(5)" label "Estabelecimento" column-label "Estab"
    field tta_num_id_tit_acr               as integer format "9999999999" initial 0 label "Token Cta Receber" column-label "Token Cta Receber"
    field ttv_ind_tip_rat_tit_acr          as character format "X(12)" label "Tipo Rateio" column-label "Tipo Rateio"
    field tta_cod_refer                    as character format "x(10)" label "Refer�ncia" column-label "Refer�ncia"
    field tta_num_seq_refer                as integer format ">>>9" initial 0 label "Sequ�ncia" column-label "Seq"
    field tta_cod_plano_cta_ctbl           as character format "x(8)" label "Plano Contas" column-label "Plano Contas"
    field tta_cod_cta_ctbl                 as character format "x(20)" label "Conta Cont bil" column-label "Conta Cont bil"
    field tta_cod_unid_negoc               as character format "x(3)" label "Unid Neg�cio" column-label "Un Neg"
    field tta_cod_plano_ccusto             as character format "x(8)" label "Plano Centros Custo" column-label "Plano Centros Custo"
    field tta_cod_ccusto                   as Character format "x(11)" label "Centro Custo" column-label "Centro Custo"
    field tta_cod_tip_fluxo_financ         as character format "x(12)" label "Tipo Fluxo Financ" column-label "Tipo Fluxo Financ"
    field tta_num_seq_aprop_ctbl_pend_acr  as integer format ">>>9" initial 0 label "Seq Aprop Pend" column-label "Seq Apro"
    field tta_val_aprop_ctbl               as decimal format "->>>,>>>,>>9.99" decimals 2 initial 0 label "Valor Aprop Ctbl" column-label "Vl Aprop Ctbl"
    field tta_log_impto_val_agreg          as logical format "Sim/N�o" initial no label "Impto Val Agreg" column-label "Imp Vl Agr"
    field tta_cod_pais                     as character format "x(3)" label "Pa�s" column-label "Pa�s"
    field tta_cod_unid_federac             as character format "x(3)" label "Unidade Federa��o" column-label "UF"
    field tta_cod_imposto                  as character format "x(5)" label "Imposto" column-label "Imposto"
    field tta_cod_classif_impto            as character format "x(05)" initial "00000" label "Class Imposto" column-label "Class Imposto"
    field tta_dat_transacao                as date format "99/99/9999" initial today label "Data Transa��o" column-label "Dat Transac"
    index tt_relac_tit_acr               
          tta_cod_estab                    ascending
          tta_num_id_tit_acr               ascending.          

def temp-table tt_alter_tit_acr_rat_desp_rec no-undo
    field tta_cod_empresa                  as character format "x(3)" label "Empresa" column-label "Empresa"
    field tta_cod_estab                    as character format "x(5)" label "Estabelecimento" column-label "Estab"
    field tta_cod_plano_cta_ctbl           as character format "x(8)" label "Plano Contas" column-label "Plano Contas"
    field tta_cod_cta_ctbl                 as character format "x(20)" label "Conta Cont bil" column-label "Conta Cont bil"
    field tta_cod_unid_negoc               as character format "x(3)" label "Unid Neg�cio" column-label "Un Neg"
    field tta_cod_tip_abat                 as character format "x(8)" label "Tipo de Abatimento" column-label "Tipo de Abatimento"
    field tta_val_perc_rat_ctbz            as decimal format ">>9.99" decimals 2 initial 0 label "Perc Rateio" column-label "% Rat"
    field tta_ind_tip_aprop_recta_despes   as character format "x(20)" label "Tipo Apropria��o" column-label "Tipo Apropria��o"
    field tta_num_id_tit_acr               as integer format "9999999999" initial 0 label "Token Cta Receber" column-label "Token Cta Receber"
    field tta_num_id_aprop_despes_recta    as integer format "9999999999" initial 0 label "Id Apropria��o" column-label "Id Apropria��o"
    field tta_cod_tip_fluxo_financ         as character format "x(12)" label "Tipo Fluxo Financ" column-label "Tipo Fluxo Financ"
    field tta_cod_livre_1                  as character format "x(100)" label "Livre 1" column-label "Livre 1"
    index tt_aprpdspa_id                   is primary unique
          tta_cod_estab                    ascending
          tta_num_id_tit_acr               ascending
          tta_cod_plano_cta_ctbl           ascending
          tta_cod_cta_ctbl                 ascending
          tta_cod_unid_negoc               ascending
          tta_cod_tip_fluxo_financ         ascending
          tta_num_id_aprop_despes_recta    ascending
    index tt_aprpdspa_token                is unique
          tta_cod_estab                    ascending
          tta_num_id_aprop_despes_recta    ascending.

def temp-table tt_log_erros_alter_tit_acr no-undo
    field tta_cod_estab                    as character format "x(3)" label "Estabelecimento" column-label "Estab"
    field tta_num_id_tit_acr               as integer format "9999999999" initial 0 label "Token Cta Receber" column-label "Token Cta Receber"
    field ttv_num_mensagem                 as integer format ">>>>,>>9" label "N�mero" column-label "N�mero Mensagem"
    field ttv_cod_tip_msg_dwb              as character format "x(12)" label "Tipo Mensagem" column-label "Tipo Mensagem"
    field ttv_des_msg_erro                 as character format "x(60)" label "Mensagem Erro" column-label "Inconsist�ncia"
    field ttv_des_msg_ajuda                as character format "x(40)" label "Mensagem Ajuda" column-label "Mensagem Ajuda"
    field ttv_wgh_focus                    as widget-handle format ">>>>>>9"
    index tt_relac_tit_acr               
          tta_cod_estab                    ascending
          tta_num_id_tit_acr               ascending
          ttv_num_mensagem                 ascending.          

def temp-table tt_alter_tit_acr_cobr_esp_2_c no-undo
    field tta_cod_estab                    as Character format "x(5)" label "Estabelecimento" column-label "Estab"
    field tta_num_id_tit_acr               as integer format "999999999" initial 0 label "Token Cta Receber" column-label "Token Cta Receber"
    field tta_cod_admdra_cartao_cr         as character format "x(5)" label "Administradora" column-label "Administradora"
    field tta_cod_band                     as character format "x(10)" label "Bandeira" column-label "Bandeira"
    field tta_cod_tid                      as character format "x(10)" label "TID" column-label "TID"
    field tta_cod_terminal                 as character format "x(8)" label "Nr Terminal" column-label "Nr Terminal".          
          
def temp-table tt_api_params_generic        
    field ttv_cod_row_id                   as character format "x(80)"
    field ttv_cod_tabela                   as character format "x(28)" label "Tabela" column-label "Tabela"
    field ttv_cod_campo                    as character format "x(35)" label "Campo" column-label "Campo"
    field ttv_cod_valor                    as character format "x(8)" label "Valor" column-label "Valor"
    index tt_idx_param_generic             is primary unique
          ttv_cod_tabela                   ascending
          ttv_cod_row_id                   ascending
          ttv_cod_campo                    ASCENDING    .          
          
//final das tt da aPI

DEFINE VARIABLE h-utapi033  AS HANDLE NO-UNDO.    

DEFINE TEMP-TABLE tt-param-api NO-UNDO
    FIELD descricao  AS CHARACTER
    FIELD valor  AS CHARACTER.

DEFINE TEMP-TABLE tt-digita-api NO-UNDO
    FIELD descricao  AS CHARACTER
    FIELD valor  AS CHARACTER.

DEF TEMP-TABLE tt_tit_acr NO-UNDO
    FIELD cod_estab       LIKE tit_acr.cod_estab
    FIELD cod_espec_docto LIKE tit_acr.cod_espec_docto
    FIELD cod_ser_docto   LIKE tit_acr.cod_ser_docto
    FIELD cod_tit_acr     LIKE tit_acr.cod_tit_acr
    FIELD cod_parcela     LIKE tit_acr.cod_parcela
    FIELD cod-emitente    LIKE emitente.cod-emitente
    FIELD nome-abrev      LIKE emitente.nome-abrev
    FIELD val_baixa       AS DEC
    FIELD val_saldo       AS DEC
    FIELD ind_sit         AS CHAR INIT "0-Importado" /*0-importado,1-Atualizado, 2-com erro*/
    FIELD mensagem        AS CHAR
    FIELD num_id_tit_acr  AS INT
    FIELD linha           AS INT
    INDEX ch_princ cod_estab      
                   cod_espec_docto
                   cod_ser_docto  
                   cod_tit_acr    
                   cod_parcela
    INDEX i-sit-linha ind_sit linha
    INDEX i-id    cod_estab num_id_tit_acr.

/* include padr�o para vari�veis para o log  */
{include/i-rpvar.i}

/* defini��o de vari�veis e streams */
def stream s-imp.
def var h-acomp as handle no-undo.
def var c-linha as char no-undo.
def var i-cust as int no-undo.
DEFINE VARIABLE i-linha AS INTEGER     NO-UNDO.
DEFINE VARIABLE l-erro  AS LOGICAL     NO-UNDO.

DEF BUFFER b_tt_tit_acr FOR tt_tit_acr.

/*--- Logica principal -----------------------------------------------------------------------*/
CREATE tt-param.
RAW-TRANSFER raw-param to tt-param.

/* defini��o de frames do log */
/* include padr�o para output de log */
//{include/i-rpout.i &TOFILE=tt-param.arq-destino}
/* include com a defini��o da frame de cabe�alho e rodap� */
//{include/i-rpcab.i }
/* bloco principal do programa */
ASSIGN c-programa   = "ESACR9003RP"
       c-versao     = "3.00"
       c-revisao    = ".00.000"
       c-empresa    = "Eucatex"
       c-sistema    = 'Contas a Receber'
       c-titulo-relat = "Erros da Importa��o baixas de t�tulos".
//view stream str-rp frame f-cabec.
//view stream str-rp frame f-rodape.

run utp/ut-acomp.p persistent set h-acomp.
{utp/ut-liter.i Importando *}

run pi-inicializar in h-acomp (input RETURN-VALUE).

ASSIGN i-linha = 0
       l-erro  = NO.

/* define o arquivo de entrada informando na p�gina de par�metros */
INPUT STREAM s-imp FROM VALUE(tt-param.arq-entrada).
REPEAT ON STOP UNDO, RETRY:
    IF RETRY THEN DO:
        MESSAGE "Processo interrompido"
            VIEW-AS ALERT-BOX ERROR BUTTONS OK.
        ASSIGN l-erro = YES.
        UNDO, LEAVE.    
    END.
	import stream s-imp unformatted c-linha.
    
    ASSIGN i-linha = i-linha + 1.
    IF TRIM(c-linha) = "" THEN NEXT.
    IF ENTRY(1, c-linha, ";") BEGINS "Est" THEN NEXT.
    
	run pi-acompanhar in h-acomp ("Importando linha:" + STRING(i-linha)).
    
    IF NUM-ENTRIES(c-linha,";") >= 6 THEN DO:
        IF  TRIM(ENTRY(1, c-linha, ";")) = ""
        AND TRIM(ENTRY(2, c-linha, ";")) = ""
        AND TRIM(ENTRY(3, c-linha, ";")) = ""
        AND TRIM(ENTRY(4, c-linha, ";")) = ""
        AND TRIM(ENTRY(5, c-linha, ";")) = "" THEN NEXT.
    END.
        
    CREATE tt_tit_acr.
    ASSIGN tt_tit_acr.linha = i-linha.
    
    IF NUM-ENTRIES(c-linha,";") < 6 THEN DO:
        RUN PI-Log("Leiaute inv�lido. O arquivo deve conter 6 colunas separadas por ';'") .
        NEXT.
    END.
    
    ASSIGN tt_tit_acr.cod_estab       = ENTRY(1, c-linha, ";")
           tt_tit_acr.cod_espec_docto = ENTRY(2, c-linha, ";")
           tt_tit_acr.cod_ser_docto   = ENTRY(3, c-linha, ";")
           tt_tit_acr.cod_tit_acr     = ENTRY(4, c-linha, ";")                
           tt_tit_acr.cod_parcela     = ENTRY(5, c-linha, ";").
    ASSIGN tt_tit_acr.val_baixa       = DEC(ENTRY(6, c-linha, ";"))
           NO-ERROR.
    IF ERROR-STATUS:ERROR THEN DO:
        RUN PI-Log("Leiaute inv�lido. O sexto campo deve conter um valor decimal. " + ERROR-STATUS:get-message(1)).
        NEXT.
    END.
    ASSIGN tt_tit_acr.ind_sit = "0-importado".
    FIND FIRST b_tt_tit_acr
         WHERE b_tt_tit_acr.cod_estab       = tt_tit_acr.cod_estab      
         AND   b_tt_tit_acr.cod_espec_docto = tt_tit_acr.cod_espec_docto
         AND   b_tt_tit_acr.cod_ser_docto   = tt_tit_acr.cod_ser_docto  
         AND   b_tt_tit_acr.cod_tit_acr     = tt_tit_acr.cod_tit_acr    
         AND   b_tt_tit_acr.cod_parcela     = tt_tit_acr.cod_parcela    
         AND   RECID(b_tt_tit_acr)         <> RECID(tt_tit_acr)
         NO-ERROR.
    IF AVAIL b_tt_tit_acr THEN DO:
        RUN PI-Log("Registro em duplicidade com a linha: " + STRING(b_tt_tit_acr.linha)).
        NEXT.
    END.
    
    FIND tit_acr
         WHERE tit_acr.cod_estab       = tt_tit_acr.cod_estab      
         AND   tit_acr.cod_espec_docto = tt_tit_acr.cod_espec_docto
         AND   tit_acr.cod_ser_docto   = tt_tit_acr.cod_ser_docto  
         AND   tit_acr.cod_tit_acr     = tt_tit_acr.cod_tit_acr    
         AND   tit_acr.cod_parcela     = tt_tit_acr.cod_parcela  
         NO-LOCK NO-ERROR.
    IF NOT AVAIL tit_acr THEN DO:
        RUN PI-Log("Titulo n�o cadastrado").
        NEXT.
    END.
    ELSE DO:
        ASSIGN tt_tit_acr.cod-emitente = tit_acr.cdn_cliente.
        
        FIND emitente WHERE emitente.cod-emitente = tit_acr.cdn_cliente NO-LOCK NO-ERROR.
        IF AVAIL emitente THEN
            ASSIGN tt_tit_acr.nome-abrev = emitente.nome-abrev.
        
        ASSIGN tt_tit_acr.num_id_tit_acr = tit_acr.num_id_tit_acr
               tt_tit_acr.val_saldo      = tit_acr.val_sdo_tit_acr.

        IF tit_acr.val_sdo_tit_acr <= 0 THEN DO:
            RUN PI-Log("Titulo sem saldo").
            NEXT.
        END.
        IF tt_tit_acr.val_baixa > tit_acr.val_sdo_tit_acr THEN DO:
            RUN PI-Log("Valor da baixa informada � maior que o saldo do titulo").
            NEXT.
        END.
        
        IF tt_tit_acr.val_baixa <= 0 THEN 
            ASSIGN tt_tit_acr.val_baixa = tit_acr.val_sdo_tit_acr.
        
    END.
END.
input stream s-imp close.

//Ha registros sem erro
IF CAN-FIND(FIRST tt_tit_acr WHERE tt_tit_acr.ind_sit < "2-com erro") THEN DO:
    
    /*retirar este bloco ap�s os testes*
    DO TRANSACTION ON ERROR UNDO, RETRY ON ENDKEY UNDO, RETRY ON STOP UNDO, RETRY:
        IF RETRY THEN DO:
            MESSAGE "Processo interrompido"
                    VIEW-AS ALERT-BOX INFORMATION BUTTONS OK.
                
            UNDO, LEAVE.
        END.
    **/
        run pi-acompanhar in h-acomp ("Preparando atualizacao").
        RUN PI-API.
        
        run pi-acompanhar in h-acomp ("Gerando LOG").
        RUN PI-GeraXML.
    /**
        MESSAGE "UNDO"
            VIEW-AS ALERT-BOX INFORMATION BUTTONS OK.
        UNDO, LEAVE.
    END.
    **/
END.
ELSE DO:
    run pi-acompanhar in h-acomp ("Gerando LOG").
    RUN PI-GeraXML.
END.


/* fechamento do output do log */
//{include/i-rpclo.i }
run pi-finalizar in h-acomp.
return "Ok":U.


/*--- Procedures Internas --------------------------------------------------------------------*/

PROCEDURE PI-API:
    DEFINE VARIABLE v_cod_refer         AS CHARACTER   NO-UNDO.
    
    DEFINE VARIABLE v_hdl_aux           AS HANDLE      NO-UNDO.
    DEFINE VARIABLE v_dat_transacao     AS DATE        NO-UNDO.
    DEFINE VARIABLE v_log_integr_cmg    AS LOGICAL     NO-UNDO.
    DEFINE VARIABLE v_cod_portador      AS CHARACTER   NO-UNDO.
    DEFINE VARIABLE v_cod_cart_bcia     AS CHARACTER   NO-UNDO.
    DEFINE VARIABLE v_cod_cta_ctbl      AS CHARACTER   NO-UNDO.
    DEFINE VARIABLE i_num_seq_tit_acr   AS INTEGER     NO-UNDO.
                    
    EMPTY TEMP-TABLE tt_alter_tit_acr_base_5        .
    EMPTY TEMP-TABLE tt_alter_tit_acr_cheq          .
    EMPTY TEMP-TABLE tt_alter_tit_acr_cobr_espec_2  .
    EMPTY TEMP-TABLE tt_alter_tit_acr_comis_1       .
    EMPTY TEMP-TABLE tt_alter_tit_acr_impto_retid_2 .
    EMPTY TEMP-TABLE tt_alter_tit_acr_iva           .
    EMPTY TEMP-TABLE tt_alter_tit_acr_ped_vda       .
    EMPTY TEMP-TABLE tt_alter_tit_acr_rateio        .
    EMPTY TEMP-TABLE tt_alter_tit_acr_rat_desp_rec  .
    EMPTY TEMP-TABLE tt_log_erros_alter_tit_acr     .
    EMPTY TEMP-TABLE tt_alter_tit_acr_cobr_esp_2_c  .
    EMPTY TEMP-TABLE tt_api_params_generic          .
    
    ASSIGN v_dat_transacao   = tt-param.dat_transacao
           v_cod_portador    = tt-param.cod_portador
           v_cod_cart_bcia   = tt-param.cod_cart_bcia
           v_log_integr_cmg  = NO
           v_cod_cta_ctbl    = tt-param.cod_cta_ctbl
           i_num_seq_tit_acr = 0
           l-erro            = NO.

    bl-tit:
    FOR EACH  tt_tit_acr
        WHERE tt_tit_acr.ind_sit = "0-importado"
        BY tt_tit_acr.cod_estab
        BY tt_tit_acr.num_id_tit_acr
        ON ERROR UNDO, RETRY ON ENDKEY UNDO, RETRY ON STOP UNDO, RETRY:
        
        IF RETRY THEN DO:
            MESSAGE "Processo interrompido"
                VIEW-AS ALERT-BOX INFORMATION BUTTONS OK.
            ASSIGN l-erro = YES.
            UNDO, LEAVE.    
        END.
        
        RUN pi-acompanhar IN h-acomp ("Carregando t�tulo: " + tt_tit_acr.cod_estab + "/" + STRING(tt_tit_acr.num_id_tit_acr)).
        
        RUN pi_retorna_sugestao_referencia(tt_tit_acr.cod_estab, "P", v_dat_transacao , OUTPUT v_cod_refer).
               
        FIND estabelecimento WHERE estabelecimento.cod_estab = tt_tit_acr.cod_estab NO-LOCK NO-ERROR.
        FIND tit_acr
             WHERE tit_acr.cod_estab       = tt_tit_acr.cod_estab      
             AND   tit_acr.cod_espec_docto = tt_tit_acr.cod_espec_docto
             AND   tit_acr.cod_ser_docto   = tt_tit_acr.cod_ser_docto  
             AND   tit_acr.cod_tit_acr     = tt_tit_acr.cod_tit_acr    
             AND   tit_acr.cod_parcela     = tt_tit_acr.cod_parcela    
             NO-LOCK NO-ERROR.
        FIND FIRST movto_tit_acr OF tit_acr NO-LOCK NO-ERROR.
        FIND FIRST aprop_ctbl_acr OF movto_tit_acr NO-LOCK NO-ERROR.
             
        ASSIGN i_num_seq_tit_acr = i_num_seq_tit_acr + 1.     
        
        CREATE tt_alter_tit_acr_base_5.
        ASSIGN tt_alter_tit_acr_base_5.tta_cod_estab                    = tit_acr.cod_estab
               tt_alter_tit_acr_base_5.tta_num_id_tit_acr               = tit_acr.num_id_tit_acr
               tt_alter_tit_acr_base_5.tta_dat_transacao                = v_dat_transacao //tit_acr.dat_transacao
               tt_alter_tit_acr_base_5.tta_cod_refer                    = v_cod_refer //tit_acr.cod_refer     
               tt_alter_tit_acr_base_5.ttv_cod_motiv_movto_tit_acr_imp  = "" 
               tt_alter_tit_acr_base_5.tta_val_sdo_tit_acr              = tit_acr.val_sdo_tit_acr - tt_tit_acr.val_baixa
               tt_alter_tit_acr_base_5.ttv_cod_motiv_movto_tit_acr_alt  = ""
               tt_alter_tit_acr_base_5.ttv_ind_motiv_acerto_val         = "Altera��o" //"Liquida��o"
               tt_alter_tit_acr_base_5.tta_cod_portador                 = v_cod_portador  //tit_acr.cod_portador
               tt_alter_tit_acr_base_5.tta_cod_cart_bcia                = v_cod_cart_bcia //tit_acr.cod_cart_bcia
               tt_alter_tit_acr_base_5.tta_val_despes_bcia              = tit_acr.val_despes_bcia
               tt_alter_tit_acr_base_5.tta_cod_agenc_cobr_bcia          = tit_acr.cod_agenc_cobr_bcia       
               tt_alter_tit_acr_base_5.tta_cod_tit_acr_bco              = tit_acr.cod_tit_acr_bco           
               tt_alter_tit_acr_base_5.tta_dat_emis_docto               = tit_acr.dat_emis_docto            
               tt_alter_tit_acr_base_5.tta_dat_vencto_tit_acr           = tit_acr.dat_vencto_tit_acr        
               tt_alter_tit_acr_base_5.tta_dat_prev_liquidac            = tit_acr.dat_prev_liquidac         
               tt_alter_tit_acr_base_5.tta_dat_fluxo_tit_acr            = tit_acr.dat_fluxo_tit_acr         
               tt_alter_tit_acr_base_5.tta_ind_sit_tit_acr              = tit_acr.ind_sit_tit_acr           
               tt_alter_tit_acr_base_5.tta_cod_cond_cobr                = tit_acr.cod_cond_cobr             
               tt_alter_tit_acr_base_5.tta_log_tip_cr_perda_dedut_tit   = tit_acr.log_tip_cr_perda_dedut_tit
               tt_alter_tit_acr_base_5.tta_dat_abat_tit_acr             = ? //tit_acr.dat_abat_tit_acr          
               tt_alter_tit_acr_base_5.tta_val_perc_abat_acr            = 0 //tit_acr.val_perc_abat_acr         
               tt_alter_tit_acr_base_5.tta_val_abat_tit_acr             = 0 //tit_acr.val_abat_tit_acr          
               tt_alter_tit_acr_base_5.tta_dat_desconto                 = tit_acr.dat_desconto              
               tt_alter_tit_acr_base_5.tta_val_perc_desc                = tit_acr.val_perc_desc             
               tt_alter_tit_acr_base_5.tta_val_desc_tit_acr             = tit_acr.val_desc_tit_acr          
               tt_alter_tit_acr_base_5.tta_qtd_dias_carenc_juros_acr    = tit_acr.qtd_dias_carenc_juros_acr 
               tt_alter_tit_acr_base_5.tta_val_perc_juros_dia_atraso    = tit_acr.val_perc_juros_dia_atraso 
               tt_alter_tit_acr_base_5.tta_qtd_dias_carenc_multa_acr    = tit_acr.qtd_dias_carenc_multa_acr 
               tt_alter_tit_acr_base_5.tta_val_perc_multa_atraso        = tit_acr.val_perc_multa_atraso     
               tt_alter_tit_acr_base_5.ttv_cod_portador_mov             = ""
               tt_alter_tit_acr_base_5.tta_ind_tip_cobr_acr             = tit_acr.ind_tip_cobr_acr        
               tt_alter_tit_acr_base_5.tta_ind_ender_cobr               = tit_acr.ind_ender_cobr          
               tt_alter_tit_acr_base_5.tta_nom_abrev_contat             = tit_acr.nom_abrev_contat        
               tt_alter_tit_acr_base_5.tta_val_liq_tit_acr              = tit_acr.val_liq_tit_acr         
               tt_alter_tit_acr_base_5.tta_cod_instruc_bcia_1_movto     = ""
               tt_alter_tit_acr_base_5.tta_cod_instruc_bcia_2_movto     = ""
               tt_alter_tit_acr_base_5.tta_log_tit_acr_destndo          = NO
               tt_alter_tit_acr_base_5.tta_cod_histor_padr              = ""
               tt_alter_tit_acr_base_5.ttv_des_text_histor              = ""
               tt_alter_tit_acr_base_5.tta_des_obs_cobr                 = ""
             //tt_alter_tit_acr_base_5.ttv_wgh_lista                    = 0
               tt_alter_tit_acr_base_5.tta_num_seq_tit_acr              = i_num_seq_tit_acr
               tt_alter_tit_acr_base_5.ttv_cod_estab_planilha           = ""
               tt_alter_tit_acr_base_5.ttv_num_planilha_vendor          = 0
               tt_alter_tit_acr_base_5.ttv_cod_cond_pagto_vendor        = ""
               tt_alter_tit_acr_base_5.ttv_val_cotac_tax_vendor_clien   = 0
               tt_alter_tit_acr_base_5.ttv_dat_base_fechto_vendor       = ?
               tt_alter_tit_acr_base_5.ttv_qti_dias_carenc_fechto       = 0
               tt_alter_tit_acr_base_5.ttv_log_assume_tax_bco           = NO
               tt_alter_tit_acr_base_5.ttv_log_vendor                   = NO
               tt_alter_tit_acr_base_5.tta_val_cr_pis                   = tit_acr.val_cr_pis           
               tt_alter_tit_acr_base_5.tta_val_cr_cofins                = tit_acr.val_cr_cofins        
               tt_alter_tit_acr_base_5.tta_val_cr_csll                  = tit_acr.val_cr_csll          
               tt_alter_tit_acr_base_5.tta_val_base_calc_impto          = tit_acr.val_base_calc_impto  
               tt_alter_tit_acr_base_5.tta_log_retenc_impto_impl        = tit_acr.log_retenc_impto_impl
               tt_alter_tit_acr_base_5.tta_cdn_repres                   = tit_acr.cdn_repres           
               tt_alter_tit_acr_base_5.tta_cod_proces_export            = tit_acr.cod_proces_export    
               tt_alter_tit_acr_base_5.ttv_log_estorn_impto_retid       = NO.

        CREATE tt_alter_tit_acr_rateio.
        ASSIGN tt_alter_tit_acr_rateio.tta_cod_estab                    = tit_acr.cod_estab
               tt_alter_tit_acr_rateio.tta_num_id_tit_acr               = tit_acr.num_id_tit_acr
               tt_alter_tit_acr_rateio.ttv_ind_tip_rat_tit_acr          = "Altera��o" //"Liquida��o"
               tt_alter_tit_acr_rateio.tta_cod_refer                    = v_cod_refer
               tt_alter_tit_acr_rateio.tta_num_seq_refer                = i_num_seq_tit_acr
               tt_alter_tit_acr_rateio.tta_cod_plano_cta_ctbl           = aprop_ctbl_acr.cod_plano_cta_ctbl
               tt_alter_tit_acr_rateio.tta_cod_cta_ctbl                 = v_cod_cta_ctbl
               tt_alter_tit_acr_rateio.tta_cod_unid_negoc               = ""
               tt_alter_tit_acr_rateio.tta_cod_plano_ccusto             = ""
               tt_alter_tit_acr_rateio.tta_cod_ccusto                   = ""
               tt_alter_tit_acr_rateio.tta_cod_tip_fluxo_financ         = ""
               tt_alter_tit_acr_rateio.tta_num_seq_aprop_ctbl_pend_acr  = 1
               tt_alter_tit_acr_rateio.tta_val_aprop_ctbl               = tt_tit_acr.val_baixa //tit_acr.val_sdo_tit_acr
               tt_alter_tit_acr_rateio.tta_log_impto_val_agreg          = NO
               tt_alter_tit_acr_rateio.tta_cod_pais                     = ""
               tt_alter_tit_acr_rateio.tta_cod_unid_federac             = ""
               tt_alter_tit_acr_rateio.tta_cod_imposto                  = ""
               tt_alter_tit_acr_rateio.tta_cod_classif_impto            = ""
               tt_alter_tit_acr_rateio.tta_dat_transacao                = v_dat_transacao.
    END. //EACH tt_tit_acr
    

    IF NOT l-erro THEN DO:
        run pi-acompanhar in h-acomp ("Executando a API").
        
        run prgfin/acr/acr711zv.py persistent set v_hdl_aux .
        
        run pi_main_code_integr_acr_alter_tit_acr_novo_15 in v_hdl_aux
                (Input  15,
                Input  table tt_alter_tit_acr_base_5,
                Input  table tt_alter_tit_acr_rateio,
                Input  table tt_alter_tit_acr_ped_vda,
                INPUT  table tt_alter_tit_acr_comis_1,
                Input  table tt_alter_tit_acr_cheq,
                Input  table tt_alter_tit_acr_iva,
                Input  table tt_alter_tit_acr_impto_retid_2,                                                     
                Input  table tt_alter_tit_acr_cobr_espec_2,
                Input  table tt_alter_tit_acr_rat_desp_rec,
                Output table tt_log_erros_alter_tit_acr,
                Input  v_log_integr_cmg,
                Input  table tt_alter_tit_acr_cobr_esp_2_c,
                Input  table tt_api_params_generic).
                
        Delete procedure v_hdl_aux.

        IF CAN-FIND(FIRST tt_log_erros_alter_tit_acr) THEN DO:
        
            FOR EACH tt_log_erros_alter_tit_acr:
                run pi-acompanhar in h-acomp ("Gravando log").
                FIND FIRST tt_tit_acr
                     WHERE tt_tit_acr.cod_estab      = tt_log_erros_alter_tit_acr.tta_cod_estab      
                     AND   tt_tit_acr.num_id_tit_acr = tt_log_erros_alter_tit_acr.tta_num_id_tit_acr 
                     NO-ERROR.
                IF AVAIL tt_tit_acr THEN DO:
                    RUN PI-Log(tt_log_erros_alter_tit_acr.ttv_cod_tip_msg_dwb + "-" +
                               tt_log_erros_alter_tit_acr.ttv_des_msg_erro    + "-" + 
                               tt_log_erros_alter_tit_acr.ttv_des_msg_ajuda). 
                END.
            END.
        END.
    END.

    //Verifica se o documento foi realmente baixado
    FOR EACH tt_tit_acr
        WHERE tt_tit_acr.ind_sit = "0-importado":
        
        run pi-acompanhar in h-acomp ("Validando atualizacao").
        FIND tit_acr
             WHERE tit_acr.cod_estab      = tt_tit_acr.cod_estab     
             AND   tit_acr.num_id_tit_acr = tt_tit_acr.num_id_tit_acr
             NO-LOCK NO-ERROR.
        IF NOT AVAIL tit_acr THEN DO:
            RUN PI-Log("Titulo do ACR nao encontrado").
            NEXT.            
        END.
        IF tit_acr.val_sdo_tit_acr <> (tt_tit_acr.val_saldo - tt_tit_acr.val_baixa) THEN DO:
            RUN PI-Log("Titulo do ACR com saldo diferente do programado. Saldo do t�tulo: " + STRING(tit_acr.val_sdo_tit_acr) + ", saldo programado: " + STRING(tt_tit_acr.val_saldo - tt_tit_acr.val_baixa)).
            NEXT.            
        END.
        ASSIGN tt_tit_acr.ind_sit = "1-Atualizado".
    END.
    
    RETURN "OK".
END PROCEDURE. //PI-API

PROCEDURE pi_retorna_sugestao_referencia:

    DEFINE INPUT  PARAMETER p_cod_estab         AS CHARACTER                     NO-UNDO.
    DEFINE INPUT  PARAMETER p_ind_tip_atualiz   as CHARACTER format "X(08)"      no-undo.
    DEFINE INPUT  PARAMETER p_dat_refer         as date      format "99/99/9999" no-undo.
    DEFINE OUTPUT PARAMETER p_cod_refer         as CHARACTER format "x(10)"      no-undo.

    DEFINE VARIABLE v_des_dat                   as character       no-undo. /*local*/
    DEFINE VARIABLE v_num_aux                   as integer         no-undo. /*local*/
    DEFINE VARIABLE v_num_aux_2                 as integer         no-undo. /*local*/
    DEFINE VARIABLE v_num_cont                  as integer         no-undo. /*local*/

    DEFINE VARIABLE v_cod_refer_acr_fix         AS CHARACTER FORMAT "x(10)" NO-UNDO.
    DEFINE VARIABLE v_cod_refer_acr             AS CHARACTER FORMAT "x(10)" NO-UNDO.
    DEFINE VARIABLE v_mes                       AS CHARACTER FORMAT "x(2)"  NO-UNDO.
    DEFINE VARIABLE v_num_i                     AS INTEGER   INITIAL 0      NO-UNDO.
    DEFINE VARIABLE i-cont                      AS INTEGER     NO-UNDO.

    DEF BUFFER b_tt_alter_tit_acr_base_5 FOR tt_alter_tit_acr_base_5.

    
    CASE MONTH(p_dat_refer):
        WHEN 1  THEN ASSIGN v_mes = "A".
        WHEN 2  THEN ASSIGN v_mes = "B".
        WHEN 3  THEN ASSIGN v_mes = "C".
        WHEN 4  THEN ASSIGN v_mes = "D".
        WHEN 5  THEN ASSIGN v_mes = "E".
        WHEN 6  THEN ASSIGN v_mes = "F".
        WHEN 7  THEN ASSIGN v_mes = "G".
        WHEN 8  THEN ASSIGN v_mes = "H".
        WHEN 9  THEN ASSIGN v_mes = "I".
        WHEN 10 THEN ASSIGN v_mes = "J".
        WHEN 11 THEN ASSIGN v_mes = "K".
        WHEN 12 THEN ASSIGN v_mes = "L".
    END CASE.

    DO i-cont = 65 TO 90:
        ASSIGN p_cod_refer = v_mes 
                           + STRING(DAY  (p_dat_refer),"99")
                           + REPLACE(STRING(TIME,"hh:mm:ss"),":","")
                           + CHR(i-cont).
        IF NOT CAN-FIND(FIRST movto_tit_acr use-index mvtttcr_refer 
        WHERE movto_tit_acr.cod_estab   = p_cod_estab
        AND   movto_tit_acr.cod_refer   = p_cod_refer)      
        AND NOT CAN-FIND(FIRST b_tt_alter_tit_acr_base_5 WHERE b_tt_alter_tit_acr_base_5.tta_cod_refer = p_cod_refer)  THEN 
            RETURN "OK" .
    END.

    //Se esta sem disponibilidade, vai para o padrao

    assign v_des_dat   = string(p_dat_refer,"99999999")
           p_cod_refer = substring(v_des_dat,7,2)
                       + substring(v_des_dat,3,2)
                       + substring(v_des_dat,1,2)
                       + substring(p_ind_tip_atualiz,1,1)
           v_num_aux_2 = integer(this-procedure:handle).

    do  v_num_cont = 1 to 3:
        assign v_num_aux   = (random(0,v_num_aux_2) mod 26) + 97
               p_cod_refer = p_cod_refer + chr(v_num_aux).
    end.
    
    
    RETURN "OK".
END PROCEDURE. /* pi_retorna_sugestao_referencia */


PROCEDURE PI-Log:
    DEFINE INPUT  PARAMETER p-mensagem AS CHARACTER   NO-UNDO.

    ASSIGN l-erro = YES
           tt_tit_acr.ind_sit  = "2-com erro"
           tt_tit_acr.mensagem = p-mensagem.

END PROCEDURE. //PI-Log


PROCEDURE PI-GeraXML :
/*------------------------------------------------------------------------------
  Purpose:     
  Parameters:  <none>
  Notes:       
------------------------------------------------------------------------------*/
    DEFINE VARIABLE iParamColumnWidth AS INTEGER EXTENT 2 NO-UNDO.
    DEFINE VARIABLE iDigitColumnWidth AS INTEGER EXTENT 2 NO-UNDO.
    DEFINE VARIABLE c-arquivo AS CHARACTER   NO-UNDO.

    ASSIGN c-arquivo = tt-param.arq-destino.
    IF c-arquivo = ? THEN DO:
        ASSIGN c-arquivo = RIGHT-TRIM(SESSION:TEMP-DIR,"~\") + "~\" + "dc1000rp.xml".
    END.
    
    /*Necessario o output porque na piProcessa da api utapi033, esta sendo apresentado o erro:
    Invalid handle.  Not initialized or points to a deleted object. (3135)
    quando executado por RPW*/
    IF i-num-ped-exec-rpw <> 0 THEN
        OUTPUT TO VALUE(c-arquivo + ".LOG").

    RUN utp/utapi033.p PERSISTENT SET h-utapi033.

    RUN show IN h-utapi033 (TRUE). //indica se deve mostrar o aquivo
    RUN ConvertToXls IN h-utapi033 (TRUE). //indica se convertera para excel
    

/*  RUN piWorksheetColumn IN h-utapi033(INPUT 1, //Pasta
                                        INPUT 1, //Coluna
                                        INPUT tt-item.desc-item:DATA-TYPE IN FRAME f-a, //"CHAR", //DATATYPE
                                        INPUT "Descri��o", //Label
                                        INPUT "",  //format 
                                        INPUT ""). //width
*/

    RUN piWorksheetColumn IN h-utapi033(INPUT 1, INPUT 01, INPUT "CHAR", INPUT "Est"          , INPUT "x(5)"         , INPUT 40). 
    RUN piWorksheetColumn IN h-utapi033(INPUT 1, INPUT 02, INPUT "CHAR", INPUT "Esp�c."       , INPUT "x(5)"         , INPUT 40). 
    RUN piWorksheetColumn IN h-utapi033(INPUT 1, INPUT 03, INPUT "CHAR", INPUT "S�rie"        , INPUT "x(5)"         , INPUT 40).
    RUN piWorksheetColumn IN h-utapi033(INPUT 1, INPUT 04, INPUT "CHAR", INPUT "T�tulo"       , INPUT "x(20)"        , INPUT 80). 
    RUN piWorksheetColumn IN h-utapi033(INPUT 1, INPUT 05, INPUT "CHAR", INPUT "Parcela"      , INPUT "x(5)"         , INPUT 40). 
    RUN piWorksheetColumn IN h-utapi033(INPUT 1, INPUT 06, INPUT "INTE", INPUT "ID"           , INPUT ">>>>>>>>9"    , INPUT 80). 
    RUN piWorksheetColumn IN h-utapi033(INPUT 1, INPUT 07, INPUT "INTE", INPUT "Emitente"     , INPUT ">>>>>>>>9"    , INPUT 80). 
    RUN piWorksheetColumn IN h-utapi033(INPUT 1, INPUT 08, INPUT "CHAR", INPUT "Nome Abrev"   , INPUT "x(20)"        , INPUT 80). 
    RUN piWorksheetColumn IN h-utapi033(INPUT 1, INPUT 09, INPUT "DECI", INPUT "Vl Saldo Ori" , INPUT ">>>>>>>>>9.99", INPUT 80). 
    RUN piWorksheetColumn IN h-utapi033(INPUT 1, INPUT 10, INPUT "DECI", INPUT "Vl Baixa"     , INPUT ">>>>>>>>>9.99", INPUT 80). 
    RUN piWorksheetColumn IN h-utapi033(INPUT 1, INPUT 11, INPUT "INTE", INPUT "Linha"        , INPUT ">>>>>9"       , INPUT 50). 
    RUN piWorksheetColumn IN h-utapi033(INPUT 1, INPUT 12, INPUT "CHAR", INPUT "Situacao"     , INPUT "x(15)"        , INPUT 80).
    RUN piWorksheetColumn IN h-utapi033(INPUT 1, INPUT 13, INPUT "CHAR", INPUT "Mensagem"     , INPUT "x(500)"       , INPUT 500). 
    
    //Cria pasta a partir da tt
    RUN piNewWorksheetbyTT IN h-utapi033(INPUT "LogBaixa", 
                                         INPUT "Relatorio de Log de Baixas do ACR",
                                         INPUT BUFFER tt_tit_acr:HANDLE,
                                         INPUT "cod_estab,cod_espec_docto,cod_ser_docto,cod_tit_acr,cod_parcela,num_id_tit_acr,cod-emitente,nome-abrev,val_saldo,val_baixa,linha,ind_sit,mensagem",
                                         INPUT "cod_estab,cod_espec_docto,cod_ser_docto,cod_tit_acr,cod_parcela").

    //Impressao de parametros
    EMPTY TEMP-TABLE tt-param-api.
    CREATE tt-param-api.
    ASSIGN tt-param-api.descricao = "Arquivo importado:"
           tt-param-api.valor     = STRING(tt-param.arq-entrada).
    CREATE tt-param-api.
    ASSIGN tt-param-api.descricao = "Transa��o:"
           tt-param-api.valor     = STRING(tt-param.dat_transacao,"99/99/9999").
    CREATE tt-param-api.
    ASSIGN tt-param-api.descricao = "Portador:"
           tt-param-api.valor     = STRING(tt-param.cod_portador).
    CREATE tt-param-api.
    ASSIGN tt-param-api.descricao = "Carteira:"
           tt-param-api.valor     = STRING(tt-param.cod_cart_bcia).
    CREATE tt-param-api.
    ASSIGN tt-param-api.descricao = "Conta:"
           tt-param-api.valor     = STRING(tt-param.cod_cta_ctbl).
    CREATE tt-param-api.
    ASSIGN tt-param-api.descricao = "Data Execu��o:"
           tt-param-api.valor     = STRING(tt-param.data-exec,"99/99/9999").
    CREATE tt-param-api.
    ASSIGN tt-param-api.descricao = "Hora Execu��o:"
           tt-param-api.valor     = STRING(tt-param.hora-exec,"hh:mm:ss").
    CREATE tt-param-api.
    ASSIGN tt-param-api.descricao = "Usu�rio:"
           tt-param-api.valor     = STRING(tt-param.usuario).
           
           
    RUN setTTParam IN h-utapi033 (INPUT TABLE tt-param-api).
    ASSIGN iParamColumnWidth[1] = 150
           iParamColumnWidth[2] = 200.
    RUN setParamColumnWidth IN h-utapi033 (INPUT iParamColumnWidth).
    /*
    //Impressao da tt-digita
    EMPTY TEMP-TABLE tt-digita-api.
    FOR EACH tt-digita:
        CREATE tt-digita-api.
        ASSIGN tt-digita-api.descricao = "Item"
               tt-digita-api.valor     = tt-digita.it-codigo.
    END.

    RUN setTTDigita IN h-utapi033 (INPUT TABLE tt-digita-api).
    ASSIGN iDigitColumnWidth[1] = 150
           iDigitColumnWidth[2] = 200.
    RUN setDigitColumnWidth IN h-utapi033 (INPUT iDigitColumnWidth).
    */
    RUN piProcessa IN h-utapi033 (INPUT-OUTPUT c-arquivo, //desc-item do arquivo destino, retornando o desc-item do xml
                                  INPUT "ESACR9003RP",    //descricao do programa
                                  INPUT "Relatorio de Log de Baixas do ACR"). //titulo do relatorio

    IF RETURN-VALUE <> "OK" THEN DO:
        RUN getRowErrors IN h-utapi033 (output table RowErrors).
        FOR EACH RowErrors:
            MESSAGE RowErrors.ErrorNumber  "-"
                    RowErrors.ErrorDescription
                    VIEW-AS ALERT-BOX ERROR BUTTONS OK.

        END.
    END.

    IF VALID-HANDLE(h-utapi033) THEN
        DELETE OBJECT h-utapi033.

    IF i-num-ped-exec-rpw <> 0 THEN
        OUTPUT CLOSE.

    RETURN "OK".
END PROCEDURE. //PI-GeraXML

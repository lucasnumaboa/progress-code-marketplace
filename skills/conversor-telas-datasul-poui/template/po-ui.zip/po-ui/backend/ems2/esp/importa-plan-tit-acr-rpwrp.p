/******************************************************************************
** Programa  : importa-plan-tit-acr-rpwrp.p
** Tipo      : Programa RPW (report)
** Objetivo  : Roda no RPW. Varre a pasta do parametro global importa-cr-rpw,
**             procura arquivos "consolida_arquivo*.csv", importa cada um
**             reutilizando a BO pi-importar-lote (mesma logica da importacao
**             em tela) e EXCLUI o arquivo apos importar com sucesso.
**
** Fluxo:
**   1. Le o caminho da pasta no parametro es_param_global_ti_item
**      (cod_parametro = "importa-cr-rpw").
**   2. Lista os arquivos "consolida_arquivo*.csv" da pasta.
**   3. Para cada arquivo: le as linhas (delimitador ";"), monta o "lote"
**      (mesma estrutura enviada pela tela) e chama pi-importar-lote.
**   4. Se importou com sucesso (status 200), exclui o arquivo.
******************************************************************************/

BLOCK-LEVEL ON ERROR UNDO, THROW.

USING Progress.Json.ObjectModel.JsonObject.
USING Progress.Json.ObjectModel.JsonArray.

/* ---------- Scaffolding RPW (report) ---------- */
DEFINE TEMP-TABLE tt-param NO-UNDO
    FIELD destino          AS INTEGER
    FIELD arquivo          AS CHAR FORMAT "x(35)"
    FIELD usuario          AS CHAR FORMAT "x(12)"
    FIELD data-exec        AS DATE
    FIELD hora-exec        AS INTEGER
    FIELD classifica       AS INTEGER
    FIELD desc-classifica  AS CHAR FORMAT "x(40)"
    FIELD modelo-rtf       AS CHAR FORMAT "x(35)"
    FIELD l-habilitaRtf    AS LOG.

DEFINE TEMP-TABLE tt-raw-digita
    FIELD raw-digita AS RAW.

DEFINE INPUT PARAMETER raw-param AS RAW NO-UNDO.
DEFINE INPUT PARAMETER TABLE FOR tt-raw-digita.

CREATE tt-param.
RAW-TRANSFER raw-param TO tt-param.

/* ---------- Variaveis ---------- */
DEFINE VARIABLE c-usuario AS CHARACTER  NO-UNDO.
DEFINE VARIABLE c-path    AS CHARACTER  NO-UNDO.
DEFINE VARIABLE c-nome    AS CHARACTER  NO-UNDO.
DEFINE VARIABLE c-full    AS CHARACTER  NO-UNDO.
DEFINE VARIABLE c-attr    AS CHARACTER  NO-UNDO.
DEFINE VARIABLE c-linha   AS CHARACTER  NO-UNDO.
DEFINE VARIABLE i-col     AS INTEGER    NO-UNDO.
DEFINE VARIABLE i-linhas  AS INTEGER    NO-UNDO.
DEFINE VARIABLE oInput    AS JsonObject NO-UNDO.
DEFINE VARIABLE aLote     AS JsonArray  NO-UNDO.
DEFINE VARIABLE aLinha    AS JsonArray  NO-UNDO.
DEFINE VARIABLE lc-resp   AS LONGCHAR   NO-UNDO.
DEFINE VARIABLE i-st      AS INTEGER    NO-UNDO.
DEFINE VARIABLE h-bo      AS HANDLE     NO-UNDO.
DEFINE VARIABLE l-imp     AS LOGICAL    NO-UNDO.

DEFINE TEMP-TABLE tt-arq NO-UNDO
    FIELD nome AS CHARACTER
    FIELD full AS CHARACTER.

/* ---------- Usuario ---------- */
ASSIGN c-usuario = tt-param.usuario NO-ERROR.
IF c-usuario = "" OR c-usuario = ? THEN c-usuario = USERID("DICT") NO-ERROR.
IF c-usuario = "" OR c-usuario = ? THEN c-usuario = USERID(LDBNAME(1)) NO-ERROR.

/* ---------- Caminho da pasta (parametro importa-cr-rpw) ---------- */
FIND FIRST es_param_global_ti_item NO-LOCK
    WHERE es_param_global_ti_item.cod_parametro      = "importa-cr-rpw"
      AND es_param_global_ti_item.cod_parametro_item = "Linux" NO-ERROR.
IF NOT AVAILABLE es_param_global_ti_item THEN
    FIND FIRST es_param_global_ti_item NO-LOCK
        WHERE es_param_global_ti_item.cod_parametro      = "importa-cr-rpw"
          AND es_param_global_ti_item.cod_parametro_item = "Unix" NO-ERROR.
IF NOT AVAILABLE es_param_global_ti_item THEN
    FIND FIRST es_param_global_ti_item NO-LOCK
        WHERE es_param_global_ti_item.cod_parametro = "importa-cr-rpw" NO-ERROR.

IF NOT AVAILABLE es_param_global_ti_item THEN RETURN.

c-path = TRIM(es_param_global_ti_item.val_1).
IF c-path = "" THEN RETURN.

/* ---------- Coleta os arquivos consolida_arquivo*.csv da pasta ---------- */
INPUT FROM OS-DIR(c-path) NO-ECHO.
REPEAT:
    IMPORT c-nome c-full c-attr.
    IF c-nome = "." OR c-nome = ".." THEN NEXT.
    IF INDEX(c-attr, "F") = 0 THEN NEXT.            /* somente arquivos */
    IF INDEX(c-nome, "consolida_arquivo") = 0 THEN NEXT.
    CREATE tt-arq.
    ASSIGN tt-arq.nome = c-nome
           tt-arq.full = c-full.
END.
INPUT CLOSE.

/* ---------- Processa cada arquivo ---------- */
FOR EACH tt-arq:

    oInput   = NEW JsonObject().
    aLote    = NEW JsonArray().
    i-linhas = 0.

    /* Le as linhas do CSV e monta o lote (delimitador ";") */
    INPUT FROM VALUE(tt-arq.full) NO-ECHO.
    REPEAT:
        IMPORT UNFORMATTED c-linha.
        IF TRIM(c-linha) = "" THEN NEXT.
        aLinha = NEW JsonArray().
        DO i-col = 1 TO NUM-ENTRIES(c-linha, ";"):
            aLinha:Add(ENTRY(i-col, c-linha, ";")).
        END.
        aLote:Add(aLinha).
        i-linhas = i-linhas + 1.
    END.
    INPUT CLOSE.

    /* Arquivo vazio: remove e segue */
    IF i-linhas = 0 THEN DO:
        OS-DELETE VALUE(tt-arq.full).
        NEXT.
    END.

    oInput:Add("lote", aLote).
    oInput:Add("codUsuario", c-usuario).

    /* Reutiliza a mesma logica da importacao em tela */
    RUN esp/api/v1/importaTituloAcrRules.p PERSISTENT SET h-bo NO-ERROR.
    IF NOT VALID-HANDLE(h-bo) THEN NEXT.

    RUN pi-importar-lote IN h-bo (INPUT oInput, OUTPUT lc-resp, OUTPUT i-st) NO-ERROR.

    IF VALID-HANDLE(h-bo) THEN DELETE PROCEDURE h-bo NO-ERROR.

    /* Importou com sucesso -> marca e exclui o arquivo da pasta */
    IF i-st = 200 AND NOT ERROR-STATUS:ERROR THEN DO:
        ASSIGN l-imp = YES.
        OS-DELETE VALUE(tt-arq.full).
    END.
END.

/* ---------- Processa os documentos importados (liquida / acerto de valor a
   menor / gera AD), exatamente como o "Processar Todos Pendentes" da tela.
   Reutiliza a mesma BO pi-processar. ---------- */
IF l-imp THEN DO:
    RUN esp/api/v1/importaTituloAcrRules.p PERSISTENT SET h-bo NO-ERROR.
    IF VALID-HANDLE(h-bo) THEN DO:
        oInput = NEW JsonObject().
        oInput:Add("processarTodos", TRUE).
        oInput:Add("codUsuario", c-usuario).
        RUN pi-processar IN h-bo (INPUT oInput, OUTPUT lc-resp, OUTPUT i-st) NO-ERROR.
        DELETE PROCEDURE h-bo NO-ERROR.
        ASSIGN h-bo = ?.
    END.
END.

CATCH oE AS Progress.Lang.Error:
    IF VALID-HANDLE(h-bo) THEN DELETE PROCEDURE h-bo NO-ERROR.
END CATCH.

FINALLY:
    IF VALID-HANDLE(h-bo) THEN DELETE PROCEDURE h-bo NO-ERROR.
END FINALLY.

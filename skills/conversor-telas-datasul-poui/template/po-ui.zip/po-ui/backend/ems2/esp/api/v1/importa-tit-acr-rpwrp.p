/******************************************************************************
** Programa  : processarTitulosAcr.p
** Tipo      : Programa batch / editor
** Objetivo  : Processa todos os titulos com ind_sit_importacao = "Pendente"
**             em es-tit-acr-importa-tit, liquidando ou criando AD conforme
**             a logica da BO importaTituloAcr-bo.p (pi-processar).
**
** Fluxo:
**   1. Reseta "Erro" para "Pendente"
**   2. Para cada "Pendente":
**      - Se cod_tit_acr = "" -> tenta matching via es_tit_acr_abrt
**        - Se achou: preenche chaves e vai para liquidacao
**        - Se NAO achou: r-tit-acr = ? -> cria AD
**      - Se cod_tit_acr <> "" -> busca em tit_acr
**        - Se achou e valor bate: vai para liquidacao
**        - Se diverge ou nao acha: ERRO (NEXT)
**   3. Chama API de liquidacao (acr901zf.p)
**   4. Atualiza es-tit-acr-importa-tit com resultado
******************************************************************************/

BLOCK-LEVEL ON ERROR UNDO, THROW.

USING Progress.Json.ObjectModel.JsonObject.
USING Progress.Json.ObjectModel.JsonArray.

{utp/ut-buffers-ems2.i}
{acr/esacr086rp.i}
{acr/esacr054.i}

/* ----------------------------------------------------------------------- */
/*  Variaveis globais                                                       */
/* ----------------------------------------------------------------------- */
DEFINE VARIABLE c-usuario       AS CHARACTER NO-UNDO.
DEFINE VARIABLE c-cod-refer     AS CHARACTER NO-UNDO.
DEFINE VARIABLE c-cod-ref-geral AS CHARACTER NO-UNDO.
DEFINE VARIABLE c-msg-lote      AS CHARACTER NO-UNDO.
DEFINE VARIABLE h-acr901zf      AS HANDLE    NO-UNDO.
DEFINE VARIABLE h-acr900zi      AS HANDLE    NO-UNDO.
DEFINE VARIABLE v-des-dat       AS CHARACTER NO-UNDO.
DEFINE VARIABLE v-num-seg       AS INTEGER   NO-UNDO.
DEFINE VARIABLE v-log-refer-uni AS LOGICAL   NO-UNDO.
DEFINE VARIABLE i-num-seq-liq   AS INTEGER   NO-UNDO INITIAL 0.
DEFINE VARIABLE i-ref-seq       AS INTEGER   NO-UNDO INITIAL 0.
DEFINE VARIABLE i-ref-ad        AS INTEGER   NO-UNDO INITIAL 0.
DEFINE VARIABLE i-proc          AS INTEGER   NO-UNDO INITIAL 0.
DEFINE VARIABLE i-erro          AS INTEGER   NO-UNDO INITIAL 0.
DEFINE VARIABLE d-val-liq       AS DECIMAL   NO-UNDO.

DEFINE VARIABLE cRaizCnpj    AS CHARACTER NO-UNDO.
DEFINE VARIABLE l-encontrou  AS LOGICAL   NO-UNDO.
DEFINE VARIABLE l-divergente AS LOGICAL   NO-UNDO.
DEFINE VARIABLE r-tit-acr    AS ROWID     NO-UNDO.

DEFINE VARIABLE c-titulo-ad   AS CHARACTER NO-UNDO.
DEFINE VARIABLE c-refer-ad    AS CHARACTER NO-UNDO.
DEFINE VARIABLE c-estab-ad    AS CHARACTER NO-UNDO.
DEFINE VARIABLE c-portador-ad AS CHARACTER NO-UNDO.
DEFINE VARIABLE c-cart-ad     AS CHARACTER NO-UNDO.
DEFINE VARIABLE d-vencto-ad   AS DATE      NO-UNDO.
DEFINE VARIABLE c-erro-api-ad AS CHARACTER NO-UNDO.
DEFINE VARIABLE v-log-ad-uni  AS LOGICAL   NO-UNDO.

DEFINE VARIABLE p_dat_refer AS DATE      NO-UNDO.
DEFINE VARIABLE p_cod_refer AS CHARACTER NO-UNDO.
DEFINE VARIABLE v_des_dat   AS CHARACTER NO-UNDO.
DEFINE VARIABLE v_num_aux   AS INTEGER   NO-UNDO.
DEFINE VARIABLE v_num_cont  AS INTEGER   NO-UNDO.
DEFINE VARIABLE vi-seq      AS INTEGER   NO-UNDO INITIAL 0.

DEFINE VARIABLE c-diag      AS CHARACTER NO-UNDO.
DEFINE VARIABLE c-ret-val   AS CHARACTER NO-UNDO.
DEFINE VARIABLE i-cnt-lote  AS INTEGER   NO-UNDO.
DEFINE VARIABLE i-cnt-item  AS INTEGER   NO-UNDO.
DEFINE VARIABLE i-cnt-ctbl  AS INTEGER   NO-UNDO.

DEFINE VARIABLE h-acomp AS HANDLE NO-UNDO.

/* Temp-table de log interno */
DEFINE TEMP-TABLE tt-proc-item NO-UNDO
    FIELD cgc             AS CHARACTER
    FIELD cod_estab       AS CHARACTER
    FIELD cod_espec_docto AS CHARACTER
    FIELD cod_ser_docto   AS CHARACTER
    FIELD cod_tit_acr     AS CHARACTER
    FIELD cod_parcela     AS CHARACTER
    FIELD cod_refer       AS CHARACTER
    FIELD status-result   AS CHARACTER
    FIELD mensagem        AS CHARACTER
    FIELD r-importa       AS ROWID.

/* ----------------------------------------------------------------------- */
/*  Inicializa                                                              */
/* ----------------------------------------------------------------------- */
Run utp/ut-acomp.p persistent set h-acomp.
Run pi-inicializar In h-acomp (Input "Processando Titulos ACR").
Run pi-seta-tipo   In h-acomp (Input 6).

ASSIGN c-usuario = USERID("DICT") NO-ERROR.
IF c-usuario = "" OR c-usuario = ? THEN
    ASSIGN c-usuario = USERID(LDBNAME(1)) NO-ERROR.

/* ----------------------------------------------------------------------- */
/*  PASSO 1: Reseta "Erro" para "Pendente"                                 */
/* ----------------------------------------------------------------------- */
FOR EACH es-tit-acr-importa-tit NO-LOCK
    WHERE es-tit-acr-importa-tit.ind_sit_importacao = "Erro":

    FIND CURRENT es-tit-acr-importa-tit EXCLUSIVE-LOCK NO-WAIT NO-ERROR.
    IF LOCKED es-tit-acr-importa-tit THEN NEXT.

    ASSIGN es-tit-acr-importa-tit.ind_sit_importacao = "Pendente"
           es-tit-acr-importa-tit.des_mensagem_erro  = "".
END.

/* ----------------------------------------------------------------------- */
/*  PASSO 2: Processa cada "Pendente"                                      */
/* ----------------------------------------------------------------------- */
FOR EACH es-tit-acr-importa-tit NO-LOCK
    WHERE es-tit-acr-importa-tit.ind_sit_importacao = "Pendente":

    RUN pi-acompanhar IN h-acomp
        ("Processando CNPJ: " + STRING(es-tit-acr-importa-tit.cgc)).

    FIND CURRENT es-tit-acr-importa-tit EXCLUSIVE-LOCK NO-WAIT NO-ERROR.
    IF LOCKED es-tit-acr-importa-tit THEN DO:
        CREATE tt-proc-item.
        ASSIGN tt-proc-item.cgc           = es-tit-acr-importa-tit.cgc
               tt-proc-item.status-result = "ERRO"
               tt-proc-item.mensagem      = "Registro em uso por outro usuario. Tente novamente.".
        i-erro = i-erro + 1.
        NEXT.
    END.

    ASSIGN cRaizCnpj    = SUBSTRING(es-tit-acr-importa-tit.cgc, 1, 8)
           l-encontrou  = FALSE
           l-divergente = FALSE
           r-tit-acr    = ?.

    /* Cria entrada no log */
    CREATE tt-proc-item.
    ASSIGN
        tt-proc-item.cgc             = es-tit-acr-importa-tit.cgc
        tt-proc-item.cod_estab       = es-tit-acr-importa-tit.cod_estab
        tt-proc-item.cod_espec_docto = es-tit-acr-importa-tit.cod_espec_docto
        tt-proc-item.cod_ser_docto   = es-tit-acr-importa-tit.cod_ser_docto
        tt-proc-item.cod_tit_acr     = es-tit-acr-importa-tit.cod_tit_acr
        tt-proc-item.cod_parcela     = es-tit-acr-importa-tit.cod_parcela
        tt-proc-item.status-result   = "OK"
        tt-proc-item.r-importa       = ROWID(es-tit-acr-importa-tit).

    /* ---------------------------------------------------------------
       Bloco A: sem cod_tit_acr � tenta matching via es_tit_acr_abrt
       --------------------------------------------------------------- */
    IF es-tit-acr-importa-tit.cod_tit_acr = "" THEN
    DO:
        /* 1a tentativa: chave exata + valor */
        FIND FIRST es_tit_acr_abrt WHERE
            es_tit_acr_abrt.cod_estab       = es-tit-acr-importa-tit.cod_estab       AND
            es_tit_acr_abrt.cod_espec_docto = es-tit-acr-importa-tit.cod_espec_docto AND
            es_tit_acr_abrt.cod_ser_docto   = es-tit-acr-importa-tit.cod_ser_docto   AND
            es_tit_acr_abrt.cod_tit_acr     = es-tit-acr-importa-tit.cod_tit_acr     AND
            es_tit_acr_abrt.cod_parcela     = es-tit-acr-importa-tit.cod_parcela     AND
            es_tit_acr_abrt.val_pendente    = es-tit-acr-importa-tit.val_recebido
            EXCLUSIVE-LOCK NO-ERROR.

        /* 2a tentativa: CNPJ exato + valor */
        IF NOT AVAIL es_tit_acr_abrt THEN
            FIND FIRST es_tit_acr_abrt WHERE
                es_tit_acr_abrt.cgc          = es-tit-acr-importa-tit.cgc        AND
                es_tit_acr_abrt.val_pendente = es-tit-acr-importa-tit.val_recebido
                EXCLUSIVE-LOCK NO-ERROR.

        /* 3a tentativa: raiz CNPJ + valor */
        IF NOT AVAIL es_tit_acr_abrt THEN
            FIND FIRST es_tit_acr_abrt WHERE
                es_tit_acr_abrt.cgc-8char    = cRaizCnpj                          AND
                es_tit_acr_abrt.val_pendente = es-tit-acr-importa-tit.val_recebido
                EXCLUSIVE-LOCK NO-ERROR.

        IF AVAIL es_tit_acr_abrt THEN
        DO:
            ASSIGN
                es-tit-acr-importa-tit.cod_estab       = es_tit_acr_abrt.cod_estab
                es-tit-acr-importa-tit.cod_espec_docto = es_tit_acr_abrt.cod_espec_docto
                es-tit-acr-importa-tit.cod_ser_docto   = es_tit_acr_abrt.cod_ser_docto
                es-tit-acr-importa-tit.cod_tit_acr     = es_tit_acr_abrt.cod_tit_acr
                es-tit-acr-importa-tit.cod_parcela     = es_tit_acr_abrt.cod_parcela

                tt-proc-item.cod_estab                 = es_tit_acr_abrt.cod_estab
                tt-proc-item.cod_espec_docto           = es_tit_acr_abrt.cod_espec_docto
                tt-proc-item.cod_ser_docto             = es_tit_acr_abrt.cod_ser_docto
                tt-proc-item.cod_tit_acr               = es_tit_acr_abrt.cod_tit_acr
                tt-proc-item.cod_parcela               = es_tit_acr_abrt.cod_parcela.

            DELETE es_tit_acr_abrt. /* remove para nao reutilizar */
        END.
        /* Se NAO achou no abrt: r-tit-acr permanece = ? -> cai no bloco AD */
    END.

    /* ---------------------------------------------------------------
       Bloco B: com cod_tit_acr � busca em tit_acr e valida valor
       --------------------------------------------------------------- */
    IF es-tit-acr-importa-tit.cod_tit_acr <> "" THEN
    DO:
        FIND FIRST tit_acr NO-LOCK
            WHERE tit_acr.cod_estab       = es-tit-acr-importa-tit.cod_estab
              AND tit_acr.cod_espec_docto = es-tit-acr-importa-tit.cod_espec_docto
              AND tit_acr.cod_ser_docto   = es-tit-acr-importa-tit.cod_ser_docto
              AND tit_acr.cod_tit_acr     = es-tit-acr-importa-tit.cod_tit_acr
              AND tit_acr.cod_parcela     = es-tit-acr-importa-tit.cod_parcela
            NO-ERROR.

        IF AVAIL tit_acr THEN
        DO:
            ASSIGN
                es-tit-acr-importa-tit.cod_portador  = tit_acr.cod_portador
                es-tit-acr-importa-tit.cod_cart_bcia = tit_acr.cod_cart_bcia
                es-tit-acr-importa-tit.dat_geracao   = TODAY
                r-tit-acr                            = ROWID(tit_acr).

            IF tit_acr.val_sdo_tit_acr = es-tit-acr-importa-tit.val_recebido THEN
                l-encontrou = TRUE.
            ELSE
                l-divergente = TRUE.

            IF l-divergente THEN
            DO:
                ASSIGN
                    tt-proc-item.status-result = "ERRO"
                    tt-proc-item.mensagem      =
                        "Titulo encontrado mas com valor divergente no CR. " + " | " +
                        "Valor apontado: "    + STRING(es-tit-acr-importa-tit.val_recebido) + " | " +
                        "Valor do CR: "       + STRING(tit_acr.val_sdo_tit_acr)             + " | " +
                        "Estabelecimento: "   + es-tit-acr-importa-tit.cod_estab            + " | " +
                        "Especie: "           + es-tit-acr-importa-tit.cod_espec_docto      + " | " +
                        "Serie: "             + es-tit-acr-importa-tit.cod_ser_docto        + " | " +
                        "Titulo: "            + es-tit-acr-importa-tit.cod_tit_acr          + " | " +
                        "Parcela: "           + es-tit-acr-importa-tit.cod_parcela          + " | " +
                        "Usuario: "           + c-usuario.
                NEXT.
            END.
        END.
        ELSE
        DO:
            ASSIGN
                tt-proc-item.status-result = "ERRO"
                tt-proc-item.mensagem      =
                    "Titulo nao encontrado no contas a receber. " + " | " +
                    "Estabelecimento: " + es-tit-acr-importa-tit.cod_estab       + " | " +
                    "Especie: "         + es-tit-acr-importa-tit.cod_espec_docto + " | " +
                    "Serie: "           + es-tit-acr-importa-tit.cod_ser_docto   + " | " +
                    "Titulo: "          + es-tit-acr-importa-tit.cod_tit_acr     + " | " +
                    "Parcela: "         + es-tit-acr-importa-tit.cod_parcela     + " | " +
                    "Usuario: "         + c-usuario.
            NEXT.
        END.
    END.

    /* ---------------------------------------------------------------
       Bloco C: nao achou titulo -> cria AD
       Condicao: r-tit-acr = ? AND NOT l-encontrou
       (so entra aqui se veio sem cod_tit_acr E nao achou no abrt)
       --------------------------------------------------------------- */
    IF r-tit-acr = ? AND NOT l-encontrou THEN
    DO:
        RUN pi-acompanhar IN h-acomp
            ("Criando AD para CNPJ: " + STRING(es-tit-acr-importa-tit.cgc)).

        /* Gera referencia unica para o lote do AD */
        ASSIGN v-log-ad-uni = NO.
        REPEAT WHILE v-log-ad-uni = NO:
            ASSIGN
                i-ref-ad   = i-ref-ad + 1
                v-des-dat  = STRING(TODAY, "99999999")
                v-num-seg  = TIME + i-ref-ad
                c-refer-ad = SUBSTRING(v-des-dat, 7, 2)
                           + SUBSTRING(v-des-dat, 3, 2)
                           + SUBSTRING(v-des-dat, 1, 2)
                           + STRING((v-num-seg MOD 9000) + 1000, "9999").

            ASSIGN v-log-ad-uni = YES.
            IF CAN-FIND(FIRST lote_impl_tit_acr NO-LOCK
                WHERE lote_impl_tit_acr.cod_estab = es-tit-acr-importa-tit.cod_estab
                  AND lote_impl_tit_acr.cod_refer = c-refer-ad) OR
               INDEX(c-cod-ref-geral, c-refer-ad) > 0 THEN
                ASSIGN v-log-ad-uni = NO.
            ELSE
                ASSIGN c-cod-ref-geral = c-cod-ref-geral + c-refer-ad + " ".
        END.

        /* Gera codigo unico para o titulo AD (AD + dd + mm + T + 3 letras random = 10 chars) */
        ASSIGN
            p_dat_refer = TODAY
            vi-seq      = 0
            v_des_dat   = STRING(p_dat_refer, "99999999")
            p_cod_refer = SUBSTRING(v_des_dat, 7, 2)
                        + SUBSTRING(v_des_dat, 3, 2)
                        + "T".

        DO v_num_cont = 1 TO 3:
            ASSIGN
                vi-seq      = vi-seq + 1
                v_num_aux   = (RANDOM(0, vi-seq + 9999) MOD 26) + 97
                p_cod_refer = p_cod_refer + CHR(v_num_aux).
        END.
        ASSIGN c-titulo-ad = "AD" + p_cod_refer.
        
        
        DEFINE VARIABLE i-tentativa  AS INT NO-UNDO.
        DEFINE VARIABLE c-letras     AS CHAR NO-UNDO.
        DEFINE VARIABLE i-letra      AS INT  NO-UNDO.
        DEFINE VARIABLE c-hora-str   AS CHARACTER NO-UNDO.
        DEFINE VARIABLE c-alfabet    AS CHARACTER NO-UNDO
            INITIAL "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ".
        
        
        DO i-tentativa = 1 TO 3 WHILE c-titulo-ad = "":
            ASSIGN c-letras = "".
            DO i-letra = 1 TO 3:
                ASSIGN c-letras = c-letras + SUBSTRING(c-alfabet, RANDOM(1, 52), 1).
            END.

            ASSIGN c-titulo-ad = c-hora-str + c-letras.

            IF CAN-FIND(FIRST tit_acr NO-LOCK
                WHERE tit_acr.cod_estab       = c-estab-ad
                  AND tit_acr.cod_espec_docto = "AD"
                  AND tit_acr.cod_ser_docto   = ""
                  AND tit_acr.cod_tit_acr     = c-titulo-ad
                  AND tit_acr.cod_parcela     = "01") THEN
                ASSIGN c-titulo-ad = "". /* colisao � tenta novamente */
        END.

        IF c-titulo-ad = "" THEN
        DO:
            ASSIGN
                tt-proc-item.status-result = "ERRO"
                tt-proc-item.mensagem      = "Nao foi possivel gerar codigo unico para o AD apos 3 tentativas.".
            NEXT.
        END.

        /* Localiza emitente pelo CGC */
        
        
        
        
        
        
        
        
        
        

        /* Localiza emitente pelo CGC */
        FIND FIRST emitente NO-LOCK
             WHERE emitente.cgc = es-tit-acr-importa-tit.cgc NO-ERROR.
        IF NOT AVAIL emitente THEN
            FIND FIRST emitente NO-LOCK
                 WHERE emitente.cgc BEGINS cRaizCnpj NO-ERROR.

        IF NOT AVAIL emitente THEN
        DO:
            ASSIGN
                tt-proc-item.status-result = "ERRO"
                tt-proc-item.mensagem      = "Cliente CNPJ " + es-tit-acr-importa-tit.cgc + " nao encontrado para criacao de AD.".
            NEXT.
        END.

        /* Resolve dados do AD */
        ASSIGN
            c-estab-ad    = (IF es-tit-acr-importa-tit.cod_estab     <> "" THEN es-tit-acr-importa-tit.cod_estab     ELSE "001")
            c-portador-ad = (IF es-tit-acr-importa-tit.cod_portador  <> "" THEN es-tit-acr-importa-tit.cod_portador  ELSE "341")
            c-cart-ad     = (IF es-tit-acr-importa-tit.cod_cart_bcia <> "" THEN es-tit-acr-importa-tit.cod_cart_bcia ELSE "SIM")
            d-vencto-ad   = (IF es-tit-acr-importa-tit.dat_geracao   <> ?  THEN es-tit-acr-importa-tit.dat_geracao   ELSE TODAY).

        /* Limpa temps da API de implantacao */
        EMPTY TEMP-TABLE tt_integr_acr_lote_impl.
        EMPTY TEMP-TABLE tt_integr_acr_item_lote_impl_9.
        EMPTY TEMP-TABLE tt_integr_acr_repres_comis_2.
        EMPTY TEMP-TABLE tt_integr_acr_aprop_relacto_2b.
        EMPTY TEMP-TABLE tt_params_generic_api.
        EMPTY TEMP-TABLE tt_integr_acr_relacto_pend_aux.
        EMPTY TEMP-TABLE tt_log_erros_atualiz.
        EMPTY TEMP-TABLE tt_integr_acr_aprop_ctbl_pend.

        /* Monta cabecalho do lote */
        CREATE tt_integr_acr_lote_impl.
        ASSIGN
            tt_integr_acr_lote_impl.tta_cod_estab           = c-estab-ad
            tt_integr_acr_lote_impl.tta_cod_refer           = c-refer-ad
            tt_integr_acr_lote_impl.tta_dat_transacao       = TODAY
            tt_integr_acr_lote_impl.tta_ind_tip_espec_docto = ""
            tt_integr_acr_lote_impl.tta_ind_tip_cobr_acr    = "Normal".

        /* Monta item do AD */
        ASSIGN i-num-seq-liq = i-num-seq-liq + 10.

        CREATE tt_integr_acr_item_lote_impl_9.
        ASSIGN
            tt_integr_acr_item_lote_impl_9.ttv_rec_lote_impl_tit_acr      = RECID(tt_integr_acr_lote_impl)
            tt_integr_acr_item_lote_impl_9.ttv_rec_item_lote_impl_tit_acr = RECID(tt_integr_acr_item_lote_impl_9)
            tt_integr_acr_item_lote_impl_9.tta_num_seq_refer               = i-num-seq-liq
            tt_integr_acr_item_lote_impl_9.tta_cdn_cliente                 = emitente.cod-emitente
            tt_integr_acr_item_lote_impl_9.tta_cod_espec_docto             = "AD"
            tt_integr_acr_item_lote_impl_9.tta_cod_ser_docto               = ""
            tt_integr_acr_item_lote_impl_9.tta_cod_tit_acr                 = c-titulo-ad
            tt_integr_acr_item_lote_impl_9.tta_cod_tit_acr_bco             = ""
            tt_integr_acr_item_lote_impl_9.tta_cod_parcela                 = "01"
            tt_integr_acr_item_lote_impl_9.tta_cod_portador                = c-portador-ad
            tt_integr_acr_item_lote_impl_9.tta_cod_cart_bcia               = c-cart-ad
            tt_integr_acr_item_lote_impl_9.tta_cod_indic_econ              = "Real"
            tt_integr_acr_item_lote_impl_9.tta_dat_vencto_tit_acr          = d-vencto-ad
            tt_integr_acr_item_lote_impl_9.tta_dat_emis_docto              = TODAY
            tt_integr_acr_item_lote_impl_9.tta_val_tit_acr                 = es-tit-acr-importa-tit.val_recebido
            tt_integr_acr_item_lote_impl_9.tta_des_text_histor             = "efetivadas via automacao"
            tt_integr_acr_item_lote_impl_9.tta_ind_tip_espec_docto         = "Antecipacao"
            tt_integr_acr_item_lote_impl_9.tta_ind_sit_tit_acr             = "Normal"
            tt_integr_acr_item_lote_impl_9.tta_ind_sit_bcia_tit_acr        = "1"
            tt_integr_acr_item_lote_impl_9.tta_ind_ender_cobr              = "1"
            tt_integr_acr_item_lote_impl_9.tta_val_cotac_indic_econ        = 1.

        /* Dados contabeis pendentes (obrigatorio para AD) */
        CREATE tt_integr_acr_aprop_ctbl_pend.
        ASSIGN
            tt_integr_acr_aprop_ctbl_pend.ttv_rec_item_lote_impl_tit_acr = RECID(tt_integr_acr_item_lote_impl_9)
            tt_integr_acr_aprop_ctbl_pend.tta_cod_unid_negoc             = "99"
            tt_integr_acr_aprop_ctbl_pend.tta_val_aprop_ctbl             = es-tit-acr-importa-tit.val_recebido.

        /* Diagnostico pre-API */
        ASSIGN i-cnt-lote = 0  i-cnt-item = 0  i-cnt-ctbl = 0.
        FOR EACH tt_integr_acr_lote_impl        NO-LOCK: ASSIGN i-cnt-lote = i-cnt-lote + 1. END.
        FOR EACH tt_integr_acr_item_lote_impl_9 NO-LOCK: ASSIGN i-cnt-item = i-cnt-item + 1. END.
        FOR EACH tt_integr_acr_aprop_ctbl_pend  NO-LOCK: ASSIGN i-cnt-ctbl = i-cnt-ctbl + 1. END.

        ASSIGN c-diag = "DIAG PRE-API: lotes=" + STRING(i-cnt-lote)
                      + " items=" + STRING(i-cnt-item)
                      + " ctbl="  + STRING(i-cnt-ctbl)
                      + " cliente=" + STRING(emitente.cod-emitente)
                      + " estab="   + c-estab-ad
                      + " titulo="  + c-titulo-ad
                      + " valor="   + STRING(es-tit-acr-importa-tit.val_recebido).

        /* Chama API de implantacao */
        ASSIGN c-erro-api-ad = "".
        IF NOT VALID-HANDLE(h-acr900zi) THEN
            RUN prgfin/acr/acr900zi.py PERSISTENT SET h-acr900zi NO-ERROR.

        IF ERROR-STATUS:ERROR OR NOT VALID-HANDLE(h-acr900zi) THEN
        DO:
            ASSIGN
                tt-proc-item.status-result = "ERRO"
                tt-proc-item.mensagem      = "Falha ao carregar acr900zi.py: "
                                           + (IF ERROR-STATUS:NUM-MESSAGES > 0 THEN ERROR-STATUS:GET-MESSAGE(1) ELSE "Handle invalido").
            EMPTY TEMP-TABLE tt_integr_acr_lote_impl.
            EMPTY TEMP-TABLE tt_integr_acr_item_lote_impl_9.
            EMPTY TEMP-TABLE tt_log_erros_atualiz.
            NEXT.
        END.

        ASSIGN c-diag = c-diag + " | HANDLE_OK".

        RUN pi_main_code_integr_acr_new_13 IN h-acr900zi
            (INPUT  11,
             INPUT  "CONS-PLANILHAS",
             INPUT  YES,
             INPUT  YES,
             INPUT  TABLE tt_integr_acr_repres_comis_2,
             INPUT-OUTPUT TABLE tt_integr_acr_item_lote_impl_9,
             INPUT  TABLE tt_integr_acr_aprop_relacto_2b,
             INPUT-OUTPUT TABLE tt_params_generic_api,
             INPUT  TABLE tt_integr_acr_relacto_pend_aux) NO-ERROR.

        ASSIGN c-ret-val = RETURN-VALUE NO-ERROR.
        ASSIGN c-diag = c-diag + " | RET=" + (IF c-ret-val <> "" AND c-ret-val <> ? THEN c-ret-val ELSE "vazio").

        IF VALID-HANDLE(h-acr900zi) THEN DO:
            DELETE PROCEDURE h-acr900zi.
            ASSIGN h-acr900zi = ?.
        END.

        /* Verifica erros de negocio da API */
        IF CAN-FIND(FIRST tt_log_erros_atualiz) THEN
        DO:
            ASSIGN c-erro-api-ad = "".
            FOR EACH tt_log_erros_atualiz NO-LOCK:
                ASSIGN c-erro-api-ad = c-erro-api-ad
                                     + STRING(tt_log_erros_atualiz.ttv_num_mensagem)
                                     + " - " + TRIM(tt_log_erros_atualiz.ttv_des_msg_erro) + " | ".
            END.
            ASSIGN
                tt-proc-item.status-result = "ERRO"
                tt-proc-item.mensagem      = "Falha ao criar AD: " + c-erro-api-ad + " || " + c-diag.
            EMPTY TEMP-TABLE tt_integr_acr_lote_impl.
            EMPTY TEMP-TABLE tt_integr_acr_item_lote_impl_9.
            EMPTY TEMP-TABLE tt_log_erros_atualiz.
            NEXT.
        END.

        /* AD criado com sucesso: atualiza chaves na importacao */
        ASSIGN
            es-tit-acr-importa-tit.cod_estab       = c-estab-ad
            es-tit-acr-importa-tit.cod_espec_docto = "AD"
            es-tit-acr-importa-tit.cod_ser_docto   = ""
            es-tit-acr-importa-tit.cod_tit_acr     = c-titulo-ad
            es-tit-acr-importa-tit.cod_parcela     = "01"
            es-tit-acr-importa-tit.cod_portador    = "341"

            tt-proc-item.cod_estab       = c-estab-ad
            tt-proc-item.cod_espec_docto = "AD"
            tt-proc-item.cod_ser_docto   = ""
            tt-proc-item.cod_tit_acr     = c-titulo-ad
            tt-proc-item.cod_parcela     = "01".

        FIND FIRST estabelec WHERE estabelec.cod-estabel = c-estab-ad NO-LOCK NO-ERROR.
        IF AVAIL estabelec AND es-tit-acr-importa-tit.cod_empresa = "" THEN
            ASSIGN es-tit-acr-importa-tit.cod_empresa = estabelec.ep-codigo.

        EMPTY TEMP-TABLE tt_integr_acr_lote_impl.
        EMPTY TEMP-TABLE tt_integr_acr_item_lote_impl_9.
        EMPTY TEMP-TABLE tt_log_erros_atualiz.

        /* Reposiciona tit_acr no AD recem-criado para cair no fluxo de liquidacao */
        FIND FIRST tit_acr EXCLUSIVE-LOCK
             WHERE tit_acr.cod_estab       = c-estab-ad
               AND tit_acr.cod_espec_docto = "AD"
               AND tit_acr.cod_ser_docto   = ""
               AND tit_acr.cod_tit_acr     = c-titulo-ad
               AND tit_acr.cod_parcela     = "01" NO-ERROR.

        IF NOT AVAIL tit_acr THEN
        DO:
            ASSIGN
                tt-proc-item.status-result = "ERRO"
                tt-proc-item.mensagem      = "AD nao localizado em tit_acr apos criacao: " + c-titulo-ad + " || " + c-diag.
            NEXT.
        END.

        ASSIGN
            r-tit-acr                  = ROWID(tit_acr)
            l-encontrou                = TRUE
            l-divergente               = FALSE
            tt-proc-item.status-result = "OK"
            tt-proc-item.mensagem      = "AD Importado com sucesso".

        /* Grava situacao do AD e vai para proximo registro
           (liquidacao do AD e feita em etapa separada se necessario) */
        ASSIGN
            es-tit-acr-importa-tit.ind_sit_importacao = "Importado"
            es-tit-acr-importa-tit.des_mensagem_erro  = tt-proc-item.mensagem
            es-tit-acr-importa-tit.dat_processamento  = TODAY
            es-tit-acr-importa-tit.hra_processamento  = STRING(TIME, "HH:MM:SS").

        NEXT.
    END. /* Bloco C - AD */

    /* ---------------------------------------------------------------
       Validacao extra antes de montar lote de liquidacao
       --------------------------------------------------------------- */
    IF r-tit-acr <> ? AND NOT l-encontrou THEN NEXT.

    IF NOT AVAILABLE tit_acr THEN
    DO:
        ASSIGN
            tt-proc-item.status-result = "ERRO"
            tt-proc-item.mensagem      = "Titulo nao encontrado em tit_acr.".
        NEXT.
    END.

    /* Complementa campos caso tenham vindo vazios */
    IF AVAILABLE tit_acr AND (
        es-tit-acr-importa-tit.cod_estab       = "" OR
        es-tit-acr-importa-tit.cod_espec_docto = "" OR
        es-tit-acr-importa-tit.cod_ser_docto   = "" OR
        es-tit-acr-importa-tit.cod_tit_acr     = "" OR
        es-tit-acr-importa-tit.cod_parcela     = "" OR
        es-tit-acr-importa-tit.cod_portador    = "") THEN
    DO:
        ASSIGN
            es-tit-acr-importa-tit.cod_estab       = tit_acr.cod_estab
            es-tit-acr-importa-tit.cod_espec_docto = tit_acr.cod_espec_docto
            es-tit-acr-importa-tit.cod_ser_docto   = tit_acr.cod_ser_docto
            es-tit-acr-importa-tit.cod_tit_acr     = tit_acr.cod_tit_acr
            es-tit-acr-importa-tit.cod_parcela     = tit_acr.cod_parcela
            es-tit-acr-importa-tit.cod_portador    = tit_acr.cod_portador

            tt-proc-item.cod_estab       = tit_acr.cod_estab
            tt-proc-item.cod_espec_docto = tit_acr.cod_espec_docto
            tt-proc-item.cod_ser_docto   = tit_acr.cod_ser_docto
            tt-proc-item.cod_tit_acr     = tit_acr.cod_tit_acr
            tt-proc-item.cod_parcela     = tit_acr.cod_parcela.
    END.

    FIND FIRST estabelec WHERE estabelec.cod-estabel = tit_acr.cod_estab NO-LOCK NO-ERROR.
    IF AVAIL estabelec AND es-tit-acr-importa-tit.cod_empresa = "" THEN
        ASSIGN es-tit-acr-importa-tit.cod_empresa = estabelec.ep-codigo.

    /* Validacoes de negocio */
    IF NOT tit_acr.log_sdo_tit_acr OR tit_acr.val_sdo_tit_acr <= 0 THEN
    DO:
        ASSIGN
            tt-proc-item.status-result = "ERRO"
            tt-proc-item.mensagem      = "Titulo sem saldo em aberto. Saldo: "
                                       + TRIM(STRING(tit_acr.val_sdo_tit_acr, ">>>,>>9.99")).
        NEXT.
    END.

    IF es-tit-acr-importa-tit.val_recebido <= 0 THEN
    DO:
        ASSIGN
            tt-proc-item.status-result = "ERRO"
            tt-proc-item.mensagem      = "Valor recebido invalido: "
                                       + TRIM(STRING(es-tit-acr-importa-tit.val_recebido, ">>>,>>9.99")).
        NEXT.
    END.

    FIND FIRST usuar_financ_estab_acr NO-LOCK
         WHERE usuar_financ_estab_acr.cod_usuario = c-usuario
           AND usuar_financ_estab_acr.cod_estab   = tit_acr.cod_estab NO-ERROR.

    IF NOT AVAIL usuar_financ_estab_acr THEN
    DO:
        ASSIGN
            tt-proc-item.status-result = "ERRO"
            tt-proc-item.mensagem      = "Usuario " + c-usuario + " sem cadastro financeiro no estab: " + tit_acr.cod_estab.
        NEXT.
    END.

    IF usuar_financ_estab_acr.log_habilit_liquidac_acr = NO THEN
    DO:
        ASSIGN
            tt-proc-item.status-result = "ERRO"
            tt-proc-item.mensagem      = "Usuario " + c-usuario + " sem permissao para liquidar titulo no estab: " + tit_acr.cod_estab.
        NEXT.
    END.

    /* ---------------------------------------------------------------
       Monta lote de liquidacao (Acao 1 + Acao 2)
       --------------------------------------------------------------- */
    FIND CURRENT tit_acr EXCLUSIVE-LOCK NO-ERROR.

    RUN pi-acompanhar IN h-acomp
        ("Liquidando titulo: " + STRING(tit_acr.cod_tit_acr) +
         " CNPJ: " + STRING(es-tit-acr-importa-tit.cgc)).

    /* Acao 1: cria ou reusa lote por estabelecimento */
    FIND FIRST tt_integr_acr_liquidac_lote EXCLUSIVE-LOCK
        WHERE tt_integr_acr_liquidac_lote.tta_cod_estab_refer = tit_acr.cod_estab NO-ERROR.

    IF NOT AVAILABLE tt_integr_acr_liquidac_lote THEN
    DO:
        ASSIGN v-log-refer-uni = NO.
        REPEAT WHILE v-log-refer-uni = NO:
            ASSIGN
                i-ref-seq   = i-ref-seq + 1
                v-des-dat   = STRING(TODAY, "99999999")
                v-num-seg   = TIME + i-ref-seq
                c-cod-refer = SUBSTRING(v-des-dat, 7, 2)
                            + SUBSTRING(v-des-dat, 3, 2)
                            + SUBSTRING(v-des-dat, 1, 2)
                            + STRING((v-num-seg MOD 9000) + 1000, "9999").

            ASSIGN v-log-refer-uni = YES.
            IF CAN-FIND(FIRST lote_impl_tit_acr NO-LOCK
                    WHERE lote_impl_tit_acr.cod_estab = tit_acr.cod_estab
                      AND lote_impl_tit_acr.cod_refer = c-cod-refer) OR
               CAN-FIND(FIRST lote_liquidac_acr NO-LOCK
                    WHERE lote_liquidac_acr.cod_estab_refer = tit_acr.cod_estab
                      AND lote_liquidac_acr.cod_refer       = c-cod-refer) OR
               CAN-FIND(FIRST movto_tit_acr NO-LOCK
                    WHERE movto_tit_acr.cod_estab = tit_acr.cod_estab
                      AND movto_tit_acr.cod_refer = c-cod-refer) OR
               CAN-FIND(FIRST his_movto_tit_acr_histor NO-LOCK
                    WHERE his_movto_tit_acr_histor.cod_estab = tit_acr.cod_estab
                      AND his_movto_tit_acr_histor.cod_refer = c-cod-refer) OR
               INDEX(c-cod-ref-geral, c-cod-refer) > 0 THEN
                ASSIGN v-log-refer-uni = NO.
            ELSE
                ASSIGN c-cod-ref-geral = c-cod-ref-geral + c-cod-refer + " ".
        END.

        FIND FIRST estabelecimento NO-LOCK
             WHERE estabelecimento.cod_estab = tit_acr.cod_estab NO-ERROR.

        CREATE tt_integr_acr_liquidac_lote.
        ASSIGN
            tt_integr_acr_liquidac_lote.tta_cod_empresa             = (IF AVAILABLE estabelecimento THEN estabelecimento.cod_empresa ELSE tit_acr.cod_empresa)
            tt_integr_acr_liquidac_lote.tta_cod_estab_refer         = tit_acr.cod_estab
            tt_integr_acr_liquidac_lote.tta_cod_refer               = c-cod-refer
            tt_integr_acr_liquidac_lote.tta_cod_usuario             = c-usuario
            tt_integr_acr_liquidac_lote.tta_dat_gerac_lote_liquidac = TODAY
            tt_integr_acr_liquidac_lote.tta_ind_tip_liquidac_acr    = "lote"
            tt_integr_acr_liquidac_lote.ttv_log_atualiz_refer       = YES
            tt_integr_acr_liquidac_lote.ttv_rec_lote_liquidac_acr   = RECID(tt_integr_acr_liquidac_lote)
            tt_integr_acr_liquidac_lote.ttv_log_gera_lote_parcial   = YES.
    END.

    /* Acao 2: cria item no lote */
    ASSIGN
        i-num-seq-liq          = i-num-seq-liq + 10
        d-val-liq              = MINIMUM(es-tit-acr-importa-tit.val_recebido, tit_acr.val_sdo_tit_acr)
        tt-proc-item.cod_refer = tt_integr_acr_liquidac_lote.tta_cod_refer.

    CREATE tt_integr_acr_liq_item_lote_3.
    ASSIGN
        tt_integr_acr_liq_item_lote_3.tta_cod_empresa                = tit_acr.cod_empresa
        tt_integr_acr_liq_item_lote_3.tta_cod_estab                  = tit_acr.cod_estab
        tt_integr_acr_liq_item_lote_3.tta_cod_espec_docto            = tit_acr.cod_espec_docto
        tt_integr_acr_liq_item_lote_3.tta_cod_ser_docto              = tit_acr.cod_ser_docto
        tt_integr_acr_liq_item_lote_3.tta_num_seq_refer              = i-num-seq-liq
        tt_integr_acr_liq_item_lote_3.tta_cod_tit_acr                = tit_acr.cod_tit_acr
        tt_integr_acr_liq_item_lote_3.tta_cod_parcela                = tit_acr.cod_parcela
        tt_integr_acr_liq_item_lote_3.tta_cdn_cliente                = tit_acr.cdn_cliente
        tt_integr_acr_liq_item_lote_3.tta_cod_portador               = es-tit-acr-importa-tit.cod_portador
        tt_integr_acr_liq_item_lote_3.tta_cod_cart_bcia              = tit_acr.cod_cart_bcia
        tt_integr_acr_liq_item_lote_3.tta_cod_indic_econ             = tit_acr.cod_indic_econ
        tt_integr_acr_liq_item_lote_3.tta_dat_cr_liquidac_tit_acr    = TODAY
        tt_integr_acr_liq_item_lote_3.tta_dat_cr_liquidac_calc       = TODAY
        tt_integr_acr_liq_item_lote_3.tta_dat_liquidac_tit_acr       = TODAY
        tt_integr_acr_liq_item_lote_3.tta_val_liquidac_tit_acr       = d-val-liq
        tt_integr_acr_liq_item_lote_3.tta_val_desc_tit_acr           = es-tit-acr-importa-tit.val_desconto
        tt_integr_acr_liq_item_lote_3.tta_val_abat_tit_acr           = es-tit-acr-importa-tit.val_abatimento
        tt_integr_acr_liq_item_lote_3.tta_val_despes_bcia            = 0
        tt_integr_acr_liq_item_lote_3.tta_val_multa_tit_acr          = 0
        tt_integr_acr_liq_item_lote_3.tta_val_juros                  = 0
        tt_integr_acr_liq_item_lote_3.tta_val_cm_tit_acr             = tit_acr.val_cm_tit_acr
        tt_integr_acr_liq_item_lote_3.tta_ind_tip_item_liquidac_acr  = "pagamento"
        tt_integr_acr_liq_item_lote_3.ttv_rec_item_lote_liquidac_acr = RECID(tit_acr)
        tt_integr_acr_liq_item_lote_3.ttv_rec_lote_liquidac_acr      = RECID(tt_integr_acr_liquidac_lote)
        tt_integr_acr_liq_item_lote_3.tta_cod_livre_1                = tit_acr.cod_livre_1
        tt_integr_acr_liq_item_lote_3.tta_cod_livre_2                = tit_acr.cod_livre_2
        tt_integr_acr_liq_item_lote_3.tta_log_livre_1                = tit_acr.log_livre_1
        tt_integr_acr_liq_item_lote_3.tta_log_livre_2                = tit_acr.log_livre_2
        tt_integr_acr_liq_item_lote_3.tta_dat_livre_1                = tit_acr.dat_livre_1
        tt_integr_acr_liq_item_lote_3.tta_dat_livre_2                = tit_acr.dat_livre_2
        tt_integr_acr_liq_item_lote_3.tta_val_livre_1                = tit_acr.val_livre_1
        tt_integr_acr_liq_item_lote_3.tta_val_livre_2                = tit_acr.val_livre_2
        tt_integr_acr_liq_item_lote_3.tta_num_livre_1                = tit_acr.num_livre_1
        tt_integr_acr_liq_item_lote_3.tta_num_livre_2                = tit_acr.num_livre_2
        tt_integr_acr_liq_item_lote_3.tta_ind_tip_calc_juros         = tit_acr.ind_tip_calc_juros
        tt_integr_acr_liq_item_lote_3.tta_val_cotac_indic_econ       = 1
        tt_integr_acr_liq_item_lote_3.tta_des_text_histor            = "efetivadas via automacao".

END. /* FOR EACH es-tit-acr-importa-tit (Pendente) */


/* ----------------------------------------------------------------------- */
/*  PASSO 3: Acao 3 � chama API de liquidacao se ha itens montados         */
/* ----------------------------------------------------------------------- */
IF CAN-FIND(FIRST tt_integr_acr_liq_item_lote_3) THEN
DO:
    RUN prgfin/acr/acr901zf.p PERSISTENT SET h-acr901zf NO-ERROR.

    RUN pi_main_code_api_integr_acr_liquidac_6 IN h-acr901zf
        (INPUT  1,
         INPUT  TABLE tt_integr_acr_liquidac_lote,
         INPUT  TABLE tt_integr_acr_liq_item_lote_3,
         INPUT  TABLE tt_integr_acr_abat_antecip,
         INPUT  TABLE tt_integr_acr_abat_prev,
         INPUT  TABLE tt_integr_acr_cheq,
         INPUT  TABLE tt_integr_acr_liquidac_impto_2,
         INPUT  TABLE tt_integr_acr_rel_pend_cheq,
         INPUT  TABLE tt_integr_acr_liq_aprop_ctbl,
         INPUT  TABLE tt_integr_acr_liq_desp_rec,
         INPUT  TABLE tt_integr_acr_aprop_liq_antec,
         INPUT  "EMS2",
         OUTPUT TABLE tt_log_erros_import_liquidac,
         INPUT  TABLE tt_integr_cambio_ems5,
         INPUT  TABLE tt_params_generic_api).

    IF VALID-HANDLE(h-acr901zf) THEN DO:
        DELETE PROCEDURE h-acr901zf.
        ASSIGN h-acr901zf = ?.
    END.

    /* Propaga erros da API para tt-proc-item */
    FOR EACH tt_log_erros_import_liquidac NO-LOCK:

        /* Rejeicao de lote inteiro (tta_cod_tit_acr vazio) */
        IF (tt_log_erros_import_liquidac.tta_cod_tit_acr = "" OR
            tt_log_erros_import_liquidac.tta_cod_tit_acr = ?) THEN
        DO:
            ASSIGN c-msg-lote = STRING(tt_log_erros_import_liquidac.ttv_num_erro_log)
                              + " - " + TRIM(tt_log_erros_import_liquidac.ttv_des_msg_erro).
            FOR EACH tt-proc-item EXCLUSIVE-LOCK
                WHERE tt-proc-item.cod_refer     = tt_log_erros_import_liquidac.tta_cod_refer
                  AND tt-proc-item.status-result = "OK":
                ASSIGN
                    tt-proc-item.status-result = "ERRO"
                    tt-proc-item.mensagem      = c-msg-lote.
            END.
        END.
        ELSE
        DO:
            FIND FIRST tt-proc-item EXCLUSIVE-LOCK
                WHERE tt-proc-item.cod_estab       = tt_log_erros_import_liquidac.tta_cod_estab
                  AND tt-proc-item.cod_espec_docto = tt_log_erros_import_liquidac.tta_cod_espec_docto
                  AND tt-proc-item.cod_ser_docto   = tt_log_erros_import_liquidac.tta_cod_ser_docto
                  AND tt-proc-item.cod_tit_acr     = tt_log_erros_import_liquidac.tta_cod_tit_acr
                NO-ERROR.
            IF AVAILABLE tt-proc-item THEN
                ASSIGN
                    tt-proc-item.status-result = "ERRO"
                    tt-proc-item.mensagem      = STRING(tt_log_erros_import_liquidac.ttv_num_erro_log)
                                               + " - " + TRIM(tt_log_erros_import_liquidac.ttv_des_msg_erro).
        END.
    END. /* FOR EACH tt_log_erros_import_liquidac */

    /* Limpa temps da API */
    EMPTY TEMP-TABLE tt_integr_acr_liquidac_lote.
    EMPTY TEMP-TABLE tt_integr_acr_liq_item_lote_3.
    EMPTY TEMP-TABLE tt_integr_acr_abat_antecip.
    EMPTY TEMP-TABLE tt_integr_acr_abat_prev.
    EMPTY TEMP-TABLE tt_integr_acr_cheq.
    EMPTY TEMP-TABLE tt_integr_acr_liquidac_impto_2.
    EMPTY TEMP-TABLE tt_integr_acr_rel_pend_cheq.
    EMPTY TEMP-TABLE tt_integr_acr_liq_aprop_ctbl.
    EMPTY TEMP-TABLE tt_integr_acr_liq_desp_rec.
    EMPTY TEMP-TABLE tt_integr_acr_aprop_liq_antec.
    EMPTY TEMP-TABLE tt_log_erros_import_liquidac.
END. /* IF CAN-FIND */


/* ----------------------------------------------------------------------- */
/*  PASSO 4: Atualiza es-tit-acr-importa-tit com resultado                */
/* ----------------------------------------------------------------------- */
FOR EACH tt-proc-item NO-LOCK:

    FIND es-tit-acr-importa-tit EXCLUSIVE-LOCK
        WHERE ROWID(es-tit-acr-importa-tit) = tt-proc-item.r-importa
        NO-ERROR.

    IF AVAILABLE es-tit-acr-importa-tit THEN
        ASSIGN
            es-tit-acr-importa-tit.ind_sit_importacao = (IF tt-proc-item.status-result = "OK" THEN "Importado" ELSE "Erro")
            es-tit-acr-importa-tit.des_mensagem_erro  = tt-proc-item.mensagem
            es-tit-acr-importa-tit.dat_processamento  = TODAY
            es-tit-acr-importa-tit.hra_processamento  = STRING(TIME, "HH:MM:SS").

    IF tt-proc-item.status-result = "OK" THEN
        i-proc = i-proc + 1.
    ELSE
        i-erro = i-erro + 1.

END.

RUN pi-finalizar IN h-acomp.

EMPTY TEMP-TABLE tt-proc-item.

CATCH oE AS Progress.Lang.Error:
    MESSAGE "Erro inesperado: " oE:GetMessage(1)
        VIEW-AS ALERT-BOX ERROR.
    IF VALID-HANDLE(h-acr901zf) THEN DELETE PROCEDURE h-acr901zf.
    IF VALID-HANDLE(h-acr900zi) THEN DELETE PROCEDURE h-acr900zi.
END CATCH.

FINALLY:
    IF VALID-HANDLE(h-acr901zf) THEN DO:
        DELETE PROCEDURE h-acr901zf.
        ASSIGN h-acr901zf = ?.
    END.
    IF VALID-HANDLE(h-acr900zi) THEN DO:
        DELETE PROCEDURE h-acr900zi.
        ASSIGN h-acr900zi = ?.
    END.
    EMPTY TEMP-TABLE tt-proc-item.
END FINALLY.

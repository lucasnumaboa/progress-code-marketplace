/******************************************************************************
** Include  : importaTituloAcr-tt.i
** Objetivo : Definições de temp-tables compartilhadas entre o handler
**            e o Business Object da API importaTituloAcr.
******************************************************************************/

/* ─── Espelho de es-tit-acr-importa-tit para respostas da API ─── */
DEFINE TEMP-TABLE tt-tit-acr-import NO-UNDO
    FIELD cgc                 AS CHARACTER FORMAT "x(19)"
    FIELD cod_estab           AS CHARACTER FORMAT "x(5)"
    FIELD cod_espec_docto     AS CHARACTER FORMAT "x(3)"
    FIELD cod_ser_docto       AS CHARACTER FORMAT "x(3)"
    FIELD cod_tit_acr         AS CHARACTER FORMAT "x(10)"
    FIELD cod_parcela         AS CHARACTER FORMAT "x(2)"
    FIELD cod_empresa         AS CHARACTER FORMAT "x(3)"
    FIELD dat_geracao         AS DATE
    FIELD cod_portador        AS CHARACTER FORMAT "x(3)"
    FIELD cod_cart_bcia       AS CHARACTER FORMAT "x(3)"
    FIELD val_recebido        AS DECIMAL   DECIMALS 2
    FIELD val_juros           AS DECIMAL   DECIMALS 2
    FIELD val_multa           AS DECIMAL   DECIMALS 2
    FIELD val_desconto        AS DECIMAL   DECIMALS 2
    FIELD val_abatimento      AS DECIMAL   DECIMALS 2
    FIELD ind_sit_importacao  AS CHARACTER FORMAT "x(10)"
    FIELD des_mensagem_erro   AS CHARACTER FORMAT "x(500)"
    FIELD dat_importacao      AS DATE
    FIELD hra_importacao      AS CHARACTER FORMAT "x(8)"
    FIELD cod_arq_origem      AS CHARACTER FORMAT "x(200)"
    FIELD cod_usuario_import  AS CHARACTER FORMAT "x(12)"
    FIELD num_lote_importacao AS INTEGER
    FIELD dat_processamento   AS DATE
    FIELD hra_processamento   AS CHARACTER FORMAT "x(8)"
    FIELD cdn_cliente         AS INTEGER
    FIELD nome-emit           AS CHARACTER FORMAT "x(80)".
     

/* ─── Rastreamento de títulos em processamento (pi-processar) ─── */
DEFINE TEMP-TABLE tt-proc-item NO-UNDO
    FIELD cgc             AS CHARACTER
    FIELD cod_estab       AS CHARACTER
    FIELD cod_espec_docto AS CHARACTER
    FIELD cod_ser_docto   AS CHARACTER
    FIELD cod_tit_acr     AS CHARACTER
    FIELD cod_parcela     AS CHARACTER
    FIELD cod_refer       AS CHARACTER
    FIELD status-result   AS CHARACTER INITIAL "OK"
    FIELD mensagem        AS CHARACTER
    FIELD r-importa           AS ROWID //24/06/2026 - Lucas 
    INDEX idx-key IS PRIMARY cod_estab cod_espec_docto cod_ser_docto cod_tit_acr cod_parcela
    INDEX idx-refer cod_refer.

/* ─── Contadores por situação ─── */
DEFINE TEMP-TABLE tt-contadores NO-UNDO
    FIELD todas     AS INTEGER INITIAL 0
    FIELD pendentes AS INTEGER INITIAL 0
    FIELD importadas AS INTEGER INITIAL 0
    FIELD com_erro  AS INTEGER INITIAL 0.



/******************************************************************************
** Programa  : importaTituloAcr.p
** Vers�o    : 001
** Tipo      : REST Handler � API TOTVS Datasul
** M�dulo    : Financeiro � Importa��o de T�tulos ACR
**
** Objetivo  : Roteador REST da API de importa��o de t�tulos a receber.
**             Recebe as requisi��es HTTP, delega ao Business Object e
**             devolve a resposta JSON com o status HTTP correspondente.
**
** Rotas dispon�veis:
**
**   GET /api/esp/v1/importaTituloAcr
**         Lista registros com filtros e pagina��o.
**         Query params: empresa, situacao, dataIni, dataFim, lote,
**                       pagina, itensPorPagina
**
**   GET /api/esp/v1/importaTituloAcr/empresas
**         Lista as empresas distintas presentes na tabela (1 por empresa).
**
**   GET /api/esp/v1/importaTituloAcr/contadores
**         Retorna totais por situa��o (para as abas do frontend).
**         Query params: empresa
**
**   GET /api/esp/v1/importaTituloAcr/{cgc}/{codEstab}/{codEspecDocto}/{codSerDocto}/{codTitAcr}/{codParcela}
**         Busca um registro espec�fico pela chave prim�ria.
**
**   DELETE /api/esp/v1/importaTituloAcr/{cgc}/{codEstab}/{codEspecDocto}/{codSerDocto}/{codTitAcr}/{codParcela}
**         Remove um t�tulo da fila de importa��o.
**         N�o permite dele��o se situa��o for "Importado".
**
** Cadastro REST (Administra��o ? Servi�os REST ? Programas):
**   Nome      : importaTituloAcr
**   Programa  : esp/importaTituloAcr.p
**   Vers�o    : v1
**   M�dulo    : esp
******************************************************************************/

BLOCK-LEVEL ON ERROR UNDO, THROW.

USING Progress.Lang.Error.
USING Progress.Json.ObjectModel.JsonObject.

{utp/ut-api.i}
{utp/ut-api-utils.i}

{utp/ut-api-action.i pi-importar-lote    POST   /importarLote/~*}
{utp/ut-api-action.i pi-gerar-relatorio  POST   /gerarRelatorio/~*}
{utp/ut-api-action.i pi-contadores     GET    /contadores/~*}
{utp/ut-api-action.i pi-listar-empresa GET    /empresas/~*}
{utp/ut-api-action.i pi-progresso      GET    /progresso/~*}
{utp/ut-api-action.i pi-remover        POST   /remover/~*}
{utp/ut-api-action.i pi-processar      POST   /processar/~*}
{utp/ut-api-action.i pi-listar-ad-cliente GET /clientes-ad/~*}
{utp/ut-api-action.i pi-listar-clientes  GET  /clientes/~*}
{utp/ut-api-action.i pi-listar-rpw-servidores GET  /rpwServidores/~*}
{utp/ut-api-action.i pi-importar-rpw          POST /importarRpw/~*}
{utp/ut-api-action.i pi-listar-titulos-grupo  GET  /titulos-grupo/~*}
{utp/ut-api-action.i pi-trocar-vinculo        POST /trocarVinculo/~*}
{utp/ut-api-action.i pi-listar         GET    /~*}
{utp/ut-api-action.i pi-deletar        DELETE /~*}

{utp/ut-api-notfound.i}

{esp/api/v1/importaTituloAcr.i}

DEFINE VARIABLE lc-resposta   AS LONGCHAR  NO-UNDO.
DEFINE VARIABLE i-status-http AS INTEGER   NO-UNDO.

/* Handle do Business Object (persistent) */
DEFINE VARIABLE h-bo AS HANDLE NO-UNDO.

PROCEDURE pi-listar:
    DEFINE INPUT  PARAM oJsonInput  AS JsonObject  NO-UNDO.
    DEFINE OUTPUT PARAM oJsonOutput AS JsonObject  NO-UNDO.

    DEFINE VARIABLE c-segmento AS CHARACTER NO-UNDO.
    
    DEFINE VARIABLE oJsonResponse  AS JsonObject NO-UNDO.
    DEFINE VARIABLE oRequestParser AS JsonAPIRequestParser NO-UNDO.
    
    CURRENT-LANG = CURRENT-LANG.
    
    ASSIGN oRequestParser = NEW JsonAPIRequestParser(oJsonInput).
     
    
    RUN esp/api/v1/importaTituloAcrRules.p PERSISTENT SET h-bo NO-ERROR.

    //c-segmento = TRIM(c-path-params, "/").
    
    RUN pi-listar IN h-bo (
        INPUT  oRequestParser:getQueryParams(),
        OUTPUT lc-resposta,
        OUTPUT i-status-http
    ).
    
    oJsonOutput   = NEW JsonObject().
    oJsonResponse = NEW JsonObject().
    
    ASSIGN oJsonResponse = JsonAPIUtils:convertLongcharToJsonObject(lc-resposta).
    
    IF oJsonResponse:getJsonArray("items"):LENGTH > 0 THEN
        ASSIGN i-status-http = 201.
        
    ASSIGN oJsonOutput   = JsonAPIResponseBuilder:ok(oJsonResponse, i-status-http).
    
    
    CATCH oE AS ERROR:
        ASSIGN oJsonOutput = JsonApiResponseBuilder:asError(oE).
    END CATCH.

/*     IF c-segmento = "empresas" THEN DO:          */
/*         RUN pi-listar-empresas IN h-bo (         */
/*             OUTPUT lc-resposta,                  */
/*             OUTPUT i-status-http                 */
/*         ).                                       */
/*         RETURN.                                  */
/*     END.                                         */
/*                                                  */
/*     IF c-segmento = "contadores" THEN DO:        */
/*         RUN pi-contadores IN h-bo (              */
/*             INPUT  c-query-string,               */
/*             OUTPUT lc-resposta,                  */
/*             OUTPUT i-status-http                 */
/*         ).                                       */
/*         RETURN.                                  */
/*     END.                                         */
/*                                                  */
/*     IF NUM-ENTRIES(c-segmento, "/") = 5 THEN DO: */
/*         RUN pi-buscar-por-chave IN h-bo (        */
/*             INPUT  c-segmento,                   */
/*             OUTPUT lc-resposta,                  */
/*             OUTPUT i-status-http                 */
/*         ).                                       */
/*         RETURN.                                  */
/*     END.                                         */

    /* Path desconhecido */
    //RUN pi-nao-encontrado(c-path-params).
    
    
    FINALLY:
        IF VALID-HANDLE(h-bo) THEN
            DELETE PROCEDURE h-bo NO-ERROR.
    END FINALLY.

END PROCEDURE.

PROCEDURE pi-listar-empresa:
    DEFINE INPUT  PARAM oJsonInput  AS JsonObject  NO-UNDO.
    DEFINE OUTPUT PARAM oJsonOutput AS JsonObject  NO-UNDO.

    DEFINE VARIABLE c-segmento AS CHARACTER NO-UNDO.
    
    DEFINE VARIABLE oJsonResponse  AS JsonObject NO-UNDO.
    DEFINE VARIABLE oRequestParser AS JsonAPIRequestParser NO-UNDO.
    
    CURRENT-LANG = CURRENT-LANG.
    
    ASSIGN oRequestParser = NEW JsonAPIRequestParser(oJsonInput).
     
    
    RUN esp/api/v1/importaTituloAcrRules.p PERSISTENT SET h-bo NO-ERROR.
    
    RUN pi-listar-empresas IN h-bo (
        INPUT  oRequestParser:getQueryParams(),
        OUTPUT lc-resposta,
        OUTPUT i-status-http
    ).
    
    
    oJsonResponse = NEW JsonObject().
    ASSIGN oJsonResponse = JsonAPIUtils:convertLongcharToJsonObject(lc-resposta).
    
    IF oJsonResponse:getJsonArray("items"):LENGTH > 0 THEN
        ASSIGN i-status-http = 201.
    
    oJsonOutput = NEW JsonObject().
    ASSIGN oJsonOutput = JsonAPIResponseBuilder:ok(oJsonResponse, i-status-http).
    
    CATCH oE AS ERROR:
        ASSIGN oJsonOutput = JsonApiResponseBuilder:asError(oE).
    END CATCH.
    
    FINALLY:
        IF VALID-HANDLE(h-bo) THEN
            DELETE PROCEDURE h-bo NO-ERROR.
    END FINALLY.

END PROCEDURE.

PROCEDURE pi-contadores:
    DEFINE INPUT  PARAM oJsonInput  AS JsonObject  NO-UNDO.
    DEFINE OUTPUT PARAM oJsonOutput AS JsonObject  NO-UNDO.

    DEFINE VARIABLE c-segmento AS CHARACTER NO-UNDO.
    
    DEFINE VARIABLE oJsonResponse  AS JsonObject NO-UNDO.
    DEFINE VARIABLE oRequestParser AS JsonAPIRequestParser NO-UNDO.
    
    ASSIGN oRequestParser = NEW JsonAPIRequestParser(oJsonInput).
     
    
    RUN esp/api/v1/importaTituloAcrRules.p PERSISTENT SET h-bo NO-ERROR.
    
    RUN pi-contadores IN h-bo (
        INPUT  oRequestParser:getQueryParams(),
        OUTPUT lc-resposta,
        OUTPUT i-status-http
    ).
    
    oJsonOutput   = NEW JsonObject().
    oJsonResponse = NEW JsonObject().
    
/*     IF oJsonResponse:getJsonArray("items"):LENGTH > 0 THEN */
/*         ASSIGN i-status-http = 201.                        */
    
    ASSIGN oJsonResponse = JsonAPIUtils:convertLongcharToJsonObject(lc-resposta)
           oJsonOutput   = JsonAPIResponseBuilder:ok(oJsonResponse, i-status-http).
           
    CATCH oE AS ERROR:
        ASSIGN oJsonOutput = JsonApiResponseBuilder:asError(oE).
    END CATCH.
    
    FINALLY:
        IF VALID-HANDLE(h-bo) THEN
            DELETE PROCEDURE h-bo NO-ERROR.
    END FINALLY.

END PROCEDURE.

/* -----------------------------------------------------------------------
   GET /importaTituloAcr/clientes
   Lista clientes agrupados por CGC com totais somados (aditivo, novo).
   ----------------------------------------------------------------------- */
PROCEDURE pi-listar-clientes:
    DEFINE INPUT  PARAM oJsonInput  AS JsonObject  NO-UNDO.
    DEFINE OUTPUT PARAM oJsonOutput AS JsonObject  NO-UNDO.

    DEFINE VARIABLE oJsonResponse  AS JsonObject NO-UNDO.
    DEFINE VARIABLE oRequestParser AS JsonAPIRequestParser NO-UNDO.

    ASSIGN oRequestParser = NEW JsonAPIRequestParser(oJsonInput).

    RUN esp/api/v1/importaTituloAcrRules.p PERSISTENT SET h-bo NO-ERROR.

    RUN pi-listar-clientes IN h-bo (
        INPUT  oRequestParser:getQueryParams(),
        OUTPUT lc-resposta,
        OUTPUT i-status-http
    ).

    oJsonOutput   = NEW JsonObject().
    oJsonResponse = NEW JsonObject().

    ASSIGN oJsonResponse = JsonAPIUtils:convertLongcharToJsonObject(lc-resposta)
           oJsonOutput   = JsonAPIResponseBuilder:ok(oJsonResponse, i-status-http).

    CATCH oE AS ERROR:
        ASSIGN oJsonOutput = JsonApiResponseBuilder:asError(oE).
    END CATCH.

    FINALLY:
        IF VALID-HANDLE(h-bo) THEN
            DELETE PROCEDURE h-bo NO-ERROR.
    END FINALLY.

END PROCEDURE.

/* -----------------------------------------------------------------------
   GET /importaTituloAcr/clientes-ad?cgc=...
   Lista titulos AD (adiantamento) com saldo disponivel para um cliente
   (aba "Grupo AD" do modal de detalhes). Aditivo, novo.
   ----------------------------------------------------------------------- */
PROCEDURE pi-listar-ad-cliente:
    DEFINE INPUT  PARAM oJsonInput  AS JsonObject  NO-UNDO.
    DEFINE OUTPUT PARAM oJsonOutput AS JsonObject  NO-UNDO.

    DEFINE VARIABLE oJsonResponse  AS JsonObject NO-UNDO.
    DEFINE VARIABLE oRequestParser AS JsonAPIRequestParser NO-UNDO.

    ASSIGN oRequestParser = NEW JsonAPIRequestParser(oJsonInput).

    RUN esp/api/v1/importaTituloAcrRules.p PERSISTENT SET h-bo NO-ERROR.

    RUN pi-listar-ad-cliente IN h-bo (
        INPUT  oRequestParser:getQueryParams(),
        OUTPUT lc-resposta,
        OUTPUT i-status-http
    ).

    oJsonOutput   = NEW JsonObject().
    oJsonResponse = NEW JsonObject().

    ASSIGN oJsonResponse = JsonAPIUtils:convertLongcharToJsonObject(lc-resposta)
           oJsonOutput   = JsonAPIResponseBuilder:ok(oJsonResponse, i-status-http).

    CATCH oE AS ERROR:
        ASSIGN oJsonOutput = JsonApiResponseBuilder:asError(oE).
    END CATCH.

    FINALLY:
        IF VALID-HANDLE(h-bo) THEN
            DELETE PROCEDURE h-bo NO-ERROR.
    END FINALLY.

END PROCEDURE.

PROCEDURE pi-progresso:
    DEFINE INPUT  PARAM oJsonInput  AS JsonObject  NO-UNDO.
    DEFINE OUTPUT PARAM oJsonOutput AS JsonObject  NO-UNDO.

    DEFINE VARIABLE oJsonResponse  AS JsonObject NO-UNDO.
    DEFINE VARIABLE oRequestParser AS JsonAPIRequestParser NO-UNDO.

    ASSIGN oRequestParser = NEW JsonAPIRequestParser(oJsonInput).

    RUN esp/api/v1/importaTituloAcrRules.p PERSISTENT SET h-bo NO-ERROR.

    RUN pi-progresso IN h-bo (
        INPUT  oRequestParser:getQueryParams(),
        OUTPUT lc-resposta,
        OUTPUT i-status-http
    ).

    oJsonOutput   = NEW JsonObject().
    oJsonResponse = NEW JsonObject().

    ASSIGN oJsonResponse = JsonAPIUtils:convertLongcharToJsonObject(lc-resposta)
           oJsonOutput   = JsonAPIResponseBuilder:ok(oJsonResponse, i-status-http).

    CATCH oE AS ERROR:
        ASSIGN oJsonOutput = JsonApiResponseBuilder:asError(oE).
    END CATCH.

    FINALLY:
        IF VALID-HANDLE(h-bo) THEN
            DELETE PROCEDURE h-bo NO-ERROR.
    END FINALLY.
END PROCEDURE.

/* -----------------------------------------------------------------------
   POST /importaTituloAcr/processar
   Body: { "cgcs": ["12345678000195", ...] }
   ----------------------------------------------------------------------- */
PROCEDURE pi-processar:
    DEFINE INPUT  PARAM oJsonInput  AS JsonObject NO-UNDO.
    DEFINE OUTPUT PARAM oJsonOutput AS JsonObject NO-UNDO.

    DEFINE VARIABLE oJsonResponse  AS JsonObject NO-UNDO.

    RUN esp/api/v1/importaTituloAcrRules.p PERSISTENT SET h-bo NO-ERROR.

    RUN pi-processar IN h-bo (
        INPUT  oJsonInput,
        OUTPUT lc-resposta,
        OUTPUT i-status-http
    ).

    oJsonResponse = JsonAPIUtils:convertLongcharToJsonObject(lc-resposta).
    oJsonOutput   = JsonAPIResponseBuilder:ok(oJsonResponse, i-status-http).

    CATCH oE AS ERROR:
        ASSIGN oJsonOutput = JsonApiResponseBuilder:asError(oE).
    END CATCH.

    FINALLY:
        IF VALID-HANDLE(h-bo) THEN
            DELETE PROCEDURE h-bo NO-ERROR.
    END FINALLY.

END PROCEDURE.

/* -----------------------------------------------------------------------
   DELETE /importaTituloAcr/{cgc}/{codEstab}/{codEspecDocto}/{codSerDocto}/{codTitAcr}/{codParcela}
   ----------------------------------------------------------------------- */
PROCEDURE pi-remover:
    DEFINE INPUT  PARAM oJsonInput  AS JsonObject NO-UNDO.
    DEFINE OUTPUT PARAM oJsonOutput AS JsonObject NO-UNDO.

    DEFINE VARIABLE oJsonResponse  AS JsonObject NO-UNDO.

    RUN esp/api/v1/importaTituloAcrRules.p PERSISTENT SET h-bo NO-ERROR.

    RUN pi-remover IN h-bo (
        INPUT  oJsonInput,
        OUTPUT lc-resposta,
        OUTPUT i-status-http
    ).

    oJsonResponse = JsonAPIUtils:convertLongcharToJsonObject(lc-resposta).
    oJsonOutput   = JsonAPIResponseBuilder:ok(oJsonResponse, i-status-http).

    CATCH oE AS ERROR:
        ASSIGN oJsonOutput = JsonApiResponseBuilder:asError(oE).
    END CATCH.

    FINALLY:
        IF VALID-HANDLE(h-bo) THEN
            DELETE PROCEDURE h-bo NO-ERROR.
    END FINALLY.

END PROCEDURE.

PROCEDURE pi-deletar:
    DEFINE INPUT  PARAM oJsonInput  AS JsonObject NO-UNDO.
    DEFINE OUTPUT PARAM oJsonOutput AS JsonObject NO-UNDO.

    DEFINE VARIABLE oJsonResponse  AS JsonObject         NO-UNDO.
    DEFINE VARIABLE oRequestParser AS JsonAPIRequestParser NO-UNDO.
    DEFINE VARIABLE oQueryParams   AS JsonObject         NO-UNDO.
    DEFINE VARIABLE c-cgc          AS CHARACTER           NO-UNDO.
    DEFINE VARIABLE c-estab        AS CHARACTER           NO-UNDO.
    DEFINE VARIABLE c-espec        AS CHARACTER           NO-UNDO.
    DEFINE VARIABLE c-serie        AS CHARACTER           NO-UNDO.
    DEFINE VARIABLE c-titulo       AS CHARACTER           NO-UNDO.
    DEFINE VARIABLE c-parcela      AS CHARACTER           NO-UNDO.
    DEFINE VARIABLE c-valor        AS CHARACTER           NO-UNDO.
    DEFINE VARIABLE c-path         AS CHARACTER           NO-UNDO.

    ASSIGN oRequestParser = NEW JsonAPIRequestParser(oJsonInput).
    oQueryParams = oRequestParser:getQueryParams().

    /* Extrai os campos-chave dos query params */
    ASSIGN c-cgc     = oQueryParams:GetJsonArray("cgc"):GetCharacter(1) NO-ERROR.
    ASSIGN c-estab   = oQueryParams:GetJsonArray("codEstab"):GetCharacter(1) NO-ERROR.
    ASSIGN c-espec   = oQueryParams:GetJsonArray("codEspecDocto"):GetCharacter(1) NO-ERROR.
    ASSIGN c-serie   = oQueryParams:GetJsonArray("codSerDocto"):GetCharacter(1) NO-ERROR.
    ASSIGN c-titulo  = oQueryParams:GetJsonArray("codTitAcr"):GetCharacter(1) NO-ERROR.
    ASSIGN c-parcela = oQueryParams:GetJsonArray("codParcela"):GetCharacter(1) NO-ERROR.
    /* Opcional - desambigua registros "sem título" (chave vazia) que só se
       distinguem pelo valor. Mantido no fim do path para nao quebrar quem
       ainda chama com apenas 6 segmentos. */
    ASSIGN c-valor   = oQueryParams:GetJsonArray("valRecebido"):GetCharacter(1) NO-ERROR.
    IF c-valor = ? THEN c-valor = "".

    /* Monta o path no formato esperado pela BO */
    c-path = c-cgc + "/" + c-estab + "/" + c-espec + "/" + c-serie + "/" + c-titulo + "/" + c-parcela
           + (IF c-valor <> "" THEN "/" + c-valor ELSE "").

    RUN esp/api/v1/importaTituloAcrRules.p PERSISTENT SET h-bo NO-ERROR.

    RUN pi-deletar IN h-bo (
        INPUT  c-path,
        OUTPUT lc-resposta,
        OUTPUT i-status-http
    ).

    oJsonResponse = JsonAPIUtils:convertLongcharToJsonObject(lc-resposta).
    oJsonOutput   = JsonAPIResponseBuilder:ok(oJsonResponse, i-status-http).

    CATCH oE AS ERROR:
        ASSIGN oJsonOutput = JsonApiResponseBuilder:asError(oE).
    END CATCH.

    FINALLY:
        IF VALID-HANDLE(h-bo) THEN
            DELETE PROCEDURE h-bo NO-ERROR.
    END FINALLY.

END PROCEDURE.

/* -----------------------------------------------------------------------
   Respostas de erro padronizadas
   ----------------------------------------------------------------------- */
/* -----------------------------------------------------------------------
   POST /importarLote
   ----------------------------------------------------------------------- */
PROCEDURE pi-importar-lote:
    DEFINE INPUT  PARAM oJsonInput  AS JsonObject NO-UNDO.
    DEFINE OUTPUT PARAM oJsonOutput AS JsonObject NO-UNDO.
    DEFINE VARIABLE oJsonResponse  AS JsonObject NO-UNDO.
    RUN esp/api/v1/importaTituloAcrRules.p PERSISTENT SET h-bo NO-ERROR.
    RUN pi-importar-lote IN h-bo (INPUT oJsonInput, OUTPUT lc-resposta, OUTPUT i-status-http).
    oJsonResponse = JsonAPIUtils:convertLongcharToJsonObject(lc-resposta).
    oJsonOutput   = JsonAPIResponseBuilder:ok(oJsonResponse, i-status-http).
    CATCH oE AS ERROR: ASSIGN oJsonOutput = JsonApiResponseBuilder:asError(oE). END CATCH.
    FINALLY: IF VALID-HANDLE(h-bo) THEN DELETE PROCEDURE h-bo NO-ERROR. END FINALLY.
END PROCEDURE.

/* -----------------------------------------------------------------------
   GET /rpwServidores  - lista servidores RPW ativos (com tipo de fila)
   ----------------------------------------------------------------------- */
PROCEDURE pi-listar-rpw-servidores:
    DEFINE INPUT  PARAM oJsonInput  AS JsonObject NO-UNDO.
    DEFINE OUTPUT PARAM oJsonOutput AS JsonObject NO-UNDO.
    DEFINE VARIABLE oJsonResponse  AS JsonObject NO-UNDO.
    DEFINE VARIABLE oRequestParser AS JsonAPIRequestParser NO-UNDO.
    ASSIGN oRequestParser = NEW JsonAPIRequestParser(oJsonInput).
    RUN esp/api/v1/importaTituloAcrRules.p PERSISTENT SET h-bo NO-ERROR.
    RUN pi-listar-rpw-servidores IN h-bo (INPUT oRequestParser:getQueryParams(), OUTPUT lc-resposta, OUTPUT i-status-http).
    oJsonResponse = JsonAPIUtils:convertLongcharToJsonObject(lc-resposta).
    oJsonOutput   = JsonAPIResponseBuilder:ok(oJsonResponse, i-status-http).
    CATCH oE AS ERROR: ASSIGN oJsonOutput = JsonApiResponseBuilder:asError(oE). END CATCH.
    FINALLY: IF VALID-HANDLE(h-bo) THEN DELETE PROCEDURE h-bo NO-ERROR. END FINALLY.
END PROCEDURE.

/* -----------------------------------------------------------------------
   POST /importarRpw  - grava o CSV na pasta do RPW (parametro importa-cr-rpw)
   ----------------------------------------------------------------------- */
PROCEDURE pi-importar-rpw:
    DEFINE INPUT  PARAM oJsonInput  AS JsonObject NO-UNDO.
    DEFINE OUTPUT PARAM oJsonOutput AS JsonObject NO-UNDO.
    DEFINE VARIABLE oJsonResponse  AS JsonObject NO-UNDO.
    RUN esp/api/v1/importaTituloAcrRules.p PERSISTENT SET h-bo NO-ERROR.
    RUN pi-importar-rpw IN h-bo (INPUT oJsonInput, OUTPUT lc-resposta, OUTPUT i-status-http).
    oJsonResponse = JsonAPIUtils:convertLongcharToJsonObject(lc-resposta).
    oJsonOutput   = JsonAPIResponseBuilder:ok(oJsonResponse, i-status-http).
    CATCH oE AS ERROR: ASSIGN oJsonOutput = JsonApiResponseBuilder:asError(oE). END CATCH.
    FINALLY: IF VALID-HANDLE(h-bo) THEN DELETE PROCEDURE h-bo NO-ERROR. END FINALLY.
END PROCEDURE.

/* -----------------------------------------------------------------------
   GET /titulos-grupo?cgc=  - titulos em aberto do grupo empresarial
   ----------------------------------------------------------------------- */
PROCEDURE pi-listar-titulos-grupo:
    DEFINE INPUT  PARAM oJsonInput  AS JsonObject NO-UNDO.
    DEFINE OUTPUT PARAM oJsonOutput AS JsonObject NO-UNDO.
    DEFINE VARIABLE oJsonResponse  AS JsonObject NO-UNDO.
    DEFINE VARIABLE oRequestParser AS JsonAPIRequestParser NO-UNDO.
    ASSIGN oRequestParser = NEW JsonAPIRequestParser(oJsonInput).
    RUN esp/api/v1/importaTituloAcrRules.p PERSISTENT SET h-bo NO-ERROR.
    RUN pi-listar-titulos-grupo IN h-bo (INPUT oRequestParser:getQueryParams(), OUTPUT lc-resposta, OUTPUT i-status-http).
    oJsonResponse = JsonAPIUtils:convertLongcharToJsonObject(lc-resposta).
    oJsonOutput   = JsonAPIResponseBuilder:ok(oJsonResponse, i-status-http).
    CATCH oE AS ERROR: ASSIGN oJsonOutput = JsonApiResponseBuilder:asError(oE). END CATCH.
    FINALLY: IF VALID-HANDLE(h-bo) THEN DELETE PROCEDURE h-bo NO-ERROR. END FINALLY.
END PROCEDURE.

/* -----------------------------------------------------------------------
   POST /trocarVinculo  - re-aponta o titulo vinculado de um pendente
   ----------------------------------------------------------------------- */
PROCEDURE pi-trocar-vinculo:
    DEFINE INPUT  PARAM oJsonInput  AS JsonObject NO-UNDO.
    DEFINE OUTPUT PARAM oJsonOutput AS JsonObject NO-UNDO.
    DEFINE VARIABLE oJsonResponse  AS JsonObject NO-UNDO.
    RUN esp/api/v1/importaTituloAcrRules.p PERSISTENT SET h-bo NO-ERROR.
    RUN pi-trocar-vinculo IN h-bo (INPUT oJsonInput, OUTPUT lc-resposta, OUTPUT i-status-http).
    oJsonResponse = JsonAPIUtils:convertLongcharToJsonObject(lc-resposta).
    oJsonOutput   = JsonAPIResponseBuilder:ok(oJsonResponse, i-status-http).
    CATCH oE AS ERROR: ASSIGN oJsonOutput = JsonApiResponseBuilder:asError(oE). END CATCH.
    FINALLY: IF VALID-HANDLE(h-bo) THEN DELETE PROCEDURE h-bo NO-ERROR. END FINALLY.
END PROCEDURE.

/* -----------------------------------------------------------------------
   POST /gerarRelatorio
   ----------------------------------------------------------------------- */
PROCEDURE pi-gerar-relatorio:
    DEFINE INPUT  PARAM oJsonInput  AS JsonObject NO-UNDO.
    DEFINE OUTPUT PARAM oJsonOutput AS JsonObject NO-UNDO.
    DEFINE VARIABLE oJsonResponse  AS JsonObject NO-UNDO.
    RUN esp/api/v1/importaTituloAcrRules.p PERSISTENT SET h-bo NO-ERROR.
    RUN pi-gerar-relatorio IN h-bo (INPUT oJsonInput, OUTPUT lc-resposta, OUTPUT i-status-http).
    oJsonResponse = JsonAPIUtils:convertLongcharToJsonObject(lc-resposta).
    oJsonOutput   = JsonAPIResponseBuilder:ok(oJsonResponse, i-status-http).
    CATCH oE AS ERROR: ASSIGN oJsonOutput = JsonApiResponseBuilder:asError(oE). END CATCH.
    FINALLY: IF VALID-HANDLE(h-bo) THEN DELETE PROCEDURE h-bo NO-ERROR. END FINALLY.
END PROCEDURE.

PROCEDURE pi-erro-interno:
    DEFINE INPUT PARAMETER c-mensagem AS CHARACTER NO-UNDO.
    DEFINE VARIABLE oErro AS JsonObject NO-UNDO.
    oErro = NEW JsonObject().
    oErro:Add("error", c-mensagem).
    oErro:Write(lc-resposta, TRUE).
    i-status-http = 500.
END PROCEDURE.

PROCEDURE pi-nao-encontrado:
    DEFINE INPUT PARAMETER c-path AS CHARACTER NO-UNDO.
    DEFINE VARIABLE oErro AS JsonObject NO-UNDO.
    oErro = NEW JsonObject().
    oErro:Add("error", "Recurso n�o encontrado: " + c-path).
    oErro:Write(lc-resposta, TRUE).
    i-status-http = 404.
END PROCEDURE.
/*                                                                     */
/* PROCEDURE pi-metodo-nao-permitido:                                  */
/*     DEFINE INPUT PARAMETER c-metodo AS CHARACTER NO-UNDO.           */
/*     DEFINE VARIABLE oErro AS JsonObject NO-UNDO.                    */
/*     oErro = NEW JsonObject().                                       */
/*     oErro:Add("error", "M�todo HTTP n�o suportado: " + c-metodo). */
/*     oErro:Write(lc-resposta, TRUE).                                 */
/*     i-status-http = 405.                                            */
/* END PROCEDURE.                                                      */



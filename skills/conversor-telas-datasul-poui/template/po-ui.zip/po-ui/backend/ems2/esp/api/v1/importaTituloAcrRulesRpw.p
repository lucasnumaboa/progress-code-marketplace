/******************************************************************************
** Programa  : importaTituloAcrRulesRpw.p
** Tipo      : RPW (Report & Processing Workbench) — TOTVS Datasul
** Objetivo  : Executa o processamento de todos os títulos pendentes/erro
**             chamando a regra de negócio central (importaTituloAcrRules.p)
**
** Parâmetros: (jobSchedule REST — POST /api/cdp/v1/jobSchedule)
**   ip-empresa         : Código da empresa
**   ip-caminho-arquivo : Caminho do arquivo (opcional para processamento em lote)
******************************************************************************/
BLOCK-LEVEL ON ERROR UNDO, THROW.
USING Progress.Json.ObjectModel.JsonObject.
/* -----------------------------------------------------------------------
   Parâmetros de entrada padrão do framework (quando via schedule da API)
   ----------------------------------------------------------------------- */
//DEFINE INPUT PARAMETER ip-empresa         AS CHARACTER NO-UNDO.
//DEFINE INPUT PARAMETER ip-caminho-arquivo AS CHARACTER NO-UNDO.
/* -----------------------------------------------------------------------
   Variáveis de controle
   ----------------------------------------------------------------------- */
DEFINE VARIABLE h-bo        AS HANDLE     NO-UNDO.
DEFINE VARIABLE oJsonBody   AS JsonObject NO-UNDO.
DEFINE VARIABLE lc-resposta AS LONGCHAR   NO-UNDO.
DEFINE VARIABLE i-status    AS INTEGER    NO-UNDO.
/* -----------------------------------------------------------------------
   Lógica Principal
   ----------------------------------------------------------------------- */
/* 1. Prepara o payload (JSON) para simular o "Processar Todos" da tela WEB */
oJsonBody = NEW JsonObject().
oJsonBody:Add("processarTodos", TRUE).
oJsonBody:Add("codUsuario", USERID(LDBNAME(1))). /* Pega o usuário logado no RPW */
/* 2. Instancia o programa de regras (BO) persistente */
RUN esp/api/v1/importaTituloAcrRules.p PERSISTENT SET h-bo NO-ERROR.
IF ERROR-STATUS:ERROR OR NOT VALID-HANDLE(h-bo) THEN DO:
    /* No RPW, mensagens via MESSAGE vão para o LOG do servidor (btrw) */
    MESSAGE "ERRO FATAL: Não foi possível instanciar esp/api/v1/importaTituloAcrRules.p." VIEW-AS ALERT-BOX ERROR.
    RETURN "NOK".
END.
/* 3. Executa a rotina central de processamento */
/* Essa rotina vai buscar todos os registros com "Pendente" ou "Erro" na tabela e processar */
RUN pi-processar IN h-bo (
    INPUT oJsonBody, 
    OUTPUT lc-resposta, 
    OUTPUT i-status
) NO-ERROR.
/* 4. Verifica possíveis erros da API e grava no LOG do RPW */
IF ERROR-STATUS:ERROR OR i-status >= 400 THEN DO:
    MESSAGE "AVISO/ERRO DURANTE O PROCESSAMENTO RPW:" VIEW-AS ALERT-BOX WARNING.
    MESSAGE STRING(lc-resposta) VIEW-AS ALERT-BOX WARNING.
END.
ELSE DO:
    MESSAGE "PROCESSAMENTO RPW CONCLUIDO COM SUCESSO." VIEW-AS ALERT-BOX INFO.
    /* Se quiser, pode imprimir o resumo que a API gerou: */
    /* MESSAGE STRING(lc-resposta) VIEW-AS ALERT-BOX INFO. */
END.
/* 5. Limpa a memória fechando a procedure persistente */
IF VALID-HANDLE(h-bo) THEN DO:
    APPLY "CLOSE" TO h-bo.
    DELETE PROCEDURE h-bo NO-ERROR.
END.
RETURN "OK".

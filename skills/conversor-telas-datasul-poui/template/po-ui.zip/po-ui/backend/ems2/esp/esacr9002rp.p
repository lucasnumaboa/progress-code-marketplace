&ANALYZE-SUSPEND _VERSION-NUMBER AB_v10r12
&ANALYZE-RESUME
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CUSTOM _DEFINITIONS Procedure 
/********************************************************************************
** Copyright DATASUL S.A. (1997)
** Todos os Direitos Reservados.
**
** Este fonte e de propriedade exclusiva da DATASUL, sua reproducao
** parcial ou total por qualquer meio, so podera ser feita mediante
** autorizacao expressa.
*******************************************************************************/
{include/i-prgvrs.i ESACR9002rp LIBERADO}  /*** 010003 ***/
{include/i_fnctrad.i}
/******************************************************************************
**
**   Programa: esacr9002rp.p
**
**   Data....: Fevereiro de 2021.
**
**   Autor...: HEBER.
**
**   Objetivo: Listagem de nota-fiscals a receber
**  
*******************************************************************************/
{include/i-rpvar.i}
{cdp/cdcfgmat.i} /* include com pre-processadores */

{esp/esacr9002.i}

/** 
**  Temporary tables 
**/
DEFINE TEMP-TABLE ttComErros           
    FIELD cod_tit_acr         LIKE tt-digita.titulo 
    FIELD cod_ser_docto       LIKE tt-digita.serie
    FIELD val_informado       LIKE tt-digita.valor
    FIELD val_origin_tit_acr  LIKE tit_acr.val_origin_tit_acr
    FIELD val_avas            LIKE tt-digita.valor
    FIELD val_sdo_tit_acr     LIKE tit_acr.val_sdo_tit_acr
    FIELD erro                AS   CHAR FORMAT "x(50)"
    INDEX pri cod_tit_acr cod_ser_docto.

DEFINE TEMP-TABLE tt_tit_antecip LIKE tit_acr.

DEFINE TEMP-TABLE ttSucesso 
    FIELD estab               LIKE tit_acr.cod_estab                                             
    FIELD espec               LIKE tit_acr.cod_espec_docto                                       
    FIELD titulo              LIKE tit_acr.cod_tit_acr                                           
    FIELD serie               LIKE tit_acr.cod_ser_docto                                         
    FIELD parcela             LIKE tit_acr.cod_parcela                                           
    FIELD transacao           LIKE movto_tit_acr.dat_transacao                                     
    FIELD movimento           LIKE movto_tit_acr.ind_trans_acr                                     
    FIELD valor               LIKE movto_tit_acr.val_movto_tit_acr                                 
    FIELD mensagem            AS   CHAR
    INDEX ind1 estab espec titulo serie
    INDEX ind2 titulo serie.

DEFINE TEMP-TABLE tt-avas
    FIELD titulo              LIKE tt-digita.titulo
    FIELD serie               LIKE tt-digita.serie
    FIELD valor               LIKE tt-digita.valor
    INDEX pri titulo serie.

DEF TEMP-TABLE tt-raw-digita
    FIELD raw-digita  AS RAW.

/* recebimento de par�metros */
DEF INPUT PARAMETER raw-param AS RAW NO-UNDO.
DEF INPUT PARAMETER TABLE FOR tt-raw-digita.

CREATE tt-param.
RAW-TRANSFER raw-param TO tt-param.

FOR EACH tt-raw-digita.
    CREATE tt-digita.
    RAW-TRANSFER tt-raw-digita.raw-digita TO tt-digita.
END. 

FIND FIRST tt-param NO-LOCK NO-ERROR.

DEFINE BUFFER b-digita  FOR tt-digita.
DEFINE BUFFER b-tit_acr FOR tit_acr.

DEFINE VARIABLE h-acomp           AS   HANDLE.
DEFINE VARIABLE v_log_refer_uni   AS   LOGICAL   FORMAT "Sim/N�o" INITIAL NO NO-UNDO.
DEFINE VARIABLE v_cod_refer       AS   CHARACTER FORMAT "x(10)":U LABEL "Refer�ncia" COLUMN-LABEL "Refer�ncia" NO-UNDO.
DEFINE VARIABLE v_seq             AS   INT       INITIAL 0     NO-UNDO.
DEFINE VARIABLE de-vl-titulo      LIKE tit_acr.val_sdo_tit_acr NO-UNDO.
DEFINE VARIABLE v_hdl_program     AS   Handle                  NO-UNDO.
DEFINE VARIABLE v_hdl_aux         AS   HANDLE                  NO-UNDO.
DEFINE VARIABLE tituloAnterior    LIKE tit_acr.cod_tit_acr     NO-UNDO.
DEFINE VARIABLE serieAnterior     LIKE tit_acr.cod_ser_docto   NO-UNDO.
DEFINE VARIABLE tituloComErro     LIKE tit_acr.cod_tit_acr     NO-UNDO. 
DEFINE VARIABLE serieComErro      LIKE tit_acr.cod_ser_docto   NO-UNDO. 
DEFINE VARIABLE v_seq_refer        AS INTEGER   NO-UNDO.
DEFINE VARIABLE v_cod_finalid_econ AS CHARACTER FORMAT "x(10)":U LABEL "Finalidade Econ�mica" COLUMN-LABEL "Finalidade Econ�mica" NO-UNDO.
DEFINE VARIABLE antec_estab       LIKE tit_acr.cod_estab.
DEFINE VARIABLE antec_espec_docto LIKE tit_acr.cod_espec_docto.
DEFINE VARIABLE antec_ser_docto   LIKE tit_acr.cod_estab.
DEFINE VARIABLE antec_cod_tit_acr LIKE tit_acr.cod_tit_acr.
DEFINE VARIABLE antec_cod_parcela LIKE tit_acr.cod_parcela.
DEFINE VARIABLE antec_original    LIKE tit_acr.val_origin_tit_acr.
DEFINE VARIABLE antec_titulos     AS   INT.
DEFINE VARIABLE antec_valor       LIKE tit_acr.val_origin_tit_acr.
DEFINE VARIABLE antec_baixas      AS   INT.
DEFINE VARIABLE antec_vrBaixas    LIKE tit_acr.val_origin_tit_acr.
DEFINE VARIABLE antec_vrSaldo     LIKE tit_acr.val_sdo_tit_acr.
DEFINE VARIABLE antec_avas        AS   INT.
DEFINE VARIABLE antec_descontos   LIKE movto_tit_acr.val_desconto.
DEFINE BUFFER b_tit_acr           FOR  tit_acr.
DEFINE BUFFER b_movto_tit_acr     FOR  movto_tit_acr.
DEFINE BUFFER b2_movto_tit_acr    FOR  movto_tit_acr.

{esp/esacr9001rp.i}
{esp/acr901zf.i}


FORM 
    ttComErros.cod_tit_acr        AT 01  COLUMN-LABEL "Titulo"       FORMAT "x(7)"  
    ttComErros.cod_ser_docto      AT 09  COLUMN-LABEL "Sr"           FORMAT "x(2)"
    ttComErros.erro               AT 13  COLUMN-LABEL "Erro"
    ttComErros.val_informado      AT 65  COLUMN-LABEL "Vr.Informado" FORMAT "->,>>>,>>9.99"
    ttComErros.val_origin_tit_acr AT 79  COLUMN-LABEL "Vr.Origin."   FORMAT "->,>>>,>>9.99"
    ttComErros.val_avas           AT 93  COLUMN-LABEL "Vr.Ava"       FORMAT "->,>>>,>>9.99"
    ttComErros.val_sdo_tit_acr    AT 107 COLUMN-LABEL "Vr.Saldo"     FORMAT "->,>>>,>>9.99"
    WITH DOWN STREAM-IO NO-BOX WIDTH 132 FRAME f-erros.

FORM
    ttSucesso.estab               AT 01  COLUMN-LABEL "EST"          FORMAT "X(03)"
    ttSucesso.espec               AT 05  COLUMN-LABEL "ES"           FORMAT "X(02)"
    ttSucesso.titulo              AT 08  COLUMN-LABEL "TITULO"       FORMAT "X(07)"
    ttSucesso.serie               AT 16  COLUMN-LABEL "SER"          FORMAT "X(03)"
    ttSucesso.parcela             AT 20  COLUMN-LABEL "P"            FORMAT "X(02)"
    ttSucesso.transacao           AT 23  COLUMN-LABEL "TRANSACAO"    FORMAT "99/99/9999"
    ttSucesso.movimento           AT 34  COLUMN-LABEL "MOVIMENTO"    FORMAT "X(30)"
    ttSucesso.valor               AT 66  COLUMN-LABEL "VALOR"        FORMAT "->,>>>,>>9.99"
    ttSucesso.mensagem            AT 80  COLUMN-LABEL "MENSAGEM"     FORMAT "X(40)"
    WITH DOWN STREAM-IO NO-BOX WIDTH 132 FRAME f-sucesso.

FORM "A N T E C I P A � � O"      AT  56 SKIP(2)
     "Estabelecimento:"           AT  45 
     antec_estab                  AT  63 NO-LABEL SKIP   
     "Esp�cie:"                   AT  45
     antec_espec_docto            AT  63 NO-LABEL SKIP
     "S�rie:"                     AT  45 
     antec_ser_docto              AT  63 NO-LABEL SKIP
     "T�tulo:"                    AT  45 
     antec_cod_tit_acr            AT  63 NO-LABEL SKIP
     "Parcela:"                   AT  45 
     antec_cod_parcela            AT  63 NO-LABEL SKIP(2)
     "Vr. Antecipa��o:"           AT  45 
     antec_original               AT  63 NO-LABEL FORMAT "->>,>>>,>>9.99" SKIP
     "Vr. T�tulos"                AT  45
     antec_valor                  AT  63 NO-LABEL FORMAT "->>,>>>,>>9.99"
     antec_titulos                AT  79 NO-LABEL FORMAT "999" 
     "titulos"                    AT  83 SKIP
     "Vr. Descontos"              AT  45
     antec_descontos              AT  63 NO-LABEL FORMAT "->>,>>>,>>9.99"
     antec_avas                   AT  79 NO-LABEL FORMAT "999"
     "lan�amentos"                AT  83 SKIP
     "Vr. Liquida��o"             AT  45
     antec_vrBaixas               AT  63 NO-LABEL FORMAT "->>,>>>,>>9.99"
     antec_baixas                 AT  79 NO-LABEL FORMAT "999"
     "titulos"                    AT  83 SKIP
     "Vr. Saldo Antecip"          AT  45 
     antec_vrSaldo                AT  63 NO-LABEL FORMAT "->>,>>>,>>9.99" SKIP
    WITH DOWN STREAM-IO NO-BOX WIDTH 132 FRAME f-antecipacao.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&ANALYZE-SUSPEND _UIB-PREPROCESSOR-BLOCK 

/* ********************  Preprocessor Definitions  ******************** */

&Scoped-define PROCEDURE-TYPE Procedure
&Scoped-define DB-AWARE no



/* _UIB-PREPROCESSOR-BLOCK-END */
&ANALYZE-RESUME


/* ************************  Function Prototypes ********************** */

&IF DEFINED(EXCLUDE-isnum) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _FUNCTION-FORWARD isnum Procedure 
FUNCTION isnum RETURNS LOGICAL
  ( INPUT param1 AS CHAR )  FORWARD.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF


/* *********************** Procedure Settings ************************ */

&ANALYZE-SUSPEND _PROCEDURE-SETTINGS
/* Settings for THIS-PROCEDURE
   Type: Procedure
   Allow: 
   Frames: 0
   Add Fields to: Neither
   Other Settings: CODE-ONLY COMPILE
 */
&ANALYZE-RESUME _END-PROCEDURE-SETTINGS

/* *************************  Create Window  ************************** */

&ANALYZE-SUSPEND _CREATE-WINDOW
/* DESIGN Window definition (used by the UIB) 
  CREATE WINDOW Procedure ASSIGN
         HEIGHT             = 15
         WIDTH              = 60.
/* END WINDOW DEFINITION */
                                                                        */
&ANALYZE-RESUME

 


&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CUSTOM _MAIN-BLOCK Procedure 


/******************************************************************************************


*******************************************************************************************/

/* RUN utp/ut-trfrrp.p (INPUT FRAME f-relat) */
{include/i-rpcab.i}

    FIND FIRST mgcad.empresa NO-LOCK NO-ERROR.
    ASSIGN 
        c-programa     = "ESACR9002RP"
        c-versao       = "2.07"
        c-revisao      = ".02.000"
        c-empresa      =  empresa.nome
        c-sistema      = "Especifico"
        c-titulo-relat = "Baixa de T�tulos com Antecipa��es Leroy".

{include/i-rpout.i}

    VIEW FRAME f-cabec.
    VIEW FRAME f-rodape.

    RUN pi-processar.

    IF CAN-FIND(FIRST ttSucesso) THEN DO:
        FOR EACH ttSucesso:
            DISPLAY ttSucesso.estab      
                    ttSucesso.espec      
                    ttSucesso.titulo     
                    ttSucesso.serie      
                    ttSucesso.parcela    
                    ttSucesso.transacao  
                    ttSucesso.movimento  
                    ttSucesso.valor      
                    ttSucesso.mensagem   WITH FRAME f-sucesso.
            DOWN WITH FRAME f-sucesso.
        END.
        PAGE.
    END.

    IF CAN-FIND(FIRST ttComErros) THEN DO:      
        FOR EACH ttComErros:
            DISPLAY ttComErros.cod_tit_acr       
                    ttComErros.cod_ser_docto     
                    ttComErros.erro              
                    ttComErros.val_informado     
                    ttComErros.val_origin_tit_acr
                    ttComErros.val_avas          
                    ttComErros.val_sdo_tit_acr   WITH FRAME f-erros.
            DOWN 1 WITH FRAME f-erros.
        END.
    END.

    IF AVAIL tt_tit_antecip THEN DO:
        RUN pi-resumo(tt_tit_antecip.cod_estab,     
                      tt_tit_antecip.cod_espec_docto, 
                      tt_tit_antecip.cod_tit_acr,     
                      tt_tit_antecip.cod_ser_docto,   
                      tt_tit_antecip.cod_parcela).    

    END.

{include/i-rpclo.i}
    return 'ok'.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


/* **********************  Internal Procedures  *********************** */

&IF DEFINED(EXCLUDE-pi-avas) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE pi-avas Procedure 
PROCEDURE pi-avas :
/*------------------------------------------------------------------------------
  Purpose:     Processa os Acertos de Valor � menor nos t�tulos  
  Parameters:  <none>
  Notes:       
------------------------------------------------------------------------------*/

    RUN pi-seta-titulo IN h-acomp (INPUT "Processando AVAS").

    IF NOT CAN-FIND(FIRST tt-digita WHERE tt-digita.ntipo = 1) THEN DO:
        RUN utp/ut-msgs("show",15825,"N�o encontrado nenhuma AVA~~Nenhum registro de Acerto de Valor a Menor foi encontrado").
        RETURN "NOK".
    END.

    FOR EACH tt-digita WHERE tt-digita.ntipo = 1:
        FIND tt-avas   WHERE tt-avas.titulo = tt-digita.titulo
                         AND tt-avas.serie  = tt-digita.serie NO-ERROR.
        IF NOT AVAIL tt-avas THEN DO:
            CREATE tt-avas.
            ASSIGN tt-avas.titulo = tt-digita.titulo
                   tt-avas.serie  = tt-digita.serie 
                   tt-avas.valor  = tt-digita.valor.
        END.
        ELSE DO:
            ASSIGN tt-avas.valor  = tt-avas.valor + tt-digita.valor.
        END.
    END.

    FOR EACH tt-digita WHERE tt-digita.ntipo = 1:

        IF tt-digita.titulo =  tituloComErro
        AND tt-digita.serie =  serieComErro  THEN
            NEXT.

        IF tt-digita.titulo <> tituloAnterior 
        AND tt-digita.serie <> serieAnterior THEN DO:
            FIND FIRST tit_acr WHERE (tit_acr.cod_estab      = "L30" OR tit_acr.cod_estab = "A14") /* tt-param.codEstabel */
                                 AND tit_acr.cod_espec_docto = "DP"
                                 AND tit_acr.cod_ser_docto   = tt-digita.serie
                                 AND tit_acr.cod_tit_acr     = tt-digita.titulo
                                 AND tit_acr.cod_parcela     = '01' NO-LOCK NO-ERROR.
            IF NOT AVAIL tit_acr THEN DO:
                RUN pi-erros(tt-digita.titulo,tt-digita.serie,tt-digita.valor,0,0,0,"N�o encontrado").
                NEXT.
            END.
            ELSE DO:
                FIND tt-avas WHERE tt-avas.titulo = tt-digita.titulo
                               AND tt-avas.serie  = tt-digita.serie   NO-LOCK NO-ERROR.
                IF AVAIL tt-avas THEN DO:

                    IF tit_acr.val_sdo_tit_acr <= tt-avas.valor THEN DO:
                        RUN pi-erros(tt-digita.titulo,
                                     tt-digita.serie,
                                     tt-digita.valor,
                                     tit_acr.val_origin_tit_acr,
                                     tt-avas.valor,
                                     tit_acr.val_sdo_tit_acr,
                                     "saldo insuficiente para os AVAs").
                    END.
                END.
            END.
        END.

        RUN pi-check-movto("PRE","AVMN",tt-digita.valor,ROWID(tt-digita),ROWID(tit_acr)).  
        IF RETURN-VALUE <> "OK" THEN
            NEXT.

        EMPTY TEMP-TABLE tt_alter_tit_acr_base_4        NO-ERROR.
        EMPTY TEMP-TABLE tt_alter_tit_acr_rateio        NO-ERROR.
        EMPTY TEMP-TABLE tt_alter_tit_acr_ped_vda       NO-ERROR.
        EMPTY TEMP-TABLE tt_alter_tit_acr_comis_1       NO-ERROR.
        EMPTY TEMP-TABLE tt_alter_tit_acr_cheq          NO-ERROR.
        EMPTY TEMP-TABLE tt_alter_tit_acr_iva           NO-ERROR.
        EMPTY TEMP-TABLE tt_alter_tit_acr_impto_retid_2 NO-ERROR.
        EMPTY TEMP-TABLE tt_alter_tit_acr_cobr_espec_2  NO-ERROR.
        EMPTY TEMP-TABLE tt_alter_tit_acr_rat_desp_rec  NO-ERROR.
        EMPTY TEMP-TABLE tt_log_erros_alter_tit_acr     NO-ERROR.
        EMPTY TEMP-TABLE tt_alter_tit_acr_cobr_esp_2_c  NO-ERROR. 
        EMPTY TEMP-TABLE tt_params_generic_api          NO-ERROR.      

        ASSIGN v_log_refer_uni = NO.

        RUN pi-acompanhar IN h-acomp ("AVA MENOR TITULO - TITULO " + tt-digita.titulo +
                                      " - " + tt-digita.serie + ":" + string(tt-digita.valor,"->,>>>,>>9.99")). 

        REPEAT WHILE NOT v_log_refer_uni:
            RUN pi-referencia
                (INPUT "P",
                INPUT TODAY,
                OUTPUT v_cod_refer).
            RUN pi-verificaReferencia
                (INPUT tit_acr.cod_estab,   
                INPUT v_cod_refer,          
                INPUT "lote_impl_tit_acr",  
                INPUT ?,                    
                OUTPUT v_log_refer_uni).    
        END.

        CREATE tt_alter_tit_acr_base_4.
        ASSIGN tt_alter_tit_acr_base_4.tta_cod_estab                   = tit_acr.cod_estab
               tt_alter_tit_acr_base_4.tta_num_id_tit_acr              = tit_acr.num_id_tit_acr
               tt_alter_tit_acr_base_4.tta_dat_transacao               = tt-param.datTransacao
               tt_alter_tit_acr_base_4.tta_cod_refer                   = v_cod_refer
               tt_alter_tit_acr_base_4.tta_cod_portador                = tit_acr.cod_portador
               tt_alter_tit_acr_base_4.tta_cod_cart_bcia               = tit_acr.cod_cart_bcia
               tt_alter_tit_acr_base_4.tta_val_sdo_tit_acr             = tit_acr.val_sdo_tit_acr - tt-digita.valor
               tt_alter_tit_acr_base_4.tta_cod_portador                = tit_acr.cod_portador
               tt_alter_tit_acr_base_4.tta_cod_cart_bcia               = tit_acr.cod_cart_bcia
               tt_alter_tit_acr_base_4.tta_val_despes_bcia             = ?
               tt_alter_tit_acr_base_4.tta_cod_agenc_cobr_bcia         = ?
               tt_alter_tit_acr_base_4.tta_cod_tit_acr_bco             = ?
               tt_alter_tit_acr_base_4.tta_dat_emis_docto              = tit_acr.dat_emis_docto
               tt_alter_tit_acr_base_4.tta_dat_vencto_tit_acr          = tit_acr.dat_vencto_tit_acr
               tt_alter_tit_acr_base_4.tta_dat_prev_liquidac           = tit_acr.dat_prev_liquidac
               tt_alter_tit_acr_base_4.tta_dat_fluxo_tit_acr           = &IF "{&ems_dbtype}":U = "MSS":U &THEN 01/01/1800 &ELSE 01/01/0001 &ENDIF
               tt_alter_tit_acr_base_4.tta_ind_sit_tit_acr             = ?
               tt_alter_tit_acr_base_4.tta_cod_cond_cobr               = tit_acr.cod_cond_cobr
               tt_alter_tit_acr_base_4.tta_log_tip_cr_perda_dedut_tit  = ?
               tt_alter_tit_acr_base_4.ttv_cod_portador_mov            = ?
               tt_alter_tit_acr_base_4.tta_ind_tip_cobr_acr            = ?
               tt_alter_tit_acr_base_4.tta_dat_abat_tit_acr            = &IF "{&ems_dbtype}":U = "MSS":U &THEN 01/01/1800 &ELSE 01/01/0001 &ENDIF
               tt_alter_tit_acr_base_4.tta_val_perc_abat_acr           = ?
               tt_alter_tit_acr_base_4.tta_val_abat_tit_acr            = ?
               tt_alter_tit_acr_base_4.tta_dat_desconto                = tit_acr.dat_desconto
               tt_alter_tit_acr_base_4.tta_val_perc_desc               = tit_acr.val_perc_desc
               tt_alter_tit_acr_base_4.tta_val_desc_tit_acr            = tit_acr.val_desc_tit_acr
               tt_alter_tit_acr_base_4.tta_qtd_dias_carenc_juros_acr   = tit_acr.qtd_dias_carenc_juros_acr
               tt_alter_tit_acr_base_4.tta_val_perc_juros_dia_atraso   = tit_acr.val_perc_juros_dia_atraso
               tt_alter_tit_acr_base_4.tta_qtd_dias_carenc_multa_acr   = tit_acr.qtd_dias_carenc_multa_acr
               tt_alter_tit_acr_base_4.tta_val_perc_multa_atraso       = tit_acr.val_perc_multa_atraso
               tt_alter_tit_acr_base_4.tta_ind_ender_cobr              = ?
               tt_alter_tit_acr_base_4.tta_nom_abrev_contat            = ?
               tt_alter_tit_acr_base_4.tta_val_liq_tit_acr             = tit_acr.val_liq_tit_acr
               tt_alter_tit_acr_base_4.tta_cod_instruc_bcia_1_movto    = ?
               tt_alter_tit_acr_base_4.tta_cod_instruc_bcia_2_movto    = ?
               tt_alter_tit_acr_base_4.tta_cod_histor_padr             = ?
               tt_alter_tit_acr_base_4.ttv_des_text_histor             = ?
               tt_alter_tit_acr_base_4.tta_des_obs_cobr                = ?
               tt_alter_tit_acr_base_4.tta_log_tit_acr_destndo         = tit_acr.log_tit_acr_destndo
               tt_alter_tit_acr_base_4.ttv_cod_cond_pagto_vendor       = ?
               tt_alter_tit_acr_base_4.ttv_dat_base_fechto_vendor      = ?.

        RUN pi_retornar_finalid_indic_econ (INPUT tit_acr.cod_indic_econ,
        INPUT TODAY,
        OUTPUT v_cod_finalid_econ).


        FOR EACH val_tit_acr NO-LOCK
            WHERE val_tit_acr.cod_estab        = tit_acr.cod_estab
            AND   val_tit_acr.num_id_tit_acr   = tit_acr.num_id_tit_acr
            AND   val_tit_acr.cod_finalid_econ = v_cod_finalid_econ:

            CREATE tt_alter_tit_acr_rateio.

            ASSIGN
                tt_alter_tit_acr_rateio.tta_cod_estab                   = tit_acr.cod_estab
                tt_alter_tit_acr_rateio.tta_num_id_tit_acr              = tit_acr.num_id_tit_acr
                tt_alter_tit_acr_rateio.ttv_ind_tip_rat_tit_acr         = "Altera��o" /*l_alteracao*/
                tt_alter_tit_acr_rateio.tta_cod_refer                   = v_cod_refer
                tt_alter_tit_acr_rateio.tta_num_seq_refer               = 10
                tt_alter_tit_acr_rateio.tta_cod_plano_cta_ctbl          = "Primario"
                tt_alter_tit_acr_rateio.tta_cod_cta_ctbl                = tt-param.ctaDesconto
                tt_alter_tit_acr_rateio.tta_cod_unid_negoc              = val_tit_acr.cod_unid_negoc
                tt_alter_tit_acr_rateio.tta_cod_plano_ccusto            = ""
                tt_alter_tit_acr_rateio.tta_cod_ccusto                  = ""
                tt_alter_tit_acr_rateio.tta_cod_tip_fluxo_financ        = val_tit_acr.cod_tip_fluxo_financ
                tt_alter_tit_acr_rateio.tta_dat_transacao               = tt_alter_tit_acr_base_4.tta_dat_transacao
                tt_alter_tit_acr_rateio.tta_num_seq_aprop_ctbl_pend_acr = v_seq_refer
                tt_alter_tit_acr_rateio.tta_val_aprop_ctbl              = ROUND(val_tit_acr.val_sdo_tit_acr * (tt-digita.valor / tit_acr.val_sdo_tit_acr), 2).

            ASSIGN
                v_seq_refer = v_seq_refer + 10.
        END.
        RUN pi-executa-api-ava.



    END.

END PROCEDURE.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF

&IF DEFINED(EXCLUDE-pi-baixas) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE pi-baixas Procedure 
PROCEDURE pi-baixas :
/*------------------------------------------------------------------------------
  Purpose:  Processa as baixas dos t�tulos contra a Antecipa��o   
  Parameters:  <none>
  Notes:       
------------------------------------------------------------------------------*/

    RUN pi-seta-titulo IN h-acomp (INPUT "Processando BAIXAS").

    IF NOT CAN-FIND(FIRST tt-digita WHERE tt-digita.ntipo = 1) THEN DO:
        RUN utp/ut-msgs("show",15825,"N�o encontrado nenhuma BAIXA~~Nenhum registro de Baixa foi encontrado").
        RETURN "NOK".
    END.

    ASSIGN v_seq = 0.

    FOR EACH tt-digita WHERE tt-digita.ntipo = 3:
        ASSIGN tt-digita.valor = ABS(tt-digita.valor).

        FIND estabelecimento WHERE estabelecimento.cod_estab = tt-param.codEstab NO-LOCK NO-ERROR.

        FIND tit_acr WHERE (tit_acr.cod_estab = 'L30' OR tit_acr.cod_estab = 'A14') /* tt-param.codEstabel */
               AND tit_acr.cod_espec_docto    = "DP"                        
               AND tit_acr.cod_ser_docto      = tt-digita.serie             
               AND tit_acr.cod_tit_acr        = tt-digita.titulo            
               AND tit_acr.cod_parcela        = '01' NO-LOCK NO-ERROR.  
        IF NOT AVAIL tit_acr THEN DO:
            RUN pi-erros(tt-digita.titulo,tt-digita.serie,tt-digita.valor,0,0,0,"N�o encontrado titulo para Baixa").
            ASSIGN tt-digita.valido = NO.
            NEXT.
        END.

        IF tt-digita.valor <> tit_acr.val_sdo_tit_acr THEN DO:
            RUN pi-erros(tt-digita.titulo,tt-digita.serie,tt-digita.valor,0,0,tit_acr.val_sdo_tit_acr,"Saldo do Titulo n�o bate com a planilha").
            ASSIGN tt-digita.valido = NO.
            NEXT.
        END.

        RUN pi-check-movto("PRE","LIQ",tt-digita.valor,ROWID(tt-digita),ROWID(tit_acr)).  
        IF RETURN-VALUE <> "OK" THEN DO:
            ASSIGN tt-digita.valido = NO.
            NEXT.
        END.
        ASSIGN tt-digita.valido = YES
               tt-digita.tit_rowid = ROWID(tit_acr).
    END.

    ASSIGN v_log_refer_uni = no
           v_cod_refer     = "".

    REPEAT WHILE NOT v_log_refer_uni:
        RUN pi-referencia
            (INPUT "P",
            INPUT TODAY,
            OUTPUT v_cod_refer).
        RUN pi-verificaReferencia
            (INPUT tit_acr.cod_estab,   
            INPUT v_cod_refer,          
            INPUT "lote_impl_tit_acr",  
            INPUT ?,                    
            OUTPUT v_log_refer_uni).    
    END.

    EMPTY TEMP-TABLE tt_integr_acr_liquidac_lote.
    EMPTY TEMP-TABLE tt_integr_acr_liq_item_lote_3.
    EMPTY TEMP-TABLE tt_integr_acr_abat_antecip.
    EMPTY TEMP-TABLE tt_integr_acr_abat_prev.
    EMPTY TEMP-TABLE tt_integr_acr_cheq.
    EMPTY TEMP-TABLE tt_integr_acr_liquidac_impto_2.
    EMPTY TEMP-TABLE tt_integr_acr_rel_pend_cheq.
    EMPTY TEMP-TABLE tt_integr_acr_liq_aprop_ctbl.
    EMPTY TEMP-TABLE tt_integr_acr_liq_desp_rec.
    EMPTY TEMP-TABLE tt_integr_acr_aprop_liq_antec.
    EMPTY TEMP-TABLE tt_log_erros_import_liquidac.
    EMPTY TEMP-TABLE tt_integr_cambio_ems5.
    EMPTY TEMP-TABLE tt_params_generic_api.

    ASSIGN v_log_refer_uni = NO.

    /* Cria��o do lote de liquida��o*/
    CREATE tt_integr_acr_liquidac_lote.
    ASSIGN tt_integr_acr_liquidac_lote.tta_cod_empresa                 = estabelecimento.cod_empresa
           tt_integr_acr_liquidac_lote.tta_cod_estab_refer             = estabelecimento.cod_estab
           tt_integr_acr_liquidac_lote.tta_cod_usuario                 = tt-param.usuario
           tt_integr_acr_liquidac_lote.tta_dat_gerac_lote_liquidac     = tt-param.datTransacao
           tt_integr_acr_liquidac_lote.tta_ind_tip_liquidac_acr        = "Lote"
           tt_integr_acr_liquidac_lote.ttv_log_atualiz_refer           = YES
           tt_integr_acr_liquidac_lote.ttv_rec_lote_liquidac_acr       = RECID(tt_integr_acr_liquidac_lote)
           tt_integr_acr_liquidac_lote.tta_cod_refer                   = v_cod_refer
           v_seq = 0.


    FOR EACH tt-digita WHERE tt-digita.ntipo = 3 AND tt-digita.valido = YES:

        FIND tit_acr WHERE ROWID(tit_acr) = tt-digita.tit_rowid NO-LOCK NO-ERROR.
        IF NOT AVAIL tit_acr THEN DO:
            RETURN ERROR.
        END.

        RUN pi-acompanhar IN h-acomp ("BAIXA DO TITULO - TITULO " + tt-digita.titulo +
                              " - " + tt-digita.serie + ":" + string(abs(tt-digita.valor),"->,>>>,>>9.99")). 

        FIND FIRST tt_integr_acr_liquidac_lote NO-LOCK NO-ERROR.  

        FIND FIRST emscad.portador NO-LOCK WHERE emscad.portador.cod_portador = tit_acr.cod_portador NO-ERROR.
        
        ASSIGN v_seq = v_seq + 10.
        /* Cria��o do item do lote de liquida��o */
        CREATE tt_integr_acr_liq_item_lote_3.
        ASSIGN tt_integr_acr_liq_item_lote_3.tta_des_text_histor                = tit_acr.cod_portador + " - " + v_cod_refer /* IF AVAIL emscad.portador THEN emscad.portador.nom_pessoa ELSE "" */
               tt_integr_acr_liq_item_lote_3.tta_num_seq_refer                  = v_seq
               tt_integr_acr_liq_item_lote_3.tta_cod_empresa                    = tit_acr.cod_empresa
               tt_integr_acr_liq_item_lote_3.tta_cod_estab                      = tit_acr.cod_estab
               tt_integr_acr_liq_item_lote_3.tta_cod_espec_docto                = tit_acr.cod_espec_docto
               tt_integr_acr_liq_item_lote_3.tta_cod_ser_docto                  = tit_acr.cod_ser_docto
               tt_integr_acr_liq_item_lote_3.tta_cod_tit_acr                    = tit_acr.cod_tit_acr
               tt_integr_acr_liq_item_lote_3.tta_cod_parcela                    = tit_acr.cod_parcela
               tt_integr_acr_liq_item_lote_3.tta_cdn_cliente                    = tit_acr.cdn_cliente
               tt_integr_acr_liq_item_lote_3.tta_cod_portador                   = tit_acr.cod_portador
               tt_integr_acr_liq_item_lote_3.tta_cod_cart_bcia                  = tit_acr.cod_cart_bcia
               tt_integr_acr_liq_item_lote_3.tta_cod_finalid_econ               = "Corrente"
               tt_integr_acr_liq_item_lote_3.tta_cod_indic_econ                 = "real"
               tt_integr_acr_liq_item_lote_3.tta_val_tit_acr                    = tit_acr.val_sdo_tit_acr  
               tt_integr_acr_liq_item_lote_3.tta_val_juros                      = 0
               tt_integr_acr_liq_item_lote_3.tta_val_desc_tit_acr               = 0
               tt_integr_acr_liq_item_lote_3.tta_val_liquidac_tit_acr           = tit_acr.val_sdo_tit_acr
               tt_integr_acr_liq_item_lote_3.tta_val_cotac_indic_econ           = 1
               tt_integr_acr_liq_item_lote_3.tta_val_abat_tit_acr               = 0
               tt_integr_acr_liq_item_lote_3.ttv_rec_lote_liquidac_acr          = tt_integr_acr_liquidac_lote.ttv_rec_lote_liquidac_acr
               tt_integr_acr_liq_item_lote_3.ttv_rec_item_lote_liquidac_acr     = RECID(tt_integr_acr_liq_item_lote_3)
               tt_integr_acr_liq_item_lote_3.tta_ind_tip_item_liquidac_acr      = "Pagamento"
               tt_integr_acr_liq_item_lote_3.tta_dat_cr_liquidac_tit_acr        = tt-param.datTransacao 
               tt_integr_acr_liq_item_lote_3.tta_dat_cr_liquidac_calc           = tt-param.datTransacao
               tt_integr_acr_liq_item_lote_3.tta_dat_liquidac_tit_acr           = tt-param.datTransacao 
               tt_integr_acr_liquidac_lote.tta_dat_transacao                    = tt-param.datTransacao
               tt_integr_acr_liquidac_lote.tta_dat_gerac_lote_liquidac          = tt_integr_acr_liq_item_lote_3.tta_dat_cr_liquidac_tit_acr.

        CREATE ttSucesso.
        ASSIGN ttSucesso.estab                                                  = tit_acr.cod_estab                        
               ttSucesso.espec                                                  = tit_acr.cod_espec_docto                 
               ttSucesso.titulo                                                 = tit_acr.cod_tit_acr                     
               ttSucesso.serie                                                  = tit_acr.cod_ser_docto                   
               ttSucesso.parcela                                                = tit_acr.cod_parcela                     
               ttSucesso.transacao                                              = tt-param.datTransacao             
               ttSucesso.movimento                                              = "Liquida��o"          
               ttSucesso.valor                                                  = tt-digita.valor         
               ttSucesso.mensagem                                               = "Baixa efetuada com sucesso".

        FOR FIRST tt_tit_antecip:
               CREATE tt_integr_acr_abat_antecip.
               ASSIGN tt_integr_acr_abat_antecip.ttv_rec_item_lote_impl_tit_acr  = RECID(tt_integr_acr_liq_item_lote_3)
                      tt_integr_acr_abat_antecip.ttv_rec_abat_antecip_acr        = RECID(tt_integr_acr_abat_antecip)
                      tt_integr_acr_abat_antecip.tta_cod_estab                   = tt_tit_antecip.cod_estab
                      tt_integr_acr_abat_antecip.tta_cod_espec_docto             = tt_tit_antecip.cod_espec_docto
                      tt_integr_acr_abat_antecip.tta_cod_ser_docto               = tt_tit_antecip.cod_ser_docto
                      tt_integr_acr_abat_antecip.tta_cod_tit_acr                 = tt_tit_antecip.cod_tit_acr
                      tt_integr_acr_abat_antecip.tta_cod_parcela                 = tt_tit_antecip.cod_parcela
                      tt_integr_acr_abat_antecip.tta_val_abtdo_antecip_tit_abat  = tit_acr.val_sdo_tit_acr. 
        END.
    END.
    RUN pi-executa-api-baixa.

END PROCEDURE.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF

&IF DEFINED(EXCLUDE-pi-check-movto) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE pi-check-movto Procedure 
PROCEDURE pi-check-movto :
/*------------------------------------------------------------------------------
  Purpose:     
  Parameters:  <none>
  Notes:       
------------------------------------------------------------------------------*/
DEFINE INPUT PARAM acao   AS CHAR.
DEFINE INPUT PARAM tran   AS CHAR.
DEFINE INPUT PARAM valor  LIKE tt-digita.valor.
DEFINE INPUT PARAM recRow AS ROWID.
DEFINE INPUT PARAM titRow AS ROWID.

    FIND b-digita  WHERE ROWID(b-digita)  = recRow NO-LOCK NO-ERROR.
    FIND b-tit_acr WHERE ROWID(b-tit_acr) = titRow NO-LOCK NO-ERROR.
    FIND FIRST movto_tit_acr    OF b-tit_acr
                             WHERE movto_tit_acr.ind_trans_acr_abrev = tran
                               AND movto_tit_acr.val_movto_tit_acr = valor NO-LOCK NO-ERROR.
    IF AVAIL movto_tit_acr THEN DO:
        IF acao = "pre" THEN DO:
            RUN pi-erros(b-digita.titulo,
                         b-digita.serie,
                         b-digita.valor,
                         b-tit_acr.val_origin_tit_acr,
                         movto_tit_acr.val_movto_tit_acr,
                         b-tit_acr.val_sdo_tit_acr,
                         tran + " j� executada em " + STRING(movto_tit_acr.dat_transacao,"99/99/9999")).
            RETURN "NOK".
        END.
        ELSE DO:
            CREATE ttSucesso.
            ASSIGN ttSucesso.estab     = b-tit_acr.cod_estab
                   ttSucesso.espec     = b-tit_acr.cod_espec_docto
                   ttSucesso.titulo    = b-tit_acr.cod_tit_acr
                   ttSucesso.serie     = b-tit_acr.cod_ser_docto
                   ttSucesso.parcela   = b-tit_acr.cod_parcela
                   ttSucesso.transacao = movto_tit_acr.dat_transacao
                   ttSucesso.movimento = movto_tit_acr.ind_trans_acr
                   ttSucesso.valor     = movto_tit_acr.val_movto_tit_acr
                   ttSucesso.mensagem  = movto_tit_acr.ind_trans_acr_abrev + " realizado(a) com sucesso".
            RETURN "OK".
        END.
    END.
    ELSE DO:
        IF acao = "POS" THEN DO:
            RUN pi-erros(b-digita.titulo,
                         b-digita.serie,
                         b-digita.valor,
                         b-tit_acr.val_origin_tit_acr,
                         0,
                         b-tit_acr.val_sdo_tit_acr,
                         "Erro na geracao de " + tran).
            RETURN "NOK".
        END.
        ELSE RETURN "OK".
    END.

END PROCEDURE.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF

&IF DEFINED(EXCLUDE-pi-erros) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE pi-erros Procedure 
PROCEDURE pi-erros :
/*------------------------------------------------------------------------------
  Purpose:     
  Parameters:  <none>
  Notes:       
------------------------------------------------------------------------------*/
DEFINE INPUT PARAM titulo   LIKE tt-digita.titulo.
DEFINE INPUT PARAM serie    LIKE tt-digita.serie.
DEFINE INPUT PARAM valInfo  LIKE tt-digita.valor.
DEFINE INPUT PARAM valTit   LIKE tit_acr.val_origin_tit_acr.
DEFINE INPUT PARAM valAvas  LIKE tt-digita.valor.
DEFINE INPUT PARAM valSaldo LIKE tit_acr.val_sdo_tit_acr.
DEFINE INPUT PARAM erro   AS   CHAR.

    CREATE ttComErros.
    ASSIGN ttComErros.cod_tit_acr        = titulo
           ttComErros.cod_ser_docto      = serie
           ttComErros.erro               = erro
           ttComErros.val_informado      = valInfo
           ttComErros.val_origin_tit_acr = valTit 
           ttComErros.val_avas           = valAvas
           ttComErros.val_sdo_tit_acr    = valSaldo
           tituloComErro                 = titulo
           serieComErro                  = serie.

END PROCEDURE.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF

&IF DEFINED(EXCLUDE-pi-executa-api-ava) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE pi-executa-api-ava Procedure 
PROCEDURE pi-executa-api-ava :
/*------------------------------------------------------------------------------
  Purpose:     
  Parameters:  <none>
  Notes:       
------------------------------------------------------------------------------*/
    RUN prgfin/acr/acr711zv.py PERSISTENT SET v_hdl_program.

    RUN pi_main_code_integr_acr_alter_tit_acr_novo_8 IN v_hdl_program
        (INPUT  5,
        INPUT  table tt_alter_tit_acr_base_4,
        INPUT  table tt_alter_tit_acr_rateio,
        INPUT  table tt_alter_tit_acr_ped_vda,
        INPUT  table tt_alter_tit_acr_comis_1,
        INPUT  table tt_alter_tit_acr_cheq,
        INPUT  table tt_alter_tit_acr_iva,
        INPUT  table tt_alter_tit_acr_impto_retid_2,
        INPUT  table tt_alter_tit_acr_cobr_espec_2,
        INPUT  table tt_alter_tit_acr_rat_desp_rec,
        OUTPUT table tt_log_erros_alter_tit_acr,
        INPUT  YES).

    DELETE PROCEDURE v_hdl_program.
    
    FOR EACH tt_log_erros_alter_tit_acr:    
        CREATE ttComErros.
        ASSIGN ttComErros.cod_tit_acr        = tt-digita.titulo
               ttComErros.cod_ser_docto      = tt-digita.serie
               ttComErros.erro               = tt_log_erros_alter_tit_acr.ttv_des_msg_erro 
               ttComErros.val_informado      = tt-digita.valor 
               ttComErros.val_origin_tit_acr = tit_acr.val_origin_tit_acr 
               ttComErros.val_avas           = tt-digita.valor
               ttComErros.val_sdo_tit_acr    = tit_acr.val_sdo_tit_acr.
    END.

    IF NOT can-find(FIRST tt_log_erros_alter_tit_acr) THEN DO:
        RUN pi-check-movto("POS","AVMN",tt-digita.valor,ROWID(tt-digita),ROWID(tit_acr)).
    END.

END PROCEDURE.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF

&IF DEFINED(EXCLUDE-pi-executa-api-baixa) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE pi-executa-api-baixa Procedure 
PROCEDURE pi-executa-api-baixa :
/*------------------------------------------------------------------------------
  Purpose:     
  Parameters:  <none>
  Notes:       
------------------------------------------------------------------------------*/
    RUN prgfin/acr/acr901zf.py persistent set v_hdl_aux.

    RUN pi_main_code_api_integr_acr_liquidac_6 in v_hdl_aux (Input 1,
                                                             input table tt_integr_acr_liquidac_lote,
                                                             input table tt_integr_acr_liq_item_lote_3,
                                                             input table tt_integr_acr_abat_antecip,
                                                             input table tt_integr_acr_abat_prev,
                                                             input table tt_integr_acr_cheq,
                                                             input table tt_integr_acr_liquidac_impto_2,
                                                             input table tt_integr_acr_rel_pend_cheq,
                                                             input table tt_integr_acr_liq_aprop_ctbl,
                                                             input table tt_integr_acr_liq_desp_rec,
                                                             input table tt_integr_acr_aprop_liq_antec,
                                                             input 'EMS2', /*Matriz de tradu��o*/
                                                             output table tt_log_erros_import_liquidac,
                                                             input table tt_integr_cambio_ems5,
                                                             input table tt_params_generic_api).


    FOR EACH tt_log_erros_import_liquidac:
        MESSAGE ttv_num_erro_log SKIP
                ttv_des_msg_erro VIEW-AS ALERT-BOX.

        CREATE ttComErros.
        ASSIGN ttComErros.cod_tit_acr        = tt_log_erros_import_liquidac.tta_cod_tit_acr 
               ttComErros.cod_ser_docto      = tt_log_erros_import_liquidac.tta_cod_ser_docto
               ttComErros.erro               = tt_log_erros_import_liquidac.ttv_des_msg_erro 
               ttComErros.val_informado      = 0
               ttComErros.val_origin_tit_acr = 0
               ttComErros.val_avas           = 0
               ttComErros.val_sdo_tit_acr    = 0.

        FIND FIRST ttSucesso WHERE ttSucesso.titulo = tt_log_erros_import_liquidac.tta_cod_tit_acr 
                               AND ttSucesso.serie  = tt_log_erros_import_liquidac.tta_cod_ser_docto NO-ERROR.
        IF AVAIL ttSucesso THEN
            ASSIGN ttSucesso.mensagem        = "Erro no processamento da Baixa".
    END.

    DELETE PROCEDURE v_hdl_aux.

END PROCEDURE.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF

&IF DEFINED(EXCLUDE-pi-processar) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE pi-processar Procedure 
PROCEDURE pi-processar :
/*------------------------------------------------------------------------------
  Purpose:     
  Parameters:  <none>
  Notes:       
------------------------------------------------------------------------------*/
    FIND tit_acr WHERE ROWID(tit_acr) = tt-param.rowidAntecipacao NO-LOCK NO-ERROR.
    IF NOT AVAIL tit_acr THEN DO:
        RUN utp/ut-msgs("show",15825,"Processamento Cancelado~~N�o encontrada a Antecipa��o").
        RETURN "NOK".
    END.
    ELSE DO:
        EMPTY TEMP-TABLE tt_tit_antecip.
        CREATE tt_tit_antecip.
        BUFFER-COPY tit_acr TO tt_tit_antecip.
    END.
    
    RUN utp/ut-acomp.p PERSISTENT SET h-acomp.
    RUN pi-inicializar IN h-acomp (INPUT "Processando").

    RUN pi-avas.

    RUN pi-baixas.

    RUN pi-finalizar IN h-acomp.

END PROCEDURE.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF

&IF DEFINED(EXCLUDE-pi-referencia) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE pi-referencia Procedure 
PROCEDURE pi-referencia :
/*------------------------------------------------------------------------------
  Purpose:     
  Parameters:  <none>
  Notes:       
------------------------------------------------------------------------------*/

    /************************ Parameter Definition Begin ************************/
    DEFINE INPUT  PARAMETER p_ind_tip_atualiz   AS CHARACTER   FORMAT "X(08)"         NO-UNDO.
    DEFINE INPUT  PARAMETER p_dat_refer         AS DATE        FORMAT "99/99/9999"    NO-UNDO.
    DEFINE OUTPUT PARAMETER p_cod_refer         AS CHARACTER   FORMAT "x(10)"         NO-UNDO.
    /************************* Parameter Definition End *************************/

    /************************* Variable Definition Begin ************************/
    DEFINE VARIABLE v_des_dat   AS CHARACTER NO-UNDO.
    DEFINE VARIABLE v_num_aux   AS INTEGER   NO-UNDO.
    DEFINE VARIABLE v_num_aux_2 AS INTEGER   NO-UNDO.
    DEFINE VARIABLE v_num_cont  AS INTEGER   NO-UNDO.
    /************************** Variable Definition End *************************/

    ASSIGN 
        v_des_dat   = STRING(p_dat_refer,"99999999")
        p_cod_refer = SUBSTRING(v_des_dat,7,2) +
                      substring(v_des_dat,3,2) +
                      substring(v_des_dat,1,2) +
                      substring(p_ind_tip_atualiz,1,1)
        v_num_aux_2 = INTEGER(THIS-PROCEDURE:HANDLE).

    DO  v_num_cont = 1 TO 3:
        ASSIGN 
            v_num_aux   = (RANDOM(0, v_num_aux_2) MOD 26) + 97
            p_cod_refer = p_cod_refer + chr(v_num_aux).
    END.
END PROCEDURE.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF

&IF DEFINED(EXCLUDE-pi-resumo) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE pi-resumo Procedure 
PROCEDURE pi-resumo :
/*------------------------------------------------------------------------------
  Purpose:     
  Parameters:  <none>
  Notes:       
------------------------------------------------------------------------------*/
DEFINE INPUT PARAM estab       LIKE tit_acr.cod_estab.      
DEFINE INPUT PARAM espec_docto LIKE tit_acr.cod_espec_docto.
DEFINE INPUT PARAM tit_acr     LIKE tit_acr.cod_tit_acr.    
DEFINE INPUT PARAM ser_docto   LIKE tit_acr.cod_ser_docto.  
DEFINE INPUT PARAM parcela     LIKE tit_acr.cod_parcela.     

FOR FIRST tit_acr WHERE tit_acr.cod_estab       = estab       
                    AND tit_acr.cod_espec_docto = espec_docto 
                    AND tit_acr.cod_tit_acr     = tit_acr     
                    AND tit_acr.cod_ser_docto   = ser_docto   
                    AND tit_acr.cod_parcela     = parcela,    

    EACH movto_tit_acr OF tit_acr WHERE movto_tit_acr.ind_trans_acr BEGINS "Liquida��o":

    ASSIGN antec_estab       = tit_acr.cod_estab        
           antec_espec_docto = tit_acr.cod_espec_docto  
           antec_ser_docto   = tit_acr.cod_estab        
           antec_cod_tit_acr = tit_acr.cod_tit_acr      
           antec_cod_parcela = tit_acr.cod_parcela      
           antec_original    = tit_acr.val_origin_tit_acr
           antec_baixas      = antec_baixas + 1
           antec_vrBaixas    = antec_vrBaixas + movto_tit_acr.val_movto_tit_acr
           antec_vrSaldo     = tit_acr.val_sdo_tit_acr.  
                 
    FIND FIRST b_movto_tit_acr WHERE b_movto_tit_acr.cod_estab            = movto_tit_acr.cod_estab
                                 AND b_movto_tit_acr.num_id_movto_tit_acr = movto_tit_acr.num_id_movto_tit_acr_pai NO-LOCK NO-ERROR.
    IF AVAIL b_movto_tit_acr THEN DO:
        FIND FIRST b_tit_acr OF b_movto_tit_acr NO-LOCK NO-ERROR.
        IF AVAIL b_tit_acr THEN DO:
            FOR EACH b2_movto_tit_acr OF b_tit_acr:
                IF b2_movto_tit_acr.ind_trans_acr_abrev = "AVMN" THEN DO:
                    ASSIGN antec_descontos = antec_descontos + b2_movto_tit_acr.val_movto_tit_acr
                           antec_avas      = antec_avas + 1.
                END.
                IF b2_movto_tit_acr.ind_trans_acr_abrev = "IMPL" THEN DO:
                    ASSIGN antec_valor = antec_valor + b2_movto_tit_acr.val_movto_tit_acr
                           antec_titulos   = antec_titulos + 1.
                END.
            END.
        END.                                                                          
    END.
END.
    PAGE.
    DISPLAY  antec_estab      
             antec_espec_docto
             antec_ser_docto  
             antec_cod_tit_acr
             antec_cod_parcela
             antec_original   
             antec_titulos    
             antec_valor      
             antec_baixas     
             antec_vrBaixas   
             antec_vrSaldo    
             antec_avas       
             antec_descontos WITH FRAME f-antecipacao.
    DOWN WITH FRAME f-antecipacao.


END PROCEDURE.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF

&IF DEFINED(EXCLUDE-pi-verificaReferencia) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE pi-verificaReferencia Procedure 
PROCEDURE pi-verificaReferencia :
/*------------------------------------------------------------------------------
  Purpose:     
  Parameters:  <none>
  Notes:       
------------------------------------------------------------------------------*/
    /************************ Parameter Definition Begin ************************/
    DEFINE INPUT PARAMETER p_cod_estab           AS CHARACTER    FORMAT "x(3)"    NO-UNDO.
    DEFINE INPUT PARAMETER p_cod_refer           AS CHARACTER    FORMAT "x(10)"   NO-UNDO.
    DEFINE INPUT PARAMETER p_cod_table           AS CHARACTER    FORMAT "x(8)"    NO-UNDO.
    DEFINE INPUT PARAMETER p_rec_tabela          AS RECID        FORMAT ">>>>>>9" NO-UNDO.
    DEFINE OUTPUT PARAMETER p_log_refer_uni      AS LOGICAL      FORMAT "Sim/N�o" NO-UNDO.
    /************************* Parameter Definition End *************************/

    /************************** Buffer Definition Begin *************************/
    &if "{&emsfin_version}" >= "5.02" &then
    DEFINE BUFFER b_cobr_especial_acr FOR cobr_especial_acr.
    &endif
    &if "{&emsfin_version}" >= "5.01" &then
    DEFINE BUFFER b_lote_impl_tit_acr FOR lote_impl_tit_acr.
    &endif
    &if "{&emsfin_version}" >= "5.01" &then
    DEFINE BUFFER b_lote_liquidac_acr FOR lote_liquidac_acr.
    &endif
    &if "{&emsfin_version}" >= "5.01" &then
    DEFINE BUFFER b_movto_tit_acr     FOR movto_tit_acr.
    &endif
    &if "{&emsfin_version}" >= "5.01" &then
    DEFINE BUFFER b_operac_financ_acr FOR operac_financ_acr.
    &endif
    &if "{&emsfin_version}" >= "5.01" &then
    DEFINE BUFFER b_renegoc_acr       FOR renegoc_acr.
    &endif
    /*************************** Buffer Definition End **************************/

    /************************* Variable Definition Begin ************************/
    DEFINE VARIABLE v_cod_return      AS CHARACTER FORMAT "x(40)":U NO-UNDO.
    DEFINE VARIABLE v_log_utiliza_mbh AS LOGICAL   FORMAT "Sim/N�o" INITIAL NO NO-UNDO.
    /************************** Variable Definition End *************************/

    &if defined(BF_FIN_BCOS_HISTORICOS) &then
    ASSIGN 
        v_log_utiliza_mbh = NO.
    IF CAN-FIND(FIRST param_utiliz_produt
        WHERE param_utiliz_produt.cod_empresa = v_cod_empres_usuar
        AND   param_utiliz_produt.cod_modul_dtsul = "MBH" NO-LOCK) THEN 
    DO:
        ASSIGN 
            v_log_utiliza_mbh = YES.
    END.
    &endif

    ASSIGN 
        p_log_refer_uni = YES.

    IF  p_cod_table <> "lote_impl_tit_acr" /*l_lote_impl_tit_acr*/  THEN 
    DO:
        FIND FIRST b_lote_impl_tit_acr NO-LOCK
            WHERE b_lote_impl_tit_acr.cod_estab = p_cod_estab
            AND b_lote_impl_tit_acr.cod_refer = p_cod_refer
            AND recid( b_lote_impl_tit_acr ) <> p_rec_tabela
            USE-INDEX ltmplttc_id NO-ERROR.
        IF  AVAILABLE b_lote_impl_tit_acr THEN
            ASSIGN p_log_refer_uni = NO.
    END.

    IF  p_cod_table <> "lote_liquidac_acr" /*l_lote_liquidac_acr*/  THEN 
    DO:
        FIND FIRST b_lote_liquidac_acr NO-LOCK
            WHERE b_lote_liquidac_acr.cod_estab_refer = p_cod_estab
            AND b_lote_liquidac_acr.cod_refer       = p_cod_refer
            AND recid( b_lote_liquidac_acr )       <> p_rec_tabela
            USE-INDEX ltlqdccr_id NO-ERROR.
        IF  AVAILABLE b_lote_liquidac_acr THEN
            ASSIGN p_log_refer_uni = NO.
    END.

    IF  p_cod_table <> "Opera��o financeira" /*l_operacao_financ*/  THEN 
    DO:
        FIND FIRST b_operac_financ_acr NO-LOCK
            WHERE b_operac_financ_acr.cod_estab               = p_cod_estab
            AND b_operac_financ_acr.cod_movto_operac_financ = p_cod_refer
            AND recid( b_operac_financ_acr )               <> p_rec_tabela
            USE-INDEX oprcfnna_id NO-ERROR.
        IF  AVAILABLE b_operac_financ_acr THEN
            ASSIGN p_log_refer_uni = NO.
    END.

    IF  p_cod_table = 'cobr_especial_acr' THEN 
    DO:
        FIND FIRST b_cobr_especial_acr NO-LOCK
            WHERE b_cobr_especial_acr.cod_estab = p_cod_estab
            AND b_cobr_especial_acr.cod_refer = p_cod_refer
            AND recid( b_cobr_especial_acr ) <> p_rec_tabela
            USE-INDEX cbrspclc_id NO-ERROR.
        IF  AVAILABLE b_cobr_especial_acr THEN
            ASSIGN p_log_refer_uni = NO.
    END.

    IF  p_log_refer_uni = YES THEN 
    DO:
        FIND FIRST b_renegoc_acr NO-LOCK
            WHERE b_renegoc_acr.cod_estab = p_cod_estab
            AND   b_renegoc_acr.cod_refer = p_cod_refer
            AND   recid(b_renegoc_acr)   <> p_rec_tabela
            NO-ERROR.
        IF  AVAILABLE b_renegoc_acr THEN
            ASSIGN p_log_refer_uni = NO.
        ELSE 
        DO:
            FIND FIRST b_movto_tit_acr NO-LOCK
                WHERE b_movto_tit_acr.cod_estab = p_cod_estab
                AND b_movto_tit_acr.cod_refer = p_cod_refer
                AND recid(b_movto_tit_acr)   <> p_rec_tabela
                USE-INDEX mvtttcr_refer
                NO-ERROR.
            IF  AVAILABLE b_movto_tit_acr THEN
                ASSIGN p_log_refer_uni = NO.
        END.
    END.

    &if defined (BF_FIN_BCOS_HISTORICOS) &then
    IF  v_log_utiliza_mbh
        AND CAN-FIND (his_movto_tit_acr_histor NO-LOCK
        WHERE his_movto_tit_acr_histor.cod_estab = p_cod_estab
        AND   his_movto_tit_acr_histor.cod_refer = p_cod_refer)
        THEN 
    DO:

        ASSIGN 
            p_log_refer_uni = NO.
    END.
    &endif

END PROCEDURE.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF

&IF DEFINED(EXCLUDE-pi_retornar_finalid_indic_econ) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE pi_retornar_finalid_indic_econ Procedure 
PROCEDURE pi_retornar_finalid_indic_econ :
/*------------------------------------------------------------------------------
  Purpose:     
  Parameters:  <none>
  Notes:       
------------------------------------------------------------------------------*/
    DEFINE INPUT PARAMETER p_cod_indic_econ      AS CHARACTER        FORMAT "x(8)"        NO-UNDO.
    DEFINE INPUT PARAMETER p_dat_transacao       AS DATE             FORMAT "99/99/9999"  NO-UNDO.
    DEFINE OUTPUT PARAMETER p_cod_finalid_econ   AS CHARACTER        FORMAT "x(10)"       NO-UNDO.


    FIND FIRST histor_finalid_econ NO-LOCK
        WHERE histor_finalid_econ.cod_indic_econ         =  p_cod_indic_econ
        AND   histor_finalid_econ.dat_inic_valid_finalid <= p_dat_transacao
        AND   histor_finalid_econ.dat_fim_valid_finalid  >  p_dat_transacao
        NO-ERROR.
        
    IF  AVAILABLE histor_finalid_econ THEN 
        ASSIGN p_cod_finalid_econ = histor_finalid_econ.cod_finalid_econ.

END PROCEDURE.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF

/* ************************  Function Implementations ***************** */

&IF DEFINED(EXCLUDE-isnum) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _FUNCTION isnum Procedure 
FUNCTION isnum RETURNS LOGICAL
  ( INPUT param1 AS CHAR ) :
/*------------------------------------------------------------------------------
  Purpose:  
    Notes:  
------------------------------------------------------------------------------*/
DEF VAR i AS INT.
DEF VAR l AS LOGICAL.
  DO i = 1 TO LENGTH(param1):
      IF SUBSTR(param1,i,1) = '0'
      OR SUBSTR(param1,i,1) = '1'
      OR SUBSTR(param1,i,1) = '2'
      OR SUBSTR(param1,i,1) = '3'
      OR SUBSTR(param1,i,1) = '4'
      OR SUBSTR(param1,i,1) = '5'
      OR SUBSTR(param1,i,1) = '6'
      OR SUBSTR(param1,i,1) = '7'
      OR SUBSTR(param1,i,1) = '8'
      OR SUBSTR(param1,i,1) = '9' THEN
         ASSIGN l = YES.
      ELSE DO:
          ASSIGN l = NO.
          LEAVE.
      END.
  END.
  RETURN l.   /* Function return value. */

END FUNCTION.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF


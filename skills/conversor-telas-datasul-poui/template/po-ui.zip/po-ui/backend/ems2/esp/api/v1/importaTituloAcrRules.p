

BLOCK-LEVEL ON ERROR UNDO, THROW.

USING Progress.Json.ObjectModel.JsonObject.
USING Progress.Json.ObjectModel.JsonArray.

{esp/api/v1/importaTituloAcr.i}

{utp/ut-buffers-ems2.i}
{acr/esacr086rp.i}
{acr/esacr054.i}
{utp/utapi019.i2}

def temp-table ttz_ava_base_5 no-undo
    field tta_cod_estab                    as character format "x(3)"
    field tta_num_id_tit_acr               as integer format "9999999999" initial 0
    field tta_dat_transacao                as date format "99/99/9999" initial today
    field tta_cod_refer                    as character format "x(10)"
    field ttv_cod_motiv_movto_tit_acr_imp  as character format "x(8)"
    field tta_val_sdo_tit_acr              as decimal format ">>>,>>>,>>9.99" decimals 2 initial 0
    field ttv_cod_motiv_movto_tit_acr_alt  as character format "x(8)"
    field ttv_ind_motiv_acerto_val         as character format "X(12)" initial "Alterao"
    field tta_cod_portador                 as character format "x(5)"
    field tta_cod_cart_bcia                as character format "x(3)"
    field tta_val_despes_bcia              as decimal format "->>>,>>>,>>9.99" decimals 2 initial 0
    field tta_cod_agenc_cobr_bcia          as character format "x(10)"
    field tta_cod_tit_acr_bco              as character format "x(20)"
    field tta_dat_emis_docto               as date format "99/99/9999" initial today
    field tta_dat_vencto_tit_acr           as date format "99/99/9999" initial ?
    field tta_dat_prev_liquidac            as date format "99/99/9999" initial ?
    field tta_dat_fluxo_tit_acr            as date format "99/99/9999" initial ?
    field tta_ind_sit_tit_acr              as character format "X(13)" initial "Normal"
    field tta_cod_cond_cobr                as character format "x(8)"
    field tta_log_tip_cr_perda_dedut_tit   as logical format "Sim/No" initial no
    field tta_dat_abat_tit_acr             as date format "99/99/9999" initial ?
    field tta_val_perc_abat_acr            as decimal format ">>9.9999" decimals 4 initial 0
    field tta_val_abat_tit_acr             as decimal format ">>>>,>>>,>>9.99" decimals 2 initial 0
    field tta_dat_desconto                 as date format "99/99/9999" initial ?
    field tta_val_perc_desc                as decimal format ">9.9999" decimals 4 initial 0
    field tta_val_desc_tit_acr             as decimal format ">>>>,>>>,>>9.99" decimals 2 initial 0
    field tta_qtd_dias_carenc_juros_acr    as decimal format ">>9" initial 0
    field tta_val_perc_juros_dia_atraso    as decimal format ">9.999999" decimals 6 initial 00.00
    field tta_qtd_dias_carenc_multa_acr    as decimal format ">>9" initial 0
    field tta_val_perc_multa_atraso        as decimal format ">9.99" decimals 2 initial 00.00
    field ttv_cod_portador_mov             as character format "x(5)"
    field tta_ind_tip_cobr_acr             as character format "X(10)" initial "Normal"
    field tta_ind_ender_cobr               as character format "X(15)" initial "Cliente"
    field tta_nom_abrev_contat             as character format "x(15)"
    field tta_val_liq_tit_acr              as decimal format ">>>,>>>,>>9.99" decimals 2 initial 0
    field tta_cod_instruc_bcia_1_movto     as character format "x(4)"
    field tta_cod_instruc_bcia_2_movto     as character format "x(4)"
    field tta_log_tit_acr_destndo          as logical format "Sim/No" initial no
    field tta_cod_histor_padr              as character format "x(8)"
    field ttv_des_text_histor              as character format "x(2000)"
    field tta_des_obs_cobr                 as character format "x(40)"
    field ttv_wgh_lista                    as widget-handle extent 26 format ">>>>>>9"
    field tta_num_seq_tit_acr              as integer format ">>>9" initial 0
    field ttv_cod_estab_planilha           as character format "x(3)"
    field ttv_num_planilha_vendor          as integer format ">>>,>>>,>>9" initial 0
    field ttv_cod_cond_pagto_vendor        as character format "x(3)" initial "0"
    field ttv_val_cotac_tax_vendor_clien   as decimal format ">>9.9999999999" decimals 10
    field ttv_dat_base_fechto_vendor       as date format "99/99/9999" initial today
    field ttv_qti_dias_carenc_fechto       as Integer format "->>9"
    field ttv_log_assume_tax_bco           as logical format "Sim/No" initial no
    field ttv_log_vendor                   as logical format "Sim/No" initial no
    field tta_val_cr_pis                   as decimal format ">>>,>>>,>>9.99" decimals 2 initial 0
    field tta_val_cr_cofins                as decimal format ">>>,>>>,>>9.99" decimals 2 initial 0
    field tta_val_cr_csll                  as decimal format ">>>,>>>,>>9.99" decimals 2 initial 0
    field tta_val_base_calc_impto          as decimal format ">>>,>>>,>>9.99" decimals 2 initial 0
    field tta_log_retenc_impto_impl        as logical format "Sim/No" initial no
    field tta_cdn_repres                   as Integer format ">>>,>>9" initial 0
    field tta_cod_proces_export            as character format "x(12)"
    field ttv_log_estorn_impto_retid       as logical format "Sim/No" initial yes
    index tt_id                            is primary unique
          tta_cod_estab                    ascending
          tta_num_id_tit_acr               ascending
          tta_dat_transacao                ascending
          tta_num_seq_tit_acr              ascending.

          
DEFINE TEMP-TABLE tt-alvo NO-UNDO
    FIELD c-estab AS CHARACTER FIELD c-espec AS CHARACTER FIELD c-serie AS CHARACTER
    FIELD c-tit AS CHARACTER   FIELD c-parc AS CHARACTER
    FIELD c-port AS CHARACTER  FIELD c-cart AS CHARACTER
    FIELD d-saldo AS DECIMAL   FIELD d-juros AS DECIMAL FIELD d-multa AS DECIMAL
    FIELD dt-venc AS DATE
    INDEX ix-venc dt-venc.          
          
def temp-table ttz_ava_cheq no-undo
    field tta_cod_estab                    as character format "x(5)"
    field tta_num_id_tit_acr               as integer format "9999999999" initial 0
    field tta_cod_banco                    as character format "x(8)"
    field tta_cod_agenc_bcia               as character format "x(10)"
    field tta_cod_cta_corren_bco           as character format "x(20)"
    field tta_num_cheque                   as integer format ">>>>,>>>,>>9" initial ?
    field tta_dat_emis_cheq                as date format "99/99/9999" initial ?
    field tta_dat_prev_apres_cheq_acr      as date format "99/99/9999" initial ?
    field tta_dat_prev_cr_cheq_acr         as date format "99/99/9999" initial ?
    field tta_cod_id_feder                 as character format "x(20)" initial ?
    field tta_nom_emit                     as character format "x(40)"
    field tta_nom_cidad_emit               as character format "x(30)"
    field tta_log_cheq_terc                as logical format "Sim/No" initial no
    field tta_cod_usuar_cheq_acr_terc      as character format "x(12)"
    field tta_ind_dest_cheq_acr            as character format "X(15)" initial "Depsito"
    index tt_id                            is primary unique
          tta_cod_estab                    ascending
          tta_num_id_tit_acr               ascending
          tta_cod_banco                    ascending
          tta_cod_agenc_bcia               ascending
          tta_cod_cta_corren_bco           ascending
          tta_num_cheque                   ascending.

def temp-table ttz_ava_cobr_espec_2 no-undo
    field tta_cod_estab                    as character format "x(5)"
    field tta_num_id_tit_acr               as integer format "9999999999" initial 0
    field tta_num_seq_tit_acr              as integer format ">>>9" initial 0
    field tta_num_id_cobr_especial_acr     as integer format "99999999" initial 0
    field tta_val_tit_acr                  as decimal format ">>>,>>>,>>9.99" decimals 2 initial 0
    field tta_cod_portador                 as character format "x(5)"
    field tta_cod_cart_bcia                as character format "x(3)"
    field tta_cod_cartcred                 as character format "x(20)"
    field tta_cod_autoriz_cartao_cr        as character format "x(6)"
    field tta_cod_mes_ano_valid_cartao     as character format "XX/XXXX"
    field tta_dat_compra_cartao_cr         as date format "99/99/9999" initial ?
    field tta_cod_banco                    as character format "x(8)"
    field tta_cod_agenc_bcia               as character format "x(10)"
    field tta_cod_cta_corren_bco           as character format "x(20)"
    field tta_cod_digito_cta_corren        as character format "x(2)"
    field tta_num_ddd_localid_conces       as integer format "999" initial 0
    field tta_num_prefix_localid_conces    as integer format ">>>9" initial 0
    field tta_num_milhar_localid_conces    as integer format "9999" initial 0
    field tta_des_text_histor              as character format "x(2000)"
    field ttv_log_alter_tip_cobr_acr       as logical format "Sim/No" initial no
    field tta_ind_sit_tit_cobr_especial    as character format "X(15)"
    field ttv_cod_comprov_vda              as character format "x(12)"
    field ttv_num_parc_cartcred            as integer format ">9"
    field ttv_val_tot_sdo_tit_acr          as decimal format ">>>,>>>,>>9.99" decimals 2 initial 0
    field tta_cod_autoriz_bco_emissor      as character format "x(6)"
    field tta_cod_lote_origin              as character format "x(7)"
    index tt_id                            is primary unique
          tta_cod_estab                    ascending
          tta_num_id_tit_acr               ascending
          tta_num_seq_tit_acr              ascending.          

def temp-table ttz_ava_comis_1 no-undo
    field tta_cod_empresa                  as character format "x(3)"
&IF "{&emsfin_version}" >= "" AND "{&emsfin_version}" < "5.07A" &THEN
    field tta_cod_estab                    as character format "x(3)"
&ENDIF
&IF "{&emsfin_version}" >= "5.07A" AND "{&emsfin_version}" < "9.99" &THEN
    field tta_cod_estab                    as Character format "x(5)"
&ENDIF
    field tta_num_id_tit_acr               as integer format "9999999999" initial 0
    field ttv_num_tip_operac               as integer format ">9"
    field tta_cdn_repres                   as Integer format ">>>,>>9" initial 0
&IF "{&emsfin_version}" >= "" AND "{&emsfin_version}" < "5.08" &THEN
    field tta_val_perc_comis_repres        as decimal format ">>9.99" decimals 2 initial 0
&ENDIF
&IF "{&emsfin_version}" >= "5.08" AND "{&emsfin_version}" < "9.99" &THEN
    field tta_val_perc_comis_repres        as decimal format ">>9.9999" decimals 4 initial 0
&ENDIF
    field tta_val_perc_comis_repres_emis   as decimal format ">>9.99" decimals 2 initial 0
    field tta_val_perc_comis_abat          as decimal format ">>9.99" decimals 2 initial 0
    field tta_val_perc_comis_desc          as decimal format ">>9.99" decimals 2 initial 0
    field tta_val_perc_comis_juros         as decimal format ">>9.99" decimals 2 initial 0
    field tta_val_perc_comis_multa         as decimal format ">>9.99" decimals 2 initial 0
    field tta_val_perc_comis_acerto_val    as decimal format ">>9.99" decimals 2 initial 0
    field tta_log_comis_repres_proporc     as logical format "Sim/Nao" initial no
    field tta_ind_tip_comis                as character format "X(15)" initial "Valor Bruto"
    field ttv_ind_tip_comis_ext            as character format "X(15)" initial "Nenhum"
    field ttv_ind_liber_pagto_comis        as character format "X(20)" initial "Nenhum"
    field ttv_ind_sit_comis_ext            as character format "X(10)" initial "Nenhum"
    field tta_val_base_calc_impto          as decimal format ">>>,>>>,>>9.99" decimals 2 initial 0
    index tt_id                            is primary unique
          tta_cod_empresa                  ascending
          tta_cod_estab                    ascending
          tta_num_id_tit_acr               ascending
          tta_cdn_repres                   ascending
    index tt_relac_tit_acr               
          tta_cod_estab                    ascending
          tta_num_id_tit_acr               ascending.

def temp-table ttz_ava_impto_retid_2 no-undo
    field tta_cod_estab                    as character format "x(5)"
    field tta_num_id_tit_acr               as integer format "9999999999" initial 0
    field tta_cod_pais                     as character format "x(3)"
    field tta_cod_unid_federac             as character format "x(3)"
    field tta_cod_imposto                  as character format "x(5)"
    field tta_cod_classif_impto            as character format "x(05)" initial "00000"
    field tta_num_impto_refer_tit_acr      as integer format ">>>>>9" initial 0
    field ttv_num_tip_operac               as integer format ">9"
    field tta_val_aliq_impto               as decimal format ">9.99" decimals 2 INITIAL 0.00
    field tta_val_rendto_tribut            as decimal format ">,>>>,>>>,>>9.99" decimals 2 initial 0
    index tt_id                            is primary unique
          tta_cod_estab                    ascending
          tta_num_id_tit_acr               ascending
          tta_cod_pais                     ascending
          tta_cod_unid_federac             ascending
          tta_cod_imposto                  ascending
          tta_cod_classif_impto            ascending
          tta_num_impto_refer_tit_acr      ascending.          

def temp-table ttz_ava_iva no-undo
    field tta_cod_estab                    as character format "x(5)"
    field tta_num_id_tit_acr               as integer format "9999999999" initial 0
    field tta_cod_refer                    as character format "x(10)"
    field tta_num_seq_refer                as integer format ">>>9" initial 0
    field tta_cod_pais                     as character format "x(3)"
    field tta_cod_unid_federac             as character format "x(3)"
    field tta_cod_imposto                  as character format "x(5)"
    field tta_cod_classif_impto            as character format "x(05)" initial "00000"
    field tta_num_seq                      as integer format ">>>,>>9" initial 0
    field ttv_num_tip_operac               as integer format ">9"
    field tta_val_rendto_tribut            as decimal format ">,>>>,>>>,>>9.99" decimals 2 initial 0
    field tta_val_aliq_impto               as decimal format ">9.99" decimals 2 INITIAL 0.00
    field tta_val_imposto                  as decimal format ">,>>>,>>>,>>9.99" decimals 2 initial 0
    index tt_id                            is primary unique
          tta_cod_estab                    ascending
          tta_num_id_tit_acr               ascending
          tta_cod_pais                     ascending
          tta_cod_unid_federac             ascending
          tta_cod_imposto                  ascending
          tta_cod_classif_impto            ascending
          tta_num_seq                      ascending.          

def temp-table ttz_ava_ped_vda no-undo
    field tta_cod_estab                    as character format "x(5)"
    field tta_num_id_tit_acr               as integer format "9999999999" initial 0
    field ttv_num_tip_operac               as integer format ">9"
    field tta_cod_ped_vda                  as character format "x(15)"
    field tta_cod_ped_vda_repres           as character format "x(30)"
    field tta_val_perc_particip_ped_vda    as decimal format ">>9.99" decimals 2 initial 0
    field tta_des_ped_vda                  as character format "x(40)"
    index tt_id                            is primary unique
          tta_cod_estab                    ascending
          tta_num_id_tit_acr               ascending
          tta_cod_ped_vda                  ascending.          

def temp-table ttz_ava_rateio no-undo
    field tta_cod_estab                    as character format "x(5)"
    field tta_num_id_tit_acr               as integer format "9999999999" initial 0
    field ttv_ind_tip_rat_tit_acr          as character format "X(12)"
    field tta_cod_refer                    as character format "x(10)"
    field tta_num_seq_refer                as integer format ">>>9" initial 0
    field tta_cod_plano_cta_ctbl           as character format "x(8)"
    field tta_cod_cta_ctbl                 as character format "x(20)"
    field tta_cod_unid_negoc               as character format "x(3)"
    field tta_cod_plano_ccusto             as character format "x(8)"
    field tta_cod_ccusto                   as Character format "x(11)"
    field tta_cod_tip_fluxo_financ         as character format "x(12)"
    field tta_num_seq_aprop_ctbl_pend_acr  as integer format ">>>9" initial 0
    field tta_val_aprop_ctbl               as decimal format "->>>,>>>,>>9.99" decimals 2 initial 0
    field tta_log_impto_val_agreg          as logical format "Sim/No" initial no
    field tta_cod_pais                     as character format "x(3)"
    field tta_cod_unid_federac             as character format "x(3)"
    field tta_cod_imposto                  as character format "x(5)"
    field tta_cod_classif_impto            as character format "x(05)" initial "00000"
    field tta_dat_transacao                as date format "99/99/9999" initial today
    index tt_relac_tit_acr               
          tta_cod_estab                    ascending
          tta_num_id_tit_acr               ascending.          

def temp-table ttz_ava_rat_desp_rec no-undo
    field tta_cod_empresa                  as character format "x(3)"
    field tta_cod_estab                    as character format "x(5)"
    field tta_cod_plano_cta_ctbl           as character format "x(8)"
    field tta_cod_cta_ctbl                 as character format "x(20)"
    field tta_cod_unid_negoc               as character format "x(3)"
    field tta_cod_tip_abat                 as character format "x(8)"
    field tta_val_perc_rat_ctbz            as decimal format ">>9.99" decimals 2 initial 0
    field tta_ind_tip_aprop_recta_despes   as character format "x(20)"
    field tta_num_id_tit_acr               as integer format "9999999999" initial 0
    field tta_num_id_aprop_despes_recta    as integer format "9999999999" initial 0
    field tta_cod_tip_fluxo_financ         as character format "x(12)"
    field tta_cod_livre_1                  as character format "x(100)"
    index tt_aprpdspa_id                   is primary unique
          tta_cod_estab                    ascending
          tta_num_id_tit_acr               ascending
          tta_cod_plano_cta_ctbl           ascending
          tta_cod_cta_ctbl                 ascending
          tta_cod_unid_negoc               ascending
          tta_cod_tip_fluxo_financ         ascending
          tta_num_id_aprop_despes_recta    ascending
    index tt_aprpdspa_token                is unique
          tta_cod_estab                    ascending
          tta_num_id_aprop_despes_recta    ascending.

def temp-table ttz_log_erros_ava no-undo
    field tta_cod_estab                    as character format "x(3)"
    field tta_num_id_tit_acr               as integer format "9999999999" initial 0
    field ttv_num_mensagem                 as integer format ">>>>,>>9"
    field ttv_cod_tip_msg_dwb              as character format "x(12)"
    field ttv_des_msg_erro                 as character format "x(60)"
    field ttv_des_msg_ajuda                as character format "x(40)"
    field ttv_wgh_focus                    as widget-handle format ">>>>>>9"
    index tt_relac_tit_acr               
          tta_cod_estab                    ascending
          tta_num_id_tit_acr               ascending
          ttv_num_mensagem                 ascending.          

def temp-table ttz_ava_cobr_esp_2_c no-undo
    field tta_cod_estab                    as Character format "x(5)"
    field tta_num_id_tit_acr               as integer format "999999999" initial 0
    field tta_cod_admdra_cartao_cr         as character format "x(5)"
    field tta_cod_band                     as character format "x(10)"
    field tta_cod_tid                      as character format "x(10)"
    field tta_cod_terminal                 as character format "x(8)".          
          
def temp-table ttz_params_generic_ava        
    field ttv_cod_row_id                   as character format "x(80)"
    field ttv_cod_tabela                   as character format "x(28)"
    field ttv_cod_campo                    as character format "x(35)"
    field ttv_cod_valor                    as character format "x(8)"
    index tt_idx_param_generic             is primary unique
          ttv_cod_tabela                   ascending
          ttv_cod_row_id                   ascending
          ttv_cod_campo                    ASCENDING    .          

DEFINE TEMP-TABLE tt-cliente-agrup NO-UNDO
        FIELD cgc            AS CHARACTER
        FIELD nome_emit      AS CHARACTER
        FIELD dat_importacao AS DATE
        FIELD val_total      AS DECIMAL
        FIELD qtd_titulos    AS INTEGER
        FIELD tem_ad         AS LOGICAL
        FIELD tem_titulo     AS LOGICAL
        FIELD val_ad         AS DECIMAL
        FIELD val_tit        AS DECIMAL
        INDEX idx-cgc IS UNIQUE cgc.

DEFINE TEMP-TABLE tt-item-sel NO-UNDO
        FIELD estab   AS CHARACTER
        FIELD espec   AS CHARACTER
        FIELD serie   AS CHARACTER
        FIELD titulo  AS CHARACTER
        FIELD parcela AS CHARACTER
        FIELD val     AS DECIMAL.

DEFINE TEMP-TABLE tt-dedup-key NO-UNDO
        FIELD chave AS CHARACTER
        FIELD rprim AS ROWID
        INDEX idx-chave chave.
        

DEFINE TEMP-TABLE tt-es-tit-acr-abrt NO-UNDO
    FIELD cgc             AS CHARACTER FORMAT "x(20)"
    FIELD cgc-8char       AS CHARACTER FORMAT "x(8)"
    FIELD cod_estab       AS CHARACTER FORMAT "x(5)"
    FIELD cod_espec_docto AS CHARACTER FORMAT "x(3)"
    FIELD cod_ser_docto   AS CHARACTER FORMAT "x(3)"
    FIELD cod_tit_acr     AS CHARACTER FORMAT "x(10)"
    FIELD cod_parcela     AS CHARACTER FORMAT "x(2)"
    FIELD val_pendente    AS DECIMAL   DECIMALS 2 FORMAT "->>>,>>>,>>9.99"
    FIELD atualizado      AS LOGICAL   INITIAL NO
    INDEX idx-cgc IS PRIMARY
        cgc
        cgc-8char
        val_pendente
        atualizado
    INDEX idx-chave
        cod_estab
        cod_espec_docto
        cod_ser_docto
        cod_tit_acr
        cod_parcela
        atualizado.

DEFINE TEMP-TABLE tt-cnpj-lote NO-UNDO
    FIELD cgc  AS CHARACTER FORMAT "x(20)"
    FIELD cgc8 AS CHARACTER FORMAT "x(8)"
    INDEX idx-cgc  IS PRIMARY cgc
    INDEX idx-cgc8 cgc8.

DEFINE TEMP-TABLE tt-valor-lote NO-UNDO
    FIELD val AS DECIMAL DECIMALS 2
    INDEX idx-val IS PRIMARY val.

FUNCTION fnFieldFilter RETURNS CHARACTER
    (INPUT jsonIn AS JsonObject,
     INPUT c-param AS CHARACTER):

    DEFINE VARIABLE c-par AS CHARACTER NO-UNDO.

    ASSIGN c-par = jsonIn:GetJsonArray(c-param):getCharacter(1) NO-ERROR.

    IF c-par <> "" THEN
        RETURN c-par.

    RETURN "".
END FUNCTION.

FUNCTION fn-query-param RETURNS CHARACTER
    (INPUT ip-query AS CHARACTER,
     INPUT ip-chave AS CHARACTER):

    DEFINE VARIABLE i     AS INTEGER   NO-UNDO.
    DEFINE VARIABLE c-par AS CHARACTER NO-UNDO.

    DO i = 1 TO NUM-ENTRIES(ip-query, "&"):
        c-par = ENTRY(i, ip-query, "&").
        IF ENTRY(1, c-par, "=") = ip-chave THEN
            RETURN ENTRY(2, c-par, "=").
    END.
    RETURN "".
END FUNCTION.

FUNCTION fn-data-json RETURNS CHARACTER (INPUT ip-data AS DATE):
    IF ip-data = ? THEN RETURN "".
    RETURN STRING(YEAR(ip-data), "9999") + "-"
         + STRING(MONTH(ip-data), "99") + "-"
         + STRING(DAY(ip-data), "99").
END FUNCTION.

FUNCTION fn-json-data RETURNS DATE (INPUT ip-str AS CHARACTER):
    DEFINE VARIABLE d-val AS DATE NO-UNDO INITIAL ?.
    IF TRIM(ip-str) = "" THEN RETURN ?.
    
    ASSIGN d-val = DATE(ip-str) NO-ERROR.
    IF NOT ERROR-STATUS:ERROR THEN RETURN d-val.
    
    ASSIGN d-val = DATE(
        INTEGER(ENTRY(2, ip-str, "-")),
        INTEGER(ENTRY(3, ip-str, "-")),
        INTEGER(ENTRY(1, ip-str, "-"))
    ) NO-ERROR.
    RETURN IF ERROR-STATUS:ERROR THEN ? ELSE d-val.
END FUNCTION.

FUNCTION fn-estabs-da-empresa RETURNS CHARACTER (INPUT ip-cod-empresa AS CHARACTER):
    DEFINE VARIABLE c-lista           AS CHARACTER NO-UNDO INITIAL "".
    DEFINE VARIABLE c-estab-formatado AS CHARACTER NO-UNDO.

    IF ip-cod-empresa = "" THEN RETURN "".

    FOR EACH estabelec NO-LOCK WHERE estabelec.ep-codigo = ip-cod-empresa:
        
        
        
        
        IF LENGTH(estabelec.cod-estabel) < 3 THEN DO:
            c-estab-formatado = STRING(INTEGER(estabelec.cod-estabel), "999").
        END.
        
        IF LENGTH(estabelec.cod-estabel) = 4 THEN DO:
            c-estab-formatado = STRING(INTEGER(estabelec.cod-estabel), "9999").
        END.
        
        IF LENGTH(estabelec.cod-estabel) = 5 THEN DO:
            c-estab-formatado = STRING(INTEGER(estabelec.cod-estabel), "99999").
        END.

            
            
            
        
        
        c-lista = c-lista + (IF c-lista = "" THEN "" ELSE ",") + c-estab-formatado.
    END.                                                                                                        

    RETURN c-lista.
END FUNCTION.

DEFINE TEMP-TABLE tt-relatorio-excel NO-UNDO
    FIELD cgc             AS CHARACTER
    FIELD nome_emit       AS CHARACTER
    FIELD cod_estab       AS CHARACTER
    FIELD cod_espec_docto AS CHARACTER
    FIELD cod_ser_docto   AS CHARACTER
    FIELD cod_tit_acr     AS CHARACTER
    FIELD cod_parcela     AS CHARACTER
    FIELD val_tit_acr     AS DECIMAL
    FIELD situacao        AS CHARACTER
    FIELD des_mensagem_erro AS CHARACTER
    FIELD disp-acr        AS LOG
    FIELD valr-abrt-acr   AS DEC.

PROCEDURE pi-item-para-json:

    DEFINE PARAMETER BUFFER b-reg FOR tt-tit-acr-import.
    DEFINE OUTPUT PARAMETER oItem AS JsonObject NO-UNDO.

    DEFINE VARIABLE c-tipo-liq AS CHARACTER NO-UNDO.
    DEFINE VARIABLE c-num-lote AS CHARACTER NO-UNDO.
    DEFINE BUFFER b-tit-acr-liq FOR tit_acr.

    oItem = NEW JsonObject().
    oItem:Add("cgc",                b-reg.cgc).
    oItem:Add("codEstab",           b-reg.cod_estab).
    oItem:Add("codEspecDocto",      b-reg.cod_espec_docto).
    oItem:Add("codSerDocto",        b-reg.cod_ser_docto).
    oItem:Add("codTitAcr",          b-reg.cod_tit_acr).
    oItem:Add("codParcela",         b-reg.cod_parcela).
    oItem:Add("codEmpresa",         b-reg.cod_empresa).
    oItem:Add("datGeracao",         fn-data-json(b-reg.dat_geracao)).
    oItem:Add("codPortador",        b-reg.cod_portador).
    oItem:Add("codCartBcia",        b-reg.cod_cart_bcia).
    oItem:Add("valRecebido",        b-reg.val_recebido).
    oItem:Add("valJuros",           b-reg.val_juros).
    oItem:Add("valMulta",           b-reg.val_multa).
    oItem:Add("valDesconto",        b-reg.val_desconto).
    oItem:Add("valAbatimento",      b-reg.val_abatimento).
    oItem:Add("indSitImportacao",   b-reg.ind_sit_importacao).
    oItem:Add("desMensagemErro",    b-reg.des_mensagem_erro).
    oItem:Add("datImportacao",      fn-data-json(b-reg.dat_importacao)).
    oItem:Add("hraImportacao",      b-reg.hra_importacao).
    oItem:Add("codArqOrigem",       b-reg.cod_arq_origem).
    oItem:Add("codUsuarioImport",   b-reg.cod_usuario_import).
    oItem:Add("numLoteImportacao",  b-reg.num_lote_importacao).
    oItem:Add("datProcessamento",   fn-data-json(b-reg.dat_processamento)).
    oItem:Add("hraProcessamento",   b-reg.hra_processamento).
    oItem:Add("cdnCliente",         b-reg.cdn_cliente).
    oItem:Add("nomeEmit",           b-reg.nome-emit).

    
    c-tipo-liq = "".
    IF b-reg.cod_tit_acr <> "" AND b-reg.cod_espec_docto <> "AD" THEN DO:
        FIND FIRST b-tit-acr-liq NO-LOCK
            WHERE b-tit-acr-liq.cod_estab       = b-reg.cod_estab
              AND b-tit-acr-liq.cod_espec_docto = b-reg.cod_espec_docto
              AND b-tit-acr-liq.cod_ser_docto   = b-reg.cod_ser_docto
              AND b-tit-acr-liq.cod_tit_acr     = b-reg.cod_tit_acr
              AND b-tit-acr-liq.cod_parcela     = b-reg.cod_parcela NO-ERROR.
        IF AVAILABLE b-tit-acr-liq THEN DO:
            
            IF b-reg.val_recebido = 0 AND b-reg.val_juros = 0 AND b-reg.val_multa = 0 THEN
                c-tipo-liq = "integral".
            ELSE IF (b-reg.val_recebido + b-reg.val_juros + b-reg.val_multa)
                     >= (b-tit-acr-liq.val_sdo_tit_acr + b-tit-acr-liq.val_juros + b-tit-acr-liq.val_multa_tit_acr) THEN
                c-tipo-liq = "integral".
            ELSE
                c-tipo-liq = "parcial".
        END.
    END.
    oItem:Add("tipoLiquidacao",     c-tipo-liq).
    
    c-num-lote = "".
    IF NUM-ENTRIES(b-reg.cod_arq_origem, "|") >= 4 THEN DO:
        c-num-lote = ENTRY(4, b-reg.cod_arq_origem, "|").
        IF c-num-lote BEGINS "Lote:" THEN c-num-lote = SUBSTRING(c-num-lote, 6).
        ELSE c-num-lote = "".
    END.
    oItem:Add("numLote",            c-num-lote).
    
    oItem:Add("isLote", (NUM-ENTRIES(b-reg.cod_arq_origem, "|") >= 4
                         AND ENTRY(4, b-reg.cod_arq_origem, "|") BEGINS "Lote:")).

END PROCEDURE.

PROCEDURE pi-copiar-db-para-tt:

    DEFINE PARAMETER BUFFER b-db FOR es-tit-acr-importa-tit.
    DEFINE PARAMETER BUFFER b-tt FOR tt-tit-acr-import.

    ASSIGN
        b-tt.cgc                 = b-db.cgc
        b-tt.cod_estab           = b-db.cod_estab
        b-tt.cod_espec_docto     = b-db.cod_espec_docto
        b-tt.cod_ser_docto       = b-db.cod_ser_docto
        b-tt.cod_tit_acr         = b-db.cod_tit_acr
        b-tt.cod_parcela         = b-db.cod_parcela
        b-tt.cod_empresa         = b-db.cod_empresa
        b-tt.dat_geracao         = b-db.dat_geracao
        b-tt.cod_portador        = b-db.cod_portador
        b-tt.cod_cart_bcia       = b-db.cod_cart_bcia
        b-tt.val_recebido        = b-db.val_recebido
        b-tt.val_juros           = b-db.val_juros
        b-tt.val_multa           = b-db.val_multa
        b-tt.val_desconto        = b-db.val_desconto
        b-tt.val_abatimento      = b-db.val_abatimento
        b-tt.ind_sit_importacao  = b-db.ind_sit_importacao
        b-tt.des_mensagem_erro   = b-db.des_mensagem_erro
        b-tt.dat_importacao      = b-db.dat_importacao
        b-tt.hra_importacao      = b-db.hra_importacao
        b-tt.cod_arq_origem      = b-db.cod_arq_origem
        b-tt.cod_usuario_import  = b-db.cod_usuario_import
        b-tt.num_lote_importacao = b-db.num_lote_importacao
        b-tt.dat_processamento   = b-db.dat_processamento
        b-tt.hra_processamento   = b-db.hra_processamento
        b-tt.cdn_cliente         = 0
        b-tt.nome-emit           = "".

    
    FIND FIRST emitente NO-LOCK
         WHERE emitente.cgc = b-db.cgc NO-ERROR.
    IF AVAILABLE emitente THEN
        ASSIGN b-tt.cdn_cliente = emitente.cod-emitente
               b-tt.nome-emit  = emitente.nome-abrev.

END PROCEDURE.

PROCEDURE pi-listar:

    DEFINE INPUT  PARAMETER oJsonIn        AS JsonObject NO-UNDO.
    DEFINE OUTPUT PARAMETER lc-resposta    AS LONGCHAR   NO-UNDO.
    DEFINE OUTPUT PARAMETER i-status       AS INTEGER    NO-UNDO.

    
    DEFINE VARIABLE c-empresa   AS CHARACTER NO-UNDO.
    DEFINE VARIABLE c-situacao  AS CHARACTER NO-UNDO.
    DEFINE VARIABLE c-cgc       AS CHARACTER NO-UNDO.
    DEFINE VARIABLE c-nome      AS CHARACTER NO-UNDO.
    DEFINE VARIABLE c-titulo    AS CHARACTER NO-UNDO.
    DEFINE VARIABLE c-estab     AS CHARACTER NO-UNDO.
    DEFINE VARIABLE c-serie     AS CHARACTER NO-UNDO.
    DEFINE VARIABLE d-data-ini  AS DATE      NO-UNDO INITIAL ?.
    DEFINE VARIABLE d-data-fim  AS DATE      NO-UNDO INITIAL ?.
    DEFINE VARIABLE i-lote      AS INTEGER   NO-UNDO INITIAL 0.
    DEFINE VARIABLE i-pagina    AS INTEGER   NO-UNDO INITIAL 1.
    DEFINE VARIABLE i-itens-pp  AS INTEGER   NO-UNDO INITIAL 50.
    DEFINE VARIABLE c-estabs-empresa AS CHARACTER NO-UNDO.

    
    DEFINE VARIABLE i-total     AS INTEGER   NO-UNDO INITIAL 0.
    DEFINE VARIABLE i-skip      AS INTEGER   NO-UNDO.
    DEFINE VARIABLE i-lidos     AS INTEGER   NO-UNDO INITIAL 0.
    DEFINE VARIABLE l-tem-mais  AS LOGICAL   NO-UNDO INITIAL FALSE.

    
    DEFINE VARIABLE oResp  AS JsonObject NO-UNDO.
    DEFINE VARIABLE aItems AS JsonArray  NO-UNDO.
    DEFINE VARIABLE oItem  AS JsonObject NO-UNDO.

    CURRENT-LANG = CURRENT-LANG.

    ASSIGN
        c-empresa  = fnFieldFilter(oJsonIn, "codEmpresa")
        c-situacao = fnFieldFilter(oJsonIn, "indSitImportacao")
        c-cgc      = fnFieldFilter(oJsonIn, "cgc")
        c-nome     = fnFieldFilter(oJsonIn, "nomeEmit")
        c-titulo   = fnFieldFilter(oJsonIn, "codTitAcr")
        c-estab    = fnFieldFilter(oJsonIn, "codEstab")
        c-serie    = fnFieldFilter(oJsonIn, "codSerDocto")
       .

    
    DEFINE VARIABLE l-todas-emp AS LOGICAL NO-UNDO.
    c-estabs-empresa = fn-estabs-da-empresa(c-empresa).
    l-todas-emp = (c-empresa = "*").

    IF fnFieldFilter(oJsonIn, "dataIni") <> "" THEN
        d-data-ini = fn-json-data(fnFieldFilter(oJsonIn, "dataIni")).
    IF fnFieldFilter(oJsonIn, "dataFim") <> "" THEN
        d-data-fim = fn-json-data(fnFieldFilter(oJsonIn, "dataFim")).

    IF fnFieldFilter(oJsonIn, "lote") <> "" THEN
        i-lote = INTEGER(fnFieldFilter(oJsonIn, "lote")) NO-ERROR.

    IF fnFieldFilter(oJsonIn, "pagina") <> "" THEN
        i-pagina = MAXIMUM(1, INTEGER(fnFieldFilter(oJsonIn, "pagina"))).

    IF fnFieldFilter(oJsonIn, "itensPorPagina") <> "" THEN
        i-itens-pp = MAX(1, MIN(200, INTEGER(fnFieldFilter(oJsonIn, "itensPorPagina")) )).

    i-skip = (i-pagina - 1) * i-itens-pp.

    
    FOR EACH es-tit-acr-importa-tit NO-LOCK
        WHERE (l-todas-emp OR LOOKUP(es-tit-acr-importa-tit.cod_estab, c-estabs-empresa) > 0)
          AND (c-situacao = "" OR es-tit-acr-importa-tit.ind_sit_importacao = c-situacao)
          AND (c-cgc      = "" OR es-tit-acr-importa-tit.cgc        BEGINS  c-cgc)
          AND (c-titulo   = "" OR es-tit-acr-importa-tit.cod_tit_acr BEGINS c-titulo)
          AND (c-estab    = "" OR es-tit-acr-importa-tit.cod_estab   = c-estab)
          AND (c-serie    = "" OR es-tit-acr-importa-tit.cod_ser_docto = c-serie)
          AND (d-data-ini = ?  OR es-tit-acr-importa-tit.dat_importacao    >= d-data-ini)
          AND (d-data-fim = ?  OR es-tit-acr-importa-tit.dat_importacao    <= d-data-fim):

        IF c-nome <> "" THEN DO:
            FIND FIRST emitente NO-LOCK WHERE emitente.cgc = es-tit-acr-importa-tit.cgc NO-ERROR.
            IF NOT AVAILABLE emitente OR INDEX(CAPS(emitente.nome-abrev), CAPS(c-nome)) = 0 THEN NEXT.
        END.
        i-total = i-total + 1.
    END.

    
    aItems = NEW JsonArray().
    i-lidos = 0.

    FOR EACH es-tit-acr-importa-tit NO-LOCK
        WHERE (l-todas-emp OR LOOKUP(es-tit-acr-importa-tit.cod_estab, c-estabs-empresa) > 0)
          AND (c-situacao = "" OR es-tit-acr-importa-tit.ind_sit_importacao = c-situacao)
          AND (c-cgc      = "" OR es-tit-acr-importa-tit.cgc        BEGINS  c-cgc)
          AND (c-titulo   = "" OR es-tit-acr-importa-tit.cod_tit_acr BEGINS c-titulo)
          AND (c-estab    = "" OR es-tit-acr-importa-tit.cod_estab   = c-estab)
          AND (c-serie    = "" OR es-tit-acr-importa-tit.cod_ser_docto = c-serie)
          AND (d-data-ini = ?  OR es-tit-acr-importa-tit.dat_importacao    >= d-data-ini)
          AND (d-data-fim = ?  OR es-tit-acr-importa-tit.dat_importacao    <= d-data-fim)
        BY es-tit-acr-importa-tit.dat_importacao DESCENDING:

        IF c-nome <> "" THEN DO:
            FIND FIRST emitente NO-LOCK WHERE emitente.cgc = es-tit-acr-importa-tit.cgc NO-ERROR.
            IF NOT AVAILABLE emitente OR INDEX(CAPS(emitente.nome-abrev), CAPS(c-nome)) = 0 THEN NEXT.
        END.

        i-lidos = i-lidos + 1.
        IF i-lidos <= i-skip THEN NEXT.
        IF i-lidos > i-skip + i-itens-pp THEN DO:
            l-tem-mais = TRUE.
            LEAVE.
        END.

        CREATE tt-tit-acr-import.
        RUN pi-copiar-db-para-tt(
            BUFFER es-tit-acr-importa-tit,
            BUFFER tt-tit-acr-import
        ).
        RUN pi-item-para-json(
            BUFFER tt-tit-acr-import,
            OUTPUT oItem
        ).
        aItems:Add(oItem).
        DELETE tt-tit-acr-import.

    END.

    
    oResp = NEW JsonObject().
    oResp:Add("items",          aItems).
    oResp:Add("totalItens",     i-total).
    oResp:Add("pagina",         i-pagina).
    oResp:Add("itensPorPagina", i-itens-pp).
    
    oResp:Add("hasNext",        l-tem-mais).

    oResp:Write(lc-resposta, TRUE).
    i-status = 200.

END PROCEDURE.

PROCEDURE pi-listar-clientes:

    DEFINE INPUT  PARAMETER oJsonIn        AS JsonObject NO-UNDO.
    DEFINE OUTPUT PARAMETER lc-resposta    AS LONGCHAR   NO-UNDO.
    DEFINE OUTPUT PARAMETER i-status       AS INTEGER    NO-UNDO.

    DEFINE VARIABLE c-empresa   AS CHARACTER NO-UNDO.
    DEFINE VARIABLE c-situacao  AS CHARACTER NO-UNDO.
    DEFINE VARIABLE c-cgc       AS CHARACTER NO-UNDO.
    DEFINE VARIABLE c-nome      AS CHARACTER NO-UNDO.
    DEFINE VARIABLE d-data-ini  AS DATE      NO-UNDO INITIAL ?.
    DEFINE VARIABLE d-data-fim  AS DATE      NO-UNDO INITIAL ?.
    DEFINE VARIABLE i-pagina    AS INTEGER   NO-UNDO INITIAL 1.
    DEFINE VARIABLE i-itens-pp  AS INTEGER   NO-UNDO INITIAL 50.

    DEFINE VARIABLE i-total     AS INTEGER   NO-UNDO INITIAL 0.
    DEFINE VARIABLE i-skip      AS INTEGER   NO-UNDO.
    DEFINE VARIABLE i-lidos     AS INTEGER   NO-UNDO INITIAL 0.
    DEFINE VARIABLE l-tem-mais  AS LOGICAL   NO-UNDO INITIAL FALSE.

    DEFINE VARIABLE oResp    AS JsonObject NO-UNDO.
    DEFINE VARIABLE aItems   AS JsonArray  NO-UNDO.
    DEFINE VARIABLE oItem    AS JsonObject NO-UNDO.
    DEFINE VARIABLE de-abrt  AS DECIMAL    NO-UNDO.
    DEFINE VARIABLE c-estabs-empresa AS CHARACTER NO-UNDO.

    

    CURRENT-LANG = CURRENT-LANG.

    ASSIGN
        c-empresa  = fnFieldFilter(oJsonIn, "codEmpresa")
        c-situacao = fnFieldFilter(oJsonIn, "indSitImportacao")
        c-cgc      = fnFieldFilter(oJsonIn, "cgc")
        c-nome     = fnFieldFilter(oJsonIn, "nomeEmit")
       .

    
    DEFINE VARIABLE l-todas-emp AS LOGICAL NO-UNDO.
    c-estabs-empresa = fn-estabs-da-empresa(c-empresa).
    l-todas-emp = (c-empresa = "*").

    IF fnFieldFilter(oJsonIn, "dataIni") <> "" THEN
        d-data-ini = fn-json-data(fnFieldFilter(oJsonIn, "dataIni")).
    IF fnFieldFilter(oJsonIn, "dataFim") <> "" THEN
        d-data-fim = fn-json-data(fnFieldFilter(oJsonIn, "dataFim")).

    IF fnFieldFilter(oJsonIn, "pagina") <> "" THEN
        i-pagina = MAXIMUM(1, INTEGER(fnFieldFilter(oJsonIn, "pagina"))).

    IF fnFieldFilter(oJsonIn, "itensPorPagina") <> "" THEN
        i-itens-pp = MAX(1, MIN(200, INTEGER(fnFieldFilter(oJsonIn, "itensPorPagina")) )).

    i-skip = (i-pagina - 1) * i-itens-pp.

    
    FOR EACH es-tit-acr-importa-tit NO-LOCK
        WHERE (l-todas-emp OR LOOKUP(es-tit-acr-importa-tit.cod_estab, c-estabs-empresa) > 0)
          AND (c-situacao = "" OR es-tit-acr-importa-tit.ind_sit_importacao = c-situacao)
          AND (c-cgc      = "" OR es-tit-acr-importa-tit.cgc        BEGINS  c-cgc)
          AND (d-data-ini = ?  OR es-tit-acr-importa-tit.dat_importacao    >= d-data-ini)
          AND (d-data-fim = ?  OR es-tit-acr-importa-tit.dat_importacao    <= d-data-fim):

        FIND FIRST tt-cliente-agrup WHERE tt-cliente-agrup.cgc = es-tit-acr-importa-tit.cgc NO-ERROR.

        IF NOT AVAILABLE tt-cliente-agrup THEN DO:
            FIND FIRST emitente NO-LOCK WHERE emitente.cgc = es-tit-acr-importa-tit.cgc NO-ERROR.

            IF c-nome <> "" AND
               (NOT AVAILABLE emitente OR INDEX(CAPS(emitente.nome-abrev), CAPS(c-nome)) = 0) THEN
                NEXT.

            CREATE tt-cliente-agrup.
            ASSIGN tt-cliente-agrup.cgc            = es-tit-acr-importa-tit.cgc
                   tt-cliente-agrup.dat_importacao  = es-tit-acr-importa-tit.dat_importacao.

            IF AVAILABLE emitente THEN
                tt-cliente-agrup.nome_emit = emitente.nome-abrev.
        END.

        ASSIGN
            tt-cliente-agrup.val_total   = tt-cliente-agrup.val_total + es-tit-acr-importa-tit.val_recebido
            tt-cliente-agrup.qtd_titulos = tt-cliente-agrup.qtd_titulos + 1.

        IF es-tit-acr-importa-tit.dat_importacao > tt-cliente-agrup.dat_importacao THEN
            tt-cliente-agrup.dat_importacao = es-tit-acr-importa-tit.dat_importacao.

        
        IF es-tit-acr-importa-tit.cod_espec_docto = "AD"
           OR (es-tit-acr-importa-tit.cod_ser_docto = "" AND es-tit-acr-importa-tit.cod_tit_acr = "") THEN DO:
            tt-cliente-agrup.tem_ad  = YES.
            tt-cliente-agrup.val_ad  = tt-cliente-agrup.val_ad + es-tit-acr-importa-tit.val_recebido.
        END.

        
        ELSE IF es-tit-acr-importa-tit.cod_tit_acr <> "" THEN DO:
            tt-cliente-agrup.tem_titulo = YES.
            tt-cliente-agrup.val_tit    = tt-cliente-agrup.val_tit + es-tit-acr-importa-tit.val_recebido.
        END.

    END.

    
    FOR EACH tt-cliente-agrup NO-LOCK:
        i-total = i-total + 1.
    END.

    
    aItems = NEW JsonArray().

    FOR EACH tt-cliente-agrup NO-LOCK BY tt-cliente-agrup.dat_importacao DESCENDING:

        i-lidos = i-lidos + 1.
        IF i-lidos <= i-skip THEN NEXT.
        IF i-lidos > i-skip + i-itens-pp THEN DO:
            l-tem-mais = TRUE.
            LEAVE.
        END.

        oItem = NEW JsonObject().
        oItem:Add("cgc",            tt-cliente-agrup.cgc).
        oItem:Add("nomeEmit",       tt-cliente-agrup.nome_emit).
        oItem:Add("dataImportacao", fn-data-json(tt-cliente-agrup.dat_importacao)).
        oItem:Add("valor",          tt-cliente-agrup.val_total).
        oItem:Add("valorEmAberto",  tt-cliente-agrup.val_tit).
        oItem:Add("valorEmAbertoAd", tt-cliente-agrup.val_ad).
        oItem:Add("qtdTitulos",     tt-cliente-agrup.qtd_titulos).

        oItem:Add("temAd", tt-cliente-agrup.tem_ad).
        oItem:Add("temTitulo", tt-cliente-agrup.tem_titulo).
        aItems:Add(oItem).

    END.

    oResp = NEW JsonObject().
    oResp:Add("items",          aItems).
    oResp:Add("totalItens",     i-total).
    oResp:Add("pagina",         i-pagina).
    oResp:Add("itensPorPagina", i-itens-pp).
    oResp:Add("hasNext",        l-tem-mais).

    oResp:Write(lc-resposta, TRUE).
    i-status = 200.

    CATCH oE AS Progress.Lang.Error:
        oResp = NEW JsonObject().
        oResp:Add("error", oE:GetMessage(1)).
        oResp:Write(lc-resposta, TRUE).
        i-status = 500.
    END CATCH.

END PROCEDURE.

PROCEDURE pi-listar-ad-cliente:

    DEFINE INPUT  PARAMETER oJsonIn     AS JsonObject NO-UNDO.
    DEFINE OUTPUT PARAMETER lc-resposta AS LONGCHAR   NO-UNDO.
    DEFINE OUTPUT PARAMETER i-status    AS INTEGER    NO-UNDO.

    DEFINE VARIABLE c-cgc  AS CHARACTER NO-UNDO.
    DEFINE VARIABLE c-situacao AS CHARACTER NO-UNDO.
    DEFINE VARIABLE c-obs-ad AS CHARACTER NO-UNDO.
    DEFINE VARIABLE oResp  AS JsonObject NO-UNDO.
    DEFINE VARIABLE aItems AS JsonArray  NO-UNDO.
    DEFINE VARIABLE oItem  AS JsonObject NO-UNDO.

    CURRENT-LANG = CURRENT-LANG.

    c-cgc = fnFieldFilter(oJsonIn, "cgc").
    c-situacao = fnFieldFilter(oJsonIn, "indSitImportacao").

    aItems = NEW JsonArray().

    IF c-cgc <> "" THEN DO:

        
        FOR EACH es-tit-acr-importa-tit NO-LOCK
            WHERE es-tit-acr-importa-tit.cgc = c-cgc
              AND (c-situacao = "" OR es-tit-acr-importa-tit.ind_sit_importacao = c-situacao)
              AND (es-tit-acr-importa-tit.cod_espec_docto = "AD"
                   OR (es-tit-acr-importa-tit.cod_ser_docto = "" AND es-tit-acr-importa-tit.cod_tit_acr = "")):

            c-obs-ad = "".
            IF NUM-ENTRIES(es-tit-acr-importa-tit.cod_arq_origem, "|") >= 2 THEN
                c-obs-ad = ENTRY(2, es-tit-acr-importa-tit.cod_arq_origem, "|").

            oItem = NEW JsonObject().
            oItem:Add("codEstab",     es-tit-acr-importa-tit.cod_estab).
            oItem:Add("codEspecDocto", es-tit-acr-importa-tit.cod_espec_docto).
            oItem:Add("codSerDocto",  es-tit-acr-importa-tit.cod_ser_docto).
            oItem:Add("codTitAcr",    es-tit-acr-importa-tit.cod_tit_acr).
            oItem:Add("codParcela",   es-tit-acr-importa-tit.cod_parcela).
            oItem:Add("datEmisDocto", fn-data-json(IF es-tit-acr-importa-tit.dat_geracao <> ?
                                                    THEN es-tit-acr-importa-tit.dat_geracao
                                                    ELSE es-tit-acr-importa-tit.dat_importacao)).
            oItem:Add("valTitAcr",    es-tit-acr-importa-tit.val_recebido).
            oItem:Add("valSdoTitAcr", es-tit-acr-importa-tit.val_recebido).
            oItem:Add("status",       es-tit-acr-importa-tit.ind_sit_importacao).
            oItem:Add("observacoes",  c-obs-ad).
            oItem:Add("desMensagemErro", es-tit-acr-importa-tit.des_mensagem_erro).
            aItems:Add(oItem).
        END.

    END.

    oResp = NEW JsonObject().
    oResp:Add("items", aItems).

    oResp:Write(lc-resposta, TRUE).
    i-status = 200.

    CATCH oE AS Progress.Lang.Error:
        oResp = NEW JsonObject().
        oResp:Add("error", oE:GetMessage(1)).
        oResp:Write(lc-resposta, TRUE).
        i-status = 500.
    END CATCH.

END PROCEDURE.

PROCEDURE pi-carteira-liquidacao:
    DEFINE OUTPUT PARAMETER p-cart AS CHARACTER NO-UNDO.
    DEFINE OUTPUT PARAMETER p-erro AS CHARACTER NO-UNDO.
    ASSIGN p-cart = "" p-erro = "".
    FIND FIRST es_param_global_ti_item NO-LOCK
        WHERE es_param_global_ti_item.cod_parametro      = "liquidacao-auto"
          AND es_param_global_ti_item.cod_parametro_item = "carteira" NO-ERROR.
    IF NOT AVAILABLE es_param_global_ti_item THEN DO:
        ASSIGN p-erro = "Carteira de liquidacao nao cadastrada. Configure o parametro 'liquidacao-auto', item 'carteira', no ESTI0101.".
        RETURN.
    END.
    ASSIGN p-cart = TRIM(es_param_global_ti_item.val_1).
END PROCEDURE.

PROCEDURE pi-criar-ad-excedente:
    DEFINE INPUT  PARAMETER p-cgc     AS CHARACTER NO-UNDO.
    DEFINE INPUT  PARAMETER p-estab   AS CHARACTER NO-UNDO.
    DEFINE INPUT  PARAMETER p-val     AS DECIMAL   NO-UNDO.
    DEFINE INPUT  PARAMETER p-arq     AS CHARACTER NO-UNDO.
    DEFINE INPUT  PARAMETER p-usuario AS CHARACTER NO-UNDO.
    DEFINE OUTPUT PARAMETER p-cod-ad  AS CHARACTER NO-UNDO.

    DEFINE VARIABLE i-t   AS INTEGER NO-UNDO.
    DEFINE VARIABLE v-c   AS INTEGER NO-UNDO.
    DEFINE VARIABLE l-uni AS LOGICAL NO-UNDO.
    DEFINE VARIABLE c-est AS CHARACTER NO-UNDO.
    DEFINE BUFFER b-ad FOR es-tit-acr-importa-tit.

    IF p-val <= 0 THEN RETURN.
    c-est = (IF p-estab <> "" THEN p-estab ELSE "001").
    l-uni = NO.
    DO i-t = 1 TO 30 WHILE l-uni = NO:
        p-cod-ad = "AD" + SUBSTRING(STRING(TODAY,"99999999"),7,2)
                        + SUBSTRING(STRING(TODAY,"99999999"),3,2) + "T".
        DO v-c = 1 TO 3:
            p-cod-ad = p-cod-ad + CHR((RANDOM(0,(TIME * i-t) + v-c + 9999) MOD 26) + 97).
        END.
        IF NOT CAN-FIND(FIRST tit_acr WHERE tit_acr.cod_estab = c-est
                          AND tit_acr.cod_espec_docto = "AD" AND tit_acr.cod_ser_docto = ""
                          AND tit_acr.cod_tit_acr = p-cod-ad AND tit_acr.cod_parcela = "01")
           AND NOT CAN-FIND(FIRST b-ad WHERE b-ad.cod_estab = c-est
                          AND b-ad.cod_espec_docto = "AD" AND b-ad.cod_tit_acr = p-cod-ad) THEN
            l-uni = YES.
    END.
    IF NOT l-uni THEN DO: p-cod-ad = "". RETURN. END.

    CREATE b-ad.
    ASSIGN
        b-ad.cgc                 = p-cgc
        b-ad.cod_estab           = c-est
        b-ad.cod_espec_docto     = "AD"
        b-ad.cod_ser_docto       = ""
        b-ad.cod_tit_acr         = p-cod-ad
        b-ad.cod_parcela         = "01"
        b-ad.val_recebido        = p-val
        b-ad.val_juros           = 0
        b-ad.val_multa           = 0
        b-ad.val_desconto        = 0
        b-ad.val_abatimento      = 0
        b-ad.ind_sit_importacao  = "Pendente"
        b-ad.dat_importacao      = TODAY
        b-ad.hra_importacao      = STRING(TIME,"HH:MM:SS")
        b-ad.cod_arq_origem      = p-arq
        b-ad.cod_usuario_import  = p-usuario
        b-ad.num_lote_importacao = 0 NO-ERROR.
    VALIDATE b-ad NO-ERROR.
    RELEASE b-ad NO-ERROR.
END PROCEDURE.

PROCEDURE pi-listar-titulos-grupo:
    DEFINE INPUT  PARAMETER oJsonIn     AS JsonObject NO-UNDO.
    DEFINE OUTPUT PARAMETER lc-resposta AS LONGCHAR   NO-UNDO.
    DEFINE OUTPUT PARAMETER i-status    AS INTEGER    NO-UNDO.

    DEFINE VARIABLE c-cgc  AS CHARACTER  NO-UNDO.
    DEFINE VARIABLE c-raiz AS CHARACTER  NO-UNDO.
    DEFINE VARIABLE oResp  AS JsonObject NO-UNDO.
    DEFINE VARIABLE aItems AS JsonArray  NO-UNDO.
    DEFINE VARIABLE oItem  AS JsonObject NO-UNDO.
    DEFINE BUFFER b-emit FOR emitente.
    DEFINE BUFFER b-tit  FOR tit_acr.

    CURRENT-LANG = CURRENT-LANG.

    c-cgc  = fnFieldFilter(oJsonIn, "cgc").
    c-cgc  = REPLACE(REPLACE(REPLACE(c-cgc, ".", ""), "-", ""), "/", "").
    c-raiz = SUBSTRING(c-cgc, 1, 8).
    aItems = NEW JsonArray().

    IF c-cgc <> "" THEN
    FOR EACH b-emit NO-LOCK WHERE b-emit.cgc BEGINS c-raiz:
        FOR EACH b-tit NO-LOCK
            WHERE b-tit.cdn_cliente     = b-emit.cod-emitente
              AND b-tit.log_sdo_tit_acr = YES
              AND b-tit.val_sdo_tit_acr > 0:
            IF b-tit.cod_portador = '9997' THEN NEXT.
            IF b-tit.cod_espec_docto = "AD" THEN NEXT.
            oItem = NEW JsonObject().
            oItem:Add("cnpj",          b-emit.cgc).
            oItem:Add("nomeEmit",      b-emit.nome-abrev).
            oItem:Add("codEstab",      b-tit.cod_estab).
            oItem:Add("codEspecDocto", b-tit.cod_espec_docto).
            oItem:Add("codSerDocto",   b-tit.cod_ser_docto).
            oItem:Add("codTitAcr",     b-tit.cod_tit_acr).
            oItem:Add("codParcela",    b-tit.cod_parcela).
            oItem:Add("valSdoTitAcr",  b-tit.val_sdo_tit_acr).
            oItem:Add("valJuros",      b-tit.val_juros).
            oItem:Add("valMulta",      b-tit.val_multa_tit_acr).
            oItem:Add("valDevido",     b-tit.val_sdo_tit_acr + b-tit.val_juros + b-tit.val_multa_tit_acr).
            oItem:Add("datVencto",     fn-data-json(b-tit.dat_vencto_tit_acr)).
            aItems:Add(oItem).
        END.
    END.

    oResp = NEW JsonObject().
    oResp:Add("items", aItems).
    oResp:Write(lc-resposta, TRUE).
    i-status = 200.

    CATCH oE AS Progress.Lang.Error:
        oResp = NEW JsonObject().
        oResp:Add("error", oE:GetMessage(1)).
        oResp:Write(lc-resposta, TRUE).
        i-status = 500.
    END CATCH.
END PROCEDURE.

PROCEDURE pi-trocar-vinculo:
    DEFINE INPUT  PARAMETER oJsonIn     AS JsonObject NO-UNDO.
    DEFINE OUTPUT PARAMETER lc-resposta AS LONGCHAR   NO-UNDO.
    DEFINE OUTPUT PARAMETER i-status    AS INTEGER    NO-UNDO.

    DEFINE VARIABLE oBody AS JsonObject NO-UNDO.
    DEFINE VARIABLE oResp AS JsonObject NO-UNDO.
    DEFINE VARIABLE c-cgc AS CHARACTER NO-UNDO.
    DEFINE VARIABLE c-e-a AS CHARACTER NO-UNDO.
    DEFINE VARIABLE c-es-a AS CHARACTER NO-UNDO.
    DEFINE VARIABLE c-sr-a AS CHARACTER NO-UNDO.
    DEFINE VARIABLE c-t-a AS CHARACTER NO-UNDO.
    DEFINE VARIABLE c-p-a AS CHARACTER NO-UNDO.
    DEFINE VARIABLE c-e-n AS CHARACTER NO-UNDO.
    DEFINE VARIABLE c-es-n AS CHARACTER NO-UNDO.
    DEFINE VARIABLE c-sr-n AS CHARACTER NO-UNDO.
    DEFINE VARIABLE c-t-n AS CHARACTER NO-UNDO.
    DEFINE VARIABLE c-p-n AS CHARACTER NO-UNDO.
    DEFINE VARIABLE de-val AS DECIMAL NO-UNDO.
    DEFINE VARIABLE de-pago AS DECIMAL NO-UNDO.
    DEFINE VARIABLE de-devido AS DECIMAL NO-UNDO.
    DEFINE VARIABLE de-dif AS DECIMAL NO-UNDO.
    DEFINE VARIABLE c-oper AS CHARACTER NO-UNDO.
    DEFINE VARIABLE c-cod-ad AS CHARACTER NO-UNDO.
    DEFINE VARIABLE c-usu AS CHARACTER NO-UNDO.
    DEFINE VARIABLE aTit AS JsonArray NO-UNDO.
    DEFINE VARIABLE oT AS JsonObject NO-UNDO.
    DEFINE VARIABLE i AS INTEGER NO-UNDO.
    DEFINE VARIABLE de-rem AS DECIMAL NO-UNDO.
    DEFINE VARIABLE de-alloc AS DECIMAL NO-UNDO.
    DEFINE VARIABLE de-ad AS DECIMAL NO-UNDO.
    DEFINE VARIABLE i-integral AS INTEGER NO-UNDO.
    DEFINE VARIABLE i-parcial AS INTEGER NO-UNDO.
    DEFINE VARIABLE c-arq AS CHARACTER NO-UNDO.
    DEFINE VARIABLE c-emp AS CHARACTER NO-UNDO.
    DEFINE BUFFER b-imp  FOR es-tit-acr-importa-tit.
    DEFINE BUFFER b-novo FOR es-tit-acr-importa-tit.
    DEFINE BUFFER b-tit  FOR tit_acr.

    IF oJsonIn:Has("payload") THEN oBody = oJsonIn:GetJsonObject("payload") NO-ERROR.
    ELSE IF oJsonIn:Has("requestBody") THEN oBody = oJsonIn:GetJsonObject("requestBody") NO-ERROR.
    ELSE IF oJsonIn:Has("body") THEN oBody = oJsonIn:GetJsonObject("body") NO-ERROR.
    ELSE oBody = oJsonIn.

    ASSIGN
        c-cgc  = oBody:GetCharacter("cgc")           NO-ERROR.
    ASSIGN c-e-a  = oBody:GetCharacter("estabAtual")   NO-ERROR.
    ASSIGN c-es-a = oBody:GetCharacter("especAtual")   NO-ERROR.
    ASSIGN c-sr-a = oBody:GetCharacter("serieAtual")   NO-ERROR.
    ASSIGN c-t-a  = oBody:GetCharacter("tituloAtual")  NO-ERROR.
    ASSIGN c-p-a  = oBody:GetCharacter("parcelaAtual") NO-ERROR.
    ASSIGN c-e-n  = oBody:GetCharacter("novoEstab")    NO-ERROR.
    ASSIGN c-es-n = oBody:GetCharacter("novoEspec")    NO-ERROR.
    ASSIGN c-sr-n = oBody:GetCharacter("novoSerie")    NO-ERROR.
    ASSIGN c-t-n  = oBody:GetCharacter("novoTitulo")   NO-ERROR.
    ASSIGN c-p-n  = oBody:GetCharacter("novoParcela")  NO-ERROR.
    ASSIGN de-val = oBody:GetDecimal("valRecebido")    NO-ERROR.
    IF de-val = ? THEN de-val = 0.
    ASSIGN c-usu = oBody:GetCharacter("codUsuario") NO-ERROR.
    IF c-usu = ? THEN c-usu = "".

    
    FIND FIRST b-imp EXCLUSIVE-LOCK
        WHERE b-imp.cgc             = c-cgc
          AND b-imp.cod_estab       = c-e-a
          AND b-imp.cod_espec_docto = c-es-a
          AND b-imp.cod_ser_docto   = c-sr-a
          AND b-imp.cod_tit_acr     = c-t-a
          AND b-imp.cod_parcela     = c-p-a
          AND b-imp.ind_sit_importacao = "Pendente" NO-ERROR.
    IF NOT AVAILABLE b-imp THEN DO:
        oResp = NEW JsonObject().
        oResp:Add("success", FALSE).
        oResp:Add("message", "Registro pendente nao encontrado para troca.").
        oResp:Write(lc-resposta, TRUE).
        i-status = 404.
        RETURN.
    END.

    
    ASSIGN
        de-pago = b-imp.val_recebido + b-imp.val_juros + b-imp.val_multa
        c-arq   = b-imp.cod_arq_origem
        c-emp   = b-imp.cod_empresa.

    
    EMPTY TEMP-TABLE tt-alvo.
    aTit = oBody:GetJsonArray("titulos") NO-ERROR.
    IF VALID-OBJECT(aTit) THEN
    DO i = 1 TO aTit:Length:
        oT = aTit:GetJsonObject(i) NO-ERROR.
        IF NOT VALID-OBJECT(oT) THEN NEXT.
        FIND FIRST b-tit NO-LOCK
            WHERE b-tit.cod_estab       = (oT:GetCharacter("estab"))
              AND b-tit.cod_espec_docto = (oT:GetCharacter("espec"))
              AND b-tit.cod_ser_docto   = (oT:GetCharacter("serie"))
              AND b-tit.cod_tit_acr     = (oT:GetCharacter("titulo"))
              AND b-tit.cod_parcela     = (oT:GetCharacter("parcela")) NO-ERROR.
        IF NOT AVAILABLE b-tit OR NOT b-tit.log_sdo_tit_acr OR b-tit.val_sdo_tit_acr <= 0 THEN NEXT.
        CREATE tt-alvo.
        ASSIGN tt-alvo.c-estab = b-tit.cod_estab
               tt-alvo.c-espec = b-tit.cod_espec_docto
               tt-alvo.c-serie = b-tit.cod_ser_docto
               tt-alvo.c-tit   = b-tit.cod_tit_acr
               tt-alvo.c-parc  = b-tit.cod_parcela
               tt-alvo.c-port  = b-tit.cod_portador
               tt-alvo.c-cart  = b-tit.cod_cart_bcia
               tt-alvo.d-saldo = b-tit.val_sdo_tit_acr
               tt-alvo.d-juros = b-tit.val_juros
               tt-alvo.d-multa = b-tit.val_multa_tit_acr
               tt-alvo.dt-venc = b-tit.dat_vencto_tit_acr.
    END.

    IF NOT CAN-FIND(FIRST tt-alvo) THEN DO:
        oResp = NEW JsonObject().
        oResp:Add("success", FALSE).
        oResp:Add("message", "Nenhum titulo de destino valido (com saldo) selecionado.").
        oResp:Write(lc-resposta, TRUE).
        i-status = 400.
        RETURN.
    END.

    
    ASSIGN de-rem = de-pago i-integral = 0 i-parcial = 0 de-ad = 0.
    FOR EACH tt-alvo BY tt-alvo.dt-venc:
        IF de-rem <= 0 THEN LEAVE.
        ASSIGN de-devido = tt-alvo.d-saldo + tt-alvo.d-juros + tt-alvo.d-multa.
        ASSIGN de-alloc  = MINIMUM(de-rem, de-devido).
        IF de-alloc <= 0 THEN NEXT.
        IF CAN-FIND(FIRST b-novo WHERE b-novo.cgc = c-cgc
                      AND b-novo.cod_estab       = tt-alvo.c-estab
                      AND b-novo.cod_espec_docto = tt-alvo.c-espec
                      AND b-novo.cod_ser_docto   = tt-alvo.c-serie
                      AND b-novo.cod_tit_acr     = tt-alvo.c-tit
                      AND b-novo.cod_parcela     = tt-alvo.c-parc
                      AND b-novo.ind_sit_importacao = "Pendente") THEN NEXT.
        CREATE b-novo.
        ASSIGN b-novo.cgc                 = c-cgc
               b-novo.cod_empresa         = c-emp
               b-novo.cod_estab           = tt-alvo.c-estab
               b-novo.cod_espec_docto     = tt-alvo.c-espec
               b-novo.cod_ser_docto       = tt-alvo.c-serie
               b-novo.cod_tit_acr         = tt-alvo.c-tit
               b-novo.cod_parcela         = tt-alvo.c-parc
               b-novo.cod_portador        = tt-alvo.c-port
               b-novo.cod_cart_bcia       = tt-alvo.c-cart
               b-novo.val_desconto        = 0
               b-novo.val_abatimento      = 0
               b-novo.ind_sit_importacao  = "Pendente"
               b-novo.dat_importacao      = TODAY
               b-novo.hra_importacao      = STRING(TIME,"HH:MM:SS")
               b-novo.cod_arq_origem      = c-arq
               b-novo.cod_usuario_import  = c-usu
               b-novo.dat_geracao         = b-imp.dat_geracao
               b-novo.num_lote_importacao = 0.
        IF de-alloc >= de-devido - 0.005 THEN
            ASSIGN b-novo.val_recebido = tt-alvo.d-saldo
                   b-novo.val_juros    = tt-alvo.d-juros
                   b-novo.val_multa    = tt-alvo.d-multa
                   i-integral          = i-integral + 1.
        ELSE
            ASSIGN b-novo.val_recebido = de-alloc
                   b-novo.val_juros    = 0
                   b-novo.val_multa    = 0
                   i-parcial           = i-parcial + 1.
        VALIDATE b-novo NO-ERROR.
        RELEASE b-novo NO-ERROR.
        ASSIGN de-rem = de-rem - de-alloc.
    END.

    
    IF de-rem > 0.005 THEN DO:
        RUN pi-criar-ad-excedente (INPUT c-cgc, INPUT c-e-a, INPUT de-rem,
                                   INPUT c-arq, INPUT c-usu, OUTPUT c-cod-ad).
        ASSIGN de-ad = de-rem.
    END.

    
    DELETE b-imp.

    oResp = NEW JsonObject().
    oResp:Add("success", TRUE).
    oResp:Add("qtdIntegral", i-integral).
    oResp:Add("qtdParcial", i-parcial).
    oResp:Add("valorAd", de-ad).
    oResp:Add("message", STRING(i-integral) + " titulo(s) liquidado(s) integral, "
                       + STRING(i-parcial) + " parcial"
                       + (IF de-ad > 0 THEN ", AD de " + TRIM(STRING(de-ad, ">>>,>>>,>>9.99")) ELSE "")
                       + ".").
    oResp:Write(lc-resposta, TRUE).
    i-status = 200.

    CATCH oE AS Progress.Lang.Error:
        oResp = NEW JsonObject().
        oResp:Add("success", FALSE).
        oResp:Add("error", oE:GetMessage(1)).
        oResp:Write(lc-resposta, TRUE).
        i-status = 500.
    END CATCH.
END PROCEDURE.

PROCEDURE pi-buscar-por-chave:

    DEFINE INPUT  PARAMETER c-path-params AS CHARACTER NO-UNDO.
    DEFINE OUTPUT PARAMETER lc-resposta   AS LONGCHAR  NO-UNDO.
    DEFINE OUTPUT PARAMETER i-status      AS INTEGER   NO-UNDO.

    DEFINE VARIABLE c-cgc        AS CHARACTER NO-UNDO.
    DEFINE VARIABLE c-estab      AS CHARACTER NO-UNDO.
    DEFINE VARIABLE c-espec      AS CHARACTER NO-UNDO.
    DEFINE VARIABLE c-serie      AS CHARACTER NO-UNDO.
    DEFINE VARIABLE c-titulo     AS CHARACTER NO-UNDO.
    DEFINE VARIABLE c-parcela    AS CHARACTER NO-UNDO.
    DEFINE VARIABLE oItem        AS JsonObject NO-UNDO.
    DEFINE VARIABLE oErro        AS JsonObject NO-UNDO.

    
    ASSIGN
        c-cgc     = ENTRY(1, c-path-params, "/")
        c-estab   = IF NUM-ENTRIES(c-path-params, "/") >= 2 THEN ENTRY(2, c-path-params, "/") ELSE ""
        c-espec   = IF NUM-ENTRIES(c-path-params, "/") >= 3 THEN ENTRY(3, c-path-params, "/") ELSE ""
        c-serie   = IF NUM-ENTRIES(c-path-params, "/") >= 4 THEN ENTRY(4, c-path-params, "/") ELSE ""
        c-titulo  = IF NUM-ENTRIES(c-path-params, "/") >= 5 THEN ENTRY(5, c-path-params, "/") ELSE ""
        c-parcela = IF NUM-ENTRIES(c-path-params, "/") >= 6 THEN ENTRY(6, c-path-params, "/") ELSE "".

    IF c-cgc = "" THEN DO:
        oErro = NEW JsonObject().
        oErro:Add("error", "CGC nao informado. Esperado: cgc/codEstab/codEspecDocto/codSerDocto/codTitAcr/codParcela").
        oErro:Write(lc-resposta, TRUE).
        i-status = 400.
        RETURN.
    END.

    FIND FIRST es-tit-acr-importa-tit
        WHERE es-tit-acr-importa-tit.cgc            = c-cgc
          AND es-tit-acr-importa-tit.cod_estab       = c-estab
          AND es-tit-acr-importa-tit.cod_espec_docto = c-espec
          AND es-tit-acr-importa-tit.cod_ser_docto   = c-serie
          AND es-tit-acr-importa-tit.cod_tit_acr     = c-titulo
          AND es-tit-acr-importa-tit.cod_parcela     = c-parcela
        NO-LOCK NO-ERROR.

    IF NOT AVAILABLE es-tit-acr-importa-tit THEN DO:
        oErro = NEW JsonObject().
        oErro:Add("error", "Registro nao encontrado.").
        oErro:Write(lc-resposta, TRUE).
        i-status = 404.
        RETURN.
    END.

    CREATE tt-tit-acr-import.
    RUN pi-copiar-db-para-tt(
        BUFFER es-tit-acr-importa-tit,
        BUFFER tt-tit-acr-import
    ).

    RUN pi-item-para-json(
        BUFFER tt-tit-acr-import,
        OUTPUT oItem
    ).

    DELETE tt-tit-acr-import.

    oItem:Write(lc-resposta, TRUE).
    i-status = 200.

END PROCEDURE.

PROCEDURE pi-deletar:

    DEFINE INPUT  PARAMETER c-path-params AS CHARACTER NO-UNDO.
    DEFINE OUTPUT PARAMETER lc-resposta   AS LONGCHAR  NO-UNDO.
    DEFINE OUTPUT PARAMETER i-status      AS INTEGER   NO-UNDO.

    DEFINE VARIABLE c-cgc     AS CHARACTER  NO-UNDO.
    DEFINE VARIABLE c-estab   AS CHARACTER  NO-UNDO.
    DEFINE VARIABLE c-espec   AS CHARACTER  NO-UNDO.
    DEFINE VARIABLE c-serie   AS CHARACTER  NO-UNDO.
    DEFINE VARIABLE c-titulo  AS CHARACTER  NO-UNDO.
    DEFINE VARIABLE c-parcela AS CHARACTER  NO-UNDO.
    DEFINE VARIABLE c-valor   AS CHARACTER  NO-UNDO.
    DEFINE VARIABLE de-valor  AS DECIMAL    NO-UNDO INITIAL ?.
    DEFINE VARIABLE oResp     AS JsonObject NO-UNDO.

    
    ASSIGN
        c-cgc     = ENTRY(1, c-path-params, "/")
        c-estab   = IF NUM-ENTRIES(c-path-params, "/") >= 2 THEN ENTRY(2, c-path-params, "/") ELSE ""
        c-espec   = IF NUM-ENTRIES(c-path-params, "/") >= 3 THEN ENTRY(3, c-path-params, "/") ELSE ""
        c-serie   = IF NUM-ENTRIES(c-path-params, "/") >= 4 THEN ENTRY(4, c-path-params, "/") ELSE ""
        c-titulo  = IF NUM-ENTRIES(c-path-params, "/") >= 5 THEN ENTRY(5, c-path-params, "/") ELSE ""
        c-parcela = IF NUM-ENTRIES(c-path-params, "/") >= 6 THEN ENTRY(6, c-path-params, "/") ELSE ""
        c-valor   = IF NUM-ENTRIES(c-path-params, "/") >= 7 THEN ENTRY(7, c-path-params, "/") ELSE "".

    IF c-valor <> "" THEN
        de-valor = DECIMAL(c-valor) NO-ERROR.

    IF c-cgc = "" THEN DO:
        oResp = NEW JsonObject().
        oResp:Add("error", "CGC nao informado. Esperado: cgc/codEstab/codEspecDocto/codSerDocto/codTitAcr/codParcela").
        oResp:Write(lc-resposta, TRUE).
        i-status = 400.
        RETURN.
    END.

    
    FIND FIRST es-tit-acr-importa-tit
        WHERE es-tit-acr-importa-tit.cgc            = c-cgc
          AND es-tit-acr-importa-tit.cod_estab       = c-estab
          AND es-tit-acr-importa-tit.cod_espec_docto = c-espec
          AND es-tit-acr-importa-tit.cod_ser_docto   = c-serie
          AND es-tit-acr-importa-tit.cod_tit_acr     = c-titulo
          AND es-tit-acr-importa-tit.cod_parcela     = c-parcela
          AND (de-valor = ? OR es-tit-acr-importa-tit.val_recebido = de-valor)
        EXCLUSIVE-LOCK NO-WAIT NO-ERROR.

    IF LOCKED es-tit-acr-importa-tit THEN DO:
        oResp = NEW JsonObject().
        oResp:Add("error", "Registro em uso por outro usuario. Tente novamente em instantes.").
        oResp:Add("cgc",       c-cgc).
        oResp:Add("codTitAcr", c-titulo).
        oResp:Add("codParcela", c-parcela).
        oResp:Write(lc-resposta, TRUE).
        i-status = 423.
        RETURN.
    END.

    IF NOT AVAILABLE es-tit-acr-importa-tit THEN DO:
        oResp = NEW JsonObject().
        oResp:Add("error", "Registro nao encontrado.").
        oResp:Write(lc-resposta, TRUE).
        i-status = 404.
        RETURN.
    END.

    
    IF es-tit-acr-importa-tit.ind_sit_importacao = "Importado" THEN DO:
        RELEASE es-tit-acr-importa-tit NO-ERROR.
        oResp = NEW JsonObject().
        oResp:Add("error", "Titulo ja importado. Remocao nao permitida.").
        oResp:Write(lc-resposta, TRUE).
        i-status = 422.
        RETURN.
    END.
    
    
 
    DEFINE VARIABLE cRaizCnpj AS CHARACTER NO-UNDO.

    
    FIND FIRST es_tit_acr_abrt EXCLUSIVE-LOCK WHERE
        es_tit_acr_abrt.cod_estab       = es-tit-acr-importa-tit.cod_estab       AND
        es_tit_acr_abrt.cod_espec_docto = es-tit-acr-importa-tit.cod_espec_docto AND
        es_tit_acr_abrt.cod_ser_docto   = es-tit-acr-importa-tit.cod_ser_docto   AND
        es_tit_acr_abrt.cod_tit_acr     = es-tit-acr-importa-tit.cod_tit_acr     AND
        es_tit_acr_abrt.cod_parcela     = es-tit-acr-importa-tit.cod_parcela     NO-ERROR.

    IF AVAILABLE es_tit_acr_abrt THEN
        ASSIGN es_tit_acr_abrt.val_pendente = es_tit_acr_abrt.val_pendente
                                            + es-tit-acr-importa-tit.val_recebido.
    ELSE DO:
        FIND FIRST tit_acr NO-LOCK
            WHERE tit_acr.cod_estab       = es-tit-acr-importa-tit.cod_estab
              AND tit_acr.cod_espec_docto = es-tit-acr-importa-tit.cod_espec_docto
              AND tit_acr.cod_ser_docto   = es-tit-acr-importa-tit.cod_ser_docto
              AND tit_acr.cod_tit_acr     = es-tit-acr-importa-tit.cod_tit_acr
              AND tit_acr.cod_parcela     = es-tit-acr-importa-tit.cod_parcela   NO-ERROR.

        IF AVAIL tit_acr AND tit_acr.val_sdo_tit_acr > 0 AND tit_acr.log_sdo_tit_acr = YES THEN
        DO:
            FIND FIRST emitente NO-LOCK WHERE emitente.cod-emitente = tit_acr.cdn_cliente NO-ERROR.
            IF AVAIL emitente THEN
            DO:
                ASSIGN cRaizCnpj = SUBSTRING(emitente.cgc, 1, 8).
                CREATE es_tit_acr_abrt.
                ASSIGN
                    es_tit_acr_abrt.cgc             = emitente.cgc
                    es_tit_acr_abrt.cgc-8char       = cRaizCnpj
                    es_tit_acr_abrt.cod_estab       = tit_acr.cod_estab
                    es_tit_acr_abrt.cod_espec_docto = tit_acr.cod_espec_docto
                    es_tit_acr_abrt.cod_ser_docto   = tit_acr.cod_ser_docto
                    es_tit_acr_abrt.cod_tit_acr     = tit_acr.cod_tit_acr
                    es_tit_acr_abrt.cod_parcela     = tit_acr.cod_parcela
                    es_tit_acr_abrt.val_pendente    = es-tit-acr-importa-tit.val_recebido.
            END.
        END.
    END.

    DELETE es-tit-acr-importa-tit.

    oResp = NEW JsonObject().
    oResp:Add("message",    "Titulo removido com sucesso.").
    oResp:Add("cgc",        c-cgc).
    oResp:Add("codEstab",   c-estab).
    oResp:Add("codTitAcr",  c-titulo).
    oResp:Add("codParcela", c-parcela).
    oResp:Write(lc-resposta, TRUE).
    i-status = 200.

END PROCEDURE.

PROCEDURE pi-listar-empresas:

    DEFINE INPUT  PARAMETER oJsonIn     AS JsonObject NO-UNDO.
    DEFINE OUTPUT PARAMETER lc-resposta AS LONGCHAR  NO-UNDO.
    DEFINE OUTPUT PARAMETER i-status    AS INTEGER   NO-UNDO.

    DEFINE VARIABLE aItems    AS JsonArray  NO-UNDO.
    DEFINE VARIABLE oEmpresa  AS JsonObject NO-UNDO.
    DEFINE VARIABLE oResp     AS JsonObject NO-UNDO.
    DEFINE VARIABLE c-usuario AS CHARACTER  NO-UNDO.
    DEFINE VARIABLE c-emps    AS CHARACTER  NO-UNDO INITIAL "".

    CURRENT-LANG = CURRENT-LANG.

    c-usuario = fnFieldFilter(oJsonIn, "codUsuario").
    IF c-usuario = "" OR c-usuario = ? THEN c-usuario = USERID("DICT") NO-ERROR.
    IF c-usuario = "" OR c-usuario = ? THEN c-usuario = USERID(LDBNAME(1)) NO-ERROR.

    aItems = NEW JsonArray().

    
    FOR EACH usuar_financ_estab_acr NO-LOCK
        WHERE usuar_financ_estab_acr.cod_usuario = c-usuario
          AND (usuar_financ_estab_acr.log_habilit_impl_tit_acr = YES
            OR usuar_financ_estab_acr.log_habilit_liquidac_acr = YES
            OR usuar_financ_estab_acr.log_habilit_gera_avdeb   = YES):

        FIND FIRST estabelecimento NO-LOCK
             WHERE estabelecimento.cod_estab = usuar_financ_estab_acr.cod_estab NO-ERROR.
        IF NOT AVAILABLE estabelecimento THEN NEXT.

        
        IF LOOKUP(estabelecimento.cod_empresa, c-emps) > 0 THEN NEXT.
        c-emps = c-emps + (IF c-emps = "" THEN "" ELSE ",") + estabelecimento.cod_empresa.

        FIND FIRST emscad.empresa NO-LOCK
             WHERE emscad.empresa.cod_empresa = estabelecimento.cod_empresa NO-ERROR.

        oEmpresa = NEW JsonObject().
        oEmpresa:Add("codEmpresa", estabelecimento.cod_empresa).
        oEmpresa:Add("descricao",
                     (IF AVAILABLE emscad.empresa THEN emscad.empresa.nom_abrev
                      ELSE estabelecimento.cod_empresa)).
        aItems:Add(oEmpresa).

    END.

    oResp = NEW JsonObject().
    oResp:Add("items", aItems).

    oResp:Write(lc-resposta, TRUE).
    i-status = 200.

    CATCH oE AS Progress.Lang.Error:
        oResp = NEW JsonObject().
        oResp:Add("error", oE:GetMessage(1)).
        oResp:Write(lc-resposta, TRUE).
        i-status = 500.
    END CATCH.

END PROCEDURE.

PROCEDURE pi-contadores:

    DEFINE INPUT  PARAMETER oJsonIn        AS JsonObject NO-UNDO.
    DEFINE OUTPUT PARAMETER lc-resposta    AS LONGCHAR  NO-UNDO.
    DEFINE OUTPUT PARAMETER i-status       AS INTEGER   NO-UNDO.

    DEFINE VARIABLE c-empresa  AS CHARACTER NO-UNDO.
    DEFINE VARIABLE c-estabs-empresa AS CHARACTER NO-UNDO.
    DEFINE VARIABLE i-todas    AS INTEGER   NO-UNDO INITIAL 0.
    DEFINE VARIABLE i-pendente AS INTEGER   NO-UNDO INITIAL 0.
    DEFINE VARIABLE i-import   AS INTEGER   NO-UNDO INITIAL 0.
    DEFINE VARIABLE i-erro     AS INTEGER   NO-UNDO INITIAL 0.
    DEFINE VARIABLE oResp      AS JsonObject NO-UNDO.

    c-empresa = fnFieldFilter(oJsonIn, "codEmpresa").
    DEFINE VARIABLE l-todas-emp AS LOGICAL NO-UNDO.
    c-estabs-empresa = fn-estabs-da-empresa(c-empresa).
    l-todas-emp = (c-empresa = "*").

    FOR EACH es-tit-acr-importa-tit NO-LOCK
        WHERE (l-todas-emp OR LOOKUP(es-tit-acr-importa-tit.cod_estab, c-estabs-empresa) > 0):

        i-todas = i-todas + 1.

        CASE es-tit-acr-importa-tit.ind_sit_importacao:
            WHEN "Pendente"  THEN i-pendente = i-pendente + 1.
            WHEN "Importado" THEN i-import   = i-import   + 1.
            WHEN "Erro"      THEN i-erro     = i-erro     + 1.
        END CASE.

    END.

    oResp = NEW JsonObject().
    oResp:Add("todas",      i-todas).
    oResp:Add("pendentes",  i-pendente).
    oResp:Add("processadas", i-import).
    oResp:Add("comErro",    i-erro).

    oResp:Write(lc-resposta, TRUE).
    i-status = 200.

END PROCEDURE.

PROCEDURE pi-progresso:

    DEFINE INPUT  PARAMETER c-query-string AS CHARACTER NO-UNDO.
    DEFINE OUTPUT PARAMETER lc-resposta    AS LONGCHAR  NO-UNDO.
    DEFINE OUTPUT PARAMETER i-status       AS INTEGER   NO-UNDO.

    DEFINE VARIABLE c-ids        AS CHARACTER NO-UNDO.
    DEFINE VARIABLE i            AS INTEGER   NO-UNDO.
    DEFINE VARIABLE c-id         AS CHARACTER NO-UNDO.
    DEFINE VARIABLE c-empresa    AS CHARACTER NO-UNDO.
    DEFINE VARIABLE c-estab      AS CHARACTER NO-UNDO.
    DEFINE VARIABLE c-titulo     AS CHARACTER NO-UNDO.
    DEFINE VARIABLE c-parcela    AS CHARACTER NO-UNDO.

    DEFINE VARIABLE i-total      AS INTEGER   NO-UNDO INITIAL 0.
    DEFINE VARIABLE i-proc       AS INTEGER   NO-UNDO INITIAL 0.
    DEFINE VARIABLE i-erro       AS INTEGER   NO-UNDO INITIAL 0.

    DEFINE VARIABLE oResp        AS JsonObject NO-UNDO.
    DEFINE VARIABLE aIds         AS JsonArray  NO-UNDO.

    c-ids = fn-query-param(c-query-string, "ids").
    aIds = NEW JsonArray().

    DO i = 1 TO NUM-ENTRIES(c-ids, ","):
        c-id = ENTRY(i, c-ids, ",").
        IF c-id = "" THEN NEXT.

        aIds:Add(c-id).
        i-total = i-total + 1.

        IF NUM-ENTRIES(c-id, "|") >= 4 THEN DO:
            ASSIGN
                c-empresa = ENTRY(1, c-id, "|")
                c-estab   = ENTRY(2, c-id, "|")
                c-titulo  = ENTRY(3, c-id, "|")
                c-parcela = ENTRY(4, c-id, "|").

            FIND FIRST es-tit-acr-importa-tit NO-LOCK
                 WHERE es-tit-acr-importa-tit.cod_empresa = c-empresa
                   AND es-tit-acr-importa-tit.cod_estab   = c-estab
                   AND es-tit-acr-importa-tit.cod_tit_acr = c-titulo
                   AND es-tit-acr-importa-tit.cod_parcela = c-parcela
                 NO-ERROR.

            IF AVAILABLE es-tit-acr-importa-tit THEN DO:
                IF es-tit-acr-importa-tit.ind_sit_importacao = "Processado" OR
                   es-tit-acr-importa-tit.ind_sit_importacao = "Importado" THEN
                    i-proc = i-proc + 1.
                ELSE IF es-tit-acr-importa-tit.ind_sit_importacao = "Erro" THEN
                    i-erro = i-erro + 1.
            END.
        END.
    END.

    oResp = NEW JsonObject().
    oResp:Add("ids", aIds).
    oResp:Add("totalRegistros", i-total).
    oResp:Add("processados", i-proc).
    oResp:Add("comErro", i-erro).

    IF i-erro > 0 THEN
        oResp:Add("status", "erro").
    ELSE
        oResp:Add("status", "concluido").

    oResp:Add("percentual", 100).

    oResp:Write(lc-resposta, TRUE).
    i-status = 200.

END PROCEDURE.

PROCEDURE pi-remover:

    DEFINE INPUT  PARAMETER oJsonBody   AS JsonObject NO-UNDO.
    DEFINE OUTPUT PARAMETER lc-resposta AS LONGCHAR   NO-UNDO.
    DEFINE OUTPUT PARAMETER i-status    AS INTEGER    NO-UNDO.

    DEFINE VARIABLE aIds       AS JsonArray  NO-UNDO.
    DEFINE VARIABLE oResp      AS JsonObject NO-UNDO.
    DEFINE VARIABLE aDetalhes  AS JsonArray  NO-UNDO.
    DEFINE VARIABLE oDetalhe   AS JsonObject NO-UNDO.
    DEFINE VARIABLE c-id       AS CHARACTER  NO-UNDO.
    DEFINE VARIABLE c-cgc      AS CHARACTER  NO-UNDO.
    DEFINE VARIABLE c-estab    AS CHARACTER  NO-UNDO.
    DEFINE VARIABLE c-espec    AS CHARACTER  NO-UNDO.
    DEFINE VARIABLE c-serie    AS CHARACTER  NO-UNDO.
    DEFINE VARIABLE c-titulo   AS CHARACTER  NO-UNDO.
    DEFINE VARIABLE c-parcela  AS CHARACTER  NO-UNDO.
    DEFINE VARIABLE c-val-rem  AS CHARACTER  NO-UNDO.
    DEFINE VARIABLE de-val-rem AS DECIMAL    NO-UNDO INITIAL ?.
    DEFINE VARIABLE i-idx      AS INTEGER    NO-UNDO.
    DEFINE VARIABLE i-removidos AS INTEGER   NO-UNDO INITIAL 0.
    DEFINE VARIABLE i-erros    AS INTEGER    NO-UNDO INITIAL 0.

    DEFINE VARIABLE oRealBody AS JsonObject NO-UNDO.
    DEFINE VARIABLE lc-debug  AS LONGCHAR   NO-UNDO.

    oJsonBody:Write(lc-debug, TRUE).

    IF oJsonBody:Has("payload") THEN
        oRealBody = oJsonBody:GetJsonObject("payload") NO-ERROR.
    ELSE IF oJsonBody:Has("requestBody") THEN
        oRealBody = oJsonBody:GetJsonObject("requestBody") NO-ERROR.
    ELSE IF oJsonBody:Has("body") THEN
        oRealBody = oJsonBody:GetJsonObject("body") NO-ERROR.
    ELSE
        oRealBody = oJsonBody.

    
    IF VALID-OBJECT(oRealBody)
       AND oRealBody:Has("removerTodos")
       AND oRealBody:GetLogical("removerTodos") = YES THEN DO:
        aDetalhes = NEW JsonArray().
        FOR EACH es-tit-acr-importa-tit EXCLUSIVE-LOCK
            WHERE es-tit-acr-importa-tit.ind_sit_importacao <> "Importado":
            DELETE es-tit-acr-importa-tit.
            i-removidos = i-removidos + 1.
        END.

        oResp = NEW JsonObject().
        oResp:Add("success",   TRUE).
        oResp:Add("message",   STRING(i-removidos) + " registro(s) removido(s).").
        oResp:Add("removidos", i-removidos).
        oResp:Add("erros",     0).
        oResp:Add("detalhes",  aDetalhes).
        oResp:Write(lc-resposta, TRUE).
        i-status = 200.
        RETURN.
    END.

    IF NOT VALID-OBJECT(oRealBody) OR NOT oRealBody:Has("ids") THEN DO:
        oResp = NEW JsonObject().
        oResp:Add("error", "Campo 'ids' nao encontrado. Recebido: " + STRING(lc-debug)).
        oResp:Write(lc-resposta, TRUE).
        i-status = 400.
        RETURN.
    END.

    aIds = oRealBody:GetJsonArray("ids").
    IF aIds:Length = 0 THEN DO:
        oResp = NEW JsonObject().
        oResp:Add("error", "Lista de IDs vazia.").
        oResp:Write(lc-resposta, TRUE).
        i-status = 400.
        RETURN.
    END.

    aDetalhes = NEW JsonArray().

    DO i-idx = 1 TO aIds:Length:
        c-id = aIds:GetCharacter(i-idx).

        ASSIGN
            c-cgc     = ENTRY(1, c-id, "|")
            c-estab   = IF NUM-ENTRIES(c-id, "|") >= 2 THEN ENTRY(2, c-id, "|") ELSE ""
            c-espec   = IF NUM-ENTRIES(c-id, "|") >= 3 THEN ENTRY(3, c-id, "|") ELSE ""
            c-serie   = IF NUM-ENTRIES(c-id, "|") >= 4 THEN ENTRY(4, c-id, "|") ELSE ""
            c-titulo  = IF NUM-ENTRIES(c-id, "|") >= 5 THEN ENTRY(5, c-id, "|") ELSE ""
            c-parcela = IF NUM-ENTRIES(c-id, "|") >= 6 THEN ENTRY(6, c-id, "|") ELSE ""
            c-val-rem = IF NUM-ENTRIES(c-id, "|") >= 7 THEN ENTRY(7, c-id, "|") ELSE ""
            NO-ERROR.

        de-val-rem = ?.
        IF c-val-rem <> "" THEN DO:
            IF SESSION:NUMERIC-DECIMAL-POINT = "," THEN c-val-rem = REPLACE(c-val-rem, ".", ",").
            de-val-rem = DECIMAL(c-val-rem) NO-ERROR.
        END.

        FIND FIRST es-tit-acr-importa-tit
            WHERE es-tit-acr-importa-tit.cgc            = c-cgc
              AND es-tit-acr-importa-tit.cod_estab       = c-estab
              AND es-tit-acr-importa-tit.cod_espec_docto = c-espec
              AND es-tit-acr-importa-tit.cod_ser_docto   = c-serie
              AND es-tit-acr-importa-tit.cod_tit_acr     = c-titulo
              AND es-tit-acr-importa-tit.cod_parcela     = c-parcela
              AND (de-val-rem = ? OR es-tit-acr-importa-tit.val_recebido = de-val-rem)
            EXCLUSIVE-LOCK NO-WAIT NO-ERROR.

        IF LOCKED es-tit-acr-importa-tit THEN DO:
            oDetalhe = NEW JsonObject().
            oDetalhe:Add("id", c-id).
            oDetalhe:Add("status", "ERRO").
            oDetalhe:Add("mensagem", "Registro em uso por outro usuario.").
            aDetalhes:Add(oDetalhe).
            i-erros = i-erros + 1.
            NEXT.
        END.

        IF NOT AVAILABLE es-tit-acr-importa-tit THEN DO:
            oDetalhe = NEW JsonObject().
            oDetalhe:Add("id", c-id).
            oDetalhe:Add("status", "ERRO").
            oDetalhe:Add("mensagem", "Registro nao encontrado.").
            aDetalhes:Add(oDetalhe).
            i-erros = i-erros + 1.
            NEXT.
        END.

        IF es-tit-acr-importa-tit.ind_sit_importacao = "Importado" THEN DO:
            RELEASE es-tit-acr-importa-tit NO-ERROR.
            oDetalhe = NEW JsonObject().
            oDetalhe:Add("id", c-id).
            oDetalhe:Add("status", "ERRO").
            oDetalhe:Add("mensagem", "Titulo ja importado. Remocao nao permitida.").
            aDetalhes:Add(oDetalhe).
            i-erros = i-erros + 1.
            NEXT.
        END.
        
        

        
        DEFINE VARIABLE cRaizCnpj AS CHARACTER NO-UNDO.

        
        FIND FIRST es_tit_acr_abrt EXCLUSIVE-LOCK WHERE
            es_tit_acr_abrt.cod_estab       = es-tit-acr-importa-tit.cod_estab       AND
            es_tit_acr_abrt.cod_espec_docto = es-tit-acr-importa-tit.cod_espec_docto AND
            es_tit_acr_abrt.cod_ser_docto   = es-tit-acr-importa-tit.cod_ser_docto   AND
            es_tit_acr_abrt.cod_tit_acr     = es-tit-acr-importa-tit.cod_tit_acr     AND
            es_tit_acr_abrt.cod_parcela     = es-tit-acr-importa-tit.cod_parcela     NO-ERROR.

        IF AVAILABLE es_tit_acr_abrt THEN
            ASSIGN es_tit_acr_abrt.val_pendente = es_tit_acr_abrt.val_pendente
                                                + es-tit-acr-importa-tit.val_recebido.
        ELSE DO:
            FIND FIRST tit_acr NO-LOCK
                WHERE tit_acr.cod_estab       = es-tit-acr-importa-tit.cod_estab
                  AND tit_acr.cod_espec_docto = es-tit-acr-importa-tit.cod_espec_docto
                  AND tit_acr.cod_ser_docto   = es-tit-acr-importa-tit.cod_ser_docto
                  AND tit_acr.cod_tit_acr     = es-tit-acr-importa-tit.cod_tit_acr
                  AND tit_acr.cod_parcela     = es-tit-acr-importa-tit.cod_parcela   NO-ERROR.

            IF AVAIL tit_acr AND tit_acr.val_sdo_tit_acr > 0 AND tit_acr.log_sdo_tit_acr = YES THEN
            DO:
                FIND FIRST emitente NO-LOCK WHERE emitente.cod-emitente = tit_acr.cdn_cliente NO-ERROR.
                IF AVAIL emitente THEN
                DO:
                    ASSIGN cRaizCnpj = SUBSTRING(emitente.cgc, 1, 8).
                    CREATE es_tit_acr_abrt.
                    ASSIGN
                        es_tit_acr_abrt.cgc             = emitente.cgc
                        es_tit_acr_abrt.cgc-8char       = cRaizCnpj
                        es_tit_acr_abrt.cod_estab       = tit_acr.cod_estab
                        es_tit_acr_abrt.cod_espec_docto = tit_acr.cod_espec_docto
                        es_tit_acr_abrt.cod_ser_docto   = tit_acr.cod_ser_docto
                        es_tit_acr_abrt.cod_tit_acr     = tit_acr.cod_tit_acr
                        es_tit_acr_abrt.cod_parcela     = tit_acr.cod_parcela
                        es_tit_acr_abrt.val_pendente    = es-tit-acr-importa-tit.val_recebido.
                END.
            END.
        END.

        DELETE es-tit-acr-importa-tit.

        oDetalhe = NEW JsonObject().
        oDetalhe:Add("id", c-id).
        oDetalhe:Add("status", "OK").
        oDetalhe:Add("mensagem", "Removido com sucesso.").
        aDetalhes:Add(oDetalhe).
        i-removidos = i-removidos + 1.

    END.

    oResp = NEW JsonObject().
    oResp:Add("success",   i-erros = 0).
    oResp:Add("message",   STRING(i-removidos) + " registro(s) removido(s)."
                           + (IF i-erros > 0 THEN " " + STRING(i-erros) + " erro(s)." ELSE "")).
    oResp:Add("removidos", i-removidos).
    oResp:Add("erros",     i-erros).
    oResp:Add("detalhes",  aDetalhes).
    oResp:Write(lc-resposta, TRUE).
    i-status = IF i-erros = 0 THEN 200 ELSE 207.

END PROCEDURE.
PROCEDURE pi-processar:

    DEFINE INPUT  PARAMETER oJsonBody   AS JsonObject NO-UNDO.
    DEFINE OUTPUT PARAMETER lc-resposta AS LONGCHAR   NO-UNDO.
    DEFINE OUTPUT PARAMETER i-status    AS INTEGER    NO-UNDO.

    DEFINE VARIABLE acgcs        AS JsonArray  NO-UNDO.
    DEFINE VARIABLE aDetalhes       AS JsonArray  NO-UNDO.
    DEFINE VARIABLE oDetalhe        AS JsonObject NO-UNDO.
    DEFINE VARIABLE oResp           AS JsonObject NO-UNDO.
    DEFINE VARIABLE c-cgc           AS CHARACTER  NO-UNDO.
    DEFINE VARIABLE c-cod-refer     AS CHARACTER  NO-UNDO.
    DEFINE VARIABLE c-cod-ref-geral AS CHARACTER  NO-UNDO.
    DEFINE VARIABLE c-usuario       AS CHARACTER  NO-UNDO.
    DEFINE VARIABLE c-msg-lote      AS CHARACTER  NO-UNDO.
    DEFINE VARIABLE h-acr901zf      AS HANDLE     NO-UNDO.
    DEFINE VARIABLE v-des-dat       AS CHARACTER  NO-UNDO.
    DEFINE VARIABLE v-num-seg       AS INTEGER    NO-UNDO.
    DEFINE VARIABLE v-log-refer-uni AS LOGICAL    NO-UNDO.
    DEFINE VARIABLE i-idx           AS INTEGER    NO-UNDO.
    DEFINE VARIABLE i-num-seq-liq   AS INTEGER    NO-UNDO INITIAL 0.
    DEFINE VARIABLE i-ref-seq       AS INTEGER    NO-UNDO INITIAL 0.
    DEFINE VARIABLE i-proc          AS INTEGER    NO-UNDO INITIAL 0.
    DEFINE VARIABLE i-erro          AS INTEGER    NO-UNDO INITIAL 0.
    DEFINE VARIABLE d-val-liq       AS DECIMAL    NO-UNDO.
    DEFINE VARIABLE de-devido       AS DECIMAL    NO-UNDO.
    DEFINE VARIABLE de-pago         AS DECIMAL    NO-UNDO.
    DEFINE VARIABLE c-cart-liq      AS CHARACTER  NO-UNDO.
    DEFINE VARIABLE c-erro-cart     AS CHARACTER  NO-UNDO.
    DEFINE VARIABLE d-dat-mov       AS DATE       NO-UNDO.

    DEFINE VARIABLE cRaizCnpj AS CHARACTER NO-UNDO.
        DEFINE VARIABLE c-titulo-ad  AS CHARACTER NO-UNDO.
    DEFINE VARIABLE h-acr900zi   AS HANDLE    NO-UNDO.
    DEFINE VARIABLE v-log-ad-uni AS LOGICAL   NO-UNDO.
    DEFINE VARIABLE i-ref-ad     AS INTEGER   NO-UNDO INITIAL 0.
    DEFINE VARIABLE c-refer-ad   AS CHARACTER NO-UNDO.
    DEFINE VARIABLE c-estab-ad   AS CHARACTER NO-UNDO.
    DEFINE VARIABLE c-portador-ad AS CHARACTER NO-UNDO.
    DEFINE VARIABLE c-cart-ad    AS CHARACTER NO-UNDO.
    DEFINE VARIABLE c-parc-ad    AS CHARACTER NO-UNDO.
    DEFINE VARIABLE d-vencto-ad  AS DATE      NO-UNDO.
    DEFINE VARIABLE c-erro-api-ad AS CHARACTER NO-UNDO.

    DEFINE VARIABLE l-encontrou  AS LOGICAL NO-UNDO.
    DEFINE VARIABLE l-divergente AS LOGICAL NO-UNDO.
    DEFINE VARIABLE l-parc-reg   AS LOGICAL NO-UNDO.
    DEFINE VARIABLE l-ok-acerto  AS LOGICAL NO-UNDO.
    DEFINE VARIABLE c-msg-acerto AS CHARACTER NO-UNDO.
    DEFINE VARIABLE r-tit-acr    AS ROWID   NO-UNDO.

    
    DEFINE VARIABLE oRealBody AS JsonObject NO-UNDO.
    DEFINE VARIABLE lc-debug  AS LONGCHAR   NO-UNDO.

    oJsonBody:Write(lc-debug, TRUE).

    IF oJsonBody:Has("payload") THEN
        oRealBody = oJsonBody:GetJsonObject("payload") NO-ERROR.
    ELSE IF oJsonBody:Has("requestBody") THEN
        oRealBody = oJsonBody:GetJsonObject("requestBody") NO-ERROR.
    ELSE IF oJsonBody:Has("body") THEN
        oRealBody = oJsonBody:GetJsonObject("body") NO-ERROR.
    ELSE
        oRealBody = oJsonBody.

    
    IF oRealBody:Has("codUsuario") THEN
        c-usuario = oRealBody:GetCharacter("codUsuario") NO-ERROR.
    IF c-usuario = "" OR c-usuario = ? THEN
        c-usuario = USERID("DICT") NO-ERROR.
    IF c-usuario = "" OR c-usuario = ? THEN
        c-usuario = USERID(LDBNAME(1)) NO-ERROR.
        
    
    DEFINE VARIABLE l-ok-lote      AS LOGICAL   NO-UNDO.
    DEFINE VARIABLE c-msg-lote-req AS CHARACTER NO-UNDO.
    DEFINE VARIABLE l-proc-lote    AS LOGICAL   NO-UNDO.
    DEFINE VARIABLE aIdsLote       AS JsonArray NO-UNDO.
    l-proc-lote = (IF oRealBody:Has("processarLote") THEN oRealBody:GetLogical("processarLote") ELSE NO) NO-ERROR.
    IF l-proc-lote = ? THEN l-proc-lote = NO.
    IF l-proc-lote THEN DO:
        aIdsLote = (IF oRealBody:Has("idsSel") THEN oRealBody:GetJsonArray("idsSel") ELSE ?) NO-ERROR.
        RUN pi-processar-lote (INPUT aIdsLote, INPUT c-usuario,
                               OUTPUT l-ok-lote, OUTPUT c-msg-lote-req).
        oResp = NEW JsonObject().
        oResp:Add("success", l-ok-lote).
        oResp:Add("message", c-msg-lote-req).
        oResp:Write(lc-resposta, TRUE).
        i-status = (IF l-ok-lote THEN 200 ELSE 207).
        RETURN.
    END.

    
    DEFINE VARIABLE l-processar-todos AS LOGICAL NO-UNDO.
    DEFINE VARIABLE l-apenas-vinculados AS LOGICAL NO-UNDO.
    l-processar-todos = (IF oRealBody:Has("processarTodos") THEN oRealBody:GetLogical("processarTodos") ELSE FALSE) NO-ERROR.
    l-apenas-vinculados = (IF oRealBody:Has("apenasVinculados") THEN oRealBody:GetLogical("apenasVinculados") ELSE FALSE) NO-ERROR.

    
    DEFINE VARIABLE l-filtro-itens AS LOGICAL   NO-UNDO.
    DEFINE VARIABLE aIdsSel        AS JsonArray NO-UNDO.
    DEFINE VARIABLE c-id-sel       AS CHARACTER NO-UNDO.
    DEFINE VARIABLE c-val-sel      AS CHARACTER NO-UNDO.
    DEFINE VARIABLE i-idx-sel      AS INTEGER   NO-UNDO.

    EMPTY TEMP-TABLE tt-item-sel.
    l-filtro-itens = NO.
    IF oRealBody:Has("idsSel") THEN DO:
        aIdsSel = oRealBody:GetJsonArray("idsSel") NO-ERROR.
        IF VALID-OBJECT(aIdsSel) THEN
        DO i-idx-sel = 1 TO aIdsSel:Length:
            c-id-sel = aIdsSel:GetCharacter(i-idx-sel) NO-ERROR.
            IF c-id-sel = "" OR c-id-sel = ? THEN NEXT.
            c-val-sel = (IF NUM-ENTRIES(c-id-sel, "|") >= 7 THEN ENTRY(7, c-id-sel, "|") ELSE "").
            IF SESSION:NUMERIC-DECIMAL-POINT = "," THEN c-val-sel = REPLACE(c-val-sel, ".", ",").
            CREATE tt-item-sel.
            ASSIGN tt-item-sel.estab   = (IF NUM-ENTRIES(c-id-sel, "|") >= 2 THEN ENTRY(2, c-id-sel, "|") ELSE "")
                   tt-item-sel.espec   = (IF NUM-ENTRIES(c-id-sel, "|") >= 3 THEN ENTRY(3, c-id-sel, "|") ELSE "")
                   tt-item-sel.serie   = (IF NUM-ENTRIES(c-id-sel, "|") >= 4 THEN ENTRY(4, c-id-sel, "|") ELSE "")
                   tt-item-sel.titulo  = (IF NUM-ENTRIES(c-id-sel, "|") >= 5 THEN ENTRY(5, c-id-sel, "|") ELSE "")
                   tt-item-sel.parcela = (IF NUM-ENTRIES(c-id-sel, "|") >= 6 THEN ENTRY(6, c-id-sel, "|") ELSE "")
                   tt-item-sel.val     = DECIMAL(c-val-sel) NO-ERROR.
            l-filtro-itens = YES.
        END.
    END.

    IF NOT l-processar-todos AND (NOT VALID-OBJECT(oRealBody) OR NOT oRealBody:Has("cgcs")) THEN DO:
        oResp = NEW JsonObject().
        oResp:Add("error", "Campo 'cgcs' nao encontrado. Recebido: " + STRING(lc-debug)).
        oResp:Write(lc-resposta, TRUE).
        i-status = 400.
        RETURN.
    END.

    IF NOT l-processar-todos THEN DO:
        acgcs = oRealBody:GetJsonArray("cgcs").
        IF acgcs:Length = 0 THEN DO:
            oResp = NEW JsonObject().
            oResp:Add("error", "Lista de CGC vazia.").
            oResp:Write(lc-resposta, TRUE).
            i-status = 400.
            RETURN.
        END.
    END.
    ELSE DO:
        acgcs = NEW JsonArray().
        FOR EACH es-tit-acr-importa-tit NO-LOCK
            WHERE es-tit-acr-importa-tit.ind_sit_importacao = "Pendente"
               OR es-tit-acr-importa-tit.ind_sit_importacao = "Erro"
            BREAK BY es-tit-acr-importa-tit.cgc:
            IF FIRST-OF(es-tit-acr-importa-tit.cgc) THEN
                acgcs:Add(es-tit-acr-importa-tit.cgc).
        END.
        IF acgcs:Length = 0 THEN DO:
            oResp = NEW JsonObject().
            oResp:Add("error", "Nenhum registro pendente ou com erro encontrado para processar.").
            oResp:Write(lc-resposta, TRUE).
            i-status = 400.
            RETURN.
        END.
    END.
    
    
    
     
    
        

    
    
    RUN pi-carteira-liquidacao (OUTPUT c-cart-liq, OUTPUT c-erro-cart).
    IF c-erro-cart <> "" THEN DO:
        oResp = NEW JsonObject().
        oResp:Add("success", FALSE).
        oResp:Add("error", c-erro-cart).
        oResp:Write(lc-resposta, TRUE).
        i-status = 400.
        RETURN.
    END.

    DO i-idx = 1 TO acgcs:Length:

        c-cgc = acgcs:GetCharacter(i-idx).

        FOR EACH es-tit-acr-importa-tit NO-LOCK
            WHERE es-tit-acr-importa-tit.cgc               = c-cgc
              AND es-tit-acr-importa-tit.ind_sit_importacao = "Erro":

              FIND CURRENT es-tit-acr-importa-tit EXCLUSIVE-LOCK NO-WAIT NO-ERROR.
              IF LOCKED es-tit-acr-importa-tit THEN NEXT.

              IF l-filtro-itens AND NOT CAN-FIND(FIRST tt-item-sel
                   WHERE tt-item-sel.estab   = es-tit-acr-importa-tit.cod_estab
                     AND tt-item-sel.espec   = es-tit-acr-importa-tit.cod_espec_docto
                     AND tt-item-sel.serie   = es-tit-acr-importa-tit.cod_ser_docto
                     AND tt-item-sel.titulo  = es-tit-acr-importa-tit.cod_tit_acr
                     AND tt-item-sel.parcela = es-tit-acr-importa-tit.cod_parcela
                     AND tt-item-sel.val     = es-tit-acr-importa-tit.val_recebido) THEN NEXT.

              ASSIGN es-tit-acr-importa-tit.ind_sit_importacao = "Pendente"
                     es-tit-acr-importa-tit.des_mensagem_erro  = ''.
        END.

        FOR EACH es-tit-acr-importa-tit NO-LOCK
            WHERE es-tit-acr-importa-tit.cgc                = c-cgc
              AND es-tit-acr-importa-tit.ind_sit_importacao = "Pendente":

            FIND CURRENT es-tit-acr-importa-tit EXCLUSIVE-LOCK NO-WAIT NO-ERROR.
            IF LOCKED es-tit-acr-importa-tit THEN DO:
                CREATE tt-proc-item.
                ASSIGN tt-proc-item.cgc           = c-cgc
                       tt-proc-item.status-result = "ERRO"
                       tt-proc-item.mensagem      = "Registro em uso por outro usuario. Tente novamente.".
                i-erro = i-erro + 1.
                NEXT.
            END.

            
            IF l-apenas-vinculados AND es-tit-acr-importa-tit.cod_tit_acr = '' THEN NEXT.

            IF l-filtro-itens AND NOT CAN-FIND(FIRST tt-item-sel
                 WHERE tt-item-sel.estab   = es-tit-acr-importa-tit.cod_estab
                   AND tt-item-sel.espec   = es-tit-acr-importa-tit.cod_espec_docto
                   AND tt-item-sel.serie   = es-tit-acr-importa-tit.cod_ser_docto
                   AND tt-item-sel.titulo  = es-tit-acr-importa-tit.cod_tit_acr
                   AND tt-item-sel.parcela = es-tit-acr-importa-tit.cod_parcela
                   AND tt-item-sel.val     = es-tit-acr-importa-tit.val_recebido) THEN NEXT.

            ASSIGN cRaizCnpj    = SUBSTRING(es-tit-acr-importa-tit.cgc, 1, 8)
                   l-encontrou  = FALSE
                   l-divergente = FALSE
                   r-tit-acr    = ?.

            
            l-parc-reg = (NUM-ENTRIES(es-tit-acr-importa-tit.cod_arq_origem, "|") >= 3
                          AND ENTRY(3, es-tit-acr-importa-tit.cod_arq_origem, "|") = "YES").

            CREATE tt-proc-item.
            ASSIGN tt-proc-item.cgc      = es-tit-acr-importa-tit.cgc
            tt-proc-item.cod_estab       = es-tit-acr-importa-tit.cod_estab
            tt-proc-item.cod_espec_docto = es-tit-acr-importa-tit.cod_espec_docto
            tt-proc-item.cod_ser_docto   = es-tit-acr-importa-tit.cod_ser_docto
            tt-proc-item.cod_tit_acr     = es-tit-acr-importa-tit.cod_tit_acr
            tt-proc-item.cod_parcela     = es-tit-acr-importa-tit.cod_parcela
            tt-proc-item.status-result   = "OK"
            tt-proc-item.r-importa = ROWID(es-tit-acr-importa-tit) . 
            
           
            
            IF es-tit-acr-importa-tit.cod_tit_acr = '' THEN
            DO:
                FIND FIRST es_tit_acr_abrt WHERE 
                           es_tit_acr_abrt.cod_estab       = es-tit-acr-importa-tit.cod_estab         AND
                           es_tit_acr_abrt.cod_espec_docto = es-tit-acr-importa-tit.cod_espec_docto   AND
                           es_tit_acr_abrt.cod_ser_docto   = es-tit-acr-importa-tit.cod_ser_docto     AND
                           es_tit_acr_abrt.cod_tit_acr     = es-tit-acr-importa-tit.cod_tit_acr       AND
                           es_tit_acr_abrt.cod_parcela     = es-tit-acr-importa-tit.cod_parcela       AND
                           es_tit_acr_abrt.val_pendente    = es-tit-acr-importa-tit.val_recebido      EXCLUSIVE-LOCK NO-ERROR.     
                           
                
                IF NOT AVAIL es_tit_acr_abrt THEN
                DO:
                    FIND FIRST es_tit_acr_abrt WHERE 
                           es_tit_acr_abrt.cgc             = es-tit-acr-importa-tit.cgc           AND
                           es_tit_acr_abrt.val_pendente    = es-tit-acr-importa-tit.val_recebido  EXCLUSIVE-LOCK NO-ERROR. 
                END.
                
                
                IF NOT AVAIL es_tit_acr_abrt THEN
                DO:
                    FIND FIRST es_tit_acr_abrt WHERE 
                              es_tit_acr_abrt.cgc-8char    = cRaizCnpj                        AND
                              es_tit_acr_abrt.val_pendente = es-tit-acr-importa-tit.val_recebido  EXCLUSIVE-LOCK NO-ERROR.
                    
                END.
                
                IF AVAIL es_tit_acr_abrt THEN
                DO:
                    ASSIGN
                    es-tit-acr-importa-tit.cod_estab       = es_tit_acr_abrt.cod_estab      
                    es-tit-acr-importa-tit.cod_espec_docto = es_tit_acr_abrt.cod_espec_docto
                    es-tit-acr-importa-tit.cod_ser_docto   = es_tit_acr_abrt.cod_ser_docto  
                    es-tit-acr-importa-tit.cod_tit_acr     = es_tit_acr_abrt.cod_tit_acr    
                    es-tit-acr-importa-tit.cod_parcela     = es_tit_acr_abrt.cod_parcela
                    
                    tt-proc-item.cod_estab             = es_tit_acr_abrt.cod_estab      
                    tt-proc-item.cod_espec_docto       = es_tit_acr_abrt.cod_espec_docto
                    tt-proc-item.cod_ser_docto         = es_tit_acr_abrt.cod_ser_docto  
                    tt-proc-item.cod_tit_acr           = es_tit_acr_abrt.cod_tit_acr    
                    tt-proc-item.cod_parcela           = es_tit_acr_abrt.cod_parcela. 
                    
                    DELETE es_tit_acr_abrt. 
                END.
            END.   
              
            IF es-tit-acr-importa-tit.cod_tit_acr <> "" THEN DO:
            FIND FIRST tit_acr NO-LOCK
                WHERE tit_acr.cod_estab       = es-tit-acr-importa-tit.cod_estab
                  AND tit_acr.cod_espec_docto = es-tit-acr-importa-tit.cod_espec_docto
                  AND tit_acr.cod_ser_docto   = es-tit-acr-importa-tit.cod_ser_docto
                  AND tit_acr.cod_tit_acr     = es-tit-acr-importa-tit.cod_tit_acr
                  AND tit_acr.cod_parcela     = es-tit-acr-importa-tit.cod_parcela
                NO-ERROR.

                IF AVAIL tit_acr THEN DO:
                    ASSIGN
                    es-tit-acr-importa-tit.cod_portador  = (IF es-tit-acr-importa-tit.cod_portador <> "" THEN es-tit-acr-importa-tit.cod_portador ELSE tit_acr.cod_portador)
                    es-tit-acr-importa-tit.cod_cart_bcia = (IF es-tit-acr-importa-tit.cod_cart_bcia <> "" THEN es-tit-acr-importa-tit.cod_cart_bcia ELSE tit_acr.cod_cart_bcia)
                    es-tit-acr-importa-tit.dat_geracao   = (IF es-tit-acr-importa-tit.dat_geracao <> ? THEN es-tit-acr-importa-tit.dat_geracao ELSE TODAY).  
                
                    ASSIGN r-tit-acr = ROWID(tit_acr).
                    
                    l-encontrou  = TRUE.
                    l-divergente = FALSE.
                        
                    IF l-divergente = TRUE THEN
                    DO:
                       ASSIGN 
                        tt-proc-item.status-result = "ERRO"
                        tt-proc-item.mensagem      = "T�tulo encontrado mas com valor divergente no contas a receber." + " | "
                                                   + "Valor apontado: " + STRING(es-tit-acr-importa-tit.val_recebido) + " | "
                                                   + "Valor do CR: "    + STRING(tit_acr.val_sdo_tit_acr) + " | "
                                                   + "--- Detalhes do T�tulo ---" + " | "
                                                   + "Estabelecimento: " + STRING(es-tit-acr-importa-tit.cod_estab) + " | "
                                                   + "Esp�cie: "         + STRING(es-tit-acr-importa-tit.cod_espec_docto) + " | "
                                                   + "S�rie: "           + STRING(es-tit-acr-importa-tit.cod_ser_docto) + " | "
                                                   + "T�tulo: "          + STRING(es-tit-acr-importa-tit.cod_tit_acr) + " | "
                                                   + "Parcela: "         + STRING(es-tit-acr-importa-tit.cod_parcel) + " | "
                                                   + "usuario: "         + STRING(c-usuario).

                       
                       IF tit_acr.val_sdo_tit_acr > 0 AND tit_acr.log_sdo_tit_acr = YES THEN DO:
                           IF NOT CAN-FIND(FIRST es_tit_acr_abrt WHERE
                              es_tit_acr_abrt.cod_estab       = tit_acr.cod_estab       AND
                              es_tit_acr_abrt.cod_espec_docto = tit_acr.cod_espec_docto AND
                              es_tit_acr_abrt.cod_ser_docto   = tit_acr.cod_ser_docto   AND
                              es_tit_acr_abrt.cod_tit_acr     = tit_acr.cod_tit_acr     AND
                              es_tit_acr_abrt.cod_parcela     = tit_acr.cod_parcela) THEN DO:
                               FIND FIRST emitente WHERE emitente.cod-emitente = tit_acr.cdn_cliente NO-LOCK NO-ERROR.
                               IF AVAIL emitente THEN DO:
                                   CREATE es_tit_acr_abrt.
                                   ASSIGN
                                       es_tit_acr_abrt.cgc             = emitente.cgc
                                       es_tit_acr_abrt.cgc-8char       = SUBSTRING(emitente.cgc, 1, 8)
                                       es_tit_acr_abrt.cod_estab       = tit_acr.cod_estab
                                       es_tit_acr_abrt.cod_espec_docto = tit_acr.cod_espec_docto
                                       es_tit_acr_abrt.cod_ser_docto   = tit_acr.cod_ser_docto
                                       es_tit_acr_abrt.cod_tit_acr     = tit_acr.cod_tit_acr
                                       es_tit_acr_abrt.cod_parcela     = tit_acr.cod_parcela
                                       es_tit_acr_abrt.val_pendente    = tit_acr.val_sdo_tit_acr.
                               END.
                           END.
                       END.

                         NEXT.
                    END.
                END.
                ELSE DO:

                    
                    IF es-tit-acr-importa-tit.cod_espec_docto = "AD" THEN.
                    ELSE DO:
                    ASSIGN 
                        tt-proc-item.status-result = "ERRO"
                        tt-proc-item.mensagem      = "T�tulo n�o encontrado no contas a receber. " + " | "
                                                   + "Estabelecimento: " + STRING(es-tit-acr-importa-tit.cod_estab) + " | "
                                                   + "Esp�cie: "         + STRING(es-tit-acr-importa-tit.cod_espec_docto) + " | "
                                                   + "S�rie: "           + STRING(es-tit-acr-importa-tit.cod_ser_docto) + " | "
                                                   + "T�tulo: "          + STRING(es-tit-acr-importa-tit.cod_tit_acr) + " | "
                                                   + "Parcela: "         + STRING(es-tit-acr-importa-tit.cod_parcel) +  " | "
                                                   + "usuario: "         + STRING(c-usuario).
                                                   
                    NEXT.
                    END.
                END.
            END.

            IF r-tit-acr <> ? THEN  DO:
                FIND tit_acr NO-LOCK WHERE ROWID(tit_acr) = r-tit-acr NO-ERROR.
            END.
            ELSE DO:
                
                ASSIGN v-log-ad-uni = NO.
                REPEAT WHILE v-log-ad-uni = NO:
                    ASSIGN i-ref-ad    = i-ref-ad + 1
                           v-des-dat   = STRING(TODAY, "99999999")
                           v-num-seg   = TIME + i-ref-ad
                           c-refer-ad  = SUBSTRING(v-des-dat, 7, 2)
                                       + SUBSTRING(v-des-dat, 3, 2)
                                       + SUBSTRING(v-des-dat, 1, 2)
                                       + STRING((v-num-seg MOD 9000) + 1000, "9999").

                    ASSIGN v-log-ad-uni = YES.
                    IF CAN-FIND(FIRST lote_impl_tit_acr NO-LOCK
                                WHERE lote_impl_tit_acr.cod_estab = es-tit-acr-importa-tit.cod_estab
                                  AND lote_impl_tit_acr.cod_refer = c-refer-ad) OR
                       INDEX(c-cod-ref-geral, c-refer-ad) > 0 THEN
                        ASSIGN v-log-ad-uni = NO.
                    ELSE
                        ASSIGN c-cod-ref-geral = c-cod-ref-geral + c-refer-ad + " ".
                END.

                
                
                
                
                
           
           

                DEFINE VARIABLE p_dat_refer AS DATE      NO-UNDO.
                DEFINE VARIABLE p_cod_refer AS CHARACTER NO-UNDO.
                DEFINE VARIABLE v_des_dat   AS CHARACTER NO-UNDO.
                DEFINE VARIABLE v_num_aux   AS INTEGER   NO-UNDO.
                DEFINE VARIABLE v_num_cont  AS INTEGER   NO-UNDO.
                DEFINE VARIABLE vi-seq      AS INTEGER   NO-UNDO INITIAL 0.
                DEFINE VARIABLE c-resultado AS CHARACTER NO-UNDO.
                

                ASSIGN p_dat_refer = TODAY.

                DO vi-seq = 1 TO 1000:

                    ASSIGN v_des_dat   = STRING(p_dat_refer, "99999999")
                           p_cod_refer = SUBSTRING(v_des_dat, 7, 2)  
                                       + SUBSTRING(v_des_dat, 3, 2)  
                                       + "T".                         

                    DO v_num_cont = 1 TO 3:
                        ASSIGN v_num_aux   = (RANDOM(0, vi-seq + 9999) MOD 26) + 97
                               p_cod_refer = p_cod_refer + CHR(v_num_aux).
                    END.

                    
                    ASSIGN c-titulo-ad = "AD" + p_cod_refer.

                    c-resultado = c-resultado + STRING(vi-seq, "9999") + " -> " + c-titulo-ad + CHR(10).

                    
                    IF vi-seq MOD 100 = 0 THEN DO:
                        MESSAGE c-resultado VIEW-AS ALERT-BOX.
                        ASSIGN c-resultado = "".
                    END.

                END.
                       

                                   
                
                
                IF es-tit-acr-importa-tit.cod_espec_docto = "AD"
                   AND es-tit-acr-importa-tit.cod_tit_acr <> "" THEN
                    c-titulo-ad = es-tit-acr-importa-tit.cod_tit_acr.

                FIND FIRST emitente NO-LOCK
                     WHERE emitente.cgc = es-tit-acr-importa-tit.cgc NO-ERROR.

                IF NOT AVAIL emitente THEN
                    FIND FIRST emitente NO-LOCK
                         WHERE emitente.cgc BEGINS cRaizCnpj NO-ERROR.

                IF NOT AVAIL emitente THEN DO:
                    ASSIGN tt-proc-item.status-result = "ERRO"
                           tt-proc-item.mensagem      = "Cliente CNPJ " + es-tit-acr-importa-tit.cgc + " nao encontrado para criacao de AD.".
                    NEXT.
                END.

                
                ASSIGN c-estab-ad   = (IF es-tit-acr-importa-tit.cod_estab    <> "" THEN es-tit-acr-importa-tit.cod_estab    ELSE "001")
                       c-portador-ad = (IF es-tit-acr-importa-tit.cod_portador <> "" THEN es-tit-acr-importa-tit.cod_portador ELSE "341")
                       c-cart-ad    = (IF es-tit-acr-importa-tit.cod_cart_bcia <> "" THEN es-tit-acr-importa-tit.cod_cart_bcia ELSE c-cart-liq)
                       d-vencto-ad  = (IF es-tit-acr-importa-tit.dat_geracao   <> ? THEN es-tit-acr-importa-tit.dat_geracao   ELSE TODAY)
                       c-parc-ad    = (IF es-tit-acr-importa-tit.cod_parcela   <> "" THEN es-tit-acr-importa-tit.cod_parcela   ELSE "01").

   
                       
                       
                       
                       
                       
                       
                       
                       
                       
                
                EMPTY TEMP-TABLE tt_integr_acr_lote_impl.
                EMPTY TEMP-TABLE tt_integr_acr_item_lote_impl_9.
                EMPTY TEMP-TABLE tt_integr_acr_repres_comis_2.
                EMPTY TEMP-TABLE tt_integr_acr_aprop_relacto_2b.
                EMPTY TEMP-TABLE tt_params_generic_api.
                EMPTY TEMP-TABLE tt_integr_acr_relacto_pend_aux.
                EMPTY TEMP-TABLE tt_log_erros_atualiz.
                EMPTY TEMP-TABLE tt_integr_acr_aprop_ctbl_pend.

                

                CREATE tt_integr_acr_lote_impl.
                ASSIGN
                    tt_integr_acr_lote_impl.tta_cod_estab           = c-estab-ad
                    tt_integr_acr_lote_impl.tta_cod_refer           = c-refer-ad
                    tt_integr_acr_lote_impl.tta_dat_transacao       = d-vencto-ad
                    tt_integr_acr_lote_impl.tta_ind_tip_espec_docto = ""
                    tt_integr_acr_lote_impl.tta_ind_tip_cobr_acr    = "Normal".

                
                ASSIGN i-num-seq-liq = i-num-seq-liq + 10.

                CREATE tt_integr_acr_item_lote_impl_9.
                ASSIGN
                    tt_integr_acr_item_lote_impl_9.ttv_rec_lote_impl_tit_acr      = RECID(tt_integr_acr_lote_impl)
                    tt_integr_acr_item_lote_impl_9.ttv_rec_item_lote_impl_tit_acr = RECID(tt_integr_acr_item_lote_impl_9)
                    tt_integr_acr_item_lote_impl_9.tta_num_seq_refer               = i-num-seq-liq
                    tt_integr_acr_item_lote_impl_9.tta_cdn_cliente                 = emitente.cod-emitente
                    tt_integr_acr_item_lote_impl_9.tta_cod_espec_docto             = "AD"
                    tt_integr_acr_item_lote_impl_9.tta_cod_ser_docto               = ""
                    tt_integr_acr_item_lote_impl_9.tta_cod_tit_acr                 = c-titulo-ad
                    tt_integr_acr_item_lote_impl_9.tta_cod_tit_acr_bco             = ""
                    tt_integr_acr_item_lote_impl_9.tta_cod_parcela                 = c-parc-ad
                    tt_integr_acr_item_lote_impl_9.tta_cod_portador                = c-portador-ad
                    tt_integr_acr_item_lote_impl_9.tta_cod_cart_bcia               = c-cart-ad
                    tt_integr_acr_item_lote_impl_9.tta_cod_indic_econ              = "Real"
                    tt_integr_acr_item_lote_impl_9.tta_dat_vencto_tit_acr          = d-vencto-ad
                    tt_integr_acr_item_lote_impl_9.tta_dat_emis_docto              = d-vencto-ad
                    tt_integr_acr_item_lote_impl_9.tta_val_tit_acr                 = es-tit-acr-importa-tit.val_recebido
                    tt_integr_acr_item_lote_impl_9.tta_des_text_histor             = "efetivadas via automa��o" 
                    tt_integr_acr_item_lote_impl_9.tta_ind_tip_espec_docto         = "Antecipa��o"
                    tt_integr_acr_item_lote_impl_9.tta_ind_sit_tit_acr             = "Normal"
                    tt_integr_acr_item_lote_impl_9.tta_ind_sit_bcia_tit_acr        = "1"
                    tt_integr_acr_item_lote_impl_9.tta_ind_ender_cobr              = "1"
                    tt_integr_acr_item_lote_impl_9.tta_val_cotac_indic_econ        = 1.

                
                CREATE tt_integr_acr_aprop_ctbl_pend.
                ASSIGN
                    tt_integr_acr_aprop_ctbl_pend.ttv_rec_item_lote_impl_tit_acr = RECID(tt_integr_acr_item_lote_impl_9)
                    tt_integr_acr_aprop_ctbl_pend.tta_cod_unid_negoc             = '99'
                    tt_integr_acr_aprop_ctbl_pend.tta_val_aprop_ctbl             = es-tit-acr-importa-tit.val_recebido.

                
                ASSIGN c-erro-api-ad = "".

                
                DEFINE VARIABLE c-diag       AS CHARACTER NO-UNDO.
                DEFINE VARIABLE i-cnt-lote   AS INTEGER   NO-UNDO.
                DEFINE VARIABLE i-cnt-item   AS INTEGER   NO-UNDO.
                DEFINE VARIABLE i-cnt-ctbl   AS INTEGER   NO-UNDO.
                DEFINE VARIABLE c-ret-val    AS CHARACTER NO-UNDO.

                ASSIGN i-cnt-lote = 0
                       i-cnt-item = 0
                       i-cnt-ctbl = 0.
                FOR EACH tt_integr_acr_lote_impl NO-LOCK:
                    ASSIGN i-cnt-lote = i-cnt-lote + 1.
                END.
                FOR EACH tt_integr_acr_item_lote_impl_9 NO-LOCK:
                    ASSIGN i-cnt-item = i-cnt-item + 1.
                END.
                FOR EACH tt_integr_acr_aprop_ctbl_pend NO-LOCK:
                    ASSIGN i-cnt-ctbl = i-cnt-ctbl + 1.
                END.

                ASSIGN c-diag = "DIAG PRE-API: lotes=" + STRING(i-cnt-lote)
                              + " items=" + STRING(i-cnt-item)
                              + " ctbl=" + STRING(i-cnt-ctbl)
                              + " cliente=" + STRING(emitente.cod-emitente)
                              + " estab=" + c-estab-ad
                              + " titulo=" + c-titulo-ad
                              + " valor=" + STRING(es-tit-acr-importa-tit.val_recebido)
                              + " data(transac/emis/vencto)=" + STRING(DAY(d-vencto-ad),"99") + "/"
                                                                 + STRING(MONTH(d-vencto-ad),"99") + "/"
                                                                 + STRING(YEAR(d-vencto-ad),"9999").

                IF NOT VALID-HANDLE(h-acr900zi) THEN
                    RUN prgfin/acr/acr900zi.py PERSISTENT SET h-acr900zi NO-ERROR.

                IF ERROR-STATUS:ERROR OR NOT VALID-HANDLE(h-acr900zi) THEN DO:
                    ASSIGN tt-proc-item.status-result = "ERRO"
                           tt-proc-item.mensagem      = "Falha ao carregar API acr900zi.py: " + (IF ERROR-STATUS:NUM-MESSAGES > 0 THEN ERROR-STATUS:GET-MESSAGE(1) ELSE "Handle invalido").
                    EMPTY TEMP-TABLE tt_integr_acr_lote_impl.
                    EMPTY TEMP-TABLE tt_integr_acr_item_lote_impl_9.
                    EMPTY TEMP-TABLE tt_log_erros_atualiz.
                    NEXT.
                END.

                ASSIGN c-diag = c-diag + " | HANDLE_OK".

                RUN pi_main_code_integr_acr_new_13 IN h-acr900zi
                    (INPUT  11,
                     INPUT  "CONS-PLANILHAS",
                     INPUT  YES,
                     INPUT  YES,
                     INPUT  TABLE tt_integr_acr_repres_comis_2,
                     INPUT-OUTPUT TABLE tt_integr_acr_item_lote_impl_9,
                     INPUT  TABLE tt_integr_acr_aprop_relacto_2b,
                     INPUT-OUTPUT TABLE tt_params_generic_api,
                     INPUT  TABLE tt_integr_acr_relacto_pend_aux) NO-ERROR.

                
                ASSIGN c-ret-val = RETURN-VALUE NO-ERROR.
                ASSIGN c-diag = c-diag + " | RET=" + (IF c-ret-val <> "" AND c-ret-val <> ? THEN c-ret-val ELSE "vazio").

                IF ERROR-STATUS:ERROR THEN DO:
                    ASSIGN c-diag = c-diag + " | ERR-STATUS:".
                    DO i-ref-ad = 1 TO ERROR-STATUS:NUM-MESSAGES:
                        ASSIGN c-diag = c-diag + ERROR-STATUS:GET-MESSAGE(i-ref-ad) + ";".
                    END.
                END.
                ELSE
                    ASSIGN c-diag = c-diag + " | NO-ERR".

                
                ASSIGN i-cnt-item = 0.
                FOR EACH tt_integr_acr_item_lote_impl_9 NO-LOCK:
                    ASSIGN i-cnt-item = i-cnt-item + 1.
                END.
                ASSIGN c-diag = c-diag + " | POST-items=" + STRING(i-cnt-item).

                IF VALID-HANDLE(h-acr900zi) THEN DO:
                    DELETE PROCEDURE h-acr900zi.
                    ASSIGN h-acr900zi = ?.
                END.

                
                IF CAN-FIND(FIRST tt_log_erros_atualiz) THEN DO:
                    ASSIGN c-erro-api-ad = "".
                    FOR EACH tt_log_erros_atualiz NO-LOCK:
                        ASSIGN c-erro-api-ad = c-erro-api-ad
                                             + STRING(tt_log_erros_atualiz.ttv_num_mensagem)
                                             + " - " + TRIM(tt_log_erros_atualiz.ttv_des_msg_erro) + " | ".
                    END.
                    ASSIGN tt-proc-item.status-result = "ERRO"
                           tt-proc-item.mensagem      = "Falha ao criar AD: " + c-erro-api-ad + " || " + c-diag.
                    EMPTY TEMP-TABLE tt_integr_acr_lote_impl.
                    EMPTY TEMP-TABLE tt_integr_acr_item_lote_impl_9.
                    EMPTY TEMP-TABLE tt_log_erros_atualiz.
                    NEXT.
                END.

                
                ASSIGN es-tit-acr-importa-tit.cod_estab       = c-estab-ad
                       es-tit-acr-importa-tit.cod_espec_docto = "AD"
                       es-tit-acr-importa-tit.cod_ser_docto   = ""
                       es-tit-acr-importa-tit.cod_tit_acr     = c-titulo-ad
                       es-tit-acr-importa-tit.cod_parcela     = c-parc-ad
                       es-tit-acr-importa-tit.cod_portador    = (IF es-tit-acr-importa-tit.cod_portador <> "" THEN es-tit-acr-importa-tit.cod_portador ELSE '341').
                       
                FIND FIRST estabelec WHERE estabelec.cod-estabel = c-estab-ad NO-LOCK NO-ERROR.
                IF AVAIL estabelec AND es-tit-acr-importa-tit.cod_empresa = '' THEN
                DO:
                    ASSIGN es-tit-acr-importa-tit.cod_empresa = estabelec.ep-codigo.
                    
                END.
                       
                
                ASSIGN tt-proc-item.cod_estab       = c-estab-ad
                       tt-proc-item.cod_espec_docto = "AD"
                       tt-proc-item.cod_ser_docto   = ""
                       tt-proc-item.cod_tit_acr     = c-titulo-ad
                       tt-proc-item.cod_parcela     = c-parc-ad.

                EMPTY TEMP-TABLE tt_integr_acr_lote_impl.
                EMPTY TEMP-TABLE tt_integr_acr_item_lote_impl_9.
                EMPTY TEMP-TABLE tt_log_erros_atualiz.

                
                FIND FIRST tit_acr EXCLUSIVE-LOCK
                     WHERE tit_acr.cod_estab       = c-estab-ad
                       AND tit_acr.cod_espec_docto = "AD"
                       AND tit_acr.cod_ser_docto   = ""
                       AND tit_acr.cod_tit_acr     = c-titulo-ad
                       AND tit_acr.cod_parcela     = c-parc-ad NO-ERROR.

                IF NOT AVAIL tit_acr THEN DO:
                    ASSIGN tt-proc-item.status-result = "ERRO"
                           tt-proc-item.mensagem      = "AD nao localizado em tit_acr: " + c-titulo-ad + " || " + c-diag.
                    NEXT.
                END.
                
                ASSIGN tt-proc-item.status-result = "OK"
                       tt-proc-item.mensagem      = "AD Importado com sucesso".

                ASSIGN r-tit-acr    = ROWID(tit_acr)
                       l-encontrou  = TRUE
                       l-divergente = FALSE.

                    ASSIGN
                    es-tit-acr-importa-tit.ind_sit_importacao = (IF tt-proc-item.status-result = "OK" THEN "Importado" ELSE "Erro")
                    es-tit-acr-importa-tit.des_mensagem_erro  = tt-proc-item.mensagem
                    es-tit-acr-importa-tit.dat_processamento  = TODAY
                    es-tit-acr-importa-tit.hra_processamento  = STRING(TIME, "HH:MM:SS").
                    
                    NEXT.
                    
                
            END.

            
            IF r-tit-acr <> ? AND NOT l-encontrou THEN DO:
                NEXT.
            END.

            
            IF AVAILABLE tit_acr AND (
            es-tit-acr-importa-tit.cod_estab       = '' OR
            es-tit-acr-importa-tit.cod_espec_docto = '' OR
            es-tit-acr-importa-tit.cod_ser_docto   = '' OR
            es-tit-acr-importa-tit.cod_tit_acr     = '' OR
            es-tit-acr-importa-tit.cod_parcela     = '' OR
            es-tit-acr-importa-tit.cod_portador    = '' ) THEN DO:
               ASSIGN es-tit-acr-importa-tit.cod_estab       = tit_acr.cod_estab
                      es-tit-acr-importa-tit.cod_espec_docto = tit_acr.cod_espec_docto
                      es-tit-acr-importa-tit.cod_ser_docto   = tit_acr.cod_ser_docto
                      es-tit-acr-importa-tit.cod_tit_acr     = tit_acr.cod_tit_acr
                      es-tit-acr-importa-tit.cod_parcela     = tit_acr.cod_parcela
                      es-tit-acr-importa-tit.cod_portador    = tit_acr.cod_portador.

               ASSIGN tt-proc-item.cod_estab       = tit_acr.cod_estab
                      tt-proc-item.cod_espec_docto = tit_acr.cod_espec_docto
                      tt-proc-item.cod_ser_docto   = tit_acr.cod_ser_docto
                      tt-proc-item.cod_tit_acr     = tit_acr.cod_tit_acr
                      tt-proc-item.cod_parcela     = tit_acr.cod_parcela.
            END.

            FIND FIRST estabelec WHERE estabelec.cod-estabel = tit_acr.cod_estab NO-LOCK NO-ERROR.
            IF AVAIL estabelec AND es-tit-acr-importa-tit.cod_empresa = '' THEN
            DO:
                ASSIGN es-tit-acr-importa-tit.cod_empresa = estabelec.ep-codigo.
            END.
            
            
            

            IF NOT AVAILABLE tit_acr THEN DO:
                ASSIGN tt-proc-item.status-result = "ERRO"
                       tt-proc-item.mensagem      = "Titulo nao encontrado em tit_acr.".
                NEXT.
            END.

            
            IF l-divergente THEN DO:
                
            END.

            IF NOT tit_acr.log_sdo_tit_acr OR tit_acr.val_sdo_tit_acr <= 0 THEN DO:
                ASSIGN tt-proc-item.status-result = "ERRO"
                       tt-proc-item.mensagem      = "Titulo sem saldo em aberto. Saldo: " + TRIM(STRING(tit_acr.val_sdo_tit_acr, ">>>,>>9.99")).
                NEXT.
            END.

            IF es-tit-acr-importa-tit.val_recebido <= 0 THEN DO:
                ASSIGN tt-proc-item.status-result = "ERRO"
                       tt-proc-item.mensagem      = "Valor recebido invalido: " + TRIM(STRING(es-tit-acr-importa-tit.val_recebido, ">>>,>>9.99")).
                NEXT.
            END.

            FIND FIRST usuar_financ_estab_acr NO-LOCK
                 WHERE usuar_financ_estab_acr.cod_usuario = c-usuario
                   AND usuar_financ_estab_acr.cod_estab   = tit_acr.cod_estab NO-ERROR.

            IF NOT AVAIL usuar_financ_estab_acr THEN DO:
                ASSIGN tt-proc-item.status-result = "ERRO"
                       tt-proc-item.mensagem      = "Usuario " + c-usuario + " sem cadastro financeiro no estab: " + tit_acr.cod_estab.
                NEXT.
            END.

            IF usuar_financ_estab_acr.log_habilit_liquidac_acr = NO THEN DO:
                ASSIGN tt-proc-item.status-result = "ERRO"
                       tt-proc-item.mensagem      = "Usuario " + c-usuario + " sem permissao para liquidar titulo no estab: " + tit_acr.cod_estab.
                NEXT.
            END.

            

            
            
            
            ASSIGN
                de-devido = tit_acr.val_sdo_tit_acr + tit_acr.val_juros + tit_acr.val_multa_tit_acr
                de-pago   = es-tit-acr-importa-tit.val_recebido + es-tit-acr-importa-tit.val_juros + es-tit-acr-importa-tit.val_multa
                d-dat-mov = (IF es-tit-acr-importa-tit.dat_geracao <> ? THEN es-tit-acr-importa-tit.dat_geracao ELSE TODAY).
            IF es-tit-acr-importa-tit.val_recebido = 0
               AND es-tit-acr-importa-tit.val_juros = 0
               AND es-tit-acr-importa-tit.val_multa = 0 THEN
                de-pago = de-devido.

            
            IF de-pago < de-devido THEN DO:
                RUN pi-acerto-valor-menor (INPUT  ROWID(tit_acr),
                                           INPUT  es-tit-acr-importa-tit.val_recebido,
                                           INPUT  c-usuario,
                                           INPUT  d-dat-mov,
                                           OUTPUT l-ok-acerto,
                                           OUTPUT c-msg-acerto).
                ASSIGN tt-proc-item.status-result = (IF l-ok-acerto THEN "OK" ELSE "ERRO")
                       tt-proc-item.mensagem      = (IF l-ok-acerto THEN "Acerto de valor a menor efetivado." ELSE c-msg-acerto).
                NEXT.
            END.

            FIND CURRENT tit_acr EXCLUSIVE-LOCK NO-ERROR.

            
            FIND FIRST tt_integr_acr_liquidac_lote EXCLUSIVE-LOCK
                WHERE tt_integr_acr_liquidac_lote.tta_cod_estab_refer = tit_acr.cod_estab NO-ERROR.

            IF NOT AVAILABLE tt_integr_acr_liquidac_lote THEN DO:
                ASSIGN v-log-refer-uni = NO.
                REPEAT WHILE v-log-refer-uni = NO:
                    ASSIGN i-ref-seq   = i-ref-seq + 1
                           v-des-dat   = STRING(TODAY, "99999999")
                           v-num-seg   = TIME + i-ref-seq
                           c-cod-refer = SUBSTRING(v-des-dat, 7, 2)
                                       + SUBSTRING(v-des-dat, 3, 2)
                                       + SUBSTRING(v-des-dat, 1, 2)
                                       + STRING((v-num-seg MOD 9000) + 1000, "9999").

                    ASSIGN v-log-refer-uni = YES.
                    IF CAN-FIND(FIRST lote_impl_tit_acr NO-LOCK WHERE lote_impl_tit_acr.cod_estab = tit_acr.cod_estab AND lote_impl_tit_acr.cod_refer = c-cod-refer) OR
                       CAN-FIND(FIRST lote_liquidac_acr NO-LOCK WHERE lote_liquidac_acr.cod_estab_refer = tit_acr.cod_estab AND lote_liquidac_acr.cod_refer = c-cod-refer) OR
                       CAN-FIND(FIRST movto_tit_acr NO-LOCK WHERE movto_tit_acr.cod_estab = tit_acr.cod_estab AND movto_tit_acr.cod_refer = c-cod-refer) OR
                       CAN-FIND(FIRST his_movto_tit_acr_histor NO-LOCK WHERE his_movto_tit_acr_histor.cod_estab = tit_acr.cod_estab AND his_movto_tit_acr_histor.cod_refer = c-cod-refer) OR
                       INDEX(c-cod-ref-geral, c-cod-refer) > 0 THEN
                        ASSIGN v-log-refer-uni = NO.
                    ELSE
                        ASSIGN c-cod-ref-geral = c-cod-ref-geral + c-cod-refer + " ".
                END.

                FIND FIRST estabelecimento NO-LOCK WHERE estabelecimento.cod_estab = tit_acr.cod_estab NO-ERROR.

                CREATE tt_integr_acr_liquidac_lote.
                ASSIGN
                    tt_integr_acr_liquidac_lote.tta_cod_empresa             = (IF AVAILABLE estabelecimento THEN estabelecimento.cod_empresa ELSE tit_acr.cod_empresa)
                    tt_integr_acr_liquidac_lote.tta_cod_estab_refer         = tit_acr.cod_estab
                    tt_integr_acr_liquidac_lote.tta_cod_refer               = c-cod-refer
                    tt_integr_acr_liquidac_lote.tta_cod_usuario             = c-usuario
                    tt_integr_acr_liquidac_lote.tta_dat_gerac_lote_liquidac = d-dat-mov
                    tt_integr_acr_liquidac_lote.tta_ind_tip_liquidac_acr    = 'lote'
                    tt_integr_acr_liquidac_lote.ttv_log_atualiz_refer       = YES
                    tt_integr_acr_liquidac_lote.ttv_rec_lote_liquidac_acr   = RECID(tt_integr_acr_liquidac_lote)
                    tt_integr_acr_liquidac_lote.ttv_log_gera_lote_parcial   = YES.
            END.

            
            ASSIGN i-num-seq-liq          = i-num-seq-liq + 10
                   d-val-liq              = tit_acr.val_sdo_tit_acr  
                   tt-proc-item.cod_refer = tt_integr_acr_liquidac_lote.tta_cod_refer.

            CREATE tt_integr_acr_liq_item_lote_3.
            ASSIGN
                tt_integr_acr_liq_item_lote_3.tta_cod_empresa                = tit_acr.cod_empresa
                tt_integr_acr_liq_item_lote_3.tta_cod_estab                  = tit_acr.cod_estab
                tt_integr_acr_liq_item_lote_3.tta_cod_espec_docto            = tit_acr.cod_espec_docto
                tt_integr_acr_liq_item_lote_3.tta_cod_ser_docto              = tit_acr.cod_ser_docto
                tt_integr_acr_liq_item_lote_3.tta_num_seq_refer              = i-num-seq-liq
                tt_integr_acr_liq_item_lote_3.tta_cod_tit_acr                = tit_acr.cod_tit_acr
                tt_integr_acr_liq_item_lote_3.tta_cod_parcela                = tit_acr.cod_parcela
                tt_integr_acr_liq_item_lote_3.tta_cdn_cliente                = tit_acr.cdn_cliente
                tt_integr_acr_liq_item_lote_3.tta_cod_portador               = es-tit-acr-importa-tit.cod_portador
                tt_integr_acr_liq_item_lote_3.tta_cod_cart_bcia              = (IF es-tit-acr-importa-tit.cod_cart_bcia <> "" THEN es-tit-acr-importa-tit.cod_cart_bcia ELSE c-cart-liq)
                tt_integr_acr_liq_item_lote_3.tta_cod_indic_econ             = tit_acr.cod_indic_econ
                tt_integr_acr_liq_item_lote_3.tta_dat_cr_liquidac_tit_acr    = d-dat-mov
                tt_integr_acr_liq_item_lote_3.tta_dat_cr_liquidac_calc       = d-dat-mov
                tt_integr_acr_liq_item_lote_3.tta_dat_liquidac_tit_acr       = d-dat-mov
                tt_integr_acr_liq_item_lote_3.tta_val_liquidac_tit_acr       = d-val-liq
                tt_integr_acr_liq_item_lote_3.tta_val_desc_tit_acr           = es-tit-acr-importa-tit.val_desconto
                tt_integr_acr_liq_item_lote_3.tta_val_abat_tit_acr           = es-tit-acr-importa-tit.val_abatimento
                tt_integr_acr_liq_item_lote_3.tta_val_despes_bcia            = 0
                tt_integr_acr_liq_item_lote_3.tta_val_multa_tit_acr          = tit_acr.val_multa_tit_acr
                tt_integr_acr_liq_item_lote_3.tta_val_juros                  = tit_acr.val_juros
                tt_integr_acr_liq_item_lote_3.tta_val_cm_tit_acr             = tit_acr.val_cm_tit_acr
                tt_integr_acr_liq_item_lote_3.tta_ind_tip_item_liquidac_acr  = 'pagamento'
                tt_integr_acr_liq_item_lote_3.ttv_rec_item_lote_liquidac_acr = RECID(tit_acr)
                tt_integr_acr_liq_item_lote_3.ttv_rec_lote_liquidac_acr      = RECID(tt_integr_acr_liquidac_lote)
                tt_integr_acr_liq_item_lote_3.tta_cod_livre_1                = tit_acr.cod_livre_1
                tt_integr_acr_liq_item_lote_3.tta_cod_livre_2                = tit_acr.cod_livre_2
                tt_integr_acr_liq_item_lote_3.tta_log_livre_1                = tit_acr.log_livre_1
                tt_integr_acr_liq_item_lote_3.tta_log_livre_2                = tit_acr.log_livre_2
                tt_integr_acr_liq_item_lote_3.tta_dat_livre_1                = tit_acr.dat_livre_1
                tt_integr_acr_liq_item_lote_3.tta_dat_livre_2                = tit_acr.dat_livre_2
                tt_integr_acr_liq_item_lote_3.tta_val_livre_1                = tit_acr.val_livre_1
                tt_integr_acr_liq_item_lote_3.tta_val_livre_2                = tit_acr.val_livre_2
                tt_integr_acr_liq_item_lote_3.tta_num_livre_1                = tit_acr.num_livre_1
                tt_integr_acr_liq_item_lote_3.tta_num_livre_2                = tit_acr.num_livre_2
                tt_integr_acr_liq_item_lote_3.tta_ind_tip_calc_juros         = tit_acr.ind_tip_calc_juros
                tt_integr_acr_liq_item_lote_3.tta_val_cotac_indic_econ       = 1
                tt_integr_acr_liq_item_lote_3.tta_des_text_histor            = "efetivadas via automa��o" . 

        END. 
    END. 

    
    IF CAN-FIND(FIRST tt_integr_acr_liq_item_lote_3) THEN DO:

        RUN prgfin/acr/acr901zf.p PERSISTENT SET h-acr901zf NO-ERROR.

        RUN pi_main_code_api_integr_acr_liquidac_6 IN h-acr901zf
            (INPUT  1,
             INPUT  TABLE tt_integr_acr_liquidac_lote,
             INPUT  TABLE tt_integr_acr_liq_item_lote_3,
             INPUT  TABLE tt_integr_acr_abat_antecip,
             INPUT  TABLE tt_integr_acr_abat_prev,
             INPUT  TABLE tt_integr_acr_cheq,
             INPUT  TABLE tt_integr_acr_liquidac_impto_2,
             INPUT  TABLE tt_integr_acr_rel_pend_cheq,
             INPUT  TABLE tt_integr_acr_liq_aprop_ctbl,
             INPUT  TABLE tt_integr_acr_liq_desp_rec,
             INPUT  TABLE tt_integr_acr_aprop_liq_antec,
             INPUT  "EMS2",
             OUTPUT TABLE tt_log_erros_import_liquidac,
             INPUT  TABLE tt_integr_cambio_ems5,
             INPUT  TABLE tt_params_generic_api).

        IF VALID-HANDLE(h-acr901zf) THEN DO:
            DELETE PROCEDURE h-acr901zf.
            ASSIGN h-acr901zf = ?.
        END.

        
        FOR EACH tt_log_erros_import_liquidac NO-LOCK:

            
            

            
            IF (tt_log_erros_import_liquidac.tta_cod_tit_acr = '' OR
                tt_log_erros_import_liquidac.tta_cod_tit_acr = ?) THEN DO:
                ASSIGN c-msg-lote = STRING(tt_log_erros_import_liquidac.ttv_num_erro_log)
                                  + " - " + TRIM(tt_log_erros_import_liquidac.ttv_des_msg_erro).
                FOR EACH tt-proc-item EXCLUSIVE-LOCK
                    WHERE tt-proc-item.cod_refer    = tt_log_erros_import_liquidac.tta_cod_refer
                      AND tt-proc-item.status-result = "OK":
                    ASSIGN tt-proc-item.status-result = "ERRO"
                           tt-proc-item.mensagem      = c-msg-lote .
                END.
            END.
            ELSE DO:
                FIND FIRST tt-proc-item EXCLUSIVE-LOCK
                    WHERE tt-proc-item.cod_estab       = tt_log_erros_import_liquidac.tta_cod_estab
                      AND tt-proc-item.cod_espec_docto = tt_log_erros_import_liquidac.tta_cod_espec_docto
                      AND tt-proc-item.cod_ser_docto   = tt_log_erros_import_liquidac.tta_cod_ser_docto
                      AND tt-proc-item.cod_tit_acr     = tt_log_erros_import_liquidac.tta_cod_tit_acr
                    NO-ERROR.
                IF AVAILABLE tt-proc-item THEN
                    ASSIGN tt-proc-item.status-result = "ERRO"
                           tt-proc-item.mensagem      = STRING(tt_log_erros_import_liquidac.ttv_num_erro_log)
                                                      + " - " + TRIM(tt_log_erros_import_liquidac.ttv_des_msg_erro) .
            END.

        END. 
        
        
        FIND tit_acr WHERE ROWID(tit_acr) = r-tit-acr NO-LOCK NO-ERROR.
        IF tit_acr.val_sdo_tit_acr = 0 THEN DO:
            ASSIGN tt-proc-item.status-result = "OK"
                   tt-proc-item.mensagem      = "T�tulo liquidado via importa��o".

        END.
        
        

        
        EMPTY TEMP-TABLE tt_integr_acr_liquidac_lote.
        EMPTY TEMP-TABLE tt_integr_acr_liq_item_lote_3.
        EMPTY TEMP-TABLE tt_integr_acr_abat_antecip.
        EMPTY TEMP-TABLE tt_integr_acr_abat_prev.
        EMPTY TEMP-TABLE tt_integr_acr_cheq.
        EMPTY TEMP-TABLE tt_integr_acr_liquidac_impto_2.
        EMPTY TEMP-TABLE tt_integr_acr_rel_pend_cheq.
        EMPTY TEMP-TABLE tt_integr_acr_liq_aprop_ctbl.
        EMPTY TEMP-TABLE tt_integr_acr_liq_desp_rec.
        EMPTY TEMP-TABLE tt_integr_acr_aprop_liq_antec.
        EMPTY TEMP-TABLE tt_log_erros_import_liquidac.

    END. 

    
    aDetalhes = NEW JsonArray().

    FOR EACH tt-proc-item NO-LOCK:

    
    
    

        FIND es-tit-acr-importa-tit EXCLUSIVE-LOCK
        WHERE ROWID(es-tit-acr-importa-tit) = tt-proc-item.r-importa
        NO-ERROR.

        IF AVAILABLE es-tit-acr-importa-tit THEN
            ASSIGN
                es-tit-acr-importa-tit.ind_sit_importacao = (IF tt-proc-item.status-result = "OK" THEN "Importado" ELSE "Erro")
                es-tit-acr-importa-tit.des_mensagem_erro  = tt-proc-item.mensagem
                es-tit-acr-importa-tit.dat_processamento  = TODAY
                es-tit-acr-importa-tit.hra_processamento  = STRING(TIME, "HH:MM:SS").

        IF tt-proc-item.status-result = "OK" THEN
            i-proc = i-proc + 1.
        ELSE
            i-erro = i-erro + 1.

        oDetalhe = NEW JsonObject().
        oDetalhe:Add("cgc",           tt-proc-item.cgc).
        oDetalhe:Add("codEstab",      tt-proc-item.cod_estab).
        oDetalhe:Add("codEspecDocto", tt-proc-item.cod_espec_docto).
        oDetalhe:Add("codSerDocto",   tt-proc-item.cod_ser_docto).
        oDetalhe:Add("codTitAcr",     tt-proc-item.cod_tit_acr).
        oDetalhe:Add("codParcela",    tt-proc-item.cod_parcela).
        oDetalhe:Add("codRefer",      tt-proc-item.cod_refer).
        oDetalhe:Add("status",        tt-proc-item.status-result).
        oDetalhe:Add("mensagem",      tt-proc-item.mensagem ).
        aDetalhes:Add(oDetalhe).

    END. 

    oResp = NEW JsonObject().
    oResp:Add("processados", i-proc).
    oResp:Add("erros",       i-erro).
    oResp:Add("detalhes",    aDetalhes).
    oResp:Write(lc-resposta, TRUE).
    i-status = 200.

    CATCH oE AS Progress.Lang.Error:
        oResp = NEW JsonObject().
        oResp:Add("error", oE:GetMessage(1)).
        oResp:Write(lc-resposta, TRUE).
        i-status = 500.
    END CATCH.

    FINALLY:
        IF VALID-HANDLE(h-acr901zf) THEN DO:
            DELETE PROCEDURE h-acr901zf.
            ASSIGN h-acr901zf = ?.
        END.
        EMPTY TEMP-TABLE tt-proc-item.
    END FINALLY.

END PROCEDURE.

DEFINE TEMP-TABLE tt-exporta NO-UNDO LIKE es-tit-acr-importa-tit.

PROCEDURE pi-importar-lote:
    DEFINE INPUT  PARAM oJsonInput  AS JsonObject NO-UNDO.
    DEFINE OUTPUT PARAM lc-resposta AS LONGCHAR   NO-UNDO.
    DEFINE OUTPUT PARAM i-status    AS INTEGER    NO-UNDO.

    DEFINE VARIABLE aLote      AS JsonArray  NO-UNDO.
    DEFINE VARIABLE aLinha     AS JsonArray  NO-UNDO.
    DEFINE VARIABLE aResult    AS JsonArray  NO-UNDO.
    DEFINE VARIABLE oLinha     AS JsonObject NO-UNDO.
    DEFINE VARIABLE i          AS INTEGER    NO-UNDO.
    DEFINE VARIABLE oResp      AS JsonObject NO-UNDO.
    DEFINE VARIABLE c-cgc      AS CHARACTER  NO-UNDO.
    DEFINE VARIABLE c-titulo   AS CHARACTER  NO-UNDO.
    DEFINE VARIABLE c-estab    AS CHARACTER  NO-UNDO.
    DEFINE VARIABLE c-espec    AS CHARACTER  NO-UNDO.
    DEFINE VARIABLE c-serie    AS CHARACTER  NO-UNDO.
    DEFINE VARIABLE c-parcela  AS CHARACTER  NO-UNDO.
    DEFINE VARIABLE c-empresa  AS CHARACTER  NO-UNDO.
    DEFINE VARIABLE c-valor    AS CHARACTER  NO-UNDO.
    DEFINE VARIABLE de-valor   AS DECIMAL    NO-UNDO.
    DEFINE VARIABLE c-obs      AS CHARACTER  NO-UNDO.
    DEFINE VARIABLE d-saldo-imp AS DECIMAL   NO-UNDO.
    DEFINE BUFFER b-es-tit-imp FOR es-tit-acr-importa-tit.
    DEFINE VARIABLE l-ad-uni        AS LOGICAL   NO-UNDO.
    DEFINE VARIABLE c-titulo-ad-imp AS CHARACTER NO-UNDO.
    DEFINE VARIABLE i-tenta         AS INTEGER   NO-UNDO.
    DEFINE VARIABLE v-cont-ad       AS INTEGER   NO-UNDO.
    DEFINE VARIABLE v-num-ad        AS INTEGER   NO-UNDO.
    DEFINE VARIABLE c-est-ad-imp    AS CHARACTER NO-UNDO.
    DEFINE VARIABLE c-cod-ad-geral  AS CHARACTER NO-UNDO.
    DEFINE VARIABLE oRealBody  AS JsonObject NO-UNDO.
    DEFINE VARIABLE c-erro     AS CHARACTER  NO-UNDO.
    DEFINE VARIABLE c-usuario  AS CHARACTER  NO-UNDO.
    DEFINE VARIABLE l-liq-parcial  AS LOGICAL   NO-UNDO INITIAL NO.
    DEFINE VARIABLE c-flag-parcial AS CHARACTER NO-UNDO.
    DEFINE VARIABLE c-lote-info    AS CHARACTER NO-UNDO.
    DEFINE VARIABLE cRaizCnpj AS CHARACTER NO-UNDO.
    DEFINE VARIABLE cEstab    AS CHARACTER NO-UNDO.
    DEFINE VARIABLE c-arq-debug-tt AS CHARACTER NO-UNDO.
    DEFINE VARIABLE i-cont-tt      AS INTEGER   NO-UNDO.
    DEFINE VARIABLE de-juros      AS DECIMAL   NO-UNDO.
    DEFINE VARIABLE de-multa      AS DECIMAL   NO-UNDO.
    DEFINE VARIABLE de-desconto   AS DECIMAL   NO-UNDO.
    DEFINE VARIABLE de-abatimento AS DECIMAL   NO-UNDO.
    DEFINE VARIABLE c-data-ger    AS CHARACTER NO-UNDO.
    DEFINE VARIABLE c-aux-val     AS CHARACTER NO-UNDO.
    DEFINE VARIABLE c-cod-ad-x    AS CHARACTER NO-UNDO.
    DEFINE VARIABLE d-dat-ger     AS DATE      NO-UNDO.
    DEFINE VARIABLE c-portador    AS CHARACTER NO-UNDO.
    DEFINE VARIABLE c-carteira    AS CHARACTER NO-UNDO.

    
    
    IF oJsonInput:Has("payload") THEN
        oRealBody = oJsonInput:GetJsonObject("payload") NO-ERROR.
    ELSE IF oJsonInput:Has("requestBody") THEN
        oRealBody = oJsonInput:GetJsonObject("requestBody") NO-ERROR.
    ELSE IF oJsonInput:Has("body") THEN
        oRealBody = oJsonInput:GetJsonObject("body") NO-ERROR.
    ELSE
        oRealBody = oJsonInput.

    
    IF oRealBody:Has("codUsuario") THEN
        c-usuario = oRealBody:GetCharacter("codUsuario") NO-ERROR.
    IF c-usuario = "" OR c-usuario = ? THEN
        c-usuario = USERID("DICT") NO-ERROR.
    IF c-usuario = "" OR c-usuario = ? THEN
        c-usuario = USERID(LDBNAME(1)) NO-ERROR.

    
    IF oRealBody:Has("liquidaParcial") THEN
        l-liq-parcial = oRealBody:GetLogical("liquidaParcial") NO-ERROR.
    IF l-liq-parcial = ? THEN l-liq-parcial = NO.
    c-flag-parcial = IF l-liq-parcial THEN "YES" ELSE "NO".
    
    c-lote-info = "".
    IF oRealBody:Has("numLote") THEN
        c-lote-info = oRealBody:GetCharacter("numLote") NO-ERROR.
    IF c-lote-info = ? THEN c-lote-info = "".
    IF c-lote-info <> "" THEN c-lote-info = "Lote:" + c-lote-info.

    aLote   = oRealBody:GetJsonArray("lote").
    aResult = NEW JsonArray().

    
    EMPTY TEMP-TABLE tt-cnpj-lote.
    EMPTY TEMP-TABLE tt-valor-lote.
    DO i = 1 TO aLote:Length:
        aLinha = aLote:GetJsonArray(i).
        c-cgc = aLinha:GetCharacter(3) NO-ERROR.
        IF c-cgc = ? THEN c-cgc = "".
        c-cgc = REPLACE(REPLACE(REPLACE(c-cgc, ".", ""), "-", ""), "/", "").

        IF c-cgc = "" THEN DO:
            
            c-valor = aLinha:GetCharacter(11) NO-ERROR.
            IF c-valor = ? OR c-valor = "" THEN c-valor = "0".
            IF INDEX(c-valor, "(") > 0 THEN NEXT.
            c-valor = TRIM(REPLACE(REPLACE(c-valor, "R$", ""), " ", "")).
            de-valor = DECIMAL(c-valor) NO-ERROR.
            IF de-valor = ? OR de-valor = 0 THEN NEXT.
            IF NOT CAN-FIND(FIRST tt-valor-lote WHERE tt-valor-lote.val = de-valor) THEN DO:
                CREATE tt-valor-lote.
                ASSIGN tt-valor-lote.val = de-valor.
            END.
            NEXT.
        END.

        IF NOT CAN-FIND(FIRST tt-cnpj-lote WHERE tt-cnpj-lote.cgc = c-cgc) THEN DO:
            CREATE tt-cnpj-lote.
            ASSIGN tt-cnpj-lote.cgc  = c-cgc
                   tt-cnpj-lote.cgc8 = SUBSTRING(c-cgc, 1, 8).
        END.
    END.

    
    EMPTY TEMP-TABLE tt-es-tit-acr-abrt.

    FOR EACH estabelec FIELDS(cod-estabel) NO-LOCK:
        IF LENGTH(estabelec.cod-estabel) < 3 THEN
            cEstab = FILL("0", 3 - LENGTH(estabelec.cod-estabel)) + estabelec.cod-estabel.
        ELSE
            cEstab = estabelec.cod-estabel.

        FOR EACH tit_acr
            FIELDS(cod_espec_docto log_sdo_tit_acr val_sdo_tit_acr cod_portador
                   cdn_cliente cod_estab cod_ser_docto cod_tit_acr cod_parcela)
            WHERE tit_acr.cod_estab       = cEstab
              AND tit_acr.cod_espec_docto <> "AD"
              AND tit_acr.log_sdo_tit_acr = YES
              AND tit_acr.val_sdo_tit_acr > 0 NO-LOCK:

            IF tit_acr.cod_portador = '9997' THEN NEXT.

            FIND emitente WHERE emitente.cod-emitente = tit_acr.cdn_cliente NO-LOCK NO-ERROR.
            IF NOT AVAIL emitente THEN NEXT.

            
            IF NOT CAN-FIND(FIRST tt-cnpj-lote WHERE tt-cnpj-lote.cgc = emitente.cgc)
               AND NOT CAN-FIND(FIRST tt-cnpj-lote WHERE tt-cnpj-lote.cgc8 = SUBSTRING(emitente.cgc, 1, 8))
               AND NOT CAN-FIND(FIRST tt-valor-lote WHERE tt-valor-lote.val = tit_acr.val_sdo_tit_acr) THEN NEXT.

            
            IF CAN-FIND(FIRST es-tit-acr-importa-tit
                    WHERE es-tit-acr-importa-tit.cod_estab       = tit_acr.cod_estab
                      AND es-tit-acr-importa-tit.cod_espec_docto = tit_acr.cod_espec_docto
                      AND es-tit-acr-importa-tit.cod_ser_docto   = tit_acr.cod_ser_docto
                      AND es-tit-acr-importa-tit.cod_tit_acr     = tit_acr.cod_tit_acr
                      AND es-tit-acr-importa-tit.cod_parcela     = tit_acr.cod_parcela) THEN NEXT.

            CREATE tt-es-tit-acr-abrt.
            ASSIGN
                tt-es-tit-acr-abrt.cgc             = emitente.cgc
                tt-es-tit-acr-abrt.cgc-8char       = SUBSTRING(emitente.cgc, 1, 8)
                tt-es-tit-acr-abrt.cod_estab       = tit_acr.cod_estab
                tt-es-tit-acr-abrt.cod_espec_docto = tit_acr.cod_espec_docto
                tt-es-tit-acr-abrt.cod_ser_docto   = tit_acr.cod_ser_docto
                tt-es-tit-acr-abrt.cod_tit_acr     = tit_acr.cod_tit_acr
                tt-es-tit-acr-abrt.cod_parcela     = tit_acr.cod_parcela
                tt-es-tit-acr-abrt.val_pendente    = tit_acr.val_sdo_tit_acr
                tt-es-tit-acr-abrt.atualizado      = NO.
        END.
    END.

    
    ASSIGN c-arq-debug-tt = SESSION:TEMP-DIRECTORY + "/tt-es-tit-acr-abrt-debug.csv"
           i-cont-tt      = 0.
    OUTPUT TO VALUE(c-arq-debug-tt).
    PUT UNFORMATTED "cgc;cgc-8char;cod_estab;cod_espec_docto;cod_ser_docto;cod_tit_acr;cod_parcela;val_pendente" SKIP.
    FOR EACH tt-es-tit-acr-abrt NO-LOCK:
        PUT UNFORMATTED
            tt-es-tit-acr-abrt.cgc             ";"
            tt-es-tit-acr-abrt.cgc-8char       ";"
            tt-es-tit-acr-abrt.cod_estab       ";"
            tt-es-tit-acr-abrt.cod_espec_docto ";"
            tt-es-tit-acr-abrt.cod_ser_docto   ";"
            tt-es-tit-acr-abrt.cod_tit_acr     ";"
            tt-es-tit-acr-abrt.cod_parcela     ";"
            tt-es-tit-acr-abrt.val_pendente    SKIP.
        i-cont-tt = i-cont-tt + 1.
    END.
    OUTPUT CLOSE.

    DO i = 1 TO aLote:Length:
        aLinha = aLote:GetJsonArray(i).

        
        c-data-ger = aLinha:GetCharacter(2) NO-ERROR.
        IF c-data-ger = ? THEN c-data-ger = "".
        c-data-ger = REPLACE(c-data-ger, ".", "/").
        
        d-dat-ger = ?.
        IF NUM-ENTRIES(c-data-ger, "/") = 3 THEN
            d-dat-ger = DATE(INTEGER(ENTRY(2, c-data-ger, "/")),
                             INTEGER(ENTRY(1, c-data-ger, "/")),
                             (IF INTEGER(ENTRY(3, c-data-ger, "/")) < 100
                                  THEN 2000 + INTEGER(ENTRY(3, c-data-ger, "/"))
                                  ELSE INTEGER(ENTRY(3, c-data-ger, "/")))) NO-ERROR.
        
        c-obs = aLinha:GetCharacter(18) NO-ERROR.
        IF c-obs = ? THEN c-obs = "".
        c-obs = REPLACE(c-obs, "|", " ").

        
        c-cgc = aLinha:GetCharacter(3) NO-ERROR.
        IF c-cgc <> ? THEN DO:
            c-cgc = REPLACE(c-cgc, ".", "").
            c-cgc = REPLACE(c-cgc, "-", "").
            c-cgc = REPLACE(c-cgc, "/", "").
        END.
        IF c-cgc = ? THEN c-cgc = "".

        
        c-titulo  = aLinha:GetCharacter(7)  NO-ERROR.
        c-estab   = aLinha:GetCharacter(4)  NO-ERROR.
        c-espec   = aLinha:GetCharacter(5)  NO-ERROR.
        c-serie   = aLinha:GetCharacter(6)  NO-ERROR.
        c-parcela = aLinha:GetCharacter(8)  NO-ERROR.
        c-empresa = aLinha:GetCharacter(1)  NO-ERROR.
        IF c-titulo  = ? THEN c-titulo  = "".
        IF c-estab   = ? THEN c-estab   = "".
        IF c-espec   = ? THEN c-espec   = "".
        IF c-serie   = ? THEN c-serie   = "".
        IF c-parcela = ? THEN c-parcela = "".
        IF c-empresa = ? THEN c-empresa = "".

        
        c-valor = aLinha:GetCharacter(11) NO-ERROR.
        IF c-valor = ? OR c-valor = "" THEN c-valor = "0".
        IF INDEX(c-valor, "(") > 0 THEN NEXT.   
        c-valor = TRIM(REPLACE(REPLACE(c-valor, "R$", ""), " ", "")).
        de-valor = DECIMAL(c-valor) NO-ERROR.
        IF de-valor = ? THEN de-valor = 0.

        
        c-aux-val = aLinha:GetCharacter(12) NO-ERROR.
        IF c-aux-val = ? OR c-aux-val = "" THEN c-aux-val = "0".
        de-juros = DECIMAL(TRIM(REPLACE(REPLACE(c-aux-val, "R$", ""), " ", ""))) NO-ERROR.
        IF de-juros = ? THEN de-juros = 0.
        c-aux-val = aLinha:GetCharacter(13) NO-ERROR.
        IF c-aux-val = ? OR c-aux-val = "" THEN c-aux-val = "0".
        de-multa = DECIMAL(TRIM(REPLACE(REPLACE(c-aux-val, "R$", ""), " ", ""))) NO-ERROR.
        IF de-multa = ? THEN de-multa = 0.
        c-aux-val = aLinha:GetCharacter(14) NO-ERROR.
        IF c-aux-val = ? OR c-aux-val = "" THEN c-aux-val = "0".
        de-desconto = DECIMAL(TRIM(REPLACE(REPLACE(c-aux-val, "R$", ""), " ", ""))) NO-ERROR.
        IF de-desconto = ? THEN de-desconto = 0.
        c-aux-val = aLinha:GetCharacter(15) NO-ERROR.
        IF c-aux-val = ? OR c-aux-val = "" THEN c-aux-val = "0".
        de-abatimento = DECIMAL(TRIM(REPLACE(REPLACE(c-aux-val, "R$", ""), " ", ""))) NO-ERROR.
        IF de-abatimento = ? THEN de-abatimento = 0.

        
        c-portador = aLinha:GetCharacter(9)  NO-ERROR.
        c-carteira = aLinha:GetCharacter(10) NO-ERROR.
        IF c-portador = ? THEN c-portador = "".
        IF c-carteira = ? THEN c-carteira = "".
        ASSIGN c-portador = TRIM(c-portador) c-carteira = TRIM(c-carteira).

        
        IF c-portador <> "" AND NOT CAN-FIND(FIRST emscad.portador WHERE emscad.portador.cod_portador = c-portador) THEN DO:
            oLinha = NEW JsonObject().
            oLinha:Add("cgc",        c-cgc).
            oLinha:Add("estab",      c-estab).
            oLinha:Add("especie",    c-espec).
            oLinha:Add("serie",      c-serie).
            oLinha:Add("titulo",     c-titulo).
            oLinha:Add("parcela",    c-parcela).
            oLinha:Add("valor",      de-valor).
            oLinha:Add("observacao", c-obs).
            oLinha:Add("situacao",   "Erro").
            oLinha:Add("mensagem",   "Portador " + c-portador + " nao existe no cadastro.").
            aResult:Add(oLinha).
            NEXT.
        END.

        
        IF c-portador <> "" AND c-obs <> ""
           AND CAN-FIND(FIRST es-import-excecao
                        WHERE es-import-excecao.cod-portador       = c-portador
                          AND es-import-excecao.nome-desconsiderar <> ""
                          AND INDEX(c-obs, es-import-excecao.nome-desconsiderar) > 0) THEN DO:
            oLinha = NEW JsonObject().
            oLinha:Add("cgc",        c-cgc).
            oLinha:Add("estab",      c-estab).
            oLinha:Add("especie",    c-espec).
            oLinha:Add("serie",      c-serie).
            oLinha:Add("titulo",     c-titulo).
            oLinha:Add("parcela",    c-parcela).
            oLinha:Add("valor",      de-valor).
            oLinha:Add("observacao", c-obs).
            oLinha:Add("situacao",   "Ignorado").
            oLinha:Add("mensagem",   "Cadastro de excecao - lancamento desconsiderado.").
            aResult:Add(oLinha).
            NEXT.
        END.
        IF de-valor = 0 AND de-juros = 0 AND de-multa = 0 AND c-titulo = "" THEN NEXT.

        
        IF de-valor < 0 THEN DO:
            oLinha = NEW JsonObject().
            oLinha:Add("cgc",        c-cgc).
            oLinha:Add("estab",      c-estab).
            oLinha:Add("especie",    c-espec).
            oLinha:Add("serie",      c-serie).
            oLinha:Add("titulo",     c-titulo).
            oLinha:Add("parcela",    c-parcela).
            oLinha:Add("valor",      de-valor).
            oLinha:Add("observacao", c-obs).
            oLinha:Add("situacao",   "Erro").
            oLinha:Add("mensagem",   "Valor negativo (debito) - linha nao importada.").
            aResult:Add(oLinha).
            NEXT.
        END.

        
        IF c-cgc = "" THEN DO:
            FIND FIRST tt-es-tit-acr-abrt
                WHERE tt-es-tit-acr-abrt.val_pendente = de-valor NO-ERROR.

            IF NOT AVAILABLE tt-es-tit-acr-abrt THEN DO:
                oLinha = NEW JsonObject().
                oLinha:Add("cgc",      "").
                oLinha:Add("estab",    "").
                oLinha:Add("especie",  "").
                oLinha:Add("serie",    "").
                oLinha:Add("titulo",   "").
                oLinha:Add("parcela",  "").
                oLinha:Add("valor",    de-valor).
                oLinha:Add("observacao", c-obs).
                oLinha:Add("situacao", "Erro").
                oLinha:Add("mensagem", "Linha sem CNPJ e nenhum titulo com o valor informado.").
                aResult:Add(oLinha).
                NEXT.
            END.

            CREATE es-tit-acr-importa-tit.
            ASSIGN
                es-tit-acr-importa-tit.cgc                 = tt-es-tit-acr-abrt.cgc
                es-tit-acr-importa-tit.cod_estab           = tt-es-tit-acr-abrt.cod_estab
                es-tit-acr-importa-tit.cod_espec_docto     = tt-es-tit-acr-abrt.cod_espec_docto
                es-tit-acr-importa-tit.cod_ser_docto       = tt-es-tit-acr-abrt.cod_ser_docto
                es-tit-acr-importa-tit.cod_tit_acr         = tt-es-tit-acr-abrt.cod_tit_acr
                es-tit-acr-importa-tit.cod_parcela         = tt-es-tit-acr-abrt.cod_parcela
                es-tit-acr-importa-tit.cod_empresa         = ""
                es-tit-acr-importa-tit.val_recebido        = tt-es-tit-acr-abrt.val_pendente
                es-tit-acr-importa-tit.val_juros           = 0
                es-tit-acr-importa-tit.val_multa           = 0
                es-tit-acr-importa-tit.val_desconto        = 0
                es-tit-acr-importa-tit.val_abatimento      = 0
                es-tit-acr-importa-tit.ind_sit_importacao  = "Pendente"
                es-tit-acr-importa-tit.dat_importacao      = TODAY
                es-tit-acr-importa-tit.hra_importacao      = STRING(TIME, "HH:MM:SS")
                es-tit-acr-importa-tit.cod_arq_origem      = "upload-web|" + c-obs + "|" + c-flag-parcial + "|" + c-lote-info
                es-tit-acr-importa-tit.cod_usuario_import  = c-usuario
                es-tit-acr-importa-tit.num_lote_importacao = 0 NO-ERROR.
            VALIDATE es-tit-acr-importa-tit NO-ERROR.

            oLinha = NEW JsonObject().
            oLinha:Add("cgc",      tt-es-tit-acr-abrt.cgc).
            oLinha:Add("estab",    tt-es-tit-acr-abrt.cod_estab).
            oLinha:Add("especie",  tt-es-tit-acr-abrt.cod_espec_docto).
            oLinha:Add("serie",    tt-es-tit-acr-abrt.cod_ser_docto).
            oLinha:Add("titulo",   tt-es-tit-acr-abrt.cod_tit_acr).
            oLinha:Add("parcela",  tt-es-tit-acr-abrt.cod_parcela).
            oLinha:Add("valor",    tt-es-tit-acr-abrt.val_pendente).
            oLinha:Add("situacao", "Importado").
            oLinha:Add("mensagem", "Vinculado por valor (linha sem CNPJ)").
            aResult:Add(oLinha).

            DELETE tt-es-tit-acr-abrt.  
            RELEASE es-tit-acr-importa-tit NO-ERROR.
            NEXT.
        END.

        
        FIND FIRST emitente NO-LOCK
             WHERE emitente.cgc = c-cgc NO-ERROR.

        IF NOT AVAILABLE emitente THEN
            FIND FIRST emitente NO-LOCK
                 WHERE emitente.cgc BEGINS SUBSTRING(c-cgc, 1, 8) NO-ERROR.

        IF NOT AVAILABLE emitente THEN DO:
            oLinha = NEW JsonObject().
            oLinha:Add("cgc",      c-cgc).
            oLinha:Add("estab",    "").
            oLinha:Add("especie",  "").
            oLinha:Add("serie",    "").
            oLinha:Add("titulo",   "").
            oLinha:Add("parcela",  "").
            oLinha:Add("valor",      de-valor).
            oLinha:Add("observacao", c-obs).
            oLinha:Add("situacao", "Erro").
            oLinha:Add("mensagem", "Emitente nao encontrado").
            aResult:Add(oLinha).
            NEXT.
        END.

        

        
        IF c-titulo <> "" THEN DO:
            FIND FIRST tit_acr NO-LOCK
                WHERE tit_acr.cod_estab       = c-estab
                  AND tit_acr.cod_espec_docto = c-espec
                  AND tit_acr.cod_ser_docto   = c-serie
                  AND tit_acr.cod_tit_acr     = c-titulo
                  AND tit_acr.cod_parcela     = c-parcela NO-ERROR.
            IF NOT AVAILABLE tit_acr THEN DO:
                oLinha = NEW JsonObject().
                oLinha:Add("cgc",        c-cgc).
                oLinha:Add("estab",      c-estab).
                oLinha:Add("especie",    c-espec).
                oLinha:Add("serie",      c-serie).
                oLinha:Add("titulo",     c-titulo).
                oLinha:Add("parcela",    c-parcela).
                oLinha:Add("valor",      de-valor).
                oLinha:Add("observacao", c-obs).
                oLinha:Add("situacao",   "Erro").
                oLinha:Add("mensagem",   "Titulo apontado nao encontrado no contas a receber.").
                aResult:Add(oLinha).
                NEXT.
            END.
            IF NOT tit_acr.log_sdo_tit_acr OR tit_acr.val_sdo_tit_acr <= 0 THEN DO:
                oLinha = NEW JsonObject().
                oLinha:Add("cgc",        c-cgc).
                oLinha:Add("estab",      c-estab).
                oLinha:Add("especie",    c-espec).
                oLinha:Add("serie",      c-serie).
                oLinha:Add("titulo",     c-titulo).
                oLinha:Add("parcela",    c-parcela).
                oLinha:Add("valor",      de-valor).
                oLinha:Add("observacao", c-obs).
                oLinha:Add("situacao",   "Erro").
                oLinha:Add("mensagem",   "Titulo apontado sem saldo em aberto (ja liquidado). Saldo: "
                                       + TRIM(STRING(tit_acr.val_sdo_tit_acr, ">>>,>>>,>>9.99")) + ".").
                aResult:Add(oLinha).
                NEXT.
            END.

            
            IF de-valor = 0 AND de-juros = 0 AND de-multa = 0 THEN
                ASSIGN de-valor = tit_acr.val_sdo_tit_acr
                       de-juros = tit_acr.val_juros
                       de-multa = tit_acr.val_multa_tit_acr.

            
            IF c-lote-info = ""
               AND (de-valor + de-juros + de-multa) >
                   (tit_acr.val_sdo_tit_acr + tit_acr.val_juros + tit_acr.val_multa_tit_acr) THEN DO:
                RUN pi-criar-ad-excedente (INPUT c-cgc, INPUT c-estab,
                    INPUT (de-valor + de-juros + de-multa)
                          - (tit_acr.val_sdo_tit_acr + tit_acr.val_juros + tit_acr.val_multa_tit_acr),
                    INPUT "upload-web|" + c-obs + "|" + c-flag-parcial + "|" + c-lote-info,
                    INPUT c-usuario, OUTPUT c-cod-ad-x).
                ASSIGN de-valor = tit_acr.val_sdo_tit_acr
                       de-juros = tit_acr.val_juros
                       de-multa = tit_acr.val_multa_tit_acr.
            END.
        END.

        
        FIND FIRST es-tit-acr-importa-tit EXCLUSIVE-LOCK
             WHERE es-tit-acr-importa-tit.cgc             = c-cgc
               AND es-tit-acr-importa-tit.cod_estab       = c-estab
               AND es-tit-acr-importa-tit.cod_espec_docto = c-espec
               AND es-tit-acr-importa-tit.cod_ser_docto   = c-serie
               AND es-tit-acr-importa-tit.cod_tit_acr     = c-titulo
               AND es-tit-acr-importa-tit.cod_parcela     = c-parcela
               AND es-tit-acr-importa-tit.val_recebido    = de-valor 
             NO-ERROR.

        IF AVAILABLE es-tit-acr-importa-tit THEN DO:
            oLinha = NEW JsonObject().
            oLinha:Add("cgc",      c-cgc).
            oLinha:Add("estab",    c-estab).
            oLinha:Add("especie",  c-espec).
            oLinha:Add("serie",    c-serie).
            oLinha:Add("titulo",   c-titulo).
            oLinha:Add("parcela",  c-parcela).
            oLinha:Add("valor",  de-valor).
            
            
            oLinha:Add("situacao", "Importado").
            oLinha:Add("mensagem", "Registro ja existente").
            aResult:Add(oLinha).
            RELEASE es-tit-acr-importa-tit NO-ERROR.
        END.
        ELSE DO:
            
            c-erro = "".
            CREATE es-tit-acr-importa-tit.
            ASSIGN
                es-tit-acr-importa-tit.cgc                = c-cgc
                es-tit-acr-importa-tit.cod_estab          = c-estab
                es-tit-acr-importa-tit.cod_espec_docto    = c-espec
                es-tit-acr-importa-tit.cod_ser_docto      = c-serie
                es-tit-acr-importa-tit.cod_tit_acr        = c-titulo
                es-tit-acr-importa-tit.cod_parcela        = c-parcela
                es-tit-acr-importa-tit.cod_empresa        = c-empresa
                es-tit-acr-importa-tit.val_recebido       = de-valor
                es-tit-acr-importa-tit.val_juros          = de-juros
                es-tit-acr-importa-tit.val_multa          = de-multa
                es-tit-acr-importa-tit.val_desconto       = de-desconto
                es-tit-acr-importa-tit.val_abatimento     = de-abatimento
                es-tit-acr-importa-tit.dat_geracao        = d-dat-ger
                es-tit-acr-importa-tit.cod_portador       = c-portador
                es-tit-acr-importa-tit.cod_cart_bcia      = c-carteira
                es-tit-acr-importa-tit.ind_sit_importacao = "Pendente"
                es-tit-acr-importa-tit.dat_importacao     = TODAY
                es-tit-acr-importa-tit.hra_importacao     = STRING(TIME, "HH:MM:SS")
                es-tit-acr-importa-tit.cod_arq_origem     = "upload-web|" + c-obs + "|" + c-flag-parcial + "|" + c-lote-info
                es-tit-acr-importa-tit.cod_usuario_import = c-usuario
                es-tit-acr-importa-tit.num_lote_importacao = 0
                NO-ERROR.
            
            cRaizCnpj = ''.
            ASSIGN cRaizCnpj    = SUBSTRING(es-tit-acr-importa-tit.cgc, 1, 8).
            
            
            IF FALSE  THEN
            DO:
                IF CAN-FIND(FIRST es_tit_acr_abrt WHERE
                   es_tit_acr_abrt.cod_estab       = es-tit-acr-importa-tit.cod_estab         AND
                   es_tit_acr_abrt.cod_espec_docto = es-tit-acr-importa-tit.cod_espec_docto   AND
                   es_tit_acr_abrt.cod_ser_docto   = es-tit-acr-importa-tit.cod_ser_docto     AND
                   es_tit_acr_abrt.cod_tit_acr     = es-tit-acr-importa-tit.cod_tit_acr       AND
                   es_tit_acr_abrt.cod_parcela     = es-tit-acr-importa-tit.cod_parcela       AND
                   es_tit_acr_abrt.val_pendente    = es-tit-acr-importa-tit.val_recebido) THEN
                FIND FIRST es_tit_acr_abrt WHERE
                           es_tit_acr_abrt.cod_estab       = es-tit-acr-importa-tit.cod_estab         AND
                           es_tit_acr_abrt.cod_espec_docto = es-tit-acr-importa-tit.cod_espec_docto   AND
                           es_tit_acr_abrt.cod_ser_docto   = es-tit-acr-importa-tit.cod_ser_docto     AND
                           es_tit_acr_abrt.cod_tit_acr     = es-tit-acr-importa-tit.cod_tit_acr       AND
                           es_tit_acr_abrt.cod_parcela     = es-tit-acr-importa-tit.cod_parcela       AND
                           es_tit_acr_abrt.val_pendente    = es-tit-acr-importa-tit.val_recebido
                           EXCLUSIVE-LOCK
                           NO-ERROR.

                
                IF NOT AVAIL es_tit_acr_abrt THEN
                DO:
                    IF CAN-FIND(FIRST es_tit_acr_abrt WHERE 
                    es_tit_acr_abrt.cgc          = es-tit-acr-importa-tit.cgc           AND
                    es_tit_acr_abrt.val_pendente = es-tit-acr-importa-tit.val_recebido) THEN
     
                    FIND FIRST es_tit_acr_abrt WHERE
                           es_tit_acr_abrt.cgc             = es-tit-acr-importa-tit.cgc           AND
                           es_tit_acr_abrt.val_pendente    = es-tit-acr-importa-tit.val_recebido EXCLUSIVE-LOCK
                           NO-ERROR.
                END.

                
                IF NOT AVAIL es_tit_acr_abrt THEN
                DO:
                   IF CAN-FIND(FIRST es_tit_acr_abrt WHERE 
                   es_tit_acr_abrt.cgc-8char    = cRaizCnpj                            AND
                   es_tit_acr_abrt.val_pendente = es-tit-acr-importa-tit.val_recebido) THEN
                    FIND FIRST es_tit_acr_abrt WHERE
                              es_tit_acr_abrt.cgc-8char    = cRaizCnpj                        AND
                              es_tit_acr_abrt.val_pendente = es-tit-acr-importa-tit.val_recebido
                              EXCLUSIVE-LOCK
                              NO-ERROR.

                END.

                IF AVAIL es_tit_acr_abrt THEN
                DO:
                    ASSIGN
                    es-tit-acr-importa-tit.cod_estab       = es_tit_acr_abrt.cod_estab
                    es-tit-acr-importa-tit.cod_espec_docto = es_tit_acr_abrt.cod_espec_docto
                    es-tit-acr-importa-tit.cod_ser_docto   = es_tit_acr_abrt.cod_ser_docto
                    es-tit-acr-importa-tit.cod_tit_acr     = es_tit_acr_abrt.cod_tit_acr
                    es-tit-acr-importa-tit.cod_parcela     = es_tit_acr_abrt.cod_parcela
                    
                    
                    c-cgc         = es_tit_acr_abrt.cgc
                    c-estab       = es_tit_acr_abrt.cod_estab
                    c-espec       = es_tit_acr_abrt.cod_espec_docto
                    c-serie       = es_tit_acr_abrt.cod_ser_docto
                    c-titulo      = es_tit_acr_abrt.cod_tit_acr
                    c-parcela     = es_tit_acr_abrt.cod_parcela.
                    
                    
                    

                    .

                END.
            END.
            
            
            
            IF NOT ERROR-STATUS:ERROR AND es-tit-acr-importa-tit.cod_tit_acr = '' THEN DO:
                d-saldo-imp = es-tit-acr-importa-tit.val_recebido.

                LACO-IMP:
                REPEAT:
                    
                    
                    FIND FIRST tt-es-tit-acr-abrt
                        WHERE tt-es-tit-acr-abrt.cod_tit_acr = "###NENHUM###" NO-ERROR.

                    
                    IF c-titulo <> "" THEN
                        FIND FIRST tt-es-tit-acr-abrt
                            WHERE tt-es-tit-acr-abrt.cod_estab       = c-estab
                              AND tt-es-tit-acr-abrt.cod_espec_docto = c-espec
                              AND tt-es-tit-acr-abrt.cod_ser_docto   = c-serie
                              AND tt-es-tit-acr-abrt.cod_tit_acr     = c-titulo
                              AND tt-es-tit-acr-abrt.cod_parcela     = c-parcela
                              AND tt-es-tit-acr-abrt.val_pendente    = d-saldo-imp NO-ERROR.

                    
                    IF NOT AVAILABLE tt-es-tit-acr-abrt THEN
                        FIND FIRST tt-es-tit-acr-abrt
                            WHERE tt-es-tit-acr-abrt.cgc          = es-tit-acr-importa-tit.cgc
                              AND tt-es-tit-acr-abrt.val_pendente = d-saldo-imp NO-ERROR.

                    
                    IF NOT AVAILABLE tt-es-tit-acr-abrt THEN
                        FIND FIRST tt-es-tit-acr-abrt
                            WHERE tt-es-tit-acr-abrt.cgc-8char    = cRaizCnpj
                              AND tt-es-tit-acr-abrt.val_pendente = d-saldo-imp NO-ERROR.

                    
                    IF NOT AVAILABLE tt-es-tit-acr-abrt THEN
                        FIND LAST tt-es-tit-acr-abrt USE-INDEX idx-cgc
                            WHERE tt-es-tit-acr-abrt.cgc          = es-tit-acr-importa-tit.cgc
                              AND tt-es-tit-acr-abrt.val_pendente > 0
                              AND tt-es-tit-acr-abrt.val_pendente <= d-saldo-imp NO-ERROR.

                    
                    IF NOT AVAILABLE tt-es-tit-acr-abrt THEN LEAVE LACO-IMP.

                    IF NOT CAN-FIND(FIRST b-es-tit-imp
                                    WHERE b-es-tit-imp.cgc             = es-tit-acr-importa-tit.cgc
                                      AND b-es-tit-imp.cod_estab       = tt-es-tit-acr-abrt.cod_estab
                                      AND b-es-tit-imp.cod_espec_docto = tt-es-tit-acr-abrt.cod_espec_docto
                                      AND b-es-tit-imp.cod_ser_docto   = tt-es-tit-acr-abrt.cod_ser_docto
                                      AND b-es-tit-imp.cod_tit_acr     = tt-es-tit-acr-abrt.cod_tit_acr
                                      AND b-es-tit-imp.cod_parcela     = tt-es-tit-acr-abrt.cod_parcela
                                      AND b-es-tit-imp.val_recebido    = tt-es-tit-acr-abrt.val_pendente) THEN DO:
                        CREATE b-es-tit-imp.
                        ASSIGN b-es-tit-imp.cgc                 = es-tit-acr-importa-tit.cgc
                               b-es-tit-imp.cod_empresa         = es-tit-acr-importa-tit.cod_empresa
                               b-es-tit-imp.cod_estab           = tt-es-tit-acr-abrt.cod_estab
                               b-es-tit-imp.cod_espec_docto     = tt-es-tit-acr-abrt.cod_espec_docto
                               b-es-tit-imp.cod_ser_docto       = tt-es-tit-acr-abrt.cod_ser_docto
                               b-es-tit-imp.cod_tit_acr         = tt-es-tit-acr-abrt.cod_tit_acr
                               b-es-tit-imp.cod_parcela         = tt-es-tit-acr-abrt.cod_parcela
                               b-es-tit-imp.val_recebido        = tt-es-tit-acr-abrt.val_pendente
                               b-es-tit-imp.val_juros           = 0
                               b-es-tit-imp.val_multa           = 0
                               b-es-tit-imp.val_desconto        = 0
                               b-es-tit-imp.val_abatimento      = 0
                               b-es-tit-imp.ind_sit_importacao  = "Pendente"
                               b-es-tit-imp.dat_importacao      = es-tit-acr-importa-tit.dat_importacao
                               b-es-tit-imp.hra_importacao      = es-tit-acr-importa-tit.hra_importacao
                               b-es-tit-imp.cod_arq_origem      = es-tit-acr-importa-tit.cod_arq_origem
                               b-es-tit-imp.cod_usuario_import  = es-tit-acr-importa-tit.cod_usuario_import
                               b-es-tit-imp.num_lote_importacao = 0
                               b-es-tit-imp.dat_geracao         = es-tit-acr-importa-tit.dat_geracao NO-ERROR.
                        VALIDATE b-es-tit-imp NO-ERROR.
                        RELEASE b-es-tit-imp NO-ERROR.
                    END.

                    oLinha = NEW JsonObject().
                    oLinha:Add("cgc",      tt-es-tit-acr-abrt.cgc).
                    oLinha:Add("estab",    tt-es-tit-acr-abrt.cod_estab).
                    oLinha:Add("especie",  tt-es-tit-acr-abrt.cod_espec_docto).
                    oLinha:Add("serie",    tt-es-tit-acr-abrt.cod_ser_docto).
                    oLinha:Add("titulo",   tt-es-tit-acr-abrt.cod_tit_acr).
                    oLinha:Add("parcela",  tt-es-tit-acr-abrt.cod_parcela).
                    oLinha:Add("valor",    tt-es-tit-acr-abrt.val_pendente).
                    oLinha:Add("situacao", "Importado").
                    oLinha:Add("mensagem", "Vinculado ao titulo (regra <=)").
                    aResult:Add(oLinha).

                    ASSIGN d-saldo-imp = d-saldo-imp - tt-es-tit-acr-abrt.val_pendente.
                    DELETE tt-es-tit-acr-abrt.
                    IF d-saldo-imp <= 0 THEN LEAVE LACO-IMP.
                END. 

                IF d-saldo-imp <= 0 THEN
                    DELETE es-tit-acr-importa-tit NO-ERROR.
                ELSE DO:
                    
                    IF l-liq-parcial THEN DO:
                        FIND FIRST tt-es-tit-acr-abrt USE-INDEX idx-cgc
                            WHERE tt-es-tit-acr-abrt.cgc          = es-tit-acr-importa-tit.cgc
                              AND tt-es-tit-acr-abrt.val_pendente > d-saldo-imp NO-ERROR.
                        IF NOT AVAILABLE tt-es-tit-acr-abrt THEN
                            FIND FIRST tt-es-tit-acr-abrt
                                WHERE tt-es-tit-acr-abrt.cgc-8char    = cRaizCnpj
                                  AND tt-es-tit-acr-abrt.val_pendente > d-saldo-imp NO-ERROR.

                        IF AVAILABLE tt-es-tit-acr-abrt THEN DO:
                            
                            FIND FIRST b-es-tit-imp EXCLUSIVE-LOCK
                                WHERE b-es-tit-imp.cgc             = tt-es-tit-acr-abrt.cgc
                                  AND b-es-tit-imp.cod_estab       = tt-es-tit-acr-abrt.cod_estab
                                  AND b-es-tit-imp.cod_espec_docto = tt-es-tit-acr-abrt.cod_espec_docto
                                  AND b-es-tit-imp.cod_ser_docto   = tt-es-tit-acr-abrt.cod_ser_docto
                                  AND b-es-tit-imp.cod_tit_acr     = tt-es-tit-acr-abrt.cod_tit_acr
                                  AND b-es-tit-imp.cod_parcela     = tt-es-tit-acr-abrt.cod_parcela
                                  AND b-es-tit-imp.ind_sit_importacao = "Pendente"
                                  AND ROWID(b-es-tit-imp) <> ROWID(es-tit-acr-importa-tit) NO-ERROR.
                            IF AVAILABLE b-es-tit-imp THEN DO:
                                ASSIGN b-es-tit-imp.val_recebido = b-es-tit-imp.val_recebido + d-saldo-imp.
                                VALIDATE b-es-tit-imp NO-ERROR.
                                ASSIGN tt-es-tit-acr-abrt.val_pendente = tt-es-tit-acr-abrt.val_pendente - d-saldo-imp.
                                IF tt-es-tit-acr-abrt.val_pendente <= 0 THEN DELETE tt-es-tit-acr-abrt.
                                oLinha = NEW JsonObject().
                                oLinha:Add("cgc",      b-es-tit-imp.cgc).
                                oLinha:Add("estab",    b-es-tit-imp.cod_estab).
                                oLinha:Add("especie",  b-es-tit-imp.cod_espec_docto).
                                oLinha:Add("serie",    b-es-tit-imp.cod_ser_docto).
                                oLinha:Add("titulo",   b-es-tit-imp.cod_tit_acr).
                                oLinha:Add("parcela",  b-es-tit-imp.cod_parcela).
                                oLinha:Add("valor",    b-es-tit-imp.val_recebido).
                                oLinha:Add("situacao", "Importado").
                                oLinha:Add("mensagem", "Agrupado ao titulo (liquida parcial)").
                                aResult:Add(oLinha).
                                RELEASE b-es-tit-imp NO-ERROR.
                                DELETE es-tit-acr-importa-tit NO-ERROR.
                                NEXT.
                            END.

                            ASSIGN es-tit-acr-importa-tit.cod_estab          = tt-es-tit-acr-abrt.cod_estab
                                   es-tit-acr-importa-tit.cod_espec_docto    = tt-es-tit-acr-abrt.cod_espec_docto
                                   es-tit-acr-importa-tit.cod_ser_docto      = tt-es-tit-acr-abrt.cod_ser_docto
                                   es-tit-acr-importa-tit.cod_tit_acr        = tt-es-tit-acr-abrt.cod_tit_acr
                                   es-tit-acr-importa-tit.cod_parcela        = tt-es-tit-acr-abrt.cod_parcela
                                   es-tit-acr-importa-tit.val_recebido       = d-saldo-imp
                                   es-tit-acr-importa-tit.ind_sit_importacao = "Pendente" NO-ERROR.
                            VALIDATE es-tit-acr-importa-tit NO-ERROR.

                            
                            ASSIGN tt-es-tit-acr-abrt.val_pendente = tt-es-tit-acr-abrt.val_pendente - d-saldo-imp.
                            IF tt-es-tit-acr-abrt.val_pendente <= 0 THEN DELETE tt-es-tit-acr-abrt.

                            oLinha = NEW JsonObject().
                            oLinha:Add("cgc",      es-tit-acr-importa-tit.cgc).
                            oLinha:Add("estab",    es-tit-acr-importa-tit.cod_estab).
                            oLinha:Add("especie",  es-tit-acr-importa-tit.cod_espec_docto).
                            oLinha:Add("serie",    es-tit-acr-importa-tit.cod_ser_docto).
                            oLinha:Add("titulo",   es-tit-acr-importa-tit.cod_tit_acr).
                            oLinha:Add("parcela",  es-tit-acr-importa-tit.cod_parcela).
                            oLinha:Add("valor",    es-tit-acr-importa-tit.val_recebido).
                            oLinha:Add("situacao", "Importado").
                            oLinha:Add("mensagem", "Vinculado parcialmente ao titulo (liquida parcial)").
                            aResult:Add(oLinha).
                            RELEASE es-tit-acr-importa-tit NO-ERROR.
                            NEXT.
                        END.
                    END.

                    
                    IF c-lote-info <> "" THEN DO:
                        oLinha = NEW JsonObject().
                        oLinha:Add("cgc",      es-tit-acr-importa-tit.cgc).
                        oLinha:Add("estab",    es-tit-acr-importa-tit.cod_estab).
                        oLinha:Add("especie",  es-tit-acr-importa-tit.cod_espec_docto).
                        oLinha:Add("serie",    es-tit-acr-importa-tit.cod_ser_docto).
                        oLinha:Add("titulo",   es-tit-acr-importa-tit.cod_tit_acr).
                        oLinha:Add("parcela",  es-tit-acr-importa-tit.cod_parcela).
                        oLinha:Add("valor",    d-saldo-imp).
                        oLinha:Add("observacao", c-obs).
                        oLinha:Add("situacao", "Erro").
                        oLinha:Add("mensagem", "Titulo nao encontrado para o valor informado"
                                             + " - AD nao gerado (importacao por lote).").
                        aResult:Add(oLinha).
                        DELETE es-tit-acr-importa-tit NO-ERROR.
                        NEXT.
                    END.

                    
                    ASSIGN l-ad-uni = NO
                           c-titulo-ad-imp = ""
                           c-est-ad-imp = (IF es-tit-acr-importa-tit.cod_estab <> "" THEN es-tit-acr-importa-tit.cod_estab ELSE "001").
                    DO i-tenta = 1 TO 20 WHILE l-ad-uni = NO:
                        ASSIGN c-titulo-ad-imp = "AD"
                                               + SUBSTRING(STRING(TODAY, "99999999"), 7, 2)
                                               + SUBSTRING(STRING(TODAY, "99999999"), 3, 2)
                                               + "T".
                        DO v-cont-ad = 1 TO 3:
                            ASSIGN v-num-ad        = (RANDOM(0, (TIME * i-tenta) + (i * 131) + v-cont-ad + 9999) MOD 26) + 97
                                   c-titulo-ad-imp = c-titulo-ad-imp + CHR(v-num-ad).
                        END.
                        
                        IF NOT CAN-FIND(FIRST tit_acr
                                        WHERE tit_acr.cod_estab       = c-est-ad-imp
                                          AND tit_acr.cod_espec_docto = "AD"
                                          AND tit_acr.cod_ser_docto   = ""
                                          AND tit_acr.cod_tit_acr     = c-titulo-ad-imp
                                          AND tit_acr.cod_parcela     = "01")
                           AND NOT CAN-FIND(FIRST es_tit_acr_abrt
                                        WHERE es_tit_acr_abrt.cgc             = es-tit-acr-importa-tit.cgc
                                          AND es_tit_acr_abrt.cod_estab       = c-est-ad-imp
                                          AND es_tit_acr_abrt.cod_espec_docto = "AD"
                                          AND es_tit_acr_abrt.cod_ser_docto   = ""
                                          AND es_tit_acr_abrt.cod_tit_acr     = c-titulo-ad-imp
                                          AND es_tit_acr_abrt.cod_parcela     = "01")
                           AND INDEX(c-cod-ad-geral, c-titulo-ad-imp) = 0 THEN
                            l-ad-uni = YES.
                    END.

                    IF NOT l-ad-uni THEN DO:
                        DELETE es-tit-acr-importa-tit NO-ERROR.
                        oLinha = NEW JsonObject().
                        oLinha:Add("cgc",      c-cgc).
                        oLinha:Add("estab",    "").
                        oLinha:Add("especie",  "AD").
                        oLinha:Add("serie",    "").
                        oLinha:Add("titulo",   "").
                        oLinha:Add("parcela",  "").
                        oLinha:Add("valor",    d-saldo-imp).
                        oLinha:Add("situacao", "Erro").
                        oLinha:Add("mensagem", "Nao foi possivel gerar codigo AD unico (3 tentativas)").
                        aResult:Add(oLinha).
                    END.
                    ELSE DO:
                        ASSIGN es-tit-acr-importa-tit.cod_estab       = c-est-ad-imp
                               es-tit-acr-importa-tit.cod_espec_docto = "AD"
                               es-tit-acr-importa-tit.cod_ser_docto   = ""
                               es-tit-acr-importa-tit.cod_tit_acr     = c-titulo-ad-imp
                               es-tit-acr-importa-tit.cod_parcela     = (IF c-parcela <> "" THEN c-parcela ELSE "01")
                               es-tit-acr-importa-tit.val_recebido    = d-saldo-imp NO-ERROR.
                        VALIDATE es-tit-acr-importa-tit NO-ERROR.
                        ASSIGN c-cod-ad-geral = c-cod-ad-geral + c-titulo-ad-imp + " ".
                        oLinha = NEW JsonObject().
                        oLinha:Add("cgc",      es-tit-acr-importa-tit.cgc).
                        oLinha:Add("estab",    es-tit-acr-importa-tit.cod_estab).
                        oLinha:Add("especie",  "AD").
                        oLinha:Add("serie",    "").
                        oLinha:Add("titulo",   c-titulo-ad-imp).
                        oLinha:Add("parcela",  "01").
                        oLinha:Add("valor",    d-saldo-imp).
                        oLinha:Add("situacao", "Importado").
                        oLinha:Add("mensagem", "AD gerado: " + c-titulo-ad-imp).
                        aResult:Add(oLinha).
                        RELEASE es-tit-acr-importa-tit NO-ERROR.
                    END.
                END.
                NEXT.
            END.

            IF ERROR-STATUS:ERROR THEN DO:
                c-erro = ERROR-STATUS:GET-MESSAGE(1).
                DELETE es-tit-acr-importa-tit NO-ERROR.

                oLinha = NEW JsonObject().
                oLinha:Add("cgc",      c-cgc).
                oLinha:Add("estab",    c-estab).
                oLinha:Add("especie",  c-espec).
                oLinha:Add("serie",    c-serie).
                oLinha:Add("titulo",   c-titulo).
                oLinha:Add("parcela",  c-parcela).
                oLinha:Add("situacao", "Erro").
                oLinha:Add("mensagem", c-erro).
                aResult:Add(oLinha).
            END.
            ELSE DO:
                VALIDATE es-tit-acr-importa-tit NO-ERROR.
                IF ERROR-STATUS:ERROR THEN DO:
                    c-erro = ERROR-STATUS:GET-MESSAGE(1).
                    DELETE es-tit-acr-importa-tit NO-ERROR.

                    oLinha = NEW JsonObject().
                    oLinha:Add("cgc",      c-cgc).
                    oLinha:Add("estab",    c-estab).
                    oLinha:Add("especie",  c-espec).
                    oLinha:Add("serie",    c-serie).
                    oLinha:Add("titulo",   c-titulo).
                    oLinha:Add("parcela",  c-parcela).
                    oLinha:Add("situacao", "Erro").
                    oLinha:Add("mensagem", c-erro).
                    aResult:Add(oLinha).

                    
                    IF AVAIL es_tit_acr_abrt THEN
                        RELEASE es_tit_acr_abrt NO-ERROR.
                END.
                ELSE DO:
                    
                    oLinha = NEW JsonObject().
                    oLinha:Add("cgc",      c-cgc).
                    oLinha:Add("estab",    c-estab).
                    oLinha:Add("especie",  c-espec).
                    oLinha:Add("serie",    c-serie).
                    oLinha:Add("titulo",   c-titulo).
                    oLinha:Add("parcela",  c-parcela).
                    oLinha:Add("situacao", "Importado").
                    oLinha:Add("mensagem", "Importado com sucesso").
                    aResult:Add(oLinha).

                    
                    IF AVAIL es_tit_acr_abrt THEN
                        DELETE es_tit_acr_abrt. 
                END.
                RELEASE es-tit-acr-importa-tit NO-ERROR.
            END.
        END.
    END.

    
    DEFINE BUFFER b-imp-dedup FOR es-tit-acr-importa-tit.
    DEFINE BUFFER b-imp-dup   FOR es-tit-acr-importa-tit.
    DEFINE VARIABLE c-chave-dedup AS CHARACTER NO-UNDO.
    EMPTY TEMP-TABLE tt-dedup-key.
    FOR EACH b-imp-dedup EXCLUSIVE-LOCK
        WHERE b-imp-dedup.ind_sit_importacao = "Pendente"
          AND b-imp-dedup.cod_tit_acr <> ""
          AND b-imp-dedup.cod_arq_origem BEGINS "upload-web":
        ASSIGN c-chave-dedup = b-imp-dedup.cgc + "|" + b-imp-dedup.cod_estab + "|"
                             + b-imp-dedup.cod_espec_docto + "|" + b-imp-dedup.cod_ser_docto + "|"
                             + b-imp-dedup.cod_tit_acr + "|" + b-imp-dedup.cod_parcela.
        FIND FIRST tt-dedup-key WHERE tt-dedup-key.chave = c-chave-dedup NO-ERROR.
        IF AVAILABLE tt-dedup-key THEN DO:
            FIND b-imp-dup EXCLUSIVE-LOCK WHERE ROWID(b-imp-dup) = tt-dedup-key.rprim NO-ERROR.
            IF AVAILABLE b-imp-dup THEN DO:
                ASSIGN b-imp-dup.val_recebido = b-imp-dup.val_recebido + b-imp-dedup.val_recebido.
                DELETE b-imp-dedup.
            END.
        END.
        ELSE DO:
            CREATE tt-dedup-key.
            ASSIGN tt-dedup-key.chave = c-chave-dedup
                   tt-dedup-key.rprim = ROWID(b-imp-dedup).
        END.
    END.

    oResp = NEW JsonObject().
    oResp:Add("status", "ok").
    oResp:Add("resultados", aResult).
    oResp:Add("debugArquivoTt", c-arq-debug-tt).
    oResp:Add("debugQtdeTt", i-cont-tt).

    /* Envia o resultado da importacao por e-mail (parametro liquidacao-auto/envio). */
    RUN pi-enviar-email-importacao (INPUT aResult) NO-ERROR.

    oResp:Write(lc-resposta, TRUE).
    i-status = 200.

    CATCH oE AS Progress.Lang.Error:
        oResp = NEW JsonObject().
        oResp:Add("error", oE:GetMessage(1)).
        oResp:Write(lc-resposta, TRUE).
        i-status = 500.
    END CATCH.
END PROCEDURE.

PROCEDURE pi-enviar-email-importacao:
    DEFINE INPUT PARAMETER aRes AS JsonArray NO-UNDO.

    DEFINE VARIABLE c-remet     AS CHARACTER NO-UNDO.
    DEFINE VARIABLE c-dest      AS CHARACTER NO-UNDO.
    DEFINE VARIABLE c-envio     AS CHARACTER NO-UNDO.
    DEFINE VARIABLE h-utapi019  AS HANDLE    NO-UNDO.
    DEFINE VARIABLE i-qt-err    AS INTEGER   NO-UNDO.
    DEFINE VARIABLE i-qt-tot    AS INTEGER   NO-UNDO.
    DEFINE VARIABLE i-i         AS INTEGER   NO-UNDO.
    DEFINE VARIABLE oItm        AS JsonObject NO-UNDO.
    DEFINE VARIABLE c-sit       AS CHARACTER NO-UNDO.
    DEFINE VARIABLE c-arq-anexo AS CHARACTER NO-UNDO.
    DEFINE VARIABLE c-corpo     AS CHARACTER NO-UNDO.
    DEFINE STREAM s-anexo.

    /* Parametros de e-mail (es_param_global_ti_item / liquidacao-auto). */
    FIND FIRST es_param_global_ti_item NO-LOCK
        WHERE es_param_global_ti_item.cod_parametro      = "liquidacao-auto"
          AND es_param_global_ti_item.cod_parametro_item = "EmailRemetente" NO-ERROR.
    IF AVAILABLE es_param_global_ti_item THEN c-remet = TRIM(es_param_global_ti_item.val_1).
    FIND FIRST es_param_global_ti_item NO-LOCK
        WHERE es_param_global_ti_item.cod_parametro      = "liquidacao-auto"
          AND es_param_global_ti_item.cod_parametro_item = "EmailDest" NO-ERROR.
    IF AVAILABLE es_param_global_ti_item THEN c-dest = TRIM(es_param_global_ti_item.val_1).
    FIND FIRST es_param_global_ti_item NO-LOCK
        WHERE es_param_global_ti_item.cod_parametro      = "liquidacao-auto"
          AND es_param_global_ti_item.cod_parametro_item = "envio" NO-ERROR.
    IF AVAILABLE es_param_global_ti_item THEN c-envio = TRIM(es_param_global_ti_item.val_1).

    IF c-remet = "" OR c-remet = ? THEN RETURN.
    IF c-dest  = "" OR c-dest  = ? THEN c-dest = c-remet.
    IF c-envio = ? THEN c-envio = "".

    /* Conta erros/total no resultado. */
    ASSIGN i-qt-err = 0 i-qt-tot = 0.
    IF VALID-OBJECT(aRes) THEN
    DO i-i = 1 TO aRes:Length:
        oItm = aRes:GetJsonObject(i-i) NO-ERROR.
        IF NOT VALID-OBJECT(oItm) THEN NEXT.
        i-qt-tot = i-qt-tot + 1.
        c-sit = (IF oItm:Has("situacao") THEN oItm:GetCharacter("situacao") ELSE "") NO-ERROR.
        IF c-sit = "Erro" THEN i-qt-err = i-qt-err + 1.
    END.

    /* Regra: "somente-erro" so envia se houver erro; "tudo" sempre envia. */
    IF c-envio = "somente-erro" AND i-qt-err = 0 THEN RETURN.

    /* Gera o anexo (CSV, separador ";") com o resultado da importacao. */
    ASSIGN c-arq-anexo = SESSION:TEMP-DIRECTORY + "/resultado_importacao_" + STRING(TIME) + ".csv".
    OUTPUT STREAM s-anexo TO VALUE(c-arq-anexo).
    PUT STREAM s-anexo UNFORMATTED
        "CGC/CPF;Estab;Especie;Serie;Titulo;Parcela;Valor;Observacao;Situacao;Mensagem" SKIP.
    IF VALID-OBJECT(aRes) THEN
    DO i-i = 1 TO aRes:Length:
        oItm = aRes:GetJsonObject(i-i) NO-ERROR.
        IF NOT VALID-OBJECT(oItm) THEN NEXT.
        PUT STREAM s-anexo UNFORMATTED
            (IF oItm:Has("cgc")        THEN oItm:GetCharacter("cgc")        ELSE "") ";"
            (IF oItm:Has("estab")      THEN oItm:GetCharacter("estab")      ELSE "") ";"
            (IF oItm:Has("especie")    THEN oItm:GetCharacter("especie")    ELSE "") ";"
            (IF oItm:Has("serie")      THEN oItm:GetCharacter("serie")      ELSE "") ";"
            (IF oItm:Has("titulo")     THEN oItm:GetCharacter("titulo")     ELSE "") ";"
            (IF oItm:Has("parcela")    THEN oItm:GetCharacter("parcela")    ELSE "") ";"
            (IF oItm:Has("valor")      THEN STRING(oItm:GetDecimal("valor")) ELSE "") ";"
            (IF oItm:Has("observacao") THEN oItm:GetCharacter("observacao") ELSE "") ";"
            (IF oItm:Has("situacao")   THEN oItm:GetCharacter("situacao")   ELSE "") ";"
            (IF oItm:Has("mensagem")   THEN oItm:GetCharacter("mensagem")   ELSE "") SKIP.
    END.
    OUTPUT STREAM s-anexo CLOSE.

    /* Corpo do e-mail. */
    ASSIGN c-corpo = "<html><body style='font-family:Arial,sans-serif;'>"
                   + "<h2>Importacao de Titulos ACR</h2>"
                   + "<p>Data: " + STRING(TODAY,"99/99/9999") + " " + STRING(TIME,"HH:MM:SS") + "</p>"
                   + "<p>Total de registros: " + STRING(i-qt-tot)
                   + "<br>Com erro: " + STRING(i-qt-err) + "</p>"
                   + "<p>Segue em anexo o resultado da importacao.</p>"
                   + "</body></html>".

    FIND FIRST param_email NO-LOCK NO-ERROR.
    IF NOT VALID-HANDLE(h-utapi019) THEN RUN utp/utapi019.p PERSISTENT SET h-utapi019.

    EMPTY TEMP-TABLE tt-envio2.
    EMPTY TEMP-TABLE tt-mensagem.
    EMPTY TEMP-TABLE tt-paramEmail2.
    EMPTY TEMP-TABLE ttAttachment.
    EMPTY TEMP-TABLE tt-erros.

    CREATE tt-envio2.
    ASSIGN tt-envio2.versao-integracao = 1
           tt-envio2.servidor          = (IF AVAIL param_email THEN param_email.cod_servid_e_mail ELSE "")
           tt-envio2.porta             = (IF AVAIL param_email THEN param_email.num_porta ELSE 0)
           tt-envio2.destino           = c-dest
           tt-envio2.remetente         = c-remet
           tt-envio2.assunto           = "Importacao de Titulos ACR - " + STRING(TODAY,"99/99/9999")
                                       + (IF i-qt-err > 0 THEN " - COM ERROS (" + STRING(i-qt-err) + ")" ELSE "")
           tt-envio2.importancia       = 2
           tt-envio2.log-enviada       = YES
           tt-envio2.log-lida          = NO
           tt-envio2.acomp             = NO
           tt-envio2.formato           = "HTML".

    CREATE tt-mensagem.
    ASSIGN tt-mensagem.seq-mensagem = 1
           tt-mensagem.mensagem     = c-corpo.

    CREATE tt-paramEmail2.
    ASSIGN tt-paramEmail2.caminhoEmail     = 5
           tt-paramEmail2.AtivaRemetPadrao = NO
           tt-paramEmail2.codRemetPadrao   = c-remet.

    CREATE ttAttachment.
    ASSIGN ttAttachment.fileName = "resultado_importacao.csv"
           ttAttachment.fileType = "text/csv".
    COPY-LOB FILE c-arq-anexo TO ttAttachment.fileContent.

    RUN pi-execute4 IN h-utapi019 (INPUT  TABLE tt-envio2,
                                   INPUT  TABLE tt-mensagem,
                                   INPUT  TABLE tt-paramEmail2,
                                   INPUT  TABLE ttAttachment,
                                   OUTPUT TABLE tt-erros).

    IF VALID-HANDLE(h-utapi019) THEN DELETE PROCEDURE h-utapi019 NO-ERROR.

    CATCH oEmailErr AS Progress.Lang.Error:
        /* Falha no envio de e-mail nao interrompe a importacao. */
    END CATCH.
END PROCEDURE.

PROCEDURE pi-gerar-relatorio:
    DEFINE INPUT  PARAM oJsonInput  AS JsonObject NO-UNDO.
    DEFINE OUTPUT PARAM lc-resposta AS LONGCHAR   NO-UNDO.
    DEFINE OUTPUT PARAM i-status    AS INTEGER    NO-UNDO.

    DEFINE VARIABLE oResp AS JsonObject NO-UNDO.
    DEFINE VARIABLE h-utapi033 AS HANDLE NO-UNDO.
    DEFINE VARIABLE c-arquivo  AS CHARACTER NO-UNDO.
    DEFINE VARIABLE c-msg      AS CHARACTER NO-UNDO.
    DEFINE VARIABLE cRaizCnpj  AS CHARACTER NO-UNDO.

    
    DEFINE VARIABLE c-cnpjIni   AS CHARACTER NO-UNDO.
    DEFINE VARIABLE c-cnpjFim   AS CHARACTER NO-UNDO.
    DEFINE VARIABLE c-estabIni  AS CHARACTER NO-UNDO.
    DEFINE VARIABLE c-estabFim  AS CHARACTER NO-UNDO.
    DEFINE VARIABLE c-serieIni  AS CHARACTER NO-UNDO.
    DEFINE VARIABLE c-serieFim  AS CHARACTER NO-UNDO.
    DEFINE VARIABLE c-tituloIni AS CHARACTER NO-UNDO.
    DEFINE VARIABLE c-tituloFim AS CHARACTER NO-UNDO.
    DEFINE VARIABLE c-situacao  AS CHARACTER NO-UNDO.

    DEFINE VARIABLE oRealBody AS JsonObject NO-UNDO.

    IF oJsonInput:Has("payload") THEN
        oRealBody = oJsonInput:GetJsonObject("payload") NO-ERROR.
    ELSE IF oJsonInput:Has("requestBody") THEN
        oRealBody = oJsonInput:GetJsonObject("requestBody") NO-ERROR.
    ELSE IF oJsonInput:Has("body") THEN
        oRealBody = oJsonInput:GetJsonObject("body") NO-ERROR.
    ELSE 
        oRealBody = oJsonInput. 

    IF VALID-OBJECT(oRealBody) THEN DO:
        ASSIGN 
            c-cnpjIni   = oRealBody:GetCharacter("cnpjIni")   NO-ERROR.
            c-cnpjFim   = oRealBody:GetCharacter("cnpjFim")   NO-ERROR.
            c-estabIni  = oRealBody:GetCharacter("estabIni")  NO-ERROR.
            c-estabFim  = oRealBody:GetCharacter("estabFim")  NO-ERROR.
            c-serieIni  = oRealBody:GetCharacter("serieIni")  NO-ERROR.
            c-serieFim  = oRealBody:GetCharacter("serieFim")  NO-ERROR.
            c-tituloIni = oRealBody:GetCharacter("tituloIni") NO-ERROR.
            c-tituloFim = oRealBody:GetCharacter("tituloFim") NO-ERROR.
            c-situacao  = oRealBody:GetCharacter("situacao")  NO-ERROR.
    END.

    IF c-situacao = ? THEN c-situacao = "".
    IF c-cnpjIni = ? THEN c-cnpjIni = "".
    IF c-estabIni = ? THEN c-estabIni = "".
    IF c-serieIni = ? THEN c-serieIni = "".
    IF c-tituloIni = ? THEN c-tituloIni = "".

    IF c-cnpjFim = ? OR c-cnpjFim = "" THEN c-cnpjFim = "zzzzzzzzzzzzzzzzzzzz".
    IF c-estabFim = ? OR c-estabFim = "" THEN c-estabFim = "zzzzz".
    IF c-serieFim = ? OR c-serieFim = "" THEN c-serieFim = "zzzzz".
    IF c-tituloFim = ? OR c-tituloFim = "" THEN c-tituloFim = "zzzzzzzzz".

    EMPTY TEMP-TABLE tt-relatorio-excel.

    DEFINE VARIABLE i-count AS INTEGER NO-UNDO INITIAL 0.

    FOR EACH es-tit-acr-importa-tit
        WHERE es-tit-acr-importa-tit.cgc           >= c-cnpjIni  AND es-tit-acr-importa-tit.cgc           <= c-cnpjFim
          AND es-tit-acr-importa-tit.cod_estab     >= c-estabIni AND es-tit-acr-importa-tit.cod_estab     <= c-estabFim
          AND es-tit-acr-importa-tit.cod_ser_docto >= c-serieIni AND es-tit-acr-importa-tit.cod_ser_docto <= c-serieFim
          AND es-tit-acr-importa-tit.cod_tit_acr   >= c-tituloIni AND es-tit-acr-importa-tit.cod_tit_acr  <= c-tituloFim
          AND (c-situacao = "" OR es-tit-acr-importa-tit.ind_sit_importacao = c-situacao) NO-LOCK:
        i-count = i-count + 1.

        FIND FIRST emitente WHERE emitente.cgc = es-tit-acr-importa-tit.cgc NO-LOCK NO-ERROR.

        CREATE tt-relatorio-excel.
        ASSIGN
            tt-relatorio-excel.cgc             = es-tit-acr-importa-tit.cgc
            tt-relatorio-excel.nome_emit       = (IF AVAIL emitente THEN emitente.nome-emit ELSE "")
            tt-relatorio-excel.cod_estab       = es-tit-acr-importa-tit.cod_estab
            tt-relatorio-excel.cod_espec_docto = es-tit-acr-importa-tit.cod_espec_docto
            tt-relatorio-excel.cod_ser_docto   = es-tit-acr-importa-tit.cod_ser_docto
            tt-relatorio-excel.cod_tit_acr     = es-tit-acr-importa-tit.cod_tit_acr
            tt-relatorio-excel.cod_parcela     = es-tit-acr-importa-tit.cod_parcela
            tt-relatorio-excel.val_tit_acr     = es-tit-acr-importa-tit.val_recebido
            tt-relatorio-excel.situacao        = es-tit-acr-importa-tit.ind_sit_importacao
            tt-relatorio-excel.des_mensagem_erro = REPLACE(REPLACE(es-tit-acr-importa-tit.des_mensagem_erro, CHR(10), " "), CHR(13), " ").

        FIND FIRST tit_acr WHERE
            tit_acr.cod_estab        = es-tit-acr-importa-tit.cod_estab         AND
            tit_acr.cod_espec_docto  = es-tit-acr-importa-tit.cod_espec_docto   AND
            tit_acr.cod_ser_docto    = es-tit-acr-importa-tit.cod_ser_docto     AND
            tit_acr.cod_tit_acr      = es-tit-acr-importa-tit.cod_tit_acr       AND
            tit_acr.cod_parcela      = es-tit-acr-importa-tit.cod_parcela       NO-LOCK NO-ERROR.

        IF AVAIL tit_acr THEN DO:
            ASSIGN
                tt-relatorio-excel.disp-acr       = YES
                tt-relatorio-excel.valr-abrt-acr  = tit_acr.val_sdo_tit_acr.
        END.
        ELSE DO:
            ASSIGN
                tt-relatorio-excel.disp-acr       = NO
                tt-relatorio-excel.valr-abrt-acr  = 0.
        END.
    END.

    IF i-count = 0 THEN DO:
        oResp = NEW JsonObject().
        oResp:Add("error", "Nenhum titulo. cgc: '" + c-cnpjIni + "'-'" + c-cnpjFim + "' estab: '" + c-estabIni + "'-'" + c-estabFim + "'").
        oResp:Write(lc-resposta, TRUE).
        i-status = 400.
        RETURN.
    END.

    
    RUN utp/utapi033.p PERSISTENT SET h-utapi033.
    RUN show IN h-utapi033 (FALSE). 
    RUN ConvertToXls IN h-utapi033 (FALSE). 

    RUN piWorksheetColumn IN h-utapi033(INPUT 1, INPUT 01, INPUT "CHAR", INPUT "CNPJ"       , INPUT "x(20)", INPUT 120). 
    RUN piWorksheetColumn IN h-utapi033(INPUT 1, INPUT 02, INPUT "CHAR", INPUT "Cliente"    , INPUT "x(40)", INPUT 200).
    RUN piWorksheetColumn IN h-utapi033(INPUT 1, INPUT 03, INPUT "CHAR", INPUT "Estab"      , INPUT "x(5)", INPUT 60). 
    RUN piWorksheetColumn IN h-utapi033(INPUT 1, INPUT 04, INPUT "CHAR", INPUT "Esp"        , INPUT "x(5)", INPUT 60). 
    RUN piWorksheetColumn IN h-utapi033(INPUT 1, INPUT 05, INPUT "CHAR", INPUT "Serie"      , INPUT "x(5)", INPUT 60). 
    RUN piWorksheetColumn IN h-utapi033(INPUT 1, INPUT 06, INPUT "CHAR", INPUT "Titulo"     , INPUT "x(12)", INPUT 100). 
    RUN piWorksheetColumn IN h-utapi033(INPUT 1, INPUT 07, INPUT "CHAR", INPUT "Parcela"    , INPUT "x(3)", INPUT 50). 
    RUN piWorksheetColumn IN h-utapi033(INPUT 1, INPUT 08, INPUT "DECI", INPUT "Valor"      , INPUT ">>>,>>>,>>9.99", INPUT 100).
    RUN piWorksheetColumn IN h-utapi033(INPUT 1, INPUT 09, INPUT "CHAR", INPUT "Situacao"    , INPUT "x(12)", INPUT 90).
    RUN piWorksheetColumn IN h-utapi033(INPUT 1, INPUT 10, INPUT "LOGI", INPUT "Disp. ACR"  , INPUT "Sim/Nao", INPUT 80).
    RUN piWorksheetColumn IN h-utapi033(INPUT 1, INPUT 11, INPUT "DECI", INPUT "Vl. Abrt ACR", INPUT ">>>,>>>,>>9.99", INPUT 100).
    RUN piWorksheetColumn IN h-utapi033(INPUT 1, INPUT 12, INPUT "CHAR", INPUT "Descricao Erro", INPUT "x(500)", INPUT 400).

    RUN piNewWorksheetbyTT IN h-utapi033(INPUT "TITULOS",
                                         INPUT "Relatorio de Titulos",
                                         INPUT BUFFER tt-relatorio-excel:HANDLE,
                                         "cgc,nome_emit,cod_estab,cod_espec_docto,cod_ser_docto,cod_tit_acr,cod_parcela,val_tit_acr,situacao,disp-acr,valr-abrt-acr,des_mensagem_erro",
                                         "cgc").
                                         
    c-arquivo = "C:\temp\relat_acr_" + REPLACE(STRING(TIME), ":", "") + ".xls".

    RUN piProcessa IN h-utapi033 (INPUT-OUTPUT c-arquivo, 
                                  INPUT "REL001",             
                                  INPUT "Relatorio de Titulos ACR").

    DEFINE VARIABLE m-file AS MEMPTR NO-UNDO.
    DEFINE VARIABLE lc-b64 AS LONGCHAR NO-UNDO.

    IF RETURN-VALUE <> "OK" THEN DO:
        c-msg = "Erro ao gerar arquivo XML".
    END.
    ELSE DO:
        c-msg = "Relatorio gerado com sucesso".
        FILE-INFO:FILE-NAME = c-arquivo.
        IF FILE-INFO:FULL-PATHNAME <> ? THEN DO:
            COPY-LOB FROM FILE c-arquivo TO m-file NO-ERROR.
            IF NOT ERROR-STATUS:ERROR THEN DO:
                lc-b64 = BASE64-ENCODE(m-file).
                SET-SIZE(m-file) = 0.
            END.
            ELSE c-msg = "Erro ao ler o arquivo gerado: " + c-arquivo.
        END.
        ELSE c-msg = "Arquivo nao encontrado apos geracao: " + c-arquivo.
    END.

    IF VALID-HANDLE(h-utapi033) THEN DELETE OBJECT h-utapi033 NO-ERROR.

    oResp = NEW JsonObject().
    oResp:Add("status", "ok").
    oResp:Add("message", c-msg).
    IF lc-b64 <> "" THEN oResp:Add("base64Data", lc-b64).
    oResp:Add("fileName", "Relatorio_ACR_" + STRING(TIME) + ".xls").
    oResp:Write(lc-resposta, TRUE).
    i-status = 200.

    CATCH oE AS Progress.Lang.Error:
        oResp = NEW JsonObject().
        oResp:Add("error", oE:GetMessage(1)).
        oResp:Write(lc-resposta, TRUE).
        i-status = 500.
    END CATCH.
END PROCEDURE.

PROCEDURE pi-listar-rpw-servidores:
    DEFINE INPUT  PARAMETER oJsonIn     AS JsonObject NO-UNDO.
    DEFINE OUTPUT PARAMETER lc-resposta AS LONGCHAR   NO-UNDO.
    DEFINE OUTPUT PARAMETER i-status    AS INTEGER    NO-UNDO.

    DEFINE VARIABLE oResp    AS JsonObject NO-UNDO.
    DEFINE VARIABLE aItems   AS JsonArray  NO-UNDO.
    DEFINE VARIABLE oItem    AS JsonObject NO-UNDO.
    DEFINE VARIABLE c-vistos AS CHARACTER  NO-UNDO INITIAL "".

    aItems = NEW JsonArray().

    FOR EACH cadastro_appserver NO-LOCK
        WHERE cadastro_appserver.cod_aplicat = "RPW":

        FIND FIRST servid_exec NO-LOCK
            WHERE servid_exec.cod_servid_exec      = cadastro_appserver.des_appserver_alias
              AND servid_exec.cdn_empres_servid    = cadastro_appserver.cod_empresa
              AND servid_exec.log_servid_exec_ativ = YES NO-ERROR.

        IF AVAILABLE servid_exec
           AND LOOKUP(servid_exec.cod_servid_exec, c-vistos) = 0 THEN DO:
            c-vistos = c-vistos + (IF c-vistos = "" THEN "" ELSE ",") + servid_exec.cod_servid_exec.

            oItem = NEW JsonObject().
            oItem:Add("codServidExec", servid_exec.cod_servid_exec).
            oItem:Add("descricao",     servid_exec.des_servid_exec).
            oItem:Add("tipoFila",      servid_exec.ind_tip_fila_exec).
            aItems:Add(oItem).
        END.
    END.

    oResp = NEW JsonObject().
    oResp:Add("items", aItems).
    oResp:Write(lc-resposta, TRUE).
    i-status = 200.

    CATCH oErpw AS Progress.Lang.Error:
        oResp = NEW JsonObject().
        oResp:Add("error", oErpw:GetMessage(1)).
        oResp:Write(lc-resposta, TRUE).
        i-status = 500.
    END CATCH.
END PROCEDURE.

PROCEDURE pi-importar-rpw:
    DEFINE INPUT  PARAMETER oJsonInput  AS JsonObject NO-UNDO.
    DEFINE OUTPUT PARAMETER lc-resposta AS LONGCHAR   NO-UNDO.
    DEFINE OUTPUT PARAMETER i-status    AS INTEGER    NO-UNDO.

    DEFINE VARIABLE oRealBody   AS JsonObject NO-UNDO.
    DEFINE VARIABLE oResp       AS JsonObject NO-UNDO.
    DEFINE VARIABLE lc-conteudo AS LONGCHAR   NO-UNDO.
    DEFINE VARIABLE c-path      AS CHARACTER  NO-UNDO.
    DEFINE VARIABLE c-arquivo   AS CHARACTER  NO-UNDO.
    DEFINE VARIABLE c-nome-arq  AS CHARACTER  NO-UNDO.

    IF oJsonInput:Has("payload") THEN
        oRealBody = oJsonInput:GetJsonObject("payload") NO-ERROR.
    ELSE IF oJsonInput:Has("requestBody") THEN
        oRealBody = oJsonInput:GetJsonObject("requestBody") NO-ERROR.
    ELSE IF oJsonInput:Has("body") THEN
        oRealBody = oJsonInput:GetJsonObject("body") NO-ERROR.
    ELSE
        oRealBody = oJsonInput.

    IF VALID-OBJECT(oRealBody) AND oRealBody:Has("conteudo") THEN
        lc-conteudo = oRealBody:GetLongchar("conteudo") NO-ERROR.

    IF lc-conteudo = ? OR lc-conteudo = "" THEN DO:
        oResp = NEW JsonObject().
        oResp:Add("error", "Conteudo do arquivo (conteudo) nao informado.").
        oResp:Write(lc-resposta, TRUE).
        i-status = 400.
        RETURN.
    END.

    
    FIND FIRST es_param_global_ti_item NO-LOCK
        WHERE es_param_global_ti_item.cod_parametro      = "importa-cr-rpw"
          AND es_param_global_ti_item.cod_parametro_item = "Linux" NO-ERROR.
    IF NOT AVAILABLE es_param_global_ti_item THEN
        FIND FIRST es_param_global_ti_item NO-LOCK
            WHERE es_param_global_ti_item.cod_parametro      = "importa-cr-rpw"
              AND es_param_global_ti_item.cod_parametro_item = "Unix" NO-ERROR.
    IF NOT AVAILABLE es_param_global_ti_item THEN
        FIND FIRST es_param_global_ti_item NO-LOCK
            WHERE es_param_global_ti_item.cod_parametro = "importa-cr-rpw" NO-ERROR.

    IF NOT AVAILABLE es_param_global_ti_item THEN DO:
        oResp = NEW JsonObject().
        oResp:Add("error", "Parametro 'importa-cr-rpw' nao configurado (es_param_global_ti_item).").
        oResp:Write(lc-resposta, TRUE).
        i-status = 400.
        RETURN.
    END.

    c-path = TRIM(es_param_global_ti_item.val_1).
    IF c-path = "" THEN DO:
        oResp = NEW JsonObject().
        oResp:Add("error", "Caminho (val_1) do parametro 'importa-cr-rpw' esta vazio.").
        oResp:Write(lc-resposta, TRUE).
        i-status = 400.
        RETURN.
    END.

    c-nome-arq = "consolida_arquivo_" + REPLACE(STRING(TIME, "HH:MM:SS"), ":", "") + ".csv".
    IF SUBSTRING(c-path, LENGTH(c-path), 1) = "/" THEN
        c-arquivo = c-path + c-nome-arq.
    ELSE
        c-arquivo = c-path + "/" + c-nome-arq.

    
    COPY-LOB FROM lc-conteudo TO FILE c-arquivo NO-ERROR.
    IF ERROR-STATUS:ERROR THEN DO:
        oResp = NEW JsonObject().
        oResp:Add("error", "Erro ao gravar o arquivo na pasta do RPW (" + c-arquivo + "): "
                           + (IF ERROR-STATUS:NUM-MESSAGES > 0 THEN ERROR-STATUS:GET-MESSAGE(1) ELSE "erro desconhecido")).
        oResp:Write(lc-resposta, TRUE).
        i-status = 500.
        RETURN.
    END.

    oResp = NEW JsonObject().
    oResp:Add("status", "ok").
    oResp:Add("arquivo", c-arquivo).
    oResp:Add("nomeArquivo", c-nome-arq).
    oResp:Write(lc-resposta, TRUE).
    i-status = 200.

    CATCH oErpw AS Progress.Lang.Error:
        oResp = NEW JsonObject().
        oResp:Add("error", "Erro ao gravar arquivo do RPW: " + oErpw:GetMessage(1)).
        oResp:Write(lc-resposta, TRUE).
        i-status = 500.
    END CATCH.
END PROCEDURE.

PROCEDURE pi-acerto-valor-menor:
    DEFINE INPUT  PARAMETER p-rowid-tit AS ROWID     NO-UNDO.
    DEFINE INPUT  PARAMETER p-val-baixa AS DECIMAL   NO-UNDO.
    DEFINE INPUT  PARAMETER p-usuario   AS CHARACTER NO-UNDO.
    DEFINE INPUT  PARAMETER p-dat        AS DATE      NO-UNDO.
    DEFINE OUTPUT PARAMETER p-ok        AS LOGICAL   NO-UNDO.
    DEFINE OUTPUT PARAMETER p-msg       AS CHARACTER NO-UNDO.

    DEFINE BUFFER b-tit-ava FOR tit_acr.
    DEFINE VARIABLE h-ava-api   AS HANDLE    NO-UNDO.
    DEFINE VARIABLE c-ref-ava   AS CHARACTER NO-UNDO.
    DEFINE VARIABLE c-plano-ava AS CHARACTER NO-UNDO.
    DEFINE VARIABLE c-cta-ava   AS CHARACTER NO-UNDO.
    DEFINE VARIABLE c-cart-liq  AS CHARACTER NO-UNDO.
    DEFINE VARIABLE c-erro-cart AS CHARACTER NO-UNDO.

    ASSIGN p-ok = NO p-msg = "".
    IF p-dat = ? THEN p-dat = TODAY.

    
    RUN pi-carteira-liquidacao (OUTPUT c-cart-liq, OUTPUT c-erro-cart).
    IF c-erro-cart <> "" THEN DO: ASSIGN p-msg = c-erro-cart. RETURN. END.

    FIND b-tit-ava NO-LOCK WHERE ROWID(b-tit-ava) = p-rowid-tit NO-ERROR.
    IF NOT AVAILABLE b-tit-ava THEN DO:
        ASSIGN p-msg = "Titulo nao encontrado para acerto de valor a menor.".
        RETURN.
    END.

    
    ASSIGN c-plano-ava = "" c-cta-ava = "".
    FIND FIRST movto_tit_acr OF b-tit-ava NO-LOCK NO-ERROR.
    IF AVAILABLE movto_tit_acr THEN DO:
        FIND FIRST aprop_ctbl_acr OF movto_tit_acr NO-LOCK NO-ERROR.
        IF AVAILABLE aprop_ctbl_acr THEN
            ASSIGN c-plano-ava = aprop_ctbl_acr.cod_plano_cta_ctbl
                   c-cta-ava   = aprop_ctbl_acr.cod_cta_ctbl.
    END.

    EMPTY TEMP-TABLE ttz_ava_base_5.
    EMPTY TEMP-TABLE ttz_ava_cheq.
    EMPTY TEMP-TABLE ttz_ava_cobr_espec_2.
    EMPTY TEMP-TABLE ttz_ava_comis_1.
    EMPTY TEMP-TABLE ttz_ava_impto_retid_2.
    EMPTY TEMP-TABLE ttz_ava_iva.
    EMPTY TEMP-TABLE ttz_ava_ped_vda.
    EMPTY TEMP-TABLE ttz_ava_rateio.
    EMPTY TEMP-TABLE ttz_ava_rat_desp_rec.
    EMPTY TEMP-TABLE ttz_log_erros_ava.
    EMPTY TEMP-TABLE ttz_ava_cobr_esp_2_c.
    EMPTY TEMP-TABLE ttz_params_generic_ava.

    RUN pi-sugestao-referencia-ava (b-tit-ava.cod_estab, "P", TODAY, OUTPUT c-ref-ava).

    CREATE ttz_ava_base_5.
    ASSIGN
        ttz_ava_base_5.tta_cod_estab = b-tit-ava.cod_estab
        ttz_ava_base_5.tta_num_id_tit_acr = b-tit-ava.num_id_tit_acr
        ttz_ava_base_5.tta_dat_transacao = p-dat
        ttz_ava_base_5.tta_cod_refer = c-ref-ava
        ttz_ava_base_5.ttv_cod_motiv_movto_tit_acr_imp = ""
        ttz_ava_base_5.tta_val_sdo_tit_acr = b-tit-ava.val_sdo_tit_acr - p-val-baixa
        ttz_ava_base_5.ttv_cod_motiv_movto_tit_acr_alt = ""
        ttz_ava_base_5.ttv_ind_motiv_acerto_val = "Altera��o"
        ttz_ava_base_5.tta_cod_portador = b-tit-ava.cod_portador
        ttz_ava_base_5.tta_cod_cart_bcia = c-cart-liq
        ttz_ava_base_5.tta_val_despes_bcia = b-tit-ava.val_despes_bcia
        ttz_ava_base_5.tta_cod_agenc_cobr_bcia = b-tit-ava.cod_agenc_cobr_bcia
        ttz_ava_base_5.tta_cod_tit_acr_bco = b-tit-ava.cod_tit_acr_bco
        ttz_ava_base_5.tta_dat_emis_docto = b-tit-ava.dat_emis_docto
        ttz_ava_base_5.tta_dat_vencto_tit_acr = b-tit-ava.dat_vencto_tit_acr
        ttz_ava_base_5.tta_dat_prev_liquidac = b-tit-ava.dat_prev_liquidac
        ttz_ava_base_5.tta_dat_fluxo_tit_acr = b-tit-ava.dat_fluxo_tit_acr
        ttz_ava_base_5.tta_ind_sit_tit_acr = b-tit-ava.ind_sit_tit_acr
        ttz_ava_base_5.tta_cod_cond_cobr = b-tit-ava.cod_cond_cobr
        ttz_ava_base_5.tta_log_tip_cr_perda_dedut_tit = b-tit-ava.log_tip_cr_perda_dedut_tit
        ttz_ava_base_5.tta_dat_abat_tit_acr = ?
        ttz_ava_base_5.tta_val_perc_abat_acr = 0
        ttz_ava_base_5.tta_val_abat_tit_acr = 0
        ttz_ava_base_5.tta_dat_desconto = b-tit-ava.dat_desconto
        ttz_ava_base_5.tta_val_perc_desc = b-tit-ava.val_perc_desc
        ttz_ava_base_5.tta_val_desc_tit_acr = b-tit-ava.val_desc_tit_acr
        ttz_ava_base_5.tta_qtd_dias_carenc_juros_acr = b-tit-ava.qtd_dias_carenc_juros_acr
        ttz_ava_base_5.tta_val_perc_juros_dia_atraso = b-tit-ava.val_perc_juros_dia_atraso
        ttz_ava_base_5.tta_qtd_dias_carenc_multa_acr = b-tit-ava.qtd_dias_carenc_multa_acr
        ttz_ava_base_5.tta_val_perc_multa_atraso = b-tit-ava.val_perc_multa_atraso
        ttz_ava_base_5.ttv_cod_portador_mov = ""
        ttz_ava_base_5.tta_ind_tip_cobr_acr = b-tit-ava.ind_tip_cobr_acr
        ttz_ava_base_5.tta_ind_ender_cobr = b-tit-ava.ind_ender_cobr
        ttz_ava_base_5.tta_nom_abrev_contat = b-tit-ava.nom_abrev_contat
        ttz_ava_base_5.tta_val_liq_tit_acr = b-tit-ava.val_liq_tit_acr
        ttz_ava_base_5.tta_cod_instruc_bcia_1_movto = ""
        ttz_ava_base_5.tta_cod_instruc_bcia_2_movto = ""
        ttz_ava_base_5.tta_log_tit_acr_destndo = NO
        ttz_ava_base_5.tta_cod_histor_padr = ""
        ttz_ava_base_5.ttv_des_text_histor = ""
        ttz_ava_base_5.tta_des_obs_cobr = ""
        ttz_ava_base_5.tta_num_seq_tit_acr = 1
        ttz_ava_base_5.ttv_cod_estab_planilha = ""
        ttz_ava_base_5.ttv_num_planilha_vendor = 0
        ttz_ava_base_5.ttv_cod_cond_pagto_vendor = ""
        ttz_ava_base_5.ttv_val_cotac_tax_vendor_clien = 0
        ttz_ava_base_5.ttv_dat_base_fechto_vendor = ?
        ttz_ava_base_5.ttv_qti_dias_carenc_fechto = 0
        ttz_ava_base_5.ttv_log_assume_tax_bco = NO
        ttz_ava_base_5.ttv_log_vendor = NO
        ttz_ava_base_5.tta_val_cr_pis = b-tit-ava.val_cr_pis
        ttz_ava_base_5.tta_val_cr_cofins = b-tit-ava.val_cr_cofins
        ttz_ava_base_5.tta_val_cr_csll = b-tit-ava.val_cr_csll
        ttz_ava_base_5.tta_val_base_calc_impto = b-tit-ava.val_base_calc_impto
        ttz_ava_base_5.tta_log_retenc_impto_impl = b-tit-ava.log_retenc_impto_impl
        ttz_ava_base_5.tta_cdn_repres = b-tit-ava.cdn_repres
        ttz_ava_base_5.tta_cod_proces_export = b-tit-ava.cod_proces_export
        ttz_ava_base_5.ttv_log_estorn_impto_retid = NO.

    CREATE ttz_ava_rateio.
    ASSIGN
        ttz_ava_rateio.tta_cod_estab = b-tit-ava.cod_estab
        ttz_ava_rateio.tta_num_id_tit_acr = b-tit-ava.num_id_tit_acr
        ttz_ava_rateio.ttv_ind_tip_rat_tit_acr = "Altera��o"
        ttz_ava_rateio.tta_cod_refer = c-ref-ava
        ttz_ava_rateio.tta_num_seq_refer = 1
        ttz_ava_rateio.tta_cod_plano_cta_ctbl = c-plano-ava
        ttz_ava_rateio.tta_cod_cta_ctbl = c-cta-ava
        ttz_ava_rateio.tta_cod_unid_negoc = ""
        ttz_ava_rateio.tta_cod_plano_ccusto = ""
        ttz_ava_rateio.tta_cod_ccusto = ""
        ttz_ava_rateio.tta_cod_tip_fluxo_financ = ""
        ttz_ava_rateio.tta_num_seq_aprop_ctbl_pend_acr = 1
        ttz_ava_rateio.tta_val_aprop_ctbl = p-val-baixa
        ttz_ava_rateio.tta_log_impto_val_agreg = NO
        ttz_ava_rateio.tta_cod_pais = ""
        ttz_ava_rateio.tta_cod_unid_federac = ""
        ttz_ava_rateio.tta_cod_imposto = ""
        ttz_ava_rateio.tta_cod_classif_impto = ""
        ttz_ava_rateio.tta_dat_transacao = p-dat.

    RUN prgfin/acr/acr711zv.py PERSISTENT SET h-ava-api NO-ERROR.
    IF NOT VALID-HANDLE(h-ava-api) THEN DO:
        ASSIGN p-msg = "Nao foi possivel carregar a API acr711zv.".
        RETURN.
    END.

    RUN pi_main_code_integr_acr_alter_tit_acr_novo_15 IN h-ava-api
        (INPUT  15,
         INPUT  TABLE ttz_ava_base_5,
         INPUT  TABLE ttz_ava_rateio,
         INPUT  TABLE ttz_ava_ped_vda,
         INPUT  TABLE ttz_ava_comis_1,
         INPUT  TABLE ttz_ava_cheq,
         INPUT  TABLE ttz_ava_iva,
         INPUT  TABLE ttz_ava_impto_retid_2,
         INPUT  TABLE ttz_ava_cobr_espec_2,
         INPUT  TABLE ttz_ava_rat_desp_rec,
         OUTPUT TABLE ttz_log_erros_ava,
         INPUT  NO,
         INPUT  TABLE ttz_ava_cobr_esp_2_c,
         INPUT  TABLE ttz_params_generic_ava) NO-ERROR.

    IF VALID-HANDLE(h-ava-api) THEN DO:
        DELETE PROCEDURE h-ava-api.
        ASSIGN h-ava-api = ?.
    END.

    IF CAN-FIND(FIRST ttz_log_erros_ava) THEN DO:
        FOR EACH ttz_log_erros_ava NO-LOCK:
            ASSIGN p-msg = p-msg + (IF p-msg = "" THEN "" ELSE " | ")
                         + STRING(ttz_log_erros_ava.ttv_num_mensagem) + " - "
                         + TRIM(ttz_log_erros_ava.ttv_des_msg_erro).
        END.
        ASSIGN p-ok = NO.
    END.
    ELSE ASSIGN p-ok = YES.
    RETURN.
END PROCEDURE.

PROCEDURE pi-sugestao-referencia-ava:
    DEFINE INPUT  PARAMETER p_cod_estab       AS CHARACTER NO-UNDO.
    DEFINE INPUT  PARAMETER p_ind_tip_atualiz AS CHARACTER NO-UNDO.
    DEFINE INPUT  PARAMETER p_dat_refer       AS DATE      NO-UNDO.
    DEFINE OUTPUT PARAMETER p_cod_refer       AS CHARACTER NO-UNDO.
    DEFINE VARIABLE v_des_dat   AS CHARACTER NO-UNDO.
    DEFINE VARIABLE v_num_aux   AS INTEGER   NO-UNDO.
    DEFINE VARIABLE v_num_aux_2 AS INTEGER   NO-UNDO.
    DEFINE VARIABLE v_num_cont  AS INTEGER   NO-UNDO.
    DEFINE VARIABLE v_mes       AS CHARACTER NO-UNDO.
    DEFINE VARIABLE i-cont      AS INTEGER   NO-UNDO.
    DEFINE BUFFER b-ava-base-5 FOR ttz_ava_base_5.
    CASE MONTH(p_dat_refer):
        WHEN 1 THEN ASSIGN v_mes = "A".
        WHEN 2 THEN ASSIGN v_mes = "B".
        WHEN 3 THEN ASSIGN v_mes = "C".
        WHEN 4 THEN ASSIGN v_mes = "D".
        WHEN 5 THEN ASSIGN v_mes = "E".
        WHEN 6 THEN ASSIGN v_mes = "F".
        WHEN 7 THEN ASSIGN v_mes = "G".
        WHEN 8 THEN ASSIGN v_mes = "H".
        WHEN 9 THEN ASSIGN v_mes = "I".
        WHEN 10 THEN ASSIGN v_mes = "J".
        WHEN 11 THEN ASSIGN v_mes = "K".
        WHEN 12 THEN ASSIGN v_mes = "L".
    END CASE.
    DO i-cont = 65 TO 90:
        ASSIGN p_cod_refer = v_mes + STRING(DAY(p_dat_refer),"99")
                           + REPLACE(STRING(TIME,"hh:mm:ss"),":","") + CHR(i-cont).
        IF NOT CAN-FIND(FIRST movto_tit_acr USE-INDEX mvtttcr_refer
                        WHERE movto_tit_acr.cod_estab = p_cod_estab
                          AND movto_tit_acr.cod_refer = p_cod_refer)
           AND NOT CAN-FIND(FIRST b-ava-base-5 WHERE b-ava-base-5.tta_cod_refer = p_cod_refer) THEN
            RETURN "OK".
    END.
    ASSIGN v_des_dat   = STRING(p_dat_refer,"99999999")
           p_cod_refer = SUBSTRING(v_des_dat,7,2) + SUBSTRING(v_des_dat,3,2)
                       + SUBSTRING(v_des_dat,1,2) + SUBSTRING(p_ind_tip_atualiz,1,1)
           v_num_aux_2 = INTEGER(THIS-PROCEDURE:HANDLE).
    DO v_num_cont = 1 TO 3:
        ASSIGN v_num_aux   = (RANDOM(0,v_num_aux_2) MOD 26) + 97
               p_cod_refer = p_cod_refer + CHR(v_num_aux).
    END.
    RETURN "OK".
END PROCEDURE.

PROCEDURE pi-processar-lote:
    DEFINE INPUT  PARAMETER p-ids     AS JsonArray NO-UNDO.
    DEFINE INPUT  PARAMETER p-usuario AS CHARACTER NO-UNDO.
    DEFINE OUTPUT PARAMETER p-ok      AS LOGICAL   NO-UNDO.
    DEFINE OUTPUT PARAMETER p-msg     AS CHARACTER NO-UNDO.

    DEFINE VARIABLE h-acr-lote    AS HANDLE    NO-UNDO.
    DEFINE VARIABLE c-ref-lote    AS CHARACTER NO-UNDO.
    DEFINE VARIABLE c-ref-geral   AS CHARACTER NO-UNDO.
    DEFINE VARIABLE c-ddmmaa      AS CHARACTER NO-UNDO.
    DEFINE VARIABLE c-rand        AS CHARACTER NO-UNDO.
    DEFINE VARIABLE l-ref-uni     AS LOGICAL   NO-UNDO.
    DEFINE VARIABLE i-r           AS INTEGER   NO-UNDO.
    DEFINE VARIABLE i-tent        AS INTEGER   NO-UNDO.
    DEFINE VARIABLE i-ix          AS INTEGER   NO-UNDO.
    DEFINE VARIABLE c-id          AS CHARACTER NO-UNDO.
    DEFINE VARIABLE i-seq-lote    AS INTEGER   NO-UNDO INITIAL 0.
    DEFINE VARIABLE i-qtd         AS INTEGER   NO-UNDO INITIAL 0.
    DEFINE VARIABLE i-ok          AS INTEGER   NO-UNDO INITIAL 0.
    DEFINE VARIABLE i-nok         AS INTEGER   NO-UNDO INITIAL 0.
    DEFINE VARIABLE c-erro-lote   AS CHARACTER NO-UNDO.
    DEFINE VARIABLE c-msg-tit     AS CHARACTER NO-UNDO.
    DEFINE VARIABLE l-lote-rejeit AS LOGICAL   NO-UNDO.
    DEFINE VARIABLE l-tit-erro    AS LOGICAL   NO-UNDO.
    DEFINE VARIABLE c-refer-estab AS CHARACTER NO-UNDO.
    DEFINE VARIABLE l-ok-ac       AS LOGICAL   NO-UNDO.
    DEFINE VARIABLE c-msg-ac      AS CHARACTER NO-UNDO.
    DEFINE VARIABLE de-devido     AS DECIMAL   NO-UNDO.
    DEFINE VARIABLE de-pago       AS DECIMAL   NO-UNDO.
    DEFINE VARIABLE c-cart-liq    AS CHARACTER NO-UNDO.
    DEFINE VARIABLE c-erro-cart   AS CHARACTER NO-UNDO.
    DEFINE VARIABLE d-dat-mov     AS DATE      NO-UNDO.
    DEFINE BUFFER b-imp-lote FOR es-tit-acr-importa-tit.
    DEFINE BUFFER b-tit-lote FOR tit_acr.
    DEFINE BUFFER b-imp-mrc  FOR es-tit-acr-importa-tit.
    DEFINE BUFFER b-log-tit  FOR tt_log_erros_import_liquidac.

    ASSIGN p-ok = NO p-msg = "".

    
    RUN pi-carteira-liquidacao (OUTPUT c-cart-liq, OUTPUT c-erro-cart).
    IF c-erro-cart <> "" THEN DO: ASSIGN p-ok = NO p-msg = c-erro-cart. RETURN. END.

    
    EMPTY TEMP-TABLE tt-item-sel.
    IF VALID-OBJECT(p-ids) THEN
    DO i-ix = 1 TO p-ids:Length:
        ASSIGN c-id = p-ids:GetCharacter(i-ix) NO-ERROR.
        IF c-id = "" OR c-id = ? THEN NEXT.
        CREATE tt-item-sel.
        ASSIGN tt-item-sel.estab   = (IF NUM-ENTRIES(c-id,"|") >= 2 THEN ENTRY(2,c-id,"|") ELSE "")
               tt-item-sel.espec   = (IF NUM-ENTRIES(c-id,"|") >= 3 THEN ENTRY(3,c-id,"|") ELSE "")
               tt-item-sel.serie   = (IF NUM-ENTRIES(c-id,"|") >= 4 THEN ENTRY(4,c-id,"|") ELSE "")
               tt-item-sel.titulo  = (IF NUM-ENTRIES(c-id,"|") >= 5 THEN ENTRY(5,c-id,"|") ELSE "")
               tt-item-sel.parcela = (IF NUM-ENTRIES(c-id,"|") >= 6 THEN ENTRY(6,c-id,"|") ELSE "")
               tt-item-sel.val     = (IF NUM-ENTRIES(c-id,"|") >= 7 THEN
                   DECIMAL(IF SESSION:NUMERIC-DECIMAL-POINT = "," THEN REPLACE(ENTRY(7,c-id,"|"), ".", ",")
                           ELSE ENTRY(7,c-id,"|")) ELSE 0) NO-ERROR.
    END.
    IF NOT CAN-FIND(FIRST tt-item-sel) THEN DO:
        ASSIGN p-ok = NO p-msg = "Nenhum titulo selecionado para o lote.".
        RETURN.
    END.

    EMPTY TEMP-TABLE tt_integr_acr_liquidac_lote.
    EMPTY TEMP-TABLE tt_integr_acr_liq_item_lote_3.
    EMPTY TEMP-TABLE tt_integr_acr_abat_antecip.
    EMPTY TEMP-TABLE tt_integr_acr_abat_prev.
    EMPTY TEMP-TABLE tt_integr_acr_cheq.
    EMPTY TEMP-TABLE tt_integr_acr_liquidac_impto_2.
    EMPTY TEMP-TABLE tt_integr_acr_rel_pend_cheq.
    EMPTY TEMP-TABLE tt_integr_acr_liq_aprop_ctbl.
    EMPTY TEMP-TABLE tt_integr_acr_liq_desp_rec.
    EMPTY TEMP-TABLE tt_integr_acr_aprop_liq_antec.
    EMPTY TEMP-TABLE tt_log_erros_import_liquidac.
    EMPTY TEMP-TABLE tt_integr_cambio_ems5.
    EMPTY TEMP-TABLE tt_params_generic_api.

    
    FOR EACH tt-item-sel BY tt-item-sel.estab:
        FIND FIRST b-imp-lote NO-LOCK
            WHERE b-imp-lote.cod_estab        = tt-item-sel.estab
              AND b-imp-lote.cod_espec_docto  = tt-item-sel.espec
              AND b-imp-lote.cod_ser_docto    = tt-item-sel.serie
              AND b-imp-lote.cod_tit_acr      = tt-item-sel.titulo
              AND b-imp-lote.cod_parcela      = tt-item-sel.parcela
              AND b-imp-lote.val_recebido     = tt-item-sel.val
              AND b-imp-lote.ind_sit_importacao = "Pendente" NO-ERROR.
        IF NOT AVAILABLE b-imp-lote OR b-imp-lote.cod_tit_acr = "" THEN NEXT.
        
        IF NOT (NUM-ENTRIES(b-imp-lote.cod_arq_origem,"|") >= 4
                AND ENTRY(4,b-imp-lote.cod_arq_origem,"|") BEGINS "Lote:") THEN NEXT.

        FIND FIRST b-tit-lote NO-LOCK
            WHERE b-tit-lote.cod_estab       = b-imp-lote.cod_estab
              AND b-tit-lote.cod_espec_docto = b-imp-lote.cod_espec_docto
              AND b-tit-lote.cod_ser_docto   = b-imp-lote.cod_ser_docto
              AND b-tit-lote.cod_tit_acr     = b-imp-lote.cod_tit_acr
              AND b-tit-lote.cod_parcela     = b-imp-lote.cod_parcela NO-ERROR.
        IF NOT AVAILABLE b-tit-lote THEN NEXT.

        
        ASSIGN
            de-devido = b-tit-lote.val_sdo_tit_acr + b-tit-lote.val_juros + b-tit-lote.val_multa_tit_acr
            de-pago   = b-imp-lote.val_recebido + b-imp-lote.val_juros + b-imp-lote.val_multa
            d-dat-mov = (IF b-imp-lote.dat_geracao <> ? THEN b-imp-lote.dat_geracao ELSE TODAY).
        IF b-imp-lote.val_recebido = 0 AND b-imp-lote.val_juros = 0 AND b-imp-lote.val_multa = 0 THEN
            de-pago = de-devido.
        IF de-pago < de-devido THEN DO:
            RUN pi-acerto-valor-menor (INPUT  ROWID(b-tit-lote),
                                       INPUT  b-imp-lote.val_recebido,
                                       INPUT  p-usuario,
                                       INPUT  d-dat-mov,
                                       OUTPUT l-ok-ac, OUTPUT c-msg-ac).
            FIND FIRST b-imp-mrc EXCLUSIVE-LOCK WHERE ROWID(b-imp-mrc) = ROWID(b-imp-lote) NO-ERROR.
            IF AVAILABLE b-imp-mrc THEN DO:
                IF l-ok-ac THEN
                    ASSIGN b-imp-mrc.ind_sit_importacao = "Importado"
                           b-imp-mrc.des_mensagem_erro  = "Acerto de valor a menor (lote)"
                           i-ok = i-ok + 1.
                ELSE
                    ASSIGN b-imp-mrc.ind_sit_importacao = "Erro"
                           b-imp-mrc.des_mensagem_erro  = c-msg-ac
                           i-nok = i-nok + 1.
                ASSIGN b-imp-mrc.dat_processamento = TODAY
                       b-imp-mrc.hra_processamento = STRING(TIME, "HH:MM:SS").
                RELEASE b-imp-mrc NO-ERROR.
            END.
            NEXT.
        END.

        
        FIND FIRST tt_integr_acr_liquidac_lote EXCLUSIVE-LOCK
            WHERE tt_integr_acr_liquidac_lote.tta_cod_estab_refer = b-tit-lote.cod_estab NO-ERROR.
        IF NOT AVAILABLE tt_integr_acr_liquidac_lote THEN DO:
            ASSIGN c-ddmmaa = STRING(DAY(TODAY),"99") + STRING(MONTH(TODAY),"99")
                            + SUBSTRING(STRING(YEAR(TODAY),"9999"),3,2)
                   l-ref-uni = NO i-tent = 0.
            REPEAT WHILE l-ref-uni = NO AND i-tent < 300:
                ASSIGN i-tent = i-tent + 1 c-rand = "".
                DO i-r = 1 TO 4:
                    ASSIGN c-rand = c-rand + CHR((RANDOM(0, 999999) MOD 26) + 97).
                END.
                ASSIGN c-ref-lote = c-ddmmaa + c-rand.
                IF NOT CAN-FIND(FIRST lote_liquidac_acr NO-LOCK
                        WHERE lote_liquidac_acr.cod_estab_refer = b-tit-lote.cod_estab
                          AND lote_liquidac_acr.cod_refer       = c-ref-lote)
                   AND INDEX(c-ref-geral, " " + c-ref-lote + " ") = 0 THEN
                    ASSIGN l-ref-uni = YES.
            END.
            ASSIGN c-ref-geral = c-ref-geral + " " + c-ref-lote + " ".
            FIND FIRST estabelecimento NO-LOCK WHERE estabelecimento.cod_estab = b-tit-lote.cod_estab NO-ERROR.
            CREATE tt_integr_acr_liquidac_lote.
            ASSIGN
                tt_integr_acr_liquidac_lote.tta_cod_empresa             = (IF AVAILABLE estabelecimento THEN estabelecimento.cod_empresa ELSE b-tit-lote.cod_empresa)
                tt_integr_acr_liquidac_lote.tta_cod_estab_refer         = b-tit-lote.cod_estab
                tt_integr_acr_liquidac_lote.tta_cod_refer               = c-ref-lote
                tt_integr_acr_liquidac_lote.tta_cod_usuario             = p-usuario
                tt_integr_acr_liquidac_lote.tta_dat_gerac_lote_liquidac = d-dat-mov
                tt_integr_acr_liquidac_lote.tta_dat_transacao           = d-dat-mov
                tt_integr_acr_liquidac_lote.tta_ind_tip_liquidac_acr    = 'lote'
                tt_integr_acr_liquidac_lote.ttv_log_atualiz_refer       = YES
                tt_integr_acr_liquidac_lote.ttv_rec_lote_liquidac_acr   = RECID(tt_integr_acr_liquidac_lote)
                tt_integr_acr_liquidac_lote.ttv_log_gera_lote_parcial   = YES.
        END.

        ASSIGN i-seq-lote = i-seq-lote + 10.
        CREATE tt_integr_acr_liq_item_lote_3.
        ASSIGN
            tt_integr_acr_liq_item_lote_3.tta_cod_empresa                = b-tit-lote.cod_empresa
            tt_integr_acr_liq_item_lote_3.tta_cod_estab                  = b-tit-lote.cod_estab
            tt_integr_acr_liq_item_lote_3.tta_cod_espec_docto            = b-tit-lote.cod_espec_docto
            tt_integr_acr_liq_item_lote_3.tta_cod_ser_docto              = b-tit-lote.cod_ser_docto
            tt_integr_acr_liq_item_lote_3.tta_num_seq_refer              = i-seq-lote
            tt_integr_acr_liq_item_lote_3.tta_cod_tit_acr                = b-tit-lote.cod_tit_acr
            tt_integr_acr_liq_item_lote_3.tta_cod_parcela                = b-tit-lote.cod_parcela
            tt_integr_acr_liq_item_lote_3.tta_cdn_cliente                = b-tit-lote.cdn_cliente
            tt_integr_acr_liq_item_lote_3.tta_cod_portador               = (IF b-imp-lote.cod_portador <> "" THEN b-imp-lote.cod_portador ELSE b-tit-lote.cod_portador)
            tt_integr_acr_liq_item_lote_3.tta_cod_cart_bcia              = (IF b-imp-lote.cod_cart_bcia <> "" THEN b-imp-lote.cod_cart_bcia ELSE c-cart-liq)
            tt_integr_acr_liq_item_lote_3.tta_cod_indic_econ             = b-tit-lote.cod_indic_econ
            tt_integr_acr_liq_item_lote_3.tta_dat_cr_liquidac_tit_acr    = d-dat-mov
            tt_integr_acr_liq_item_lote_3.tta_dat_cr_liquidac_calc       = d-dat-mov
            tt_integr_acr_liq_item_lote_3.tta_dat_liquidac_tit_acr       = d-dat-mov
            tt_integr_acr_liq_item_lote_3.tta_val_liquidac_tit_acr       = b-tit-lote.val_sdo_tit_acr  
            tt_integr_acr_liq_item_lote_3.tta_val_desc_tit_acr           = b-imp-lote.val_desconto
            tt_integr_acr_liq_item_lote_3.tta_val_abat_tit_acr           = b-imp-lote.val_abatimento
            tt_integr_acr_liq_item_lote_3.tta_val_despes_bcia            = 0
            tt_integr_acr_liq_item_lote_3.tta_val_multa_tit_acr          = b-tit-lote.val_multa_tit_acr
            tt_integr_acr_liq_item_lote_3.tta_val_juros                  = b-tit-lote.val_juros
            tt_integr_acr_liq_item_lote_3.tta_val_cm_tit_acr             = b-tit-lote.val_cm_tit_acr
            tt_integr_acr_liq_item_lote_3.tta_ind_tip_item_liquidac_acr  = 'pagamento'
            tt_integr_acr_liq_item_lote_3.ttv_rec_item_lote_liquidac_acr = RECID(b-tit-lote)
            tt_integr_acr_liq_item_lote_3.ttv_rec_lote_liquidac_acr      = RECID(tt_integr_acr_liquidac_lote)
            tt_integr_acr_liq_item_lote_3.tta_val_cotac_indic_econ       = 1
            tt_integr_acr_liq_item_lote_3.tta_des_text_histor            = "Liquidacao por lote (CONS-PLANILHAS)".

        ASSIGN i-qtd = i-qtd + 1.
    END.

    IF i-qtd = 0 AND i-ok = 0 AND i-nok = 0 THEN DO:
        ASSIGN p-ok = NO
               p-msg = "Nenhum titulo pendente de importacao por lote entre os selecionados.".
        RETURN.
    END.

    IF i-qtd > 0 THEN DO:

    
    RUN prgfin/acr/acr901zf.p PERSISTENT SET h-acr-lote NO-ERROR.
    IF NOT VALID-HANDLE(h-acr-lote) THEN DO:
        ASSIGN p-ok = NO p-msg = "Nao foi possivel carregar a API de liquidacao (acr901zf).".
        RETURN.
    END.
    RUN pi_main_code_api_integr_acr_liquidac_6 IN h-acr-lote
        (INPUT  1,
         INPUT  TABLE tt_integr_acr_liquidac_lote,
         INPUT  TABLE tt_integr_acr_liq_item_lote_3,
         INPUT  TABLE tt_integr_acr_abat_antecip,
         INPUT  TABLE tt_integr_acr_abat_prev,
         INPUT  TABLE tt_integr_acr_cheq,
         INPUT  TABLE tt_integr_acr_liquidac_impto_2,
         INPUT  TABLE tt_integr_acr_rel_pend_cheq,
         INPUT  TABLE tt_integr_acr_liq_aprop_ctbl,
         INPUT  TABLE tt_integr_acr_liq_desp_rec,
         INPUT  TABLE tt_integr_acr_aprop_liq_antec,
         INPUT  "EMS2",
         OUTPUT TABLE tt_log_erros_import_liquidac,
         INPUT  TABLE tt_integr_cambio_ems5,
         INPUT  TABLE tt_params_generic_api).
    IF VALID-HANDLE(h-acr-lote) THEN DO:
        DELETE PROCEDURE h-acr-lote.
        ASSIGN h-acr-lote = ?.
    END.

    
    ASSIGN c-erro-lote = "" l-lote-rejeit = NO.
    FOR EACH tt_log_erros_import_liquidac NO-LOCK:
        IF tt_log_erros_import_liquidac.tta_cod_tit_acr = "" OR tt_log_erros_import_liquidac.tta_cod_tit_acr = ? THEN
            ASSIGN l-lote-rejeit = YES
                   c-erro-lote   = c-erro-lote + (IF c-erro-lote = "" THEN "" ELSE " | ")
                                 + STRING(tt_log_erros_import_liquidac.ttv_num_erro_log) + " - "
                                 + TRIM(tt_log_erros_import_liquidac.ttv_des_msg_erro).
    END.

    
    FOR EACH tt-item-sel:
        FIND FIRST b-imp-mrc EXCLUSIVE-LOCK
            WHERE b-imp-mrc.cod_estab        = tt-item-sel.estab
              AND b-imp-mrc.cod_espec_docto  = tt-item-sel.espec
              AND b-imp-mrc.cod_ser_docto    = tt-item-sel.serie
              AND b-imp-mrc.cod_tit_acr      = tt-item-sel.titulo
              AND b-imp-mrc.cod_parcela      = tt-item-sel.parcela
              AND b-imp-mrc.val_recebido     = tt-item-sel.val
              AND b-imp-mrc.ind_sit_importacao = "Pendente" NO-ERROR.
        IF NOT AVAILABLE b-imp-mrc OR b-imp-mrc.cod_tit_acr = "" THEN NEXT.
        IF NOT (NUM-ENTRIES(b-imp-mrc.cod_arq_origem,"|") >= 4
                AND ENTRY(4,b-imp-mrc.cod_arq_origem,"|") BEGINS "Lote:") THEN NEXT.

        ASSIGN c-refer-estab = "".
        FIND FIRST tt_integr_acr_liquidac_lote NO-LOCK
            WHERE tt_integr_acr_liquidac_lote.tta_cod_estab_refer = b-imp-mrc.cod_estab NO-ERROR.
        IF AVAILABLE tt_integr_acr_liquidac_lote THEN
            ASSIGN c-refer-estab = tt_integr_acr_liquidac_lote.tta_cod_refer.

        ASSIGN l-tit-erro = l-lote-rejeit c-msg-tit = c-erro-lote.
        IF NOT l-tit-erro THEN
        FOR FIRST b-log-tit NO-LOCK
            WHERE b-log-tit.tta_cod_estab       = b-imp-mrc.cod_estab
              AND b-log-tit.tta_cod_espec_docto = b-imp-mrc.cod_espec_docto
              AND b-log-tit.tta_cod_ser_docto   = b-imp-mrc.cod_ser_docto
              AND b-log-tit.tta_cod_tit_acr     = b-imp-mrc.cod_tit_acr:
            ASSIGN l-tit-erro = YES
                   c-msg-tit  = STRING(b-log-tit.ttv_num_erro_log) + " - "
                              + TRIM(b-log-tit.ttv_des_msg_erro).
        END.

        IF l-tit-erro THEN
            ASSIGN b-imp-mrc.ind_sit_importacao = "Erro"
                   b-imp-mrc.des_mensagem_erro  = c-msg-tit
                   i-nok = i-nok + 1.
        ELSE DO:
            
            ASSIGN ENTRY(4, b-imp-mrc.cod_arq_origem, "|") = "Lote:" + c-refer-estab NO-ERROR.
            ASSIGN b-imp-mrc.ind_sit_importacao = "Importado"
                   b-imp-mrc.des_mensagem_erro  = "Liquidado no lote " + c-refer-estab
                   i-ok = i-ok + 1.
        END.
        ASSIGN b-imp-mrc.dat_processamento = TODAY
               b-imp-mrc.hra_processamento = STRING(TIME, "HH:MM:SS").
    END.

    END.  

    ASSIGN p-ok  = (i-nok = 0)
           p-msg = STRING(i-ok) + " titulo(s) processado(s) por lote"
                 + (IF i-nok > 0 THEN ", " + STRING(i-nok) + " com erro" ELSE "")
                 + (IF i-nok > 0 AND c-erro-lote <> "" THEN " | " + c-erro-lote ELSE "") + ".".
    RETURN.
END PROCEDURE.

/******************************************************************************
** Programa...: TW_MOVTO_TIT_ACR.P
** Data.......: Dezembro de 2020
** Analista...: Josias Afelis - Mir
** Objetivo...: Trigger da movto_tit_acr - Projeto TI-305
** Versao.....: 5.06.00.002
*******************************************************************************/

/*definicao dos parametros*/
DEFINE PARAMETER BUFFER new_tit_acr FOR movto_tit_acr.
DEFINE PARAMETER BUFFER old_tit_acr FOR movto_tit_acr.

/*definicao de buffers*/
DEFINE BUFFER b_histor_clien FOR histor_clien.
DEFINE BUFFER bf-ext-emitente FOR ext-emitente. 
DEFINE BUFFER bf-es-ord-serv  FOR es-ord-servico.
DEFINE BUFFER b-es-movto-ordem-servico FOR es-movto-ordem-servico.
DEFINE BUFFER bbf-es-movto-ordem-servico FOR es-movto-ordem-servico.
DEFINE NEW GLOBAL SHARED VAR c-seg-usuario AS CHAR NO-UNDO.
DEFINE NEW GLOBAL SHARED VAR v_cod_usuar_corren AS CHAR NO-UNDO.
DEF VAR l-cancela AS LOGICAL NO-UNDO.
DEF VAR d-total   AS DECIMAL NO-UNDO.
DEF VAR i-qtde    AS INTEGER NO-UNDO.
DEF VAR h-acomp   AS HANDLE  NO-UNDO.
DEFINE VARIABLE l-verifica AS LOGICAL NO-UNDO.

DEF VAR c-nr-pedcli  LIKE ped-venda.nr-pedcli  NO-UNDO.
DEF VAR c-nome-abrev LIKE ped-venda.nome-abrev NO-UNDO.

DEFINE TEMP-TABLE tt-titulos 
    FIELD composicao AS CHAR
    FIELD dt-vencto  AS DATE
    FIELD vlr-orig   AS DEC
    FIELD cod-emitente AS INTEGER.
DEFINE TEMP-TABLE tt-quitados LIKE tt-titulos.

/*definicao de variaveis*/
{pdp\pd9999.i2}

{utp\ut-glob.i}
{utp/utapi019.i2}
{include/i-epc200.i cdapi013xxx}
{method/dbotterr.i}

DEFINE VARIABLE h-objeto               AS HANDLE   NO-UNDO.
DEFINE VARIABLE i-empresa              LIKE param-global.empresa-prin             NO-UNDO.
DEFINE VARIABLE de-lim-credito         AS DECIMAL FORMAT "zzz,zzz,zzz,zzz,zz9.99" NO-UNDO.
DEFINE VARIABLE l-considera-replica-pd AS LOG                                     NO-UNDO.  /* usado na cdapi013.i */
DEFINE VARIABLE i-ind-aval             LIKE emitente.ind-aval    NO-UNDO.
DEFINE VARIABLE perSemConsumo          AS INTEGER NO-UNDO.

DEFINE VARIABLE de-perc-lim            AS DECIMAL NO-UNDO.
DEFINE VARIABLE de-lim-aux             AS DECIMAL NO-UNDO.
DEFINE VARIABLE de-vl-pedido           LIKE ped-venda.vl-liq-abe NO-UNDO.
DEFINE VARIABLE de-vl-descto-pa        LIKE ped-venda.vl-liq-abe NO-UNDO.

{cdp/cdapi013.i}  /* definic�o de TTs para cr�dito     */
{cdp/cdapi013.i1} /* verifica��o de cr�dito do cliente */


/* MESSAGE "TRIGGER"                             */
/*     view-as ALERT-BOX INFORMATION BUTTONS OK. */


IF  NEW new_tit_acr AND
    new_tit_acr.ind_trans_acr = "Liquidacao Perda Dedutivel" THEN DO:

    IF  CAN-FIND (FIRST ext-emitente
                  WHERE ext-emitente.cod-emitente  = new_tit_acr.cdn_cliente
                    AND LOOKUP(ext-emitente.classificacao,"VIP,OURO,LICITACAO") > 0) THEN
        RETURN 'OK':U.

    FIND emitente NO-LOCK WHERE emitente.cod-emitente = new_tit_acr.cdn_cliente NO-ERROR.
    FIND tit_acr OF new_tit_acr NO-LOCK NO-ERROR.
    
    IF  CAN-FIND (FIRST ped-ent NO-LOCK
                  WHERE ped-ent.nome-abrev = emitente.nome-abrev
                    AND ped-ent.dt-entrega > tit_acr.dat_vencto_tit_acr
                    AND ped-ent.cod-sit-ent = 3) THEN
        RETURN 'OK':U.

    FIND LAST nota-fiscal NO-LOCK
        WHERE nota-fiscal.cod-emitente = emitente.cod-emitente
          AND nota-fiscal.dt-emis > tit_acr.dat_vencto_tit_acr NO-ERROR.
    IF  AVAIL nota-fiscal THEN
        RETURN 'OK':U.
    
    //Tela 4 - CM0102 marcar clientes como suspensos
    IF  emitente.ind-cre-cli <> 4 THEN DO:
        FIND CURRENT emitente EXCLUSIVE-LOCK NO-ERROR.
        ASSIGN emitente.ind-cre-cli = 4. //suspenso
        FIND CURRENT emitente NO-LOCK NO-ERROR.

        //Tela 5 - Desenvolvimento de Trigger para grava��o de hist�rico na tela padr�o de consulta do cliente (ACR205AA).
        //texto provis�rio "Cliente suspenso devido � t�tulo indicado para PDD"
        FOR FIRST emscad.cliente NO-LOCK
            WHERE cliente.cdn_cliente = new_tit_acr.cdn_cliente:

            CREATE histor_clien. 
            ASSIGN histor_clien.cod_empresa            = cliente.cod_empresa
                   histor_clien.cdn_cliente            = cliente.cdn_cliente
                   histor_clien.des_abrev_histor_clien = "Cliente Suspenso"
                   histor_clien.des_histor_clien       = "Cliente suspenso devido � t�tulo indicado para PDD"
                   histor_clien.cod_usuario            = v_cod_usuar_corren
                   histor_clien.dat_gerac_histor       = TODAY
                   histor_clien.hra_gerac_histor       = STRING(TIME,"hh:mm:ss").
            
            FIND LAST b_histor_clien NO-LOCK
                WHERE b_histor_clien.cod_empresa = histor_clien.cod_empresa
                  AND b_histor_clien.cdn_cliente = histor_clien.cdn_cliente NO-ERROR.
            IF  AVAIL b_histor_clien THEN
                ASSIGN histor_clien.num_seq_histor_clien = b_histor_clien.num_seq_histor_clien + 1.
            ELSE
                ASSIGN histor_clien.num_seq_histor_clien = 1.

        END.

    END.

    //Tela 6 - cancelar todas as programa��es em aberto para este cliente
    /*
    FOR EACH es-ocorrencia EXCLUSIVE-LOCK
       WHERE es-ocorrencia.cod-emitente = new_tit_acr.cdn_cliente
         AND es-ocorrencia.cod-status  <> 5
         AND es-ocorrencia.cod-status  <> 7:
    
        /* Cria��o do historico */
        RUN pdp/espd0013i.p (INPUT es-ocorrencia.nr-ocorrencia,
                             INPUT 10, //cancelada
                             INPUT "Cliente suspenso devido � t�tulo indicado para PDD") NO-ERROR.
        
        ASSIGN es-ocorrencia.cod-status = 7. //cancelada
    END.*/
    //regra espd0027
    FOR EACH ped-venda EXCLUSIVE-LOCK 
       WHERE ped-venda.nome-abrev  = emitente.nome-abrev
         AND ped-venda.cod-sit-ped < 3  /*Aberto ou Atendido Parcial*/                       
         AND ped-venda.esp-ped     = 2: /*Prog. Entrega*/        

        ASSIGN ped-venda.cod-sit-ped   = 6 //cancelado
               ped-venda.dt-cancel     = TODAY
               ped-venda.desc-cancela  = "Cliente Suspenso PDD"
               ped-venda.user-canc     = v_cod_usuar_corren
               ped-venda.dt-usercan    = TODAY.
               

        FOR EACH ped-item OF ped-venda EXCLUSIVE-LOCK:
            ASSIGN ped-item.cod-sit-item = 6 //cancelado
                   ped-item.dt-canseq    = TODAY
                   ped-item.desc-cancela = ped-venda.desc-cancela
                   ped-item.user-canc    = v_cod_usuar_corren
                   ped-item.dt-usercan   = TODAY.
        END.

        FOR EACH ped-ent OF ped-venda EXCLUSIVE-LOCK
            WHERE ped-ent.dt-entrega >= TODAY:
            ASSIGN ped-ent.cod-sit-ent = 6 //cancelado
                   ped-ent.user-canc    = v_cod_usuar_corren
                   ped-ent.dt-usercan   = today
                   ped-ent.dt-canent    = today
                   ped-ent.desc-cancela = ped-venda.desc-cancela.

        END.
    END.
    
    //Tela 7 - altera��o da classifica��o do cliente dispon�vel na tela ESCD0043.
    FOR EACH ext-emitente EXCLUSIVE-LOCK
       WHERE ext-emitente.cod-emitente = new_tit_acr.cdn_cliente:

        ASSIGN ext-emitente.classificacao      = "PDD"
               ext-emitente.classificacao-fixa = YES.
    END.
END.




//20/06/2026 - Lucas - adicionado para criar a tabela tempor�ria

DEFINE VARIABLE cRaizCnpj AS CHARACTER NO-UNDO.
ASSIGN cRaizCnpj = ''.



IF  NEW new_tit_acr AND
    new_tit_acr.ind_trans_acr = "Implanta��o" THEN DO:
    
/*     MESSAGE " entrou na trigger "                 */
/*         view-as ALERT-BOX INFORMATION BUTTONS OK. */
    
    FIND FIRST tit_acr OF new_tit_acr NO-LOCK NO-ERROR.
    
    IF AVAIL tit_acr AND tit_acr.val_sdo_tit_acr > 0 AND tit_acr.cod_ser_docto = 'DM' THEN DO:
        FIND FIRST emitente WHERE emitente.cod-emitente = tit_acr.cdn_cliente NO-LOCK NO-ERROR.
        IF  AVAIL emitente THEN
        DO:
        
/*         MESSAGE " entrrou na grava��o do emit"        */
/*             view-as ALERT-BOX INFORMATION BUTTONS OK. */
        

            ASSIGN cRaizCnpj    = SUBSTRING(emitente.cgc, 1, 8).
            
            FIND FIRST es_tit_acr_abrt WHERE 
                       es_tit_acr_abrt.cod_estab       = tit_acr.cod_estab         AND
                       es_tit_acr_abrt.cod_espec_docto = tit_acr.cod_espec_docto   AND
                       es_tit_acr_abrt.cod_ser_docto   = tit_acr.cod_ser_docto     AND
                       es_tit_acr_abrt.cod_tit_acr     = tit_acr.cod_tit_acr       AND
                       es_tit_acr_abrt.cod_parcela     = tit_acr.cod_parcela       AND
                       es_tit_acr_abrt.val_pendente    = tit_acr.val_sdo_tit_acr   EXCLUSIVE-LOCK NO-ERROR.        
            
            IF NOT AVAIL es_tit_acr_abrt THEN
            DO:
                CREATE es_tit_acr_abrt.
            END.
            
/*             MESSAGE "criou a tabela es_tit_acr_abrt"  SKIP */
/*             es_tit_acr_abrt.cgc                       SKIP */
/*             es_tit_acr_abrt.cgc-8char                 SKIP */
/*             es_tit_acr_abrt.cod_estab                 SKIP */
/*             es_tit_acr_abrt.cod_espec_docto           SKIP */
/*             es_tit_acr_abrt.cod_ser_docto             SKIP */
/*             es_tit_acr_abrt.cod_tit_acr               SKIP */
/*             es_tit_acr_abrt.cod_parcela               SKIP */
/*             es_tit_acr_abrt.val_pendente              SKIP */
/*                 view-as ALERT-BOX INFORMATION BUTTONS OK.  */
            
            ASSIGN 
            es_tit_acr_abrt.cgc             = emitente.cgc
            es_tit_acr_abrt.cgc-8char       = cRaizCnpj
            es_tit_acr_abrt.cod_estab       = tit_acr.cod_estab
            es_tit_acr_abrt.cod_espec_docto = tit_acr.cod_espec_docto
            es_tit_acr_abrt.cod_ser_docto   = tit_acr.cod_ser_docto
            es_tit_acr_abrt.cod_tit_acr     = tit_acr.cod_tit_acr
            es_tit_acr_abrt.cod_parcela     = tit_acr.cod_parcela
            es_tit_acr_abrt.val_pendente    = tit_acr.val_sdo_tit_acr. 

        END.
    END.    
END.






IF NEW  new_tit_acr THEN
DO:
    CASE new_tit_acr.ind_trans_acr_abrev:
        WHEN "LIQ"  OR
        WHEN "LQEC" OR
        WHEN "DEV"  OR
        WHEN "AVCR" OR
        WHEN "AVMN" OR
        WHEN "LQTE" OR
        WHEN "LQRN"
        THEN DO:
            IF   new_tit_acr.val_sdo_tit_acr = 0 THEN
            DO:
                 RUN pi-cancela-os (INPUT new_tit_acr.cdn_cliente).
            END.
            
            IF CAN-FIND(FIRST es-revendedor-glp 
                        WHERE es-revendedor-glp.cod-emitente = new_tit_acr.cdn_cliente) THEN
            DO:     
                FIND FIRST ext-emitente NO-LOCK
                     WHERE ext-emitente.cod-emitente = new_tit_acr.cdn_cliente NO-ERROR.
                ASSIGN l-verifica = NO.
                FOR EACH emscad.estabelecimento NO-LOCK:
/*                     IF ext-emitente.cod-grupo-matriz = 1351 THEN */
/*                     DO:                                          */
                        IF CAN-FIND(FIRST tit_acr USE-INDEX titacr_espec_vencto
                                    WHERE tit_acr.cod_estab = emscad.estabelecimento.cod_estab
                                      AND tit_acr.cod_espec_docto = "DM"
                                      AND tit_acr.log_sdo_tit_acr
                                      AND tit_acr.dat_vencto_tit_acr > TODAY - 365
                                      AND tit_acr.dat_vencto_tit_acr < TODAY
                                      AND tit_acr.cdn_cliente = ext-emitente.cod-emitente
                                      AND tit_acr.num_id_tit_acr <> new_tit_acr.num_id_tit_acr) THEN
                            ASSIGN l-verifica = YES.
/*                     END.                                                                                 */
/*                     ELSE                                                                                 */
/*                     DO:                                                                                  */
/*                         FOR EACH bf-ext-emitente NO-LOCK                                                 */
/*                            WHERE bf-ext-emitente.cod-grupo-matriz = ext-emitente.cod-grupo-matriz:       */
/*                             IF CAN-FIND(FIRST tit_acr USE-INDEX titacr_espec_vencto                      */
/*                                         WHERE tit_acr.cod_estab = emscad.estabelecimento.cod_estab       */
/*                                           AND tit_acr.cod_espec_docto = "DM"                             */
/*                                           AND tit_acr.log_sdo_tit_acr                                    */
/*                                           AND tit_acr.dat_vencto_tit_acr > TODAY - 365                   */
/*                                           AND tit_acr.dat_vencto_tit_acr < TODAY                         */
/*                                           AND tit_acr.cdn_cliente = bf-ext-emitente.cod-emitente         */
/*                                           AND tit_acr.num_id_tit_acr <> new_tit_acr.num_id_tit_acr) THEN */
/*                                 ASSIGN l-verifica = YES.                                                 */
/*                         END.                                                                             */
/*                     END.                                                                                 */
                END.
                IF NOT l-verifica THEN
                    RUN pi-aprova-ped(INPUT new_tit_acr.cdn_cliente,
                                      INPUT new_tit_acr.val_movto_tit_acr).
            END.
        END.
        /*
        WHEN "Estorno de Liquida��o"      OR
        WHEN "Estorno Acerto Val Cr�dito" OR
        WHEN "Estorno Acerto Val Menor"   OR
        WHEN "Estorno Liquida��o Subst"   OR
        WHEN "Estorno Liquid Rengociac"   OR
        WHEN   "Estorno Liquid Transf Estab"
        THEN DO:
             IF new_tit_acr.val_sdo_tit_acr > 0 THEN
             DO:
                 RUN pi-reativa-os.
             END.
        END.
             */
    END CASE.
    
    CASE new_tit_acr.ind_trans_acr_abrev:
       WHEN "ADVN" THEN DO:
       
            FIND FIRST tit_acr OF new_tit_acr  NO-LOCK NO-ERROR.
            IF tit_acr.dat_vencto_tit_acr > TODAY THEN
            DO:
                IF CAN-FIND(FIRST emitente 
                            WHERE emitente.cod-emitente = new_tit_acr.cdn_cliente AND
                                  emitente.ind-cre-cli = 1 AND
                   CAN-FIND(FIRST es-revendedor-glp 
                            WHERE es-revendedor-glp.cod-emitente = emitente.cod-emitente NO-LOCK) NO-LOCK) THEN
                DO:
            
                    FIND FIRST ext-emitente NO-LOCK
                         WHERE ext-emitente.cod-emitente = new_tit_acr.cdn_cliente NO-ERROR.
                    ASSIGN l-verifica = NO.
                    FOR EACH emscad.estabelecimento NO-LOCK:
                        FOR EACH bf-ext-emitente NO-LOCK
                           WHERE bf-ext-emitente.cod-grupo-matriz = ext-emitente.cod-grupo-matriz:
                            IF CAN-FIND(FIRST tit_acr NO-LOCK
                                        WHERE tit_acr.cod_estab = emscad.estabelecimento.cod_estab
                                          AND tit_acr.cod_espec_docto = "DM"
                                          AND tit_acr.cdn_cliente = bf-ext-emitente.cod-emitente
                                          AND tit_acr.dat_vencto_tit_acr < TODAY
                                          AND tit_acr.log_sdo_tit_acr
                                          AND tit_acr.num_id_tit_acr <> new_tit_acr.num_id_tit_acr) THEN
                                ASSIGN l-verifica = YES.
                        END.
                    END.
                    IF NOT l-verifica THEN
                    DO:
                        RUN pi-aprova-ped(INPUT new_tit_acr.cdn_cliente,
                                          INPUT tit_acr.val_sdo_tit_acr).       
                    END.
                END.   
            END.            
       END.
       
    END CASE.
    
END.

PROCEDURE pi-aprova-ped:
    DEFINE INPUT PARAMETER p-cod-emitente AS INTEGER NO-UNDO.
    DEFINE INPUT PARAMETER p-vl-movto LIKE movto_tit_acr.val_movto_tit_acr NO-UNDO.
    
    DEFINE VARIABLE de-vl-movto  LIKE movto_tit_acr.val_movto_tit_acr NO-UNDO.

    FIND FIRST emitente NO-LOCK
         WHERE emitente.cod-emitente = p-cod-emitente NO-ERROR.
    FIND FIRST ext-emitente NO-LOCK
         WHERE ext-emitente.cod-emitente = emitente.cod-emitente NO-ERROR.
    
    FIND FIRST estabelec NO-LOCK NO-ERROR.
    IF  NOT AVAIL estabelec THEN  RETURN.
    
    RUN cdp/cd9970.p (INPUT ROWID(estabelec),
                      OUTPUT i-empresa).
                      
    RUN pi-seta-empresa-estabel (INPUT i-empresa,
                                 INPUT estabelec.cod-estabel).
    FIND FIRST clien_analis_cr NO-LOCK
         WHERE clien_analis_cr.cod_empresa = i-empresa
         AND   clien_analis_cr.cdn_cliente = emitente.cod-emitente NO-ERROR.
    IF AVAIL clien_analis_cr THEN  
        ASSIGN perSemConsumo = TODAY - clien_analis_cr.dat_ult_impl_tit_acr .
        
    CREATE tt-emitente.
    ASSIGN tt-emitente.cod-emitente      = emitente.cod-emitente
           tt-emitente.nome-abrev        = emitente.nome-abrev
           tt-emitente.nr-mesina         = emitente.nr-mesina
           tt-emitente.cod-gr-cli        = emitente.cod-gr-cli
           tt-emitente.nr-peratr         = emitente.nr-peratr
           /* Informa��es para o EMS 5.0 */
           tt-emitente.nr-cheque-devol   = emitente.nr-cheque-devol
           tt-emitente.vl-max-devol      = emitente.vl-max-devol
           tt-emitente.qtd-dias          = emitente.periodo-devol
           tt-emitente.moeda-credito     = 0
           tt-emitente.de_saldo_cr       = 0
           tt-emitente.de_saldo_ap       = 0
           tt-emitente.de_tot_tit_atr_cr = 0
           tt-emitente.de_tot_ad_cr      = 0
           tt-emitente.de_cr_ant_aberto  = 0
           tt-emitente.de_ap_ant_aberto  = 0
           tt-emitente.identif           = emitente.identif.
    
    EMPTY TEMP-TABLE tt-erros-analise-credito. 
    
    RUN pi-determina-limite (OUTPUT de-lim-credito).
    
    IF de-lim-credito > 0 THEN
    DO:
        find first es_param_global_ti no-lock 
             where es_param_global_ti.cod_empresa  = v_cod_empres_usuar     
               and es_param_global_ti.cod_parametro = 'PercentualLimCredit'
               and es_param_global_ti.dt_val_ini <= TODAY 
               and es_param_global_ti.dt_val_fim >= TODAY NO-ERROR.
        IF AVAIL es_param_global_ti THEN DO:
            for each es_param_global_ti_item
               WHERE es_param_global_ti_item.cod_empresa    = es_param_global_ti.cod_empresa   
                 AND es_param_global_ti_item.cod_parametro  = es_param_global_ti.cod_parametro no-lock:
               IF es_param_global_ti_item.cod_parametro_item = "PercLimCredit" THEN 
                   ASSIGN de-perc-lim = DEC(es_param_global_ti_item.val_1) NO-ERROR. 
            END.
        END.
        
        IF de-perc-lim > 0 AND de-perc-lim < 100 THEN
            ASSIGN de-lim-aux = de-lim-credito * (1 + (de-perc-lim / 100)).
        ELSE
            ASSIGN de-lim-aux = de-lim-credito.
        
        RUN pi-verifica-ped.
        RUN pi-verifica-ft.
    
        ASSIGN i-ind-aval = IF emitente.ind-aval = 2 THEN 1 ELSE 3.
    
        RUN pi-saldo-cr (INPUT i-ind-aval).
        RUN pi-saldo-ap.
        
        FIND param_integr_ems WHERE
             param_integr_ems.ind_param_integr_ems  = 'Faturamento 2.00' NO-LOCK NO-ERROR.
    
        FOR EACH emscad.estabelecimento NO-LOCK:
            FOR EACH tit_acr NO-LOCK USE-INDEX titacr_cliente
               WHERE tit_acr.cod_estab = emscad.estabelecimento.cod_estab
                 AND tit_acr.cdn_cliente = emitente.cod-emitente
                 AND tit_acr.dat_emis_docto > 01/01/2000
                 AND tit_acr.log_sdo_tit_acr 
                 AND tit_acr.cod_espec_docto = "DM":
                 
                FIND trad_org_ext WHERE
                     trad_org_ext.cod_matriz_trad_org_ext = param_integr_ems.des_contdo_param_integr_ems AND
                     trad_org_ext.cod_tip_unid_organ      = '999' AND 
                     trad_org_ext.cod_unid_organ          = tit_Acr.cod_estab NO-LOCK NO-ERROR.
                FOR FIRST fat-duplic NO-LOCK
                    WHERE fat-duplic.cod-estabel   = trad_org_ext.cod_unid_organ_ext
                      AND fat-duplic.cod-esp       = tit_acr.cod_espec_docto
                      AND fat-duplic.serie         = tit_acr.cod_ser_docto
                      AND fat-duplic.nr-fatura     = tit_acr.cod_tit_acr
                      AND fat-duplic.parcela       = tit_acr.cod_parcela, 
                     FIRST  nota-fiscal NO-LOCK
                     WHERE  nota-fiscal.cod-estabel = fat-duplic.cod-estabel
                       AND  nota-fiscal.serie       = fat-duplic.serie
                       AND  nota-fiscal.nr-nota-fis = fat-duplic.nr-fatura
                       AND (nota-fiscal.nat-operacao = "5102TI" OR 
                            nota-fiscal.nat-operacao = "6102TI"):
                            
                     ASSIGN de-saldo-cr = de-saldo-cr - tit_acr.val_sdo_tit_acr.
                END.
            END.
        END.
        
        ASSIGN de-lim-aux = de-lim-aux + (de-saldo-ap + mp-vl-ap-abe)
                          - (de-saldo-cr + mp-vl-cr-abe + de-vl-nota + de-totvlap + de-vl-pedido).
                 
    END.                
    
    ASSIGN de-vl-movto = p-vl-movto + de-lim-aux.
    
    aprova-ped:     
    DO WHILE de-vl-movto > 0:
    
       FOR EACH ped-venda NO-LOCK USE-INDEX ch-credito WHERE 
                ped-venda.nome-abrev    = emitente.nome-abrev AND 
                ped-venda.cod-sit-ped  <= 2 AND
                ped-venda.cod-sit-aval  = 4 AND
                ped-venda.dt-implant   >= TODAY - 4 BY ped-venda.vl-tot-ped:
            
            ASSIGN de-vl-descto-pa = 0.
            FOR EACH ped-item OF ped-venda NO-LOCK
               WHERE ped-item.it-codigo BEGINS "PA":
               
               ASSIGN de-vl-descto-pa = de-vl-descto-pa + ped-item.vl-tot-it.
               
            END.

            ASSIGN de-vl-pedido = ped-venda.vl-liq-abe - de-vl-descto-pa.
            
            IF de-vl-pedido < de-vl-movto THEN
            DO:
                RUN pi-aprova-automatico.
                
                ASSIGN p-vl-movto = de-vl-movto - de-vl-pedido.
            END.
            ELSE
                LEAVE aprova-ped.
       END.
       LEAVE aprova-ped.
    END.         

END PROCEDURE.

PROCEDURE pi-aprova-automatico.

    {utp/ut-liter.i Autom�tica *}
    IF  AVAIL ped-venda THEN DO:
        FIND CURRENT ped-venda EXCLUSIVE-LOCK NO-ERROR.
        ASSIGN ped-venda.cod-sit-aval = 3
               ped-venda.cod-sit-com  = 2
               ped-venda.user-aprov   = RETURN-VALUE 
               ped-venda.quem-aprovou = RETURN-VALUE 
               ped-venda.dt-apr-cred  = TODAY 
               //ped-venda.desc-bloq-cr = ""
               ped-venda.desc-forc-cr = "Aprovacao Automatica"
               c-nr-pedcli            = ped-venda.nr-pedcli
               c-nome-abrev           = ped-venda.nome-abrev
               ped-venda.dsp-pre-fat  = YES.
        
/*         FIND FIRST es-integr-ped-venda EXCLUSIVE-LOCK                             */
/*              WHERE es-integr-ped-venda.nome-abrev = ped-venda.nome-abrev          */
/*                AND es-integr-ped-venda.nr-pedcli  = ped-venda.nr-pedcli NO-ERROR. */
/*         IF AVAIL es-integr-ped-venda THEN                                         */
/*             ASSIGN es-integr-ped-venda.dt-apr-cred = NOW.                         */
        
        RELEASE ped-venda.
                
        RUN pi-envia-email-aprovado(input c-nr-pedcli,
                                    input c-nome-abrev).               
    END.
    
END PROCEDURE.

PROCEDURE pi-envia-email-aprovado :
/*------------------------------------------------------------------------------
  Purpose:     
  Parameters:  <none>
  Notes:       
------------------------------------------------------------------------------*/
DEFINE INPUT PARAMETER p-nr-pedcli      AS CHAR         NO-UNDO.
DEFINE INPUT PARAMETER p-nome-abrev     AS CHAR         NO-UNDO.

DEFINE VAR c-remetente      AS CHAR         NO-UNDO.
DEFINE VAR c-destinatario   AS CHAR         NO-UNDO.     
DEFINE VAR c-assunto        AS CHAR         NO-UNDO.    
DEFINE VAR c-cliente        AS CHAR         NO-UNDO. 
DEFINE VAR h-utapi019       AS HANDLE       NO-UNDO.

/*DEFINE OUTPUT param table for           tt-erros.*/

DEF VAR c-mensagem AS LONGCHAR.

ASSIGN c-remetente = "automacao#contato-consigaz.com.br"
       //c-remetente = "aprovacaopedidosrevenda#consigaz.com.br"
       c-mensagem = '<html> ~
                     <meta http-equiv=�Content-Type� content=�text/html; charset=utf-8?> ~
                     <body> ~
                     <br> ~
                     <font face="tahoma" size="4" color="#163272"> ~
                           Ol&aacute; #CLIENTE!</font> ~
                     <br> ~
                     Informamos que o pedido #PEDIDO foi aprovado. ~
                     </body> ~
                     </html>'.
    
    FIND FIRST ped-venda NO-LOCK
         WHERE ped-venda.nr-pedcli  = p-nr-pedcli
           AND ped-venda.nome-abrev = p-nome-abrev NO-ERROR.
    IF AVAIL ped-venda THEN
    DO:
       FIND FIRST emitente NO-LOCK
            WHERE emitente.nome-abrev = ped-venda.nome-abrev NO-ERROR.
       ASSIGN c-cliente = emitente.nome-emit
              c-assunto = "Pedido: " + ped-venda.nr-pedcli + " aprovado".
              
    END.          
    /*          
    FOR EACH cont-emit NO-LOCK
       WHERE cont-emit.cod-emitente = ped-venda.cod-emitente
         AND cont-emit.area = "NFE":
         IF c-destinatario = "" THEN
            ASSIGN c-destinatario = cont-emit.e-mail .
         ELSE
            ASSIGN c-destinatario = c-destinatario + ";" + cont-emit.e-mail .            
    END.
    */
    FIND FIRST usuar_mestre NO-LOCK
         WHERE usuar_mestre.cod_usuario = ped-venda.user-impl NO-ERROR.

    ASSIGN c-destinatario = c-destinatario + ";" + usuar_mestre.cod_e_mail_local.
         
    ASSIGN c-mensagem = REPLACE(c-mensagem,'#CLIENTE', c-cliente)
           c-mensagem = REPLACE(c-mensagem,'#PEDIDO', p-nr-pedcli).

    RUN utp/utapi019.p PERSISTENT SET h-utapi019.
    
    FIND FIRST param_email NO-LOCK NO-ERROR.
    
    IF LENGTH(c-mensagem) < 32000 THEN DO:
        CREATE tt-mensagem.
        ASSIGN tt-mensagem.seq-mensagem = 1
               tt-mensagem.mensagem = c-mensagem.
    END.
    ELSE DO:
        CREATE tt-mensagem.
        ASSIGN tt-mensagem.seq-mensagem = 1
               tt-mensagem.mensagem = SUBSTRING(c-mensagem,1,31900).
    END.
    
    CREATE tt-paramEmail2.
    ASSIGN tt-paramEmail2.caminhoEmail   = 5
           tt-paramEmail2.codRemetPadrao = param_email.cod_remte_email
           tt-paramEmail2.mailUser       = param_email.cod_usuar_email
           tt-paramEmail2.mailPass       = param_email.cod_senha.
    
    CREATE tt-envio2.
    ASSIGN tt-envio2.versao-integracao = 1
           tt-envio2.destino     = c-destinatario
           tt-envio2.remetente   = param_email.cod_remte_email 
           tt-envio2.assunto     = c-assunto 
           tt-envio2.arq-anexo   = ''
           tt-envio2.formato     = "HTML".
    
    RUN pi-execute4 in h-utapi019(INPUT  TABLE tt-envio2,
                                  INPUT  TABLE tt-mensagem,
                                  INPUT  TABLE tt-paramEmail2,
                                  INPUT  TABLE ttAttachment,
                                  OUTPUT TABLE tt-erros). 
    
    FOR EACH tt-paramEmail2:
        DELETE tt-paramEmail2.
    END.
                                  
    FOR EACH tt-envio2:
        DELETE tt-envio2.
    END.
     
    FOR EACH tt-mensagem:
         DELETE  tt-mensagem.
    END.
    
    DELETE PROCEDURE h-utapi019.

END PROCEDURE.

PROCEDURE pi-verifica-ped.

    /* Alterado para utilizar o buffer da ped-venda (bf-ped-venda), e n�o mais a pr�pria tabela, pois no retorno desta procedure,
       no cdapi013.p, estava sendo desposicionada a tabela ped-venda, gerando alguns erros. */

    DEF VAR de-valor-item  AS   DECIMAL             NO-UNDO.
    DEF VAR i-cod-sit-aval AS   INTEGER             NO-UNDO.
    DEF VAR i-nr-pedido    LIKE ped-venda.nr-pedido NO-UNDO.

    ASSIGN i-total-ped = 0
           i-tot-pdap  = 0
           i-tot-pdre  = 0
           i-tot-pdaa  = 0
           de-totvlap  = 0
           de-totvlre  = 0
           de-totvlaa  = 0
           de-pd-sl-ap-forc = 0.

    IF AVAIL tt-param-aval THEN 
       ASSIGN i-nr-pedido = tt-param-aval.nr-pedido.

    assign l-considera-replica-pd = no.

    /*************************** INICIO UPC ******************************************************************************/
    IF c-nom-prog-dpc-mg97  <> "" OR 
       c-nom-prog-appc-mg97 <> "" OR 
       c-nom-prog-upc-mg97  <> "" THEN DO:

        IF  INDEX(PROGRAM-NAME(1),".w") = 0 THEN DO: /* evita que haja conflito de UPCs quando esta include est� definida em programas com interface */
           FOR EACH tt-epc WHERE 
                    tt-epc.cod-event = "call-Upc-Verify-ped-item":
               DELETE tt-epc.
           END.

           CREATE tt-epc.
           ASSIGN tt-epc.cod-event     = "call-Upc-Verify-ped-item"
                  tt-epc.cod-parameter = "return"
                  tt-epc.val-parameter = STRING("no").

            {include/i-epc201.i "call-Upc-Verify-ped-item"}

           IF CAN-FIND (FIRST tt-epc WHERE 
                              tt-epc.cod-event     = "call-Upc-Verify-ped-item" AND 
                              tt-epc.cod-parameter = "return" AND 
                              tt-epc.val-parameter = STRING("yes") ) THEN 
                            
              ASSIGN l-chama-upc-item = YES.

       END.    

    END.
    /*************************** FIM UPC ******************************************************************************/

    FOR EACH tt-emitente NO-LOCK:    

        FOR EACH bf-ped-venda NO-LOCK USE-INDEX ch-credito WHERE 
            bf-ped-venda.nome-abrev        = tt-emitente.nome-abrev AND 
            bf-ped-venda.cod-sit-ped      <= 2 AND /* aberto e atend. parcial */ 
           (bf-ped-venda.replica-pd        = NO OR l-considera-replica-pd = YES),
            EACH  natur-oper  /** CONSISTENCIA SE GERA OU NAO FATURAMENTO **/ WHERE
                  natur-oper.nat-operacao = bf-ped-venda.nat-operacao AND 
                  natur-oper.emite-duplic = YES NO-LOCK:
            
            /* N�o considera cota��o para a avalia��o de cr�dito
               N�o considera pedidos incompletos para a avali��o de cr�dito */ 
            IF bf-ped-venda.log-cotacao 
            OR bf-ped-venda.completo = no THEN
                NEXT.
                
            if bf-ped-venda.nr-pedido = i-nr-pedido then
                next.
                
            &IF DEFINED(bf_resum_emit) &THEN
              if bf-ped-venda.cod-estabel <> c-cod-estabel-resum then
                next. 
            &ENDIF
            
            IF SUBSTRING(bf-ped-venda.nr-pedcli, LENGTH(bf-ped-venda.nr-pedcli) - 1, 1) = "D" THEN NEXT.
            
            IF bf-ped-venda.dt-implant < TODAY - 4 THEN NEXT.                       

            ASSIGN i-cod-sit-aval = bf-ped-venda.cod-sit-aval.

            IF AVAIL tt-param-aval THEN 
                &IF "{&bf_dis_versao_ems}":U >= "2.062":U &THEN
                       IF ENTRY(1,tt-param-aval.programa,",") = "cm0202":U THEN DO:
                &ELSE
                       IF ENTRY(1,tt-param-aval.programa,",") = "pd0808":U THEN DO:
                &ENDIF
                  FIND tt-param-aval WHERE 
                       tt-param-aval.nr-pedido = bf-ped-venda.nr-pedido NO-ERROR.
                  /*
                  ** se est� na sele��o e n�o foi avaliado n�o considera saldo
                  */
                  IF AVAIL tt-param-aval AND tt-param-aval.cod-sit-aval < 2 THEN 
                     NEXT.
                  /*
                  ** busca situa��o da temp-table para evitar que situa��o esteja incorreta caso simula��o
                  */
                  IF AVAIL tt-param-aval AND tt-param-aval.cod-sit-aval > 1 THEN 
                     ASSIGN i-cod-sit-aval = tt-param-aval.cod-sit-aval.
                  FIND tt-param-aval WHERE 
                       tt-param-aval.nr-pedido = i-nr-pedido NO-ERROR.
               END.

            ASSIGN i-total-ped = i-total-ped + 1.

            /*** vers�o 2.03 ***/
            &IF DEFINED(BF_DIS_ADM_PRECO) &THEN
                IF  bf-ped-venda.cod-sit-com = 3 AND 
                    NOT &IF "{&bf_dis_versao_ems}":U >= "2.062":U &THEN l-cm-log-consid-cotas-credito &else para-ped.log-consid-cotas-credito &endif THEN  
                    NEXT. 

                IF  bf-ped-venda.ind-sit-descon = 3 AND 
                    NOT &IF "{&bf_dis_versao_ems}":U >= "2.062":U &THEN l-cm-log-consid-desco-credito &else para-ped.log-consid-desco-credito &endif THEN  
                    NEXT.

                IF  bf-ped-venda.cod-sit-preco = 3 AND 
                    NOT &IF "{&bf_dis_versao_ems}":U >= "2.062":U &THEN  l-cm-log-consid-precos-credito &else para-ped.log-consid-precos-credito &endif THEN  
                    NEXT.
            &ENDIF


            /*** Projeto Gr�so x Aval. Cr�dito - A partir do 2.06b dever� utilizar a api evolu�da de integra��o com o EMS5 ***/
            &if '{&BF_DIS_VERSAO_EMS}' >= '2.062' &then
                if l-modul-graos then /*** M�dulo de Gr�os implantado - cd0101 ***/
                   &IF '{&BF_DIS_VERSAO_EMS}' >= '2.08' &THEN
                       FIND FIRST tt-emit-safra-dis
                            WHERE tt-emit-safra-dis.cod-emitente = emitente.cod-emitente
                              AND tt-emit-safra-dis.cod-safra    = bf-ped-venda.cod-safra NO-ERROR.
                   &ELSE
                       FIND FIRST tt-emit-safra-dis
                            WHERE tt-emit-safra-dis.cod-emitente = emitente.cod-emitente
                              AND tt-emit-safra-dis.cod-safra    = substring(bf-ped-venda.char-2,101,8) NO-ERROR.
                   &ENDIF
                IF not l-modul-graos
                OR (    l-modul-graos
                    and not avail tt-emit-safra-dis) then
            &endif
            /*** Fim - Proj Graos ***/

            IF  i-cod-sit-aval = 2  /* Avaliados */ OR
                i-cod-sit-aval = 3  /* Aprovados */ THEN
                ASSIGN i-tot-pdap = i-tot-pdap + 1. 
            ELSE 
                IF  i-cod-sit-aval = 4 THEN /* Reprovados */
                    ASSIGN i-tot-pdre = i-tot-pdre + 1.
                ELSE  /* N�o avaliados */
                    ASSIGN i-tot-pdaa = i-tot-pdaa + 1.

            FOR EACH ped-item NO-LOCK USE-INDEX ch-item-ped WHERE 
                ped-item.nome-abrev    = bf-ped-venda.nome-abrev AND 
                ped-item.nr-pedcli     = bf-ped-venda.nr-pedcli AND 
                ped-item.cod-sit-item <= 2,
                FIRST b-natur-oper /* CONSISTENCIA GERA OU NAO FATURAMENTO */ FIELDS () NO-LOCK WHERE 
                     b-natur-oper.nat-operacao = ped-item.nat-operacao AND 
                     b-natur-oper.emite-duplic = YES:

                IF  ped-item.ind-componen = 3 THEN 
                    NEXT.

                /*************************** INICIO UPC ******************************************************************************/
                IF l-chama-upc-item = YES THEN DO: /* para usar esse ponto, deve ser setada essa variavel em outro evento de upc */

                   /* Caroline - Petroflex - Inicio */

                   IF  INDEX(PROGRAM-NAME(1),".w") = 0 THEN DO: /* evita que haja conflito de UPCs quando esta include est� definida em programas com interface */
                       FOR EACH tt-epc WHERE 
                                tt-epc.cod-event = "Verify-ped-item":
                           DELETE tt-epc.
                       END.

                       CREATE tt-epc.
                       ASSIGN tt-epc.cod-event     = "Verify-ped-item"
                              tt-epc.cod-parameter = "ped-item rowid"
                              tt-epc.val-parameter = STRING(ROWID(ped-item)).

                       {include/i-epc201.i "Verify-ped-item"}

                       FIND FIRST tt-epc WHERE 
                                  tt-epc.cod-event     = "Verify-ped-item" AND 
                                  tt-epc.cod-parameter = "Error" NO-ERROR.
                       IF AVAIL tt-epc THEN NEXT.
                   END.    

                   /* Caroline - Petroflex - Fim */
                END.
                /*************************** FIM UPC ******************************************************************************/

                ASSIGN de-valor-item = ped-item.vl-liq-abe * fn-indice(bf-ped-venda.mo-codigo).


                IF l-chama-upc-item = YES THEN DO: /* para usar esse ponto, deve ser setada essa variavel em outro evento de upc */

                   /* Francisco - Nitroquimia - Inicio */

                   IF  INDEX(PROGRAM-NAME(1),".w") = 0 THEN DO: /* evita que haja conflito de UPCs quando esta include est� definida em programas com interface */
                       FOR EACH tt-epc WHERE 
                                tt-epc.cod-event = "avaliaValorEntrega":
                           DELETE tt-epc.
                       END.

                       CREATE tt-epc.
                       ASSIGN tt-epc.cod-event     = "avaliaValorEntrega"
                              tt-epc.cod-parameter = "ped-item rowid"
                              tt-epc.val-parameter = STRING(ROWID(ped-item)).

                       {include/i-epc201.i "avaliaValorEntrega"}

                       FIND FIRST tt-epc WHERE 
                                  tt-epc.cod-event     = "avaliaValorEntrega" AND 
                                  tt-epc.cod-parameter = "de-valor-item-upc" NO-ERROR.
                       IF AVAIL tt-epc THEN DO:
                           ASSIGN de-valor-item = dec(tt-epc.val-parameter).
                       END.
                   END.    

                   /* Francisco - Nitroquimia - Fim */
                END.
                /*************************** FIM UPC ******************************************************************************/                    
                &IF DEFINED(BF_DIS_ADM_PRECO) &THEN  /*** vers�o 2.03 ***/

                    IF  bf-ped-venda.cod-sit-com = 3 AND 
                        NOT &IF "{&bf_dis_versao_ems}":U >= "2.062":U &THEN l-cm-log-consid-cotas-credito &else para-ped.log-consid-cotas-credito &endif THEN  
                        NEXT.

                    IF  bf-ped-venda.ind-sit-descon = 3 AND 
                        NOT &IF "{&bf_dis_versao_ems}":U >= "2.062":U &THEN l-cm-log-consid-desco-credito &else para-ped.log-consid-desco-credito &endif THEN  
                        NEXT.

                    IF  bf-ped-venda.cod-sit-preco = 3 AND 
                        NOT &IF "{&bf_dis_versao_ems}":U >= "2.062":U &THEN l-cm-log-consid-precos-credito &else para-ped.log-consid-precos-credito &endif THEN  
                        NEXT.

                &ENDIF

                IF  i-cod-sit-aval = 2 /* Avaliados */ OR 
                    i-cod-sit-aval = 3 /* Aprovados */ THEN DO:

                    IF ped-item.dt-entrega <= (TODAY + &IF "{&bf_dis_versao_ems}":U >= "2.062":U &THEN i-cm-num-horiz-fix &else para-ped.horiz-fixo &endif) THEN DO: 
                       IF  bf-ped-venda.desc-forc-cr <> "" THEN 
                           ASSIGN  de-pd-sl-ap-forc = de-pd-sl-ap-forc + de-valor-item.       

                       /*** Projeto Gr�so x Aval. Cr�dito - A partir do 2.06b dever� utilizar a api evolu�da de integra��o com o EMS5 ***/
                       &if '{&BF_DIS_VERSAO_EMS}' >= '2.062' &then
                           if l-modul-graos and avail tt-emit-safra-dis then /*** M�dulo de Gr�os implantado - cd0101 ***/
                              ASSIGN de-totvlap-safra                = de-totvlap-safra                 + de-valor-item /*** Total Pedidos Aprovado/Avaliados Safra (C) ***/ 
                                     tt-emit-safra-dis.totvlap-safra = tt-emit-safra-dis.totvlap-safra  + de-valor-item.
                           else
                       &endif
                       
                       ASSIGN de-totvlap = de-totvlap + de-valor-item. 
                       /*** Fim - Proj Graos ***/                

                    END.             
                END.
                ELSE  
                    IF  i-cod-sit-aval = 4 THEN DO: /* Reprovados */
                        &if '{&BF_DIS_VERSAO_EMS}' >= '2.062' &then
                            if not (l-modul-graos and SUBSTRING(bf-ped-venda.char-2,101,8) <> "") then /*** M�dulo de Gr�os implantado - cd0101 ***/
                        &endif
                        &IF DEFINED(BF_DIS_ADM_PRECO) &THEN
                            IF AVAIL tt-param-aval AND SUBSTR(tt-param-aval.programa,1,2) = "pd" THEN DO:
                               IF ped-item.dt-entrega   <= (TODAY + &IF "{&bf_dis_versao_ems}":U >= "2.062":U &THEN i-cm-num-horiz-fix &else para-ped.horiz-fixo &endif ) THEN 
                                  ASSIGN de-totvlre = de-totvlre + de-valor-item.
                            END.
                            ELSE
                        &ENDIF
                            ASSIGN de-totvlre = de-totvlre + de-valor-item.
                    END.
                    ELSE DO: /* N�o avaliados */
                    
                        /*** Projeto Gr�so x Aval. Cr�dito - A partir do 2.06b dever� utilizar a api evolu�da de integra��o com o EMS5 ***/
                        &if '{&BF_DIS_VERSAO_EMS}' >= '2.062' &then
                            if l-modul-graos and avail tt-emit-safra-dis then /*** M�dulo de Gr�os implantado - cd0101 ***/
                               ASSIGN de-totvlaa-safra                = de-totvlaa-safra                + de-valor-item  /*** Total Pedidos a Aprovar Safra (D) ***/
                                      tt-emit-safra-dis.totvlaa-safra = tt-emit-safra-dis.totvlaa-safra + de-valor-item.
                            else
                        &endif
                        
                        ASSIGN de-totvlaa = de-totvlaa + de-valor-item.
                        /*** Fim - Proj Graos ***/                

                    END.
                {cdp/cdapi013.i20 "11" "ped-item.nome-abrev + chr(24) + ped-item.nr-pedcli + chr(24) + string(ped-item.nr-sequencia) + chr(24) + ped-item.it-codigo + chr(24) + ped-item.cod-refer + chr(24) + string(ped-item.vl-liq-abe) + chr(24) + string(bf-ped-venda.mo-codigo) + chr(24) + string(fn-indice(bf-ped-venda.mo-codigo)) + chr(24) + string(ped-item.dt-entrega) + chr(24) + string(bf-ped-venda.cod-sit-aval)"}

            END.
        END.
    END.

    FIND tt-param-aval WHERE 
         tt-param-aval.nr-pedido = i-nr-pedido NO-ERROR.


END PROCEDURE.


PROCEDURE pi-cancela-os:
    DEFINE INPUT PARAMETER p-emitente AS INTEGER NO-UNDO.
    //DEFINE VARIABLE h-acomp AS HANDLE.
    
    //RUN utp/ut-acomp.p PERSISTENT SET h-acomp.

    //RUN pi-inicializar IN h-acomp (INPUT 'Verificando t�tulos atrasados').
    FIND FIRST ext-para-fat NO-LOCK NO-ERROR.
    FIND FIRST es-regras-ord-serv NO-LOCK NO-ERROR.
    FIND FIRST es-regras-ord-serv-estab NO-LOCK NO-ERROR.
    //FIND FIRST es-param-ord-servico NO-LOCK NO-ERROR.
    
    IF CAN-FIND(FIRST es-ord-servico    NO-LOCK
        WHERE es-ord-servico.cod-motivo        = 41
        and NOT(es-ord-servico.situacao        = 7
        or   es-ord-servico.situacao           = 8
        or   es-ord-servico.situacao           = 10
        or   es-ord-servico.situacao           = 11
        or   es-ord-servico.situacao           = 15
        or   es-ord-servico.situacao           = 16)
        and es-ord-servico.dt-implantacao      >= datetime(today - 180)
        and es-ord-servico.dt-implantacao      <= datetime(TODAY) )  THEN DO:
        ASSIGN d-total = 0
               i-qtde  = 0
               l-cancela = NO.

        FOR EACH emscad.estabelecimento NO-LOCK: 
            titulos:
            FOR EACH tit_acr NO-LOCK 
                WHERE tit_acr.cod_estab = emscad.estabelecimento.cod_estab
                    AND LOOKUP(tit_acr.cod_espec_docto, es-regras-ord-serv.cod-esp) > 0
                    AND tit_acr.LOG_sdo_tit_acr    = YES                                                     /*Titulos com Saldo*/
                    AND tit_acr.dat_vencto_tit_acr < (TODAY - 45)   /*Titulos vencidos a mais de 45 dias*/
                    AND tit_acr.cdn_cliente = p-emitente:
                    
                    //RUN pi-acompanhar IN h-prog (INPUT tit_acr.cod_tit_acr).
                    
                IF tit_acr.dat_liquidac_tit_acr  <> 12/31/9999 THEN NEXT titulos.
                        ASSIGN d-total = d-total + tit_acr.val_sdo_tit_acr
                               i-qtde  = i-qtde + 1.
                  FIND FIRST tt-titulos 
                  WHERE tt-titulos.composicao = tit_acr.cod_estab + "/" + tit_acr.cod_espec_docto + "/" + tit_acr.cod_ser_docto + "/" + tit_acr.cod_tit_acr + "/" + tit_acr.cod_parcela NO-ERROR.
                  
                  IF NOT AVAIL tt-titulos THEN
                  DO:
                      CREATE tt-titulos.
                      ASSIGN tt-titulos.composicao = tit_acr.cod_estab + "/" + tit_acr.cod_espec_docto + "/" + tit_acr.cod_ser_docto + "/" + tit_acr.cod_tit_acr + "/" + tit_acr.cod_parcela
                             tt-titulos.dt-vencto  = tit_acr.dat_vencto_tit_acr
                             tt-titulos.vlr-orig   = tit_acr.val_sdo_tit_acr
                             tt-titulos.cod-emitente = tit_acr.cdn_cliente.
                      
                  END.
            end.                                
        end.
        /*
        if es-regras-ord-serv.vlr-titulos > d-total then
            assign l-cancela = YES.
        else
            assign l-cancela = no.
          */
        if  es-regras-ord-serv.log-qtde-deslig
        and es-regras-ord-serv.qtd-titulo > i-qtde 
        and es-regras-ord-serv.vlr-titulos > d-total then
            assign l-cancela = YES.
        else if es-regras-ord-serv.vlr-titulos > d-total then
            assign l-cancela = YES.
        else
            assign l-cancela = no.
           
    END.
    busca:
    /*Verifica existencia de ocorrencia de mesmo titulo em outros cancelamentos
    se houver ordens com titulos nao quitados de forma recorrente, nao executa cancelamento*/
    FOR EACH es-ord-servico    NO-LOCK
        WHERE es-ord-servico.cod-motivo        = 41
        AND   es-ord-servico.situacao          = 10
        AND   es-ord-servico.dt-implantacao      >= datetime(today - 180)
        AND   es-ord-servico.dt-implantacao      <= datetime(TODAY) 
        AND   es-ord-servico.cod-emitente        = p-emitente :

        
        FOR EACH bbf-es-movto-ordem-servico NO-LOCK
            WHERE bbf-es-movto-ordem-servico.nr-ordem-servico = es-ord-servico.nr-ordem-servico
            AND   bbf-es-movto-ordem-servico.nr-sequencia     = 1:
            titulos:
            FOR EACH  tt-titulos
            WHERE tt-titulos.cod-emitente = p-emitente:
                
                IF bbf-es-movto-ordem-servico.descricao MATCHES "*" + tt-titulos.composicao + "*" THEN
                DO:
                    FIND LAST bf-es-ord-serv NO-LOCK
                         WHERE bf-es-ord-serv.cod-motivo = 41
                           and NOT(bf-es-ord-serv.situacao        = 7
                            or   bf-es-ord-serv.situacao           = 8
                            or   bf-es-ord-serv.situacao           = 10
                            or   bf-es-ord-serv.situacao           = 11
                            or   bf-es-ord-serv.situacao           = 15
                            or   bf-es-ord-serv.situacao           = 16)
                            and bf-es-ord-serv.dt-implantacao      >= datetime(today - 180)
                            and bf-es-ord-serv.dt-implantacao      <= datetime(TODAY + 1) 
                            AND bf-es-ord-serv.cod-emitente        = p-emitente NO-ERROR.
                            
                    FIND FIRST b-es-movto-ordem-servico 
                         WHERE b-es-movto-ordem-servico.nr-ordem-servico =  bf-es-ord-serv.nr-ordem-servico 
                         AND   b-es-movto-ordem-servico.nr-sequencia     = 1 EXCLUSIVE-LOCK NO-ERROR.
                    IF AVAIL b-es-movto-ordem-servico THEN DO:
                         
                         IF b-es-movto-ordem-servico.descricao MATCHES "*" + "Nao elegivel para cancelamento" + "*" THEN NEXT titulos.
                            
                        ASSIGN l-cancela = NO
                                b-es-movto-ordem-servico.descricao = bbf-es-movto-ordem-servico.descricao + CHR(10) + "Nao elegivel para cancelamento da OS" +
                                                                     " pelo titulo " + tt-titulos.composicao + " ser recorrente".
                                                                     
                    END.
                    
                    FOR FIRST emscad.cliente NO-LOCK
                        WHERE cliente.cdn_cliente = new_tit_acr.cdn_cliente:
                        FIND FIRST histor_clien 
                        WHERE histor_clien.cod_empresa            = cliente.cod_empresa
                        AND   histor_clien.cdn_cliente            = cliente.cdn_cliente
                        AND   histor_clien.des_abrev_histor_clien = "Cancelamento Nao Elegivel OS " + STRING( es-ord-servico.nr-ordem-servico) NO-ERROR.
                        
                        IF NOT AVAIL histor_clien THEN DO:
                        CREATE histor_clien. 
                        ASSIGN histor_clien.cod_empresa            = cliente.cod_empresa
                               histor_clien.cdn_cliente            = cliente.cdn_cliente
                               histor_clien.des_abrev_histor_clien = "Cancelamento Nao Elegivel OS " + STRING( es-ord-servico.nr-ordem-servico)
                               histor_clien.cod_usuario            = v_cod_usuar_corren
                               histor_clien.dat_gerac_histor       = TODAY
                               histor_clien.hra_gerac_histor       = STRING(TIME,"hh:mm:ss").
                               
                            IF histor_clien.des_histor_clien = "" THEN
                              ASSIGN histor_clien.des_histor_clien   = "OS nao foi CANCELADA devido recorrencia de atraso em titulo  " +
                                                                     "para o local de entrega do cliente " + es-ord-servico.endereco   + CHR(10) +  tt-titulos.composicao  + "(vencimento em " +  STRING(tt-titulos.dt-vencto) +
                                                                     " Vl original " + STRING(tt-titulos.vlr-orig) + ")".
                            ELSE 
                              ASSIGN histor_clien.des_histor_clien   = histor_clien.des_histor_clien   + CHR(10) +  tt-titulos.composicao  + "(vencimento em " +  STRING(tt-titulos.dt-vencto) +
                                                                     " Vl original " + STRING(tt-titulos.vlr-orig) + ")".
                               
                        END.
                        ELSE DO:
                        
                            ASSIGN histor_clien.des_histor_clien   = histor_clien.des_histor_clien  + CHR(10) + tt-titulos.composicao  + "(vencimento em " +  STRING(tt-titulos.dt-vencto) +
                                                    " Vl original " + STRING(tt-titulos.vlr-orig) + ")".
                        END.
                        
                        FIND LAST b_histor_clien NO-LOCK
                            WHERE b_histor_clien.cod_empresa = histor_clien.cod_empresa
                              AND b_histor_clien.cdn_cliente = histor_clien.cdn_cliente NO-ERROR.
                        IF  AVAIL b_histor_clien THEN
                            ASSIGN histor_clien.num_seq_histor_clien = b_histor_clien.num_seq_histor_clien + 1.
                        ELSE
                            ASSIGN histor_clien.num_seq_histor_clien = 1.

                    END.
                                                                 
                    LEAVE busca.
                    
                END.
                DELETE tt-titulos.
            END.
        END.
    END.
    
    IF l-cancela THEN
    DO:
    FOR EACH emscad.estabelecimento NO-LOCK: 
        FOR EACH movto_tit_acr NO-LOCK
            WHERE movto_tit_acr.cod_estab = estabelecimento.cod_estab
            AND LOOKUP(movto_tit_acr.cod_espec_docto, es-regras-ord-serv.cod-esp) > 0
            AND   movto_tit_acr.dat_transacao = new_tit_acr.dat_transacao
            AND   (movto_tit_acr.ind_trans_acr_abrev = "LIQ"
            OR     movto_tit_acr.ind_trans_acr_abrev = "LQEC"   
            OR     movto_tit_acr.ind_trans_acr_abrev = "DEV"                 
            OR     movto_tit_acr.ind_trans_acr_abrev = "AVCR"    
            OR     movto_tit_acr.ind_trans_acr_abrev = "AVMN"      
            OR     movto_tit_acr.ind_trans_acr_abrev = "LQTE"   
            OR     movto_tit_acr.ind_trans_acr_abrev = "LQRN" )
            AND    movto_tit_acr.cdn_cliente   =  p-emitente:
            FIND FIRST TIT_ACR NO-LOCK
                 WHERE tit_acr.cod_estab = movto_tit_acr.cod_estab
                 AND   tit_acr.num_id_tit_acr = movto_tit_Acr.num_id_tit_acr NO-ERROR.
                 
             FIND FIRST tt-quitados
             WHERE tt-quitados.composicao = tit_acr.cod_estab + "/" + tit_acr.cod_espec_docto + "/" + tit_acr.cod_ser_docto + "/" + tit_acr.cod_tit_acr + "/" + tit_acr.cod_parcela NO-ERROR.
             IF NOT AVAIL tt-quitados THEN
             DO:
                 CREATE tt-quitados.
                 ASSIGN tt-quitados.composicao = tit_acr.cod_estab + "/" + tit_acr.cod_espec_docto + "/" + tit_acr.cod_ser_docto + "/" + tit_acr.cod_tit_acr + "/" + tit_acr.cod_parcela
                        tt-quitados.dt-vencto  = tit_acr.dat_vencto_tit_acr
                        tt-quitados.vlr-orig   = tit_acr.val_sdo_tit_acr
                        tt-quitados.cod-emitente = tit_acr.cdn_cliente.
                 
             END.
        END.
    END.
        FOR EACH es-ord-servico    NO-LOCK
            WHERE es-ord-servico.cod-motivo        = 41
            and NOT(es-ord-servico.situacao        = 7
            or   es-ord-servico.situacao           = 8
            or   es-ord-servico.situacao           = 10
            or   es-ord-servico.situacao           = 11
            or   es-ord-servico.situacao           = 15
            or   es-ord-servico.situacao           = 16)
            and es-ord-servico.dt-implantacao      >= datetime(today - 180)
            and es-ord-servico.dt-implantacao      <= datetime(TODAY) 
            AND es-ord-servico.cod-emitente        = p-emitente:
            
            FIND FIRST bf-es-ord-serv EXCLUSIVE-LOCK
            WHERE bf-es-ord-serv.nr-ordem-servico = es-ord-servico.nr-ordem-servico NO-ERROR.
            ASSIGN bf-es-ord-serv.dt-avaliacao         = NOW
                   bf-es-ord-serv.usuario-avaliacao    = c-seg-usuario
                   bf-es-ord-serv.situacao             = 10    /*10=Cancelada*/
                   bf-es-ord-serv.dt-cancelamento      = NOW
                   bf-es-ord-serv.usuario-cancelamento = c-seg-usuario.    
            
            
            FIND LAST b-es-movto-ordem-servico WHERE b-es-movto-ordem-servico.nr-ordem-servico = es-ord-servico.nr-ordem-servico NO-LOCK NO-ERROR.
            
            
            CREATE es-movto-ordem-servico.
            ASSIGN es-movto-ordem-servico.nr-ordem-servico  = es-ord-servico.nr-ordem-servico
                   es-movto-ordem-servico.nr-sequencia      = (IF AVAIL b-es-movto-ordem-servico THEN b-es-movto-ordem-servico.nr-sequencia ELSE 0)  + 1
                   es-movto-ordem-servico.dt-movimento      = NOW
                   es-movto-ordem-servico.usuario           = c-seg-usuario
                   es-movto-ordem-servico.ind-tip-justific  = 2
                   es-movto-ordem-servico.cod-justific      = 20
                   es-movto-ordem-servico.ind-tip-movto     = 7
                   es-movto-ordem-servico.desc-justific     = "Cancelamento autom�tico, cliente realizou o pagamento do titulo "
                   .    /*7=Cancelamento*/   
                   
                   
            FOR EACH tt-quitados WHERE tt-quitados.cod-emitente = es-ord-servico.cod-emitente:
                IF es-movto-ordem-servico.descricao = "" THEN
                    ASSIGN es-movto-ordem-servico.descricao = "Cancelamento autom�tico, cliente realizou o pagamento do titulo " + tt-quitados.composicao.
                ELSE
                    ASSIGN es-movto-ordem-servico.descricao = es-movto-ordem-servico.descricao + CHR(10) + tt-quitados.composicao. 
            END.
             
                   

            CREATE his-emit.
            ASSIGN his-emit.cod-emitente = es-ord-servico.cod-emitente 
                   his-emit.dt-his-emit  = TODAY
                   his-emit.horario      = SUBstring(STRING(TIME,"HH:MM"),1,2) + SUBstring(STRING(TIME,"HH:MM"),4,2).
                   
            FOR EACH tt-quitados WHERE tt-quitados.cod-emitente = es-ord-servico.cod-emitente:
                IF his-emit.historico = "" THEN
                    ASSIGN his-emit.historico    = "Cancelamento autom�tico, cliente realizou o pagamento do titulo " + tt-quitados.composicao. 
                ELSE
                    ASSIGN his-emit.historico    = his-emit.historico + CHR(10) + tt-quitados.composicao. 
                
            
                       
            END.
            
            
            FOR FIRST emscad.cliente NO-LOCK
                WHERE cliente.cdn_cliente = new_tit_acr.cdn_cliente:
                FIND FIRST histor_clien 
                WHERE histor_clien.cod_empresa            = cliente.cod_empresa
                AND   histor_clien.cdn_cliente            = cliente.cdn_cliente
                AND   histor_clien.des_abrev_histor_clien = "Cancelamento OS " + STRING( es-ord-servico.nr-ordem-servico) NO-ERROR.
                
                IF NOT AVAIL histor_clien THEN DO:
                CREATE histor_clien. 
                ASSIGN histor_clien.cod_empresa            = cliente.cod_empresa
                       histor_clien.cdn_cliente            = cliente.cdn_cliente
                       histor_clien.des_abrev_histor_clien = "Cancelamento OS " + STRING( es-ord-servico.nr-ordem-servico)
                       histor_clien.cod_usuario            = v_cod_usuar_corren
                       histor_clien.dat_gerac_histor       = TODAY
                       histor_clien.hra_gerac_histor       = STRING(TIME,"hh:mm:ss").
                       
                    FOR EACH tt-quitados WHERE tt-quitados.cod-emitente = cliente.cdn_cliente:
                        IF histor_clien.des_histor_clien = "" THEN
                          ASSIGN histor_clien.des_histor_clien   = "Devido a realiza��o do pagamento dos titulos realizado pleo cliente, foi CANCELADA a ordem de servico de corte de fornecimento de g�s " +
                                                                 "para o local de entrega do cliente " + es-ord-servico.endereco   + CHR(10) +  tt-quitados.composicao  + "(vencimento em " +  STRING(tt-quitados.dt-vencto) +
                                                                 " Vl original " + STRING(tt-quitados.vlr-orig) + ")".
                        ELSE 
                          ASSIGN histor_clien.des_histor_clien   = histor_clien.des_histor_clien   + CHR(10) +  tt-quitados.composicao  + "(vencimento em " +  STRING(tt-quitados.dt-vencto) +
                                                                 " Vl original " + STRING(tt-quitados.vlr-orig) + ")".
                    END.
                       
                END.
                ELSE DO:
                    FOR EACH tt-quitados WHERE tt-quitados.cod-emitente = cliente.cdn_cliente:
                
                        ASSIGN histor_clien.des_histor_clien   = histor_clien.des_histor_clien  + CHR(10) + tt-quitados.composicao  + "(vencimento em " +  STRING(tt-quitados.dt-vencto) +
                                                " Vl original " + STRING(tt-quitados.vlr-orig) + ")".
                    END.
                END.
                
                FIND LAST b_histor_clien NO-LOCK
                    WHERE b_histor_clien.cod_empresa = histor_clien.cod_empresa
                      AND b_histor_clien.cdn_cliente = histor_clien.cdn_cliente NO-ERROR.
                IF  AVAIL b_histor_clien THEN
                    ASSIGN histor_clien.num_seq_histor_clien = b_histor_clien.num_seq_histor_clien + 1.
                ELSE
                    ASSIGN histor_clien.num_seq_histor_clien = 1.

            END.
        END.
    END.

    //RUN pi-finalizar IN h-acomp.
END PROCEDURE.

RETURN 'OK':U.

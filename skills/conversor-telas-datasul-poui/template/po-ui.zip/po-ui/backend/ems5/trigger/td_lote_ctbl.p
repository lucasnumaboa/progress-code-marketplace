/******************************************************************************
** Programa...: TW_LOTE_CTBL.P
** Data.......: NOVEMBRO de 2020
** Analista...: Wellington Santo (WSA DESENV)
** Objetivo...: Trigger da LOTE_CTBL
** Versao.....: 1.00.00.000
*******************************************************************************/

/*definicao dos parametros*/
DEFINE PARAMETER BUFFER p_table  FOR LOTE_CTBL.


IF AVAIL p_table THEN DO:

    IF CAN-FIND(FIRST es-ctrl-fgl-entreg
                WHERE es-ctrl-fgl-entreg.lote-entr = p_table.num_lote_ctbl) THEN DO:


        FOR FIRST es-ctrl-fgl-entreg EXCLUSIVE-LOCK
            WHERE es-ctrl-fgl-entreg.lote-entr = p_table.num_lote_ctbl:
            DELETE es-ctrl-fgl-entreg.
        END.

    END.
    ELSE DO:

        IF CAN-FIND(FIRST es-ctrl-fgl-entreg
                    WHERE es-ctrl-fgl-entreg.lote-estorno = p_table.num_lote_ctbl) THEN DO:


            FOR FIRST es-ctrl-fgl-entreg EXCLUSIVE-LOCK
                WHERE es-ctrl-fgl-entreg.lote-estorno = p_table.num_lote_ctbl:
                DELETE es-ctrl-fgl-entreg.
            END.


        END.
        
    END.

END.
             


RETURN 'OK':U.

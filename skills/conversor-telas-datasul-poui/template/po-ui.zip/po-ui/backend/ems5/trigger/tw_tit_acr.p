/******************************************************************************
** Programa...: TW_TIT_ACR.P
** Data.......: Janeiro de 2011
** Analista...: Rodrigo Guimaraes  
** Objetivo...: Trigger da tit_acr
** Versao.....: 5.06.00.001
*******************************************************************************
** Data.......: 28/6/2016
** Analista...: Denis Berteli
** Objetivo...: Alterado o criterio da carteira para DA
*******************************************************************************/

DEF VAR l-debito-automatico AS LOGICAL NO-UNDO.
DEF VAR c-impr              AS LOGICAL NO-UNDO. 
DEF VAR i-contador          AS INTEGER INITIAL 1 NO-UNDO.

DEFINE NEW GLOBAL SHARED VARIABLE c-seg-usuario LIKE emsfnd.usuar_mestre.cod_usuario NO-UNDO.

/*definicao dos parametros*/
DEFINE PARAMETER BUFFER b-new-tit_acr  FOR tit_acr.
DEFINE PARAMETER BUFFER b-old-tit_acr  FOR tit_acr.

/*definicao de buffers*/
DEFINE BUFFER b_es_tit_acr_org_publico FOR es_tit_acr_org_publico.


/*definicao de funcoes adiante e persistentes*/

/* Carlos - Grupo MIR - 02/07/2021 - Declaracoes de Funcoes para nao chamar mais ESACR001 em modo persistent */
DEFINE VARIABLE c_param_portad_edi  AS CHARACTER                    NO-UNDO EXTENT 11.
FUNCTION fn-numero-bancario-ems5 RETURNS CHARACTER (c_cod_estab         AS CHARACTER,
                                                    c_cod_portador      AS CHARACTER,
                                                    c_cod_cart_bcia     AS CHARACTER,
                                                    c_cod_indic_econ    AS CHARACTER,
                                                    da_dat_emis_docto   AS DATE) FORWARD.

FUNCTION fn-portador-bancario-ems5 RETURNS LOGICAL (c_cod_estab         AS CHARACTER,
                                                    c_cod_portador      AS CHARACTER,
                                                    c_cod_cart_bcia     AS CHARACTER,
                                                    c_cod_indic_econ    AS CHARACTER,
                                                    da_dat_emis_docto   AS DATE) FORWARD.

FUNCTION fn-digito-verificador-modulo-10 RETURNS CHARACTER (c-numero AS CHARACTER) FORWARD.

FUNCTION fn-digito-verificador-modulo-11 RETURNS CHARACTER (c-numero    AS CHARACTER,
                                                            i-base      AS INTEGER,
                                                            c-parametro AS CHARACTER) FORWARD.
FUNCTION fn-numero-bancario RETURNS CHARACTER (c_cod_estab        AS CHARACTER,
                                               c_cod_portador     AS CHARACTER,
                                               c_cod_cart_bcia    AS CHARACTER,
                                               c_cod_finalid_econ AS CHARACTER) FORWARD.
/* Carlos - Grupo MIR - 02/07/2021 - Declaracoes de Funcoes para nao chamar mais ESACR001 em modo persistent */

/*zerar saldo nas tabelas de cobranca, serasa e spc - Rodrigo em 11/08/2011*/
IF NOT NEW(b-new-tit_acr) AND
   b-new-tit_acr.log_sdo_tit_acr <> b-old-tit_acr.log_sdo_tit_acr THEN DO:
    
    FIND es_tit_acr_cobr WHERE
         es_tit_acr_cobr.cod_estab      = b-new-tit_acr.cod_estab AND
         es_tit_acr_cobr.num_id_tit_acr = b-new-tit_acr.num_id_tit_acr EXCLUSIVE-LOCK NO-ERROR.
    
    IF AVAIL es_tit_acr_cobr THEN DO:
    
        ASSIGN es_tit_acr_cobr.log_sdo_tit_acr = b-new-tit_acr.log_sdo_tit_acr.

        RELEASE es_tit_acr_cobr.
    END.

    FIND es_tit_acr_serasa WHERE
         es_tit_acr_serasa.cod_estab      = b-new-tit_acr.cod_estab AND
         es_tit_acr_serasa.num_id_tit_acr = b-new-tit_acr.num_id_tit_acr EXCLUSIVE-LOCK NO-ERROR.
    
    IF AVAIL es_tit_acr_serasa THEN DO:
    
        ASSIGN es_tit_acr_serasa.log_sdo_tit_acr    = b-new-tit_acr.log_sdo_tit_acr.

        RELEASE es_tit_acr_serasa.
    END.

    FIND es_tit_acr_spc WHERE
        es_tit_acr_spc.cod_estab         = b-new-tit_acr.cod_estab AND
        es_tit_acr_spc.num_id_tit_acr    = b-new-tit_acr.num_id_tit_acr EXCLUSIVE-LOCK NO-ERROR.
    
    IF AVAIL es_tit_acr_spc THEN DO:
    
        ASSIGN es_tit_acr_spc.log_sdo_tit_acr    = b-new-tit_acr.log_sdo_tit_acr.

        RELEASE es_tit_acr_spc.
    END.

    FIND es_tit_acr_spc_nej WHERE
         es_tit_acr_spc_nej.cod_estab         = b-new-tit_acr.cod_estab AND
         es_tit_acr_spc_nej.num_id_tit_acr    = b-new-tit_acr.num_id_tit_acr EXCLUSIVE-LOCK NO-ERROR.
    
    IF AVAIL es_tit_acr_spc_nej THEN DO:
    
        ASSIGN es_tit_acr_spc_nej.log_sdo_tit_acr    = b-new-tit_acr.log_sdo_tit_acr.

        RELEASE es_tit_acr_spc_nej.
    END.

    FOR EACH b_es_tit_acr_org_publico WHERE
        b_es_tit_acr_org_publico.cod_estab      = b-new-tit_acr.cod_estab AND
        b_es_tit_acr_org_publico.num_id_tit_acr = b-new-tit_acr.num_id_tit_acr NO-LOCK:

        FIND es_tit_acr_org_publico WHERE
            ROWID(es_tit_acr_org_publico)   = ROWID(b_es_tit_acr_org_publico) EXCLUSIVE-LOCK NO-ERROR.

        IF AVAIL es_tit_acr_org_publico THEN DO:

            ASSIGN es_tit_acr_org_publico.log_sdo_tit_acr   = b-new-tit_acr.log_sdo_tit_acr.

            RELEASE es_tit_acr_org_publico.

        END.
    END.    

    //nota denegada  criacao AN --->  esp�ice NX j� esta parametrizada para gerar automaticamente AN (produto padr�o)
    
    IF b-new-tit_acr.cod_espec_docto = 'NX' AND b-new-tit_acr.log_sdo_tit_acr = NO AND b-new-tit_acr.log_tit_acr_estordo = NO THEN DO:  

          FIND FIRST es-cliente-denegada
               WHERE INT(es-cliente-denegada.cod-estabel)    = INT(b-new-tit_acr.cod_estab)
                 AND es-cliente-denegada.cod-EMITENTE        = b-new-tit_acr.cdn_cliente
                 AND es-cliente-denegada.cod-parcela-nx      = b-new-tit_acr.cod_parcela
                 AND es-cliente-denegada.cod-espec-docto-nx  = "NX"
                 AND es-cliente-denegada.cod-ser-docto-nx    = b-new-tit_acr.cod_ser_docto
                 AND es-cliente-denegada.cod-tit-acr-nx      = b-new-tit_acr.cod_tit_acr  EXCLUSIVE-LOCK NO-ERROR.
          IF AVAIL es-cliente-denegada THEN DO:

              ASSIGN es-cliente-denegada.cod-parcela-ad     =  b-new-tit_acr.cod_parcela
                     es-cliente-denegada.cod-ser-docto-ad   =  b-new-tit_acr.cod_ser_docto
                     es-cliente-denegada.cod-espec-docto-ad =  "AN"
                     es-cliente-denegada.cod-tit-acr-ad     =  b-new-tit_acr.cod_tit_acr.
          END.
    END.
 END.   

/*novo registro*/
IF  NEW(b-new-tit_acr) THEN DO:

    IF  b-new-tit_acr.cod_tit_acr_bco = '' AND 
        /* Denis - 12/6/2019 - Denis - filtro por especie para n�o gastar numero bancario */
        (b-new-tit_acr.cod_espec_docto = 'DM' OR 
         b-new-tit_acr.cod_espec_docto = 'TC' OR
        (b-new-tit_acr.cod_espec_docto = 'MU' AND b-new-tit_acr.cod_cart_bcia <> 'BA') OR
         b-new-tit_acr.cod_espec_docto = 'TX') AND
        fn-portador-bancario-ems5 (b-new-tit_acr.cod_estab,
                                   b-new-tit_acr.cod_portador,
                                   b-new-tit_acr.cod_cart_bcia,
                                   b-new-tit_acr.cod_indic_econ,
                                   b-new-tit_acr.dat_emis_docto) THEN DO:

        FIND param_integr_ems WHERE
            param_integr_ems.ind_param_integr_ems  = 'Faturamento 2.00' NO-LOCK NO-ERROR.

        FIND trad_org_ext WHERE
            trad_org_ext.cod_matriz_trad_org_ext    = param_integr_ems.des_contdo_param_integr_ems AND
            trad_org_ext.cod_tip_unid_organ         = '999' AND 
            trad_org_ext.cod_unid_organ             = b-new-tit_acr.cod_estab NO-LOCK NO-ERROR.
    
        FIND FIRST trad_org_ext WHERE
            trad_org_ext.cod_tip_unid_organ = '999' AND /*estabelecimento*/
            trad_org_ext.cod_unid_organ     = b-new-tit_acr.cod_estab NO-LOCK NO-ERROR.

        FIND fat-duplic WHERE
            fat-duplic.cod-estabel              = trad_org_ext.cod_unid_organ_ext AND
            fat-duplic.serie                    = b-new-tit_acr.cod_ser_docto AND
            fat-duplic.nr-fatura                = b-new-tit_acr.cod_tit_acr AND
            fat-duplic.parcela                  = b-new-tit_acr.cod_parcela AND
            SUBSTRING(fat-duplic.char-1,1,20)   <> '' NO-LOCK NO-ERROR.

        IF AVAIL fat-duplic THEN
            ASSIGN b-new-tit_acr.cod_tit_acr_bco = SUBSTRING(fat-duplic.char-1,1,20).

    END. /*if b-new-tit_acr.cod_tit_acr_bco = '' then do*/


    /**** ALTERACAO DO PORTADOR SE CLIENTE ESTIVER EM DEBITO AUTOMATICO ****/
     
    FIND FIRST es_espec_docto_financ_acr
         WHERE es_espec_docto_financ_acr.cod_espec_docto = b-new-tit_acr.cod_espec_docto
         NO-LOCK NO-ERROR.

    ASSIGN l-debito-automatico = IF NOT AVAIL es_espec_docto_financ_acr THEN YES ELSE es_espec_docto_financ_acr.log_debito_automatico.
       
    IF l-debito-automatico  = YES THEN 
    DO:

        IF b-new-tit_acr.cod_portador = '9997' THEN
        DO:
            FOR EACH es_clien_db_autom
                WHERE es_clien_db_autom.cdn_cliente     = b-new-tit_acr.cdn_cliente             AND
                     (es_clien_db_autom.ind_situacao    = 1  OR
                      es_clien_db_autom.ind_situacao    = 2) NO-LOCK,
                FIRST es_cta_corren_db_autom 
               WHERE es_cta_corren_db_autom.cod_cta_corren   = es_clien_db_autom.cod_cta_corren NO-LOCK:
               
    
                FIND FIRST cta_corren  
                     WHERE cta_corren.cod_cta_corren = es_clien_db_autom.cod_cta_corren AND 
                           cta_corren.cod_empresa    = b-new-tit_acr.cod_empresa NO-LOCK NO-ERROR.
                IF AVAIL cta_corren THEN
                DO:
                   RUN acr/esacr054.p (INPUT ROWID(b-new-tit_acr),
                                       INPUT es_cta_corren_db_autom.cod_portador,
                                       INPUT es_cta_corren_db_autom.cod_cart_bcia).
                   LEAVE.
                END.
            END.
        END.
        ELSE
        DO:
           FIND portad_finalid_econ WHERE
               portad_finalid_econ.cod_estab       = b-new-tit_acr.cod_estab AND
               portad_finalid_econ.cod_portador    = b-new-tit_acr.cod_portador AND
               portad_finalid_econ.cod_cart_bcia   = "DA" /*b-new-tit_acr.cod_cart_bcia*/ AND
               CAN-FIND(FIRST histor_finalid_econ WHERE
                        histor_finalid_econ.cod_finalid_econ       = portad_finalid_econ.cod_finalid_econ AND
                        histor_finalid_econ.cod_indic_econ         = b-new-tit_acr.cod_indic_econ AND
                        histor_finalid_econ.dat_inic_valid_finalid <= b-new-tit_acr.dat_emis_docto AND
                        histor_finalid_econ.dat_fim_valid_finalid  > b-new-tit_acr.dat_emis_docto NO-LOCK) NO-LOCK NO-ERROR.
           
           FOR FIRST es_cta_corren_db_autom 
               WHERE es_cta_corren_db_autom.cod_cta_corren   = portad_finalid_econ.cod_cta_corren NO-LOCK,
               FIRST es_clien_db_autom 
               WHERE es_clien_db_autom.cod_cta_corren  = es_cta_corren_db_autom.cod_cta_corren AND
                     es_clien_db_autom.cdn_cliente     = b-new-tit_acr.cdn_cliente             AND
                    (es_clien_db_autom.ind_situacao    = 1  OR
                     es_clien_db_autom.ind_situacao    = 2) NO-LOCK.
               
                   RUN acr/esacr054.p (INPUT ROWID(b-new-tit_acr),
                                       INPUT es_cta_corren_db_autom.cod_portador,
                                       INPUT es_cta_corren_db_autom.cod_cart_bcia).
           END.
        END.
    END. /*IF l-debito-automatico  = YES THEN*/ 
END.

//20/06/2026 - Lucas - adicionado para criar a tabela tempor�ria para liquida��o autom�tica
DEFINE VARIABLE cRaizCnpj AS CHARACTER NO-UNDO.
ASSIGN cRaizCnpj = ''.

IF  b-new-tit_acr.cod_espec_docto = 'DM' AND b-new-tit_acr.val_sdo_tit_acr > 0 THEN DO:
    
    //MESSAGE " entrou na trigger "
   //     view-as ALERT-BOX INFORMATION BUTTONS OK.
        
    
    FIND FIRST emitente WHERE emitente.cod-emitente = b-new-tit_acr.cdn_cliente NO-LOCK NO-ERROR.
    IF  AVAIL emitente THEN
    DO:
    
   // MESSAGE " entrrou na grava��o do emit"
    //    view-as ALERT-BOX INFORMATION BUTTONS OK.
    

        ASSIGN cRaizCnpj    = SUBSTRING(emitente.cgc, 1, 8).
        
        FIND FIRST es_tit_acr_abrt WHERE 
                   es_tit_acr_abrt.cod_estab       = b-new-tit_acr.cod_estab         AND
                   es_tit_acr_abrt.cod_espec_docto = b-new-tit_acr.cod_espec_docto   AND
                   es_tit_acr_abrt.cod_ser_docto   = b-new-tit_acr.cod_ser_docto     AND
                   es_tit_acr_abrt.cod_tit_acr     = b-new-tit_acr.cod_tit_acr       AND
                   es_tit_acr_abrt.cod_parcela     = b-new-tit_acr.cod_parcela       AND
                   es_tit_acr_abrt.val_pendente    = b-new-tit_acr.val_sdo_tit_acr   EXCLUSIVE-LOCK NO-ERROR.        
        
        IF NOT AVAIL es_tit_acr_abrt THEN
        DO:
            CREATE es_tit_acr_abrt.
        END.
        
/*         MESSAGE "B-NEW "               SKIP           */
/*         b-new-tit_acr.cod_estab        SKIP           */
/*         b-new-tit_acr.cod_espec_docto  SKIP           */
/*         b-new-tit_acr.cod_ser_docto    SKIP           */
/*         b-new-tit_acr.cod_tit_acr      SKIP           */
/*         b-new-tit_acr.cod_parcela      SKIP           */
/*         b-new-tit_acr.val_sdo_tit_acr  SKIP           */
/*             view-as ALERT-BOX INFORMATION BUTTONS OK. */
        

        
        ASSIGN 
        es_tit_acr_abrt.cgc             = emitente.cgc
        es_tit_acr_abrt.cgc-8char       = cRaizCnpj
        es_tit_acr_abrt.cod_estab       = b-new-tit_acr.cod_estab
        es_tit_acr_abrt.cod_espec_docto = b-new-tit_acr.cod_espec_docto
        es_tit_acr_abrt.cod_ser_docto   = b-new-tit_acr.cod_ser_docto
        es_tit_acr_abrt.cod_tit_acr     = b-new-tit_acr.cod_tit_acr
        es_tit_acr_abrt.cod_parcela     = b-new-tit_acr.cod_parcela
        es_tit_acr_abrt.val_pendente    = b-new-tit_acr.val_sdo_tit_acr. 
        
/*         MESSAGE "criou a tabela es_tit_acr_abrt"  SKIP */
/*         es_tit_acr_abrt.cgc                       SKIP */
/*         es_tit_acr_abrt.cgc-8char                 SKIP */
/*         es_tit_acr_abrt.cod_estab                 SKIP */
/*         es_tit_acr_abrt.cod_espec_docto           SKIP */
/*         es_tit_acr_abrt.cod_ser_docto             SKIP */
/*         es_tit_acr_abrt.cod_tit_acr               SKIP */
/*         es_tit_acr_abrt.cod_parcela               SKIP */
/*         es_tit_acr_abrt.val_pendente              SKIP */
/*             view-as ALERT-BOX INFORMATION BUTTONS OK.  */

    END.
END.

//20/06/2026 - Lucas - se o valor do saldo ficar zerado preciso tirar da tabela de rastreabilidade para liquida��o

/* MESSAGE "valor "  SKIP                                                              */
/* b-new-tit_acr.val_sdo_tit_acr ' <= '  0 ' AND '  b-old-tit_acr.val_sdo_tit_acr SKIP */
/* b-new-tit_acr.cod_espec_docto                                                       */
/*     view-as ALERT-BOX INFORMATION BUTTONS OK.                                       */

IF b-new-tit_acr.val_sdo_tit_acr <= 0 AND b-old-tit_acr.val_sdo_tit_acr > 0 THEN DO:
   IF b-new-tit_acr.cod_espec_docto = 'DM' THEN DO:
   
       FIND FIRST es_tit_acr_abrt WHERE 
                  es_tit_acr_abrt.cod_estab       = b-new-tit_acr.cod_estab         AND
                  es_tit_acr_abrt.cod_espec_docto = b-new-tit_acr.cod_espec_docto   AND
                  es_tit_acr_abrt.cod_ser_docto   = b-new-tit_acr.cod_ser_docto     AND
                  es_tit_acr_abrt.cod_tit_acr     = b-new-tit_acr.cod_tit_acr       AND
                  es_tit_acr_abrt.cod_parcela     = b-new-tit_acr.cod_parcela       //AND
                  //es_tit_acr_abrt.val_pendente    = b-new-tit_acr.val_sdo_tit_acr  
                  EXCLUSIVE-LOCK NO-ERROR.
       
/*        MESSAGE " procura es_tit_acr_abrt "           */
/*            view-as ALERT-BOX INFORMATION BUTTONS OK. */
       
       IF AVAIL es_tit_acr_abrt THEN
       DO:
       
/*        MESSAGE " achou es_tit_acr_abrt  "            */
/*        es_tit_acr_abrt.cod_estab       SKIP          */
/*        es_tit_acr_abrt.cod_espec_docto SKIP          */
/*        es_tit_acr_abrt.cod_ser_docto   SKIP          */
/*        es_tit_acr_abrt.cod_tit_acr     SKIP          */
/*        es_tit_acr_abrt.cod_parcela     SKIP          */
/*        es_tit_acr_abrt.val_pendente    SKIP          */
/*                                                      */
/*            view-as ALERT-BOX INFORMATION BUTTONS OK. */
       
           
       END.
       ELSE DO:
       MESSAGE "n�o achou es_tit_acr_abrt "
           view-as ALERT-BOX INFORMATION BUTTONS OK.
       
       
       END.
       
       
       
       
       
       IF AVAIL es_tit_acr_abrt THEN
       DO:
       
/*            MESSAGE " delete " SKIP                       */
/*            es_tit_acr_abrt.cod_estab        SKIP         */
/*            es_tit_acr_abrt.cod_espec_docto  SKIP         */
/*            es_tit_acr_abrt.cod_ser_docto    SKIP         */
/*            es_tit_acr_abrt.cod_tit_acr      SKIP         */
/*            es_tit_acr_abrt.cod_parcela      SKIP         */
/*            es_tit_acr_abrt.val_pendente     SKIP         */
/*                view-as ALERT-BOX INFORMATION BUTTONS OK. */

           DELETE es_tit_acr_abrt.
           
       END.
                  
                  
                  
   
   END.
END.






/*gerar numero bancario apenas para portadores bancarios quando novo registro ou alteracao de portador nao-bancario para portador bancario*/
IF  (NEW(b-new-tit_acr) AND
     (b-new-tit_acr.ind_orig_tit_acr BEGINS 'ACR' OR
      b-new-tit_acr.ind_orig_tit_acr BEGINS 'CMG') OR
     NOT NEW(b-new-tit_acr) AND
     NOT fn-portador-bancario-ems5(b-old-tit_acr.cod_estab,
                                   b-old-tit_acr.cod_portador,
                                   b-old-tit_acr.cod_cart_bcia,
                                   b-old-tit_acr.cod_indic_econ,
                                   b-old-tit_acr.dat_emis_docto)) AND
    fn-portador-bancario-ems5(b-new-tit_acr.cod_estab,
                              b-new-tit_acr.cod_portador,
                              b-new-tit_acr.cod_cart_bcia,
                              b-new-tit_acr.cod_indic_econ,
                              b-new-tit_acr.dat_emis_docto) THEN DO:
    ASSIGN b-new-tit_acr.cod_tit_acr_bco = fn-numero-bancario-ems5(b-new-tit_acr.cod_estab,
                                                                   b-new-tit_acr.cod_portador,
                                                                   b-new-tit_acr.cod_cart_bcia,
                                                                   b-new-tit_acr.cod_indic_econ,
                                                                   b-new-tit_acr.dat_emis_docto).

END.

/*  Denis Berteli - 1/11/2019
    exluido objeto antes do proximo if:
    O bloco abaixo n�o usa e n�o deixa finalizar o objeto.
    Analisa se esse bloco abaixo poder� ser excluido quando a area do cliente entrar em produ��o */

 

/*gerar dados para a tabela "ES-WEBSITE-MOVTO" para transferencia de T�tulos para o Web Site*/
IF NEW(b-new-tit_acr) OR NOT NEW(b-new-tit_acr) THEN DO:
    
    IF b-new-tit_Acr.cod_espec_docto <> 'NC' THEN
        ASSIGN b-new-tit_acr.val_ajust_val_tit_acr = b-new-tit_acr.val_sdo_tit_acr - b-new-tit_acr.val_origin_tit_acr .

   /****** retirado em 31/5/2021 - Denis Berteli - Consigaz
   Essa tabela n�o � mais usada porque a area do cliente nao utiliza
   IF b-new-tit_acr.cod_espec_docto <> 'DM' THEN NEXT.

   FIND FIRST portad_edi  
        WHERE portad_edi.cod_modul_dtsul = 'ACR'                   
          AND portad_edi.cod_estab       =  b-new-tit_acr.cod_estab     
          AND portad_edi.cod_portador    =  b-new-tit_acr.cod_portador    
          AND portad_edi.cod_cart_bcia   =  b-new-tit_acr.cod_cart_bcia NO-LOCK NO-ERROR.

   IF NOT AVAIL portad_edi THEN NEXT.

   FIND FIRST portad_finalid_econ  
        WHERE portad_finalid_econ.cod_estab        = b-new-tit_acr.cod_estab     
          AND portad_finalid_econ.cod_portador     = b-new-tit_acr.cod_portador  
          AND portad_finalid_econ.cod_cart_bcia    = b-new-tit_acr.cod_cart_bcia 
          AND portad_finalid_econ.cod_finalid_econ = portad_edi.cod_finalid_econ NO-LOCK NO-ERROR.
   IF NOT AVAIL portad_finalid_econ THEN NEXT.

   FIND FIRST cta_corren  
        WHERE cta_corren.cod_cta_corren = portad_finalid_econ.cod_cta_corren NO-LOCK NO-ERROR.
   IF NOT AVAIL cta_corren THEN NEXT.

   FIND FIRST param_integr_ems
        WHERE param_integr_ems.ind_param_integr_ems  = 'Faturamento 2.00' NO-LOCK NO-ERROR.
   IF NOT AVAIL param_integr_ems THEN DO:
      MESSAGE "N�o achou par�metro de integra��o EMS - Faturamento 2.00" VIEW-AS ALERT-BOX INFO BUTTONS OK.
      NEXT.
   END.

   FIND FIRST trad_org_ext 
        WHERE trad_org_ext.cod_matriz_trad_org_ext = param_integr_ems.des_contdo_param_integr_ems
          AND trad_org_ext.cod_tip_unid_organ      = '999' 
          AND trad_org_ext.cod_unid_organ          = b-new-tit_acr.cod_estab NO-LOCK NO-ERROR.
   IF NOT AVAIL trad_org_ext THEN DO: 
      MESSAGE "N�o achou o Estabelecimeto Externo  = "  b-new-tit_acr.cod_estab  VIEW-AS ALERT-BOX INFO BUTTONS OK.
      NEXT.
   END.

   FIND FIRST nota-fiscal
        WHERE nota-fiscal.cod-estabel  = trad_org_ext.cod_unid_organ_ext
          AND nota-fiscal.serie        = b-new-tit_acr.cod_ser_docto
          AND nota-fiscal.nr-fatura    = b-new-tit_acr.cod_tit_acr 
          AND nota-fiscal.cod-emitente = b-new-tit_acr.cdn_cliente NO-LOCK NO-ERROR.

   IF NOT AVAIL nota-fiscal THEN NEXT.           /* Nao achou NOTA FISCAL */

   IF nota-fiscal.dt-cancela <> ? THEN NEXT.     /* Ignora Nota Cancelada */

   IF nota-fiscal.cod-emitente = 6659 THEN NEXT. /* ignora vendas balcao  */

   FIND FIRST emitente
        WHERE emitente.cod-emitente = nota-fiscal.cod-emitente NO-LOCK NO-ERROR.
   IF NOT AVAIL emitente THEN NEXT.

/*
   IF CAN-FIND(FIRST estabelec 
               WHERE estabelec.cod-emitente = nota-fiscal.cod-emitente) THEN NEXT.

   FIND FIRST mgcad.estabelec 
        WHERE mgcad.estabelec.cod-estabel = nota-fiscal.cod-estabel NO-LOCK NO-ERROR. 
   IF NOT AVAIL mgcad.estabelec THEN NEXT.
*/
   FIND FIRST es-instalacao-csim
        WHERE es-instalacao-csim.cod-emitente = emitente.cod-emitente NO-LOCK NO-ERROR.
   IF AVAIL es-instalacao-csim THEN 
      IF es-instalacao-csim.situacao = 4 THEN
         ASSIGN c-impr = NO.
      ELSE
         ASSIGN c-impr = YES.
   ELSE
      ASSIGN c-impr = YES.

   FIND FIRST es-website-movto
        WHERE es-website-movto.cod_estab      = b-new-tit_acr.cod_estab
          AND es-website-movto.num_id_tit_acr = b-new-tit_acr.num_id_tit_acr NO-ERROR.

   IF NOT AVAIL es-website-movto THEN DO:
      CREATE es-website-movto.
      ASSIGN es-website-movto.cod_estab       = b-new-tit_acr.cod_estab
             es-website-movto.num_id_tit_acr  = b-new-tit_acr.num_id_tit_acr.
   END.
   ASSIGN es-website-movto.dat_gerac_movto = TODAY                        
          es-website-movto.hra_gerac_movto = STRING(TIME,"HH:MM:SS") 
          es-website-movto.ind-lib-imp     = c-impr  
          es-website-movto.nome-abrev      = emitente.nome-abrev
          es-website-movto.cod-entrega     = nota-fiscal.cod-entrega.
   */
END.

IF NOT NEW(b-new-tit_acr) AND 
   b-new-tit_acr.cod_tit_acr_bco <> b-old-tit_acr.cod_tit_acr_bco THEN
DO:
    CREATE es-log_acr.
    ASSIGN es-log_acr.nome-tabela = "tit_acr"
           es-log_acr.nome-campo = "cod_tit_acr_bco"
           es-log_acr.vl-atual = b-new-tit_acr.cod_tit_acr_bco 
           es-log_acr.vl-anterior = b-old-tit_acr.cod_tit_acr_bco
           es-log_acr.usuario = c-seg-usuario
           es-log_acr.Data = TODAY
           es-log_acr.hora = STRING(TIME, "HH:MM:SS")
           es-log_acr.seq = NEXT-VALUE(seq-log-acr)
           //es-log_acr.ip = ""          
           //es-log_acr.nome-pc = ""
           es-log_acr.r-rowid = STRING(ROWID(b-new-tit_acr))
           es-log_acr.acao = "Alteracao Nr Bancario titulo: " + b-new-tit_acr.cod_estab + "|" ~
                                                              + b-new-tit_acr.cod_espec_docto + "|" ~
                                                              + b-new-tit_acr.cod_ser_docto + "|" ~
                                                              + b-new-tit_acr.cod_tit_acr + "|" ~
                                                              + b-new-tit_acr.cod_parcela.
    
    DO WHILE PROGRAM-NAME(i-contador) <> ?:
       ASSIGN i-contador = i-contador + 1.

       IF PROGRAM-NAME(i-contador) <> ? THEN
           ASSIGN es-log_acr.programa = es-log_acr.programa + PROGRAM-NAME(i-contador) + CHR(10).
    END.    
END.

RETURN 'OK':U.


/* Carlos - Grupo MIR - 02/07/2021 - Declaracoes de Funcoes para nao chamar mais ESACR001 em modo persistent */
FUNCTION fn-portador-bancario-ems5 RETURNS LOGICAL (c_cod_estab         AS CHARACTER,
                                                    c_cod_portador      AS CHARACTER,
                                                    c_cod_cart_bcia     AS CHARACTER,
                                                    c_cod_indic_econ    AS CHARACTER,
                                                    da_dat_emis_docto   AS DATE):

    RETURN
        CAN-FIND(FIRST histor_finalid_econ WHERE
                 histor_finalid_econ.cod_indic_econ          = c_cod_indic_econ AND
                 histor_finalid_econ.dat_inic_valid_finalid  <= da_dat_emis_docto AND
                 histor_finalid_econ.dat_fim_valid_finalid   >= da_dat_emis_docto AND
                 CAN-FIND(FIRST portad_bco WHERE
                          portad_bco.cod_modul_dtsul  = 'ACR' AND
                          portad_bco.cod_estab        = c_cod_estab AND
                          portad_bco.cod_portador     = c_cod_portador AND
                          portad_bco.cod_cart_bcia    = c_cod_cart_bcia AND
                          portad_bco.cod_finalid_econ = histor_finalid_econ.cod_finalid_econ NO-LOCK) NO-LOCK).

END FUNCTION.


FUNCTION fn-numero-bancario-ems5 RETURNS CHARACTER (c_cod_estab         AS CHARACTER,
                                                    c_cod_portador      AS CHARACTER,
                                                    c_cod_cart_bcia     AS CHARACTER,
                                                    c_cod_indic_econ    AS CHARACTER,
                                                    da_dat_emis_docto   AS DATE):

    FIND histor_finalid_econ WHERE
        histor_finalid_econ.cod_indic_econ          = c_cod_indic_econ AND
        histor_finalid_econ.dat_inic_valid_finalid  <= da_dat_emis_docto AND
        histor_finalid_econ.dat_fim_valid_finalid   >= da_dat_emis_docto NO-LOCK NO-ERROR.

    RETURN fn-numero-bancario (c_cod_estab,
                               c_cod_portador,
                               c_cod_cart_bcia,
                               (IF AVAIL histor_finalid_econ THEN histor_finalid_econ.cod_finalid_econ ELSE '')).

END FUNCTION.

FUNCTION fn-numero-bancario RETURNS CHARACTER (c_cod_estab        AS CHARACTER,
                                               c_cod_portador     AS CHARACTER,
                                               c_cod_cart_bcia    AS CHARACTER,
                                               c_cod_finalid_econ AS CHARACTER):

    /*definicao de variaveis*/
    /*DEFINE VARIABLE c_param_portad_edi  AS CHARACTER    NO-UNDO EXTENT 11.*/
    DEFINE VARIABLE c_cod_tit_acr_bco   AS CHARACTER    NO-UNDO.

    RUN pi-parametros-portador-edi (INPUT 'ACR',
                                    INPUT c_cod_estab,
                                    INPUT c_cod_portador,
                                    INPUT c_cod_cart_bcia,
                                    INPUT c_cod_finalid_econ,
                                    OUTPUT c_param_portad_edi).

    FOR FIRST emscad.portador FIELDS(cod_banco) WHERE
        emscad.portador.cod_portador = c_cod_portador NO-LOCK:

        CASE emscad.portador.cod_banco:

            WHEN '1' THEN
                ASSIGN c_cod_tit_acr_bco = c_param_portad_edi[1] + STRING(NEXT-VALUE(nr-seq-boleto),FILL('9',10)).

            WHEN '33' THEN
                ASSIGN c_cod_tit_acr_bco = STRING(NEXT-VALUE(nr-seq-boleto),FILL('9',7))
                       c_cod_tit_acr_bco = c_cod_tit_acr_bco + fn-digito-verificador-modulo-11(c_cod_tit_acr_bco,9,emscad.portador.cod_banco).

            WHEN '237' THEN
                ASSIGN c_cod_tit_acr_bco = STRING(NEXT-VALUE(nr-seq-boleto),FILL('9',11))
                       c_cod_tit_acr_bco = c_cod_tit_acr_bco + fn-digito-verificador-modulo-11(c_param_portad_edi[2] + c_cod_tit_acr_bco,7,emscad.portador.cod_banco).

            WHEN '341' THEN
                ASSIGN c_cod_tit_acr_bco = STRING(NEXT-VALUE(nr-seq-boleto),FILL('9',8))
                       c_cod_tit_acr_bco = c_cod_tit_acr_bco + fn-digito-verificador-modulo-10(c_cod_tit_acr_bco).

            WHEN '104' THEN
                ASSIGN c_cod_tit_acr_bco = '14' + STRING(NEXT-VALUE(nr-seq-boleto),FILL('9',15)).

            WHEN '21' OR 
            WHEN '021' THEN
                ASSIGN c_cod_tit_acr_bco = STRING(NEXT-VALUE(nr-seq-boleto),FILL('9',8))
                       c_cod_tit_acr_bco = c_cod_tit_acr_bco + fn-digito-verificador-modulo-11(c_cod_tit_acr_bco,9,'33')
                       c_cod_tit_acr_bco = c_cod_tit_acr_bco + fn-digito-verificador-modulo-11(c_cod_tit_acr_bco,10,'33').
            
            WHEN '41' OR 
            WHEN '041' THEN
                ASSIGN c_cod_tit_acr_bco = STRING(NEXT-VALUE(nr-seq-boleto),FILL('9',8))
                       c_cod_tit_acr_bco = c_cod_tit_acr_bco + fn-digito-verificador-modulo-10(c_cod_tit_acr_bco)
                       c_cod_tit_acr_bco = c_cod_tit_acr_bco + fn-digito-verificador-modulo-11(c_cod_tit_acr_bco,7,'33').

            WHEN '756' THEN
                ASSIGN c_cod_tit_acr_bco = STRING(NEXT-VALUE(nr-seq-boleto),FILL('9',7))
                       c_cod_tit_acr_bco = c_cod_tit_acr_bco + fn-digito-verificador-modulo-11(INPUT c_cod_tit_acr_bco, INPUT 1, INPUT '756').

            OTHERWISE
                ASSIGN c_cod_tit_acr_bco = ''.

        END CASE.

    END.

    RETURN c_cod_tit_acr_bco.

END FUNCTION.

PROCEDURE pi-parametros-portador-edi:

    /********************************************** PARAMETROS PORTADOR EDI ***************************************************
    1 - Convenio            4 - Tipo Servico            7 - Sigla Empresa                   10 - Numero da Carteira
    2 - Carteira Banco      5 - Conta Complementar      8 - Variacao                        11 - Sequencia Lote Estorno
    3 - Esp�cie Banco       6 - Codigo Empresa          9 - Codigo de Responsabilidade
    **************************************************************************************************************************/

    /*definicao de parametros*/
    DEFINE INPUT PARAMETER p_cod_modul_dtsul        LIKE portad_edi.cod_modul_dtsul     NO-UNDO.
    DEFINE INPUT PARAMETER p_cod_estab              LIKE portad_edi.cod_estab           NO-UNDO.
    DEFINE INPUT PARAMETER p_cod_portador           LIKE portad_edi.cod_portador        NO-UNDO.
    DEFINE INPUT PARAMETER p_cod_cart_bcia          LIKE portad_edi.cod_cart_bcia       NO-UNDO.
    DEFINE INPUT PARAMETER p_cod_finalid_econ       LIKE portad_edi.cod_finalid_econ    NO-UNDO.
    DEFINE OUTPUT PARAMETER p_param_portad_edi      AS CHARACTER                        NO-UNDO EXTENT 11.

    /*definicao de variaveis*/
    DEFINE VARIABLE i-cont  AS INTEGER  NO-UNDO.

    FOR FIRST portad_edi WHERE
        portad_edi.cod_modul_dtsul  = p_cod_modul_dtsul AND
        portad_edi.cod_estab        = p_cod_estab AND
        portad_edi.cod_portador     = p_cod_portador AND
        portad_edi.cod_cart_bcia    = p_cod_cart_bcia AND
        portad_edi.cod_finalid_econ = p_cod_finalid_econ NO-LOCK:

        DO i-cont = 1 TO EXTENT(p_param_portad_edi):

            IF NUM-ENTRIES(portad_edi.des_tip_var_portad_edi,CHR(10)) >= i-cont THEN
                ASSIGN p_param_portad_edi[i-cont] = ENTRY(i-cont,portad_edi.des_tip_var_portad_edi,CHR(10)).

        END.

    END.

END PROCEDURE.

FUNCTION fn-digito-verificador-modulo-10 RETURNS CHARACTER (c-numero AS CHARACTER):

    /*definicao de variaveis*/
    DEFINE VARIABLE i-cont              AS INTEGER  NO-UNDO INITIAL 0.
    DEFINE VARIABLE l-fator-2           AS LOGICAL  NO-UNDO INITIAL NO.
    DEFINE VARIABLE i-result-parcial    AS INTEGER  NO-UNDO INITIAL 0.
    DEFINE VARIABLE i-resultado         AS INTEGER  NO-UNDO INITIAL 0.

    DO i-cont = LENGTH(c-numero) TO 1 BY -1:

        ASSIGN l-fator-2        = NOT l-fator-2
               i-result-parcial = INTEGER(SUBSTRING(c-numero,i-cont,1)) * (IF l-fator-2 THEN 2 ELSE 1)
               i-resultado      = i-resultado + i-result-parcial - (IF i-result-parcial > 9 THEN 9 ELSE 0).

    END.

    ASSIGN i-resultado = i-resultado MOD 10.

    IF i-resultado > 0 THEN
        ASSIGN i-resultado = 10 - i-resultado.

    RETURN STRING(i-resultado).

END FUNCTION.

FUNCTION fn-digito-verificador-modulo-11 RETURNS CHARACTER (c-numero    AS CHARACTER,
                                                            i-base      AS INTEGER,
                                                            c-parametro AS CHARACTER):

    /*definicao de variaveis*/
    DEFINE VARIABLE i-cont      AS INTEGER  NO-UNDO INITIAL 0.
    DEFINE VARIABLE i-fator     AS INTEGER  NO-UNDO INITIAL 1.
    DEFINE VARIABLE i-resultado AS INTEGER  NO-UNDO INITIAL 0.
    DEFINE VARIABLE c-fator-341 AS CHAR     NO-UNDO INITIAL "4329876543298765432987654329876543298765432".
    DEFINE VARIABLE c-fator-756 AS CHAR     NO-UNDO INITIAL "319731973197319731973".
                                                             
    DEFINE VARIABLE c-aux AS CHARACTER   NO-UNDO.
/*     c-cod_barra_bco-aux = "3419166700000123451101234567880057123457000".  */

    c-aux = "".
    
    DO i-cont = LENGTH(c-numero) TO 1 BY -1:

        ASSIGN i-fator      = (IF i-fator = i-base THEN 1 ELSE i-fator) + 1
               i-resultado  = i-resultado + INTEGER(SUBSTRING(c-numero,i-cont,1)) * i-fator.
        c-aux = c-aux + STRING(i-fator).
    END.

/* PUT  UNFORMATTED "c-aux 1: " + c-aux SKIP.  */

/*     IF i-cod-banco-aux = 341 /*341-Itau*/ THEN DO:                                                                      */
/*        ASSIGN i-resultado = 0.                                                                                          */
/*        DO i-cont = 1 TO 43:                                                                                             */
/*           i-resultado = i-resultado + (int(SUBSTR(c-cod_barra_bco-aux,i-cont,1)) * int(SUBSTR(c-fator-341,i-cont,1))).  */
/*        END.                                                                                                             */
/*     END.                                                                                                                */

    IF c-parametro = '756' THEN
    DO:
        ASSIGN c-numero = STRING(INT(c_param_portad_edi[3]),'9999') + STRING(INT(c_param_portad_edi[1]),'9999999999') + c-numero.
        ASSIGN i-resultado = 0.
        DO i-cont = 1 TO LENGTH(c-numero):
            ASSIGN i-resultado  = i-resultado + (INTEGER(SUBSTRING(c-numero,i-cont,1)) * INTEGER(SUBSTRING(c-fator-756,i-cont,1))).
        END.
    END.

    ASSIGN i-resultado = i-resultado MOD 11.

    IF i-resultado = 0 THEN DO:

        CASE c-parametro:

            WHEN 'CodigoBarra' THEN
                RETURN '1'.

            WHEN '33' OR
            WHEN '237' OR 
            WHEN 'DA237' OR
            WHEN '756' THEN
                RETURN '0'.

        END CASE.

    END.

    IF i-resultado = 1 THEN DO:

        CASE c-parametro:

            WHEN 'CodigoBarra' THEN
                RETURN '1'.

            WHEN '33' OR
            WHEN 'DA237' OR
            WHEN '756' THEN
                RETURN '0'.

            WHEN '237' THEN
                RETURN 'P'.

        END CASE.

    END.

    RETURN STRING(11 - i-resultado).

END FUNCTION.
/* Carlos - Grupo MIR - 02/07/2021 - Declaracoes de Funcoes para nao chamar mais ESACR001 em modo persistent */

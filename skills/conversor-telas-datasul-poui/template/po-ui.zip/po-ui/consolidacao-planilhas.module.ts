import { NgModule, LOCALE_ID } from '@angular/core';
import { CommonModule, registerLocaleData } from '@angular/common';
import localePt from '@angular/common/locales/pt';
import { FormsModule } from '@angular/forms';

// Registra o locale pt-BR para que as colunas de data (po-table type:'date')
// e pipes de data/moeda exibam no formato brasileiro (dd/MM/yyyy), evitando o
// padrão en-US (MM/dd/yyyy) que invertia dia/mês.
registerLocaleData(localePt, 'pt-BR');
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';

import { PoModule, PoI18nModule, PoI18nConfig } from '@po-ui/ng-components';
import { DtsBackofficeUtilsModule } from 'dts-backoffice-util';

import { ConsolidacaoPlanilhasComponent } from './consolidacao-planilhas.component';
import { ConsolidacaoPlanilhasService } from './consolidacao-planilhas.service';
import { DatasulAuthInterceptor } from './auth.interceptor';

/**
 * Configuração mínima de i18n do PO-UI.
 * Necessária para que o PoI18nService (usado internamente pelo
 * TotvsScheduleExecutionComponent da dts-backoffice-util) encontre
 * o InjectionToken I18N_CONFIG no injetor.
 *
 * O componente de agendamento RPW usa o i18n para traduzir seus
 * próprios labels — não é necessário fornecer arquivos de tradução
 * customizados para a aplicação funcionar.
 */
const i18nConfig: PoI18nConfig = {
  default: {
    language: 'pt',
    context:  'general',
    cache:    true
  },
  contexts: {
    general: {
      pt: {}
    }
  }
};

@NgModule({
  declarations: [
    ConsolidacaoPlanilhasComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    HttpClientModule,
    PoModule,
    PoI18nModule.config(i18nConfig),   // ← provê InjectionToken I18N_CONFIG
    DtsBackofficeUtilsModule.forRoot()
  ],
  providers: [
    ConsolidacaoPlanilhasService,
    { provide: LOCALE_ID, useValue: 'pt-BR' },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: DatasulAuthInterceptor,
      multi: true
    }
  ],
  exports: [
    ConsolidacaoPlanilhasComponent
  ]
})
export class ConsolidacaoPlanilhasModule { }

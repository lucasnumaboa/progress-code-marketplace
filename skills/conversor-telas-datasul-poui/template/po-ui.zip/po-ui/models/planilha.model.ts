/**
 * Model: Planilha (Título a Receber importado)
 * Representa um registro retornado pelo endpoint /importaTituloAcr.
 *
 * Todos os campos refletem exatamente o contrato da API PASOE.
 * O campo `id` é gerado pelo frontend como chave composta para
 * seleção e ações em lote na tabela PO-UI.
 */
export interface Planilha {
  /** Indica se a linha está selecionada na tabela PO-UI */
  $selected?: boolean;

  /**
   * Identificador composto gerado no frontend.
   * Formato: `codEmpresa|codEstab|codTitAcr|codParcela`
   * Usado nas ações em lote (processar, remover).
   */
  id: string;

  // ── Identificação do título ──────────────────────
  codEmpresa: string;
  codEstab: string;
  codTitAcr: string;
  codParcela: string;
  codEspecDocto: string;
  codSerDocto: string;
  codPortador: string;
  codCartBcia: string;

  // ── Valores financeiros ──────────────────────────
  valRecebido: number;
  valDesconto: number;
  valAbatimento: number;
  valJuros: number;
  valMulta: number;

  // ── Datas e horas ────────────────────────────────
  datImportacao: string;
  hraImportacao: string;
  datGeracao: string;
  datProcessamento: string;
  hraProcessamento: string;

  // ── Cliente ──────────────────────────────────────
  codCliente: string;
  nomeEmit: string;    // nome do emitente/cliente
  cgc: string;    // CNPJ ou CPF do cliente

  // ── Coluna de ação (valor ativa ícone type:'icon' no PO-UI) ──
  acoes?: string;

  // ── Status e rastreabilidade ─────────────────────
  indSitImportacao: StatusPlanilha;
  desMensagemErro: string;
  numLoteImportacao: number;
  codArqOrigem: string;
  codUsuarioImport: string;

  /**
   * Tipo de liquidação do título vinculado, calculado no backend:
   * 'integral' quando o valor apontado é igual ao saldo do título no CR,
   * 'parcial' quando é a menor. Vazio quando ainda não há título vinculado.
   */
  tipoLiquidacao?: 'integral' | 'parcial' | '';

  /** Número do lote (importação por lote), extraído do cod_arq_origem. Vazio até o processamento gravar a referência. */
  numLote?: string;

  /** Indica que o título é de importação por lote (marcador "Lote:" no cod_arq_origem). */
  isLote?: boolean;
}

/**
 * Representa um cliente agrupado na tela principal.
 * Cada linha do grid home é um cliente com os totais somados de seus títulos.
 * Retornado pelo endpoint GET /clientes (agrupamento server-side por CGC).
 */
export interface ClienteAgrupado {
  $selected?: boolean;

  /** Chave de agrupamento — igual ao `cgc` (mantido por conveniência da po-table) */
  id: string;

  cgc: string;
  nomeEmit: string;

  /** Data de importação do registro mais recente do cliente (ISO yyyy-mm-dd) */
  dataImportacao: string;

  /** Soma de `valRecebido` dos títulos do cliente que casam com o filtro/aba ativa */
  valor: number;

  /** Soma de `es_tit_acr_abrt.val_pendente` do cliente — saldo em aberto ainda não baixado */
  valorEmAberto: number;

  /** Soma de `es_tit_acr_abrt.val_pendente` apenas dos títulos AD (espécie "AD") do cliente */
  valorEmAbertoAd: number;

  /** Quantidade de títulos do cliente que casam com o filtro/aba ativa */
  qtdTitulos: number;

  /** `true` quando o cliente possui algum documento com título vinculado — habilita a coluna "Títulos" */
  temTitulo?: boolean;

  /** `true` quando o cliente possui algum título AD (adiantamento) com saldo — habilita a coluna "AD" */
  temAd?: boolean;

  /** Rótulo fixo usado pela coluna type:'link' de "Detalhes" na po-table */
  detalhesLabel?: string;

  /** Rótulo fixo usado pela coluna type:'link' de "AD" na po-table */
  adLabel?: string;
}

/**
 * Envelope de resposta paginada do endpoint GET /clientes.
 */
export interface ClientesPaginacaoResponse {
  items: ClienteAgrupado[];
  totalItens: number;
  pagina: number;
  itensPorPagina: number;
  hasNext: boolean;
}

/**
 * Título de Adiantamento (AD) com saldo disponível para um cliente —
 * usado na aba "Grupo AD" do modal de detalhes, para relacionar/baixar
 * títulos manualmente. Retornado por GET /clientes-ad?cgc=...
 */
export interface AdTitulo {
  $selected?: boolean;
  id?: string;

  codEstab: string;
  codEspecDocto: string;
  codSerDocto: string;
  codTitAcr: string;
  codParcela: string;

  /** Data de emissão do título AD (ISO yyyy-mm-dd) */
  datEmisDocto: string;

  /** Valor original do título AD */
  valTitAcr: number;

  /** Valor do adiantamento (val_recebido do registro importado) */
  valSdoTitAcr: number;

  /** Situação da importação do registro AD (Pendente/Importado/Erro) */
  status: StatusPlanilha;

  /**
   * Observação do adiantamento — vem da 2ª coluna (B, "Lançamento") do
   * Excel importado, gravada em `cod_arq_origem` após o "|".
   */
  observacoes?: string;
}

/**
 * Valores possíveis do campo `indSitImportacao` retornado pela API.
 */
export type StatusPlanilha = 'Pendente' | 'Importado' | 'Erro' | 'Processando';

/**
 * Model: Empresa — usado no filtro de empresas.
 * A API retorna apenas o código da empresa.
 */
export interface Empresa {
  codEmpresa: string;
  descricao: string;
}

/**
 * Contadores de registros por status — retornados pela API
 * para popular as abas sem precisar carregar todos os registros.
 */
export interface ContadoresApi {
  todas: number;
  pendentes: number;
  processadas: number;
  comErro: number;
}

/**
 * Parâmetros de paginação enviados à API.
 */
export interface PaginacaoParams {
  pagina: number;
  itensPorPagina: number;
  empresa?: string;
  status?: StatusPlanilha;
  cgc?: string;
  nomeEmit?: string;
  dataIni?: string;
  dataFim?: string;
  codTitAcr?: string;
  codEstab?: string;
  codSerDocto?: string;
}

/**
 * Envelope de resposta paginada da API — estrutura retornada
 * pelo endpoint raiz de importaTituloAcr.
 */
export interface PaginacaoResponse {
  items: Planilha[];
  totalItens: number;
  pagina: number;
  itensPorPagina: number;
  totalPaginas: number;
  hasNext: boolean;
}

/**
 * Progresso de processamento de um lote — usado no polling.
 */
export interface ProgressoProcessamento {
  ids: string[];
  totalRegistros: number;
  processados: number;
  comErro: number;
  status: 'processando' | 'concluido' | 'erro';
  percentual: number;
  mensagem?: string;
}

/**
 * Payload para remover registros em lote.
 */
export interface LoteRequest {
  ids: string[];
}

/**
 * Payload para processar clientes em lote — envia a lista de CGCs selecionados.
 */
export interface LoteRequestProcessar {
  cgcs: string[];
}

/**
 * Resposta padrão da API Progress 4GL.
 */
export interface ApiResponse<T = any> {
  success: boolean;
  message?: string;
  data?: T;
}

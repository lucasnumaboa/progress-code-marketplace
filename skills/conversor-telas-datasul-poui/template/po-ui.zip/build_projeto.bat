@echo off
setlocal

echo =======================================================
echo  Build do Projeto po-ui (Producao)
echo =======================================================

rem ---------------------------------------------------------------
rem  A raiz e sempre a pasta onde ESTE .bat esta gravado.
rem  Assim o projeto pode ser movido de lugar sem editar o script.
rem ---------------------------------------------------------------
set "RAIZ=%~dp0"
if "%RAIZ:~-1%"=="\" set "RAIZ=%RAIZ:~0,-1%"

echo.
echo Raiz .....: %RAIZ%

rem --- 1) Procura "po-ui" como subpasta direta da raiz -------------
set "PROJETO="
if exist "%RAIZ%\po-ui\package.json" set "PROJETO=%RAIZ%\po-ui"

rem --- 2) Fallback: procura "po-ui" em qualquer nivel abaixo -------
if not defined PROJETO (
  for /f "delims=" %%D in ('dir /b /s /ad "%RAIZ%\po-ui" 2^>nul') do (
    if not defined PROJETO if exist "%%D\package.json" set "PROJETO=%%D"
  )
)

if not defined PROJETO (
  echo.
  echo [ERRO] Nao encontrei uma pasta "po-ui" com package.json dentro de:
  echo        %RAIZ%
  goto :fim
)

echo Projeto ..: %PROJETO%

cd /d "%PROJETO%"
if errorlevel 1 goto :erro

rem --- Instala dependencias apenas na primeira vez -----------------
if not exist "node_modules" (
  echo.
  echo node_modules nao encontrado. Instalando dependencias...
  echo [npm install --legacy-peer-deps]
  call npm install --legacy-peer-deps --no-audit --no-fund
  if errorlevel 1 goto :erro
)

echo.
echo Executando: npm run build:prod
call npm run build:prod
if errorlevel 1 goto :erro

rem --- Gera o WAR se o script for chamado como: build_projeto.bat war
if /i "%~1"=="war" (
  echo.
  echo Empacotando o WAR para o Tomcat...
  call npm run build:war
  if errorlevel 1 goto :erro
)

echo.
echo =======================================================
echo  Build finalizado com sucesso!
echo  Saida: %PROJETO%\dist
echo =======================================================
goto :fim

:erro
echo.
echo =======================================================
echo  [ERRO] O build falhou. Veja as mensagens acima.
echo =======================================================

:fim
echo.
pause
endlocal

---
name: web-scraping-estruturado
description: Extrai dados de páginas web de forma estruturada com requests + BeautifulSoup (paginação, tabelas HTML, cache, limites, respeito a robots.txt), sem precisar instalar um navegador automatizado. Use quando o usuário pedir para "extrair dados desse site", "pegar essa tabela da página", "baixar essas informações do portal" — quando o site depende pesadamente de JavaScript para renderizar o conteúdo (a página vem vazia com `requests`), é necessário automação de navegador de verdade (skill `automatizar-navegador-playwright`, que depende de instalar binários de navegador — confirme com o usuário antes).
argument-hint: [URL] [dados a extrair]
---

# Web scraping estruturado (requests + BeautifulSoup)

## Passo 1 — Instalar
```
pip install requests beautifulsoup4 lxml
```

## Passo 2 — Antes de tudo: confira `robots.txt` e os termos de uso
```python
import requests
robots = requests.get("https://exemplo.com/robots.txt").text
print(robots)
```
Se `robots.txt` proibir explicitamente o caminho que você quer acessar (`Disallow: /caminho`), não faça scraping
ali — avise o usuário. Isso vale independente de o site ter ou não proteção técnica contra scraping.

## Passo 3 — Buscar e verificar se veio conteúdo de verdade
```python
resp = requests.get(url, headers={"User-Agent": "Mozilla/5.0 (compatible; pesquisa-interna/1.0)"}, timeout=15)
resp.raise_for_status()

from bs4 import BeautifulSoup
sopa = BeautifulSoup(resp.text, "lxml")
```
Se o conteúdo esperado não aparecer no HTML retornado (confira com `print(sopa.prettify()[:2000])`), o site
provavelmente renderiza via JavaScript no navegador — `requests` só baixa o HTML inicial, não executa JS. Nesse
caso, PARE e avise o usuário que precisa de automação de navegador (dependência externa, pedir confirmação).

## Passo 4 — Extrair tabela HTML
```python
import pandas as pd
tabelas = pd.read_html(str(sopa.find("table", {"id": "tabela-dados"})))
df = tabelas[0]
```
`pd.read_html` já lida com a maioria das tabelas HTML bem formadas — só caia para navegação manual de `<tr>`/`<td>`
com BeautifulSoup se a tabela tiver estrutura irregular (`colspan`/`rowspan` complexos) que confunda o `pd.read_html`.

## Passo 5 — Paginação
```python
pagina = 1
todos_os_dados = []
while True:
    resp = requests.get(f"{url_base}?pagina={pagina}", timeout=15)
    sopa = BeautifulSoup(resp.text, "lxml")
    itens = sopa.select(".item-lista")
    if not itens:
        break
    todos_os_dados.extend(extrair_itens(itens))
    pagina += 1
    time.sleep(1)  # respeitar o servidor - nao bombardear requisicoes
```
Sempre tenha uma condição de parada clara (página sem itens, ou um limite máximo de páginas como salvaguarda) para
não entrar em loop infinito se a paginação nunca "acabar" por algum erro de lógica.

## Passo 6 — Cache (não repetir requisição desnecessária)
Salve cada resposta bruta (HTML) em disco/SQLite antes de processar, com a URL como chave — permite reprocessar a
extração sem bater no site de novo se o parsing precisar de ajuste.

## Regras
- Sempre coloque `time.sleep` entre requisições em loop (1-2 segundos é um ponto de partida razoável) — bombardear
  um site sem pausa pode ser tratado como ataque e derrubar o serviço ou bloquear seu IP.
- Login em sites de terceiros: nunca automatize login guardando senha em texto no código — se o scraping exige
  login, pare e pergunte como o usuário quer lidar com as credenciais.
- Sempre verifique se existe uma API oficial antes de fazer scraping — API é mais estável e não corre risco de
  quebrar quando o site mudar o HTML.

## Arquivos desta skill
Nenhum script fixo — os trechos acima cobrem o fluxo completo; adapte à estrutura real da página do usuário.

"""Operacoes basicas de PDF via pypdf: juntar, dividir, girar.

Uso:
    python operacoes_pdf.py juntar a.pdf b.pdf --saida junto.pdf
    python operacoes_pdf.py dividir junto.pdf --saida-pasta paginas/
    python operacoes_pdf.py girar a.pdf --graus 90 --saida a-girado.pdf
"""
import argparse
import os

from pypdf import PdfReader, PdfWriter


def juntar(arquivos, saida):
    writer = PdfWriter()
    for caminho in arquivos:
        writer.append(PdfReader(caminho))
    with open(saida, "wb") as f:
        writer.write(f)
    print(f"Gerado: {saida} ({len(writer.pages)} paginas)")


def dividir(arquivo, saida_pasta):
    os.makedirs(saida_pasta, exist_ok=True)
    reader = PdfReader(arquivo)
    largura = len(str(len(reader.pages)))
    for i, pagina in enumerate(reader.pages, start=1):
        writer = PdfWriter()
        writer.add_page(pagina)
        nome = os.path.join(saida_pasta, f"pagina-{str(i).zfill(largura)}.pdf")
        with open(nome, "wb") as f:
            writer.write(f)
    print(f"{len(reader.pages)} paginas gravadas em {saida_pasta}")


def girar(arquivo, graus, saida):
    reader = PdfReader(arquivo)
    writer = PdfWriter()
    for pagina in reader.pages:
        pagina.rotate(graus)
        writer.add_page(pagina)
    with open(saida, "wb") as f:
        writer.write(f)
    print(f"Gerado: {saida} (rotacionado {graus} graus)")


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="comando", required=True)

    p_juntar = sub.add_parser("juntar")
    p_juntar.add_argument("arquivos", nargs="+")
    p_juntar.add_argument("--saida", required=True)

    p_dividir = sub.add_parser("dividir")
    p_dividir.add_argument("arquivo")
    p_dividir.add_argument("--saida-pasta", required=True)

    p_girar = sub.add_parser("girar")
    p_girar.add_argument("arquivo")
    p_girar.add_argument("--graus", type=int, required=True)
    p_girar.add_argument("--saida", required=True)

    args = ap.parse_args()
    if args.comando == "juntar":
        juntar(args.arquivos, args.saida)
    elif args.comando == "dividir":
        dividir(args.arquivo, args.saida_pasta)
    elif args.comando == "girar":
        girar(args.arquivo, args.graus, args.saida)


if __name__ == "__main__":
    main()

"""Aplica uma marca d'agua de texto em todas as paginas de um PDF.

Depende de reportlab (gera a pagina da marca) e pypdf (sobrepoe nas paginas).
    pip install reportlab pypdf

Uso:
    python marca_dagua.py entrada.pdf "CONFIDENCIAL" saida.pdf
"""
import io
import sys

from pypdf import PdfReader, PdfWriter
from reportlab.lib.colors import Color
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas


def gerar_pagina_marca(texto, tamanho):
    buffer = io.BytesIO()
    c = canvas.Canvas(buffer, pagesize=tamanho)
    c.saveState()
    c.setFillColor(Color(0.6, 0.6, 0.6, alpha=0.35))
    c.setFont("Helvetica-Bold", 60)
    largura, altura = tamanho
    c.translate(largura / 2, altura / 2)
    c.rotate(45)
    c.drawCentredString(0, 0, texto)
    c.restoreState()
    c.save()
    buffer.seek(0)
    return PdfReader(buffer).pages[0]


def aplicar(entrada, texto, saida):
    reader = PdfReader(entrada)
    writer = PdfWriter()
    for pagina in reader.pages:
        tamanho = (float(pagina.mediabox.width), float(pagina.mediabox.height))
        marca = gerar_pagina_marca(texto, tamanho)
        pagina.merge_page(marca)
        writer.add_page(pagina)
    with open(saida, "wb") as f:
        writer.write(f)
    print(f"Gerado: {saida}")


if __name__ == "__main__":
    if len(sys.argv) != 4:
        print('Uso: python marca_dagua.py entrada.pdf "TEXTO" saida.pdf')
        sys.exit(1)
    aplicar(sys.argv[1], sys.argv[2], sys.argv[3])

---
name: manipular-pdf
description: Lê, divide, junta, gira, extrai texto/tabelas e preenche formulários de PDF usando pypdf e pdfplumber — só bibliotecas Python, sem instalar programa externo. Use quando o usuário pedir para "juntar esses PDFs", "extrair as tabelas desse PDF", "separar as páginas", "colocar marca d'água", "preencher esse formulário PDF", ou citar arquivos .pdf sem pedir para criar do zero a partir de HTML (nesse caso ver a skill `gerar-pdf-html`) nem para ler PDF escaneado sem texto (nesse caso é OCR, skill à parte, ainda não criada neste catálogo).
argument-hint: [operação: juntar|dividir|extrair|girar|marca-d-agua|preencher] [arquivo(s)]
---

# Manipular PDF (pypdf / pdfplumber)

## Passo 1 — Instalar
```
pip install pypdf pdfplumber
```
`pypdf` para juntar/dividir/girar/marca d'água/formulários. `pdfplumber` para extrair texto e tabelas com boa
fidelidade de layout (melhor que `pypdf` para tabelas).

## Passo 2 — Antes de tudo: o PDF tem texto de verdade?
```python
import pdfplumber
with pdfplumber.open("arquivo.pdf") as pdf:
    tem_texto = any(page.extract_text() for page in pdf.pages)
```
Se `tem_texto` for `False` (ou o texto vier vazio/lixo), o PDF é uma imagem escaneada — nenhuma biblioteca de
manipulação de PDF "lê" o conteúdo visual. **Pare e avise o usuário**: precisa de OCR (ainda não é uma skill deste
catálogo — se o usuário topar instalar o Tesseract, é um trabalho separado).

## Passo 3 — Extrair texto e tabelas
```python
with pdfplumber.open("arquivo.pdf") as pdf:
    for pagina in pdf.pages:
        texto = pagina.extract_text()
        tabelas = pagina.extract_tables()  # lista de listas de linhas
```
`extract_tables()` depende de linhas/espaçamento visual — para tabelas sem bordas visíveis, ajuste
`table_settings={"vertical_strategy": "text", "horizontal_strategy": "text"}`. Sempre confira o resultado antes de
assumir que a tabela saiu certa; PDFs com colunas mal alinhadas produzem tabelas quebradas.

## Passo 4 — Juntar, dividir, girar
Use `scripts/operacoes_pdf.py`:
```
python scripts/operacoes_pdf.py juntar a.pdf b.pdf c.pdf --saida junto.pdf
python scripts/operacoes_pdf.py dividir junto.pdf --saida-pasta paginas/
python scripts/operacoes_pdf.py girar a.pdf --graus 90 --saida a-girado.pdf
```

## Passo 5 — Marca d'água
Gere uma página de marca d'água (texto ou logo) com `reportlab` (pip) e sobreponha em cada página com
`page.merge_page(marca_dagua_page)` do pypdf — exemplo em `scripts/marca_dagua.py`.

## Passo 6 — Preencher formulário (AcroForm)
```python
from pypdf import PdfReader, PdfWriter

reader = PdfReader("formulario.pdf")
writer = PdfWriter()
writer.append(reader)
campos = reader.get_fields()
if campos is None:
    print("Este PDF nao tem campos de formulario preenchiveis (AcroForm).")
else:
    writer.update_page_form_field_values(writer.pages[0], {"nome_do_campo": "valor"})
    with open("preenchido.pdf", "wb") as f:
        writer.write(f)
```
Descubra os nomes reais dos campos com `reader.get_fields().keys()` antes de tentar preencher — nunca adivinhe o
nome do campo.

## Regras
- Sempre confirme quantas páginas o PDF de entrada tem (`len(reader.pages)`) antes de operações de divisão/rotação
  por índice, para não estourar índice ou processar página errada.
- Ao juntar PDFs, preserve a ordem que o usuário pediu explicitamente — se ele não especificou ordem, pergunte ou
  use a ordem alfabética dos nomes de arquivo e informe qual ordem foi usada.
- PDF protegido por senha: `PdfReader(caminho).is_encrypted` — se `True`, PARE e peça a senha ao usuário; nunca
  tente contornar a proteção.

## Arquivos desta skill
- `scripts/operacoes_pdf.py` — juntar, dividir, girar via linha de comando.
- `scripts/marca_dagua.py` — gerar e aplicar marca d'água de texto.

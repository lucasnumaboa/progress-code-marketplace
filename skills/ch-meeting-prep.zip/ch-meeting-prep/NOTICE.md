# Origem

Skill de especialista empacotada para o marketplace do Progress Code (id `ch-meeting-prep`).

- Repositório: https://github.com/TheCraigHewitt/skills
- Caminho: `ceo/meeting-prep`
- Autor: Craig Hewitt
- Detentor do copyright no arquivo de licença: Craig Hewitt
- Licença: MIT (texto completo em `LICENSE`, copiado de `LICENSE` no repositório)
- Commit: `fdbf39b61fbc8cb7cea67949bfb5e8fc567bbc51` (baixado em 2026-11-22)

## Arquivos incluídos

- `SKILL.md` (de `ceo/meeting-prep/SKILL.md`)

## Mudanças feitas

1. Frontmatter: `name:` trocado de `meeting-prep` para `ch-meeting-prep` (a descrição foi mantida).

O texto do especialista foi mantido em inglês, sem tradução.

# Origem

Skill de especialista empacotada para o marketplace do Progress Code (id `acb-agent-patterns`).

- Repositório: https://github.com/anthropics/claude-cookbooks
- Caminho: `patterns/agents`
- Autor: Anthropic
- Detentor do copyright no arquivo de licença: Anthropic
- Licença: MIT (texto completo em `LICENSE`, copiado de `LICENSE` no repositório)
- Commit: `8ad5de647d4f0f50c95d74aabc8aa20a3f70cdd3` (baixado em 2026-11-22)

## Arquivos incluídos

- `SKILL.md` (de `patterns/agents/README.md + células de texto de basic_workflows.ipynb, orchestrator_workers.ipynb e evaluator_optimizer.ipynb`)

## Mudanças feitas

1. O SKILL.md foi montado juntando, sem alterar o texto, o README.md da pasta `patterns/agents` e a primeira célula de texto (markdown) de cada notebook: `basic_workflows.ipynb`, `orchestrator_workers.ipynb` e `evaluator_optimizer.ipynb`. Cada trecho traz um comentário com a origem.
2. Acrescentado frontmatter (`name: acb-agent-patterns` e uma `description` em inglês), que o original não tem.
3. Removida a subseção "Prerequisites" de orchestrator_workers (instalação do Python e chave de API).

O texto do especialista foi mantido em inglês, sem tradução.

## Não incluído

- O código Python dos notebooks e o `util.py` (chamam a API paga da Anthropic com chave).

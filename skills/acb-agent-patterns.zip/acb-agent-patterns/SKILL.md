---
name: acb-agent-patterns
description: Building Effective Agents patterns (Anthropic cookbook): prompt chaining, routing, parallelization, orchestrator-workers and evaluator-optimizer, with when to use and when not to use each. Use when deciding how to split work between one agent, several agents, a reviewer loop or a fixed pipeline.
---

# Building Effective Agents Cookbook

Reference implementation for [Building Effective Agents](https://anthropic.com/research/building-effective-agents) by Erik Schluntz and Barry Zhang.

This repository contains example minimal implementations of common agent workflows discussed in the blog:

- Basic Building Blocks
  - Prompt Chaining
  - Routing
  - Multi-LLM Parallelization
- Advanced Workflows
  - Orchestrator-Subagents
  - Evaluator-Optimizer

## Getting Started
See the Jupyter notebooks for detailed examples:

- [Basic Workflows](basic_workflows.ipynb)
- [Evaluator-Optimizer Workflow](evaluator_optimizer.ipynb) 
- [Orchestrator-Workers Workflow](orchestrator_workers.ipynb)
- [Async Multi-Agent Orchestration](async_multi_agent_orchestration.ipynb)
- [Multi-Agent Teams Under Latency Pressure and Budgets](latency_multi_agent.ipynb)

---

<!-- de basic_workflows.ipynb (célula de texto 1) -->
## Basic Multi-LLM Workflows

This notebook demonstrates three simple multi-LLM workflows. They trade off cost or latency for potentially improved task performances:

1. **Prompt-Chaining**: Decomposes a task into sequential subtasks, where each step builds on previous results
2. **Parallelization**: Distributes independent subtasks across multiple LLMs for concurrent processing
3. **Routing**: Dynamically selects specialized LLM paths based on input characteristics

Note: These are sample implementations meant to demonstrate core concepts - not production code.

---

<!-- de orchestrator_workers.ipynb (célula de texto 1) -->
# Orchestrator-Workers Workflow

## Introduction

Have you ever needed multiple perspectives on the same task, but couldn't predict in advance which perspectives would be most valuable? The orchestrator-workers pattern solves this by having a central LLM analyze each unique task and dynamically determine the best subtasks to delegate to specialized worker LLMs.

Traditional approaches either require manual prompting multiple times or use hardcoded parallelization that generates the same variations regardless of context.

With this approach, an orchestrator LLM analyzes the task, determines which variations would be most valuable for this specific case, then delegates to worker LLMs that generate each variation.

### What You'll Build

A system that takes a product description request and:

1. Analyzes what types of marketing copy would be valuable
2. Dynamically generates specialized task descriptions for workers
3. Produces multiple content variations optimized for different audiences
4. Returns coordinated results from all workers

### When to use this workflow

This workflow is well-suited for complex tasks where you can't predict the subtasks needed in advance. The key difference from simple parallelization is its flexibility—subtasks aren't pre-defined, but determined by the orchestrator based on the specific input.

**Use this pattern when:**

- Tasks require multiple distinct approaches or perspectives
- The optimal subtasks depend on the specific input
- You need to compare different strategies or styles

**Don't use this pattern when:**

- You have simple, single-output tasks (unnecessary complexity)
- Latency is critical (multiple LLM calls add overhead)
- Subtasks are predictable and can be pre-defined (use simpler parallelization)

## How It Works

The orchestrator-workers pattern operates in two phases:

1. **Analysis & Planning Phase**: The orchestrator LLM receives the task and context, analyzes what approaches would be valuable, and generates structured subtask descriptions in XML format.

2. **Execution Phase**: Each worker LLM receives:
   - The original task for context
   - Its specific subtask type and description
   - Any additional context provided

The orchestrator decides *at runtime* what subtasks to create, making this more adaptive than pre-defined parallel workflows.

---

<!-- de evaluator_optimizer.ipynb (célula de texto 1) -->
## Evaluator-Optimizer Workflow
In this workflow, one LLM call generates a response while another provides evaluation and feedback in a loop.

### When to use this workflow
This workflow is particularly effective when we have:

- Clear evaluation criteria
- Value from iterative refinement

The two signs of good fit are:

- LLM responses can be demonstrably improved when feedback is provided
- The LLM can provide meaningful feedback itself

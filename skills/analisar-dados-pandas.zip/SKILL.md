---
name: analisar-dados-pandas
description: Carrega, limpa, agrupa, cruza e exporta dados tabulares (CSV/Excel/JSON/SQL) com pandas, incluindo as armadilhas específicas de dados brasileiros (encoding, datas dd/mm/aaaa, vírgula decimal). Use quando o usuário pedir para "analisar essa planilha/CSV", "cruzar essas duas bases", "agrupar por categoria e somar", "por que esse número não bate".
argument-hint: [arquivo(s) de dados] [o que analisar]
---

# Analisar dados com pandas

## Passo 1 — Instalar e carregar
```
pip install pandas openpyxl
```
```python
import pandas as pd

df = pd.read_csv("dados.csv", encoding="latin-1", sep=";", decimal=",", thousands=".")
# ou
df = pd.read_excel("dados.xlsx", sheet_name="Plan1")
```

## Passo 2 — Armadilhas de dados brasileiros (a causa mais comum de "número errado")
- **Encoding**: CSV exportado de sistemas legados brasileiros (Progress/Datasul incluso) frequentemente vem em
  `latin-1`/`cp1252`, não UTF-8. Se aparecer `Ã©`/`�` nos textos, tente `encoding="latin-1"` antes de qualquer outra
  coisa.
- **Separador decimal**: `decimal=","` e `sep=";"` juntos são comuns em CSV exportado de Excel brasileiro (porque a
  vírgula já é o separador decimal, o `;` vira separador de coluna). Ler sem isso faz `1.234,56` virar texto ou um
  número errado (`1.234` truncado).
- **Datas dd/mm/aaaa**: `pd.read_csv(..., parse_dates=["data"], dayfirst=True)` — sem `dayfirst=True`, pandas
  assume mm/dd/aaaa (padrão americano) e `03/04/2026` vira 3 de abril em vez de 4 de março, silenciosamente, sem
  erro algum. Essa é a fonte de bug mais comum e mais difícil de perceber — sempre confira uma data conhecida do
  conjunto depois de carregar.
- **Milhares**: `thousands="."` quando o número vem como `1.234.567` (formato brasileiro) em vez de `1,234,567`.

## Passo 3 — Limpar, agrupar, cruzar
```python
df["valor"] = df["valor"].fillna(0)
resumo = df.groupby("categoria")["valor"].agg(["sum", "mean", "count"])

# juntar duas bases (equivalente a PROCV/VLOOKUP, mas vetorizado)
df_final = df.merge(outra_df, on="chave", how="left", indicator=True)
sem_match = df_final[df_final["_merge"] == "left_only"]  # linhas que NAO acharam correspondencia
```
`indicator=True` + checar `_merge` é a forma de descobrir quantas linhas não bateram no cruzamento — não confie que
o `merge` "deu certo" só porque não deu erro; um `left` join sempre "funciona" mesmo perdendo tudo.

## Passo 4 — Pivotar e exportar
```python
tabela = df.pivot_table(index="regiao", columns="mes", values="valor", aggfunc="sum", fill_value=0)
tabela.to_excel("resumo.xlsx")
```

## Regras
- Sempre imprima `df.dtypes` e `df.head()` logo depois de carregar, antes de qualquer cálculo — colunas numéricas
  que vieram como texto (`object`) por causa de separador decimal errado dão soma errada sem erro nenhum.
- Ao cruzar duas bases, sempre reporte quantas linhas não bateram (passo 3) — nunca entregue um resultado de merge
  sem checar isso.
- Números "estranhos": antes de aceitar como correto, confira se a causa não é uma das armadilhas do passo 2 —
  é a causa mais comum de discordância entre o resultado do pandas e o que o usuário via no sistema de origem.

## Arquivos desta skill
Nenhum script fixo — os trechos acima cobrem os casos mais comuns; adapte às colunas/formato reais do usuário.

---
name: jira-azuredevops-github-issues
description: Cria, atualiza, transiciona e consulta itens no Jira (JQL), Azure DevOps (WIQL) e GitHub Issues via API, com anexo de evidências e sincronização com planilhas. Use quando o usuário pedir para "criar um chamado/issue no Jira/Azure DevOps/GitHub", "consultar os itens abertos", "mudar o status desse card", "gerar relatório dos itens do sprint".
argument-hint: [Jira|Azure DevOps|GitHub] [operação]
---

# Jira / Azure DevOps / GitHub Issues via API

## Jira (REST API v3, autenticação por token de API)
```python
import requests
from requests.auth import HTTPBasicAuth

auth = HTTPBasicAuth(email, api_token)  # token gerado em id.atlassian.com/manage-profile/security/api-tokens

# criar
requests.post(f"{base_url}/rest/api/3/issue", auth=auth, json={
    "fields": {
        "project": {"key": "PROJ"},
        "summary": "Título do chamado",
        "issuetype": {"name": "Bug"},
        "description": {"type": "doc", "version": 1, "content": [
            {"type": "paragraph", "content": [{"type": "text", "text": "Descrição em texto."}]}
        ]},
    }
})

# consultar via JQL
resp = requests.get(f"{base_url}/rest/api/3/search", auth=auth,
                     params={"jql": 'project = PROJ AND status = "In Progress"'})

# transicionar (mudar status - precisa do ID da transicao, nao so o nome)
transicoes = requests.get(f"{base_url}/rest/api/3/issue/{chave}/transitions", auth=auth).json()
id_transicao = next(t["id"] for t in transicoes["transitions"] if t["name"] == "Done")
requests.post(f"{base_url}/rest/api/3/issue/{chave}/transitions", auth=auth,
              json={"transition": {"id": id_transicao}})
```
`description` no Jira Cloud usa o formato **ADF** (Atlassian Document Format, um JSON estruturado) — não é
markdown nem texto puro; para descrições simples, o exemplo acima já cobre o caso comum.

## Azure DevOps (REST API, autenticação por Personal Access Token)
```python
import base64
auth_header = {"Authorization": "Basic " + base64.b64encode(f":{pat}".encode()).decode()}

# criar work item (usa JSON Patch, nao um objeto direto)
requests.post(
    f"https://dev.azure.com/{org}/{projeto}/_apis/wit/workitems/$Bug?api-version=7.1",
    headers={**auth_header, "Content-Type": "application/json-patch+json"},
    json=[
        {"op": "add", "path": "/fields/System.Title", "value": "Título do bug"},
        {"op": "add", "path": "/fields/System.Description", "value": "Descrição."},
    ],
)

# consultar via WIQL
requests.post(f"https://dev.azure.com/{org}/{projeto}/_apis/wit/wiql?api-version=7.1",
              headers=auth_header,
              json={"query": "SELECT [System.Id] FROM WorkItems WHERE [System.State] = 'Active'"})
```

## GitHub Issues (REST API, autenticação por token de acesso pessoal ou GitHub App)
```python
headers = {"Authorization": f"Bearer {token}", "Accept": "application/vnd.github+json"}

requests.post(f"https://api.github.com/repos/{owner}/{repo}/issues", headers=headers,
              json={"title": "Título", "body": "Descrição.", "labels": ["bug"]})

requests.get(f"https://api.github.com/repos/{owner}/{repo}/issues", headers=headers,
             params={"state": "open", "labels": "bug"})
```
Para tarefas GitHub, prefira o `gh` CLI (já disponível neste ambiente) quando a operação for pontual — ver as
instruções gerais de uso do `gh` já conhecidas por você; use a API HTTP diretamente só quando for parte de uma
automação/pipeline maior em Python.

## Anexar evidência (print, log) a um item
Todos os três aceitam anexo via endpoint próprio (`/attachments` no Jira/Azure DevOps, upload de asset+comentário no
GitHub) — sempre gere a evidência primeiro (ex.: skill `capturar-tela-janelas`) e depois anexe via API.

## Regras
- Nunca crie/edite itens em produção sem confirmar com o usuário o texto exato (título, descrição, projeto) —
  esses sistemas geralmente não têm "excluir em massa" fácil se algo for criado errado.
- Ao sincronizar com planilha, trate a direção do sync com cuidado: decida com o usuário se a planilha é fonte de
  verdade (sobrescreve o sistema) ou o contrário — sincronizar nos dois sentidos sem essa regra clara duplica ou
  perde dados.
- Token/PAT: nunca em código versionado; trate como segredo (ver skill `oauth2-login-servicos` para OAuth2, ou
  variável de ambiente para token estático).

## Arquivos desta skill
Nenhum script fixo — os trechos acima cobrem os casos mais comuns; adapte ao projeto/instância real do usuário.

---
name: automatizar-windows-uiautomation
description: Automatiza programas Windows de verdade (clicar, digitar, ler grids) localizando janelas e controles pelo nome/tipo via UI Automation (pywinauto), em vez de depender de coordenadas de tela fixas. Use quando o usuário pedir para "automatizar esse programa desktop", "clicar nesse botão do sistema X", "preencher esse formulário de um app Windows" — para Excel/Word/Outlook especificamente, prefira a skill `automatizar-office-com` (COM é mais direto que UI Automation para esses três).
argument-hint: [nome do programa/janela] [ação desejada]
---

# Automatizar programas Windows (UI Automation via pywinauto)

## Por que localizar controles em vez de usar coordenadas
Coordenadas de tela (`click(500, 300)`) quebram se a janela mudar de tamanho, posição, resolução de tela, ou escala
de DPI. Localizar o controle pelo nome/tipo/AutomationId sobrevive a tudo isso. **Só use coordenadas como último
recurso**, quando o programa não expõe os controles via UI Automation (comum em apps desenhados sob medida com
frameworks antigos ou canvas customizado).

## Passo 1 — Instalar
```
pip install pywinauto
```

## Passo 2 — Conectar/abrir e inspecionar a janela
```python
from pywinauto import Application

app = Application(backend="uia").start(r"C:\caminho\programa.exe")
# ou conectar a um já aberto:
app = Application(backend="uia").connect(title_re=".*Nome da Janela.*")

janela = app.window(title_re=".*Nome da Janela.*")
janela.print_control_identifiers()  # lista TODOS os controles com seus nomes/tipos - use isso antes de tentar clicar em qualquer coisa
```
**Nunca** tente clicar num controle sem antes rodar `print_control_identifiers()` (ou o utilitário gráfico
`python -m pywinauto.actions` / Inspect.exe do Windows SDK) para confirmar o nome exato — adivinhar nome de
controle é a causa mais comum de script que "não acha o botão".

## Passo 3 — Interagir
```python
janela.child_window(title="Salvar", control_type="Button").click()
janela.child_window(auto_id="txtNome", control_type="Edit").set_text("Fulano de Tal")
grid = janela.child_window(control_type="DataGrid")
linhas = grid.children(control_type="DataItem")
```
`backend="uia"` (Microsoft UI Automation) funciona para a maioria dos apps modernos (WPF, WinForms, Win32, Chromium
embarcado); use `backend="win32"` só para apps Win32 muito antigos onde `uia` não enxerga os controles.

## Passo 4 — Esperar em vez de `sleep` fixo
```python
from pywinauto.timings import wait_until_passes

wait_until_passes(timeout=10, retry_interval=0.5,
                   func=lambda: janela.child_window(title="Concluído").exists())
```
Espera fixa (`time.sleep(5)`) quebra quando o programa demora mais que o esperado (máquina lenta, rede) ou desperdiça
tempo quando termina antes — sempre prefira esperar por uma condição real.

## Passo 5 — Último recurso: coordenadas
Se o controle realmente não aparece via UI Automation, use coordenadas relativas à janela (não à tela inteira, para
sobreviver a a janela mover de posição):
```python
janela.click_input(coords=(x, y))  # x, y relativos ao canto superior esquerdo da JANELA, nao da tela
```

## Regras
- Sempre confirme com `print_control_identifiers()` antes de codificar a interação — não escreva "às cegas" supondo
  o nome do controle.
- Trate o programa não abrir/não responder como erro esperado (rede lenta, licença, primeira execução com
  diálogo de boas-vindas) — não deixe o script travar para sempre; sempre com `timeout`.
- Cuidado com diálogos inesperados (atualização disponível, licença, erro) que roubam o foco — se o script depende
  de uma sequência rígida de cliques, um popup inesperado quebra tudo; trate isso ou avise o usuário da limitação.

## Arquivos desta skill
Nenhum script fixo — o padrão de uso acima é o ponto de partida; adapte ao programa real do usuário depois de
inspecionar os controles.

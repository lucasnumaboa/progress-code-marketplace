---
name: gerenciar-segredos-windows
description: Guarda e lê segredos (senhas, tokens, chaves de API) com segurança no Credential Manager do Windows, variáveis de ambiente ou .env fora do Git, com rotação e detecção de vazamento no histórico do Git. Use sempre que um script/automação precisar de senha, token ou chave de API — nunca escreva o valor direto no código.
argument-hint: [onde o segredo será usado]
---

# Gerenciar segredos com segurança

## Regra de ouro
**Nunca** escreva senha/token/chave de API literal em código, mesmo "temporariamente para testar" — é fácil
esquecer de remover antes de commitar. Sempre passe por uma das opções abaixo desde a primeira linha de código.

## Windows Credential Manager (via `keyring`, para scripts/apps locais)
```
pip install keyring
```
```python
import keyring
keyring.set_password("minha-app", "api_token", "valor-secreto")   # roda uma vez, interativamente, para guardar
token = keyring.get_password("minha-app", "api_token")             # o script le daqui, nunca hardcoded
```
O valor fica criptografado no cofre do Windows, atrelado ao usuário logado — outro usuário da mesma máquina não
consegue ler.

## Variável de ambiente (para processos/serviços, CI/CD)
```powershell
[Environment]::SetEnvironmentVariable("API_TOKEN", "valor-secreto", "User")
```
```python
import os
token = os.environ["API_TOKEN"]
```
Em CI/CD, use o mecanismo de segredo da própria plataforma (ver skill `cicd-pipelines`) — nunca a variável de
ambiente "visível" em log de build.

## .env (para projetos com várias variáveis, ambiente de desenvolvimento)
```
pip install python-dotenv
```
```
# .env (adicionar ao .gitignore ANTES de criar o arquivo, nao depois)
API_TOKEN=valor-secreto
DATABASE_URL=postgresql://...
```
```python
from dotenv import load_dotenv
load_dotenv()
token = os.environ["API_TOKEN"]
```
**Sempre** adicione `.env` ao `.gitignore` antes de criar o arquivo pela primeira vez — se já foi commitado por
engano, ver a seção de vazamento abaixo (remover do `.gitignore` depois não desfaz o commit já feito).

## Cofre em nuvem (Key Vault/AWS Secrets Manager) — para produção com múltiplos serviços
Ver skills `azure-para-desenvolvedores` (Key Vault) e `aws-para-desenvolvedores` (Secrets Manager/Parameter Store)
— prefira isso a `.env` quando o segredo é usado por múltiplos serviços/ambientes que precisam de rotação
centralizada.

## Rotação
Regra prática: qualquer segredo que já foi exposto (mesmo brevemente, mesmo "só no log de erro") deve ser rotacionado
(gerar um novo, revogar o antigo) assim que possível — não é suficiente remover o texto de onde apareceu, porque não
há garantia de que ninguém mais viu/copiou antes da remoção.

## Detectar vazamento no histórico do Git (segredo commitado por engano)
```
git log --all --full-history -- .env
```
Se encontrar, o segredo **já vazou** (mesmo que o arquivo tenha sido removido num commit posterior — ele continua
no histórico, recuperável por qualquer um com acesso ao repositório). Passos:
1. Rotacione o segredo imediatamente (gere um novo, revogue o antigo) — isso é mais importante e mais rápido que
   limpar o histórico.
2. Depois, se necessário remover do histórico: `git filter-repo` (ferramenta recomendada atualmente, precisa
   instalar) ou BFG Repo-Cleaner — **isso reescreve o histórico e exige coordenação com todo mundo que tem clone
   do repositório**; confirme com o usuário antes de fazer isso, é uma operação disruptiva para o time.

## Regras
- Nunca "só desta vez" hardcode um segredo real para testar rápido — use um valor de teste separado ou uma das
  opções acima desde o início.
- Ao revisar `git status`/`git diff` antes de commitar (como já orientado de forma geral), preste atenção redobrada
  a arquivos `.env`, `credentials.json`, `*.pem`, `*.key` — nunca adicione esses ao stage sem certeza absoluta de
  que não têm segredo real.
- Segredo exposto: rotação vem antes de limpeza de histórico, sempre.

## Arquivos desta skill
Nenhum script fixo — os trechos acima cobrem os casos mais comuns; adapte ao segredo/plataforma reais do usuário.

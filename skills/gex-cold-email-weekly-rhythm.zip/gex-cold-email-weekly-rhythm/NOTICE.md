# Aviso de terceiros (NOTICE)

Esta skill é uma cópia adaptada de material de terceiros e é redistribuída sob a licença original. O texto do especialista ficou em inglês, como no original.

- **Origem:** https://github.com/growthenginenowoslawski/coldoutboundskills
- **Caminho no repositório:** `skills/cold-email-weekly-rhythm`
- **Commit:** `25c5d85fbb5dd3efec97b0ca457cbbc286547476` (baixado em 2026-11-22)
- **Autor:** GrowthEngineX
- **Licença:** MIT (texto completo em `LICENSE`, copiado de `LICENSE` do repositório)

## Arquivos incluídos

- `SKILL.md` (de `skills/cold-email-weekly-rhythm/SKILL.md`)
- `LICENSE`

## Mudanças feitas

- Frontmatter: `name: cold-email-weekly-rhythm` trocado por `name: gex-cold-email-weekly-rhythm` (a descrição ficou igual).

## Arquivos do original que não foram incluídos

- As skills e scripts citados no playbook (`email-deliverability-audit`, `positive-reply-scoring`, `inbox-lifecycle-manager`, `smartlead-inbox-manager`, `deliverability-incident-response`, `experiment-design`, `zapmail-domain-setup-public` e os scripts `.ts` de cada uma) não fazem parte deste pacote: dependem de ferramentas pagas (Smartlead, Zapmail) e de chaves de API. O ritmo e os limiares do SKILL.md valem sem eles.

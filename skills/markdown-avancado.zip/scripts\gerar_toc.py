"""Gera um sumario em Markdown a partir dos cabecalhos de um arquivo .md,
usando a mesma regra de ancora do GitHub (sem dependencias externas).

Uso:
    python gerar_toc.py documento.md
"""
import re
import sys
from collections import Counter


def slugificar(texto):
    texto = texto.lower().strip()
    texto = re.sub(r"[^\w\s-]", "", texto, flags=re.UNICODE)
    texto = re.sub(r"[\s]+", "-", texto)
    return texto


def gerar_toc(caminho):
    with open(caminho, "r", encoding="utf-8") as f:
        linhas = f.readlines()

    contagem = Counter()
    toc = []
    dentro_bloco_codigo = False
    for linha in linhas:
        if linha.strip().startswith("```"):
            dentro_bloco_codigo = not dentro_bloco_codigo
            continue
        if dentro_bloco_codigo:
            continue
        m = re.match(r"^(#{1,6})\s+(.*)", linha)
        if not m:
            continue
        nivel = len(m.group(1))
        if nivel == 1:
            continue  # titulo principal normalmente nao entra no proprio sumario
        titulo = m.group(2).strip()
        slug_base = slugificar(titulo)
        contagem[slug_base] += 1
        slug = slug_base if contagem[slug_base] == 1 else f"{slug_base}-{contagem[slug_base] - 1}"
        indent = "  " * (nivel - 2)
        toc.append(f"{indent}- [{titulo}](#{slug})")

    print("\n".join(toc))


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Uso: python gerar_toc.py documento.md")
        sys.exit(1)
    gerar_toc(sys.argv[1])

---
name: markdown-avancado
description: Escreve Markdown avançado de verdade — tabelas, admonitions (avisos/notas), diagramas Mermaid, sumário automático — e sabe quando cada recurso funciona (GitHub, Docusaurus/MkDocs, Claude) e quando precisa de uma ferramenta externa para converter para HTML/PDF/DOCX. Use quando o usuário pedir para "melhorar essa documentação em markdown", "adicionar um sumário", "colocar um aviso destacado", "desenhar um diagrama no markdown".
argument-hint: [caminho do .md]
---

# Markdown avançado

## Tabelas (GFM)
```markdown
| Coluna A | Coluna B |
|---|---|
| 1 | 2 |
```
Alinhamento: `|:---|` esquerda, `|:---:|` centro, `|---:|` direita. Célula com `|` literal precisa de `\|`.

## Admonitions (avisos/notas destacadas)
A sintaxe **depende de onde o markdown vai ser renderizado** — não existe um padrão universal:
- **GitHub** (issues, PRs, README): `> [!NOTE]`, `> [!WARNING]`, `> [!IMPORTANT]`, `> [!TIP]`, `> [!CAUTION]` dentro
  de uma citação `>`. Só funciona no github.com, não em qualquer visualizador de markdown.
- **MkDocs Material / Docusaurus**: `::: note` ... `:::` ou `!!! note "Título"` (MkDocs) com o conteúdo indentado.
- **Sem certeza de onde vai renderizar**: use só `**Nota:**`/`**Atenção:**` em negrito — funciona em qualquer lugar,
  sem depender de extensão.
Pergunte ao usuário (ou infira pelo repositório/plataforma) antes de escolher a sintaxe.

## Diagramas Mermaid
````markdown
```mermaid
flowchart LR
    A[Início] --> B{Decisão}
    B -->|Sim| C[Fim]
    B -->|Não| A
```
````
GitHub, GitLab, Claude e a maioria dos visualizadores modernos renderizam blocos ` ```mermaid ` **direto**, sem
precisar de nenhuma ferramenta instalada. Só é preciso instalar `mermaid-cli` (programa externo, Node.js) se o
objetivo for gerar uma **imagem PNG/SVG estática** do diagrama fora de um visualizador que entenda Mermaid (ex.:
para colar num Word). Se for esse o caso, pare e confirme com o usuário antes de propor instalar Node.js.

## Sumário automático (sem instalar nada)
`scripts/gerar_toc.py` lê um `.md`, extrai os cabeçalhos (`#`, `##`, `##...`) e gera uma lista de links âncora no
formato que o GitHub usa (minúsculas, espaços viram `-`, remove pontuação):
```
python scripts/gerar_toc.py documento.md
```
Ele imprime o bloco de sumário para você colar manualmente logo abaixo do título principal — não sobrescreve o
arquivo sozinho, para o usuário poder revisar antes.

## Convertendo para HTML/PDF/DOCX (requer instalar Pandoc — confirme antes)
Isso **não** é necessário só para visualizar o markdown formatado — é só quando o destino final precisa ser um
arquivo `.docx`/`.pdf`/`.html` separado. Pandoc é um programa externo (não vem com pip/npm); se o usuário topar
instalar (`winget install --id JohnMacFarlane.Pandoc`):
```
pandoc documento.md -o documento.docx
pandoc documento.md -o documento.pdf   # precisa tambem de um motor LaTeX (MiKTeX/TinyTeX) instalado separadamente
pandoc documento.md -o documento.html --standalone
```
Para PDF sem instalar um motor LaTeX pesado, prefira gerar HTML com Pandoc e depois usar a skill `gerar-pdf-html`
(Edge headless, sem instalação extra) para o passo final HTML → PDF.

## Regras
- Nunca assuma que uma sintaxe de admonition renderiza em qualquer lugar — confirme a plataforma de destino antes.
- Ao gerar sumário, não invente âncoras — gere a partir dos cabeçalhos reais do arquivo (script acima), e avise se
  dois cabeçalhos geram a mesma âncora (o GitHub desambigua com sufixo `-1`, `-2`; replique essa regra).
- Se o usuário pedir conversão para PDF/DOCX, primeiro ofereça o caminho sem instalar nada (Edge headless via
  `gerar-pdf-html`, que exige o conteúdo já em HTML); só proponha Pandoc se precisar de recursos que ele tem e o
  outro caminho não (ex.: geração de `.docx` editável).

## Arquivos desta skill
- `scripts/gerar_toc.py` — gera sumário em Markdown a partir dos cabeçalhos do arquivo, sem dependências externas.

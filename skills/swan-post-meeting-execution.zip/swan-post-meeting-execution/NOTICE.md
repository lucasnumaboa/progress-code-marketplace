# Aviso de terceiros (NOTICE)

Esta skill é uma cópia adaptada de material de terceiros e é redistribuída sob a licença original. O texto do especialista ficou em inglês, como no original.

- **Origem:** https://github.com/swan-gtm/gtm-skills
- **Caminho no repositório:** `skills/jeremy-hurst/post-meeting-execution`
- **Commit:** `eb0026f469f90645e1a64168d08a3e0afb59ee12` (baixado em 2026-11-22)
- **Autor:** Jeremy Hurst (autor da skill); copyright do repositório: Swan
- **Licença:** MIT (texto completo em `LICENSE`, copiado de `LICENSE` do repositório)

## Arquivos incluídos

- `SKILL.md` (de `skills/jeremy-hurst/post-meeting-execution/SKILL.md`)
- `references/setup-customization-checklist.md` (de `skills/jeremy-hurst/post-meeting-execution/references/setup-customization-checklist.md`)
- `author.md` (de `skills/jeremy-hurst/author.md`, crédito do autor pedido pelo repositório)
- `LICENSE`

## Mudanças feitas

- Frontmatter: `name: post-meeting-execution` trocado por `name: swan-post-meeting-execution` (a descrição ficou igual).

## Crédito do autor (author.md)

O repositório pede que o crédito do autor acompanhe a skill. Conteúdo do `author.md` original:

```markdown
---
name: Jeremy Hurst
avatarUrl: "https://www.gtmskills.com/authors/jeremy-hurst.jpg"
title: VP of Autonomous GTM
linkedinUrl: "https://linkedin.com/in/jeremyhurstprofile"
companyDomain: getswan.com
---

I left a $450K VP Sales role to take a job with a made-up title: VP of Autonomous GTM.
```

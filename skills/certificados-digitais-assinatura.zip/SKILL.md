---
name: certificados-digitais-assinatura
description: Trabalha com certificados digitais (PFX/PEM, cadeia de confiança), assina PDF e XML (padrão NF-e) e valida validade/CRL, usando bibliotecas Python (sem precisar do openssl.exe instalado separadamente). Use quando o usuário pedir para "assinar esse PDF/XML digitalmente", "converter esse certificado PFX para PEM", "verificar se esse certificado está válido/revogado", "montar a cadeia de certificação".
argument-hint: [certificado/arquivo a assinar] [operação]
---

# Certificados digitais e assinatura

## Ler um certificado PFX (o formato mais comum entregue por autoridades certificadoras brasileiras — e-CPF/e-CNPJ)
```python
from cryptography.hazmat.primitives.serialization import pkcs12

with open("certificado.pfx", "rb") as f:
    chave_privada, certificado, cadeia_adicional = pkcs12.load_key_and_certificates(f.read(), b"senha-do-pfx")

print(certificado.subject)
print("Válido de:", certificado.not_valid_before_utc, "até:", certificado.not_valid_after_utc)
```
```
pip install cryptography
```
Isso já resolve o caso mais comum sem precisar instalar `openssl.exe` separado (o pacote `cryptography` traz o
OpenSSL compilado internamente no wheel do Windows).

## Converter PFX para PEM (quando uma ferramenta específica só aceita PEM)
```python
from cryptography.hazmat.primitives import serialization

pem_chave = chave_privada.private_bytes(
    encoding=serialization.Encoding.PEM,
    format=serialization.PrivateFormat.PKCS8,
    encryption_algorithm=serialization.NoEncryption(),  # cuidado: PEM sem senha - proteja o arquivo gerado
)
pem_cert = certificado.public_bytes(serialization.Encoding.PEM)
```

## Verificar validade e cadeia
```python
import datetime
agora = datetime.datetime.now(datetime.timezone.utc)
if certificado.not_valid_after_utc < agora:
    print("CERTIFICADO EXPIRADO")
elif (certificado.not_valid_after_utc - agora).days < 30:
    print("Certificado expira em menos de 30 dias - avisar o responsavel")
```
Verificação de **cadeia completa** (certificado → intermediária → raiz confiável) e **CRL/OCSP** (revogação) é mais
elaborada — para isso, prefira uma biblioteca de mais alto nível como `pyOpenSSL`/`certvalidator` em vez de montar
a validação manualmente; erros sutis nessa lógica são um risco de segurança real.

## Assinar PDF (padrão comum para documentos brasileiros)
```
pip install pyhanko
```
```python
from pyhanko.sign import signers

signer = signers.SimpleSigner.load_pkcs12("certificado.pfx", passphrase=b"senha-do-pfx")
# ver documentacao do pyHanko para o fluxo completo de assinatura visivel/invisivel em PDF
```

## Assinar XML (padrão XML-DSig, base da assinatura de NF-e/NFS-e — ver skill `nfe-nfse-cte-xml`)
```
pip install signxml
```
```python
from signxml import XMLSigner
from lxml import etree

root = etree.parse("nota.xml").getroot()
assinado = XMLSigner().sign(root, key=chave_privada_pem, cert=pem_cert)
```
A estrutura exata exigida pela SEFAZ para NF-e (qual elemento assinar, algoritmo específico) tem particularidades
próprias — ver a skill `nfe-nfse-cte-xml` para os detalhes específicos do padrão fiscal brasileiro; esta skill
cobre a mecânica geral de assinatura XML.

## Regras
- Nunca grave a senha do PFX em texto no código — trate como segredo (ver skill `gerenciar-segredos-windows`).
- Certificado expirando em breve (< 30 dias): sempre alerte proativamente — um certificado vencido em produção
  para o fluxo de assinatura/emissão fiscal de uma empresa inteira.
- Nunca implemente a lógica de verificação de cadeia/revogação "na mão" com comparação simples de datas — use uma
  biblioteca madura (`certvalidator`) para isso, o risco de uma falha sutil de segurança é real.

## Arquivos desta skill
Nenhum script fixo — os trechos acima cobrem os casos mais comuns; adapte ao certificado/documento reais do usuário.

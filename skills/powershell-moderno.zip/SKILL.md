---
name: powershell-moderno
description: Usa PowerShell de verdade — pipeline de objetos (não texto), Where-Object/Select-Object/Group-Object, try/catch com $ErrorActionPreference, módulos, remoting — e conhece as armadilhas do 5.1 vs 7 e as equivalências com comandos Unix. Use sempre que for escrever ou revisar um script PowerShell, ou quando o usuário perguntar "como faço isso em PowerShell" vindo de experiência em Bash/Unix.
argument-hint: [o que o script precisa fazer]
---

# PowerShell moderno de verdade

## O pipeline passa objetos, não texto (a diferença fundamental vs. Bash)
```powershell
Get-Process | Where-Object { $_.CPU -gt 100 } | Select-Object Name, CPU | Sort-Object CPU -Descending
```
Nunca faça parsing de texto de saída de outro cmdlet (`Get-Process | Out-String -match "..."`) quando dá para
filtrar o objeto direto com `Where-Object`/`Select-Object` — isso é o equivalente a fazer `grep`/`awk` em Bash
quando o dado já vem estruturado; PowerShell existe justamente para não precisar disso.

## Equivalências com Unix (para quem vem de Bash)
| Unix | PowerShell |
|---|---|
| `grep` | `Select-String` ou `Where-Object` |
| `awk`/`cut` | `Select-Object`, `.Property` direto no objeto |
| `sed` | `-replace` (operador de regex) |
| `ls -la` | `Get-ChildItem -Force` |
| `cat` | `Get-Content` |
| `ps aux` | `Get-Process` |
| `kill` | `Stop-Process` |
| `\|\|` / `&&` | **não existem em PowerShell 5.1** — use `if ($?) { ... }` ou `-and`/`-or` dentro de `if` |
| `$?` (status do último comando) | `$?` existe mas reflete sucesso de **cmdlet**, não de código de saída de EXE — para EXE, cheque `$LASTEXITCODE` |

## Tratamento de erro
```powershell
$ErrorActionPreference = 'Stop'  # sem isso, erro nao-terminante NAO para o script nem cai no catch
try {
    Get-Item "C:\arquivo-que-nao-existe.txt"
} catch {
    Write-Error "Falhou: $($_.Exception.Message)"
}
```
**Armadilha nº 1**: sem `$ErrorActionPreference = 'Stop'` (ou `-ErrorAction Stop` por comando), muitos cmdlets geram
erro "não-terminante" que **não** é capturado por `catch` — o script continua rodando como se nada tivesse
acontecido, só imprime o erro em vermelho.

## PowerShell 5.1 (Windows PowerShell) vs. 7+ (PowerShell Core) — o que muda
- `&&`/`||` só existem no 7+. Em 5.1: `comando1; if ($?) { comando2 }`.
- Ternário (`?:`), null-coalescing (`??`), null-conditional (`?.`) só no 7+.
- `ConvertFrom-Json` no 5.1 devolve `PSCustomObject`; `-AsHashtable` só existe no 7+.
- Módulos com `#Requires -Version 7` falham silenciosamente em 5.1 sem essa diretiva — sempre declare a versão
  mínima no topo do script se usar sintaxe do 7+.
- Este ambiente usa 5.1 por padrão (confirme antes de usar sintaxe exclusiva do 7+).

## Remoting (executar em máquina remota)
```powershell
Invoke-Command -ComputerName servidor01 -ScriptBlock { Get-Service -Name Spooler }
$sessao = New-PSSession -ComputerName servidor01
Invoke-Command -Session $sessao -ScriptBlock { ... }
Remove-PSSession $sessao
```
Precisa de WinRM habilitado no destino (`Enable-PSRemoting`, já vem habilitado em muitos ambientes de domínio, mas
não em máquinas standalone) — se falhar com erro de acesso negado/WinRM, confirme se está habilitado antes de
assumir que é erro de permissão.

## Regras
- Nunca use `Invoke-Expression` sobre texto que veio de fonte externa/não confiável — equivalente a `eval`, risco
  de injeção de comando.
- Prefira `-Confirm:$false`/`-Force` explícitos em vez de suprimir prompt com `2>$null` — isso documenta a intenção
  no próprio comando.
- Scripts que rodam em ambiente não-interativo (agendado, remoto): nunca usem `Read-Host` nem qualquer prompt que
  espera entrada — falha travando ou lendo EOF.

## Arquivos desta skill
Nenhum script fixo — as referências acima orientam qualquer script PowerShell escrito para o usuário.

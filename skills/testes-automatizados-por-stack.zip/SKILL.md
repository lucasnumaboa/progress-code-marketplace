---
name: testes-automatizados-por-stack
description: Estrutura testes automatizados por stack (pytest, Jest/Vitest, xUnit, JUnit) — fixtures, mocks, cobertura — e sabe quando um teste de integração precisa de banco em container (Docker, dependência separada). Use quando o usuário pedir para "escrever testes para isso", "essa fixture não está funcionando", "medir cobertura de teste", "montar teste de integração com banco".
argument-hint: [stack] [o que testar]
---

# Testes automatizados por stack

## Python (pytest)
```python
import pytest

@pytest.fixture
def cliente_exemplo():
    return {"id": 1, "nome": "Fulano"}

def test_calcular_desconto(cliente_exemplo):
    assert calcular_desconto(cliente_exemplo, 100) == 90

@pytest.mark.parametrize("valor,esperado", [(100, 90), (0, 0), (-10, 0)])
def test_calcular_desconto_varios_casos(valor, esperado):
    assert calcular_desconto({}, valor) == esperado
```
```
pip install pytest pytest-cov pytest-mock
pytest --cov=meu_pacote --cov-report=term-missing
```
Mock de dependência externa: `pytest-mock` (`mocker.patch("modulo.funcao_externa", return_value=...)`) — nunca deixe
um teste unitário bater numa API/banco real, isso o torna um teste de integração disfarçado (lento, instável).

## JavaScript/TypeScript (Jest/Vitest — sintaxe quase idêntica entre os dois)
```javascript
import { describe, it, expect, vi } from 'vitest';

describe('calcularDesconto', () => {
  it('aplica 10% de desconto', () => {
    expect(calcularDesconto(100)).toBe(90);
  });

  it('chama o servico externo', () => {
    const mockFn = vi.fn().mockResolvedValue({ ok: true });
    // ...
  });
});
```
Vitest é mais rápido e tem configuração mais simples para projetos que já usam Vite; Jest é o padrão mais
estabelecido e com mais plugins — escolha conforme o que o projeto já usa, não force migração sem motivo.

## .NET (xUnit)
```csharp
public class CalculoTests
{
    [Theory]
    [InlineData(100, 90)]
    [InlineData(0, 0)]
    public void CalcularDesconto_RetornaValorCorreto(decimal valor, decimal esperado)
    {
        Assert.Equal(esperado, Calculadora.CalcularDesconto(valor));
    }
}
```
```
dotnet add package xunit
dotnet test
```

## Java (JUnit 5)
```java
class CalculoTests {
    @ParameterizedTest
    @CsvSource({"100,90", "0,0"})
    void calcularDesconto_retornaValorCorreto(double valor, double esperado) {
        assertEquals(esperado, Calculadora.calcularDesconto(valor));
    }
}
```

## Page Objects (testes de UI/E2E — padrão de organização, não amarrado a uma ferramenta específica)
Encapsule seletores e ações de uma página numa classe, para o teste ler como um cenário de negócio, não uma lista
de cliques:
```python
class PaginaLogin:
    def fazer_login(self, usuario, senha):
        self.pagina.fill("#usuario", usuario)
        self.pagina.fill("#senha", senha)
        self.pagina.click("#entrar")
```
(A ferramenta de automação de navegador em si — Playwright/Cypress — depende de instalar binários de navegador;
ver a skill correspondente quando essa decisão for tomada.)

## Teste de integração com banco real — precisa de Docker (dependência separada)
Rodar um Postgres/SQL Server real em container para teste de integração garante comportamento mais próximo de
produção que mocks, mas exige Docker instalado (ver skill `docker-windows` quando essa decisão for tomada). Sem
Docker, uma alternativa mais limitada é usar SQLite em memória para os testes (mais rápido, mas alguns
comportamentos específicos do banco de produção não são replicados fielmente).

## Regras
- Teste unitário nunca deve bater em rede/banco/sistema de arquivos real — se bate, é teste de integração, trate e
  nomeie como tal (pastas/marcadores separados, ex.: `@pytest.mark.integration`).
- Cobertura de código (%) é um indicador, não uma meta — 100% de cobertura com asserts fracos (`assert resultado is
  not None`) não garante nada; prefira menos testes que afirmam comportamento real a muitos testes vazios.
- Nunca escreva teste que dependa de ordem de execução dos outros testes — cada teste deve poder rodar sozinho e
  dar o mesmo resultado.

## Arquivos desta skill
Nenhum script fixo — os trechos acima cobrem os casos mais comuns; adapte à stack/domínio reais do usuário.

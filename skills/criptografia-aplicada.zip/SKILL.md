---
name: criptografia-aplicada
description: Aplica hash correto para senhas (bcrypt/argon2, nunca SHA/MD5 puro), criptografia simétrica AES para arquivos e TLS, usando bibliotecas Python puras (sem precisar do OpenSSL instalado separadamente). Use quando o usuário pedir para "guardar senha com segurança", "criptografar esse arquivo", "gerar um hash", "isso está usando MD5, é problema?".
argument-hint: [o que precisa proteger]
---

# Criptografia aplicada

## Hash de senha — NUNCA use SHA-256/MD5 puro para senha
```python
import bcrypt

hash_senha = bcrypt.hashpw("senha-do-usuario".encode(), bcrypt.gensalt())
# guardar hash_senha no banco (ja inclui o salt embutido)

confere = bcrypt.checkpw("senha-digitada".encode(), hash_senha)
```
```
pip install bcrypt
```
`SHA-256`/`MD5` são hashes **rápidos de propósito geral** — ótimos para checar integridade de arquivo, péssimos
para senha, porque um atacante com a lista de hashes vazada consegue testar bilhões de senhas por segundo numa
GPU. `bcrypt`/`argon2` são **deliberadamente lentos** (com fator de custo ajustável) e incluem salt automático —
essa lentidão é a proteção. Se encontrar um sistema usando `SHA-256`/`MD5` puro para senha, isso é uma
vulnerabilidade real a reportar, não um detalhe de implementação.

## Argon2 (alternativa mais moderna, vencedora da competição de hashing de senha)
```python
from argon2 import PasswordHasher
ph = PasswordHasher()
hash_senha = ph.hash("senha-do-usuario")
ph.verify(hash_senha, "senha-digitada")  # levanta excecao se nao bater
```
```
pip install argon2-cffi
```

## Hash para integridade de arquivo (aqui sim, SHA-256 é o certo)
```python
import hashlib
def sha256_arquivo(caminho):
    h = hashlib.sha256()
    with open(caminho, "rb") as f:
        for bloco in iter(lambda: f.read(8192), b""):
            h.update(bloco)
    return h.hexdigest()
```
Ver skill `downloads-uploads-em-massa` para o mesmo padrão aplicado a validar download.

## AES — criptografar/descriptografar arquivo (sem precisar do OpenSSL instalado)
```python
from cryptography.fernet import Fernet

chave = Fernet.generate_key()  # guardar com seguranca (ver skill gerenciar-segredos-windows) - sem ela, os dados sao IRRECUPERAVEIS
f = Fernet(chave)

with open("arquivo.pdf", "rb") as file:
    dados_cifrados = f.encrypt(file.read())
with open("arquivo.pdf.enc", "wb") as file:
    file.write(dados_cifrados)

# para descriptografar
dados_originais = f.decrypt(dados_cifrados)
```
```
pip install cryptography
```
`Fernet` usa AES-128 em modo CBC com autenticação (HMAC) por baixo — é a opção recomendada para "criptografar um
arquivo/dado com uma chave simétrica" sem precisar entender os detalhes de modo de operação AES manualmente. A
biblioteca `cryptography` já traz o OpenSSL compilado internamente no pacote Windows — não precisa instalar
`openssl.exe` separado para isso funcionar.

## Assinatura digital (verificar que algo não foi alterado e veio de quem diz)
```python
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives import hashes

chave_privada = rsa.generate_private_key(public_exponent=65537, key_size=2048)
assinatura = chave_privada.sign(dados, padding.PSS(mgf=padding.MGF1(hashes.SHA256()), salt_length=padding.PSS.MAX_LENGTH), hashes.SHA256())
# a chave publica correspondente verifica com .verify(assinatura, dados, ...) - levanta excecao se nao bater
```

## TLS (HTTPS) — o que não fazer
```python
# NUNCA em producao: desativa verificacao de certificado, abre a porta para ataque man-in-the-middle
requests.get(url, verify=False)
```
Se o erro é de certificado autoassinado/expirado num ambiente interno de teste, resolva o certificado (gere um
válido, ou adicione a CA interna ao repositório de confiança) — nunca desative a verificação como solução, mesmo
"só para testar", porque esse código tende a ir para produção sem ninguém perceber.

## Regras
- Nunca implemente um algoritmo de criptografia "do zero" — sempre use uma biblioteca estabelecida
  (`cryptography`, `bcrypt`, `argon2-cffi`); criptografia caseira quase sempre tem falha sutil que não aparece em
  teste normal.
- Nunca use `SHA-256`/`MD5` para senha, mesmo com salt manual — use `bcrypt`/`argon2`.
- Chave de criptografia simétrica (Fernet): perder a chave torna os dados irrecuperáveis para sempre — trate a
  chave com o mesmo cuidado (ou mais) que o dado que ela protege (ver skill `gerenciar-segredos-windows`).

## Arquivos desta skill
Nenhum script fixo — os trechos acima cobrem os casos mais comuns; adapte à necessidade real do usuário.

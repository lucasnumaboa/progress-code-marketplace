---
name: sqlite-local
description: Cria e consulta um banco SQLite local (embutido no Python, sem instalar nada) para usar como cache, catálogo de dados do projeto, ou importar planilhas para consultar com SQL. Use quando o usuário pedir para "guardar isso num banco local", "importar essa planilha para um banco", "criar um índice/cache para consultas repetidas".
argument-hint: [caminho do .db] [operação]
---

# SQLite como banco local

## Por que SQLite aqui
`sqlite3` já vem embutido na biblioteca padrão do Python — nenhuma instalação, nenhum servidor rodando, o banco é
um único arquivo `.db`. Ideal para: cache de resultado de uma consulta lenta, catálogo pequeno/médio de dados do
projeto, ou como destino intermediário ao importar uma planilha para consultar com SQL de verdade.

## Passo 1 — Criar/conectar e criar tabela
```python
import sqlite3

con = sqlite3.connect("catalogo.db")
con.execute("""
    CREATE TABLE IF NOT EXISTS produtos (
        id INTEGER PRIMARY KEY,
        nome TEXT NOT NULL,
        categoria TEXT,
        preco REAL
    )
""")
con.commit()
```

## Passo 2 — Importar planilha/CSV
```python
import pandas as pd
df = pd.read_excel("produtos.xlsx")
df.to_sql("produtos", con, if_exists="replace", index=False)
```
`if_exists="replace"` apaga e recria a tabela — use `"append"` se o objetivo é acumular dados de várias importações,
mas aí trate duplicidade (chave única) antes, ou a mesma linha entra várias vezes a cada reimportação.

## Passo 3 — Consultar
```python
cursor = con.execute("SELECT categoria, COUNT(*), AVG(preco) FROM produtos GROUP BY categoria")
for linha in cursor:
    print(linha)

# ou direto num DataFrame
df_resultado = pd.read_sql("SELECT * FROM produtos WHERE preco > 100", con)
```

## Passo 4 — Índice para consulta repetida rápida
```python
con.execute("CREATE INDEX IF NOT EXISTS idx_categoria ON produtos(categoria)")
```
Crie índice nas colunas usadas em `WHERE`/`JOIN`/`GROUP BY` com frequência — sem índice, toda consulta varre a
tabela inteira; em tabelas pequenas (poucos milhares de linhas) isso raramente importa, mas vale a pena a partir de
dezenas de milhares de linhas.

## Regras
- `sqlite3.connect` cria o arquivo automaticamente se não existir — confirme com o usuário se o arquivo de destino
  já existir e tiver dados, para não sobrescrever sem querer.
- SQLite trava o arquivo inteiro em escrita concorrente (não é feito para múltiplos processos escrevendo ao mesmo
  tempo) — não proponha como substituto de um banco de verdade (SQL Server/Postgres) para uma aplicação com vários
  usuários gravando simultaneamente.
- Sempre feche a conexão (`con.close()`) ou use `with sqlite3.connect(...) as con:` — conexão aberta demais impede
  outro processo de acessar o arquivo.

## Arquivos desta skill
Nenhum script fixo — os trechos acima cobrem o padrão de uso; adapte ao esquema real do usuário.

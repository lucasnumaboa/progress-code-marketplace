---
name: dotnet-csharp-moderno
description: Usa o dotnet CLI moderno — projetos, NuGet, async/await, Entity Framework Core, minimal APIs — e sabe ler exceptions e stack traces .NET para achar a causa real. Use quando o usuário pedir para "criar um projeto .NET/C#", "essa exception .NET não faz sentido", "configurar o Entity Framework", "publicar como self-contained".
argument-hint: [tipo de projeto/dúvida .NET]
---

# .NET / C# moderno

## Pré-requisito
Precisa do .NET SDK instalado (`dotnet --version`). Se não estiver, `winget install Microsoft.DotNet.SDK.8` (ver
skill `instalar-software-ambientes`).

## Criar e rodar projetos
```
dotnet new webapi -n MinhaApi
dotnet new console -n MeuConsole
dotnet new classlib -n MinhaBiblioteca
cd MinhaApi && dotnet run
```

## NuGet
```
dotnet add package Microsoft.EntityFrameworkCore.SqlServer
dotnet restore
dotnet list package --outdated
```

## async/await — a armadilha mais comum
```csharp
// ERRADO: bloqueia a thread esperando a Task, pode causar deadlock em contexto com SynchronizationContext (ex.: ASP.NET classico)
var resultado = MetodoAssincronoAsync().Result;

// CERTO: propaga async ate o topo da cadeia de chamadas
var resultado = await MetodoAssincronoAsync();
```
`.Result`/`.Wait()` sobre uma `Task` de dentro de código que já roda num contexto assíncrono é a causa clássica de
deadlock em aplicações .NET mais antigas (menos comum em ASP.NET Core moderno, que não tem `SynchronizationContext`
por padrão, mas ainda uma prática ruim).

## Entity Framework Core — mínimo essencial
```csharp
public class MeuContexto : DbContext
{
    public DbSet<Cliente> Clientes { get; set; }
    protected override void OnConfiguring(DbContextOptionsBuilder options) =>
        options.UseSqlServer(connectionString);
}
```
```
dotnet ef migrations add InicialCriacao
dotnet ef database update
```
`AsNoTracking()` em consultas só de leitura evita overhead de rastreamento de mudança desnecessário — use sempre
que o resultado não vai ser modificado e salvo de volta.

## Minimal API (endpoints sem controller)
```csharp
var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();
app.MapGet("/clientes/{id}", async (int id, MeuContexto db) => await db.Clientes.FindAsync(id));
app.Run();
```

## Publicar self-contained (não precisa do .NET instalado na máquina de destino)
```
dotnet publish -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true
```

## Ler exceptions .NET (de baixo para cima no stack trace)
```
System.NullReferenceException: Object reference not set to an instance of an object.
   at MeuNamespace.MinhaClasse.MeuMetodo() in C:\projeto\MinhaClasse.cs:line 42
   at MeuNamespace.Program.Main(String[] args) in C:\projeto\Program.cs:line 10
```
A **primeira linha do stack trace de baixo para cima que está no seu código** (não em bibliotecas do framework) é
onde procurar primeiro — `line 42` diz exatamente onde. `NullReferenceException` sempre significa: algo que você
assumiu não-nulo estava nulo — confira o valor logo antes daquela linha.

## Regras
- Nunca use `async void` exceto em handlers de evento — exceção dentro de `async void` não pode ser capturada por
  quem chamou, derruba a aplicação de forma difícil de rastrear.
- Sempre `Dispose()`/`using` em `DbContext`, `HttpClient` de vida curta e outros `IDisposable` — `HttpClient` tem a
  particularidade de que criar um novo a cada requisição (em vez de reusar via `IHttpClientFactory`) esgota sockets
  sob carga.
- `connectionString`/segredos: nunca em `appsettings.json` versionado — use `dotnet user-secrets` em desenvolvimento
  e variável de ambiente/Key Vault em produção.

## Arquivos desta skill
Nenhum script fixo — os trechos acima cobrem os casos mais comuns; adapte ao projeto real do usuário.

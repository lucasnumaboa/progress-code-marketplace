---
name: escrever-bons-prompts
description: Escreve prompts e system prompts eficazes — estrutura, exemplos few-shot, saída estruturada em JSON, redução de alucinação, e como adaptar por tamanho/capacidade do modelo. Use quando o usuário pedir para "melhorar esse prompt", "escrever um system prompt para esse agente", "por que o modelo não está seguindo essa instrução", "fazer o modelo responder em JSON de forma confiável".
argument-hint: [o que o prompt precisa fazer] [modelo-alvo, se souber]
---

# Escrever bons prompts e system prompts

## Estrutura que funciona (na ordem)
1. **Papel/contexto**: quem o modelo é nessa interação e por quê (ex.: "Você é um assistente de suporte técnico
   para o produto X").
2. **Tarefa específica**: o que fazer, em linguagem direta e imperativa, não vaga ("resuma o texto abaixo em até 3
   frases", não "ajude com esse texto").
3. **Restrições explícitas**: o que não fazer, formato exato esperado, tom.
4. **Exemplos (few-shot)** quando o formato de saída é específico ou o comportamento é sutil de explicar só com
   regra (ver abaixo).
5. **A entrada/pergunta em si**, claramente demarcada do resto do prompt (ex.: com um delimitador `---` ou tag XML)
   para o modelo não confundir instrução com dado a processar.

## Few-shot — quando exemplos valem mais que regras
Para tarefas de formato ou julgamento sutil, 2-3 exemplos de entrada→saída no prompt geralmente superam uma
descrição longa da regra:
```
Classifique o sentimento como positivo, negativo ou neutro.

Texto: "Adorei o atendimento, super rápido!"
Sentimento: positivo

Texto: "Demorou 3 semanas e ninguém respondeu meu e-mail."
Sentimento: negativo

Texto: "{entrada real do usuário}"
Sentimento:
```
Escolha exemplos que cubram os casos-limite reais do domínio (não só os óbvios) — se o problema real é distinguir
"neutro" de "levemente negativo", inclua um exemplo exatamente nessa fronteira.

## Saída estruturada em JSON (confiável, não "na maioria das vezes")
```
Responda APENAS com um objeto JSON no formato exato abaixo, sem texto antes ou depois:
{"categoria": "string", "confianca": 0.0, "motivo": "string"}
```
Para uso via API (não conversação), prefira o recurso nativo de saída estruturada da API quando disponível
(`response_format`/structured outputs da OpenAI, `tool_use` forçado da Anthropic) em vez de só pedir "responda em
JSON" no texto — o recurso nativo garante a validade sintática do JSON, o pedido em texto livre não garante (o
modelo pode, ocasionalmente, adicionar uma frase antes/depois mesmo instruído a não fazer).

## Reduzir alucinação
- Dê ao modelo permissão explícita para dizer "não sei"/"a informação não está disponível" — sem essa permissão
  explícita, alguns modelos preferem inventar uma resposta plausível a admitir incerteza.
- Peça para citar a fonte/trecho específico de onde tirou a informação (quando há um documento de referência no
  contexto) — isso força o modelo a ancorar a resposta no material fornecido em vez de "completar de memória".
- Para fatos verificáveis, prefira perguntar "o que o documento X diz sobre Y" a "o que você sabe sobre Y" quando
  o documento estiver disponível no contexto.

## Adaptar por tamanho/capacidade do modelo
Modelos menores/mais rápidos precisam de instruções **mais literais e menos ambíguas** — passos numerados,
comandos exatos em vez de descrição de alto nível, condições explícitas de quando parar. Modelos maiores toleram
instrução mais abstrata/de intenção e conseguem inferir passos intermediários razoavelmente. Ao escrever uma skill/
system prompt que vai rodar em modelos variados (ver `CRIANDO-SKILLS.md` deste próprio projeto para o mesmo
princípio aplicado a skills), escreva pensando no modelo mais fraco do conjunto-alvo — o modelo forte ainda segue
bem instruções literais, o contrário não é verdade.

## Avaliar se um prompt está bom (antes de considerar pronto)
Rode contra um conjunto pequeno mas representativo de casos reais (incluindo casos-limite e "pegadinhas" do
domínio), não só o caso feliz óbvio — um prompt que só foi testado com um exemplo fácil tende a falhar
silenciosamente em produção com entrada real mais variada.

## Regras
- Nunca escreva um prompt vago esperando que o modelo "adivinhe" a intenção certa — seja específico sobre formato,
  tom e o que fazer em casos ambíguos/de erro.
- Ao pedir saída estruturada para uso programático, prefira o recurso nativo da API a confiar só em instrução de
  texto livre.
- Teste o prompt contra casos-limite reais do domínio antes de considerar pronto, não só o caso mais óbvio.

## Arquivos desta skill
Nenhum script fixo — os princípios acima orientam qualquer prompt/system prompt escrito para o usuário.

# Origem e licença

Esta skill é uma cópia, com as alterações listadas abaixo, de material de especialista com licença aberta.

- **Fonte:** https://github.com/brendanlong/alt-text-skill
- **Arquivos de origem:** `plugins/alt-text/skills/alt-text/SKILL.md`
- **Autor:** Brendan Long
- **Licença:** MIT (texto completo em `LICENSE`)
- **Commit:** `83b8d078ee215e469e6a45d43a45e9e57488d855` (baixado em 2026-11-22)

## Alterações feitas

- `name:` do frontmatter trocado de `alt-text` para `alt-alt-text`.
- Fora isso, o texto do especialista está como no original (em inglês).

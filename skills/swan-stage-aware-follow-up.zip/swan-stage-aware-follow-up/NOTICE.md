# Aviso de terceiros (NOTICE)

Esta skill é uma cópia adaptada de material de terceiros e é redistribuída sob a licença original. O texto do especialista ficou em inglês, como no original.

- **Origem:** https://github.com/swan-gtm/gtm-skills
- **Caminho no repositório:** `skills/tanyo-gochev/stage-aware-follow-up`
- **Commit:** `eb0026f469f90645e1a64168d08a3e0afb59ee12` (baixado em 2026-11-22)
- **Autor:** Tanyo Gochev (autor da skill); copyright do repositório: Swan
- **Licença:** MIT (texto completo em `LICENSE`, copiado de `LICENSE` do repositório)

## Arquivos incluídos

- `SKILL.md` (de `skills/tanyo-gochev/stage-aware-follow-up/SKILL.md`)
- `author.md` (de `skills/tanyo-gochev/author.md`, crédito do autor pedido pelo repositório)
- `LICENSE`

## Mudanças feitas

- Frontmatter: `name: stage-aware-follow-up` trocado por `name: swan-stage-aware-follow-up` (a descrição ficou igual).

## Crédito do autor (author.md)

O repositório pede que o crédito do autor acompanhe a skill. Conteúdo do `author.md` original:

```markdown
---
name: Tanyo Gochev
avatarUrl: https://www.gtmskills.com/authors/tanyo-gochev.jpg
title: "Co-Founder & Head of GTM, The Demand Department"
linkedinUrl: https://www.linkedin.com/in/tanyo/
companyDomain: demanddept.com
email: tanyo@copytg.com
---

Co-Founder and Head of GTM of The Demand Department. We build go-to-market engines for funded B2B startups and founder-led service businesses — the list, the offer, the sequences, the content, and the pipeline discipline that holds them together.
```

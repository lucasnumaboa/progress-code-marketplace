---
name: armadilhas-telas-w-progress
description: Armadilhas de tempo de execução ao alterar telas Progress/OpenEdge geradas pelo UIB/AppBuilder (.w) com o framework ADM do Datasul — campo que não aceita digitação, variável local que sombreia o widget da tela, ordem do local-initialize, data fixa (TODAY) espalhada pelo fonte, reset de tela que apaga o que o usuário digitou, programa irmão com a lógica duplicada. Use ao alterar, revisar ou depurar um .w, especialmente quando o sintoma for "a tela não aceita o que eu digito", "ele ignora o valor da tela" ou "só funciona com a data de hoje".
---

# Alterando telas .w (UIB/AppBuilder + ADM)

Um `.w` não é um programa comum: o UIB gera blocos que o compilador aceita mas que se contradizem em
runtime. Os erros abaixo **não dão erro de compilação** — a tela simplesmente ignora o usuário. Todos vieram
de casos reais; confira cada um antes de dizer que a alteração está pronta.

## 1. Campo que não aceita digitação

Um campo só recebe entrada do usuário se estiver nas **duas** listas:

- `&Scoped-Define ENABLED-OBJECTS` (bloco de definições do UIB, no topo do fonte);
- o `ENABLE ... WITH FRAME f-...` dentro do `enable_UI`.

Fora disso ele aparece na tela e não aceita nada (é o efeito de `NO-ENABLE`). Se o pedido é "quero poder
digitar aqui", editar só o `ENABLE` ou só a lista não resolve.

Para o campo passar a rebuscar dados ao ser preenchido, reaproveite a rotina que já existe em vez de
duplicar a query:

```progress
&Scoped-define SELF-NAME d-data
ON LEAVE OF d-data IN FRAME f-cad /* Data */
DO:
    APPLY 'LEAVE':U TO c-item IN FRAME {&FRAME-NAME}.
END.
```

## 2. Variável local com o mesmo nome do widget

```progress
DEFINE VARIABLE d-data AS DATE NO-UNDO.   /* existe um campo d-data na tela */
ASSIGN d-data = DATE(pi-buscar-dt-fim-prod(INPUT emp)).
```

Dentro desse procedimento `d-data` é a variável, **não** o campo: o que o usuário digitou nunca é lido e o
programa trabalha com outro valor. É silencioso e costuma aparecer em mais de um procedimento do mesmo
fonte (quem escreveu copiou o bloco).

- Ao mexer num procedimento que usa um nome de campo, procure `DEFINE VARIABLE <nome>` no fonte inteiro.
- Para ler a tela use sempre `campo:SCREEN-VALUE IN FRAME {&FRAME-NAME}`, com fallback para a regra antiga:

```progress
IF d-data:SCREEN-VALUE IN FRAME {&FRAME-NAME} <> "" THEN
    ASSIGN dt-emissao = DATE(d-data:SCREEN-VALUE IN FRAME {&FRAME-NAME}) NO-ERROR.
IF dt-emissao = ? THEN
    ASSIGN dt-emissao = /* regra antiga */ .
```

- Renomeie a **variável local** (`dt-emissao`, `d-aux`), não o widget: o widget aparece em `ENABLE`,
  `DISPLAY`, triggers e no bloco de definições do UIB.

## 3. Ordem do `local-initialize`

O ADM chama os blocos numa ordem fixa, e `APPLY 'LEAVE'` / `RUN` disparam triggers **na hora**. Um
`APPLY 'leave' TO c-estabel` antes do `ASSIGN d-data = TODAY` roda o trigger com o campo ainda vazio:
`DATE(d-data:SCREEN-VALUE)` devolve `?` na primeira passada e a tela abre sem dados.

Regra: preencher e exibir (`ASSIGN` + `DISPLAY`) **antes** de aplicar eventos que dependem daquele valor.
Ao ler um `local-initialize`, siga a sequência linha a linha em vez de olhar cada comando isolado.

## 4. Data fixa espalhada pelo fonte

Quando a tela passa a aceitar uma data informada (ou qualquer parâmetro que antes era constante),
**inventarie todas as ocorrências antes de responder** — não corrija só o ponto que o usuário citou:

- `WHERE ... >= TODAY - n`, `MONTH(campo) = MONTH(TODAY)`, `dt-vali-lote > TODAY`;
- validações de pendentes/duplicidade (`IF ... data_emissao >= TODAY - 1`);
- procedimentos auxiliares do mesmo fonte que refazem a busca por conta própria;
- `pi-limpa-tela` e afins, que devolvem o campo para `TODAY` depois de gravar e apagam o que foi digitado
  (decida com o usuário se a data digitada deve ser preservada entre execuções);
- gravações (`data_emissao`, `data`) que continuam recebendo a data antiga;
- **programas chamados** (`RUN esp/mbpl011f.p`): se gravam `TODAY` internamente e não recebem a data por
  parâmetro, a alteração para na fronteira — diga isso ao usuário em vez de dar por resolvido.

Ocorrência dentro de comentário (`/* ... */`) ou de bloco morto é no-op: verifique antes de "corrigir" e
avise que era comentário.

## 5. Programa irmão com a lógica duplicada

Telas do Datasul costumam ter irmãs (`plt0020.w` e `plt0020A.w`, `...B.w`) com a mesma regra copiada. Ao
alterar uma, liste as irmãs na pasta e pergunte qual está em produção — corrigir só uma metade é o mesmo
que não corrigir.

## 6. Integridade do arquivo

Fonte de cliente costuma estar em **CP850/CP1252 com CRLF**. Leia, altere e grave preservando o encoding e
as quebras de linha, e guarde um `.bak` antes. Depois confira: contagem de linhas, zero bytes UTF-8
inesperados, acentos intactos.

## Antes de responder

1. `ENABLE` + `ENABLED-OBJECTS` conferidos, se o pedido envolvia digitação.
2. Nenhuma variável local sombreando o campo alterado (procure `DEFINE VARIABLE` com o nome dele).
3. Todas as ocorrências do padrão trocado decididas uma por uma — o resultado da ferramenta Edit lista as
   que sobraram; não ignore.
4. Ordem do `local-initialize` conferida como sequência de runtime, não só lida.
5. Irmãs do programa e programas chamados mencionados.

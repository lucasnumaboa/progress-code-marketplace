---
name: limpeza-deduplicacao-cadastros
description: Normaliza nomes, endereços e telefones brasileiros e encontra registros parecidos (fuzzy matching) para deduplicar cadastros, gerando um relatório de conflitos para revisão humana em vez de mesclar automaticamente. Use quando o usuário pedir para "limpar essa base de clientes", "achar duplicados", "esse cadastro tem gente repetida com nome escrito diferente".
argument-hint: [planilha/tabela de cadastro] [colunas a comparar]
---

# Limpeza e deduplicação de cadastros

## Passo 1 — Instalar
```
pip install pandas rapidfuzz unidecode
```

## Passo 2 — Normalizar antes de comparar
Nunca compare texto bruto — normalize primeiro (senão "João Silva" e "JOAO DA SILVA " nunca vão "parecer iguais"
o suficiente):
```python
from unidecode import unidecode
import re

def normalizar(texto):
    if not isinstance(texto, str):
        return ""
    texto = unidecode(texto).upper().strip()
    texto = re.sub(r"\s+", " ", texto)          # espacos multiplos -> um so
    texto = re.sub(r"[^\w\s]", "", texto)        # remove pontuacao
    return texto

df["nome_normalizado"] = df["nome"].apply(normalizar)
```
Telefone: extraia só os dígitos (`re.sub(r"\D", "", telefone)`) antes de comparar — `(11) 99999-8888` e
`11999998888` são o mesmo número, mas string bruta nunca vai bater.

## Passo 3 — Fuzzy matching (achar parecidos, não só idênticos)
```python
from rapidfuzz import process, fuzz

nomes = df["nome_normalizado"].tolist()
candidatos = []
for i, nome in enumerate(nomes):
    matches = process.extract(nome, nomes[i+1:], scorer=fuzz.token_sort_ratio, limit=5, score_cutoff=85)
    for nome_parecido, score, _ in matches:
        candidatos.append({"nome_a": nome, "nome_b": nome_parecido, "score": score})
```
`token_sort_ratio` ignora ordem das palavras ("Silva João" ≈ "João Silva"). `score_cutoff=85` é um ponto de partida
razoável — abaixo disso começam a aparecer falsos positivos (nomes diferentes que só parecem parecidos); ajuste
olhando uma amostra real antes de rodar na base inteira.

## Passo 4 — Relatório de conflitos (nunca mesclar sozinho)
Gere uma planilha com os pares candidatos a duplicado, incluindo as colunas originais (não só as normalizadas) e o
score, para um humano decidir:
```python
relatorio = pd.DataFrame(candidatos).sort_values("score", ascending=False)
relatorio.to_excel("possiveis_duplicados.xlsx", index=False)
```

## Regras
- **Nunca mescle ou apague registros automaticamente.** Fuzzy matching erra (nomes parecidos que são pessoas
  diferentes, como irmãos ou pai/filho com nome quase igual) — sempre entregue como relatório para revisão humana,
  nunca como ação já aplicada.
- CPF/CNPJ, quando disponível, é um identificador muito mais confiável que nome para achar duplicado de verdade —
  se a base tiver essa coluna, priorize comparação exata por CPF/CNPJ (normalizado, só dígitos) antes de recorrer a
  fuzzy matching por nome.
- Endereço: normalizar abreviações comuns antes de comparar (`R.`/`Rua`, `Av.`/`Avenida`, `Apto`/`Apartamento`) ou o
  fuzzy matching vai subestimar a similaridade de endereços que são, na prática, o mesmo lugar.

## Arquivos desta skill
Nenhum script fixo — os trechos acima cobrem o fluxo completo; adapte às colunas reais da base do usuário.

# Aviso de terceiros (NOTICE)

Esta skill é uma cópia adaptada de material de terceiros e é redistribuída sob a licença original. O texto do especialista ficou em inglês, como no original.

- **Origem:** https://github.com/coreyhaines31/marketingskills
- **Caminho no repositório:** `skills/revops`
- **Commit:** `5b2b400eec1e7e1cec76245a715d0b0d4fd2a9c1` (baixado em 2026-11-22)
- **Autor:** Corey Haines
- **Licença:** MIT (texto completo em `LICENSE`, copiado de `LICENSE` do repositório)

## Arquivos incluídos

- `SKILL.md` (de `skills/revops/SKILL.md`)
- `references/automation-playbooks.md` (de `skills/revops/references/automation-playbooks.md`)
- `references/inbound-routing.md` (de `skills/revops/references/inbound-routing.md`)
- `references/lifecycle-definitions.md` (de `skills/revops/references/lifecycle-definitions.md`)
- `references/routing-rules.md` (de `skills/revops/references/routing-rules.md`)
- `references/scoring-models.md` (de `skills/revops/references/scoring-models.md`)
- `LICENSE`

## Mudanças feitas

- Frontmatter: `name: revops` trocado por `name: mk-revops` (a descrição ficou igual).
- `SKILL.md`: removida a seção "## Tool Integrations" (tabela de links para o registro de ferramentas do repositório original, que não acompanha a skill, com marcações de parceiro e ferramenta do próprio mantenedor).

## Arquivos do original que não foram incluídos

- `evals/evals.json` (casos de teste do autor, não usados pela skill).

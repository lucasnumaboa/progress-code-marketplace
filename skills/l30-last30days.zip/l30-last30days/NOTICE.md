# Origem e mudanças

- **Repositório:** https://github.com/mvanhorn/last30days-skill
- **Caminho no repositório:** `skills/last30days`
- **Autor:** Matt Van Horn
- **Licença:** MIT (texto em `LICENSE`)
- **Commit usado:** `b1b096bd5ac9ab945da757ebc3ccee0c5f264fd6`
- **Arquivos copiados:** `SKILL.md`, `references/comparison.md`, `references/synthesis.md`

## Mudanças feitas

- no cabeçalho (frontmatter), `name:` passou de `last30days` para `l30-last30days`; a descrição ficou igual
- removido do cabeçalho (frontmatter) o bloco `metadata` (registro "openclaw": variáveis de chaves de API, binários e tags de instalação do motor próprio)
- removido o parágrafo que obriga a rodar o motor Python próprio (não incluído)
- removidas as seções "Bootstrap and file reads", "Reference routing" e "Dispatch before research" (instalação, inicialização, primeiro uso, chaves e roteamento do motor Python próprio, não incluído)
- removidas as seções "HTML and follow-up handoff" e "Security & Permissions" (exportação e chamadas de rede do motor Python próprio, não incluído)
- nenhuma outra alteração no texto do especialista (mantido em inglês)

## Observações

- o motor Python do autor (`scripts/`, 177 arquivos, com caminhos que usam APIs pagas, cookies de navegador e publicação em ht-ml.app) NÃO foi incluído. Ficaram as leis de saída, a autoconferência e as referências de síntese (`references/synthesis.md`) e comparação (`references/comparison.md`). As demais referências tratam do motor e não foram copiadas; regras que citam o rodapé, o selo ou comandos do motor não se aplicam sem ele

Empacotada para o marketplace do Progress Code em 2026-11-22.

- Acrescentada no topo uma nota (em inglês) avisando que o motor Python não vem no pacote e que as regras de selo, rodapé e comandos do motor não se aplicam.

---
name: gerar-qrcode-codigo-barras
description: Gera QR Code (com ou sem logo), código de barras EAN-13/Code128 e QR PIX (payload EMV completo) para impressão em etiquetas, usando qrcode e python-barcode. Use quando o usuário pedir "gerar um QR code", "código de barras para esse produto", "QR code do PIX", "etiqueta com código de barras".
argument-hint: [qrcode|barcode|pix] [conteúdo]
---

# QR Code e código de barras

## Passo 1 — Instalar
```
pip install qrcode[pil] python-barcode Pillow
```

## Passo 2 — QR Code simples e com logo
```python
import qrcode
from PIL import Image

qr = qrcode.QRCode(error_correction=qrcode.constants.ERROR_CORRECT_H)  # H = 30% de correcao, sobra espaco pro logo
qr.add_data("https://exemplo.com")
qr.make(fit=True)
img = qr.make_image(fill_color="black", back_color="white").convert("RGB")

logo = Image.open("logo.png")
tamanho_logo = min(img.size) // 4  # logo nao pode passar de ~25% da area ou quebra a leitura
logo.thumbnail((tamanho_logo, tamanho_logo))
pos = ((img.width - logo.width) // 2, (img.height - logo.height) // 2)
img.paste(logo, pos, logo if logo.mode == "RGBA" else None)
img.save("qrcode.png")
```
`error_correction=ERROR_CORRECT_H` é obrigatório quando for colocar logo por cima — com correção menor o QR pode
ficar ilegível.

## Passo 3 — Código de barras (EAN-13, Code128)
```python
import barcode
from barcode.writer import ImageWriter

# EAN-13 exige 12 digitos (o 13o e o digito verificador, calculado sozinho)
codigo = barcode.get("ean13", "078439899", writer=ImageWriter())
codigo.save("codigo-ean13")  # gera codigo-ean13.png

codigo128 = barcode.get("code128", "PEDIDO-00123", writer=ImageWriter())
codigo128.save("codigo-128")
```
EAN-13 só aceita dígitos numéricos (12 antes do verificador); Code128 aceita texto alfanumérico livre — escolha
conforme a regra do sistema que vai ler o código (a maioria dos leitores de mercado só lê EAN/UPC).

## Passo 4 — QR PIX (payload EMV/BR Code)
O payload do PIX segue o padrão EMV QR Code (o mesmo usado em outros países, com campos específicos do Banco
Central). Monte o payload manualmente (não existe biblioteca oficial simples para isso) seguindo a estrutura
TLV (tag-length-value) e calcule o CRC16 no final — use `scripts/gerar_pix.py`, que já implementa o payload estático
(valor fixo ou em aberto) com chave PIX, nome do recebedor, cidade e valor opcional.
```
python scripts/gerar_pix.py --chave "11999998888" --nome "FULANO DE TAL" --cidade "SAO PAULO" --valor 150.00 --saida pix.png
```
**Atenção**: PIX dinâmico (com QR que expira e retorna dados via API do banco) exige integração com o banco/PSP —
isso é bem mais envolvido que o payload estático e está fora do escopo desta skill; avise o usuário se for esse o
caso.

## Regras
- Nome/cidade do recebedor no PIX: o padrão exige maiúsculas sem acento e limite de caracteres (nome até 25, cidade
  até 15) — o script normaliza automaticamente, mas avise o usuário se o nome tiver sido truncado.
- Sempre teste a leitura do QR/código gerado (visualmente, com `Read`/`ViewImage`, ou pedindo para o usuário
  escanear) antes de considerar concluído — payload PIX errado é um erro sério (dinheiro pode ir para lugar errado
  se o CRC/chave estiver incorreto).
- EAN-13 com dígito verificador errado (calculado por você manualmente) é rejeitado por qualquer leitor de mercado —
  sempre deixe a biblioteca calcular, nunca digite o 13º dígito à mão.

## Arquivos desta skill
- `scripts/gerar_pix.py` — monta o payload EMV do PIX estático (com CRC16) e gera o QR Code.

"""Gera o payload EMV/BR Code do PIX estatico (com CRC16) e o QR Code correspondente.

Nao cobre PIX dinamico (que exige integracao com o banco/PSP).

Uso:
    python gerar_pix.py --chave "11999998888" --nome "FULANO DE TAL" --cidade "SAO PAULO" \
        --valor 150.00 --saida pix.png
"""
import argparse
import re
import unicodedata

import qrcode


def remover_acentos(texto):
    nfkd = unicodedata.normalize("NFKD", texto)
    return "".join(c for c in nfkd if not unicodedata.combining(c))


def campo(tag, valor):
    valor = str(valor)
    return f"{tag}{len(valor):02d}{valor}"


def crc16_ccitt_false(payload):
    """CRC16/CCITT-FALSE: poly 0x1021, init 0xFFFF, sem reflexao - o exigido pelo padrao EMV/PIX."""
    crc = 0xFFFF
    for byte in payload.encode("utf-8"):
        crc ^= byte << 8
        for _ in range(8):
            if crc & 0x8000:
                crc = ((crc << 1) ^ 0x1021) & 0xFFFF
            else:
                crc = (crc << 1) & 0xFFFF
    return format(crc, "04X")


def montar_payload(chave, nome, cidade, valor=None, descricao=None, txid="***"):
    nome = remover_acentos(nome).upper()[:25]
    cidade = remover_acentos(cidade).upper()[:15]

    merchant_account = campo("00", "br.gov.bcb.pix") + campo("01", chave)
    if descricao:
        merchant_account += campo("02", remover_acentos(descricao)[:99])

    partes = [
        campo("00", "01"),                # Payload Format Indicator
        campo("01", "11"),                # Point of Initiation Method: 11 = estatico
        campo("26", merchant_account),    # Merchant Account Information - PIX
        campo("52", "0000"),              # Merchant Category Code
        campo("53", "986"),               # Transaction Currency: BRL
    ]
    if valor is not None:
        partes.append(campo("54", f"{float(valor):.2f}"))
    partes += [
        campo("58", "BR"),                # Country Code
        campo("59", nome),                # Merchant Name
        campo("60", cidade),              # Merchant City
        campo("62", campo("05", txid)),   # Additional Data Field: Reference Label
    ]

    payload_sem_crc = "".join(partes) + "6304"
    crc = crc16_ccitt_false(payload_sem_crc)
    return payload_sem_crc + crc


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--chave", required=True, help="chave PIX (CPF/CNPJ/e-mail/telefone/aleatoria)")
    ap.add_argument("--nome", required=True, help="nome do recebedor (max 25 caracteres, sem acento)")
    ap.add_argument("--cidade", required=True, help="cidade do recebedor (max 15 caracteres, sem acento)")
    ap.add_argument("--valor", type=float, default=None, help="valor fixo (omitir para deixar em aberto)")
    ap.add_argument("--descricao", default=None)
    ap.add_argument("--saida", required=True, help="arquivo .png de saida")
    args = ap.parse_args()

    payload = montar_payload(args.chave, args.nome, args.cidade, args.valor, args.descricao)
    print("Payload:", payload)

    img = qrcode.make(payload)
    img.save(args.saida)
    print(f"QR Code gerado: {args.saida}")


if __name__ == "__main__":
    main()

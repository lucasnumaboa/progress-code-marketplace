---
name: estatistica-descritiva-anomalias
description: Calcula estatística descritiva (média, mediana, desvio, percentis) e detecta outliers/anomalias (IQR, z-score) e sazonalidade, com critério para decidir se um número "estranho" é anomalia real ou erro de dado. Use quando o usuário pedir "tem algo estranho nesses dados?", "achar os outliers", "esse número parece errado, é anomalia ou erro?".
argument-hint: [dados/coluna a analisar]
---

# Estatística descritiva e detecção de anomalias

## Passo 1 — Sempre comece pela descrição básica
```python
import pandas as pd
print(df["valor"].describe())  # count, mean, std, min, 25%, 50%, 75%, max
```
Olhe `min`/`max` contra `25%`/`75%` antes de qualquer teste formal — um `max` muito maior que o 75º percentil já é
um indício visual de outlier, antes mesmo de calcular qualquer coisa.

## Passo 2 — Outliers por IQR (robusto, bom padrão para a maioria dos casos)
```python
q1, q3 = df["valor"].quantile([0.25, 0.75])
iqr = q3 - q1
limite_inferior = q1 - 1.5 * iqr
limite_superior = q3 + 1.5 * iqr
outliers = df[(df["valor"] < limite_inferior) | (df["valor"] > limite_superior)]
```
`1.5 * IQR` é a convenção padrão (a mesma usada no box plot). Para detecção mais rigorosa (só os casos extremos),
use `3 * IQR` em vez de `1.5`.

## Passo 3 — Outliers por z-score (quando os dados são aproximadamente normais)
```python
from scipy import stats
z = stats.zscore(df["valor"].dropna())
outliers_z = df.loc[df["valor"].dropna().index[abs(z) > 3]]
```
Z-score assume distribuição aproximadamente normal — se os dados forem muito assimétricos (ex.: valores de venda,
que costumam ter cauda longa à direita), IQR costuma ser mais confiável que z-score.

## Passo 4 — Sazonalidade (antes de chamar algo de "anomalia")
Um valor alto em dezembro (Natal) ou baixo em fevereiro (poucos dias úteis) não é anomalia — é padrão sazonal.
Antes de sinalizar algo como anômalo, compare com o **mesmo período em anos anteriores**, não só com a média geral:
```python
df["mes"] = df["data"].dt.month
media_por_mes = df.groupby("mes")["valor"].mean()
```
Se o valor "estranho" está dentro do range normal para aquele mês especificamente, não é anomalia.

## Passo 5 — Anomalia real vs. erro de dado (critério prático)
Antes de reportar um outlier como "anomalia de negócio", descarte as causas mais comuns de erro de dado:
- Duplicação (a mesma venda lançada duas vezes) → confira se existe uma linha quase idêntica.
- Erro de dígito (R$ 100.000 digitado em vez de R$ 1.000, um zero a mais) → confira se o valor é ~10x/100x um valor
  típico.
- Unidade errada (valor em centavos misturado com valor em reais na mesma coluna).
Só depois de descartar essas causas é razoável reportar como "anomalia de negócio real" ao usuário.

## Regras
- Nunca remova outliers silenciosamente antes de mostrar ao usuário — a "anomalia" pode ser exatamente o que ele
  está procurando (fraude, erro de sistema, evento real).
- Sempre reporte quantos registros foram sinalizados como outlier e por qual método, não só a lista — para o
  usuário calibrar se o critério (1.5 IQR, z>3) está razoável para o caso dele.
- Para série temporal, sempre olhe o gráfico (linha do tempo) antes de confiar só no número — um outlier em
  estatística pura pode ser óbvio visualmente como um evento pontual conhecido (feriado, promoção, pane).

## Arquivos desta skill
Nenhum script fixo — os trechos acima cobrem o fluxo completo; adapte à coluna/série real do usuário.

---
name: certificados-https-nginx-winacme
description: Configura reverse proxy com Nginx e emite/renova certificados HTTPS gratuitos (Let's Encrypt) com win-acme, ambos portáteis já empacotados nesta skill — não precisa instalar nada. Use quando o usuário pedir para "colocar HTTPS nesse site/API interna", "configurar um reverse proxy", "renovar certificado Let's Encrypt", "redirecionar HTTP para HTTPS". Para servir via IIS em vez de Nginx (recurso do Windows, não empacotável), veja a nota no final.
argument-hint: [domínio/serviço a proteger] [porta interna da aplicação]
---

# Certificados digitais e HTTPS (Nginx + win-acme embutidos)

## Sobre os binários embutidos
- `bin/nginx/nginx.exe` — Nginx para Windows, portátil (zip oficial nginx.org), sem instalador.
- `bin/winacme/wacs.exe` — win-acme ("WACS"), cliente Let's Encrypt para Windows, build "trimmed" (portátil).
Nenhum dos dois precisa de instalação — são executáveis que rodam direto da pasta.

## Passo 1 — Configurar o Nginx como reverse proxy
Edite `bin/nginx/conf/nginx.conf`, dentro do bloco `http { server { ... } }`:
```nginx
server {
    listen 80;
    server_name meusite.empresa.com.br;

    location / {
        proxy_pass http://127.0.0.1:8080;   # porta onde a aplicacao real esta rodando
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```
Iniciar/parar/recarregar (rodar a partir da pasta `bin/nginx/`, o Nginx espera isso):
```
bin\nginx\nginx.exe
bin\nginx\nginx.exe -s reload
bin\nginx\nginx.exe -s stop
```

## Passo 2 — Emitir certificado com win-acme (precisa da porta 80 acessível publicamente para validação HTTP-01)
```
bin\winacme\wacs.exe --target manual --host meusite.empresa.com.br --validation selfhosting --store pemfiles --pemfilespath "C:\certs\meusite"
```
`--validation selfhosting` faz o próprio `wacs.exe` responder temporariamente ao desafio HTTP-01 do Let's Encrypt
na porta 80 — se o Nginx já estiver ocupando a porta 80, pare-o (`nginx -s stop`) antes de rodar o `wacs.exe`, ou
use `--validationport` para outra porta com um redirecionamento configurado.

## Passo 3 — Configurar Nginx para usar o certificado emitido
```nginx
server {
    listen 443 ssl;
    server_name meusite.empresa.com.br;
    ssl_certificate     C:/certs/meusite/meusite.empresa.com.br-chain.pem;
    ssl_certificate_key C:/certs/meusite/meusite.empresa.com.br-key.pem;
    location / { proxy_pass http://127.0.0.1:8080; }
}
server {
    listen 80;
    server_name meusite.empresa.com.br;
    return 301 https://$host$request_uri;   # redireciona HTTP -> HTTPS
}
```

## Passo 4 — Renovação automática (certificado Let's Encrypt expira em 90 dias)
```
bin\winacme\wacs.exe --renew --baseuri "https://acme-v02.api.letsencrypt.org/"
```
Agende essa chamada (ver skill `servicos-tarefas-agendadas-windows`) para rodar diariamente — win-acme só renova
de fato os certificados perto do vencimento, então rodar todo dia é seguro e é o padrão recomendado pela própria
ferramenta. Adicione um passo pós-renovação para recarregar o Nginx (`nginx -s reload`) automaticamente.

## Compressão e logs de acesso (Nginx)
```nginx
gzip on;
gzip_types text/plain text/css application/json application/javascript;
access_log logs/access.log;
error_log logs/error.log;
```

## Alternativa: IIS em vez de Nginx
Se a máquina já é um Windows Server com o recurso **IIS habilitado** (recurso do Windows, não um programa para
baixar — habilita via `Install-WindowsFeature Web-Server` ou Painel de Recursos), pode ser preferível usar IIS
como reverse proxy (módulo ARR) em vez do Nginx empacotado aqui, especialmente se o time já administra IIS.
Confirme com o usuário qual caminho ele prefere antes de escolher — esta skill cobre o caminho Nginx/win-acme
(totalmente portátil); o caminho IIS depende de habilitar o recurso do Windows separadamente.

## Regras
- Porta 80 precisa estar acessível pela internet (não só rede local) para a validação HTTP-01 do Let's Encrypt
  funcionar — confirme isso com o usuário antes de tentar emitir o certificado.
- Nunca exponha a aplicação real diretamente na porta 80/443 sem o proxy — sempre rode a aplicação numa porta
  interna e deixe o Nginx como única porta de entrada pública.
- Renovação: sempre agende automaticamente (passo 4) — certificado vencido derruba o HTTPS do site inteiro sem
  aviso prévio óbvio para quem administra.

## Arquivos desta skill
- `bin/nginx/` — Nginx para Windows portátil (nginx.org, oficial).
- `bin/winacme/` — win-acme build "trimmed" portátil (cliente Let's Encrypt).

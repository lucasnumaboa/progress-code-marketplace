---
name: oracle-basico-integracoes
description: Conecta e consulta Oracle via sqlplus/tnsnames, com tipos de dados, sequências e PL/SQL mínimo para consultas e cargas. Requer o Oracle Instant Client, que a Oracle não permite baixar por comando direto (exige login e aceite de licença no site) — a skill guia exatamente qual arquivo pegar, mas esse passo específico precisa ser feito manualmente pelo usuário no navegador. Use quando o usuário pedir para "conectar nesse banco Oracle", "consultar/carregar dados no Oracle", "configurar o tnsnames.ora".
argument-hint: [banco Oracle] [operação]
---

# Oracle básico para integrações

## Passo 0 — Instant Client: o único passo que não dá para automatizar sozinho
```
python -c "import oracledb"
```
Se der erro, o pacote Python (`pip install oracledb`) resolve a maior parte sozinho — desde a versão "thin mode",
`python-oracledb` **não precisa mais do Instant Client instalado** para a maioria das operações (SQL simples,
DML). Só é necessário instalar o Instant Client separadamente para recursos avançados específicos (ex.: Advanced
Queuing, alguns tipos de dado legados) — **tente primeiro sem o Instant Client**, é bem provável que já funcione:
```
pip install oracledb
```
```python
import oracledb
conexao = oracledb.connect(user="usuario", password="senha", dsn="servidor:1521/nomedoservico")
```
Se especificamente precisar do modo "thick" (recursos avançados), **aí sim** é preciso o Instant Client: baixe em
`https://www.oracle.com/database/technologies/instant-client/downloads.html` — a Oracle exige criar conta gratuita
e aceitar a licença OTN clicando no site, não existe link de download direto sem esse passo manual. Avise o
usuário exatamente qual arquivo pegar (ex.: "Basic Package" para Windows x64, versão compatível com o banco de
destino) e peça para ele baixar e informar o caminho onde extraiu — não tente contornar esse aceite de licença.

## Passo 1 — tnsnames.ora (se for usar esse padrão de conexão em vez de EZCONNECT)
```
# tnsnames.ora
MEUBANCO =
  (DESCRIPTION =
    (ADDRESS = (PROTOCOL = TCP)(HOST = servidor)(PORT = 1521))
    (CONNECT_DATA = (SERVICE_NAME = nomedoservico))
  )
```
Mais simples: use EZCONNECT direto na string de conexão (não precisa de arquivo `tnsnames.ora` separado):
```python
conexao = oracledb.connect(user="usuario", password="senha", dsn="servidor:1521/nomedoservico")
```

## Passo 2 — Tipos de dados que confundem (Oracle vs. outros bancos)
- `VARCHAR2` (não `VARCHAR` puro — Oracle trata como reservado para uso futuro, sempre use `VARCHAR2`).
- `NUMBER` sem precisão definida aceita inteiro ou decimal — `NUMBER(10,2)` para valor monetário, evite `NUMBER`
  puro quando a intenção é sempre um tipo específico.
- `DATE` do Oracle **sempre inclui hora** (diferente de outros bancos onde `DATE` é só a data) — se precisar só da
  data, trunque explicitamente (`TRUNC(coluna_data)`) nas comparações.
- Sem tipo `BOOLEAN` nativo em tabela (só em PL/SQL) — convenção comum é `NUMBER(1)` com `CHECK (coluna IN (0,1))`.

## Passo 3 — Sequências (Oracle não tem auto-incremento nativo como outros bancos até certa versão)
```sql
CREATE SEQUENCE seq_pedido START WITH 1 INCREMENT BY 1;
INSERT INTO pedido (id, cliente_id) VALUES (seq_pedido.NEXTVAL, :cliente_id);
```
Oracle 12c+ suporta `GENERATED AS IDENTITY` (mais parecido com auto-incremento de outros bancos) como alternativa
mais moderna à sequência manual — confirme a versão do Oracle de destino antes de escolher qual usar.

## Passo 4 — PL/SQL mínimo para consulta/carga
```sql
DECLARE
  v_total NUMBER;
BEGIN
  SELECT COUNT(*) INTO v_total FROM pedido WHERE status = 'PENDENTE';
  DBMS_OUTPUT.PUT_LINE('Total pendente: ' || v_total);
END;
/
```
```python
cursor = conexao.cursor()
cursor.execute("SELECT id, cliente_id FROM pedido WHERE status = :status", status="PENDENTE")
for linha in cursor:
    print(linha)
```
Sempre use parâmetros nomeados (`:status`) em vez de concatenar string na query — mesma regra de qualquer banco
(proteção contra SQL injection).

## Regras
- Nunca prometa "baixar o Instant Client automaticamente" — a Oracle exige aceite manual de licença; a skill guia
  o arquivo certo, mas o download em si é do usuário.
- Sempre tente primeiro o modo "thin" do `python-oracledb` (sem Instant Client) antes de assumir que ele é
  necessário — cobre a maioria dos casos de uso comuns hoje em dia.
- `DATE` do Oracle incluir hora é a causa mais comum de "consulta não bate" ao migrar de/para outro banco — ver
  skill `migrar-dados-entre-bancos` para o mapeamento de tipos mais amplo.

## Arquivos desta skill
Nenhum script fixo — os trechos acima cobrem os casos mais comuns; adapte ao banco/versão reais do usuário.

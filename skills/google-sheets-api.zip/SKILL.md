---
name: google-sheets-api
description: Lê e escreve em planilhas Google Sheets via API oficial (google-api-python-client), com autenticação por conta de serviço, incluindo escrita de fórmulas e controle de quota. Use quando o usuário pedir para "ler/escrever numa planilha do Google", "automatizar o Google Sheets", "conectar no Google Sheets por API" — não confundir com arquivos .xlsx locais (skill `ler-escrever-xlsx`).
argument-hint: [ID da planilha] [operação: ler|escrever]
---

# Google Sheets via API (conta de serviço)

## Passo 1 — Credenciais (conta de serviço)
Isso não é feito por esta skill sozinha — precisa de um projeto no Google Cloud Console com a API "Google Sheets
API" ativada e uma conta de serviço com uma chave JSON baixada. **Peça ao usuário** o caminho do arquivo JSON de
credenciais (nunca peça para colar o conteúdo da chave na conversa). Depois:
1. Abra a planilha de destino no navegador → Compartilhar → adicione o e-mail da conta de serviço (algo como
   `nome@projeto.iam.gserviceaccount.com`, está dentro do JSON em `client_email`) como Editor.
2. Sem esse compartilhamento, toda chamada à API falha com `403 PERMISSION_DENIED`, mesmo com a chave certa.

## Passo 2 — Instalar e autenticar
```
pip install google-api-python-client google-auth
```
```python
from google.oauth2 import service_account
from googleapiclient.discovery import build

SCOPES = ["https://www.googleapis.com/auth/spreadsheets"]
creds = service_account.Credentials.from_service_account_file("credenciais.json", scopes=SCOPES)
service = build("sheets", "v4", credentials=creds)
```

## Passo 3 — Ler um intervalo
```python
resultado = service.spreadsheets().values().get(
    spreadsheetId=SPREADSHEET_ID, range="Plan1!A1:D100"
).execute()
linhas = resultado.get("values", [])  # lista de listas; linhas mais curtas que o cabecalho SAO possiveis (celulas vazias no fim nao vem)
```
Trate `linhas` com cuidado: uma linha com células vazias no final vem **mais curta** que o cabeçalho — não assuma
`len(linha) == len(cabecalho)`.

## Passo 4 — Escrever valores ou fórmulas
```python
service.spreadsheets().values().update(
    spreadsheetId=SPREADSHEET_ID,
    range="Plan1!D2",
    valueInputOption="USER_ENTERED",  # obrigatorio para o Sheets INTERPRETAR formula/data, nao so gravar texto cru
    body={"values": [["=SOMA(A2:C2)"]]},
).execute()
```
`valueInputOption`:
- `RAW`: grava exatamente o texto/número como veio, sem interpretar (uma fórmula digitada vira texto literal).
- `USER_ENTERED`: interpreta como se o usuário tivesse digitado na célula — necessário para fórmulas, datas e
  números formatados funcionarem de verdade.

Para escrever muitas células de uma vez, use `batchUpdate`/`values().batchUpdate()` em vez de uma chamada por
célula — cada chamada individual conta separadamente na cota.

## Passo 5 — Cota e retries
A API tem limite de requisições por minuto por projeto/usuário. Em `HttpError` com status 429, faça retry com
backoff exponencial (`time.sleep(2 ** tentativa)`, no máximo ~5 tentativas) antes de desistir e avisar o usuário.

## Regras
- Nunca grave o conteúdo do arquivo de credenciais em nenhum lugar do repositório do usuário nem na conversa —
  trate como segredo.
- Confirme o `spreadsheetId` certo com o usuário (é o trecho da URL entre `/d/` e `/edit`) antes de escrever —
  escrever na planilha errada é difícil de reverter sem o histórico de versões do Google Sheets.
- Para leitura simples sem necessidade de conta de serviço, se a planilha for pública, considere exportar como CSV
  via URL (`.../export?format=csv`) como alternativa mais simples — só quando não há necessidade de escrita.

## Arquivos desta skill
Nenhum script fixo — os trechos acima cobrem o padrão de uso; adapte ao intervalo/planilha real do usuário.

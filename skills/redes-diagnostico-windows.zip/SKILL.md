---
name: redes-diagnostico-windows
description: Diagnostica problemas de rede no Windows por camada — ping, tracert, nslookup, Test-NetConnection, netstat — para separar problema de DNS, roteamento, porta bloqueada ou proxy/VPN. Use quando o usuário pedir para "essa conexão não funciona, o que pode ser", "testar se essa porta está aberta", "por que não resolve esse DNS".
argument-hint: [host/porta/serviço com problema]
---

# Redes: diagnóstico por camada

## Ordem de diagnóstico (de baixo para cima na pilha)
Sempre teste nessa ordem — cada camada só faz sentido testar se a anterior já funcionou:

**1. Conectividade básica (ping)**
```powershell
Test-Connection -ComputerName exemplo.com -Count 4
```
Falha aqui: pode ser rede física/Wi-Fi, ou o destino simplesmente bloqueia ICMP (muito comum em servidores/firewalls
— **ping falhar não prova que o serviço está fora do ar**, só que ICMP está bloqueado ou há problema de rede real).

**2. Resolução de nome (DNS)**
```powershell
Resolve-DnsName exemplo.com
nslookup exemplo.com
nslookup exemplo.com 8.8.8.8   # forcar um DNS especifico - se resolver aqui mas nao no DNS padrao, o problema e o servidor DNS configurado, nao o dominio
```

**3. Porta específica aberta (o teste mais útil na prática)**
```powershell
Test-NetConnection -ComputerName exemplo.com -Port 443
```
`TcpTestSucceeded : True/False` diz se a porta está acessível dali — este é geralmente o teste mais direto para
"o sistema X não conecta no serviço Y", mais útil que ping puro.

**4. Rota até o destino (onde para no meio do caminho)**
```powershell
Test-NetConnection -ComputerName exemplo.com -TraceRoute
tracert exemplo.com
```
Útil quando a porta 3 falha e é preciso saber em qual salto (roteador/firewall) a conexão para.

**5. Conexões e portas locais**
```powershell
Get-NetTCPConnection -State Listen        # o que esta escutando localmente
netstat -ano | findstr :8080              # quem esta usando a porta 8080 localmente (o numero no final e o PID)
Get-Process -Id <PID>
```
Útil para "essa porta já está em uso" ou "o serviço deveria estar escutando mas não aparece aqui".

## Proxy e VPN (causa comum de "funciona em casa, não funciona na empresa")
```powershell
netsh winhttp show proxy
[System.Net.WebRequest]::DefaultWebProxy
```
Muitas aplicações usam configuração de proxy diferente (`WinHTTP` vs. configuração do navegador vs. variável de
ambiente `HTTP_PROXY`) — confira qual a aplicação específica está realmente usando, não assuma que é a mesma do
navegador.

## Interpretando os resultados (o que cada camada indica)
| Sintoma | Camada provável |
|---|---|
| Ping falha, tudo falha | Rede física/Wi-Fi, ou ICMP bloqueado (não conclusivo sozinho) |
| Ping ok, DNS falha | Servidor DNS configurado errado, ou domínio não existe |
| DNS ok, porta falha | Firewall bloqueando, serviço não está rodando no destino, ou porta errada |
| Porta ok, aplicação ainda falha | Problema de autenticação/certificado/aplicação, não de rede |

## Regras
- Nunca conclua "está tudo bem" só porque ping funcionou — a maioria dos problemas reais de aplicação está em
  camadas acima do ping (porta, TLS, autenticação).
- Sempre teste da própria máquina que tem o problema, não de outra — configuração de rede pode ser específica por
  máquina (proxy, VPN, firewall local).
- Ao reportar o diagnóstico ao usuário, diga exatamente em qual camada parou e o comando usado — não só "não
  funciona"/"funciona agora", para ele poder reproduzir o teste depois.

## Arquivos desta skill
Nenhum script fixo — os comandos acima cobrem o fluxo completo de diagnóstico; adapte ao host/porta reais.

---
name: python-ambientes-empacotamento
description: Gerencia ambientes virtuais Python (venv, uv), dependências (requirements.txt, pyproject.toml) e gera .exe standalone com PyInstaller para rodar sem Python instalado no destino. Use quando o usuário pedir para "criar um ambiente virtual", "esse pip install está poluindo o Python do sistema", "gerar um .exe desse script Python", "organizar as dependências do projeto".
argument-hint: [operação: criar ambiente|empacotar|dependências]
---

# Python: ambientes e empacotamento

## Por que sempre usar ambiente virtual
Instalar pacotes no Python "do sistema" (`pip install` sem ambiente ativo) polui um Python compartilhado por
outros scripts/ferramentas, e pode gerar conflito de versão entre projetos diferentes. **Sempre** crie um ambiente
por projeto antes de instalar qualquer coisa.

## venv (embutido no Python, sem instalar nada)
```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1     # ativa - o prompt passa a mostrar (.venv)
pip install pandas openpyxl
pip freeze > requirements.txt
deactivate
```
Se `Activate.ps1` falhar com erro de política de execução: `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass`
(só para a sessão atual do PowerShell, não altera política do sistema).

## uv (mais rápido, instala pacotes em paralelo — ferramenta adicional, mas leve e só um binário)
```powershell
winget install --id astral-sh.uv
uv venv
uv pip install -r requirements.txt
```
`uv` é uma reimplementação do pip focada em velocidade — só proponha se o projeto já usa (ou o usuário topar
instalar), não é estritamente necessário sobre `venv`+`pip` puro.

## requirements.txt vs. pyproject.toml
- `requirements.txt`: simples, uma lista de pacotes — bom para scripts e projetos pequenos.
- `pyproject.toml`: padrão moderno para bibliotecas/pacotes distribuíveis, com metadados (nome, versão, dependências,
  scripts de entrada). Use quando o projeto vai ser instalado como pacote (`pip install .`) ou publicado.
```toml
[project]
name = "meu-pacote"
version = "0.1.0"
dependencies = ["pandas>=2.0", "openpyxl"]

[project.scripts]
meu-comando = "meu_pacote.cli:main"
```

## Gerar .exe standalone (PyInstaller — não precisa de Python instalado no destino)
```powershell
pip install pyinstaller
pyinstaller --onefile --name meu-programa script.py
```
O `.exe` gerado (`dist\meu-programa.exe`) inclui o interpretador Python embutido — mas fica grande (dezenas de MB) e
**não** funciona em outro sistema operacional (gere no Windows para rodar no Windows). Bibliotecas com dependências
nativas (ex.: algumas de visão computacional) às vezes precisam de `--hidden-import` explícito porque o PyInstaller
não detecta a dependência automaticamente — teste o `.exe` gerado antes de considerar pronto, não assuma que
funciona só porque a geração não deu erro.

## Regras
- Nunca instale pacote de projeto no Python global — sempre dentro de um ambiente virtual ativado.
- `requirements.txt` gerado com `pip freeze` inclui a árvore inteira de dependências transitivas fixadas — bom para
  reprodutibilidade exata, mas dificulta atualizar uma lib específica depois; para bibliotecas, prefira declarar só
  as dependências diretas em `pyproject.toml` com faixa de versão.
- Ao empacotar com PyInstaller, sempre teste o `.exe` numa máquina limpa (ou pelo menos numa pasta fora do ambiente
  de desenvolvimento) antes de entregar — é comum funcionar "sempre" na máquina de dev por causa de algo que só
  está lá (DLL, variável de ambiente) e não seria empacotado.

## Arquivos desta skill
Nenhum script fixo — os comandos acima cobrem os casos mais comuns; adapte ao projeto real do usuário.

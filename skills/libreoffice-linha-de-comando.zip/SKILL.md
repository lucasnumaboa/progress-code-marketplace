---
name: libreoffice-linha-de-comando
description: Converte entre formatos de documento (doc→pdf, xls→csv, pptx→pdf) e roda macros em lote via LibreOffice em modo headless, sem precisar do Office instalado — instala o LibreOffice sozinho (via winget) se ainda não estiver presente. Use quando o usuário pedir para "converter esse documento sem o Word/Excel instalado", "converter vários arquivos de formato em lote", "isso precisa rodar num servidor sem Office".
argument-hint: [arquivo(s) de origem] [formato de destino]
---

# LibreOffice em linha de comando

## Passo 0 — Verificar/instalar
```
soffice --version
```
Se não existir:
```
winget install TheDocumentFoundation.LibreOffice
```
Instalador ~350-400MB — avise o usuário antes de iniciar que isso vai baixar/instalar um pacote grande (LibreOffice
completo; não existe uma versão "só o motor de conversão" separada instalável via winget). Depois de instalar,
abra um terminal novo antes de confirmar com `soffice --version` de novo (PATH só atualiza em processo novo).

## Passo 1 — Converter um arquivo
```
soffice --headless --convert-to pdf --outdir "C:\saida" "C:\entrada\documento.docx"
soffice --headless --convert-to csv --outdir "C:\saida" "C:\entrada\planilha.xlsx"
soffice --headless --convert-to pdf --outdir "C:\saida" "C:\entrada\apresentacao.pptx"
```
`--headless` roda sem interface gráfica. O nome do arquivo de saída é o mesmo da entrada, só troca a extensão —
não é possível renomear no mesmo comando (renomeie depois com `Rename-Item` se precisar de nome diferente).

## Passo 2 — Converter em lote (vários arquivos de uma vez)
```powershell
Get-ChildItem "C:\entrada\*.docx" | ForEach-Object {
    & soffice --headless --convert-to pdf --outdir "C:\saida" $_.FullName
}
```
**Atenção**: rodar várias instâncias do `soffice` em paralelo (vários processos ao mesmo tempo) costuma falhar por
disputa do "perfil de usuário" do LibreOffice — converta um arquivo de cada vez em sequência, como no exemplo
acima, não dispare todos em paralelo.

## Passo 3 — Opções de exportação específicas (ex.: CSV com separador customizado)
```
soffice --headless --convert-to "csv:Text - txt - csv (StarCalc):59,34,0,1,,0,false,true,false,false,false" --outdir "C:\saida" planilha.xlsx
```
O filtro de exportação do LibreOffice usa uma sintaxe própria bem específica por formato — para o caso mais comum
(CSV separado por vírgula, UTF-8), o comando simples do Passo 1 já basta; só use essa sintaxe estendida se precisar
de separador/encoding não-padrão.

## Passo 4 — Rodar uma macro (Basic) em lote
```
soffice --headless --invisible "vnd.sun.star.script:Standard.Modulo1.MinhaMacro?language=Basic&location=application" documento.odt
```
Escrever/depurar a macro em si é mais fácil interativamente no LibreOffice (Ferramentas → Macros → Editar) antes de
rodar via linha de comando — teste a macro manualmente primeiro, só depois automatize a chamada.

## Regras
- Sempre confira o arquivo de saída depois da conversão (abrir/checar tamanho > 0) — conversões headless às vezes
  falham silenciosamente (retornam código de saída 0 mas não geram o arquivo) se o processo de fundo já estava
  ocupado com outro documento.
- Nunca rode conversões em paralelo (múltiplos `soffice` simultâneos) — sequencial é mais lento mas confiável.
- Formatação complexa (estilos avançados do Word/Excel) pode não converter perfeitamente — avise o usuário para
  conferir visualmente o resultado em documentos com formatação rica, não assuma fidelidade 100%.

## Arquivos desta skill
Nenhum script fixo — os comandos acima cobrem os casos mais comuns; adapte ao formato/lote real do usuário.

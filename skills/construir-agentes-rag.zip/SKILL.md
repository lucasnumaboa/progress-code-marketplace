---
name: construir-agentes-rag
description: Monta um pipeline RAG (chunking, embeddings, banco vetorial embutido, recuperação) e avalia se RAG é de fato a resposta certa para o problema, usando bibliotecas Python puras (Chroma/sqlite-vec, sem servidor separado). Use quando o usuário pedir para "buscar em documentos com IA", "montar um RAG para essa base de conhecimento", "por que a busca semântica não acha o trecho certo", "isso precisa de RAG ou é caso mais simples".
argument-hint: [conjunto de documentos] [o que precisa ser respondido a partir deles]
---

# Construir agentes e RAG

## Quando RAG não é a resposta (verificar antes de montar o pipeline)
- **Poucos documentos que cabem no contexto do modelo**: cole o conteúdo direto no prompt em vez de montar um
  pipeline de recuperação — mais simples, sem perda de recall por busca imperfeita.
- **Pergunta precisa de cálculo/agregação sobre dados estruturados** (soma, contagem, filtro exato): isso é uma
  consulta SQL/pandas (ver skills `analisar-dados-pandas`/`sqlite-local`), não busca semântica — RAG "adivinha"
  por similaridade, não agrega com exatidão.
- **A resposta depende de informação que muda o tempo todo** (preço atual, status de pedido): busque a informação
  em tempo real na fonte (API/banco), RAG sobre um índice desatualizado dá resposta errada com confiança.
RAG vale a pena quando: o volume de documentos não cabe no contexto, o conteúdo é relativamente estável, e a
pergunta é do tipo "o que esse conjunto de documentos diz sobre X" (busca por relevância semântica).

## Chunking (dividir documentos antes de indexar)
```python
def dividir_em_chunks(texto, tamanho=500, sobreposicao=50):
    palavras = texto.split()
    chunks = []
    inicio = 0
    while inicio < len(palavras):
        chunks.append(" ".join(palavras[inicio:inicio + tamanho]))
        inicio += tamanho - sobreposicao
    return chunks
```
`sobreposicao` (overlap) evita que uma informação relevante fique cortada exatamente na fronteira entre dois
chunks e se torne irrecuperável em ambos. Prefira dividir por **estrutura natural do documento** (parágrafo, seção,
cabeçalho) quando possível, em vez de contagem cega de palavras — um chunk que corta uma frase ou uma tabela no
meio perde qualidade de recuperação.

## Embeddings e banco vetorial embutido (sem servidor separado)
```
pip install chromadb
```
```python
import chromadb

cliente = chromadb.PersistentClient(path="./banco_vetorial")  # arquivo local, sem servidor
colecao = cliente.get_or_create_collection("documentos")

colecao.add(
    documents=chunks,
    ids=[f"chunk-{i}" for i in range(len(chunks))],
    metadatas=[{"fonte": nome_arquivo, "posicao": i} for i in range(len(chunks))],
)
```
Chroma calcula o embedding automaticamente com um modelo padrão embutido — para melhor qualidade em domínio
específico (jurídico, técnico), considere passar uma função de embedding de um provedor de IA (ver skill
`chamar-apis-de-ia`) em vez do modelo padrão genérico.

## Recuperação (retrieval)
```python
resultados = colecao.query(query_texts=["pergunta do usuário aqui"], n_results=5)
trechos_relevantes = resultados["documents"][0]
```
`n_results` alto demais dilui a relevância (o modelo recebe muito ruído); baixo demais pode perder o trecho certo.
Comece com `5`, ajuste observando casos reais de falha.

## Montar o prompt final com os trechos recuperados
```
Responda a pergunta usando SOMENTE as informações nos trechos abaixo. Se a resposta não estiver nos trechos,
diga que não encontrou a informação nos documentos.

Trechos:
{trechos_relevantes concatenados, cada um identificando a fonte}

Pergunta: {pergunta do usuário}
```
Sempre inclua a instrução explícita de "não invente se não estiver nos trechos" (ver skill
`escrever-bons-prompts`, seção de redução de alucinação) — sem isso, o modelo tende a misturar conhecimento
próprio com o conteúdo recuperado sem deixar claro qual é qual.

## Avaliação (o pipeline está recuperando o trecho certo?)
Monte um conjunto pequeno de perguntas com a resposta/trecho esperado já conhecido, e meça se a recuperação
(antes mesmo de gerar a resposta final) traz o trecho certo entre os top-N resultados. Se a recuperação já falha
nesse teste, o problema é chunking/embedding, não o prompt final — ajustar o prompt não resolve recuperação ruim.

## Regras
- Nunca monte um pipeline RAG completo sem antes confirmar que o problema realmente precisa dele (ver seção
  inicial) — é mais trabalho e mais uma fonte de erro (recuperação imprecisa) que uma solução mais direta quando
  aplicável.
- Sempre inclua a fonte/identificação do trecho recuperado na resposta final — permite ao usuário verificar e
  aumenta a confiabilidade percebida (e real) da resposta.
- Reavalie a qualidade do chunking quando o pipeline "erra" seguidamente numa mesma categoria de pergunta — quase
  sempre é o tamanho/corte do chunk, não o modelo de geração.

## Arquivos desta skill
Nenhum script fixo — os trechos acima cobrem o pipeline completo; adapte ao conjunto de documentos real do usuário.

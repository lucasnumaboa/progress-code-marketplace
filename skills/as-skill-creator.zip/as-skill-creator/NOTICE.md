# Origem

Skill de especialista empacotada para o marketplace do Progress Code (id `as-skill-creator`).

- Repositório: https://github.com/anthropics/skills
- Caminho: `skills/skill-creator`
- Autor: Anthropic
- Copyright no arquivo de licença: "Copyright 2026 Anthropic, PBC."
- Licença: Apache-2.0 (texto completo em `LICENSE`, copiado de `skills/skill-creator/LICENSE.txt` no repositório)
- Commit: `e4bb5d960d87126ff3b3a8af1a104b7db67560ba` (baixado em 2026-11-22)

## Arquivos incluídos

- `SKILL.md` (de `skills/skill-creator/SKILL.md`)
- `agents/analyzer.md` (de `skills/skill-creator/agents/analyzer.md`)
- `agents/comparator.md` (de `skills/skill-creator/agents/comparator.md`)
- `agents/grader.md` (de `skills/skill-creator/agents/grader.md`)
- `references/schemas.md` (de `skills/skill-creator/references/schemas.md`)
- `scripts/__init__.py` (de `skills/skill-creator/scripts/__init__.py`)
- `scripts/aggregate_benchmark.py` (de `skills/skill-creator/scripts/aggregate_benchmark.py`)
- `scripts/generate_report.py` (de `skills/skill-creator/scripts/generate_report.py`)
- `scripts/package_skill.py` (de `skills/skill-creator/scripts/package_skill.py`)
- `scripts/quick_validate.py` (de `skills/skill-creator/scripts/quick_validate.py`)
- `scripts/utils.py` (de `skills/skill-creator/scripts/utils.py`)
- `eval-viewer/generate_review.py` (de `skills/skill-creator/eval-viewer/generate_review.py`)
- `eval-viewer/viewer.html` (de `skills/skill-creator/eval-viewer/viewer.html`)
- `assets/eval_review.html` (de `skills/skill-creator/assets/eval_review.html`)

## Mudanças feitas

1. Frontmatter: `name:` trocado de `skill-creator` para `as-skill-creator` (a descrição foi mantida).
2. A seção "Cowork-Specific Instructions" foi removida (regras de execução de outro produto).
3. Não incluídos: `scripts/run_eval.py`, `scripts/run_loop.py` e `scripts/improve_description.py`. Eles chamam o `claude -p` (CLI paga do Claude Code). Sem eles, a etapa "Description Optimization" do SKILL.md não roda; faça a revisão da descrição à mão, como a seção "Claude.ai-specific instructions" orienta.

O texto do especialista foi mantido em inglês, sem tradução.
Conforme a Apache-2.0 (seção 4b), este aviso registra que os arquivos acima foram modificados.

# Aviso de terceiros (NOTICE)

Esta skill é uma cópia adaptada de material de terceiros e é redistribuída sob a licença original. O texto do especialista ficou em inglês, como no original.

- **Origem:** https://github.com/swan-gtm/gtm-skills
- **Caminho no repositório:** `skills/manny-medina/roi-proof-generator`
- **Commit:** `eb0026f469f90645e1a64168d08a3e0afb59ee12` (baixado em 2026-11-22)
- **Autor:** Manny Medina (autor da skill); copyright do repositório: Swan
- **Licença:** MIT (texto completo em `LICENSE`, copiado de `LICENSE` do repositório)

## Arquivos incluídos

- `SKILL.md` (de `skills/manny-medina/roi-proof-generator/SKILL.md`)
- `author.md` (de `skills/manny-medina/author.md`, crédito do autor pedido pelo repositório)
- `LICENSE`

## Mudanças feitas

- Frontmatter: `name: roi-proof-generator` trocado por `name: swan-roi-proof-generator` (a descrição ficou igual).

## Crédito do autor (author.md)

O repositório pede que o crédito do autor acompanhe a skill. Conteúdo do `author.md` original:

```markdown
---
name: Manny Medina
avatarUrl: "https://www.gtmskills.com/authors/manny-medina.jpg"
title: "Founder & CEO"
linkedinUrl: "https://linkedin.com/in/medinism"
companyDomain: paid.ai
---

Founder and CEO of Paid.ai, the monetization platform for AI agents. Previously founded Outreach and built it into the category-defining sales engagement platform.
```

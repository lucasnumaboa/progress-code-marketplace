---
name: doctome
description: DocToMe — gera a documentação completa de uma alteração de código (PDF técnico, Markdown e apresentação PPTX) comparando os ORIGINAIS guardados pelo Progress Code com o projeto atual, explicando o que foi feito e por quê. Use quando o usuário pedir "cria uma documentação", "documenta o que foi feito", "gera a documentação da alteração", "faz o documento técnico" ou "preciso documentar essa mudança".
---

# DocToMe — documentação da alteração

Tudo que você precisa está nesta pasta. **Não escreva código**: use os comandos prontos abaixo pela ferramenta Bash
(PowerShell). O `doctome.cmd` está no PATH.

| arquivo | para quê |
|---|---|
| `doctome.cmd` | o único comando que você chama |
| `doctome.py` | faz o diff dos originais e gera PDF, MD e PPTX (o `.cmd` chama ele) |
| `modelo-doc.json` | modelo do conteúdo que VOCÊ preenche (é o único trabalho de redação) |

## Passo a passo

### 1. Ache a pasta dos originais

O Progress Code guarda o original de cada arquivo antes da primeira alteração na conversa. O caminho está no seu
contexto, na seção **"Originais da conversa"** (algo como `C:\Users\...\AppData\Roaming\Progress Code\baselines\<id>`).
Você também pode chamar a ferramenta `CompararOriginal` sem argumento: a primeira linha diz onde estão.

Se esta conversa não alterou nada (a pasta não existe ou está vazia), liste os originais das outras conversas deste
projeto e escolha com o usuário:

```powershell
doctome.cmd listar "<pasta do projeto>"
```

### 2. Colete o diff (determinístico — não resuma de cabeça)

```powershell
doctome.cmd coletar "<pasta dos originais>" "<pasta do projeto>" "$env:TEMP\doctome-coleta.json"
```

A saída lista cada arquivo com `+`/`−` linhas. Leia o JSON (`Read` em `$env:TEMP\doctome-coleta.json`) para ver
os diffs completos antes de escrever. Se `arquivos` vier vazio, diga ao usuário que não há diferença em relação
aos originais e pare.

### 3. Escreva o conteúdo (`doc.json`)

Leia `modelo-doc.json` desta pasta e grave um `doc.json` no mesmo formato em `$env:TEMP\doctome-doc.json`
(ferramenta `Write`). Regras:

- **`contexto` e `motivo` são o "porquê"**: tire dos pedidos do usuário nesta conversa e do que foi investigado
  (causa encontrada, decisão tomada). Se não souber o motivo de uma mudança, escreva "motivo não registrado na
  conversa" — **nunca invente**.
- Uma entrada em `alteracoes` para **cada** arquivo da coleta. `detalhes` descreve o que mudou em linguagem de
  programador; `trechos` mostra 1 a 3 trechos antes/depois copiados **do diff** (não reescreva código).
- `resumo` e `testes` em linguagem de usuário (tela → campo → ação → resultado).
- `impacto`: se a ferramenta `Impacto` existir, use-a em cada arquivo (quem chama, tabelas gravadas, irmãos). Irmão
  parecido que não foi alterado vai em `pendencias`.
- Preencha `cliente`, `projeto`, `autor`, `data` (hoje), `chamado` se aparecerem na conversa; senão, deixe vazio.
- JSON válido: aspas duplas, `\n` para quebra de linha dentro de strings.

### 4. Gere os três arquivos

Pasta de saída: `<pasta do projeto>\documentacao\<AAAA-MM-DD>-<assunto-curto>` (crie o nome você mesmo).

```powershell
doctome.cmd gerar "$env:TEMP\doctome-doc.json" "$env:TEMP\doctome-coleta.json" "<pasta de saída>"
```

Saída (JSON): `gerados` com os caminhos e `avisos`. O comando gera:

- **`<nome>.pdf`** — documento técnico: resumo, porquê, tabela de arquivos, cada alteração com motivo e trechos
  antes/depois, impacto, testes, pendências e o **diff completo em anexo**;
- **`<nome>.md`** — o mesmo conteúdo em Markdown (editável, bom para wiki/Git);
- **`<nome>.pptx`** — apresentação executiva (capa, resumo, porquê, arquivos, uma página por alteração, impacto,
  testes, pendências).

### 5. Responda

Diga onde ficaram os 3 arquivos e, em 3 a 5 linhas, o que o documento cobre. Se `avisos` não vier vazio, repita o
aviso para o usuário (ex.: Python ou navegador ausente).

## Se algo falhar

- `Python 3 nao encontrado`: diga ao usuário para rodar `winget install -e --id Python.Python.3.12` e reabrir o
  Progress Code.
- PDF não gerado: o `.html` fica ao lado do `.md`; o usuário pode abrir e imprimir em PDF.
- PPTX não gerado: o script tenta instalar o `python-pptx` sozinho (`pip install --user`). Sem internet, avise.
- Erro de JSON no `gerar`: corrija o `doc.json` (vírgula, aspas) e rode de novo — não mexa no `doctome.py`.

"""
DocToMe — documentação de uma alteração a partir dos ORIGINAIS da conversa.

  python doctome.py coletar --originais <pasta dos originais> --projeto <pasta do projeto> [--saida coleta.json]
      Compara cada original guardado pelo Progress Code com o arquivo atual do projeto e grava um JSON com
      a lista de arquivos, contagem de linhas e o diff unificado de cada um. Não inventa nada: é difflib.

  python doctome.py listar --projeto <pasta do projeto>
      Lista as pastas de originais de TODAS as conversas daquele projeto (%APPDATA%/Progress Code/baselines),
      com data e arquivos — para documentar a partir de outra conversa.

  python doctome.py gerar --spec doc.json --coleta coleta.json --saida <pasta>
      Gera, na pasta de saída:
        <nome>.md    documentação completa (editável)
        <nome>.pdf   documento técnico (HTML impresso pelo Edge/Chrome em modo headless)
        <nome>.pptx  apresentação executiva (python-pptx; instala sozinho se faltar)

Os fontes de cliente costumam estar em CP850 ou CP1252: a codificação é detectada arquivo a arquivo (UTF-8, senão a que der texto em português).
"""
import argparse
import datetime as dt
import difflib
import html
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile


# ---------------------------------------------------------------- coleta

PT = set('áéíóúâêôãõçàÁÉÍÓÚÂÊÔÃÕÇÀüÜ')


def read_text(p):
    """UTF-8, senão CP850 (padrão dos fontes Progress/Datasul) ou CP1252 — a que der mais letras de português."""
    with open(p, 'rb') as f:
        raw = f.read()
    try:
        return raw.decode('utf-8')
    except UnicodeDecodeError:
        pass
    cands = []
    for enc in ('cp850', 'cp1252'):
        try:
            t = raw.decode(enc)
            cands.append((sum(1 for ch in t if ch in PT), enc == 'cp850', t))
        except UnicodeDecodeError:
            continue
    if cands:
        return max(cands)[2]
    return raw.decode('latin-1', errors='replace')


def coletar(originais, projeto):
    arquivos = []
    for root, _dirs, files in os.walk(originais):
        for name in files:
            if name == '.baseline.json':
                continue
            orig = os.path.join(root, name)
            rel = os.path.relpath(orig, originais).replace('\\', '/')
            atual = os.path.join(projeto, rel)
            a = read_text(orig).splitlines()
            b = read_text(atual).splitlines() if os.path.exists(atual) else None
            if b is not None and a == b:
                continue
            diff = list(difflib.unified_diff(a, b or [], fromfile=f'original/{rel}', tofile=f'atual/{rel}', lineterm='', n=3))
            add = sum(1 for l in diff if l.startswith('+') and not l.startswith('+++'))
            rem = sum(1 for l in diff if l.startswith('-') and not l.startswith('---'))
            arquivos.append({
                'arquivo': rel,
                'status': 'removido' if b is None else 'alterado',
                'linhas_original': len(a),
                'linhas_atual': len(b) if b is not None else 0,
                'adicionadas': add,
                'removidas': rem,
                'diff': '\n'.join(diff),
            })
    arquivos.sort(key=lambda x: x['arquivo'])
    return {'originais': originais, 'projeto': projeto, 'coletado_em': dt.datetime.now().isoformat(timespec='seconds'), 'arquivos': arquivos}


def listar(projeto):
    root = os.path.join(os.environ.get('APPDATA', ''), 'Progress Code', 'baselines')
    alvo = os.path.normcase(os.path.abspath(projeto))
    out = []
    if os.path.isdir(root):
        for sid in os.listdir(root):
            man = os.path.join(root, sid, '.baseline.json')
            try:
                with open(man, encoding='utf-8') as f:
                    m = json.load(f)
            except Exception:
                continue
            if os.path.normcase(os.path.abspath(m.get('cwd', ''))) != alvo:
                continue
            out.append({
                'originais': os.path.join(root, sid),
                'conversa': sid,
                'criado_em': dt.datetime.fromtimestamp(m.get('createdAt', 0) / 1000).strftime('%d/%m/%Y %H:%M'),
                'atualizado_em': dt.datetime.fromtimestamp(m.get('updatedAt', 0) / 1000).strftime('%d/%m/%Y %H:%M'),
                'arquivos': sorted(m.get('files', {}).keys()),
            })
    out.sort(key=lambda x: x['atualizado_em'], reverse=True)
    return out


# ---------------------------------------------------------------- utilidades

def slug(s):
    s = re.sub(r'[^\w\s-]', '', s, flags=re.UNICODE).strip().lower()
    return re.sub(r'[\s_-]+', '-', s)[:40].strip('-') or 'documentacao'


def lista(v):
    return [x for x in (v or []) if str(x).strip()]


# ---------------------------------------------------------------- Markdown

def gerar_md(spec, coleta):
    L = []
    L.append(f"# {spec.get('titulo', 'Documentação da alteração')}")
    if spec.get('subtitulo'):
        L.append(f"_{spec['subtitulo']}_")
    meta = [f"**{k}:** {spec[c]}" for k, c in (('Cliente', 'cliente'), ('Projeto', 'projeto'), ('Autor', 'autor'), ('Data', 'data'), ('Chamado', 'chamado')) if spec.get(c)]
    if meta:
        L.append('  \n'.join(meta))
    L.append('')
    L.append('## Resumo')
    L.append(spec.get('resumo', ''))
    L.append('')
    L.append('## Contexto: por que a alteração foi feita')
    L.append(spec.get('contexto', ''))
    if lista(spec.get('objetivos')):
        L.append('')
        L.append('### Objetivos')
        L += [f'- {o}' for o in lista(spec.get('objetivos'))]
    L.append('')
    L.append('## O que foi alterado')
    L.append('')
    L.append('| Arquivo | Situação | + linhas | − linhas |')
    L.append('|---|---|---:|---:|')
    for a in coleta['arquivos']:
        L.append(f"| `{a['arquivo']}` | {a['status']} | {a['adicionadas']} | {a['removidas']} |")
    for alt in spec.get('alteracoes', []):
        L.append('')
        L.append(f"### {alt.get('arquivo', '')}")
        if alt.get('resumo'):
            L.append(alt['resumo'])
        if alt.get('motivo'):
            L.append('')
            L.append(f"**Por quê:** {alt['motivo']}")
        if lista(alt.get('detalhes')):
            L.append('')
            L += [f'- {d}' for d in lista(alt.get('detalhes'))]
        for t in alt.get('trechos', []):
            L.append('')
            L.append(f"#### {t.get('titulo', 'Trecho')}")
            if t.get('explicacao'):
                L.append(t['explicacao'])
            if t.get('antes'):
                L.append('')
                L.append('Antes:')
                L.append('```')
                L.append(t['antes'])
                L.append('```')
            if t.get('depois'):
                L.append('')
                L.append('Depois:')
                L.append('```')
                L.append(t['depois'])
                L.append('```')
    imp = spec.get('impacto') or {}
    if any(lista(imp.get(k)) for k in ('programas', 'tabelas', 'riscos')):
        L.append('')
        L.append('## Impacto')
        for k, t in (('programas', 'Programas afetados'), ('tabelas', 'Tabelas gravadas/lidas'), ('riscos', 'Riscos e cuidados')):
            if lista(imp.get(k)):
                L.append('')
                L.append(f'**{t}**')
                L += [f'- {x}' for x in lista(imp.get(k))]
    if spec.get('testes'):
        L.append('')
        L.append('## Como testar')
        L.append('')
        L.append('| # | Passos | Resultado esperado |')
        L.append('|---|---|---|')
        for i, t in enumerate(spec['testes'], 1):
            L.append(f"| {i} | {str(t.get('passos', '')).replace('|', '/')} | {str(t.get('esperado', '')).replace('|', '/')} |")
    if lista(spec.get('pendencias')):
        L.append('')
        L.append('## Pendências e fora do escopo')
        L += [f'- {p}' for p in lista(spec.get('pendencias'))]
    L.append('')
    L.append('## Anexo: diff completo (original → atual)')
    for a in coleta['arquivos']:
        L.append('')
        L.append(f"### {a['arquivo']}")
        L.append('```diff')
        L.append(a['diff'])
        L.append('```')
    L.append('')
    L.append(f"_Gerado pelo DocToMe em {dt.datetime.now().strftime('%d/%m/%Y %H:%M')} a partir dos originais guardados em `{coleta['originais']}`._")
    return '\n'.join(L) + '\n'


# ---------------------------------------------------------------- PDF (HTML impresso pelo navegador)

CSS = """
@page { size: A4; margin: 18mm 16mm; }
* { box-sizing: border-box; }
body { font: 10.5pt/1.5 "Segoe UI", system-ui, sans-serif; color: #1d2330; }
h1 { font-size: 22pt; margin: 0 0 4px; color: #2b1f73; }
h2 { font-size: 14pt; margin: 22px 0 8px; padding-bottom: 4px; border-bottom: 2px solid #6d4aff; color: #2b1f73; page-break-after: avoid; }
h3 { font-size: 12pt; margin: 16px 0 6px; font-family: Consolas, monospace; page-break-after: avoid; }
h4 { font-size: 10.5pt; margin: 12px 0 4px; }
.sub { color: #5b6374; font-size: 11pt; margin-bottom: 10px; }
.meta { display: grid; grid-template-columns: repeat(3, 1fr); gap: 6px 16px; background: #f4f2ff; border-radius: 8px; padding: 10px 14px; margin: 12px 0 4px; font-size: 9.5pt; }
.meta b { display: block; color: #5b6374; font-weight: 600; font-size: 8.5pt; text-transform: uppercase; }
table { width: 100%; border-collapse: collapse; margin: 8px 0; font-size: 9.5pt; }
th, td { border: 1px solid #d9dce3; padding: 5px 7px; text-align: left; vertical-align: top; }
th { background: #f4f5f8; }
td.num { text-align: right; font-variant-numeric: tabular-nums; }
.why { background: #fff8e6; border-left: 3px solid #f59e0b; padding: 6px 10px; margin: 8px 0; }
pre { background: #f6f7f9; border: 1px solid #e3e6ec; border-radius: 6px; padding: 8px 10px; font: 8.5pt/1.4 Consolas, monospace; white-space: pre-wrap; word-break: break-word; }
pre.diff .add { color: #0b6b3a; background: #e8f6ef; display: block; }
pre.diff .del { color: #a01818; background: #fde8e8; display: block; }
pre.diff .hunk { color: #5b4ad6; display: block; }
pre.diff .ctx { display: block; }
.ba { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; }
.ba .lbl { font-size: 8.5pt; color: #5b6374; text-transform: uppercase; }
.anexo { page-break-before: always; }
.foot { color: #8a91a1; font-size: 8.5pt; margin-top: 24px; }
"""


def e(s):
    return html.escape(str(s or ''))


def diff_html(d):
    out = []
    for line in d.splitlines():
        c = 'add' if line.startswith('+') and not line.startswith('+++') else 'del' if line.startswith('-') and not line.startswith('---') else 'hunk' if line.startswith('@@') else ''
        # cada linha é um bloco próprio: juntar com \n dobraria o espaçamento
        out.append(f'<span class="{c or "ctx"}">{e(line) or "&nbsp;"}</span>')
    return '<pre class="diff">' + ''.join(out) + '</pre>'


def gerar_html(spec, coleta):
    H = [f'<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><title>{e(spec.get("titulo"))}</title><style>{CSS}</style></head><body>']
    H.append(f'<h1>{e(spec.get("titulo", "Documentação da alteração"))}</h1>')
    if spec.get('subtitulo'):
        H.append(f'<div class="sub">{e(spec["subtitulo"])}</div>')
    metas = [(k, spec.get(c)) for k, c in (('Cliente', 'cliente'), ('Projeto', 'projeto'), ('Autor', 'autor'), ('Data', 'data'), ('Chamado', 'chamado'), ('Arquivos', None)) ]
    metas[-1] = ('Arquivos alterados', str(len(coleta['arquivos'])))
    H.append('<div class="meta">' + ''.join(f'<div><b>{k}</b>{e(v)}</div>' for k, v in metas if v) + '</div>')
    H.append(f'<h2>Resumo</h2><p>{e(spec.get("resumo"))}</p>')
    H.append(f'<h2>Contexto: por que a alteração foi feita</h2><p>{e(spec.get("contexto"))}</p>')
    if lista(spec.get('objetivos')):
        H.append('<h4>Objetivos</h4><ul>' + ''.join(f'<li>{e(o)}</li>' for o in lista(spec.get('objetivos'))) + '</ul>')
    H.append('<h2>O que foi alterado</h2><table><tr><th>Arquivo</th><th>Situação</th><th>+ linhas</th><th>− linhas</th></tr>')
    for a in coleta['arquivos']:
        H.append(f'<tr><td><code>{e(a["arquivo"])}</code></td><td>{e(a["status"])}</td><td class="num">{a["adicionadas"]}</td><td class="num">{a["removidas"]}</td></tr>')
    H.append('</table>')
    for alt in spec.get('alteracoes', []):
        H.append(f'<h3>{e(alt.get("arquivo"))}</h3>')
        if alt.get('resumo'):
            H.append(f'<p>{e(alt["resumo"])}</p>')
        if alt.get('motivo'):
            H.append(f'<div class="why"><b>Por quê:</b> {e(alt["motivo"])}</div>')
        if lista(alt.get('detalhes')):
            H.append('<ul>' + ''.join(f'<li>{e(d)}</li>' for d in lista(alt.get('detalhes'))) + '</ul>')
        for t in alt.get('trechos', []):
            H.append(f'<h4>{e(t.get("titulo", "Trecho"))}</h4>')
            if t.get('explicacao'):
                H.append(f'<p>{e(t["explicacao"])}</p>')
            if t.get('antes') or t.get('depois'):
                H.append('<div class="ba">'
                         f'<div><div class="lbl">Antes</div><pre>{e(t.get("antes"))}</pre></div>'
                         f'<div><div class="lbl">Depois</div><pre>{e(t.get("depois"))}</pre></div></div>')
    imp = spec.get('impacto') or {}
    if any(lista(imp.get(k)) for k in ('programas', 'tabelas', 'riscos')):
        H.append('<h2>Impacto</h2>')
        for k, t in (('programas', 'Programas afetados'), ('tabelas', 'Tabelas gravadas/lidas'), ('riscos', 'Riscos e cuidados')):
            if lista(imp.get(k)):
                H.append(f'<h4>{t}</h4><ul>' + ''.join(f'<li>{e(x)}</li>' for x in lista(imp.get(k))) + '</ul>')
    if spec.get('testes'):
        H.append('<h2>Como testar</h2><table><tr><th>#</th><th>Passos</th><th>Resultado esperado</th></tr>')
        for i, t in enumerate(spec['testes'], 1):
            H.append(f'<tr><td class="num">{i}</td><td>{e(t.get("passos"))}</td><td>{e(t.get("esperado"))}</td></tr>')
        H.append('</table>')
    if lista(spec.get('pendencias')):
        H.append('<h2>Pendências e fora do escopo</h2><ul>' + ''.join(f'<li>{e(p)}</li>' for p in lista(spec.get('pendencias'))) + '</ul>')
    H.append('<div class="anexo"><h2>Anexo: diff completo (original → atual)</h2>')
    for a in coleta['arquivos']:
        H.append(f'<h3>{e(a["arquivo"])}</h3>{diff_html(a["diff"])}')
    H.append('</div>')
    H.append(f'<div class="foot">Gerado pelo DocToMe em {dt.datetime.now().strftime("%d/%m/%Y %H:%M")} a partir dos originais guardados em {e(coleta["originais"])}.</div>')
    H.append('</body></html>')
    return ''.join(H)


def navegador():
    cands = [
        os.path.expandvars(r'%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe'),
        os.path.expandvars(r'%ProgramFiles%\Microsoft\Edge\Application\msedge.exe'),
        os.path.expandvars(r'%ProgramFiles%\Google\Chrome\Application\chrome.exe'),
        os.path.expandvars(r'%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe'),
        os.path.expandvars(r'%LocalAppData%\Google\Chrome\Application\chrome.exe'),
        shutil.which('msedge') or '', shutil.which('chrome') or '', shutil.which('google-chrome') or '', shutil.which('chromium') or ''
    ]
    return next((c for c in cands if c and os.path.exists(c)), None)


def longo(p):
    """Caminho absoluto com o prefixo do Windows para passar do limite de 260 caracteres."""
    p = os.path.abspath(p)
    prefix = '\\\\?\\'
    return prefix + p if os.name == 'nt' and len(p) > 240 and not p.startswith(prefix) else p


def gerar_pdf(html_text, pdf_path):
    nav = navegador()
    if not nav:
        return 'Edge/Chrome não encontrado: o PDF não foi gerado (o .html ao lado pode ser impresso em PDF).'
    html_final = pdf_path[:-4] + '.html'
    with open(longo(html_final), 'w', encoding='utf-8') as f:
        f.write(html_text)
    # o Edge não grava além de 260 caracteres de caminho (pasta de cliente funda): imprime numa pasta curta e move
    work = tempfile.mkdtemp(prefix='dtm-')
    prof = os.path.join(work, 'p')
    tmp_html = os.path.join(work, 'doc.html')
    tmp_pdf = os.path.join(work, 'doc.pdf')
    with open(tmp_html, 'w', encoding='utf-8') as f:
        f.write(html_text)
    r = None
    try:
        uri = 'file:///' + tmp_html.replace('\\', '/')
        for modo in ('--headless=new', '--headless'):
            # a saída precisa ser capturada: com stdout descartado o Edge headless pode terminar sem imprimir
            r = subprocess.run([nav, modo, '--disable-gpu', '--no-first-run', f'--user-data-dir={prof}', '--no-pdf-header-footer', f'--print-to-pdf={tmp_pdf}', uri],
                               capture_output=True, text=True, timeout=120)
            if os.path.exists(tmp_pdf) and os.path.getsize(tmp_pdf) > 1000:
                break
        if not os.path.exists(tmp_pdf) or os.path.getsize(tmp_pdf) < 1000:
            detalhe = ((r.stderr or '') + (r.stdout or '')).strip().splitlines()[-3:] if r else []
            return f'O navegador não gerou o PDF ({nav}): {" | ".join(detalhe)[:300]}. O .html ficou ao lado e pode ser impresso em PDF.'
        shutil.copyfile(tmp_pdf, longo(pdf_path))
    finally:
        shutil.rmtree(work, ignore_errors=True)
    return None


# ---------------------------------------------------------------- PPTX

def carregar_pptx():
    try:
        import pptx  # noqa: F401
        return True
    except ImportError:
        pass
    r = subprocess.run([sys.executable, '-m', 'pip', 'install', '--user', '--quiet', 'python-pptx'], capture_output=True, text=True)
    if r.returncode != 0:
        return False
    import site, importlib
    importlib.invalidate_caches()
    if site.getusersitepackages() not in sys.path:
        sys.path.append(site.getusersitepackages())
    try:
        import pptx  # noqa: F401
        return True
    except ImportError:
        return False


def gerar_pptx(spec, coleta, path):
    if not carregar_pptx():
        return 'python-pptx indisponível e a instalação automática falhou: a apresentação não foi gerada.'
    from pptx import Presentation
    from pptx.util import Inches, Pt
    from pptx.dml.color import RGBColor

    ROXO = RGBColor(0x2B, 0x1F, 0x73)
    ACENTO = RGBColor(0x6D, 0x4A, 0xFF)
    CINZA = RGBColor(0x5B, 0x63, 0x74)
    prs = Presentation()
    prs.slide_width, prs.slide_height = Inches(13.333), Inches(7.5)
    blank = prs.slide_layouts[6]

    def caixa(slide, x, y, w, h, texto, size=18, bold=False, color=None):
        tb = slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
        tf = tb.text_frame
        tf.word_wrap = True
        p = tf.paragraphs[0]
        p.text = texto
        p.font.size = Pt(size)
        p.font.bold = bold
        if color:
            p.font.color.rgb = color
        return tf

    def barra(slide):
        s = slide.shapes.add_shape(1, 0, 0, prs.slide_width, Inches(0.18))
        s.fill.solid()
        s.fill.fore_color.rgb = ACENTO
        s.line.fill.background()

    def topicos(titulo, itens, sub=None):
        itens = lista(itens)
        if not itens:
            return
        for i in range(0, len(itens), 7):
            s = prs.slides.add_slide(blank)
            barra(s)
            caixa(s, 0.6, 0.45, 12, 0.8, titulo + (' (cont.)' if i else ''), 30, True, ROXO)
            if sub and not i:
                caixa(s, 0.6, 1.2, 12, 0.5, sub, 14, False, CINZA)
            tf = caixa(s, 0.8, 1.8, 11.8, 5.2, '', 18)
            first = True
            for it in itens[i:i + 7]:
                p = tf.paragraphs[0] if first else tf.add_paragraph()
                first = False
                p.text = '•  ' + str(it)
                p.font.size = Pt(18)
                p.space_after = Pt(10)

    # capa
    s = prs.slides.add_slide(blank)
    fundo = s.shapes.add_shape(1, 0, 0, prs.slide_width, prs.slide_height)
    fundo.fill.solid()
    fundo.fill.fore_color.rgb = ROXO
    fundo.line.fill.background()
    caixa(s, 0.8, 2.2, 11.5, 1.5, spec.get('titulo', 'Documentação da alteração'), 40, True, RGBColor(0xFF, 0xFF, 0xFF))
    linha = ' · '.join(str(spec[c]) for c in ('cliente', 'projeto', 'data', 'chamado') if spec.get(c))
    caixa(s, 0.8, 3.8, 11.5, 0.8, spec.get('subtitulo') or linha, 20, False, RGBColor(0xDD, 0xD6, 0xFF))
    if spec.get('subtitulo') and linha:
        caixa(s, 0.8, 4.5, 11.5, 0.6, linha, 16, False, RGBColor(0xDD, 0xD6, 0xFF))

    topicos('Resumo', [spec.get('resumo', '')])
    topicos('Por que foi feito', [spec.get('contexto', '')] + lista(spec.get('objetivos')))
    arqs = [f"{a['arquivo']} — {a['status']} (+{a['adicionadas']} / −{a['removidas']})" for a in coleta['arquivos']]
    topicos('Arquivos alterados', arqs, f'{len(arqs)} arquivo(s) comparados com os originais')
    for alt in spec.get('alteracoes', []):
        itens = ([f"Por quê: {alt['motivo']}"] if alt.get('motivo') else []) + lista(alt.get('detalhes'))
        topicos(alt.get('arquivo', 'Alteração'), itens or [alt.get('resumo', '')], alt.get('resumo'))
    imp = spec.get('impacto') or {}
    topicos('Impacto', [f'Programa: {x}' for x in lista(imp.get('programas'))] + [f'Tabela: {x}' for x in lista(imp.get('tabelas'))] + [f'Risco: {x}' for x in lista(imp.get('riscos'))])
    topicos('Como testar', [f"{t.get('passos', '')} → {t.get('esperado', '')}" for t in spec.get('testes', [])])
    topicos('Pendências e fora do escopo', spec.get('pendencias'))
    prs.save(longo(path))
    return None


# ---------------------------------------------------------------- main

def main():
    # terminal em CP1252 não quebra com caractere que ele não tem (ex.: "−")
    try:
        sys.stdout.reconfigure(errors='replace')
    except Exception:
        pass
    ap = argparse.ArgumentParser(description='DocToMe')
    sub = ap.add_subparsers(dest='cmd', required=True)
    c = sub.add_parser('coletar')
    c.add_argument('--originais', required=True)
    c.add_argument('--projeto', required=True)
    c.add_argument('--saida', default='')
    li = sub.add_parser('listar')
    li.add_argument('--projeto', required=True)
    g = sub.add_parser('gerar')
    g.add_argument('--spec', required=True)
    g.add_argument('--coleta', required=True)
    g.add_argument('--saida', required=True)
    a = ap.parse_args()

    if a.cmd == 'listar':
        print(json.dumps(listar(a.projeto), ensure_ascii=False, indent=1))
        return

    if a.cmd == 'coletar':
        if not os.path.isdir(a.originais):
            print(json.dumps({'erro': f'pasta de originais não existe: {a.originais}'}, ensure_ascii=False))
            sys.exit(2)
        r = coletar(a.originais, a.projeto)
        txt = json.dumps(r, ensure_ascii=False, indent=1)
        if a.saida:
            with open(a.saida, 'w', encoding='utf-8') as f:
                f.write(txt)
            resumo = [{k: x[k] for k in ('arquivo', 'status', 'adicionadas', 'removidas')} for x in r['arquivos']]
            print(json.dumps({'coleta': os.path.abspath(a.saida), 'arquivos': resumo}, ensure_ascii=False, indent=1))
        else:
            print(txt)
        return

    with open(a.spec, encoding='utf-8') as f:
        spec = json.load(f)
    with open(a.coleta, encoding='utf-8') as f:
        coleta = json.load(f)
    os.makedirs(a.saida, exist_ok=True)
    nome = slug(spec.get('titulo', 'documentacao'))
    base = os.path.join(a.saida, nome)
    avisos = []
    with open(longo(base + '.md'), 'w', encoding='utf-8') as f:
        f.write(gerar_md(spec, coleta))
    w = gerar_pdf(gerar_html(spec, coleta), base + '.pdf')
    if w:
        avisos.append(w)
    w = gerar_pptx(spec, coleta, base + '.pptx')
    if w:
        avisos.append(w)
    arquivos = [p for p in (base + '.pdf', base + '.md', base + '.pptx') if os.path.exists(p)]
    print(json.dumps({'gerados': arquivos, 'avisos': avisos}, ensure_ascii=False, indent=1))


if __name__ == '__main__':
    main()

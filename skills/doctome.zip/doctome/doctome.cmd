@echo off
setlocal
rem DocToMe - atalho: acha o Python e chama o doctome.py desta pasta.
rem   doctome.cmd coletar "<pasta dos originais>" "<pasta do projeto>" "<arquivo coleta.json>"
rem   doctome.cmd listar "<pasta do projeto>"
rem   doctome.cmd gerar "<doc.json>" "<coleta.json>" "<pasta de saída>"
set "DIR=%~dp0"
set "PY="
where py >nul 2>nul && set "PY=py -3"
if not defined PY where python >nul 2>nul && set "PY=python"
if not defined PY (
  echo {"erro": "Python 3 nao encontrado. Instale com: winget install -e --id Python.Python.3.12  (depois feche e abra o Progress Code)"}
  exit /b 3
)
if /i "%~1"=="coletar" (
  %PY% "%DIR%doctome.py" coletar --originais "%~2" --projeto "%~3" --saida "%~4"
  exit /b %errorlevel%
)
if /i "%~1"=="listar" (
  %PY% "%DIR%doctome.py" listar --projeto "%~2"
  exit /b %errorlevel%
)
if /i "%~1"=="gerar" (
  %PY% "%DIR%doctome.py" gerar --spec "%~2" --coleta "%~3" --saida "%~4"
  exit /b %errorlevel%
)
echo Uso:
echo   doctome.cmd coletar "pasta dos originais" "pasta do projeto" "coleta.json"
echo   doctome.cmd listar "pasta do projeto"
echo   doctome.cmd gerar "doc.json" "coleta.json" "pasta de saida"
exit /b 1

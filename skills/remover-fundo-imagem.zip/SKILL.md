---
name: remover-fundo-imagem
description: Remove o fundo de uma imagem (deixa transparente) com rembg, e prepara imagens para web (WebP/AVIF, otimização sem perda visível perceptível). Use quando o usuário pedir "remover o fundo dessa foto/logo", "deixar o fundo transparente", "otimizar essa imagem para o site".
argument-hint: [caminho da imagem]
---

# Remover fundo e preparar imagens para web

## Passo 1 — Instalar
```
pip install rembg[cpu] Pillow
```
Na primeira execução, o `rembg` baixa automaticamente o modelo de rede neural usado (alguns MB, uma vez só,
guardado em cache do usuário) — isso precisa de internet na primeira vez; execuções seguintes funcionam offline.

## Passo 2 — Remover fundo
```python
from rembg import remove
from PIL import Image

img = Image.open("entrada.jpg")
sem_fundo = remove(img)  # retorna imagem RGBA com fundo transparente
sem_fundo.save("saida.png")  # sempre PNG (ou WebP) - JPG nao suporta transparencia
```
Para lotes, processe uma imagem por vez com `try/except` e reporte falhas — imagens com fundo muito parecido com o
objeto principal (baixo contraste) podem sair com recorte impreciso; avise o usuário para conferir visualmente
antes de usar em produção (ex.: catálogo de produtos).

## Passo 3 — Otimizar para web (WebP/AVIF, sem instalar programa novo)
```python
img = Image.open("entrada.jpg")
img.save("saida.webp", "WEBP", quality=80, method=6)  # method=6 = mais lento, mais comprimido
```
AVIF precisa do plugin `pillow-avif-plugin` (`pip install pillow-avif-plugin`) — sem ele, Pillow não sabe salvar
`.avif`. WebP já funciona nativamente no Pillow moderno, sem plugin extra.

## Passo 4 — Sprites (juntar várias imagens pequenas em uma só)
```python
sprite = Image.new("RGBA", (largura_total, altura_max), (0, 0, 0, 0))
x = 0
for img in imagens:
    sprite.paste(img, (x, 0), img)
    x += img.width
sprite.save("sprite.png")
```
Guarde à parte um mapeamento (JSON) de qual região do sprite corresponde a qual imagem original — sem isso o sprite
não é utilizável no CSS/código que vai consumi-lo.

## Regras
- Fundo removido "quase certo" (sobra uma borda ou falta um pedaço) não deve ser entregue como pronto — mostre o
  resultado ao usuário (ou descreva visualmente) antes de assumir que está definitivo, especialmente para logos
  onde a nitidez da borda importa muito.
- Sempre salve o resultado com transparência em PNG ou WebP — nunca em JPG (perde o canal alpha silenciosamente,
  virando fundo preto ou branco sem aviso).
- Comprimir demais (`quality` muito baixo) degrada visivelmente logos/textos finos — teste visualmente o resultado
  antes de aplicar em lote com uma configuração agressiva.

## Arquivos desta skill
Nenhum script fixo — os trechos acima cobrem os casos mais comuns; adapte à imagem/lote real do usuário.

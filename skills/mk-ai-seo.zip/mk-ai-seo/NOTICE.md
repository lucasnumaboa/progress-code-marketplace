# Origem e mudanças

- **Repositório:** https://github.com/coreyhaines31/marketingskills
- **Caminho no repositório:** `skills/ai-seo`
- **Autor:** Corey Haines
- **Licença:** MIT (texto em `LICENSE`)
- **Commit usado:** `5b2b400eec1e7e1cec76245a715d0b0d4fd2a9c1`
- **Arquivos copiados:** `SKILL.md`, `references/agent-defaults.md`, `references/agent-readiness.md`, `references/ai-attribution.md`, `references/answer-accuracy.md`, `references/citations-vs-recommendations.md`, `references/content-patterns.md`, `references/content-types.md`, `references/format-volatility.md`, `references/linkedin-ai-citations.md`, `references/multilingual-and-commerce.md`, `references/okf.md`, `references/platform-ranking-factors.md`, `references/positioning-and-consensus.md`, `references/prompt-portfolio.md`, `references/youtube-ai-citations.md`

## Mudanças feitas

- no cabeçalho (frontmatter), `name:` passou de `ai-seo` para `mk-ai-seo`; a descrição ficou igual
- removida a menção ao Magister, produto do próprio mantenedor do repositório (propaganda)
- removida a menção a "Verified Partner"/parceiro comercial do repositório (◆), que é colocação paga/propaganda
- removida a menção a "Verified Partner"/parceiro comercial do repositório (◆), que é colocação paga/propaganda (em `references/agent-readiness.md`)
- nenhuma outra alteração no texto do especialista (mantido em inglês)

Empacotada para o marketplace do Progress Code em 2026-11-22.

# O roteiro YAML

Um arquivo por vídeo, de preferência em `<projeto>/roteiros/<nome>.yaml`. O gravador põe:
- o vídeo em `<projeto>/saida/<nome>.mp4`, com `.srt` e `.txt`;
- os arquivos de trabalho em `<projeto>/trabalho/`.

## Cabeçalho

```yaml
titulo: Sistema X - novidades de novembro      # entra na descrição (.txt)
descricao: |                                    # texto da descrição (.txt), para quem recebe o vídeo
  O que mudou no sistema X: ...
base: http://localhost:8320                     # endereço do site (ambiente de demonstração ou teste)
inicio: /#/painel                               # opcional: a página da primeira cena, se ela não for cartão
login:                                          # opcional: entra pela API do site antes de gravar
  caminho: /api/auth/login                      # POST com o JSON do arquivo abaixo
  credenciais: trabalho/login.json              # relativo à pasta do projeto; só usuário de teste
marca: Sistema X · Cliente Y                    # rodapé dos cartões e selo padrão
logo: ../site/public/img/logo.png               # opcional: logo no cartão (png, jpg ou svg)
cores: {fundo: "#0b1f14", destaque1: "#1f9d55", destaque2: "#0f5f2e"}   # opcional: fundo dos cartões
avisos: ".avisos > *"                           # opcional: seletor dos toasts que podem cobrir um botão
navegador: msedge                               # opcional: msedge, chrome ou chromium (padrão: o que houver)
css: ".banner-cookies { display: none }"        # opcional: CSS aplicado em todas as páginas
```

`login` é para sites que entram por uma rota de API e guardam a sessão em cookie. Use só em ambiente de teste, com usuário de teste:
- a senha fica num arquivo local (`trabalho/`), nunca no roteiro;
- a senha nunca é digitada na tela gravada;
- apague o arquivo no fim.

Se o site não tem rota assim, combine com o usuário. Uma saída é um ambiente de demonstração sem login. A outra é o usuário entrar e você usar um cookie de teste. Não digite a senha real de ninguém.

## Cenas

```yaml
cenas:
  - cartao: {selo: Novidades, titulo: O que há de novo, subtitulo: "Prévia, tempo real e agendamentos"}
    fala: Olá! Neste vídeo, mostramos o que mudou no sistema.
    capitulo: Introdução

  - fala: Começamos pelo Painel. Aqui ficam todas as execuções.
    capitulo: Painel
    atraso: 0                  # espera antes da primeira ação (padrão 0,6 s)
    acoes:
      - ir: /#/painel
      - destacar: {alvo: "#conteudo table", segundos: 2.5}

  - fala: A inspiração veio do n8n.
    pronuncia: A inspiração veio do ene oito ene.   # só a voz lê assim; a legenda mostra a "fala"
    depois: 1                  # tempo extra no fim da cena (padrão 0,5 s)
```

- A cena dura o que durar a mais longa das duas: a fala ou as ações. As ações começam junto com a fala.
- Um `cartao` sozinho na cena troca a tela por um cartão de título.
- Um `capitulo` marca o início de um capítulo na descrição. A lista só sai com 3 capítulos ou mais.

YAML: dentro de `{ }`, texto com `?`, `:`, `,`, `#` ou aspas vai entre aspas. Exemplo: `titulo: "Dúvidas?"`.

## Ações

| Ação | Exemplo | O que faz |
|---|---|---|
| `ir` | `ir: /#/fluxos` | abre o caminho (ou um endereço completo) |
| `clicar` | `clicar: "button:has-text('Salvar')"` | leva o cursor até o elemento e clica (com a onda do clique) |
| `marcar` | `marcar: "label[for=f-simular]"` | mesmo que clicar (caixas e interruptores) |
| `digitar` | `digitar: {alvo: "#f-nome", texto: "Fechamento", atraso: 60}` | clica no campo, limpa e digita letra a letra (`limpar: false` mantém o que tinha) |
| `selecionar` | `selecionar: {alvo: "#f-bloco", opcao: "Bloco A"}` | escolhe a opção de um `<select>` pelo texto |
| `arrastar` | `arrastar: {de: ".lista .item:has-text('FT2100')", para: ".area", vaga: ".area .item"}` | arrasta com o cursor e uma cópia do item seguindo o mouse; com `vaga`, solta logo depois do último item já solto |
| `apontar` | `apontar: {alvo: "#f-hora", segundos: 1.5}` | destaca e leva o cursor até o elemento, sem clicar |
| `destacar` | `destacar: {alvo: ".cartao", segundos: 3}` | contorno laranja pulsando, sem mover o cursor |
| `rolar` | `rolar: "#rodape"` ou `rolar: 400` | rola até o elemento, ou N pixels |
| `esperar` | `esperar: {alvo: "text=Concluído", max: 120, cortar: true}` | espera o elemento aparecer; com `cortar`, a espera sai do vídeo (depois que a fala da cena termina) |
| `tecla` | `tecla: Escape` | aperta uma tecla |
| `pausa` | `pausa: 1.5` | espera N segundos |
| `js` | `js: "document.querySelector('.lista').scrollTo({top: 0, behavior: 'smooth'})"` | roda JavaScript na página (rolar uma lista, fechar um aviso) |

Seletores são os do Playwright: CSS, `:has-text('...')`, `text=...` e `:has(...)`.

O primeiro que bater é o usado. Prefira seletores estáveis:
- id;
- `aria-label`;
- atributo de dado.

Seletores ruins:
- posição: `tr:nth-child(3)` quebra quando os dados mudam;
- classes geradas.

## Narração que funciona

- Fale ao ritmo de cerca de 2,6 palavras por segundo. Uma cena com 25 palavras dura uns 10 s.
- Uma ideia por frase. Use frases curtas, na voz ativa, falando do que está na tela naquele momento.
- Siglas e nomes estrangeiros vão em `pronuncia` para a voz ler direito: "n8n" vira "ene oito ene", "RPW" vira "erre pê dáblio" se a voz tropeçar.
- O vídeo vai para terceiros: não narre detalhes internos (nomes de variáveis, tabelas, bugs).
- Um vídeo de novidades fica bom entre 2 e 5 min. Se passar disso, divida em vídeos menores.

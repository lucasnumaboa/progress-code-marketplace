// Camada visual dos vídeos: cursor do mouse (o Chromium sem janela não desenha), onda no clique e destaque
// ao redor do elemento. Injetado em todas as páginas antes dos scripts do site.
(() => {
  if (window.__tut) return;
  // Dentro da moldura de celular (iframe): o cursor é desenhado só na página de fora, que recebe a posição daqui
  const emQuadro = window.top !== window;
  const css = `
    #tut-cursor { position: fixed; left: 0; top: 0; width: 28px; height: 28px; z-index: 2147483647;
      pointer-events: none; transform: translate(-3px, -2px); filter: drop-shadow(0 2px 3px rgba(0,0,0,.35)); }
    .tut-onda { position: fixed; z-index: 2147483646; pointer-events: none; width: 16px; height: 16px;
      margin: -8px 0 0 -8px; border-radius: 50%; border: 3px solid #ff7a00; animation: tut-onda .6s ease-out forwards; }
    @keyframes tut-onda { from { transform: scale(.4); opacity: 1; } to { transform: scale(3.2); opacity: 0; } }
    .tut-destaque { position: fixed; z-index: 2147483645; pointer-events: none; border: 3px solid #ff7a00;
      border-radius: 10px; box-shadow: 0 0 0 6px rgba(255,122,0,.18); transition: opacity .3s;
      animation: tut-pulso 1.2s ease-in-out infinite; }
    @keyframes tut-pulso { 50% { box-shadow: 0 0 0 11px rgba(255,122,0,.08); } }`;
  const svg = `<svg viewBox="0 0 24 24" width="28" height="28" xmlns="http://www.w3.org/2000/svg">
    <path d="M3 2 L3 19 L7.5 14.8 L10.6 21.6 L13.6 20.3 L10.6 13.6 L16.8 13.6 Z" fill="#fff" stroke="#111" stroke-width="1.4" stroke-linejoin="round"/></svg>`;

  let x = 720, y = 400;
  try {
    const salvo = JSON.parse(sessionStorage.getItem('tut-pos') || 'null');
    if (salvo) { x = salvo[0]; y = salvo[1]; }
  } catch (e) { /* sem sessionStorage */ }

  function montar() {
    if (document.getElementById('tut-cursor') || document.getElementById('tut-estilo') || !document.body) return;
    const estilo = document.createElement('style');
    estilo.id = 'tut-estilo';
    estilo.textContent = css;
    document.head.appendChild(estilo);
    if (emQuadro) return;
    const c = document.createElement('div');
    c.id = 'tut-cursor';
    c.innerHTML = svg;
    document.body.appendChild(c);
    mover(x, y);
  }
  function mover(nx, ny) {
    x = nx; y = ny;
    const c = document.getElementById('tut-cursor');
    if (c) {
      c.style.left = x + 'px';
      c.style.top = y + 'px';
    }
    try { sessionStorage.setItem('tut-pos', JSON.stringify([x, y])); } catch (e) { /* ignora */ }
  }
  window.addEventListener('mousemove', e => {
    if (emQuadro) {
      try { parent.postMessage({ tut: 'cursor', x: e.clientX, y: e.clientY }, '*'); } catch (erro) { /* ignora */ }
    } else {
      mover(e.clientX, e.clientY);
    }
  }, true);
  if (!emQuadro) {
    window.addEventListener('message', e => {
      const d = e.data;
      if (!d || d.tut !== 'cursor') return;
      const quadro = [...document.querySelectorAll('iframe')].find(f => f.contentWindow === e.source);
      if (!quadro) return;
      const r = quadro.getBoundingClientRect();
      mover(r.left + d.x, r.top + d.y);
    });
  }
  window.addEventListener('mousedown', e => {
    const o = document.createElement('div');
    o.className = 'tut-onda';
    o.style.left = e.clientX + 'px';
    o.style.top = e.clientY + 'px';
    document.body.appendChild(o);
    setTimeout(() => o.remove(), 700);
  }, true);

  // Arrastar e soltar (HTML5): no navegador sem janela nao ha' mousemove durante o arraste (o cursor
  // ficava parado na origem) nem a imagem que o Chrome desenha seguindo o mouse. Aqui o cursor segue os
  // eventos drag/dragover e uma copia do elemento arrastado acompanha o cursor, como no Chrome de verdade.
  let fantasma = null;
  function moverFantasma(nx, ny) {
    if (!fantasma) return;
    fantasma.style.left = (nx - fantasma.__dx) + 'px';
    fantasma.style.top = (ny - fantasma.__dy) + 'px';
  }
  function tirarFantasma() { if (fantasma) { fantasma.remove(); fantasma = null; } }
  window.addEventListener('dragstart', e => {
    tirarFantasma();
    const el = (e.target && e.target.closest && e.target.closest('[draggable="true"]')) || e.target;
    if (!el || !el.getBoundingClientRect) return;
    const r = el.getBoundingClientRect();
    const cs = getComputedStyle(el);
    fantasma = el.cloneNode(true);
    fantasma.removeAttribute('id');
    Object.assign(fantasma.style, {
      position: 'fixed', left: r.left + 'px', top: r.top + 'px', width: r.width + 'px', minHeight: r.height + 'px',
      maxWidth: 'none', height: 'auto', margin: '0', boxSizing: 'border-box', zIndex: '2147483646', pointerEvents: 'none', opacity: '.9',
      background: cs.backgroundColor && cs.backgroundColor !== 'rgba(0, 0, 0, 0)' ? cs.backgroundColor : '#fff',
      transform: 'rotate(-2deg) scale(1.03)', boxShadow: '0 12px 28px rgba(16,24,20,.28)', transition: 'none',
    });
    const px = e.clientX || (r.left + Math.min(r.width / 2, 60));
    const py = e.clientY || (r.top + r.height / 2);
    fantasma.__dx = px - r.left;
    fantasma.__dy = py - r.top;
    document.body.appendChild(fantasma);
  }, true);
  ['drag', 'dragover'].forEach(t => window.addEventListener(t, e => {
    if (!e.clientX && !e.clientY) return; // o ultimo "drag" vem com 0,0
    mover(e.clientX, e.clientY);
    moverFantasma(e.clientX, e.clientY);
  }, true));
  ['drop', 'dragend'].forEach(t => window.addEventListener(t, tirarFantasma, true));

  window.__tut = {
    destacar(el, folga = 6) {
      this.limpar();
      const r = el.getBoundingClientRect();
      const d = document.createElement('div');
      d.className = 'tut-destaque';
      Object.assign(d.style, { left: (r.left - folga) + 'px', top: (r.top - folga) + 'px',
        width: (r.width + folga * 2) + 'px', height: (r.height + folga * 2) + 'px' });
      document.body.appendChild(d);
    },
    limpar() { document.querySelectorAll('.tut-destaque').forEach(d => d.remove()); },
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', montar);
  else montar();
})();

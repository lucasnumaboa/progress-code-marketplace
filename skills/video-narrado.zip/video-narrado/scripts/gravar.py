"""Grava um video narrado de um site a partir de um roteiro YAML (skill video-narrado).

O navegador (Edge ou Chromium, sem janela, pelo Playwright) faz os passos do roteiro; a narracao vem de um
modelo de voz pelo OpenRouter; o ffmpeg monta o MP4 1920x1080 com a legenda (.srt) e a descricao com os
capitulos (.txt).

    python -I gravar.py --conferir                       # ambiente e chave (cria o arquivo da chave, se faltar)
    python -I gravar.py --instalar                       # instala o que falta (pip, ffmpeg pelo winget, navegador)
    python -I gravar.py --conferir --testar-chave        # ... e pergunta ao OpenRouter se a chave vale
    python -I gravar.py roteiro.yaml --explorar /caminho # foto da pagina e a lista do que da' para clicar
    python -I gravar.py roteiro.yaml --rapido            # so' uma foto por cena (sem narracao, sem video)
    python -I gravar.py roteiro.yaml --so-narracao       # gera os mp3 e mostra a duracao de cada fala
    python -I gravar.py roteiro.yaml                     # o video completo

A chave do OpenRouter fica em ~/.claude/video-narrado/config.env (OPENROUTER_API_KEY=...). Uma variavel de
ambiente com o mesmo nome vale por cima do arquivo. O script nunca imprime a chave.

Pastas: o projeto do video e' a pasta acima de "roteiros/" (ou a do roteiro, se ele nao estiver numa pasta
"roteiros"); la' ficam trabalho/ (audio guardado, fotos, quadros) e saida/ (o video). --pasta e --saida mudam.
"""
import argparse
import asyncio
import base64
import bisect
import hashlib
import html
import importlib
import json
import os
import re
import shutil
import subprocess
import sys
import time

AQUI = os.path.dirname(os.path.abspath(__file__))
CONFIG_DIR = os.path.join(os.path.expanduser('~'), '.claude', 'video-narrado')
CONFIG = os.path.join(CONFIG_DIR, 'config.env')
MODELO_CONFIG = """# Skill video-narrado: a chave do OpenRouter para a narracao dos videos.
# Crie a chave em https://openrouter.ai/keys e cole logo depois do "=" (sem aspas, sem espacos).
# Este arquivo e' so' seu: nao mande para ninguem nem coloque no Git.
OPENROUTER_API_KEY=

# Voz da narracao (opcional; estes sao os padroes)
TTS_MODELO=microsoft/mai-voice-2.1
TTS_VOZ=pt-BR-Luana:MAI-Voice-2.1
TTS_VELOCIDADE=1.0
"""

VIEWPORT = {'width': 1440, 'height': 810}
ESCALA = 4 / 3  # 1440x810 vira 1920x1080: letra maior no video
LARGURA, ALTURA = 1920, 1080
FPS = 30


# ------------------------------------------------------------------ configuracao (a chave nunca e' impressa)

def ler_config():
    valores = {}
    if os.path.exists(CONFIG):
        with open(CONFIG, encoding='utf-8-sig') as f:
            for linha in f:
                m = re.match(r'^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$', linha)
                if m and not linha.lstrip().startswith('#'):
                    valores[m.group(1)] = m.group(2).strip().strip('"').strip("'")
    for k in ('OPENROUTER_API_KEY', 'TTS_MODELO', 'TTS_VOZ', 'TTS_VELOCIDADE'):
        if os.environ.get(k, '').strip():
            valores[k] = os.environ[k].strip()
    return valores


def origem_da_chave():
    if os.environ.get('OPENROUTER_API_KEY', '').strip():
        return 'variavel de ambiente OPENROUTER_API_KEY'
    return CONFIG


def preparar_config():
    """Cria o arquivo da chave (vazio) se ele nao existe. Devolve True se criou."""
    if os.path.exists(CONFIG):
        return False
    os.makedirs(CONFIG_DIR, exist_ok=True)
    with open(CONFIG, 'w', encoding='utf-8') as f:
        f.write(MODELO_CONFIG)
    return True


def conferir(testar_chave=False):
    """Confere o que o gravador precisa. Codigo de saida: 0 tudo certo, 2 falta a chave, 1 falta outra coisa."""
    faltou = False
    print(f'python: {sys.version.split()[0]}')
    for modulo in ('playwright', 'yaml', 'requests'):
        try:
            __import__(modulo)
            print(f'{modulo}: ok')
        except ImportError:
            print(f'{modulo}: FALTA (pip install {"pyyaml" if modulo == "yaml" else modulo})')
            faltou = True
    for prog in ('ffmpeg', 'ffprobe'):
        print(f'{prog}: {"ok" if shutil.which(prog) else "FALTA (instale o ffmpeg e ponha no PATH)"}')
        faltou = faltou or not shutil.which(prog)
    if not faltou:
        nav = asyncio.run(_testar_navegador())
        print(f'navegador: {nav}')
        faltou = faltou or nav.startswith('FALTA')
    # com a chave na variavel de ambiente (ex.: Progress Code, pelo provedor OpenRouter do app) o arquivo nao e' preciso
    criou = False if os.environ.get('OPENROUTER_API_KEY', '').strip() else preparar_config()
    cfg = ler_config()
    chave = cfg.get('OPENROUTER_API_KEY', '')
    if criou:
        print(f'arquivo da chave: CRIADO agora em {CONFIG}')
    if not chave:
        print(f'chave: FALTA (abra {CONFIG} e cole a chave depois de OPENROUTER_API_KEY=)')
    else:
        print(f'chave: definida ({origem_da_chave()}; {len(chave)} caracteres)')
        if testar_chave:
            print(f'chave no OpenRouter: {_testar_chave(chave)}')
    print(f"voz: {cfg.get('TTS_MODELO', 'microsoft/mai-voice-2.1')} / {cfg.get('TTS_VOZ', 'pt-BR-Luana:MAI-Voice-2.1')}")
    if faltou:
        return 1
    return 0 if chave else 2


def _achar_ffmpeg_winget():
    """ffmpeg instalado pelo winget e ainda fora do PATH deste processo (o PATH novo so' vale em janela nova)."""
    if os.name != 'nt' or (shutil.which('ffmpeg') and shutil.which('ffprobe')):
        return
    winget = os.path.join(os.environ.get('LOCALAPPDATA', ''), 'Microsoft', 'WinGet')
    candidatos = [os.path.join(winget, 'Links')]
    pacotes = os.path.join(winget, 'Packages')
    if os.path.isdir(pacotes):
        for d in sorted(os.listdir(pacotes), reverse=True):
            if not d.lower().startswith('gyan.ffmpeg'):
                continue
            for raiz, _, arqs in os.walk(os.path.join(pacotes, d)):
                if 'ffmpeg.exe' in arqs and 'ffprobe.exe' in arqs:
                    candidatos.append(raiz)
                    break
    for c in candidatos:
        if os.path.isfile(os.path.join(c, 'ffmpeg.exe')) and os.path.isfile(os.path.join(c, 'ffprobe.exe')):
            os.environ['PATH'] = c + os.pathsep + os.environ.get('PATH', '')
            return


def instalar():
    """Instala o que falta e confere de novo. Codigo de saida igual ao do --conferir."""
    if sys.version_info < (3, 10):
        print(f'python {sys.version.split()[0]}: precisa do 3.10 ou mais novo (winget install -e --id Python.Python.3.12)')
        return 1
    faltam = []
    for modulo, pacote in (('playwright', 'playwright'), ('yaml', 'pyyaml'), ('requests', 'requests')):
        try:
            __import__(modulo)
        except ImportError:
            faltam.append(pacote)
    if faltam:
        print('instalando pelo pip: ' + ', '.join(faltam), flush=True)
        r = subprocess.run([sys.executable, '-m', 'pip', 'install', '--disable-pip-version-check', *faltam])
        if r.returncode != 0:
            print('o pip nao conseguiu instalar: ' + ', '.join(faltam))
            return 1
        importlib.invalidate_caches()
        # com -I o Python ignora a pasta de usuario: se o pip instalou la', a biblioteca nao aparece para o gravador
        teste = subprocess.run([sys.executable, '-I', '-c', 'import playwright, yaml, requests'], capture_output=True)
        if teste.returncode != 0:
            print('as bibliotecas foram para a pasta de usuario do Python, que o gravador (python -I) nao enxerga.')
            print('instale num Python so' + "'" + ' seu (python.org, "instalar para mim") ou rode: python -m pip install --target <pasta do site-packages> ...')
            return 1
    _achar_ffmpeg_winget()
    if not (shutil.which('ffmpeg') and shutil.which('ffprobe')):
        if os.name == 'nt' and shutil.which('winget'):
            print('instalando o ffmpeg pelo winget...', flush=True)
            subprocess.run(['winget', 'install', '--id', 'Gyan.FFmpeg', '-e', '--accept-source-agreements',
                            '--accept-package-agreements', '--disable-interactivity'])
            _achar_ffmpeg_winget()
        if not (shutil.which('ffmpeg') and shutil.which('ffprobe')):
            print('ffmpeg: nao deu para instalar sozinho (Windows: winget install --id Gyan.FFmpeg -e; '
                  'Mac: brew install ffmpeg; Linux: sudo apt install ffmpeg)')
            return 1
    if asyncio.run(_testar_navegador()).startswith('FALTA'):
        print('instalando o navegador do Playwright (chromium)...', flush=True)
        subprocess.run([sys.executable, '-m', 'playwright', 'install', 'chromium'])
    print('---')
    return conferir(False)


def _testar_chave(chave):
    import requests
    try:
        r = requests.get('https://openrouter.ai/api/v1/key', headers={'Authorization': f'Bearer {chave}'}, timeout=20)
    except Exception as e:  # sem rede
        return f'sem resposta ({type(e).__name__})'
    if r.status_code == 200:
        return 'aceita'
    if r.status_code in (401, 403):
        return f'RECUSADA ({r.status_code}): confira a chave no arquivo'
    return f'resposta {r.status_code}'


async def _testar_navegador():
    from playwright.async_api import async_playwright
    async with async_playwright() as p:
        for canal in _canais(None):
            try:
                nav = await (p.chromium.launch(channel=canal, headless=True) if canal else p.chromium.launch(headless=True))
                await nav.close()
                return f'ok ({canal or "chromium do Playwright"})'
            except Exception:
                continue
    return 'FALTA (instale o Edge/Chrome, ou rode: python -m playwright install chromium)'


def _canais(pedido):
    if pedido:
        return [None if pedido == 'chromium' else pedido]
    return ['msedge', 'chrome', None] if os.name == 'nt' else [None, 'chrome', 'msedge']


# ------------------------------------------------------------------ narracao

def _duracao(caminho):
    saida = subprocess.run(['ffprobe', '-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', caminho],
                           capture_output=True, text=True, check=True).stdout
    return float(saida.strip())


def _estimar(texto):
    return max(1.5, len(texto.split()) / 2.6 + 0.4)


def gerar_fala(texto, pasta_audio, sem_audio=False):
    """(mp3, duracao). O mp3 fica guardado por modelo/voz/velocidade/texto: regravar nao paga de novo.
    Sem chave (ou com --sem-audio) e sem o mp3 guardado: (None, duracao estimada)."""
    cfg = ler_config()
    chave = cfg.get('OPENROUTER_API_KEY', '')
    modelo = cfg.get('TTS_MODELO', 'microsoft/mai-voice-2.1')
    voz = cfg.get('TTS_VOZ', 'pt-BR-Luana:MAI-Voice-2.1')
    velocidade = float(cfg.get('TTS_VELOCIDADE', '1.0') or 1.0)
    nome = hashlib.sha1(f'{modelo}|{voz}|{velocidade}|{texto}'.encode()).hexdigest()[:20]
    caminho = os.path.join(pasta_audio, nome + '.mp3')
    if sem_audio:
        return None, _estimar(texto)
    if os.path.exists(caminho):
        return caminho, _duracao(caminho)
    if not chave:
        return None, _estimar(texto)
    import requests
    os.makedirs(pasta_audio, exist_ok=True)
    pcm = modelo.startswith('google/')  # Gemini so' devolve PCM cru (24 kHz, 16 bits, mono)
    corpo = {'model': modelo, 'input': texto, 'voice': voz, 'response_format': 'pcm' if pcm else 'mp3'}
    if velocidade != 1.0:
        corpo['speed'] = velocidade
    for tentativa in range(3):
        r = requests.post('https://openrouter.ai/api/v1/audio/speech', json=corpo, timeout=180,
                          headers={'Authorization': f'Bearer {chave}'})
        if r.status_code == 200 and r.content:
            break
        print(f'  TTS falhou ({r.status_code}): {r.text[:200]}', flush=True)
        if r.status_code in (401, 403):
            raise SystemExit(f'O OpenRouter recusou a chave ({r.status_code}). Confira {origem_da_chave()}.')
        time.sleep(3 * (tentativa + 1))
    else:
        raise SystemExit('Nao foi possivel gerar a narracao.')
    if pcm:
        subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-f', 's16le', '-ar', '24000', '-ac', '1', '-i', 'pipe:0',
                        '-c:a', 'libmp3lame', '-q:a', '2', '-f', 'mp3', caminho + '.tmp'], input=r.content, check=True)
    else:
        with open(caminho + '.tmp', 'wb') as f:
            f.write(r.content)
    os.replace(caminho + '.tmp', caminho)
    return caminho, _duracao(caminho)


# ------------------------------------------------------------------ captura da tela

class Captura:
    """Quadros do screencast do navegador com o horario de cada um, mais os trechos cortados."""

    def __init__(self, cdp, pasta):
        self.cdp, self.pasta = cdp, pasta
        self.quadros = []
        self.cortes = []
        self.inicio = None
        self._corte_aberto = None

    async def iniciar(self):
        shutil.rmtree(self.pasta, ignore_errors=True)
        os.makedirs(self.pasta)
        self.cdp.on('Page.screencastFrame', self._quadro)
        await self.cdp.send('Page.startScreencast', {'format': 'jpeg', 'quality': 92, 'maxWidth': LARGURA,
                                                     'maxHeight': ALTURA, 'everyNthFrame': 1})
        self.inicio = time.time()

    async def parar(self):
        self.fim = time.time()
        await self.cdp.send('Page.stopScreencast')

    def _quadro(self, p):
        horario = p.get('metadata', {}).get('timestamp') or time.time()
        caminho = os.path.join(self.pasta, f'{len(self.quadros):06d}.jpg')
        with open(caminho, 'wb') as f:
            f.write(base64.b64decode(p['data']))
        self.quadros.append((horario, caminho))
        asyncio.ensure_future(self.cdp.send('Page.screencastFrameAck', {'sessionId': p['sessionId']}))

    def cortar_inicio(self):
        self._corte_aberto = time.time()

    def cortar_fim(self):
        if self._corte_aberto:
            self.cortes.append((self._corte_aberto, time.time()))
            self._corte_aberto = None

    def no_video(self, parede=None):
        parede = time.time() if parede is None else parede
        t = parede - self.inicio
        for a, b in self.cortes:
            if parede >= b:
                t -= b - a
            elif parede > a:
                t -= parede - a
        return t

    def na_parede(self, t):
        parede = self.inicio + t
        for a, b in sorted(self.cortes):
            if parede >= a:
                parede += b - a
        return parede

    def montar(self, destino):
        """Video sem som, quadro a quadro a 30 por segundo pelo stdin do ffmpeg. (O concat de imagens com
        "duration" contava cada imagem com no minimo 1/25 s no ffmpeg do Windows: o video saia mais longo
        que o audio e a narracao escorregava.)"""
        if not self.quadros:
            raise SystemExit('Nenhum quadro capturado.')
        self.quadros.sort()
        horarios = [h for h, _ in self.quadros]
        total = int(self.no_video(self.fim) * FPS)
        proc = subprocess.Popen(['ffmpeg', '-y', '-loglevel', 'error', '-f', 'image2pipe', '-framerate', str(FPS),
                                 '-c:v', 'mjpeg', '-i', '-',
                                 '-vf', f'scale={LARGURA}:{ALTURA}:flags=lanczos,format=yuv420p',
                                 '-c:v', 'libx264', '-preset', 'slow', '-crf', '18', '-r', str(FPS), destino],
                                stdin=subprocess.PIPE)
        ultimo, dados = None, b''
        for k in range(total):
            i = max(0, bisect.bisect_right(horarios, self.na_parede(k / FPS)) - 1)
            arquivo = self.quadros[i][1]
            if arquivo != ultimo:
                with open(arquivo, 'rb') as f:
                    dados = f.read()
                ultimo = arquivo
            proc.stdin.write(dados)
        proc.stdin.close()
        if proc.wait() != 0:
            raise SystemExit('O ffmpeg falhou ao montar o video.')
        return total / FPS


# ------------------------------------------------------------------ acoes na tela

class Diretor:
    def __init__(self, page, base, captura=None, rapido=False):
        self.page, self.base, self.captura, self.rapido = page, base, captura, rapido
        self.pos = (VIEWPORT['width'] * 0.5, VIEWPORT['height'] * 0.5)
        self.fim_fala = 0
        self.avisos = None

    async def dormir(self, s):
        await asyncio.sleep(min(s, 0.15) if self.rapido else s)

    async def alvo(self, seletor, timeout=20000):
        loc = self.page.locator(seletor).first
        await loc.wait_for(state='visible', timeout=timeout)
        return loc

    async def mostrar(self, loc):
        """Rola com suavidade ate' o elemento fora da tela; dentro de uma lista que rola, so' o minimo."""
        visivel = await loc.evaluate('''e => { const r = e.getBoundingClientRect();
            if (r.top < 70 || r.bottom > innerHeight - 20) return false;
            const t = document.elementFromPoint(r.left + Math.min(r.width / 2, 60), r.top + r.height / 2);
            return !t || e === t || e.contains(t) || t.contains(e); }''')
        if not visivel:
            await loc.evaluate("e => e.scrollIntoView({behavior: 'smooth', block: 'center', inline: 'nearest'})")
            await self.dormir(0.9)
            return
        cortado = await loc.evaluate('''e => { for (let a = e.parentElement; a && a !== document.body; a = a.parentElement) {
                const s = getComputedStyle(a);
                if (!/(auto|scroll)/.test(s.overflowY) || a.scrollHeight <= a.clientHeight) continue;
                const r = e.getBoundingClientRect(), q = a.getBoundingClientRect();
                return r.top < q.top + 2 || r.bottom > q.bottom - 2; }
            return false; }''')
        if cortado:
            await loc.evaluate("e => e.scrollIntoView({behavior: 'smooth', block: 'nearest', inline: 'nearest'})")
            await self.dormir(0.7)

    async def ponto(self, loc):
        caixa = await loc.bounding_box()
        return (caixa['x'] + min(caixa['width'] / 2, 60), caixa['y'] + caixa['height'] / 2)

    async def mover_para(self, destino, duracao=None):
        x0, y0 = self.pos
        distancia = ((destino[0] - x0) ** 2 + (destino[1] - y0) ** 2) ** 0.5
        if duracao is None:
            duracao = 0.05 if self.rapido else min(1.0, max(0.4, distancia / 1100))
        passos = max(2, int(duracao * 60))
        for i in range(1, passos + 1):
            t = i / passos
            t = 3 * t * t - 2 * t * t * t  # acelera e freia
            await self.page.mouse.move(x0 + (destino[0] - x0) * t, y0 + (destino[1] - y0) * t)
            await asyncio.sleep(duracao / passos)
        self.pos = destino

    async def mover(self, loc):
        await self.mover_para(await self.ponto(loc))

    async def destacar(self, loc):
        await loc.evaluate('e => window.__tut && window.__tut.destacar(e)')

    async def limpar(self):
        try:
            await self.page.evaluate('window.__tut && window.__tut.limpar()')
        except Exception:
            pass

    async def apontar(self, seletor, destacar=True):
        loc = await self.alvo(seletor)
        await self.mostrar(loc)
        if destacar:
            await self.destacar(loc)
        await self.mover(loc)
        return loc

    async def desobstruir(self, loc, cobertura):
        """Um aviso flutuante (toast) por cima do alvo: espera sumir; se nao some em 8 s, tira da tela."""
        if not cobertura:
            return
        for _ in range(40):
            coberto = await loc.evaluate("""(e, sel) => { const r = e.getBoundingClientRect();
                const t = document.elementFromPoint(r.x + Math.min(r.width / 2, 60), r.y + r.height / 2);
                return !!(t && !e.contains(t) && t.closest(sel)); }""", cobertura)
            if not coberto:
                return
            await asyncio.sleep(0.2)
        await self.page.evaluate("sel => document.querySelectorAll(sel).forEach(a => a.remove())", cobertura)

    async def clicar(self, seletor):
        loc = await self.alvo(seletor)
        await self.desobstruir(loc, self.avisos)
        await self.apontar(seletor)
        await self.dormir(0.35)
        await self.page.mouse.down()
        await asyncio.sleep(0.08)
        await self.page.mouse.up()
        await self.limpar()
        try:
            await self.page.wait_for_load_state('load', timeout=15000)
        except Exception:
            pass
        await self.dormir(0.5)

    async def arrastar(self, de, para, vaga=None):
        """Arrastar e soltar (HTML5 ou mouse). O cursor.js desenha o cursor e a copia do elemento seguindo o
        mouse (o navegador sem janela nao desenha). Com "vaga" (seletor dos itens ja' soltos dentro do
        destino), solta logo depois do ultimo item; sem ela, no meio do destino."""
        await self.apontar(de, destacar=False)
        await self.dormir(0.45)
        await self.page.mouse.down()
        await asyncio.sleep(0.12)
        await self.mover_para((self.pos[0] + 10, self.pos[1] + 8), 0.15)  # o arraste so' comeca depois de uns pixels
        await self.alvo(para)
        destino = await self.page.evaluate('''([sel, vaga]) => {
            const a = document.querySelector(sel); const r = a.getBoundingClientRect();
            const itens = vaga ? [...a.querySelectorAll(vaga)] : [];
            if (!vaga) return [r.left + r.width / 2, r.top + Math.min(r.height / 2, 120)];
            if (!itens.length) return [r.left + 140, r.top + 60];
            const u = itens[itens.length - 1].getBoundingClientRect();
            if (u.right + 230 < r.right) return [u.right + 120, u.top + u.height / 2];
            return [r.left + 140, u.bottom + 50]; }''', [para, vaga])
        await self.mover_para(tuple(destino), 0.1 if self.rapido else 1.25)
        await asyncio.sleep(0.05 if self.rapido else 0.4)  # um instante em cima do destino (realce de "soltar aqui")
        await self.page.mouse.up()
        await self.dormir(0.7)

    async def executar(self, acao):
        tipo, valor = next(iter(acao.items()))  # cada acao e' {tipo: valor}
        if tipo == 'ir':
            await self.page.goto(valor if valor.startswith('http') else self.base + valor, wait_until='load')
            await self.dormir(1.0)
        elif tipo == 'clicar':
            await self.clicar(valor)
        elif tipo == 'digitar':
            loc = await self.apontar(valor['alvo'])
            await self.dormir(0.25)
            await self.page.mouse.click(*self.pos)
            if valor.get('limpar', True):
                await loc.fill('')
            await loc.press_sequentially(str(valor['texto']), delay=8 if self.rapido else valor.get('atraso', 55))
            await self.dormir(0.3)
            await self.limpar()
        elif tipo == 'selecionar':
            loc = await self.apontar(valor['alvo'])
            await self.dormir(0.4)
            await loc.select_option(label=valor['opcao'])
            await self.dormir(0.5)
            await self.limpar()
        elif tipo == 'marcar':
            await self.clicar(valor)
        elif tipo == 'arrastar':
            await self.arrastar(valor['de'], valor['para'], valor.get('vaga'))
        elif tipo == 'apontar':
            alvo = valor if isinstance(valor, str) else valor['alvo']
            await self.apontar(alvo)
            await self.dormir(1.0 if isinstance(valor, str) else valor.get('segundos', 1.0))
            await self.limpar()
        elif tipo == 'destacar':
            alvo = valor if isinstance(valor, str) else valor['alvo']
            loc = await self.alvo(alvo)
            await self.mostrar(loc)
            await self.destacar(loc)
            await self.dormir(1.5 if isinstance(valor, str) else valor.get('segundos', 1.5))
            await self.limpar()
        elif tipo == 'rolar':
            if isinstance(valor, str):
                loc = await self.alvo(valor)
                await loc.evaluate("e => e.scrollIntoView({behavior: 'smooth', block: 'center'})")
            else:
                await self.page.evaluate(f"window.scrollBy({{top: {int(valor)}, behavior: 'smooth'}})")
            await self.dormir(1.0)
        elif tipo == 'esperar':
            alvo = valor if isinstance(valor, str) else valor['alvo']
            cortar = isinstance(valor, dict) and valor.get('cortar')
            if cortar and self.captura:
                await asyncio.sleep(max(0, self.fim_fala - time.time()))  # o corte nao come a fala da cena
                await asyncio.sleep(0.4)
                self.captura.cortar_inicio()
            limite = (valor.get('max', 240) if isinstance(valor, dict) else 30) * 1000
            await self.page.locator(alvo).first.wait_for(state='visible', timeout=limite)
            if cortar and self.captura:
                await asyncio.sleep(0.3)
                self.captura.cortar_fim()
            await self.dormir(0.5)
        elif tipo == 'tecla':
            await self.page.keyboard.press(valor)
            await self.dormir(0.6)
        elif tipo == 'pausa':
            await self.dormir(float(valor))
        elif tipo == 'js':
            await self.page.evaluate(valor)
        else:
            raise SystemExit(f'Acao desconhecida: {tipo} (veja references/roteiro.md da skill)')


# ------------------------------------------------------------------ saidas: legenda e descricao

def _tempo_srt(s):
    ms = int(round(s * 1000))
    return f'{ms // 3600000:02d}:{ms // 60000 % 60:02d}:{ms // 1000 % 60:02d},{ms % 1000:03d}'


def _pedacos(texto, limite=84):
    frases = re.split(r'(?<=[.!?;:,])\s+', texto.strip())
    pedacos, atual = [], ''
    for frase in frases:
        if atual and len(atual) + 1 + len(frase) > limite:
            pedacos.append(atual)
            atual = frase
        else:
            atual = f'{atual} {frase}'.strip()
    if atual:
        pedacos.append(atual)
    return pedacos


def escrever_legenda(falas, destino):
    linhas, n = [], 0
    for inicio, duracao, texto in falas:
        pedacos = _pedacos(texto)
        total = sum(len(p) for p in pedacos)
        t = inicio
        for p in pedacos:
            d = duracao * len(p) / total
            n += 1
            linhas += [str(n), f'{_tempo_srt(t)} --> {_tempo_srt(t + d)}', p, '']
            t += d
    with open(destino, 'w', encoding='utf-8') as f:
        f.write('\n'.join(linhas))


def _mmss(s):
    s = int(s)
    return f'{s // 60}:{s % 60:02d}'


def escrever_descricao(roteiro, capitulos, destino):
    texto = [roteiro.get('titulo', ''), '', str(roteiro.get('descricao', '')).strip(), '']
    if len(capitulos) >= 3:
        texto.append('Capítulos:')
        texto += [f'{_mmss(t)} {nome}' for t, nome in capitulos]
    with open(destino, 'w', encoding='utf-8') as f:
        f.write('\n'.join(texto).strip() + '\n')


# ------------------------------------------------------------------ gravacao

class Projeto:
    def __init__(self, caminho_roteiro, pasta=None, saida=None):
        with open(caminho_roteiro, encoding='utf-8') as f:
            self.roteiro = yaml_load(f)
        aqui = os.path.dirname(os.path.abspath(caminho_roteiro))
        self.pasta = os.path.abspath(pasta) if pasta else (os.path.dirname(aqui) if os.path.basename(aqui) == 'roteiros' else aqui)
        self.trabalho = os.path.join(self.pasta, 'trabalho')
        self.saida = os.path.abspath(saida) if saida else os.path.join(self.pasta, 'saida')
        self.nome = os.path.splitext(os.path.basename(caminho_roteiro))[0]
        self.base = str(self.roteiro.get('base', '')).rstrip('/')

    def caminho(self, p):
        """Caminho do roteiro: absoluto, ou relativo a' pasta do projeto."""
        return p if os.path.isabs(p) else os.path.join(self.pasta, p)


def yaml_load(f):
    import yaml
    try:
        return yaml.safe_load(f)
    except yaml.YAMLError as e:
        marca = getattr(e, 'problem_mark', None)
        onde = f' (linha {marca.line + 1}, coluna {marca.column + 1})' if marca else ''
        raise SystemExit(f'Roteiro com YAML invalido{onde}: {getattr(e, "problem", e)}. '
                         'Dentro de { }, texto com ? : , # ou aspas vai entre aspas.')


def _cartao(projeto, dados):
    r = projeto.roteiro
    with open(os.path.join(AQUI, 'cartao.html'), encoding='utf-8') as f:
        modelo = f.read()
    cores = r.get('cores') or {}
    logo = ''
    if r.get('logo'):
        caminho = projeto.caminho(r['logo'])
        tipo = 'svg+xml' if caminho.lower().endswith('.svg') else ('jpeg' if caminho.lower().endswith(('.jpg', '.jpeg')) else 'png')
        with open(caminho, 'rb') as f:
            logo = f'<div class="logo"><img src="data:image/{tipo};base64,{base64.b64encode(f.read()).decode()}" alt=""></div>'
    valores = {'selo': dados.get('selo', r.get('marca', '')), 'titulo': dados.get('titulo', ''),
               'subtitulo': dados.get('subtitulo', ''), 'marca': r.get('marca', '')}
    for chave, valor in valores.items():
        modelo = modelo.replace('{{' + chave + '}}', html.escape(str(valor)))
    for chave, padrao in (('fundo', '#0b1220'), ('destaque1', '#1f6feb'), ('destaque2', '#12b886')):
        modelo = modelo.replace('{{' + chave + '}}', re.sub(r'[^#a-zA-Z0-9(),.% ]', '', str(cores.get(chave, padrao))))
    return modelo.replace('{{logo}}', logo)


async def _abrir(p, projeto):
    r = projeto.roteiro
    navegador = None
    for canal in _canais(r.get('navegador')):
        try:
            args = {'headless': True, 'args': ['--lang=pt-BR']}
            navegador = await (p.chromium.launch(channel=canal, **args) if canal else p.chromium.launch(**args))
            break
        except Exception:
            continue
    if not navegador:
        raise SystemExit('Nenhum navegador: instale o Edge/Chrome ou rode python -m playwright install chromium.')
    contexto = await navegador.new_context(viewport=VIEWPORT, device_scale_factor=ESCALA, locale='pt-BR',
                                           timezone_id=r.get('fuso', 'America/Sao_Paulo'))
    login = r.get('login')
    if login:
        # login pela API do proprio site (ambiente de teste), com o JSON de um arquivo local: a senha nao
        # aparece no video nem no roteiro
        with open(projeto.caminho(login['credenciais']), encoding='utf-8') as f:
            corpo = json.load(f)
        resp = await contexto.request.fetch(projeto.base + login.get('caminho', '/api/auth/login'),
                                            method=login.get('metodo', 'POST'), data=corpo)
        if resp.status >= 400:
            raise SystemExit(f'O login pela API falhou ({resp.status}).')
    with open(os.path.join(AQUI, 'cursor.js'), encoding='utf-8') as f:
        await contexto.add_init_script(f.read())
    if r.get('css'):
        await contexto.add_init_script(
            "document.addEventListener('DOMContentLoaded', () => { const s = document.createElement('style');"
            f" s.textContent = {json.dumps(r['css'])}; document.head.appendChild(s); }});")
    return navegador, contexto


async def explorar(projeto, caminho):
    from playwright.async_api import async_playwright
    async with async_playwright() as p:
        navegador, contexto = await _abrir(p, projeto)
        page = await contexto.new_page()
        await page.goto(caminho if caminho.startswith('http') else projeto.base + caminho, wait_until='load')
        await page.wait_for_timeout(1500)
        os.makedirs(projeto.trabalho, exist_ok=True)
        foto = os.path.join(projeto.trabalho, 'explorar.png')
        await page.screenshot(path=foto)
        campos = await page.evaluate('''() => [...document.querySelectorAll('a, button, input, select, textarea, [draggable=true], [role=tab]')]
            .filter(e => e.offsetParent !== null)
            .map(e => `${e.tagName.toLowerCase()}${e.id ? '#' + e.id : ''}${e.name ? '[name=' + e.name + ']' : ''}` +
                      `${e.getAttribute('aria-label') ? '[aria-label="' + e.getAttribute('aria-label') + '"]' : ''}` +
                      Object.keys(e.dataset).slice(0, 2).map(k => `[data-${k.replace(/[A-Z]/g, m => '-' + m.toLowerCase())}="${e.dataset[k]}"]`).join('') +
                      `${e.className && typeof e.className === 'string' ? '.' + e.className.trim().split(/\\s+/).slice(0, 2).join('.') : ''}` +
                      `  ${(e.innerText || e.value || e.placeholder || e.title || '').trim().replace(/\\s+/g, ' ').slice(0, 50)}`)''')
        print(page.url)
        print(f'foto: {foto}')
        print('\n'.join(campos))
        await navegador.close()


async def gravar(projeto, rapido=False, sem_audio=False, ate=None, so_narracao=False):
    from playwright.async_api import async_playwright
    r = projeto.roteiro
    cenas = r['cenas'][:ate] if ate else r['cenas']
    pasta_audio = os.path.join(projeto.trabalho, 'audio')

    print(f'Narracao ({len(cenas)} cenas)...', flush=True)
    audios = [gerar_fala(c.get('pronuncia') or c['fala'], pasta_audio, sem_audio or rapido) if c.get('fala') else (None, 0)
              for c in cenas]
    com = sum(1 for a, _ in audios if a)
    print(f"  duracao das falas: {_mmss(sum(d for _, d in audios))} ({com} de {sum(1 for c in cenas if c.get('fala'))} com audio)", flush=True)
    if so_narracao:
        for i, (a, d) in enumerate(audios, 1):
            print(f'  cena {i}: {d:5.1f} s{"" if a else " (sem audio: duracao estimada)"}', flush=True)
        if com < sum(1 for c in cenas if c.get('fala')) and not ler_config().get('OPENROUTER_API_KEY'):
            print(f'Sem a chave do OpenRouter ({CONFIG}): as falas sem audio ficaram so na estimativa.')
        return
    if not rapido and not sem_audio and com < sum(1 for c in cenas if c.get('fala')):
        raise SystemExit(f'Falta a chave do OpenRouter para a narracao ({CONFIG}). Use --sem-audio para gravar mudo.')

    async with async_playwright() as p:
        navegador, contexto = await _abrir(p, projeto)
        page = await contexto.new_page()
        pasta_fotos = os.path.join(projeto.trabalho, 'rapido', projeto.nome)
        captura = None
        if rapido:
            shutil.rmtree(pasta_fotos, ignore_errors=True)
            os.makedirs(pasta_fotos)
        else:
            cdp = await contexto.new_cdp_session(page)
            captura = Captura(cdp, os.path.join(projeto.trabalho, 'quadros', projeto.nome))
        diretor = Diretor(page, projeto.base, captura, rapido)
        diretor.avisos = r.get('avisos')  # seletor dos avisos flutuantes (toasts) que podem cobrir um botao

        primeira = cenas[0]
        if primeira.get('cartao'):
            await page.set_content(_cartao(projeto, primeira['cartao']), wait_until='load')
        elif r.get('inicio'):
            await page.goto(projeto.base + r['inicio'], wait_until='load')
        if captura:
            await captura.iniciar()
            await asyncio.sleep(0.3)

        falas, capitulos = [], []
        for i, cena in enumerate(cenas):
            if cena.get('cartao') and i > 0:
                await page.set_content(_cartao(projeto, cena['cartao']), wait_until='load')
            audio, duracao = audios[i]
            inicio = captura.no_video() if captura else 0
            if cena.get('fala'):
                falas.append((inicio, duracao, cena['fala'], audio))
            if cena.get('capitulo'):
                capitulos.append((inicio, cena['capitulo']))
            diretor.fim_fala = time.time() + duracao
            print(f"  cena {i + 1}: {cena.get('fala', '')[:70]}", flush=True)
            acoes = cena.get('acoes') or []
            if acoes:
                await diretor.dormir(cena.get('atraso', 0.6))
            acao = None
            try:
                for acao in acoes:
                    await diretor.executar(acao)
            except SystemExit:
                raise
            except Exception as e:
                os.makedirs(projeto.trabalho, exist_ok=True)
                foto = os.path.join(projeto.trabalho, f'erro-cena-{i + 1}.png')
                await page.screenshot(path=foto)
                raise SystemExit(f'Cena {i + 1} falhou em {acao}: {str(e).splitlines()[0]} (foto: {foto})')
            if rapido:
                await page.screenshot(path=os.path.join(pasta_fotos, f'{i + 1:02d}.png'))
            else:
                await asyncio.sleep(max(0, diretor.fim_fala - time.time()) + cena.get('depois', 0.5))
        if captura:
            await asyncio.sleep(0.5)
            await captura.parar()
        await navegador.close()

    if rapido:
        print(f'Fotos em {pasta_fotos}')
        return

    os.makedirs(projeto.saida, exist_ok=True)
    mudo = os.path.join(projeto.trabalho, f'{projeto.nome}-mudo.mp4')
    print('Montando o video...', flush=True)
    duracao_video = captura.montar(mudo)
    final = os.path.join(projeto.saida, f'{projeto.nome}.mp4')
    com_audio = [(t, a) for t, _, _, a in falas if a]
    if com_audio:
        comando = ['ffmpeg', '-y', '-loglevel', 'error', '-i', mudo]
        filtros = []
        for j, (t, a) in enumerate(com_audio, 1):
            comando += ['-i', a]
            filtros.append(f'[{j}:a]aresample=48000,adelay={int(t * 1000)}:all=1[a{j}]')
        entradas = ''.join(f'[a{j}]' for j in range(1, len(com_audio) + 1))
        filtros.append(f'{entradas}amix=inputs={len(com_audio)}:normalize=0:dropout_transition=0,'
                       f'apad,atrim=0:{duracao_video:.3f},loudnorm=I=-16:TP=-1.5:LRA=11[audio]')
        comando += ['-filter_complex', ';'.join(filtros), '-map', '0:v', '-map', '[audio]', '-c:v', 'copy',
                    '-c:a', 'aac', '-b:a', '160k', '-ar', '48000', '-movflags', '+faststart', final]
        subprocess.run(comando, check=True)
    else:
        subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-i', mudo, '-c', 'copy', '-movflags', '+faststart',
                        final], check=True)
    os.remove(mudo)
    escrever_legenda([(t, d, texto) for t, d, texto, _ in falas], os.path.join(projeto.saida, f'{projeto.nome}.srt'))
    escrever_descricao(r, capitulos, os.path.join(projeto.saida, f'{projeto.nome}.txt'))
    shutil.rmtree(captura.pasta, ignore_errors=True)
    # a sincronia: a trilha de video e a de audio com a mesma duracao
    trilhas = subprocess.run(['ffprobe', '-v', 'error', '-show_entries', 'stream=codec_type,duration', '-of', 'csv=p=0', final],
                             capture_output=True, text=True, check=True).stdout.split()
    duracoes = {t.split(',')[0]: float(t.split(',')[1]) for t in trilhas if ',' in t}
    if 'audio' in duracoes:
        dif = abs(duracoes['video'] - duracoes['audio'])
        print(f"sincronia: video {duracoes['video']:.1f} s, audio {duracoes['audio']:.1f} s"
              f"{' (ok)' if dif <= 0.5 else ' - ATENCAO: a narracao sai fora de sincronia'}")
    print(f'Pronto: {final} ({_mmss(duracao_video)}){"" if com_audio else " SEM NARRACAO"}')
    if capitulos:
        print('capitulos: ' + ', '.join(f'{_mmss(t)} {n}' for t, n in capitulos))


def principal():
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    ap = argparse.ArgumentParser(description='Video narrado de um site a partir de um roteiro YAML.')
    ap.add_argument('roteiro', nargs='?')
    ap.add_argument('--conferir', action='store_true', help='confere ambiente e chave (cria o arquivo da chave se faltar)')
    ap.add_argument('--testar-chave', action='store_true', help='com --conferir: pergunta ao OpenRouter se a chave vale')
    ap.add_argument('--instalar', action='store_true', help='instala o que falta (pip, ffmpeg pelo winget, navegador) e confere')
    ap.add_argument('--explorar', metavar='CAMINHO', help='foto de uma pagina e a lista do que da para clicar')
    ap.add_argument('--rapido', action='store_true', help='so uma foto por cena, sem video e sem narracao')
    ap.add_argument('--sem-audio', action='store_true', help='video sem narracao (duracao estimada)')
    ap.add_argument('--so-narracao', action='store_true', help='so gera os mp3 das falas e mostra a duracao de cada uma')
    ap.add_argument('--ate', type=int, help='so as N primeiras cenas')
    ap.add_argument('--pasta', help='pasta do projeto do video (trabalho/ e saida/)')
    ap.add_argument('--saida', help='pasta do video pronto (padrao: <pasta>/saida)')
    a = ap.parse_args()
    _achar_ffmpeg_winget()
    if a.instalar:
        sys.exit(instalar())
    if a.conferir:
        sys.exit(conferir(a.testar_chave))
    if not a.roteiro:
        ap.print_help()
        sys.exit(1)
    projeto = Projeto(a.roteiro, a.pasta, a.saida)
    if a.explorar:
        asyncio.run(explorar(projeto, a.explorar))
    else:
        asyncio.run(gravar(projeto, a.rapido, a.sem_audio, a.ate, a.so_narracao))


if __name__ == '__main__':
    principal()

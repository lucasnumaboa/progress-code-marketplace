---
name: video-narrado
description: >-
  Grava um vídeo narrado (MP4 1080p com voz em português, legenda .srt e capítulos) de um site ou sistema web
  mexendo sozinho: o navegador clica, digita e arrasta seguindo um roteiro, uma voz de IA narra e o ffmpeg monta.
  Use sempre que o usuário pedir um vídeo de demonstração, tutorial, vídeo de novidades ou de entrega para o
  cliente, "gravar a tela do sistema com áudio", "um vídeo mostrando as telas", ou quiser transformar uma
  mensagem/lista de novidades num vídeo, mesmo sem citar a skill. Não serve para editar um vídeo já gravado nem
  para gravar a tela do próprio usuário ao vivo.
provider-env: OPENROUTER_API_KEY=openrouter
---

# Vídeo narrado de um site

O resultado é um MP4 1920x1080 com:
- o cursor desenhado, a onda no clique e o destaque laranja no que importa;
- os cartões de título;
- a narração e a legenda;
- uma descrição com os capítulos.

Tudo sai de um roteiro YAML. O gravador fica em `scripts/gravar.py`, nesta pasta da skill. Chame-o sempre com `python -I` e com o caminho completo do script. Se `python` não existir no PATH, use `py -3`, que é o que o instalador da skill usa nesse caso.

No Windows pelo Git Bash, um argumento começado por `/` (ex.: `--explorar "/#/painel"`) é trocado por um caminho de disco:
- escreva o caminho do script como `C:/Users/...`;
- prefixe o comando com `MSYS_NO_PATHCONV=1`;
- ou passe o endereço completo (`http://localhost:8320/#/painel`).

## 1. Primeiro: o ambiente e a chave

```bash
python -I "<pasta da skill>/scripts/gravar.py" --conferir
```

- **Sem Python** (`python` e `py` não existem): instale com `winget install -e --id Python.Python.3.12` e chame o Python pelo caminho completo (`%LOCALAPPDATA%\Programs\Python\Python312\python.exe`), porque o PATH novo só vale em janela nova.
- **Código 1 (falta ferramenta):** rode `python -I "<pasta da skill>/scripts/gravar.py" --instalar`. Ele instala o que falta: as bibliotecas do Python pelo pip, o ffmpeg pelo winget e, sem Edge nem Chrome, o navegador do Playwright. No fim confere de novo. Se ainda faltar algo, diga ao usuário o que é.
- **No Progress Code a chave vem do provedor OpenRouter do app:** a variável `OPENROUTER_API_KEY` já chega aos comandos que chamam a pasta desta skill, e o valor nunca aparece nas saídas. Não peça a chave nem crie o arquivo dela. Se o app não tiver o OpenRouter, peça ao usuário para cadastrá-lo em Configurações → Provedores.
- **Código 2 (falta a chave do OpenRouter), fora do Progress Code:** o script cria o arquivo `~/.claude/video-narrado/config.env`, com `OPENROUTER_API_KEY=` em branco.
  - Peça ao usuário para abrir o arquivo, colar a chave depois do `=` e salvar.
  - A chave se cria em https://openrouter.ai/keys. Os modelos de voz são pagos por uso, centavos por vídeo.
  - Dê o caminho completo do arquivo e espere ele avisar que preencheu. Depois rode `--conferir --testar-chave` para confirmar que o OpenRouter aceita a chave.
- **Código 0:** pode seguir.

Por que o arquivo e não o chat:
- a chave colada no chat fica no histórico da conversa, e o arquivo fica só na máquina;
- não peça a chave no chat e não abra o arquivo com `cat`, `type` ou Read: o valor iria para o histórico;
- o script lê o arquivo sozinho e nunca imprime a chave.

Se o usuário colar a chave no chat mesmo assim, grave-a no arquivo e não repita o valor na resposta.

Enquanto a chave não vem, dá para adiantar o roteiro e a passada rápida (passos 2 a 5), que não usam a voz.

## 2. Entender o vídeo

Antes de escrever qualquer cena, saiba:
- **Para quem é** (cliente, equipe interna, tutorial) e **o que precisa ficar claro**.
  - Se o usuário já tem uma mensagem ou lista de novidades, cada tópico vira um capítulo, na mesma ordem.
- **Quais telas e quais ações** mostram cada ponto. Leia o código do front, se tiver: é a melhor fonte de seletores estáveis e do que cada botão faz.
- **Duração.** De 2 a 5 min funciona bem. A fala sai a cerca de 2,6 palavras por segundo.

## 3. O ambiente que será gravado

O gravador clica de verdade: grava, executa, cria registro. E o vídeo vai para terceiros. Por isso:
- **Ambiente:** grave num ambiente de demonstração ou de teste, nunca em produção nem com dados reais de clientes, salvo pedido explícito do usuário. Mostre "Demonstração" ou "Teste" na tela, se o sistema tiver um selo de ambiente.
- **Senhas:** nunca digite senha real na tela.
  - Use o `login` do roteiro (rota de API + arquivo de credenciais de teste em `trabalho/`) ou um ambiente sem login.
  - Apague o arquivo de credenciais no fim.
- **Serviços externos:** se o sistema depende de um serviço que não existe no notebook (ERP, API de terceiros), suba um servidor de demonstração com uma imitação desse serviço. Assim a tela mostra o fluxo real andando.
  - Exemplo: um servidor de demonstração que copia o banco de desenvolvimento para um banco de teste a cada subida e responde como o ERP ou a API externa.
- **O que aparece na tela:** antes da gravação final, procure:
  - avisos técnicos ("X desligado", variáveis de ambiente);
  - e-mails e nomes reais;
  - dados de teste esquisitos;
  - textos trocados por interceptadores (ex.: um login "contabil" virando "contábil").

  Ajuste o ambiente, não o vídeo.

## 4. Achar os seletores

```bash
python -I "<skill>/scripts/gravar.py" <roteiro.yaml> --explorar /caminho/da/pagina
```

Tira a foto da página (`trabalho/explorar.png`) e lista links, botões, campos e itens arrastáveis com id, aria-label e classe. Abra a foto para ver a tela (ViewImage no Progress Code, Read no Claude Code).

## 5. O roteiro e a passada rápida

O formato completo, a lista de ações e as dicas de narração estão em `references/roteiro.md`: leia antes de escrever. Há um modelo em `assets/roteiro-modelo.yaml`.

```bash
python -I "<skill>/scripts/gravar.py" <roteiro.yaml> --rapido
```

A passada rápida roda todas as cenas sem esperar a fala e tira uma foto de cada uma em `trabalho/rapido/<nome>/`.
- Olhe as fotos das cenas principais.
- Se uma cena falhar, o erro diz a ação, e `trabalho/erro-cena-N.png` mostra a tela naquele momento.
- A passada rápida também cria dados (registros, execuções). Antes da gravação final, volte o ambiente ao estado inicial.

## 6. Narração e gravação

```bash
python -I "<skill>/scripts/gravar.py" <roteiro.yaml> --so-narracao   # gera os mp3 e mostra a duração de cada fala
python -I "<skill>/scripts/gravar.py" <roteiro.yaml>                 # o vídeo completo
```

- Cada fala é guardada em `trabalho/audio`: regravar não paga a voz de novo, só as falas alteradas.
- A gravação completa leva o tempo do vídeo, mais a montagem. Rode com timeout folgado (10 min).
- No fim, o script imprime a **sincronia** (duração do vídeo × áudio) e os capítulos. Se aparecer "ATENCAO", a narração escorregou: não entregue.

## 7. Conferir antes de entregar

Entregar sem olhar já custou uma volta: o usuário achou o trecho do arrastar "ruim" porque o cursor ficava parado. Confira:
- **Quadros:** tire quadros nos capítulos e nos trechos com movimento (arrastar, digitar), numa folha de miniaturas:

  ```bash
  ffmpeg -ss <s> -t <dur> -i saida/<nome>.mp4 -vf "fps=2,scale=640:-1,tile=3x6" -frames:v 1 trabalho/folha.jpg
  ```

  Abra a imagem (ViewImage no Progress Code, Read no Claude Code).
- **Legenda × imagem:** compare o `.srt` com a imagem no mesmo segundo. A fala tem que bater com a tela.
- **Volume:** `ffmpeg -i saida/<nome>.mp4 -af volumedetect -vn -f null -` dá a média perto de −18 dB e o pico abaixo de −1 dB.
- **Ouvido:** você não ouve o áudio. Diga ao usuário para conferir a pronúncia de siglas e nomes.

## 8. Entregar e limpar

- Entregue o MP4: no Progress Code, dê o caminho completo dele; no Claude Code, mande com SendUserFile (`display: render`). Cite também o `.srt` (legenda) e o `.txt` (descrição com capítulos) em `saida/`.
- Pare os servidores de demonstração. Um agendamento ou executor ligado continua rodando sozinho.
- Apague `trabalho/login.json` (ou o arquivo de credenciais) e `trabalho/rapido`. Deixe `trabalho/audio` para regravar barato.
- Não commite o vídeo nem `trabalho/`: ponha os dois no `.gitignore` do projeto.

## O que o gravador já resolve (não refaça)

- **Cursor e arraste:** o navegador sem janela não desenha cursor nem a cópia do item arrastado. O `scripts/cursor.js` desenha os dois e o cursor segue o arraste. Na ação `arrastar`, use `vaga` para a tela cair na próxima posição da lista.
- **Rolagem:** um elemento cortado dentro de uma lista que rola faz a lista rolar só o mínimo, sem pulos.
- **Sincronia:** a montagem é quadro a quadro, a 30 fps (o concat de imagens do ffmpeg esticava o vídeo).
- **Esperas:** use `esperar` com `cortar: true` para tirar uma espera longa do vídeo.
- **Avisos flutuantes:** com `avisos:` no roteiro, um toast por cima do botão é esperado ou retirado antes do clique.

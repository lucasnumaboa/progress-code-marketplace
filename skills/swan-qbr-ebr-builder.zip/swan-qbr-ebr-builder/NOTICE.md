# Aviso de terceiros (NOTICE)

Esta skill é uma cópia adaptada de material de terceiros e é redistribuída sob a licença original. O texto do especialista ficou em inglês, como no original.

- **Origem:** https://github.com/swan-gtm/gtm-skills
- **Caminho no repositório:** `skills/rutger-katz/qbr-ebr-builder`
- **Commit:** `eb0026f469f90645e1a64168d08a3e0afb59ee12` (baixado em 2026-11-22)
- **Autor:** Rutger Katz (autor da skill); copyright do repositório: Swan
- **Licença:** MIT (texto completo em `LICENSE`, copiado de `LICENSE` do repositório)

## Arquivos incluídos

- `SKILL.md` (de `skills/rutger-katz/qbr-ebr-builder/SKILL.md`)
- `references/business-review-practices.md` (de `skills/rutger-katz/qbr-ebr-builder/references/business-review-practices.md`)
- `author.md` (de `skills/rutger-katz/author.md`, crédito do autor pedido pelo repositório)
- `LICENSE`

## Mudanças feitas

- Frontmatter: `name: qbr-ebr-builder` trocado por `name: swan-qbr-ebr-builder` (a descrição ficou igual).

## Crédito do autor (author.md)

O repositório pede que o crédito do autor acompanhe a skill. Conteúdo do `author.md` original:

```markdown
---
name: Rutger Katz
avatarUrl: "https://www.gtmskills.com/authors/rutger-katz.jpg"
title: "Founder @ Neon Triforce — AI-Ready Revenue Systems"
linkedinUrl: "https://www.linkedin.com/in/rutgerkatz"
companyDomain: neontriforce.com
---

Helps B2B scale-ups (€15–150M) build AI-ready revenue systems — diagnostics first, then the operating system: forecasting, pipeline architecture, handoffs, and the tooling to run it.
```

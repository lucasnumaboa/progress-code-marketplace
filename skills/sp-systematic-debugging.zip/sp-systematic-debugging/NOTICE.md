# Origem e licença

Esta skill é uma cópia, com as alterações listadas abaixo, de material de especialista com licença aberta.

- **Fonte:** https://github.com/obra/superpowers
- **Arquivos de origem:** `skills/systematic-debugging/SKILL.md`, `skills/systematic-debugging/condition-based-waiting-example.ts`, `skills/systematic-debugging/condition-based-waiting.md`, `skills/systematic-debugging/defense-in-depth.md`, `skills/systematic-debugging/find-polluter.sh`, `skills/systematic-debugging/root-cause-tracing.md`
- **Autor:** Jesse Vincent
- **Licença:** MIT (texto completo em `LICENSE`)
- **Commit:** `22f0b463e7a5e579904dd6211a520321035526f7` (baixado em 2026-11-22)

## Alterações feitas

- `name:` do frontmatter trocado de `systematic-debugging` para `sp-systematic-debugging`.
- Acrescentada no fim uma nota de uma linha que traduz as referências `superpowers:<nome>` para os ids `sp-<nome>` do marketplace.
- Fora isso, o texto do especialista está como no original (em inglês).

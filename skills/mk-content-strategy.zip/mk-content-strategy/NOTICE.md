# Origem

Skill de especialista empacotada para o marketplace do Progress Code (id `mk-content-strategy`).

- Repositório: https://github.com/coreyhaines31/marketingskills
- Caminho: `skills/content-strategy`
- Autor: Corey Haines
- Detentor do copyright no arquivo de licença: Corey Haines
- Licença: MIT (texto completo em `LICENSE`, copiado de `LICENSE` no repositório)
- Commit: `5b2b400eec1e7e1cec76245a715d0b0d4fd2a9c1` (baixado em 2026-11-22)

## Arquivos incluídos

- `SKILL.md` (de `skills/content-strategy/SKILL.md`)
- `references/content-distribution.md` (de `skills/content-strategy/references/content-distribution.md`)
- `references/headless-cms.md` (de `skills/content-strategy/references/headless-cms.md`)

## Mudanças feitas

1. Frontmatter: `name:` trocado de `content-strategy` para `mk-content-strategy` (a descrição foi mantida).

O texto do especialista foi mantido em inglês, sem tradução.

## Não incluído

- `evals/evals.json` (casos de teste do autor, sem uso em tempo de execução).

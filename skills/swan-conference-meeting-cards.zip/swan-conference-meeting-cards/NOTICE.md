# Origem

Skill de especialista empacotada para o marketplace do Progress Code (id `swan-conference-meeting-cards`).

- Repositório: https://github.com/swan-gtm/gtm-skills
- Caminho: `skills/jeremy-hurst/conference-meeting-cards`
- Autor: Jeremy Hurst / Swan (biblioteca Swan; autoria registrada em `author.md`, copiado do repositório)
- Detentor do copyright no arquivo de licença: Swan
- Licença: MIT (texto completo em `LICENSE`, copiado de `LICENSE` no repositório)
- Commit: `eb0026f469f90645e1a64168d08a3e0afb59ee12` (baixado em 2026-11-22)

## Arquivos incluídos

- `SKILL.md` (de `skills/jeremy-hurst/conference-meeting-cards/SKILL.md`)
- `references/day-card-template.md` (de `skills/jeremy-hurst/conference-meeting-cards/references/day-card-template.md`)
- `references/setup-customization-checklist.md` (de `skills/jeremy-hurst/conference-meeting-cards/references/setup-customization-checklist.md`)
- `author.md` (de `skills/jeremy-hurst/author.md`)

## Mudanças feitas

1. Frontmatter: `name:` trocado de `conference-meeting-cards` para `swan-conference-meeting-cards` (a descrição foi mantida).

O texto do especialista foi mantido em inglês, sem tradução.

A biblioteca swan-gtm/gtm-skills é MIT (LICENSE "Copyright (c) 2026 Swan"; CONTRIBUTING: "Contributions are MIT-licensed"). O crédito ao autor de cada skill é mantido pelo `author.md`.

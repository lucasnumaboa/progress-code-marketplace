# Origem

Skill de especialista empacotada para o marketplace do Progress Code (id `kwp-task-management`).

- Repositório: https://github.com/anthropics/knowledge-work-plugins
- Caminho: `productivity/skills/task-management`
- Autor: Anthropic
- Titular: Anthropic (o texto Apache-2.0 em `LICENSE` não traz linha de copyright preenchida)
- Licença: Apache-2.0 (texto completo em `LICENSE`, copiado de `productivity/LICENSE` no repositório)
- Commit: `0e0fcacddcc892eb92a1b7873ff9d68159c47571` (baixado em 2026-11-22)

## Arquivos incluídos

- `SKILL.md` (de `productivity/skills/task-management/SKILL.md`)

## Mudanças feitas

1. Frontmatter: `name:` trocado de `task-management` para `kwp-task-management` (a descrição foi mantida).
2. A seção "Dashboard Setup (First Run)" foi removida: ela copia um painel HTML do plugin do Cowork (`${CLAUDE_PLUGIN_ROOT}/skills/dashboard.html`) e manda rodar `/productivity:start`, que não existem aqui.

O texto do especialista foi mantido em inglês, sem tradução.
Conforme a Apache-2.0 (seção 4b), este aviso registra que os arquivos acima foram modificados.

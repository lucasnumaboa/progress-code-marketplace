---
name: downloads-uploads-em-massa
description: Baixa listas de URLs em paralelo controlado (com retomada e validação de hash) e envia arquivos em lote para SharePoint/OneDrive/Google Drive via API. Use quando o usuário pedir para "baixar essa lista de arquivos", "subir essas centenas de arquivos para o SharePoint/Drive", "o download parou no meio, como retomo".
argument-hint: [lista de URLs ou pasta de origem] [destino]
---

# Downloads e uploads em massa

## Passo 1 — Download em paralelo controlado
```python
import concurrent.futures
import requests
from pathlib import Path

def baixar(url, destino):
    if Path(destino).exists():
        return "ja_existe"
    try:
        with requests.get(url, stream=True, timeout=30) as resp:
            resp.raise_for_status()
            with open(destino, "wb") as f:
                for chunk in resp.iter_content(chunk_size=8192):
                    f.write(chunk)
        return "ok"
    except Exception as e:
        return f"erro: {e}"

with concurrent.futures.ThreadPoolExecutor(max_workers=5) as executor:
    resultados = list(executor.map(lambda item: baixar(*item), lista_url_destino))
```
`max_workers=5` é um ponto de partida conservador — paralelismo alto demais pode ser tratado como abuso pelo
servidor de origem (bloqueio de IP) ou saturar a rede local; ajuste com cautela.

## Passo 2 — Retomar downloads interrompidos
A checagem `Path(destino).exists()` acima já pula arquivos já baixados por completo — mas um download que parou
**no meio** deixa um arquivo parcial que parece existir. Para retomar de verdade (não rebaixar do zero):
```python
tamanho_parcial = Path(destino).stat().st_size if Path(destino).exists() else 0
headers = {"Range": f"bytes={tamanho_parcial}-"} if tamanho_parcial else {}
resp = requests.get(url, headers=headers, stream=True)
modo = "ab" if tamanho_parcial else "wb"
```
Isso só funciona se o servidor suportar `Range` (a maioria dos servidores de arquivo estático suporta; APIs
dinâmicas geralmente não) — confira o header de resposta `Accept-Ranges: bytes` antes de confiar nisso.

## Passo 3 — Validar hash depois de baixar
```python
import hashlib

def sha256_arquivo(caminho):
    h = hashlib.sha256()
    with open(caminho, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()
```
Se a origem fornecer um hash esperado (comum em portais de download de arquivos grandes), compare antes de
considerar o download íntegro — um download "concluído sem erro" ainda pode estar corrompido por queda de rede no
meio sem gerar exceção.

## Passo 4 — Upload em lote (SharePoint/OneDrive via Graph API)
```python
import requests

with open(caminho_local, "rb") as f:
    resp = requests.put(
        f"https://graph.microsoft.com/v1.0/sites/{site_id}/drive/root:/{pasta}/{nome_arquivo}:/content",
        headers={"Authorization": f"Bearer {token}"},
        data=f,
    )
```
Arquivos grandes (>4MB): a Graph API exige "upload session" em vez de `PUT` direto — crie a sessão
(`POST .../createUploadSession`) e envie em pedaços (chunks) conforme a resposta indicar.

## Regras
- Sempre trate erro por item individualmente (um arquivo falhar não deve travar o lote inteiro) e reporte no final
  quantos tiveram sucesso/falha e quais.
- Nunca sobrescreva arquivo de destino sem checar antes se já existe e é igual (mesmo hash) — evita retrabalho e
  reduz risco de corromper um arquivo já correto por uma reexecução acidental.
- Login/token para upload: nunca grave a senha em texto no script — use OAuth2 (ver skill `oauth2-login-servicos`).

## Arquivos desta skill
Nenhum script fixo — os trechos acima cobrem o fluxo completo; adapte às URLs/API de destino reais do usuário.

---
name: trello-notion-clickup
description: Cria quadros/cartões/páginas a partir de um plano e move cartões conforme o progresso, via API do Trello, Notion e ClickUp. Use quando o usuário pedir para "montar um quadro Trello a partir desse plano", "criar páginas no Notion para cada item", "mover esse card no ClickUp".
argument-hint: [Trello|Notion|ClickUp] [operação]
---

# Trello / Notion / ClickUp

## Trello (API key + token, autenticação simples via query string)
```python
import requests

params = {"key": api_key, "token": token}

# criar cartao
requests.post("https://api.trello.com/1/cards", params={
    **params, "idList": lista_id, "name": "Título do cartão", "desc": "Descrição.",
})

# mover cartao (mudar de lista = mudar de coluna/status no Trello)
requests.put(f"https://api.trello.com/1/cards/{card_id}", params={**params, "idList": nova_lista_id})

# listar cartoes de um quadro
requests.get(f"https://api.trello.com/1/boards/{board_id}/cards", params=params)
```

## Notion (token de integração interna, API baseada em blocos)
```python
headers = {"Authorization": f"Bearer {token}", "Notion-Version": "2022-06-28", "Content-Type": "application/json"}

# criar pagina num banco de dados (database) do Notion
requests.post("https://api.notion.com/v1/pages", headers=headers, json={
    "parent": {"database_id": database_id},
    "properties": {
        "Name": {"title": [{"text": {"content": "Título da página"}}]},
        "Status": {"select": {"name": "A fazer"}},
    },
})

# consultar banco de dados
requests.post(f"https://api.notion.com/v1/databases/{database_id}/query", headers=headers,
              json={"filter": {"property": "Status", "select": {"equals": "A fazer"}}})
```
**Atenção**: a integração interna precisa ser explicitamente **compartilhada** com a página/database no Notion
(botão "..." → Conectar a → nome da integração) — sem isso, a API retorna `404` mesmo com token válido, o que
confunde muita gente (parece "não encontrado" quando na verdade é falta de permissão).

## ClickUp (token de API pessoal ou de app)
```python
headers = {"Authorization": token}

# criar tarefa numa lista
requests.post(f"https://api.clickup.com/api/v2/list/{list_id}/task", headers=headers, json={
    "name": "Título da tarefa", "description": "Descrição.",
})

# mover tarefa para outro status
requests.put(f"https://api.clickup.com/api/v2/task/{task_id}", headers=headers, json={"status": "em andamento"})
```

## Gerar quadro/páginas a partir de um plano estruturado
Padrão comum aos três: ler uma lista de itens (de um plano, planilha ou JSON) e criar um cartão/página por item,
com tratamento de erro por item (não parar o lote inteiro se um item falhar) — mesmo princípio da skill
`mala-direta-documentos`, aplicado a cartões/páginas em vez de documentos.

## Regras
- Confirme o quadro/database/lista de destino certo com o usuário antes de criar em massa — IDs parecidos entre
  ambientes de teste e produção são um risco real.
- Nunca mova/apague cartões em massa sem confirmação — essas ferramentas não têm undo em lote fácil.
- Rate limit: todas as três limitam requisições por minuto — trate `429` com retry e backoff (mesmo padrão da
  skill `chamar-apis-http`).

## Arquivos desta skill
Nenhum script fixo — os trechos acima cobrem os casos mais comuns; adapte ao quadro/database real do usuário.

# Origem e licença

Esta skill é uma cópia, com as alterações listadas abaixo, de material de especialista com licença aberta.

- **Fonte:** https://github.com/getsentry/skills
- **Arquivos de origem:** `skills/iterate-pr/SKILL.md`, `skills/iterate-pr/scripts/fetch_pr_checks.py`, `skills/iterate-pr/scripts/fetch_pr_feedback.py`, `skills/iterate-pr/scripts/monitor_pr_checks.py`, `skills/iterate-pr/scripts/reply_to_thread.py`
- **Autor:** Sentry (Functional Software, Inc.)
- **Licença:** Apache-2.0 (texto completo em `LICENSE`)
- **Commit:** `a582c51ee29d0f35e6ac321340796f77d43da733` (baixado em 2026-11-22)

## Alterações feitas

- `name:` do frontmatter trocado de `iterate-pr` para `sen-iterate-pr`.
- Fora isso, o texto do especialista está como no original (em inglês).

## Arquivos da skill original que não vieram

- `SPEC.md` e `agents/openai.yaml` (especificação interna e metadado de outro produto).

---
name: consultar-dados-duckdb
description: Consulta arquivos CSV/Parquet de gigabytes diretamente com SQL usando DuckDB, sem carregar tudo na memória e sem instalar programa externo (motor embutido no pacote Python). Use quando o usuário pedir para "consultar esse CSV enorme", "rodar SQL num arquivo Parquet", ou quando o pandas ficar lento/travar por causa do tamanho do arquivo.
argument-hint: [arquivo(s) .csv/.parquet] [consulta SQL desejada]
---

# Consultar arquivos grandes com DuckDB

## Por que DuckDB em vez de pandas para arquivos grandes
Pandas carrega o arquivo inteiro na memória antes de processar. DuckDB lê só o que a consulta precisa (leitura em
streaming/colunar), então um CSV/Parquet de vários GB que travaria o pandas roda em segundos com SQL direto — e não
precisa instalar um servidor de banco separado, é só uma biblioteca Python com o motor embutido.

## Passo 1 — Instalar
```
pip install duckdb
```

## Passo 2 — Consultar CSV/Parquet direto, sem importar
```python
import duckdb

resultado = duckdb.sql("""
    SELECT regiao, SUM(valor) AS total
    FROM read_csv_auto('vendas_2026.csv')
    GROUP BY regiao
    ORDER BY total DESC
""").df()  # .df() converte para DataFrame do pandas so no resultado final (ja agregado, pequeno)
```
`read_csv_auto` detecta separador/encoding/tipos automaticamente na maioria dos casos — se detectar errado (comum
com CSV brasileiro com `;` e vírgula decimal), force explicitamente:
```python
duckdb.sql("SELECT * FROM read_csv('arquivo.csv', delim=';', decimal_separator=',', header=true)")
```

## Passo 3 — Vários arquivos de uma vez (glob)
```python
duckdb.sql("SELECT * FROM read_parquet('dados/*.parquet')")
duckdb.sql("SELECT * FROM read_csv_auto('vendas_*.csv', union_by_name=true)")
```
`union_by_name=true` é necessário se os arquivos tiverem colunas em ordens diferentes (comum em exportações
mensais feitas em momentos diferentes).

## Passo 4 — Exportar resultado
```python
duckdb.sql("COPY (SELECT * FROM read_csv_auto('vendas.csv') WHERE regiao = 'Sul') TO 'sul.parquet' (FORMAT PARQUET)")
```
Parquet é muito mais compacto e rápido de reler que CSV — prefira Parquet como formato intermediário quando o
resultado ainda vai ser reprocessado depois.

## Passo 5 — SQLite/Postgres como fonte
```python
duckdb.sql("ATTACH 'banco.sqlite' AS sqlite_db (TYPE sqlite)")
duckdb.sql("SELECT * FROM sqlite_db.tabela LIMIT 10")
```
Útil para cruzar um CSV grande com uma tabela de um banco menor sem escrever um ETL completo.

## Regras
- Antes de rodar uma consulta pesada, rode com `LIMIT 20` primeiro para conferir que as colunas/tipos saíram como
  esperado — DuckDB é rápido, mas isso não substitui checar o resultado antes de processar o arquivo inteiro.
- Se o arquivo tiver colunas com nomes repetidos ou inconsistentes entre múltiplos arquivos (glob), use
  `union_by_name=true` e trate como erro real (não ignore) qualquer coluna que sumiu ou virou `NULL` em massa —
  geralmente indica nome de coluna diferente entre arquivos.
- DuckDB não substitui um banco transacional para escrita concorrente — é uma ferramenta de consulta/análise, não
  para aplicações que gravam dados o tempo todo.

## Arquivos desta skill
Nenhum script fixo — as consultas acima são o padrão de uso; adapte ao arquivo e à pergunta reais do usuário.

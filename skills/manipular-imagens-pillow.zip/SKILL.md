---
name: manipular-imagens-pillow
description: Redimensiona, recorta, converte, comprime, monta colagens e adiciona texto/marca d'água em imagens usando Pillow (só biblioteca Python, sem instalar programa externo como ImageMagick). Use quando o usuário pedir para "redimensionar essa imagem", "converter para PNG/JPG", "gerar miniaturas em lote", "colocar marca d'água/texto na imagem", "montar uma colagem".
argument-hint: [operação] [arquivo(s) de imagem]
---

# Manipular imagens (Pillow)

## Passo 1 — Instalar
```
pip install Pillow
```
Isso cobre praticamente tudo abaixo sem precisar do ImageMagick (programa externo) — só considere ImageMagick se o
usuário precisar de algo muito específico que o Pillow não faz (ex.: certos efeitos de linha de comando em lote
muito grandes) e topar instalar.

## Passo 2 — Operações básicas
```python
from PIL import Image, ImageOps, ImageDraw, ImageFont

img = Image.open("entrada.jpg")

# redimensionar mantendo proporção
img.thumbnail((800, 800))  # altera in-place, cabe DENTRO de 800x800

# recortar
img_recortada = img.crop((left, top, right, bottom))

# converter formato (a extensao do save() decide o formato)
img.convert("RGB").save("saida.png")  # RGB obrigatorio antes de salvar JPG (nao aceita alpha/RGBA)

# comprimir JPG
img.save("saida.jpg", quality=80, optimize=True)
```

## Passo 3 — Miniaturas em lote
```python
import os
from PIL import Image

for nome in os.listdir("entrada"):
    with Image.open(os.path.join("entrada", nome)) as img:
        img.thumbnail((300, 300))
        img.save(os.path.join("miniaturas", nome))
```
Trate erro por arquivo individualmente (`try/except`) e reporte no final quais falharam — um arquivo corrompido não
deve interromper o lote inteiro.

## Passo 4 — Texto e marca d'água
```python
draw = ImageDraw.Draw(img, "RGBA")
fonte = ImageFont.truetype("arial.ttf", 40)  # caminho de fonte no Windows: C:\Windows\Fonts\arial.ttf
draw.text((20, 20), "CONFIDENCIAL", font=fonte, fill=(255, 0, 0, 160))
```
Para marca d'água semi-transparente sobre a imagem inteira, crie uma camada `RGBA` do mesmo tamanho, desenhe nela, e
componha com `Image.alpha_composite(base.convert("RGBA"), camada)`.

## Passo 5 — Colagem
```python
colagem = Image.new("RGB", (largura_total, altura_total), "white")
colagem.paste(img1, (0, 0))
colagem.paste(img2, (img1.width, 0))
colagem.save("colagem.png")
```
Calcule `largura_total`/`altura_total` a partir do tamanho real de cada imagem antes de colar — não assuma que
todas têm o mesmo tamanho.

## Regras
- Sempre confira a orientação EXIF antes de redimensionar fotos de celular: `ImageOps.exif_transpose(img)` corrige
  fotos que aparecem giradas.
- Nunca sobrescreva o arquivo original — grave em pasta/nome de saída diferente, a menos que o usuário peça
  explicitamente para substituir.
- Formatos com transparência (PNG/WebP) perdem o canal alpha se convertidos direto para JPG — avise o usuário antes
  se isso for relevante (ex.: logo com fundo transparente virando fundo preto sem querer).

## Arquivos desta skill
Nenhum script fixo — os trechos acima cobrem os casos mais comuns; adapte à operação pedida.

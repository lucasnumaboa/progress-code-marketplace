# Origem e mudanças

- **Repositório:** https://github.com/ericosiu/ai-marketing-skills
- **Caminho no repositório:** `video-clip-pipeline`
- **Autor:** Single Grain
- **Licença:** MIT (texto em `LICENSE`)
- **Commit usado:** `c715f900e3a7c1f4274976ca851849d9a7c3fe55`
- **Arquivos copiados:** `SKILL.md`

## Mudanças feitas

- no cabeçalho (frontmatter), `name:` passou de `video-clip-pipeline` para `es-video-clip-pipeline`; a descrição ficou igual
- removido o bloco "Preamble" (checagem de versão e telemetria do repositório)
- removida a seção "Prerequisites" (instalação de dependências e chave ANTHROPIC_API_KEY para os scripts próprios)
- removido o bloco "Run this skill on live data" (chamada comercial para o Single Brain Gateway e contato da agência Single Grain)
- nenhuma outra alteração no texto do especialista (mantido em inglês)

## Observações

- os scripts Python do autor (`longform_pipeline.py`, `scored_pipeline.py`, `clip_segmenter.py`, `clip_cutter.py`) NÃO foram incluídos: a segmentação depende de chave paga de API. A skill fica como referência de método (critérios de gancho, arco completo e corte limpo); o corte e a transcrição são feitos com outras skills

Empacotada para o marketplace do Progress Code em 2026-11-22.

---
name: graphql-grpc
description: Explica quando usar GraphQL ou gRPC em vez de REST, monta schemas básicos e gera código a partir deles (protoc para gRPC exige instalar o compilador separadamente — confirme antes). Use quando o usuário pedir para "essa API deveria ser GraphQL ou REST", "criar um schema GraphQL", "definir um contrato gRPC/protobuf", "por que usar gRPC aqui".
argument-hint: [GraphQL|gRPC] [domínio da API]
---

# GraphQL e gRPC

## Quando usar cada um em vez de REST
- **REST** (ver skill `apis-rest-bem-desenhadas`): padrão default, mais simples de cachear (HTTP cache nativo),
  mais fácil de debugar (URL + método já diz o que faz).
- **GraphQL**: cliente precisa buscar dados de várias entidades relacionadas numa única chamada, e o formato exato
  do que precisa varia por tela (evita over-fetching/under-fetching que REST sofre quando uma tela precisa de um
  subconjunto específico de campos de vários recursos). Custo: cache HTTP tradicional não funciona bem (tudo é
  `POST` num único endpoint), e uma consulta mal desenhada pelo cliente pode sobrecarregar o servidor (N+1 nos
  resolvers) sem limite óbvio.
- **gRPC**: comunicação serviço-a-serviço interna (não voltado a navegador/cliente público), com necessidade de
  performance alta (binário via Protocol Buffers, não JSON) e contrato fortemente tipado compartilhado entre
  linguagens diferentes. Não é a escolha natural para uma API pública consumida por navegador (suporte a gRPC-Web
  existe mas é limitado).

## GraphQL — schema básico (sem precisar instalar nada além da lib da linguagem)
```graphql
type Cliente {
  id: ID!
  nome: String!
  pedidos: [Pedido!]!
}

type Query {
  cliente(id: ID!): Cliente
  clientes(status: String): [Cliente!]!
}

type Mutation {
  criarCliente(nome: String!): Cliente!
}
```
Python: `pip install strawberry-graphql` ou `graphene`. Node: `npm install graphql apollo-server`. Nenhum dos dois
precisa de binário externo — é só biblioteca da linguagem.

## O problema do N+1 em resolvers GraphQL (a armadilha mais comum)
```python
# ERRADO: uma query para clientes + uma query POR CLIENTE para pedidos (N+1)
def resolver_pedidos(cliente):
    return db.query(f"SELECT * FROM pedidos WHERE cliente_id = {cliente.id}")

# CERTO: usar DataLoader para agrupar em uma unica query com IN (...)
```
Sem tratar isso, uma consulta que busca 100 clientes com seus pedidos dispara 101 consultas ao banco — use
`DataLoader` (Python: `aiodataloader`; Node: `dataloader`) para agrupar e cachear por requisição.

## gRPC — definir o contrato (.proto)
```protobuf
syntax = "proto3";

service ClienteService {
  rpc BuscarCliente (BuscarClienteRequest) returns (Cliente);
}

message BuscarClienteRequest { string id = 1; }
message Cliente { string id = 1; string nome = 2; }
```

## Gerar código a partir do .proto (precisa do compilador `protoc` — confirme antes de instalar)
`protoc` é um binário separado (não vem com pip/npm) — para Python:
```
pip install grpcio-tools   # este pacote inclui o protoc necessario, sem precisar instalar separadamente
python -m grpc_tools.protoc -I. --python_out=. --grpc_python_out=. cliente.proto
```
Boa notícia: para **Python especificamente**, `grpcio-tools` já traz o `protoc` embutido no próprio pacote pip —
não é necessário instalar o compilador do sistema à parte nesse caso. Para outras linguagens (Go, Java, C++), o
`protoc` do sistema geralmente é necessário separadamente — confirme com o usuário antes de propor essa instalação
adicional se o alvo não for Python.

## Regras
- Nunca proponha GraphQL só "porque é moderno" — REST resolve a maioria dos casos com menos complexidade
  operacional; GraphQL vale o custo quando o problema de over/under-fetching é real e recorrente.
- Sempre trate o problema de N+1 em resolvers GraphQL desde o design inicial — é o bug de performance mais comum e
  mais difícil de perceber em desenvolvimento (só aparece com volume real de dados).
- gRPC: nunca proponha para uma API pública consumida diretamente por navegador sem entender as limitações do
  gRPC-Web primeiro.

## Arquivos desta skill
Nenhum script fixo — os trechos acima cobrem os casos mais comuns; adapte ao domínio real da API do usuário.

# Origem e licença

Esta skill é uma cópia, com as alterações listadas abaixo, de material de especialista com licença aberta.

- **Fonte:** https://github.com/getsentry/skills
- **Arquivos de origem:** `skills/skill-writer/SKILL.md`, `skills/skill-writer/references/authoring-path.md`, `skills/skill-writer/references/claude-argument-substitutions.md`, `skills/skill-writer/references/claude-dynamic-context.md`, `skills/skill-writer/references/claude-frontmatter-invocation.md`, `skills/skill-writer/references/claude-hook-backed.md`, `skills/skill-writer/references/claude-subagent-fork.md`, `skills/skill-writer/references/description-optimization.md`, `skills/skill-writer/references/design-principles.md`, `skills/skill-writer/references/example-documentation-skill.md`, `skills/skill-writer/references/example-hook-backed-skill.md`, `skills/skill-writer/references/example-router-skill.md`, `skills/skill-writer/references/example-subagent-fork-skill.md`, `skills/skill-writer/references/example-workflow-process-skill.md`, `skills/skill-writer/references/execution-shapes.md`, `skills/skill-writer/references/iteration-evidence.md`, `skills/skill-writer/references/iteration-path.md`, `skills/skill-writer/references/layout-argument-driven-skill.md`, `skills/skill-writer/references/layout-asset-template-skill.md`, `skills/skill-writer/references/layout-inline-skill.md`, `skills/skill-writer/references/layout-reference-backed-skill.md`, `skills/skill-writer/references/layout-script-backed-workflow.md`, `skills/skill-writer/references/mode-selection.md`, `skills/skill-writer/references/output-contracts.md`, `skills/skill-writer/references/reference-architecture.md`, `skills/skill-writer/references/registration-validation.md`, `skills/skill-writer/references/skill-evals.md`, `skills/skill-writer/references/source-adaptation.md`, `skills/skill-writer/references/source-discovery.md`, `skills/skill-writer/references/spec-template.md`, `skills/skill-writer/references/structure-troubleshooting.md`, `skills/skill-writer/references/synthesis-path.md`, `skills/skill-writer/references/workflow-orchestrator-workers.md`, `skills/skill-writer/references/workflow-parallel.md`, `skills/skill-writer/references/workflow-plan-validate-execute.md`, `skills/skill-writer/references/workflow-prompt-chaining.md`, `skills/skill-writer/references/workflow-routing.md`, `skills/skill-writer/references/workflow-validation-loops.md`, `skills/skill-writer/scripts/quick_validate.py`
- **Autor:** Sentry (Functional Software, Inc.)
- **Licença:** Apache-2.0 (texto completo em `LICENSE`)
- **Commit:** `a582c51ee29d0f35e6ac321340796f77d43da733` (baixado em 2026-11-22)

## Alterações feitas

- `name:` do frontmatter trocado de `skill-writer` para `sen-skill-writer`.
- Fora isso, o texto do especialista está como no original (em inglês).

## Arquivos da skill original que não vieram

- `SPEC.md`, `SOURCES.md`, `EVAL.md` e `evals/` (especificação interna, registro de fontes e casos de teste do autor, não usados no fluxo).

# Origem

Skill de especialista empacotada para o marketplace do Progress Code (id `swan-event-room-intelligence`).

- Repositório: https://github.com/swan-gtm/gtm-skills
- Caminho: `skills/ariel-cohen/event-room-intelligence`
- Autor: Ariel Cohen / Swan (biblioteca Swan; autoria registrada em `author.md`, copiado do repositório)
- Detentor do copyright no arquivo de licença: Swan
- Licença: MIT (texto completo em `LICENSE`, copiado de `LICENSE` no repositório)
- Commit: `eb0026f469f90645e1a64168d08a3e0afb59ee12` (baixado em 2026-11-22)

## Arquivos incluídos

- `SKILL.md` (de `skills/ariel-cohen/event-room-intelligence/SKILL.md`)
- `references/buying-committee-rubric.md` (de `skills/ariel-cohen/event-room-intelligence/references/buying-committee-rubric.md`)
- `references/card-anatomy-and-sort-order.md` (de `skills/ariel-cohen/event-room-intelligence/references/card-anatomy-and-sort-order.md`)
- `references/company-mapping-waterfall.md` (de `skills/ariel-cohen/event-room-intelligence/references/company-mapping-waterfall.md`)
- `references/day-of-and-after-checklist.md` (de `skills/ariel-cohen/event-room-intelligence/references/day-of-and-after-checklist.md`)
- `author.md` (de `skills/ariel-cohen/author.md`)

## Mudanças feitas

1. Frontmatter: `name:` trocado de `event-room-intelligence` para `swan-event-room-intelligence` (a descrição foi mantida).

O texto do especialista foi mantido em inglês, sem tradução.

A biblioteca swan-gtm/gtm-skills é MIT (LICENSE "Copyright (c) 2026 Swan"; CONTRIBUTING: "Contributions are MIT-licensed"). O crédito ao autor de cada skill é mantido pelo `author.md`.

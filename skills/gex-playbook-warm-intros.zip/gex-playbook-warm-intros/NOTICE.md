# Aviso de terceiros (NOTICE)

Esta skill é uma cópia adaptada de material de terceiros e é redistribuída sob a licença original. O texto do especialista ficou em inglês, como no original.

- **Origem:** https://github.com/growthenginenowoslawski/coldoutboundskills
- **Caminho no repositório:** `skills/playbooks/playbook-warm-intros`
- **Commit:** `25c5d85fbb5dd3efec97b0ca457cbbc286547476` (baixado em 2026-11-22)
- **Autor:** GrowthEngineX
- **Licença:** MIT (texto completo em `LICENSE`, copiado de `LICENSE` do repositório)

## Arquivos incluídos

- `SKILL.md` (de `skills/playbooks/playbook-warm-intros/SKILL.md`)
- `LICENSE`

## Mudanças feitas

- Frontmatter: `name: playbook-warm-intros` trocado por `name: gex-playbook-warm-intros` (a descrição ficou igual).

## Arquivos do original que não foram incluídos

- `clay-table.md` e `clay-workflow.md` (seção 5 do SKILL.md): implementação na ferramenta paga Clay. O método do SKILL.md não depende deles.

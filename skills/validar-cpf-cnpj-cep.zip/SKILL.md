---
name: validar-cpf-cnpj-cep
description: Valida CPF/CNPJ pelo algoritmo real de dígito verificador (não regex) e consulta CEP/dados de empresa via APIs públicas gratuitas (BrasilAPI/ViaCEP/ReceitaWS), com tratamento de indisponibilidade. Use quando o usuário pedir para "validar esse CPF/CNPJ", "buscar o endereço desse CEP", "consultar os dados dessa empresa pelo CNPJ".
argument-hint: [CPF|CNPJ|CEP] [valor]
---

# Validar e consultar CPF/CNPJ/CEP

## CPF — algoritmo do dígito verificador (não uma regex)
```python
def validar_cpf(cpf):
    cpf = "".join(filter(str.isdigit, cpf))
    if len(cpf) != 11 or cpf == cpf[0] * 11:  # sequencia de digitos iguais "passa" na conta mas e invalida
        return False
    for i in [9, 10]:
        soma = sum(int(cpf[num]) * ((i + 1) - num) for num in range(0, i))
        digito = ((soma * 10) % 11) % 10
        if digito != int(cpf[i]):
            return False
    return True
```
`cpf == cpf[0] * 11` (todos os dígitos iguais, ex.: `111.111.111-11`) passa matematicamente no cálculo do dígito
verificador mas nunca é um CPF real emitido — sempre exclua esse caso explicitamente.

## CNPJ — mesma ideia, pesos diferentes
```python
def validar_cnpj(cnpj):
    cnpj = "".join(filter(str.isdigit, cnpj))
    if len(cnpj) != 14 or cnpj == cnpj[0] * 14:
        return False
    pesos1 = [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
    pesos2 = [6] + pesos1
    for i, pesos in [(12, pesos1), (13, pesos2)]:
        soma = sum(int(cnpj[num]) * pesos[num] for num in range(i))
        digito = 11 - (soma % 11)
        digito = 0 if digito >= 10 else digito
        if digito != int(cnpj[i]):
            return False
    return True
```
Desde 2026, o CNPJ alfanumérico começou a ser adotado (letras + números) — se o usuário mencionar CNPJ com letras,
confirme a versão do algoritmo (o cálculo do dígito verificador muda: usa valor ASCII menos 48 para cada
caractere) antes de aplicar o algoritmo numérico puro acima, que só vale para CNPJ 100% numérico.

## Consultar CEP (ViaCEP ou BrasilAPI — gratuitas, sem chave de API)
```python
import requests

resp = requests.get(f"https://viacep.com.br/ws/{cep}/json/", timeout=10)
dados = resp.json()
if dados.get("erro"):
    print("CEP não encontrado")
else:
    print(dados["logradouro"], dados["bairro"], dados["localidade"], dados["uf"])
```
BrasilAPI (`https://brasilapi.com.br/api/cep/v2/{cep}`) é uma alternativa com formato de resposta um pouco
diferente e geralmente boa disponibilidade — use como fallback se ViaCEP estiver fora do ar.

## Consultar dados de empresa por CNPJ (ReceitaWS/BrasilAPI)
```python
resp = requests.get(f"https://brasilapi.com.br/api/cnpj/v1/{cnpj}", timeout=10)
dados = resp.json()
print(dados["razao_social"], dados["descricao_situacao_cadastral"])
```
ReceitaWS (`https://www.receitaws.com.br/v1/cnpj/{cnpj}`) tem limite de requisições mais restrito na versão
gratuita — para volume alto, prefira BrasilAPI ou considere um plano pago.

## Tratamento de indisponibilidade (essas APIs públicas caem às vezes)
```python
def consultar_cep_com_fallback(cep):
    for url in [f"https://viacep.com.br/ws/{cep}/json/", f"https://brasilapi.com.br/api/cep/v2/{cep}"]:
        try:
            resp = requests.get(url, timeout=5)
            if resp.ok:
                return resp.json()
        except requests.exceptions.RequestException:
            continue
    raise Exception(f"Nenhum servico de CEP respondeu para {cep}")
```
Nunca deixe a aplicação travar/falhar por completo porque uma API pública gratuita está temporariamente fora do ar
— tenha um fallback, ou pelo menos um erro claro em vez de exceção não tratada.

## Regras
- Nunca valide CPF/CNPJ só por formato (quantidade de dígitos/regex) quando o dígito verificador real pode e deve
  ser calculado — ver skill `regex-multiplataforma` para o porquê disso ser insuficiente.
- CEP não encontrado não é necessariamente erro do sistema — pode ser CEP genérico de cidade pequena sem
  logradouro específico, ou CEP inexistente; trate os dois casos com mensagens diferentes para o usuário.
- Ao consultar dados de terceiros (CNPJ de empresa) via API pública, não presuma que o dado está 100% atualizado —
  são bases replicadas da Receita Federal com alguma defasagem.

## Arquivos desta skill
Nenhum script fixo — as funções acima cobrem os casos mais comuns; adapte à validação/consulta real do usuário.

# Origem

Skill de especialista empacotada para o marketplace do Progress Code (id `mp-to-tickets`).

- Repositório: https://github.com/mattpocock/skills
- Caminho: `skills/engineering/to-tickets`
- Autor: Matt Pocock
- Detentor do copyright no arquivo de licença: Matt Pocock
- Licença: MIT (texto completo em `LICENSE`, copiado de `LICENSE` no repositório)
- Commit: `abeeaf95660ba9e8b7c753eb38f441ca707a8823` (baixado em 2026-11-22)

## Arquivos incluídos

- `SKILL.md` (de `skills/engineering/to-tickets/SKILL.md`)

## Mudanças feitas

1. Frontmatter: `name:` trocado de `to-tickets` para `mp-to-tickets` (a descrição foi mantida).

O texto do especialista foi mantido em inglês, sem tradução.

## Não incluído

- `agents/openai.yaml` (configuração para o Codex da OpenAI, sem uso aqui).

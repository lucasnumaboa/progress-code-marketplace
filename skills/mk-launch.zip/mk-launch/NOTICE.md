# Origem e mudanças

- **Repositório:** https://github.com/coreyhaines31/marketingskills
- **Caminho no repositório:** `skills/launch`
- **Autor:** Corey Haines
- **Licença:** MIT (texto em `LICENSE`)
- **Commit usado:** `5b2b400eec1e7e1cec76245a715d0b0d4fd2a9c1`
- **Arquivos copiados:** `SKILL.md`, `references/shipped-changes.md`, `references/site-launch-qa.md`

## Mudanças feitas

- no cabeçalho (frontmatter), `name:` passou de `launch` para `mk-launch`; a descrição ficou igual
- removida a menção a "Verified Partner"/parceiro comercial do repositório (◆), que é colocação paga/propaganda (em `references/site-launch-qa.md`)
- nenhuma outra alteração no texto do especialista (mantido em inglês)

Empacotada para o marketplace do Progress Code em 2026-11-22.

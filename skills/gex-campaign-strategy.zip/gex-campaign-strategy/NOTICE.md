# Aviso de terceiros (NOTICE)

Esta skill é uma cópia adaptada de material de terceiros e é redistribuída sob a licença original. O texto do especialista ficou em inglês, como no original.

- **Origem:** https://github.com/growthenginenowoslawski/coldoutboundskills
- **Caminho no repositório:** `skills/campaign-strategy`
- **Commit:** `25c5d85fbb5dd3efec97b0ca457cbbc286547476` (baixado em 2026-11-22)
- **Autor:** GrowthEngineX
- **Licença:** MIT (texto completo em `LICENSE`, copiado de `LICENSE` do repositório)

## Arquivos incluídos

- `SKILL.md` (de `skills/campaign-strategy/SKILL.md`)
- `LICENSE`

## Mudanças feitas

- Frontmatter: `name: campaign-strategy` trocado por `name: gex-campaign-strategy` (a descrição ficou igual).

## Arquivos do original que não foram incluídos

- As skills citadas em "What to do next" e "Related skills" (`icp-onboarding`, `lead-magnet-brainstorm`, `campaign-copywriting`, `cold-email-kickoff`, `zapmail-domain-setup-public`, `prospeo-full-export`, `disco-like`) não fazem parte deste pacote; `campaign-copywriting` está empacotada à parte como `gex-campaign-copywriting`.

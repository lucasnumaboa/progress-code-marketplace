# Origem e mudanças

- **Repositório:** https://github.com/blader/humanizer
- **Caminho no repositório:** `(raiz do repositório)`
- **Autor:** Siqi Chen
- **Licença:** MIT (texto em `LICENSE`)
- **Commit usado:** `a32f24407364c74c812b43c15926d638bee1e072`
- **Arquivos copiados:** `SKILL.md`

## Mudanças feitas

- no cabeçalho (frontmatter), `name:` passou de `humanizer` para `hum-humanizer`; a descrição ficou igual
- nenhuma outra alteração no texto do especialista (mantido em inglês)

## Observações

- os padrões vêm do guia "Signs of AI writing" da Wikipedia (https://en.wikipedia.org/wiki/Wikipedia:Signs_of_AI_writing), mantido pelo WikiProject AI Cleanup, sob CC BY-SA 4.0; a skill reescreve a ideia com palavras próprias e credita a fonte no fim do SKILL.md

Empacotada para o marketplace do Progress Code em 2026-11-22.

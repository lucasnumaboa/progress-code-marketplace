# Aviso de terceiros (NOTICE)

Esta skill é uma cópia adaptada de material de terceiros e é redistribuída sob a licença original. O texto do especialista ficou em inglês, como no original.

- **Origem:** https://github.com/anthropics/skills
- **Caminho no repositório:** `skills/pptx`
- **Commit:** `e4bb5d960d87126ff3b3a8af1a104b7db67560ba` (baixado em 2026-11-22)
- **Autor:** Anthropic
- **Licença:** Apache-2.0 (texto completo em `LICENSE`, copiado de `skills/pptx/LICENSE.txt` do repositório)

## Arquivos incluídos

- `SKILL.md` (de `skills/pptx/SKILL.md`)
- `LICENSE.txt` (de `skills/pptx/LICENSE.txt`)
- `scripts/__init__.py` (de `skills/pptx/scripts/__init__.py`)
- `scripts/add_slide.py` (de `skills/pptx/scripts/add_slide.py`)
- `scripts/apply_theme.js` (de `skills/pptx/scripts/apply_theme.js`)
- `scripts/clean.py` (de `skills/pptx/scripts/clean.py`)
- `scripts/office/helpers/__init__.py` (de `skills/pptx/scripts/office/helpers/__init__.py`)
- `scripts/office/helpers/pptx_chart.py` (de `skills/pptx/scripts/office/helpers/pptx_chart.py`)
- `scripts/office/helpers/pptx_slide.py` (de `skills/pptx/scripts/office/helpers/pptx_slide.py`)
- `scripts/office/helpers/pptx_theme.py` (de `skills/pptx/scripts/office/helpers/pptx_theme.py`)
- `scripts/office/schemas/ISO-IEC29500-4_2016/dml-chart.xsd` (de `skills/pptx/scripts/office/schemas/ISO-IEC29500-4_2016/dml-chart.xsd`)
- `scripts/office/schemas/ISO-IEC29500-4_2016/dml-chartDrawing.xsd` (de `skills/pptx/scripts/office/schemas/ISO-IEC29500-4_2016/dml-chartDrawing.xsd`)
- `scripts/office/schemas/ISO-IEC29500-4_2016/dml-diagram.xsd` (de `skills/pptx/scripts/office/schemas/ISO-IEC29500-4_2016/dml-diagram.xsd`)
- `scripts/office/schemas/ISO-IEC29500-4_2016/dml-lockedCanvas.xsd` (de `skills/pptx/scripts/office/schemas/ISO-IEC29500-4_2016/dml-lockedCanvas.xsd`)
- `scripts/office/schemas/ISO-IEC29500-4_2016/dml-main.xsd` (de `skills/pptx/scripts/office/schemas/ISO-IEC29500-4_2016/dml-main.xsd`)
- `scripts/office/schemas/ISO-IEC29500-4_2016/dml-picture.xsd` (de `skills/pptx/scripts/office/schemas/ISO-IEC29500-4_2016/dml-picture.xsd`)
- `scripts/office/schemas/ISO-IEC29500-4_2016/dml-spreadsheetDrawing.xsd` (de `skills/pptx/scripts/office/schemas/ISO-IEC29500-4_2016/dml-spreadsheetDrawing.xsd`)
- `scripts/office/schemas/ISO-IEC29500-4_2016/dml-wordprocessingDrawing.xsd` (de `skills/pptx/scripts/office/schemas/ISO-IEC29500-4_2016/dml-wordprocessingDrawing.xsd`)
- `scripts/office/schemas/ISO-IEC29500-4_2016/pml.xsd` (de `skills/pptx/scripts/office/schemas/ISO-IEC29500-4_2016/pml.xsd`)
- `scripts/office/schemas/ISO-IEC29500-4_2016/shared-additionalCharacteristics.xsd` (de `skills/pptx/scripts/office/schemas/ISO-IEC29500-4_2016/shared-additionalCharacteristics.xsd`)
- `scripts/office/schemas/ISO-IEC29500-4_2016/shared-bibliography.xsd` (de `skills/pptx/scripts/office/schemas/ISO-IEC29500-4_2016/shared-bibliography.xsd`)
- `scripts/office/schemas/ISO-IEC29500-4_2016/shared-commonSimpleTypes.xsd` (de `skills/pptx/scripts/office/schemas/ISO-IEC29500-4_2016/shared-commonSimpleTypes.xsd`)
- `scripts/office/schemas/ISO-IEC29500-4_2016/shared-customXmlDataProperties.xsd` (de `skills/pptx/scripts/office/schemas/ISO-IEC29500-4_2016/shared-customXmlDataProperties.xsd`)
- `scripts/office/schemas/ISO-IEC29500-4_2016/shared-customXmlSchemaProperties.xsd` (de `skills/pptx/scripts/office/schemas/ISO-IEC29500-4_2016/shared-customXmlSchemaProperties.xsd`)
- `scripts/office/schemas/ISO-IEC29500-4_2016/shared-documentPropertiesCustom.xsd` (de `skills/pptx/scripts/office/schemas/ISO-IEC29500-4_2016/shared-documentPropertiesCustom.xsd`)
- `scripts/office/schemas/ISO-IEC29500-4_2016/shared-documentPropertiesExtended.xsd` (de `skills/pptx/scripts/office/schemas/ISO-IEC29500-4_2016/shared-documentPropertiesExtended.xsd`)
- `scripts/office/schemas/ISO-IEC29500-4_2016/shared-documentPropertiesVariantTypes.xsd` (de `skills/pptx/scripts/office/schemas/ISO-IEC29500-4_2016/shared-documentPropertiesVariantTypes.xsd`)
- `scripts/office/schemas/ISO-IEC29500-4_2016/shared-math.xsd` (de `skills/pptx/scripts/office/schemas/ISO-IEC29500-4_2016/shared-math.xsd`)
- `scripts/office/schemas/ISO-IEC29500-4_2016/shared-relationshipReference.xsd` (de `skills/pptx/scripts/office/schemas/ISO-IEC29500-4_2016/shared-relationshipReference.xsd`)
- `scripts/office/schemas/ISO-IEC29500-4_2016/sml.xsd` (de `skills/pptx/scripts/office/schemas/ISO-IEC29500-4_2016/sml.xsd`)
- `scripts/office/schemas/ISO-IEC29500-4_2016/vml-main.xsd` (de `skills/pptx/scripts/office/schemas/ISO-IEC29500-4_2016/vml-main.xsd`)
- `scripts/office/schemas/ISO-IEC29500-4_2016/vml-officeDrawing.xsd` (de `skills/pptx/scripts/office/schemas/ISO-IEC29500-4_2016/vml-officeDrawing.xsd`)
- `scripts/office/schemas/ISO-IEC29500-4_2016/vml-presentationDrawing.xsd` (de `skills/pptx/scripts/office/schemas/ISO-IEC29500-4_2016/vml-presentationDrawing.xsd`)
- `scripts/office/schemas/ISO-IEC29500-4_2016/vml-spreadsheetDrawing.xsd` (de `skills/pptx/scripts/office/schemas/ISO-IEC29500-4_2016/vml-spreadsheetDrawing.xsd`)
- `scripts/office/schemas/ISO-IEC29500-4_2016/vml-wordprocessingDrawing.xsd` (de `skills/pptx/scripts/office/schemas/ISO-IEC29500-4_2016/vml-wordprocessingDrawing.xsd`)
- `scripts/office/schemas/ISO-IEC29500-4_2016/wml.xsd` (de `skills/pptx/scripts/office/schemas/ISO-IEC29500-4_2016/wml.xsd`)
- `scripts/office/schemas/ISO-IEC29500-4_2016/xml.xsd` (de `skills/pptx/scripts/office/schemas/ISO-IEC29500-4_2016/xml.xsd`)
- `scripts/office/schemas/ecma/fouth-edition/opc-contentTypes.xsd` (de `skills/pptx/scripts/office/schemas/ecma/fouth-edition/opc-contentTypes.xsd`)
- `scripts/office/schemas/ecma/fouth-edition/opc-coreProperties.xsd` (de `skills/pptx/scripts/office/schemas/ecma/fouth-edition/opc-coreProperties.xsd`)
- `scripts/office/schemas/ecma/fouth-edition/opc-digSig.xsd` (de `skills/pptx/scripts/office/schemas/ecma/fouth-edition/opc-digSig.xsd`)
- `scripts/office/schemas/ecma/fouth-edition/opc-relationships.xsd` (de `skills/pptx/scripts/office/schemas/ecma/fouth-edition/opc-relationships.xsd`)
- `scripts/office/schemas/mce/mc.xsd` (de `skills/pptx/scripts/office/schemas/mce/mc.xsd`)
- `scripts/office/schemas/microsoft/wml-2010.xsd` (de `skills/pptx/scripts/office/schemas/microsoft/wml-2010.xsd`)
- `scripts/office/schemas/microsoft/wml-2012.xsd` (de `skills/pptx/scripts/office/schemas/microsoft/wml-2012.xsd`)
- `scripts/office/schemas/microsoft/wml-2018.xsd` (de `skills/pptx/scripts/office/schemas/microsoft/wml-2018.xsd`)
- `scripts/office/schemas/microsoft/wml-cex-2018.xsd` (de `skills/pptx/scripts/office/schemas/microsoft/wml-cex-2018.xsd`)
- `scripts/office/schemas/microsoft/wml-cid-2016.xsd` (de `skills/pptx/scripts/office/schemas/microsoft/wml-cid-2016.xsd`)
- `scripts/office/schemas/microsoft/wml-sdtdatahash-2020.xsd` (de `skills/pptx/scripts/office/schemas/microsoft/wml-sdtdatahash-2020.xsd`)
- `scripts/office/schemas/microsoft/wml-symex-2015.xsd` (de `skills/pptx/scripts/office/schemas/microsoft/wml-symex-2015.xsd`)
- `scripts/office/soffice.py` (de `skills/pptx/scripts/office/soffice.py`)
- `scripts/office/validate.py` (de `skills/pptx/scripts/office/validate.py`)
- `scripts/office/validators/__init__.py` (de `skills/pptx/scripts/office/validators/__init__.py`)
- `scripts/office/validators/base.py` (de `skills/pptx/scripts/office/validators/base.py`)
- `scripts/office/validators/docx.py` (de `skills/pptx/scripts/office/validators/docx.py`)
- `scripts/office/validators/pptx.py` (de `skills/pptx/scripts/office/validators/pptx.py`)
- `scripts/office/validators/redlining.py` (de `skills/pptx/scripts/office/validators/redlining.py`)
- `scripts/slide_text.py` (de `skills/pptx/scripts/slide_text.py`)
- `scripts/thumbnail.py` (de `skills/pptx/scripts/thumbnail.py`)
- `LICENSE`

## Mudanças feitas

- Frontmatter: `name: pptx` trocado por `name: as-pptx` (a descrição ficou igual).
- Conforme a seção 4(b) da Licença Apache 2.0: os arquivos acima foram modificados em relação ao original nos pontos listados. Fora esses pontos, o texto é o original.

## Observação

Os scripts em `scripts/` foram conferidos: trabalham só com arquivos locais (python-pptx, lxml, Pillow, LibreOffice local e o módulo npm pptxgenjs), sem chave de API, serviço pago ou telemetria. O arquivo `LICENSE.txt` citado no frontmatter foi mantido com o nome original, além da cópia em `LICENSE`.

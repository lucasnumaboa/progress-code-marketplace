"""Exemplos de geracao/edicao de .docx com python-docx.

Uso:
    python gerar_docx.py saida.docx
"""
import sys
from docx import Document
from docx.shared import Inches, Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.oxml import OxmlElement


def add_page_number_field(paragraph):
    """Insere o campo PAGE (o Word calcula o numero ao abrir/atualizar campos)."""
    run = paragraph.add_run()
    fld_char1 = OxmlElement("w:fldChar")
    fld_char1.set(qn("w:fldCharType"), "begin")
    instr_text = OxmlElement("w:instrText")
    instr_text.set(qn("xml:space"), "preserve")
    instr_text.text = "PAGE"
    fld_char2 = OxmlElement("w:fldChar")
    fld_char2.set(qn("w:fldCharType"), "end")
    run._r.append(fld_char1)
    run._r.append(instr_text)
    run._r.append(fld_char2)


def add_toc_field(document):
    """Insere o campo de sumario. O Word precisa atualizar campos (F9) para calcular."""
    paragraph = document.add_paragraph()
    run = paragraph.add_run()
    fld_char1 = OxmlElement("w:fldChar")
    fld_char1.set(qn("w:fldCharType"), "begin")
    instr_text = OxmlElement("w:instrText")
    instr_text.set(qn("xml:space"), "preserve")
    instr_text.text = 'TOC \\o "1-3" \\h \\z \\u'
    fld_char2 = OxmlElement("w:fldChar")
    fld_char2.set(qn("w:fldCharType"), "separate")
    fld_char3 = OxmlElement("w:t")
    fld_char3.text = "Atualize o sumario no Word (Ctrl+A, F9)."
    fld_char4 = OxmlElement("w:fldChar")
    fld_char4.set(qn("w:fldCharType"), "end")
    run._r.append(fld_char1)
    run._r.append(instr_text)
    run._r.append(fld_char2)
    run._r.append(fld_char3)
    run._r.append(fld_char4)


def substituir_mantendo_formato(paragraph, de, para):
    """Substitui texto num paragrafo mesmo quando o texto esta dividido em varios runs,
    preservando a formatacao do primeiro run afetado. Retorna True se substituiu algo."""
    texto_completo = "".join(r.text for r in paragraph.runs)
    if de not in texto_completo:
        return False
    novo_texto = texto_completo.replace(de, para)

    # zera todos os runs e poe o texto novo inteiro no primeiro (mais simples e robusto
    # que tentar remapear posicao por posicao entre runs antigos e novos)
    if not paragraph.runs:
        return False
    primeiro = paragraph.runs[0]
    primeiro.text = novo_texto
    for r in paragraph.runs[1:]:
        r.text = ""
    return True


def gerar_exemplo(caminho_saida):
    document = Document()

    document.add_heading("Relatorio de exemplo", level=0)
    document.add_heading("1. Introducao", level=1)

    p = document.add_paragraph()
    p.add_run("Este paragrafo tem um trecho em ").font.size = Pt(11)
    p.add_run("negrito").bold = True
    p.add_run(" e outro em ")
    p.add_run("italico").italic = True
    p.add_run(".")

    document.add_heading("2. Sumario (campo de campo)", level=1)
    add_toc_field(document)

    document.add_heading("3. Tabela", level=1)
    tabela = document.add_table(rows=1, cols=3)
    tabela.style = "Table Grid"
    hdr = tabela.rows[0].cells
    hdr[0].text, hdr[1].text, hdr[2].text = "Item", "Quantidade", "Valor"
    for item, qtd, valor in [("Produto A", "10", "R$ 100,00"), ("Produto B", "5", "R$ 50,00")]:
        row = tabela.add_row().cells
        row[0].text, row[1].text, row[2].text = item, qtd, valor

    document.add_page_break()
    document.add_heading("4. Rodape com numero de pagina", level=1)
    section = document.sections[0]
    footer_p = section.footer.paragraphs[0]
    footer_p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    footer_p.add_run("Pagina ")
    add_page_number_field(footer_p)

    document.save(caminho_saida)
    print(f"Gerado: {caminho_saida}")
    print("Lembrete: abra no Word e de Ctrl+A, F9 para calcular o sumario e o numero de pagina.")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Uso: python gerar_docx.py saida.docx")
        sys.exit(1)
    gerar_exemplo(sys.argv[1])

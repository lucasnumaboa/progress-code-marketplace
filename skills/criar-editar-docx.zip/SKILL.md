---
name: criar-editar-docx
description: Cria documentos Word (.docx) do zero ou edita um existente preservando formatação, usando python-docx — títulos, estilos, tabelas, imagens, cabeçalho/rodapé, sumário e substituição de marcadores {{campo}} em modelos. Use quando o usuário pedir "gerar um Word", "criar um relatório em .docx", "preencher esse modelo de contrato", "editar esse documento sem perder a formatação", ou citar arquivos .docx/.dotx sem pedir apresentação (.pptx) ou planilha (.xlsx).
argument-hint: [criar novo | editar existente] [caminho do .docx]
---

# Criar e editar Word (.docx)

## Passo 1 — Preparar o ambiente
```
pip install python-docx
```
Se o objetivo final é gerar PDF a partir do `.docx`, o Word precisa estar instalado (automação COM) — ver passo 5.
Sem Word instalado, converta usando a skill `gerar-pdf-html` só se o conteúdo também existir em HTML; não há forma
confiável de converter `.docx` → PDF fielmente sem Word ou LibreOffice.

## Passo 2 — Documento novo do zero
Use `scripts/gerar_docx.py` como base (rode com `python scripts/gerar_docx.py saida.docx`). Ele mostra:
- Título e níveis de heading (`document.add_heading(texto, level=1)`).
- Parágrafos com formatação em nível de *run* (negrito/itálico só numa parte do texto — nunca em `add_paragraph`
  inteiro, sempre crie `run = paragraph.add_run(texto)` e formate `run.bold`/`run.italic`/`run.font.size`).
- Tabela (`document.add_table(rows, cols)`, estilo `Table Grid`, mesclar células com `cell.merge()`).
- Imagem (`document.add_picture(caminho, width=Inches(4))`).
- Quebra de página (`document.add_page_break()`).
- Cabeçalho/rodapé (`section.header.paragraphs[0]`) e número de página via campo de campo `PAGE` (python-docx não
  calcula o número — insere o campo, o Word calcula ao abrir; ver função `add_page_number` no script).
- Sumário (TOC): python-docx **não gera o sumário calculado** — insere o campo `TOC \o "1-3" \h \z \u`; ao abrir no
  Word, o usuário (ou a automação COM) precisa dar Ctrl+A, F9 para atualizar campos, ou "Atualizar Sumário".

## Passo 3 — Editar um documento existente sem perder formatação
**Nunca** substitua `paragraph.text = novo_texto` inteiro — isso apaga toda a formatação de *runs* daquele parágrafo
(negrito, cor, fonte diferente por trecho viram um único run sem estilo). Regra:
1. Abra com `Document(caminho)`.
2. Para trocar um texto específico, procure em qual(is) *run* ele está. Um mesmo texto visual pode estar **dividido
   em vários runs** (o Word quebra runs por motivos internos, não por palavra) — por isso `run.text.replace(...)`
   simples falha silenciosamente em muitos documentos reais. Use a função `substituir_mantendo_formato` do script
   `scripts/gerar_docx.py`, que concatena o texto de todos os runs do parágrafo, faz a substituição no texto
   concatenado, e reescreve preservando a formatação do primeiro run afetado.
3. Salve **sempre em um novo arquivo** ou com backup do original antes de sobrescrever (`shutil.copy2` primeiro).

## Passo 4 — Modelos com marcadores `{{campo}}` (mala direta / geração em lote)
Convenção: o `.docx` modelo tem marcadores como `{{nome}}`, `{{data}}`, `{{valor}}` em qualquer lugar (parágrafo,
célula de tabela, cabeçalho). Use `scripts/preencher_modelo.py`:
```
python scripts/preencher_modelo.py --modelo contrato.docx --dados dados.json --saida contrato-preenchido.docx
```
`dados.json` é um objeto simples `{"nome": "...", "data": "...", "valor": "..."}`. O script varre parágrafos e
células de tabela (inclusive dentro de cabeçalho/rodapé) com a mesma lógica "runs concatenados" do passo 3. Se um
campo do modelo não existir em `dados.json`, o script **para e avisa** em vez de deixar `{{campo}}` sem preencher no
documento final — não gere documento com marcador visível para o usuário final.

## Passo 5 — Converter para PDF (precisa do Word instalado)
```
powershell -Command "$w = New-Object -ComObject Word.Application; $w.Visible = $false; $d = $w.Documents.Open('C:\caminho\arquivo.docx'); $d.SaveAs([ref]'C:\caminho\arquivo.pdf', [ref]17); $d.Close(); $w.Quit()"
```
`17` é `wdFormatPDF`. Isso também é o momento de atualizar campos calculados (sumário, número de página): antes de
`SaveAs`, rode `$d.Fields.Update()`.

## Regras
- Sempre valide abrindo o `.docx` gerado (ex.: `python -c "from docx import Document; Document('saida.docx')"`) para
  garantir que não está corrompido antes de entregar ao usuário.
- Não invente campos que não existem no modelo original — se `dados.json` tiver uma chave a mais, avise mas não é
  erro; se faltar uma chave que o modelo usa, PARE e pergunte o valor.
- Imagens: verifique que o arquivo de imagem existe e tem proporção sensata antes de inserir; imagem não encontrada
  deve parar a execução com mensagem clara, não gerar documento com erro silencioso.

## Arquivos desta skill
- `scripts/gerar_docx.py` — exemplos de geração do zero e função `substituir_mantendo_formato`.
- `scripts/preencher_modelo.py` — preenchimento de modelo `{{campo}}` a partir de JSON.

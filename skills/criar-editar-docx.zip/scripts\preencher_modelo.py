"""Preenche um modelo .docx com marcadores {{campo}} a partir de um JSON de dados.

Varre paragrafos soltos, celulas de tabela e cabecalho/rodape de todas as secoes.
Para se algum marcador do modelo nao tiver valor correspondente em dados.json.

Uso:
    python preencher_modelo.py --modelo modelo.docx --dados dados.json --saida saida.docx
"""
import argparse
import json
import re
import sys

from docx import Document

PADRAO_MARCADOR = re.compile(r"\{\{\s*(\w+)\s*\}\}")


def substituir_no_paragrafo(paragraph, dados, faltando):
    texto_completo = "".join(r.text for r in paragraph.runs)
    if "{{" not in texto_completo:
        return

    def resolver(m):
        chave = m.group(1)
        if chave not in dados:
            faltando.add(chave)
            return m.group(0)
        return str(dados[chave])

    novo_texto = PADRAO_MARCADOR.sub(resolver, texto_completo)
    if novo_texto != texto_completo and paragraph.runs:
        paragraph.runs[0].text = novo_texto
        for r in paragraph.runs[1:]:
            r.text = ""


def processar_tabelas(tabelas, dados, faltando):
    for tabela in tabelas:
        for row in tabela.rows:
            for cell in row.cells:
                for paragraph in cell.paragraphs:
                    substituir_no_paragrafo(paragraph, dados, faltando)
                for t in cell.tables:
                    processar_tabelas([t], dados, faltando)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--modelo", required=True)
    ap.add_argument("--dados", required=True)
    ap.add_argument("--saida", required=True)
    args = ap.parse_args()

    with open(args.dados, "r", encoding="utf-8") as f:
        dados = json.load(f)

    document = Document(args.modelo)
    faltando = set()

    for paragraph in document.paragraphs:
        substituir_no_paragrafo(paragraph, dados, faltando)
    processar_tabelas(document.tables, dados, faltando)

    for section in document.sections:
        for paragraph in list(section.header.paragraphs) + list(section.footer.paragraphs):
            substituir_no_paragrafo(paragraph, dados, faltando)
        processar_tabelas(section.header.tables, dados, faltando)
        processar_tabelas(section.footer.tables, dados, faltando)

    if faltando:
        print(f"ERRO: o modelo usa marcador(es) sem valor em dados.json: {sorted(faltando)}")
        sys.exit(1)

    document.save(args.saida)
    print(f"Gerado: {args.saida}")


if __name__ == "__main__":
    main()

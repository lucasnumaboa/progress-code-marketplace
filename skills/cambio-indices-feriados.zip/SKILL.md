---
name: cambio-indices-feriados
description: Consulta câmbio e índices oficiais do Banco Central (PTAX, SELIC, IPCA) via API pública e calcula dias úteis considerando feriados nacionais/estaduais/municipais. Use quando o usuário pedir para "converter esse valor pelo câmbio do dia", "qual foi a SELIC/IPCA nesse período", "quantos dias úteis entre essas datas", "esse dia é feriado onde".
argument-hint: [índice/câmbio ou datas para calcular dias úteis]
---

# Câmbio, índices e feriados

## API do Banco Central (SGS — Sistema Gerenciador de Séries Temporais, gratuita, sem chave)
```python
import requests

# codigo da serie: 1 = dolar PTAX venda, 433 = IPCA, 4390 = SELIC meta, etc.
def consultar_serie_bacen(codigo_serie, data_inicial, data_final):
    url = f"https://api.bcb.gov.br/dados/serie/bcdata.sgs.{codigo_serie}/dados"
    resp = requests.get(url, params={
        "formato": "json", "dataInicial": data_inicial, "dataFinal": data_final,
    }, timeout=15)
    return resp.json()  # lista de {"data": "dd/mm/aaaa", "valor": "..."}
```
Códigos de série mais usados: `1` (dólar PTAX venda), `10813` (dólar PTAX compra), `433` (IPCA mensal), `4390`
(SELIC meta), `11` (SELIC diária), `21619` (câmbio USD compra fechamento) — a lista completa de códigos está no
próprio site do SGS/BACEN; confirme o código certo antes de assumir, séries parecidas têm códigos diferentes e
metodologia diferente (ex.: PTAX vs. câmbio de fechamento não são o mesmo valor).

## PTAX especificamente (câmbio oficial para conversão fiscal/contábil)
```python
resp = requests.get(
    "https://olinda.bcb.gov.br/olinda/servico/PTAX/versao/v1/odata/"
    "CotacaoDolarDia(dataCotacao=@dataCotacao)"
    "?@dataCotacao='03-10-2026'&$format=json",
    timeout=15,
)
```
PTAX é divulgada em dois horários (compra/venda, boletim de abertura e fechamento) — confirme com o usuário qual
delas é a exigida para o cálculo (ex.: legislação fiscal geralmente pede a PTAX de venda do dia anterior à
operação, não a do próprio dia — confirme a regra aplicável antes de assumir).

## Feriados nacionais/estaduais/municipais
```
pip install workalendar
```
```python
from workalendar.america import BrazilBankCalendar
cal = BrazilBankCalendar()
print(cal.holidays(2026))                     # lista de feriados bancarios nacionais do ano
print(cal.is_working_day(date(2026, 4, 21)))  # Tiradentes - False
```
Feriados **estaduais e municipais** (ex.: aniversário da cidade, Revolução Constitucionalista em SP) não estão
cobertos por um calendário nacional único — para esses, é preciso uma lista específica por município/estado
(mantida separadamente, já que não há uma API pública unificada e confiável para todos os ~5.500 municípios
brasileiros); confirme com o usuário se o cálculo precisa considerar feriado municipal específico antes de omitir
essa possibilidade.

## Calcular dias úteis entre duas datas
```python
dias_uteis = cal.get_working_days_delta(date(2026, 3, 1), date(2026, 3, 31))
```
Para "somar N dias úteis a uma data" (comum em prazo de vencimento):
```python
data_vencimento = cal.add_working_days(date(2026, 3, 10), 5)
```

## Regras
- Nunca assuma que "feriado nacional" cobre tudo — confirme se o cálculo precisa de feriado bancário
  especificamente (que pode diferir de feriado nacional geral em alguns casos) ou municipal/estadual.
- PTAX: sempre confirme compra vs. venda e qual data (dia da operação vs. dia anterior) antes de aplicar num
  cálculo fiscal/contábil — a regra exata depende da legislação/norma específica aplicável ao caso.
- APIs do BACEN são públicas e gratuitas mas podem ter indisponibilidade pontual — trate erro de rede como
  esperado (retry com backoff, ver skill `chamar-apis-http`), não como falha definitiva.

## Arquivos desta skill
Nenhum script fixo — os trechos acima cobrem os casos mais comuns; adapte ao índice/período reais do usuário.

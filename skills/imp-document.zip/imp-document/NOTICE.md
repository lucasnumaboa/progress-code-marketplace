# Origem e licença

Esta skill é uma cópia, com as alterações listadas abaixo, de material de especialista com licença aberta.

- **Fonte:** https://github.com/pbakaus/impeccable
- **Arquivos de origem:** `.agents/skills/impeccable/reference/document.md`
- **Autor:** Paul Bakaus
- **Licença:** Apache-2.0 (texto completo em `LICENSE`)
- **Commit:** `b49177d32788f2dc585c42831d845dacf1ebed2c` (baixado em 2026-11-22)

## Alterações feitas

- Frontmatter (`name: imp-document` e `description`) acrescentado, porque o arquivo original não tinha.
- O arquivo era `reference/document.md` (um subcomando do Impeccable); virou o `SKILL.md` desta skill.
- `NOTICE.md` do repositório Impeccable incluído como `NOTICE-impeccable.md`, como pede a Apache-2.0.
- Fora isso, o texto do especialista está como no original (em inglês).

<#
.SYNOPSIS
    Captura a tela inteira ou um monitor especifico para um arquivo PNG, usando so .NET (sem instalar nada).
.PARAMETER Saida
    Caminho do arquivo .png de saida.
.PARAMETER Monitor
    Indice do monitor (1 = primario). Se omitido, captura todos os monitores juntos (area total).
.EXAMPLE
    powershell -File Capturar-Tela.ps1 -Saida "C:\temp\tela.png"
    powershell -File Capturar-Tela.ps1 -Saida "C:\temp\tela2.png" -Monitor 2
#>
param(
    [Parameter(Mandatory = $true)][string]$Saida,
    [int]$Monitor
)

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

if ($Monitor) {
    $telas = [System.Windows.Forms.Screen]::AllScreens
    if ($Monitor -lt 1 -or $Monitor -gt $telas.Count) {
        Write-Error "Monitor $Monitor invalido. Ha $($telas.Count) monitor(es) detectado(s)."
        exit 1
    }
    $area = $telas[$Monitor - 1].Bounds
} else {
    $area = [System.Windows.Forms.SystemInformation]::VirtualScreen
}

$bitmap = New-Object System.Drawing.Bitmap($area.Width, $area.Height)
$graphics = [System.Drawing.Graphics]::FromImage($bitmap)
$graphics.CopyFromScreen($area.Location, [System.Drawing.Point]::Empty, $area.Size)

$pastaSaida = Split-Path -Parent $Saida
if ($pastaSaida -and -not (Test-Path $pastaSaida)) {
    New-Item -ItemType Directory -Path $pastaSaida -Force | Out-Null
}
$bitmap.Save($Saida, [System.Drawing.Imaging.ImageFormat]::Png)

$graphics.Dispose()
$bitmap.Dispose()

Write-Host "Capturado: $Saida ($($area.Width)x$($area.Height))"

<#
.SYNOPSIS
    Encontra uma janela pelo titulo (correspondencia parcial), traz para frente e captura so a area dela
    para um PNG, usando so .NET + P/Invoke (sem instalar nada).
.PARAMETER Titulo
    Trecho do titulo da janela a procurar (case-insensitive).
.PARAMETER Saida
    Caminho do arquivo .png de saida.
.EXAMPLE
    powershell -File Capturar-Janela.ps1 -Titulo "Excel" -Saida "C:\temp\janela.png"
#>
param(
    [Parameter(Mandatory = $true)][string]$Titulo,
    [Parameter(Mandatory = $true)][string]$Saida
)

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

Add-Type @"
using System;
using System.Runtime.InteropServices;
using System.Text;
using System.Collections.Generic;

public class JanelaUtil {
    [DllImport("user32.dll")] public static extern bool EnumWindows(EnumWindowsProc lpEnumFunc, IntPtr lParam);
    [DllImport("user32.dll")] public static extern int GetWindowText(IntPtr hWnd, StringBuilder text, int count);
    [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr hWnd);
    [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr hWnd, out RECT rect);
    [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr hWnd);
    public delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);

    public struct RECT { public int Left, Top, Right, Bottom; }

    public static List<Tuple<IntPtr, string>> ListarJanelasVisiveis() {
        var lista = new List<Tuple<IntPtr, string>>();
        EnumWindows((hWnd, lParam) => {
            if (IsWindowVisible(hWnd)) {
                var sb = new StringBuilder(256);
                GetWindowText(hWnd, sb, 256);
                if (sb.Length > 0) lista.Add(Tuple.Create(hWnd, sb.ToString()));
            }
            return true;
        }, IntPtr.Zero);
        return lista;
    }
}
"@

$janelas = [JanelaUtil]::ListarJanelasVisiveis() | Where-Object { $_.Item2 -imatch [regex]::Escape($Titulo) }

if ($janelas.Count -eq 0) {
    Write-Error "Nenhuma janela visivel com titulo contendo '$Titulo'. Janelas abertas agora:"
    [JanelaUtil]::ListarJanelasVisiveis() | ForEach-Object { Write-Host "  - $($_.Item2)" }
    exit 1
}
if ($janelas.Count -gt 1) {
    Write-Warning "Mais de uma janela corresponde a '$Titulo':"
    $janelas | ForEach-Object { Write-Host "  - $($_.Item2)" }
    Write-Error "Seja mais especifico no -Titulo para escolher uma unica janela."
    exit 1
}

$hWnd = $janelas[0].Item1
[JanelaUtil]::SetForegroundWindow($hWnd) | Out-Null
Start-Sleep -Milliseconds 300

$rect = New-Object JanelaUtil+RECT
[JanelaUtil]::GetWindowRect($hWnd, [ref]$rect) | Out-Null
$largura = $rect.Right - $rect.Left
$altura = $rect.Bottom - $rect.Top

if ($largura -le 0 -or $altura -le 0) {
    Write-Error "Janela encontrada mas com tamanho invalido (minimizada?)."
    exit 1
}

$bitmap = New-Object System.Drawing.Bitmap($largura, $altura)
$graphics = [System.Drawing.Graphics]::FromImage($bitmap)
$graphics.CopyFromScreen($rect.Left, $rect.Top, 0, 0, (New-Object System.Drawing.Size($largura, $altura)))

$pastaSaida = Split-Path -Parent $Saida
if ($pastaSaida -and -not (Test-Path $pastaSaida)) {
    New-Item -ItemType Directory -Path $pastaSaida -Force | Out-Null
}
$bitmap.Save($Saida, [System.Drawing.Imaging.ImageFormat]::Png)

$graphics.Dispose()
$bitmap.Dispose()

Write-Host "Capturado: $Saida (janela '$($janelas[0].Item2)', ${largura}x${altura})"

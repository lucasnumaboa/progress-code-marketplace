---
name: capturar-tela-janelas
description: Captura a tela inteira, um monitor específico ou uma janela por título no Windows, usando só PowerShell + .NET (sem instalar nada), para alimentar a ferramenta de leitura de imagem. Use quando o usuário pedir para "tirar um print", "capturar a tela do programa X", "ver o que está na tela agora".
argument-hint: [tela inteira | janela "título"] [caminho de saída .png]
---

# Capturar tela e janelas específicas (Windows, sem instalar nada)

## Passo 1 — Tela inteira (ou um monitor específico)
```
powershell -File Capturar-Tela.ps1 -Saida "C:\temp\tela.png"
```
Use `-Monitor 2` para capturar um monitor específico em setup multi-monitor (índice conforme
`[System.Windows.Forms.Screen]::AllScreens`).

## Passo 2 — Janela por título
```
powershell -File Capturar-Janela.ps1 -Titulo "Excel" -Saida "C:\temp\janela.png"
```
Busca por correspondência parcial no título da janela (case-insensitive). Se houver mais de uma janela com título
parecido, o script lista todas e pede para escolher pelo handle exato em vez de adivinhar qual capturar.

## Passo 3 — Usar a captura
Depois de gerar o `.png`, use a ferramenta de leitura de imagem (`Read`/`ViewImage`) no caminho gerado para
descrever o que está na tela antes de decidir a próxima ação — não assuma o conteúdo da tela sem olhar.

## Regras
- Nunca capture e leia telas que possam conter dados sensíveis (senhas, dados de terceiros) sem que isso seja
  claramente o que o usuário pediu.
- Se a janela do título pedido não existir, o script avisa e lista as janelas abertas no momento — não invente que
  capturou algo.
- Espera de renderização: se a janela acabou de abrir/mudar, aguarde ~300-500ms antes de capturar
  (`Start-Sleep -Milliseconds 300`) para não pegar a tela em transição.

## Arquivos desta skill
- `scripts/Capturar-Tela.ps1` — tela inteira ou monitor específico.
- `scripts/Capturar-Janela.ps1` — janela por título (traz para frente antes de capturar).

---
name: compartilhamentos-permissoes-ntfs
description: Configura compartilhamentos de rede, permissões NTFS (icacls), herança, mapeamento de unidade e auditoria de quem tem acesso a quê, e como corrigir excesso de permissão. Use quando o usuário pedir para "compartilhar essa pasta na rede", "ver quem tem acesso a essa pasta", "essa permissão está bagunçada, como corrijo", "mapear essa unidade de rede".
argument-hint: [pasta/compartilhamento] [operação]
---

# Compartilhamentos, permissões NTFS e mapeamentos

## Duas camadas de permissão (a confusão mais comum)
Uma pasta compartilhada na rede tem **duas** permissões independentes que se combinam pela mais restritiva:
1. **Permissão de compartilhamento** (SMB share) — quem pode acessar `\\servidor\pasta` pela rede.
2. **Permissão NTFS** (do sistema de arquivos) — quem pode fazer o quê no arquivo/pasta, seja local ou via rede.
Se o compartilhamento libera "Todos: Leitura/Gravação" mas o NTFS só libera "Leitura" para o usuário, o resultado
final é **Leitura** (a mais restritiva vence). Ao diagnosticar "não consigo gravar", confira as duas camadas.

## Criar compartilhamento
```powershell
New-SmbShare -Name "Compartilhado" -Path "C:\Dados\Compartilhado" -FullAccess "DOMINIO\GrupoTI" -ReadAccess "DOMINIO\Usuarios"
Get-SmbShare
```

## Ver e ajustar permissão NTFS (icacls)
```powershell
icacls "C:\Dados\Compartilhado"                                    # lista permissoes atuais
icacls "C:\Dados\Compartilhado" /grant "DOMINIO\Fulano:(OI)(CI)M"   # M = Modificar, (OI)(CI) = heranca para subpastas e arquivos
icacls "C:\Dados\Compartilhado" /remove "DOMINIO\Fulano"
```
Letras comuns: `F` (controle total), `M` (modificar), `RX` (ler e executar), `R` (só leitura), `W` (só escrita).
`(OI)(CI)` = herda para Object Inherit (arquivos) e Container Inherit (subpastas) — sem isso, a permissão só vale
na pasta em si, não no que tem dentro.

## Auditoria: quem tem acesso a quê
```powershell
icacls "C:\Dados\Compartilhado" /T /C > relatorio_permissoes.txt   # /T = recursivo, /C = continua mesmo com erro em algum arquivo
```
Para uma visão mais legível por grupo/usuário sem repetir por arquivo, processe a saída do `icacls` ou use o módulo
`NTFSSecurity` (`Install-Module NTFSSecurity`) que devolve objetos em vez de texto.

## Corrigir excesso de permissão (o pedido mais comum e mais arriscado)
1. **Sempre gere o relatório de permissões atuais antes de remover qualquer coisa** (passo acima) — isso é o
   "backup" para reverter se remover algo que era necessário.
2. Identifique quem realmente precisa de acesso (confirme com o usuário/dono da pasta — não decida sozinho quem
   "não deveria" ter acesso).
3. Remova acesso de grupos amplos demais (`Todos`, `Usuários Autenticados`) que não deveriam estar ali, substituindo
   por um grupo específico.
4. Aplique com `/T` (recursivo) só depois de validar num subconjunto pequeno primeiro.

## Mapear unidade de rede
```powershell
New-PSDrive -Name "Z" -PSProvider FileSystem -Root "\\servidor\Compartilhado" -Persist
net use Z: \\servidor\Compartilhado /persistent:yes
```

## Regras
- Nunca remova permissão em massa sem relatório "antes" salvo — reverter uma remoção errada sem esse registro é
  muito mais difícil do que prevenir.
- Sempre confirme com o dono/responsável da pasta antes de alterar permissões de pastas compartilhadas por várias
  pessoas — o que parece "acesso desnecessário" de fora pode ser usado por um processo que você não conhece.
- `icacls` com `/T` numa árvore muito grande pode demorar e travar outros acessos concorrentes — avise antes de
  rodar em horário de pico.

## Arquivos desta skill
Nenhum script fixo — os comandos acima cobrem os casos mais comuns; adapte à pasta/permissão reais do usuário.

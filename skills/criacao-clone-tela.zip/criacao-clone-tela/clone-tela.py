# -*- coding: utf-8 -*-
"""
clone-tela.py — clona a ÁRVORE inteira de uma tela Progress/Datasul (container + viewers + browsers +
queries + includes + sub-programas específicos) a partir do catálogo ProgressAdmin, renomeando por token,
trocando tabela(s) e gerando o .df completo da(s) tabela(s) nova(s). Preserva CP850 byte a byte.

Uso:
  python clone-tela.py inventario --origem cd0704.w [--cliente CAMIL] [--profundidade 3]
  python clone-tela.py clonar --origem cd0704.w --novo escd0704 [--tabela emitente=es-emitente ...]
         [--campo es-emitente.ativo:logical:"Sim/Nao":Ativo] [--cliente CAMIL] [--saida escd0704]
         [--copiar nome.w ...] [--manter nome.w ...] [--area dados] [--area-indice indices]
         [--license manter|renomear] [--label "Manutenção Cliente"]

Somente biblioteca padrão. Roda a partir da pasta do projeto (cwd): grava originais em fontes-base/,
o clone em <saida>/, o relatório em docs/.
"""
import argparse, json, os, re, sys, time, urllib.parse, urllib.request
from pathlib import Path

BASE_URL = os.environ.get('PROGRESSADMIN_BASE_URL', 'https://progress.manerostream.com.br/api/external')
def _apikey():
    k = os.environ.get('PROGRESSADMIN_APIKEY')
    if not k:
        f = Path(__file__).with_name('apikey.txt')  # arquivo local, fora do git
        k = f.read_text(encoding='utf8').strip() if f.exists() else ''
    if not k:
        sys.exit('Defina PROGRESSADMIN_APIKEY ou crie apikey.txt ao lado do script com a chave da API do ProgressAdmin.')
    return k
APIKEY = _apikey()
CWD = Path.cwd()
FONTES = CWD / 'fontes-base'
DOCS = CWD / 'docs'
CACHE = CWD / '.progress' / 'api-cache'

# Objetos do framework/produto que NUNCA são copiados (ficam apontando para o padrão)
MANTER_RE = re.compile(
    r'^(src/adm/|adm/|panel/|utp/|include/|cdp/cdcfg|cdp/cd9900|cdp/cdapi|btb/|men/|adzoom/|adgo/|adqry/|'
    r'method/|template/|prgind/|utils/|ut-|i-|w-|sobre\.i|win-size\.i|cd0004i1\.i|cd0001i1\.i)', re.I)
SOURCE_EXT = ('.w', '.p', '.i', '.cls')

def log(msg=''):
    print(msg, flush=True)

class ApiError(Exception):
    def __init__(self, code, body, route):
        super().__init__(f'API {route} -> HTTP {code}: {body[:300]}')
        self.code, self.body, self.route = code, body, route

def tabela_df(cliente: str, tabela: str, banco: str | None = None):
    """Definição da tabela; resolve o 409 (tabela em mais de um banco) tentando cada banco. Retorna (resposta, bancos_com_a_tabela)."""
    params = {'cliente': cliente, 'tabela': tabela}
    if banco:
        params['banco'] = banco
    try:
        r = api('tabela-df', **params)
        return r, [r.get('banco')] if r.get('tabela') else []
    except ApiError as e:
        if e.code != 409:
            raise
        try:
            bancos = json.loads(e.body).get('bancos') or []
        except Exception:
            bancos = []
        found = []
        best = None
        for b in bancos:
            try:
                r = api('tabela-df', cliente=cliente, tabela=tabela, banco=b)
            except ApiError:
                continue
            if r.get('tabela'):
                found.append(b)
                if best is None or len(r['tabela'].get('campos') or []) > len(best['tabela'].get('campos') or []):
                    best = r
        return best or {}, found

def api(route, **params):
    params['apikey'] = APIKEY
    url = f"{BASE_URL}/{route}?" + urllib.parse.urlencode(params)
    CACHE.mkdir(parents=True, exist_ok=True)
    key = re.sub(r'[^\w.-]', '_', url.split('?')[0].rsplit('/', 1)[-1] + '_' + urllib.parse.urlencode({k: v for k, v in params.items() if k != 'apikey'}))[:150]
    cf = CACHE / f'clone_{key}.json'
    if cf.exists() and time.time() - cf.stat().st_mtime < 24 * 3600:
        return json.loads(cf.read_text(encoding='utf8'))
    req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0 (ProgressCode clone-tela)', 'Accept': 'application/json'})
    try:
        with urllib.request.urlopen(req, timeout=120) as r:
            data = json.loads(r.read().decode('utf8'))
    except urllib.error.HTTPError as e:
        body = e.read().decode('utf8', 'replace')
        raise ApiError(e.code, body, route)
    cf.write_text(json.dumps(data, ensure_ascii=False), encoding='utf8')
    return data

def to_bytes(content: str) -> bytes:
    """A API devolve os bytes CP850 decodificados como latin1: encode latin1 devolve o original."""
    try:
        return content.encode('latin1')
    except UnicodeEncodeError:
        return content.encode('cp850', 'replace')

def cp850(b: bytes) -> str:
    return b.decode('cp850', 'replace')

def fetch_source(name: str, cliente: str | None):
    """Busca um fonte pelo nome; grava em fontes-base/ (bytes originais). Retorna (bytes, filepath) ou (None, None)."""
    local = FONTES / name
    if local.exists():
        return local.read_bytes(), None
    try:
        r = api('search', filename=name, type='newer', **{'return': 'only'})
    except ApiError as e:
        log(f'AVISO: catálogo indisponível ao buscar {name} ({e}). Tratando como não encontrado; repita quando a API voltar.')
        return None, None
    files = r.get('files') or []
    if not files or not files[0].get('content'):
        return None, None
    f = files[0]
    b = to_bytes(f['content'])
    FONTES.mkdir(parents=True, exist_ok=True)
    local.write_bytes(b)
    return b, f.get('filepath')

def relacionamentos(name: str):
    try:
        r = api('relacionamentos', programa=name, direcao='chama')
    except Exception as e:
        return []
    return r.get('chama') or []

REF_RE = re.compile(r"""(?:RUN\s+(?:VALUE\s*\()?['"]?|\{|['"])([\w./\\-]+?\.(?:w|p|i|cls))\b""", re.I)

def refs_in_source(text: str):
    """Caminhos de objetos referenciados no fonte (RUN, {include}, strings de init-object)."""
    out = {}
    for m in REF_RE.finditer(text):
        p = m.group(1).replace('\\', '/')
        base = p.rsplit('/', 1)[-1].lower()
        if base.startswith('.'):
            continue
        out.setdefault(base, p)
    return out

def stem_of(name: str):
    return re.sub(r'\.[^.]+$', '', name).lower()

def is_specific(base: str, path: str, stem: str) -> bool:
    """Objeto específico do programa: carrega o nome/prefixo do programa e não é framework."""
    if MANTER_RE.search(path.lower()) and not base.lower().startswith(stem):
        return False
    b = stem_of(base)
    # específico = carrega o nome do programa (cd0704-v01, cd0704b, cd0704i1, cd0704-crm); outro programa da família (cd0401a) fica como padrão
    return b.startswith(stem)

TABLE_KW = r'(?:FOR\s+EACH|FOR\s+FIRST|FOR\s+LAST|FIND\s+FIRST|FIND\s+LAST|FIND\s+NEXT|FIND\s+PREV|FIND\s+CURRENT|FIND|CAN-FIND\s*\(\s*(?:FIRST\s+|LAST\s+)?|DEFINE\s+BUFFER\s+[\w-]+\s+FOR|BUFFER\s+[\w-]+\s+FOR|QUERY\s+[\w-]+\s+FOR|FOR\s+TABLE|BUFFER-COPY|BUFFER-COMPARE|RAW-TRANSFER|LIKE|CREATE|DELETE|RELEASE|AVAILABLE|AVAIL|VALIDATE|RECID\s*\(|ROWID\s*\(|OF|FOR)'

def tables_in_source(text: str):
    """Tabelas de banco usadas: contagem de 'tabela.campo' + evidência por palavra-chave/TABLES-IN-QUERY."""
    counts = {}
    for m in re.finditer(r'(?<![\w.-])([a-z][\w-]*[a-z0-9])\.([a-z][\w-]*)', text, re.I):
        t = m.group(1).lower()
        if t in ('this-procedure', 'session', 'file-info', 'error-status', 'frame', 'focus', 'self', 'target-procedure', 'source-procedure', 'adm-broker-hdl'):
            continue
        if re.match(r'^(mg|mov|ems|dth|emp)[a-z0-9]*$', t) and re.match(r'^[a-z][\w-]*$', m.group(2)) and len(m.group(2)) > 3:
            continue  # qualificador de banco ("mgadm.emitente"), não tabela
        counts[t] = counts.get(t, 0) + 1
    evidence = set()
    for m in re.finditer(TABLE_KW + r'\s+([a-z][\w-]*)', text, re.I):
        evidence.add(m.group(1).lower())
    for m in re.finditer(r'&Scoped-define\s+(?:TABLES-IN-QUERY|INTERNAL-TABLES|EXTERNAL-TABLES|FIRST-EXTERNAL-TABLE|ENABLED-TABLES|FIRST-ENABLED-TABLE)[\w-]*\s+([^\r\n]+)', text, re.I):
        for tok in re.split(r'[\s,]+', m.group(1).strip()):
            t = tok.rsplit('.', 1)[-1].lower()   # "mgadm.emitente" -> emitente
            if re.match(r'^[a-z][\w-]*$', t):
                evidence.add(t)
    for m in re.finditer(r'_TblList\s+"([^"]+)"', text):
        for t in m.group(1).split(','):
            evidence.add(t.strip().split('.')[-1].lower())
    tables = {}
    for t, n in counts.items():
        if t in evidence or n >= 3:
            if t.startswith('tt-') or t.startswith('tt_') or t.startswith('b-') or t.startswith('bf-') or t.startswith('h_') or t.startswith('h-'):
                continue
            tables[t] = n
    return tables

def inventario(origem: str, cliente: str | None, profundidade: int, forced_copiar=(), forced_manter=()):
    stem = stem_of(origem)
    tree = {}   # base -> {path, tipo, acao, motivo, depth, filepath}
    queue = [(origem.lower(), origem, 0)]
    seen = set()
    sources = {}
    while queue:
        base, path, depth = queue.pop(0)
        if base in seen:
            continue
        seen.add(base)
        b, fp = fetch_source(base, cliente)
        if b is None:
            tree[base] = {'path': path, 'acao': 'NAO-ENCONTRADO', 'motivo': 'não retornou do catálogo', 'depth': depth}
            continue
        text = cp850(b)
        sources[base] = text
        tree[base] = {'path': path, 'acao': 'COPIAR', 'motivo': 'container' if depth == 0 else 'específico do programa', 'depth': depth, 'filepath': fp}
        if depth >= profundidade:
            continue
        children = {}
        for c in relacionamentos(base):
            nm = str(c.get('programa') or '').lower()
            ref = str(c.get('referencia') or nm).replace('\\', '/').lower()
            if nm and nm.endswith(SOURCE_EXT):
                children[nm.rsplit('/', 1)[-1]] = ref
        for cb, cp in refs_in_source(text).items():
            children.setdefault(cb, cp)
        for cb, cp in children.items():
            if cb == base:
                continue
            forced_c = cb in forced_copiar
            forced_m = cb in forced_manter
            if forced_m or (not forced_c and not is_specific(cb, cp, stem)):
                if cb not in tree:
                    tree[cb] = {'path': cp, 'acao': 'MANTER', 'motivo': 'framework/produto padrão' if not forced_m else 'forçado (--manter)', 'depth': depth + 1}
                continue
            queue.append((cb, cp, depth + 1))
    # tabelas usadas pelos objetos copiados
    tables = {}
    for base, text in sources.items():
        for t, n in tables_in_source(text).items():
            tables.setdefault(t, {'refs': 0, 'arquivos': []})
            tables[t]['refs'] += n
            tables[t]['arquivos'].append(base)
    # objetos MANTER de consulta/zoom que usam essas tabelas (aviso): lê o fonte deles uma vez
    for base, info in list(tree.items()):
        if info['acao'] != 'MANTER' or not re.search(r'^(adqry|adzoom|adgo)/', info['path'].lower()):
            continue
        b, _ = fetch_source(base, cliente)
        if b:
            used = tables_in_source(cp850(b))
            info['tabelas'] = sorted(t for t in used if t in tables)
    # classificação: temp-table / buffer (definidos no fonte) x tabela de banco (confirmada no dicionário) x desconhecida
    temps, buffers = set(), {}
    for text in sources.values():
        for m in re.finditer(r'DEF(?:INE)?\s+(?:NEW\s+)?(?:GLOBAL\s+)?(?:SHARED\s+)?(?:TEMP-TABLE|WORK-TABLE|WORKFILE)\s+([\w-]+)', text, re.I):
            temps.add(m.group(1).lower())
        for m in re.finditer(r'DEF(?:INE)?\s+(?:NEW\s+)?(?:SHARED\s+)?BUFFER\s+([\w-]+)\s+FOR\s+(?:TEMP-TABLE\s+)?([\w.-]+)', text, re.I):
            buffers[m.group(1).lower()] = m.group(2).lower().rsplit('.', 1)[-1]
    for t, info in tables.items():
        real = buffers.get(t)
        if t in temps or (real and (real in temps or real.startswith(('tt-', 'tt_')))):
            info['tipo'] = 'temp-table'
        elif t in buffers:
            info['tipo'] = f'buffer de {buffers[t]}'
            info['tabela_real'] = buffers[t]
        else:
            info['tipo'] = 'banco?'
    if cliente:
        for t, info in tables.items():
            if info['tipo'] == 'temp-table':
                info['no_dicionario'] = False
                continue
            alvo = info.get('tabela_real', t)
            try:
                r, bancos = tabela_df(cliente, alvo)
                tb = r.get('tabela')
                info['no_dicionario'] = bool(tb)
                info['campos_dicionario'] = len((tb or {}).get('campos') or [])
                info['banco'] = ', '.join(bancos) if bancos else r.get('banco')
                if info['tipo'] == 'banco?':
                    info['tipo'] = 'banco' if tb else 'desconhecida (não está no dicionário: handle, include ou temp-table externa)'
            except Exception as e:
                info['no_dicionario'] = None
                info['erro'] = str(e)[:120]
    return {'origem': origem, 'stem': stem, 'cliente': cliente, 'arvore': tree, 'tabelas': tables}

def tabela_de_banco(inv, nome: str) -> bool:
    """True se o inventário confirmou a tabela no dicionário do cliente (não é temp-table/buffer/desconhecida)."""
    info = inv['tabelas'].get(nome.lower())
    return bool(info and info.get('no_dicionario') and info.get('tipo') == 'banco')

def print_inventario(inv):
    log(f"# Inventário de {inv['origem']}  (cliente: {inv['cliente'] or 'não informado'})\n")
    log('| Objeto | Caminho | Ação | Motivo |')
    log('|---|---|---|---|')
    for base, i in sorted(inv['arvore'].items(), key=lambda kv: (kv[1]['acao'] != 'COPIAR', kv[1]['depth'], kv[0])):
        extra = f" — usa tabelas: {', '.join(i['tabelas'])}" if i.get('tabelas') else ''
        log(f"| {base} | {i['path']} | {i['acao']} | {i['motivo']}{extra} |")
    itens = sorted(inv['tabelas'].items(), key=lambda kv: -kv[1]['refs'])
    banco = [(t, i) for t, i in itens if i.get('tipo') in ('banco', 'banco?') or str(i.get('tipo', '')).startswith('buffer')]
    temps = [(t, i) for t, i in itens if i.get('tipo') == 'temp-table']
    desc = [(t, i) for t, i in itens if str(i.get('tipo', '')).startswith('desconhecida')]
    log('\n## Tabelas de BANCO usadas (candidatas a --tabela)')
    log('| Tabela | tipo | refs | arquivos | dicionário |')
    log('|---|---|---|---|---|')
    for t, info in banco:
        nd = info.get('no_dicionario')
        nd_s = 'não validado (informe --cliente)' if nd is None else (f"sim ({info.get('campos_dicionario')} campos, {info.get('banco')})" if nd else 'NÃO')
        log(f"| {t} | {info.get('tipo')} | {info['refs']} | {', '.join(info['arquivos'])} | {nd_s} |")
    if temps:
        log('\nTemp-tables / work-tables definidas nos fontes (NÃO são tabelas de banco; não use em --tabela): ' + ', '.join(t for t, _ in temps))
    if desc:
        log('\nNomes com ponto que NÃO existem no dicionário (handles, includes, temp-tables externas — ignorar): ' + ', '.join(f'{t} ({i["refs"]})' for t, i in desc))
    manter_tab = [(b, i['tabelas']) for b, i in inv['arvore'].items() if i.get('tabelas')]
    if manter_tab:
        log('\nAVISO: objetos padrão (não copiados) que consultam tabelas usadas pela tela — se uma dessas tabelas for trocada, eles continuam na tabela ORIGINAL:')
        for b, ts in manter_tab:
            log(f"  - {b}: {', '.join(ts)}")

# ---------------------------------------------------------------- renomeação
def case_like(src: str, new: str) -> str:
    if src.isupper():
        return new.upper()
    if src[:1].isupper():
        return new[:1].upper() + new[1:]
    return new

def rename_tokens(text: str, pairs):
    """pairs: [(old_base, new_base)] sem extensão, do mais longo para o mais curto. Token = não precedido por [\\w] nem seguido por [\\w-]."""
    for old, new in pairs:
        pat = re.compile(r'(?<![\w])' + re.escape(old) + r'(?![\w-])', re.I)
        text = pat.sub(lambda m: case_like(m.group(0), new), text)
    return text

def swap_tables(text: str, old: str, new: str):
    n = 0
    def sub(pat, repl):
        nonlocal text, n
        text, k = re.subn(pat, repl, text, flags=re.I)
        n += k
    b_old = re.escape(old)
    # tabela.campo
    sub(r'(?<![\w.-])' + b_old + r'(?=\.[a-z])', new)
    # palavras-chave seguidas da tabela
    sub(r'(' + TABLE_KW + r'\s*)(?<![\w-])' + b_old + r'(?![\w-])', lambda m: m.group(1) + new)
    # argumentos de include {prog.i ... emitente ... "emitente"}, parâmetros de preprocessador (&tabela=emitente)
    sub(r'(\{[^{}]*?(?<![\w.-]))' + b_old + r'(?=[\s"\'}])', lambda m: m.group(1) + new)
    sub(r'(=\s*)' + b_old + r'(?![\w-])', lambda m: m.group(1) + new)
    # literal de string igual ao nome da tabela ('emitente' / "emitente"), fora de comentário
    sub(r"""(['"])""" + b_old + r"""\1""", lambda m: m.group(1) + new + m.group(1))
    # listas do AppBuilder: qualquer &Scoped-define *TABLE* / *FIELDS*
    sub(r'(&Scoped-define\s+[\w-]*(?:TABLE|FIELDS)[\w-]*\s+[^\r\n]*?(?<![\w.-]))' + b_old + r'(?![\w-])', lambda m: m.group(1) + new)
    # WHERE tabela (sem ponto, ex.: "OF emitente", "EACH emitente NO-LOCK") já coberto; listas do AppBuilder:
    sub(r'(&Scoped-define\s+(?:TABLES-IN-QUERY|INTERNAL-TABLES|EXTERNAL-TABLES|FIRST-EXTERNAL-TABLE|ENABLED-TABLES|FIRST-ENABLED-TABLE|ADM-CREATE-FIELDS|ENABLED-FIELDS|DISPLAYED-FIELDS)[^\r\n]*?(?<![\w.-]))' + b_old + r'(?![\w-])', lambda m: m.group(1) + new)
    sub(r'(_TblList\s+"[^"]*?)(?<![\w-])' + b_old + r'(?=["\.,])', lambda m: m.group(1) + new)
    sub(r'("(?:[\w-]+\.)?)' + b_old + r'("\s*(?:,|\)))', lambda m: m.group(1) + new + m.group(2))  # strings "mgcad.emitente"
    return text, n

# ---------------------------------------------------------------- .df
def df_field(tab_new: str, c: dict, pos: int):
    tp = str(c.get('data_type') or c.get('tipo') or 'character').lower()
    fmt = c.get('formato') or c.get('format') or {'character': 'x(20)', 'integer': '->>>>>>>>9', 'decimal': '->>,>>>,>>9.99', 'logical': 'yes/no', 'date': '99/99/9999', 'int64': '->>>>>>>>>>>>9', 'datetime': '99/99/9999 HH:MM:SS.SSS'}.get(tp, 'x(20)')
    init = c.get('initial') if c.get('initial') is not None else c.get('valor_inicial')
    if init is None or init == '':
        init = {'character': '""', 'integer': '"0"', 'int64': '"0"', 'decimal': '"0"', 'logical': '"no"', 'date': '?', 'datetime': '?', 'datetime-tz': '?'}.get(tp, '""')
    else:
        init = str(init) if str(init).startswith('"') or str(init) == '?' else f'"{init}"'
    lines = [f'ADD FIELD "{c["nome"]}" OF "{tab_new}" AS {tp}']
    if c.get('descricao'):
        lines.append(f'  DESCRIPTION "{str(c["descricao"]).replace(chr(34), chr(39))}"')
    lines.append(f'  FORMAT "{fmt}"')
    lines.append(f'  INITIAL {init}')
    if c.get('label'):
        lines.append(f'  LABEL "{str(c["label"]).replace(chr(34), chr(39))}"')
    lines.append(f'  POSITION {pos}')
    mw = c.get('max_width') or c.get('max-width')
    if not mw:
        m = re.search(r'x\((\d+)\)', str(fmt), re.I)
        mw = {'integer': 4, 'int64': 8, 'decimal': 17, 'logical': 1, 'date': 4, 'datetime': 8, 'datetime-tz': 12}.get(tp, (2 * int(m.group(1))) if m else 40)
        ext = c.get('extent')
        if ext and int(ext) > 1:
            mw = int(mw) * int(ext)
    lines.append(f'  MAX-WIDTH {mw}')
    if c.get('column_label') or c.get('column-label'):
        lines.append(f'  COLUMN-LABEL "{c.get("column_label") or c.get("column-label")}"')
    if c.get('help'):
        lines.append(f'  HELP "{str(c["help"]).replace(chr(34), chr(39))}"')
    if c.get('view_as') or c.get('view-as'):
        lines.append(f'  VIEW-AS "{c.get("view_as") or c.get("view-as")}"')
    if tp == 'decimal':
        lines.append(f'  DECIMALS {c.get("decimals") if c.get("decimals") is not None else 2}')
    ext = c.get('extent')
    if ext and int(ext) > 1:
        lines.append(f'  EXTENT {int(ext)}')
    lines.append(f'  ORDER {c.get("ordem") or c.get("order") or pos * 10}')
    if c.get('mandatory'):
        lines.append('  MANDATORY')
    if c.get('case_sensitive') or c.get('case-sensitive'):
        lines.append('  CASE-SENSITIVE')
    return '\n'.join(lines)

def parse_campo(spec: str):
    """nome:tipo[:formato[:label[:initial]]] — ex.: es-emitente.ativo:logical:Sim/Nao:Ativo:yes"""
    parts = spec.split(':')
    full = parts[0]
    tab, nome = (full.split('.', 1) + [None])[:2] if '.' in full else (None, full)
    tp = parts[1] if len(parts) > 1 else 'character'
    return {'tabela': tab, 'nome': nome, 'data_type': tp, 'formato': parts[2] if len(parts) > 2 else None, 'label': parts[3] if len(parts) > 3 else nome, 'initial': parts[4] if len(parts) > 4 else None, 'view_as': 'view-as toggle-box' if tp == 'logical' else None}

def build_df(cliente: str, old: str, new: str, extra_fields, area: str, area_idx: str, label: str | None, banco: str | None = None):
    r, bancos = tabela_df(cliente, old, banco)
    tb = r.get('tabela')
    if not tb:
        raise SystemExit(f'Tabela {old} não encontrada no dicionário do cliente {cliente} (/tabela-df). Use /tabelas-df?q= para conferir o nome.')
    if len(bancos) > 1 and not banco:
        log(f'AVISO: {old} existe em mais de um banco ({", ".join(bancos)}); usando o de mais campos ({r.get("banco")}). Informe --banco para escolher.')
    campos = tb.get('campos') or []
    area = tb.get('area') or area
    blocks = [f'ADD TABLE "{new}"\n  AREA "{area}"\n  LABEL "{label or tb.get("label") or new}"\n  DESCRIPTION "Cópia específica de {old} ({tb.get("label") or ""})"\n  DUMP-NAME "{re.sub(r"[^a-z0-9]", "", new.lower())[:8]}"']
    pos = 2
    for c in campos:
        blocks.append(df_field(new, c, pos))
        pos += 1
    for f in extra_fields:
        if f['tabela'] and f['tabela'].lower() != new.lower():
            continue
        blocks.append(df_field(new, f, pos))
        pos += 1
    for ix in tb.get('indices') or []:
        lines = [f'ADD INDEX "{ix["nome"]}" ON "{new}"', f'  AREA "{area_idx}"']
        if ix.get('unique'):
            lines.append('  UNIQUE')
        if ix.get('primary') or ix.get('primario'):
            lines.append('  PRIMARY')
        for cf in sorted(ix.get('campos') or [], key=lambda x: x.get('ordem') or 0):
            lines.append(f'  INDEX-FIELD "{cf["nome"]}" {"DESCENDING" if str(cf.get("direcao", "ASC")).upper().startswith("DESC") else "ASCENDING"}')
        blocks.append('\n'.join(lines))
    body = '\n\n'.join(blocks) + '\n\n.\nPSC\ncpstream=ibm850\n.\n'
    rollback = f'DROP TABLE "{new}"\n\n.\nPSC\ncpstream=ibm850\n.\n'
    return body.replace('\n', '\r\n'), rollback.replace('\n', '\r\n'), len(campos), len(tb.get('indices') or []), r.get('banco')

# ---------------------------------------------------------------- clonar
def clonar(a):
    origem = a.origem.lower()
    stem = stem_of(origem)
    novo = a.novo.lower()
    inv = inventario(origem, a.cliente, a.profundidade, set(x.lower() for x in a.copiar), set(x.lower() for x in a.manter))
    print_inventario(inv)
    copiar = {b: i for b, i in inv['arvore'].items() if i['acao'] == 'COPIAR'}
    if not copiar:
        raise SystemExit('Nada para copiar: o programa de origem não foi encontrado no catálogo.')
    # mapa de renomeação (por base sem extensão), do nome mais longo para o mais curto
    pairs = []
    for base in copiar:
        ob = stem_of(base)
        nb = (novo + ob[len(stem):]) if ob.startswith(stem) else ('es' + ob if not ob.startswith('es') else ob)
        pairs.append((ob, nb))
    pairs.sort(key=lambda p: -len(p[0]))
    tab_pairs = [tuple(t.split('=', 1)) for t in a.tabela]
    for old, new in tab_pairs:
        if not a.cliente:
            raise SystemExit(f'--tabela {old}={new}: informe --cliente para validar a tabela no dicionário e copiar a estrutura.')
        if not tabela_de_banco(inv, old) and not a.forcar:
            info = inv['tabelas'].get(old.lower())
            motivo = 'não aparece nos fontes copiados' if not info else f"classificada como {info.get('tipo')}"
            raise SystemExit(f'--tabela {old}: não é uma tabela de banco confirmada no dicionário do cliente ({motivo}). Escolha uma das "Tabelas de BANCO usadas" do inventário ou use --forcar se tiver certeza.')
    extra = [parse_campo(c) for c in a.campo]
    saida = CWD / (a.saida or novo)
    report = ['# Clone ' + origem + ' -> ' + novo, '', '| Original | Novo | Pasta | Renomeações | Trocas de tabela |', '|---|---|---|---|---|']
    outputs = {}
    for base, info in copiar.items():
        raw = (FONTES / base).read_bytes()
        text = cp850(raw)
        new_base = dict(pairs)[stem_of(base)] + os.path.splitext(base)[1]
        before = text
        text = rename_tokens(text, pairs)
        if a.license == 'manter':
            text = re.sub(r'(\{include/i-license-manager\.i\s+)' + re.escape(novo) + r'\b', lambda m: m.group(1) + stem.upper(), text, flags=re.I)
        ren = sum(1 for _ in re.finditer(re.escape(novo), text, re.I)) - sum(1 for _ in re.finditer(re.escape(novo), before, re.I))
        swaps = 0
        for old, new in tab_pairs:
            text, k = swap_tables(text, old, new)
            swaps += k
        folder = info['path'].replace('\\', '/').rsplit('/', 1)[0] if '/' in info['path'].replace('\\', '/') else ('cdp' if base == origem or info['depth'] == 0 else '')
        if base == origem and folder == '':
            fp = str(info.get('filepath') or '').replace('\\', '/')
            folder = fp.rsplit('/', 2)[-2] if fp.count('/') >= 2 else 'cdp'
        target = saida / folder / new_base
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(text.encode('cp850', 'replace'))
        outputs[new_base] = (target, text)
        report.append(f'| {base} | {new_base} | {folder or "."} | {ren} | {swaps} |')
    # .df das tabelas novas
    dfs = []
    for old, new in tab_pairs:
        if not a.cliente:
            raise SystemExit('Para gerar o .df da tabela nova informe --cliente (dicionário de onde copiar a estrutura).')
        body, rollback, nc, ni, banco = build_df(a.cliente, old, new, extra, a.area, a.area_indice, None, a.banco)
        (saida / f'{new}.df').write_bytes(body.encode('cp850', 'replace'))
        (saida / f'{new}-rollback.df').write_bytes(rollback.encode('cp850', 'replace'))
        dfs.append((old, new, nc, ni, banco))
    # verificação
    leftovers = {}
    for nb, (target, text) in outputs.items():
        code = re.sub(r'/\*.*?\*/', ' ', text, flags=re.S)   # ignora comentários
        hits = [m.group(0) for m in re.finditer(r'(?<![\w])' + re.escape(stem) + r'(?![\w-])', code, re.I)]
        for old, _ in tab_pairs:
            # 'use-index emitente' é nome de ÍNDICE de outra tabela, não a tabela
            hits += [m.group(0) for m in re.finditer(r'(?<!use-index\s)(?<![\w.-])' + re.escape(old) + r'(?=\.[a-z]|[\s,)]|$)', code, re.I)]
        if hits:
            leftovers[nb] = len(hits)
    used_fields = {}
    for old, new in tab_pairs:
        used = set()
        for nb, (target, text) in outputs.items():
            used |= set(m.group(1).lower() for m in re.finditer(r'(?<![\w-])' + re.escape(new) + r'\.([\w-]+)', text, re.I))
        r, _ = tabela_df(a.cliente, old, a.banco)
        have = set(c['nome'].lower() for c in (r.get('tabela') or {}).get('campos') or []) | set(f['nome'].lower() for f in extra if not f['tabela'] or f['tabela'].lower() == new.lower())
        used_fields[new] = sorted(used - have)
    report += ['', '## Tabelas novas (.df)']
    for old, new, nc, ni, banco in dfs:
        report.append(f'- `{new}.df`: cópia de `{old}` ({banco}) com {nc} campos e {ni} índices + {sum(1 for f in extra if not f["tabela"] or f["tabela"].lower() == new.lower())} campo(s) novo(s); rollback em `{new}-rollback.df`. AREA "{a.area}" / "{a.area_indice}" — A CONFIRMAR com o ambiente.')
        if used_fields.get(new):
            report.append(f'  - ATENÇÃO: campos usados nos fontes e ausentes no .df: {", ".join(used_fields[new])}')
        else:
            report.append('  - Todos os campos usados pelos fontes existem no .df.')
    report += ['', '## Verificação']
    report.append('- Tokens antigos remanescentes: ' + (', '.join(f'{k} ({v})' for k, v in leftovers.items()) if leftovers else 'nenhum'))
    manter = [(b, i) for b, i in inv['arvore'].items() if i['acao'] == 'MANTER']
    report.append(f'- Objetos mantidos apontando para o padrão: {len(manter)} (framework/produto). Os que consultam tabela trocada:')
    for b, i in manter:
        if i.get('tabelas') and any(t == old for t in i['tabelas'] for old, _ in tab_pairs):
            report.append(f'  - {b} usa {", ".join(i["tabelas"])} — continua na tabela ORIGINAL (query/zoom padrão). Decidir: criar cópia específica ou aceitar.')
    nf = [b for b, i in inv['arvore'].items() if i['acao'] == 'NAO-ENCONTRADO']
    if nf:
        report.append('- Não encontrados no catálogo: ' + ', '.join(nf))
    report += ['', '## Próximos passos do agente', '1. Se houver campo novo de tela, adicionar o widget no viewer adequado (Edit) — o script não mexe em layout.', '2. Renderizar com a skill AppBuilder-Web (/appbuilder-render-upload enviando container + todos os arquivos do clone).', '3. Entregar: arquivos, .df e rollback, o que o usuário compila/carrega e testa.']
    DOCS.mkdir(parents=True, exist_ok=True)
    rep = '\n'.join(report)
    (DOCS / f'clone-{novo}.md').write_text(rep, encoding='utf8')
    log('\n' + rep)
    log(f'\nRelatório gravado em docs/clone-{novo}.md; arquivos em {saida}')

# ---------------------------------------------------------------- render (AppBuilder-Web upload)
def render(a):
    """Envia container + viewers/browsers/includes para /appbuilder-render-upload (convertidos para UTF-8, que é o que o
    servidor espera no upload; os arquivos em disco continuam CP850) e baixa os PNGs em docs/."""
    import uuid
    pasta = Path(a.pasta)
    files = sorted([p for p in pasta.glob('*') if p.suffix.lower() in ('.w', '.i', '.p')])
    if not files:
        raise SystemExit(f'Nenhum .w/.i/.p em {pasta}')
    boundary = '----clonetela' + uuid.uuid4().hex
    body = bytearray()
    def field(name, value):
        body.extend(f'--{boundary}\r\nContent-Disposition: form-data; name="{name}"\r\n\r\n{value}\r\n'.encode('utf8'))
    for p in files:
        content = p.read_bytes()
        try:
            content = content.decode('cp850').encode('utf8')
        except Exception:
            pass
        body.extend(f'--{boundary}\r\nContent-Disposition: form-data; name="arquivo"; filename="{p.name}"\r\nContent-Type: text/plain\r\n\r\n'.encode('utf8'))
        body.extend(content)
        body.extend(b'\r\n')
    field('entrada', a.entrada)
    field('scale', str(a.scale))
    if a.all:
        field('all', 'true')
    field('apikey', APIKEY)
    body.extend(f'--{boundary}--\r\n'.encode('utf8'))
    req = urllib.request.Request(f'{BASE_URL}/appbuilder-render-upload?apikey={APIKEY}', data=bytes(body), method='POST',
                                 headers={'Content-Type': f'multipart/form-data; boundary={boundary}', 'User-Agent': 'Mozilla/5.0 (ProgressCode clone-tela)'})
    try:
        with urllib.request.urlopen(req, timeout=300) as r:
            res = json.loads(r.read().decode('utf8'))
    except urllib.error.HTTPError as e:
        raise SystemExit(f'render-upload -> HTTP {e.code}: {e.read().decode("utf8", "replace")[:300]}')
    if not res.get('success'):
        raise SystemExit(f'render falhou: {json.dumps(res, ensure_ascii=False)[:500]}')
    DOCS.mkdir(parents=True, exist_ok=True)
    saved = []
    for png in res.get('pngs') or []:
        url = f'{BASE_URL}/appbuilder-imagem?' + urllib.parse.urlencode({'apikey': APIKEY, 'render_id': res['renderId'], 'arquivo': png})
        req2 = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0 (ProgressCode clone-tela)'})
        with urllib.request.urlopen(req2, timeout=300) as r:
            base = a.prefixo or Path(a.entrada).stem
            pag = re.search(r'-pag\d+', png)
            out = DOCS / (f'{base}{pag.group(0)}.png' if pag else f'{base}.png')
            out.write_bytes(r.read())
            saved.append(str(out.relative_to(CWD)))
    log(f"# Render de {a.entrada} ({len(files)} arquivos enviados)")
    log(f"- resumo: {res.get('resumo')}")
    for w in res.get('avisos') or []:
        log(f'- AVISO: {w}')
    for e in res.get('erros') or []:
        log(f'- ERRO: {e}')
    log('- imagens: ' + ', '.join(saved))
    log('Abra cada PNG com ViewImage e confira: acentos, abas, campos, campo novo. "objeto X não encontrado" para item clonado = clone incompleto; para adqry/adzoom padrão é esperado.')

def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest='cmd', required=True)
    p1 = sub.add_parser('inventario')
    p1.add_argument('--origem', required=True)
    p1.add_argument('--cliente')
    p1.add_argument('--profundidade', type=int, default=3)
    p1.add_argument('--copiar', nargs='*', default=[])
    p1.add_argument('--manter', nargs='*', default=[])
    p2 = sub.add_parser('clonar')
    p2.add_argument('--origem', required=True)
    p2.add_argument('--novo', required=True)
    p2.add_argument('--cliente')
    p2.add_argument('--banco', help='banco do dicionário quando a tabela existe em mais de um (ex.: mgcad)')
    p2.add_argument('--forcar', action='store_true', help='aceita --tabela mesmo sem confirmação no dicionário')
    p2.add_argument('--tabela', nargs='*', default=[], help='antiga=nova (pode repetir)')
    p2.add_argument('--campo', nargs='*', default=[], help='tabela.nome:tipo[:formato[:label[:initial]]]')
    p2.add_argument('--saida')
    p2.add_argument('--copiar', nargs='*', default=[])
    p2.add_argument('--manter', nargs='*', default=[])
    p2.add_argument('--area', default='dados')
    p2.add_argument('--area-indice', default='indices')
    p2.add_argument('--license', choices=['manter', 'renomear'], default='manter')
    p2.add_argument('--profundidade', type=int, default=3)
    p3 = sub.add_parser('render', help='renderiza pelo AppBuilder-Web (upload) uma pasta de fontes do clone')
    p3.add_argument('--pasta', required=True, help='pasta com container + viewers/browsers/includes (ex.: escd0704/cdp)')
    p3.add_argument('--entrada', required=True, help='nome do .w principal (ex.: escd0704.w)')
    p3.add_argument('--scale', default='2')
    p3.add_argument('--all', action='store_true', help='um PNG por aba')
    p3.add_argument('--prefixo', help='prefixo dos PNGs em docs/ (padrão: nome do container)')
    a = ap.parse_args()
    if a.cmd == 'render':
        render(a)
        return
    if a.cmd == 'inventario':
        inv = inventario(a.origem.lower(), a.cliente, a.profundidade, set(x.lower() for x in a.copiar), set(x.lower() for x in a.manter))
        print_inventario(inv)
        DOCS.mkdir(parents=True, exist_ok=True)
        (DOCS / f'inventario-{stem_of(a.origem)}.json').write_text(json.dumps(inv, ensure_ascii=False, indent=1), encoding='utf8')
        log(f'\nJSON em docs/inventario-{stem_of(a.origem)}.json')
    else:
        clonar(a)

if __name__ == '__main__':
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    main()

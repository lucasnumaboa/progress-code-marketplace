---
name: criacao-clone-tela
description: Clona a ÁRVORE inteira de uma tela Progress/Datasul (container .w + viewers + browsers + includes + sub-programas específicos) a partir do catálogo ProgressAdmin, renomeando por token, trocando tabela(s) e gerando o .df completo da(s) tabela(s) nova(s), tudo em CP850, com um script determinístico. Use sempre que o pedido for "crie X igual/parecido/baseado na tela Y", "copie a tela Y como X", "clone com tabela nova" — em vez de copiar e renomear fontes à mão.
---

# criacao-clone-tela — clone determinístico de tela Datasul

Copiar uma tela é trabalho mecânico e propenso a erro (encoding, substituição parcial, viewer
esquecido, .df incompleto). Este script faz a parte mecânica; você decide os parâmetros e faz só
as edições pequenas depois.

Script: `clone-tela.py` (Python 3, só biblioteca padrão), nesta pasta. Rode SEMPRE a partir da
**pasta do projeto** (cwd), pois ele grava em `fontes-base/`, `docs/` e na pasta de saída.

```powershell
python "<pasta-desta-skill>\clone-tela.py" <comando> ...
```
O caminho desta pasta aparece no cabeçalho quando a skill é carregada.

## Passo 1 — inventário (sempre primeiro)

```powershell
python "<skill>\clone-tela.py" inventario --origem cd0704.w --cliente CAMIL
```

Devolve duas tabelas e um aviso:
1. **Árvore**: cada objeto encontrado (catálogo `/relacionamentos` + varredura do fonte) com ação
   **COPIAR** (carrega o nome do programa: `cd0704-v01.w`, `cd0704b.w`, `cd0704i1.i`, `cd0704-crm.p`)
   ou **MANTER** (framework/produto: `src/adm`, `panel/`, `utp/`, `include/i-*`, `cdp/cdcfg*`,
   `adqry/adzoom/adgo`, outros programas da família como `cd0401a.w`). `NAO-ENCONTRADO` = o
   catálogo não tem o arquivo (relate ao usuário).
2. **Tabelas de BANCO usadas** pelos objetos COPIAR, já validadas: cada nome com ponto é
   classificado como `banco` (confirmado em `/tabela-df` do cliente), `buffer de X` (DEFINE BUFFER
   no fonte → a tabela real é X), `temp-table` (DEFINE TEMP-TABLE/WORK-TABLE no fonte) ou
   `desconhecida` (não está no dicionário: handle, include, temp-table externa). Só as de `banco`
   entram na tabela principal e são aceitas em `--tabela`; temp-tables e desconhecidas são listadas
   à parte só para você saber que foram descartadas. Sem `--cliente` a validação não roda
   ("não validado") — informe sempre o cliente quando houver tabela nova.
3. **Aviso**: objetos padrão (query/zoom) que consultam essas tabelas — se você trocar a tabela,
   eles continuam na ORIGINAL. Isso é decisão de negócio: mostre ao usuário.

Também grava `docs/inventario-<stem>.json`. Use `--copiar nome` / `--manter nome` para forçar a
classificação de um objeto.

## Passo 2 — decidir (você, com o pedido do usuário)

- **Nome novo**: o que o usuário pediu; sem nome, padrão `es` + original (`escd0704`) e "A CONFIRMAR".
- **Tabelas**: só troque as que o pedido mandar ("tabela nova es-emitente"). Uma `--tabela` por
  troca; as demais ficam como estão. Sem `--tabela` o clone usa as mesmas tabelas do original.
- **Campos novos**: `--campo tabela.nome:tipo[:formato[:label[:initial]]]` (um por campo). Tipos
  válidos: os da skill `criacao-arquivo-df` (`character`, `integer`, `decimal`, `logical`, `date`...).
- **Cliente/banco**: `--cliente` é obrigatório quando há tabela nova (é de onde a estrutura é copiada);
  se a tabela existir em mais de um banco use `--banco mgcad`.

## Passo 3 — clonar

```powershell
python "<skill>\clone-tela.py" clonar --origem cd0704.w --novo escd0704 --cliente CAMIL --banco mgcad `
  --tabela emitente=es-emitente --campo es-emitente.ativo:logical:Sim/Nao:Ativo:yes --saida escd0704
```

O que ele faz, nessa ordem:
- Baixa cada fonte COPIAR (cache em `fontes-base/`, bytes CP850 preservados).
- Renomeia por **token inteiro** (`cd0704` → `escd0704`, `cd0704-v01` → `escd0704-v01`,
  `CD0704` → `ESCD0704`), nunca por substring: não gera `cod-es-emitente`.
  `{include/i-license-manager.i CD0704 ...}` mantém o código original (`--license renomear` para trocar).
- Troca a tabela em contexto de banco: `tabela.campo`, `FOR EACH/FIND/CAN-FIND/BUFFER ... FOR/LIKE/
  CREATE/DELETE/RELEASE/AVAILABLE/ROWID(/RECID(/BUFFER-COPY`, listas `&Scoped-define *TABLE*/*FIELDS*`,
  `_TblList`, argumentos de include `{... emitente ...}`, `&tabela=`, literais `"emitente"`.
  Não mexe em comentários nem em `use-index emitente` (nome de índice de outra tabela).
- Gera `<saida>/<nova>.df` com **todos** os campos e índices da tabela original (via `/tabela-df`)
  mais os campos novos, e `<nova>-rollback.df` (`DROP TABLE`). AREA vem do dicionário quando
  disponível; senão `--area/--area-indice` (padrão `dados`/`indices`) — marque "A CONFIRMAR".
- Grava em `<saida>/<pasta-original>/<novo-nome>` (ex.: `escd0704/cdp/escd0704-v01.w`), CP850, CRLF.
- Relatório em `docs/clone-<novo>.md`: arquivos, contagem de renomeações/trocas, **tokens antigos
  remanescentes** (deve ser zero fora de comentários), **campos usados pelos fontes que não existem
  no .df** (deve ser zero), objetos padrão que continuam na tabela antiga, não encontrados.

## Passo 4 — o que continua sendo seu

1. Ler `docs/clone-<novo>.md`. Remanescente ≠ 0 ou campo ausente ≠ 0 → corrija com Edit antes de seguir.
2. Campo novo **na tela**: o script não mexe em layout. Adicione o widget no viewer certo (Edit):
   `&Scoped-define ENABLED-FIELDS/DISPLAYED-FIELDS/ADM-CREATE-FIELDS` + definição no frame
   (`es-emitente.ativo AT ROW .. COL .. LABEL "Ativo" VIEW-AS TOGGLE-BOX`).
3. Renderizar com o próprio script (usa a rota de upload do AppBuilder-Web e já converte as cópias
   para UTF-8, que é o que o servidor espera no upload — os arquivos em disco continuam CP850):
   ```powershell
   python "<skill>\clone-tela.py" render --pasta escd0704/cdp --entrada escd0704.w --all
   ```
   Gera `docs/<novo>-pagN.png` (um por aba) e lista os avisos. Abra cada PNG com ViewImage e confira
   acentos, abas, campos e o campo novo. Aviso "objeto adqry/adzoom/... não encontrado" é esperado
   (objeto padrão fora do upload); para um objeto que você clonou, é clone incompleto.
   Não faça o upload à mão com `curl` mandando os arquivos CP850: o render sai com "�" nos acentos.
4. Entregar: lista de arquivos, .df + rollback, decisão sobre query/zoom padrão (aviso do inventário),
   o que o usuário compila (ordem: includes → viewers → browser → container) e carrega
   (Data Dictionary → Admin → Load Data and Definitions, base indicada).

## Regras
- Nunca copie/renomeie fontes à mão quando este script se aplica.
- Nunca escreva um .df de tabela copiada à mão: use o gerado (200 campos não se digitam).
- Se o script avisar "catálogo indisponível" (HTTP 502/503), pare e avise o usuário; não invente conteúdo.
- Encoding: os arquivos saem em CP850; não os reabra com `Get-Content -Encoding Default` nem grave em UTF-8.
- Variáveis de ambiente opcionais: `PROGRESSADMIN_BASE_URL`, `PROGRESSADMIN_APIKEY`.

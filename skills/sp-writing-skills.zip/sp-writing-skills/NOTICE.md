# Origem e licença

Esta skill é uma cópia, com as alterações listadas abaixo, de material de especialista com licença aberta.

- **Fonte:** https://github.com/obra/superpowers
- **Arquivos de origem:** `skills/writing-skills/SKILL.md`, `skills/writing-skills/references/CLAUDE_MD_TESTING.md`, `skills/writing-skills/references/anthropic-best-practices.md`, `skills/writing-skills/references/bulletproofing.md`, `skills/writing-skills/references/discovery.md`, `skills/writing-skills/references/flowcharts.md`, `skills/writing-skills/references/graphviz-conventions.dot`, `skills/writing-skills/references/persuasion-principles.md`, `skills/writing-skills/references/testing-skills-with-subagents.md`, `skills/writing-skills/render-graphs.js`
- **Autor:** Jesse Vincent
- **Licença:** MIT (texto completo em `LICENSE`)
- **Commit:** `22f0b463e7a5e579904dd6211a520321035526f7` (baixado em 2026-11-22)

## Alterações feitas

- `name:` do frontmatter trocado de `writing-skills` para `sp-writing-skills`.
- Acrescentada no fim uma nota de uma linha que traduz as referências `superpowers:<nome>` para os ids `sp-<nome>` do marketplace.
- Fora isso, o texto do especialista está como no original (em inglês).

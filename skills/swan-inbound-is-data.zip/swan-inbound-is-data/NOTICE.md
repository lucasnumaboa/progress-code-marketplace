# Aviso de terceiros (NOTICE)

Esta skill é uma cópia adaptada de material de terceiros e é redistribuída sob a licença original. O texto do especialista ficou em inglês, como no original.

- **Origem:** https://github.com/swan-gtm/gtm-skills
- **Caminho no repositório:** `skills/nadav-david/inbound-is-data`
- **Commit:** `eb0026f469f90645e1a64168d08a3e0afb59ee12` (baixado em 2026-11-22)
- **Autor:** Nadav David (autor da skill); copyright do repositório: Swan
- **Licença:** MIT (texto completo em `LICENSE`, copiado de `LICENSE` do repositório)

## Arquivos incluídos

- `SKILL.md` (de `skills/nadav-david/inbound-is-data/SKILL.md`)
- `references/attack-families.md` (de `skills/nadav-david/inbound-is-data/references/attack-families.md`)
- `author.md` (de `skills/nadav-david/author.md`, crédito do autor pedido pelo repositório)
- `LICENSE`

## Mudanças feitas

- Frontmatter: `name: inbound-is-data` trocado por `name: swan-inbound-is-data` (a descrição ficou igual).

## Crédito do autor (author.md)

O repositório pede que o crédito do autor acompanhe a skill. Conteúdo do `author.md` original:

```markdown
---
name: Nadav David
avatarUrl: https://www.gtmskills.com/authors/nadav-david.jpg
title: Strategic Partnerships Manager, Kidoz
linkedinUrl: https://www.linkedin.com/in/nadavdvd/
companyDomain: kidoz.net
email: nadav@kidoz.net
---

Strategic partnerships in advertising technology, selling media into brand and agency
buying teams. My skills encode the outbound discipline I run daily: find the real bridge
into an account before spending a cold touch, and refuse to ship a message that is clean
but gives a stranger no reason to answer.
```

# Aviso de terceiros (NOTICE)

Esta skill é uma cópia adaptada de material de terceiros e é redistribuída sob a licença original. O texto do especialista ficou em inglês, como no original.

- **Origem:** https://github.com/swan-gtm/gtm-skills
- **Caminho no repositório:** `skills/rutger-katz/revops-forecasting`
- **Commit:** `eb0026f469f90645e1a64168d08a3e0afb59ee12` (baixado em 2026-11-22)
- **Autor:** Rutger Katz (autor da skill); copyright do repositório: Swan
- **Licença:** MIT (texto completo em `LICENSE`, copiado de `LICENSE` do repositório)

## Arquivos incluídos

- `SKILL.md` (de `skills/rutger-katz/revops-forecasting/SKILL.md`)
- `references/dashboard-architecture.md` (de `skills/rutger-katz/revops-forecasting/references/dashboard-architecture.md`)
- `references/forecast-accuracy-diagnosis.md` (de `skills/rutger-katz/revops-forecasting/references/forecast-accuracy-diagnosis.md`)
- `references/forecast-breach-rules.md` (de `skills/rutger-katz/revops-forecasting/references/forecast-breach-rules.md`)
- `references/forecast-cadence.md` (de `skills/rutger-katz/revops-forecasting/references/forecast-cadence.md`)
- `references/forecast-variance-and-capacity.md` (de `skills/rutger-katz/revops-forecasting/references/forecast-variance-and-capacity.md`)
- `references/forecasting-methods.md` (de `skills/rutger-katz/revops-forecasting/references/forecasting-methods.md`)
- `references/forecasting-revenue-types.md` (de `skills/rutger-katz/revops-forecasting/references/forecasting-revenue-types.md`)
- `references/pipeline-analytics-views.md` (de `skills/rutger-katz/revops-forecasting/references/pipeline-analytics-views.md`)
- `references/pipeline-coverage-model.md` (de `skills/rutger-katz/revops-forecasting/references/pipeline-coverage-model.md`)
- `references/slippage-benchmarks.md` (de `skills/rutger-katz/revops-forecasting/references/slippage-benchmarks.md`)
- `author.md` (de `skills/rutger-katz/author.md`, crédito do autor pedido pelo repositório)
- `LICENSE`

## Mudanças feitas

- Frontmatter: `name: revops-forecasting` trocado por `name: swan-revops-forecasting` (a descrição ficou igual).

## Crédito do autor (author.md)

O repositório pede que o crédito do autor acompanhe a skill. Conteúdo do `author.md` original:

```markdown
---
name: Rutger Katz
avatarUrl: "https://www.gtmskills.com/authors/rutger-katz.jpg"
title: "Founder @ Neon Triforce — AI-Ready Revenue Systems"
linkedinUrl: "https://www.linkedin.com/in/rutgerkatz"
companyDomain: neontriforce.com
---

Helps B2B scale-ups (€15–150M) build AI-ready revenue systems — diagnostics first, then the operating system: forecasting, pipeline architecture, handoffs, and the tooling to run it.
```

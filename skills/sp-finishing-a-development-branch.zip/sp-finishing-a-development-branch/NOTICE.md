# Origem e licença

Esta skill é uma cópia, com as alterações listadas abaixo, de material de especialista com licença aberta.

- **Fonte:** https://github.com/obra/superpowers
- **Arquivos de origem:** `skills/finishing-a-development-branch/SKILL.md`
- **Autor:** Jesse Vincent
- **Licença:** MIT (texto completo em `LICENSE`)
- **Commit:** `22f0b463e7a5e579904dd6211a520321035526f7` (baixado em 2026-11-22)

## Alterações feitas

- `name:` do frontmatter trocado de `finishing-a-development-branch` para `sp-finishing-a-development-branch`.
- Fora isso, o texto do especialista está como no original (em inglês).

---
name: infra-como-codigo-terraform
description: Versiona infraestrutura como código com Terraform (ou Bicep para Azure nativo) — estrutura de módulos, gerenciamento de state, plan/apply seguro. Use quando o usuário pedir para "versionar essa infraestrutura", "criar esse recurso via Terraform", "por que o terraform apply quer destruir isso", "Bicep em vez de Terraform".
argument-hint: [provedor: Azure|AWS] [recurso a provisionar]
---

# Infra como código (Terraform/Bicep)

## Terraform vs. Bicep — quando usar cada um
- **Terraform**: multi-nuvem (ou pelo menos a possibilidade de precisar), maior ecossistema de módulos prontos,
  padrão de mercado mais amplo.
- **Bicep**: só Azure, sintaxe mais simples para esse caso específico, já vem com o Azure CLI (`az bicep`, sem
  instalar binário separado) — prefira Bicep se o projeto é 100% Azure e não há necessidade de portabilidade.
Terraform precisa de um binário próprio (`winget install Hashicorp.Terraform`) — instalação leve (um executável),
mas ainda é um passo a mais comparado a Bicep, que já vem embutido no Azure CLI.

## Estrutura básica de um projeto Terraform
```hcl
# main.tf
terraform {
  required_providers {
    azurerm = { source = "hashicorp/azurerm", version = "~> 3.0" }
  }
}
provider "azurerm" { features {} }

resource "azurerm_resource_group" "principal" {
  name     = "meu-grupo"
  location = "Brazil South"
}

resource "azurerm_storage_account" "dados" {
  name                     = "meustorage"
  resource_group_name      = azurerm_resource_group.principal.name
  location                 = azurerm_resource_group.principal.location
  account_tier             = "Standard"
  account_replication_type = "LRS"
}
```
```
terraform init      # baixa os providers declarados
terraform plan       # mostra o que SERIA feito, sem aplicar
terraform apply      # aplica de verdade, pede confirmacao "yes"
```

## State — o arquivo mais importante e mais frágil do projeto
O `terraform.tfstate` registra o que o Terraform acredita que existe de verdade na nuvem — perder ou corromper esse
arquivo faz o Terraform "esquecer" os recursos já criados (podendo tentar recriá-los do zero, duplicando, ou achar
que precisa destruir algo que na verdade quer manter). Regras inegociáveis:
- **Nunca** versione `terraform.tfstate` no Git (pode conter segredos em texto claro, ex.: senha de banco criada
  via recurso).
- Use um **backend remoto** (Azure Storage, S3, Terraform Cloud) com lock, para times — state local só serve para
  experimentação individual.
```hcl
terraform {
  backend "azurerm" {
    resource_group_name  = "terraform-state-rg"
    storage_account_name = "tfstatestorage"
    container_name       = "tfstate"
    key                  = "producao.tfstate"
  }
}
```

## Módulos (reutilização)
```hcl
module "rede" {
  source = "./modulos/rede"
  cidr   = "10.0.0.0/16"
}
```
Extraia para módulo quando o mesmo bloco de recursos se repete (ex.: "grupo de recursos + storage + key vault" para
cada ambiente dev/hml/prod) — parametrizado por variável, não copiado e colado com pequenas mudanças manuais.

## Por que `terraform apply` às vezes quer destruir algo inesperado
Geralmente por **drift**: alguém mudou o recurso manualmente pelo portal/CLI, fora do Terraform, e agora o state
não bate com a realidade — o Terraform, ao comparar, propõe "corrigir" revertendo a mudança manual (às vezes via
destruir-e-recriar se o atributo não suporta atualização in-place). **Sempre leia o `plan` linha por linha antes de
aplicar** — nunca rode `apply` sem revisar o que ele diz que vai fazer, especialmente qualquer linha com `-` (destruir).

## Regras
- Nunca rode `terraform apply` em ambiente de produção sem revisar o `plan` completo antes — isso não é opcional,
  é a proteção principal contra destruir algo por engano.
- Nunca versione o state nem arquivos `.tfvars` com segredo em texto — use backend remoto e variáveis de ambiente
  (`TF_VAR_nome`) ou um cofre de segredos.
- Ao adotar Terraform para infraestrutura que já existe (criada manualmente antes), use `terraform import` para
  trazer o recurso para o state em vez de recriar do zero — recriar pode gerar recurso duplicado ou downtime.

## Arquivos desta skill
Nenhum script fixo — os trechos acima cobrem os casos mais comuns; adapte ao provedor/recurso reais do usuário.

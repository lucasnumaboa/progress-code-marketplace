---
name: ssh-sftp-linux-windows
description: Usa SSH/SFTP a partir do Windows com o cliente OpenSSH já embutido (chaves, config, túneis, scp/sftp em lote) sem instalar programa separado, e explica quando vale a pena instalar o WSL para um ambiente Linux completo. Use quando o usuário pedir para "conectar nesse servidor Linux via SSH", "copiar arquivos por SFTP", "criar um túnel SSH", "preciso rodar comandos Linux no Windows".
argument-hint: [servidor de destino] [operação]
---

# SSH, SFTP e Linux a partir do Windows

## Cliente OpenSSH já vem com o Windows moderno (Windows 10 1809+/11)
```powershell
Get-WindowsCapability -Online -Name OpenSSH.Client*   # confirma se esta instalado (normalmente ja vem)
```
Se não estiver instalado (raro, mas acontece em imagens corporativas customizadas):
```powershell
Add-WindowsCapability -Online -Name OpenSSH.Client~~~~0.0.1.0
```

## Chave SSH (autenticação sem senha)
```powershell
ssh-keygen -t ed25519 -C "usuario@empresa.com"   # gera em C:\Users\<voce>\.ssh\id_ed25519
ssh-copy-id usuario@servidor   # so existe em builds mais novos do OpenSSH Windows; se nao existir, copie a chave publica manualmente:
type $env:USERPROFILE\.ssh\id_ed25519.pub | ssh usuario@servidor "cat >> ~/.ssh/authorized_keys"
```

## Config (~/.ssh/config) — evitar digitar host/usuário/chave toda vez
```
Host producao
    HostName 10.0.0.5
    User deploy
    IdentityFile ~/.ssh/id_ed25519
    Port 2222
```
Depois disso, `ssh producao` já usa tudo isso automaticamente — inclusive `scp`/`sftp` reconhecem o alias do config.

## scp/sftp em lote
```powershell
scp arquivo.txt producao:/home/deploy/
scp -r pasta_local producao:/home/deploy/pasta_remota
```
Para lote com muitos arquivos e necessidade de log/retomada, prefira um script sftp em modo batch:
```
sftp -b comandos.txt producao
```
onde `comandos.txt` tem uma linha por comando (`put arquivo1.txt`, `put arquivo2.txt`, ...).

## Túnel SSH (encaminhamento de porta)
```powershell
ssh -L 8080:localhost:80 producao   # porta 8080 local -> porta 80 do servidor remoto (visto DO PONTO DE VISTA DO SERVIDOR)
ssh -R 9000:localhost:9000 producao # o contrario: expor um servico local para o servidor remoto acessar
```
Útil para acessar um banco de dados ou painel web que só escuta em `localhost` do servidor remoto, sem abrir a
porta para a internet.

## Quando vale a pena o WSL (Windows Subsystem for Linux)
Se a necessidade é rodar **ferramentas de linha de comando Linux de verdade** (não só conectar em servidor remoto)
— compilar algo que só builda em Linux, rodar um script bash complexo, usar uma ferramenta que só existe para
Linux — o WSL é o caminho, mas é uma instalação maior (baixa uma distribuição Linux inteira,
`wsl --install`, GBs de espaço, reinício da máquina). **Confirme com o usuário antes de propor isso** — não é
necessário só para SSH/SFTP, que já funcionam com o cliente OpenSSH nativo.

## Regras
- Nunca grave senha de servidor em texto/script — prefira chave SSH; se precisar de senha por política do
  servidor, use um cofre de credenciais (ver skill `oauth2-login-servicos`/gerenciamento de segredos).
- Ao copiar arquivos em lote, valide a contagem/hash no destino antes de considerar a transferência concluída (ver
  skill `downloads-uploads-em-massa`, mesmo princípio).
- Túnel SSH aberto consome uma sessão ativa — feche (`Ctrl+C` ou matar o processo) quando não precisar mais, não
  deixe túneis esquecidos abertos indefinidamente.

## Arquivos desta skill
Nenhum script fixo — os comandos acima cobrem os casos mais comuns; adapte ao servidor/chave reais do usuário.

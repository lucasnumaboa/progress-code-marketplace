# Origem e mudanças

- **Repositório:** https://github.com/browser-use/video-use
- **Caminho no repositório:** `(raiz do repositório)`
- **Autor:** Browser Use
- **Licença:** MIT (texto em `LICENSE`)
- **Commit usado:** `43cfc566833548093455c9d4a46bd69913b7e552`
- **Arquivos copiados:** `SKILL.md`, `helpers/grade.py`, `helpers/pack_transcripts.py`, `helpers/render.py`, `helpers/timeline_view.py`

## Mudanças feitas

- no cabeçalho (frontmatter), `name:` passou de `video-use` para `vu-video-use`; a descrição ficou igual
- removida a seção "Setup" (instalação do próprio repositório, chave ELEVENLABS_API_KEY e registro da skill)
- nenhuma outra alteração no texto do especialista (mantido em inglês)

## Observações

- incluídos os ajudantes locais `helpers/render.py`, `helpers/grade.py`, `helpers/pack_transcripts.py` e `helpers/timeline_view.py` (ffmpeg, Pillow, numpy); NÃO incluídos `helpers/transcribe.py` e `helpers/transcribe_batch.py`, que usam a API paga da ElevenLabs. A transcrição com tempo por palavra vem de outra skill (Whisper local)
- a pasta `skills/manim-video` (vendorizada no repositório) não foi incluída

Empacotada para o marketplace do Progress Code em 2026-11-22.

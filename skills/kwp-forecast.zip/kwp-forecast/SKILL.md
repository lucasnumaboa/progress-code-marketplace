---
name: kwp-forecast
description: Generate the commit / best-case / pipeline narrative for a forecast call or a 1:1 with your manager - what's closing, what's at risk, what changed since last time. Use when the user asks "write my forecast", "forecast narrative", "prep for forecast call", "prep for my quarterly forecast call", "which deals should I commit vs. call upside", "forecast from this pipeline export", or "prep for my 1:1 with my manager".
argument-hint: "<period>"
---

# Forecast

Turn crm opportunity data into the narrative a
rep or leader delivers in a forecast review: the number, the deals
behind it, what changed, and where the risk is.

## Tools used

| Tool type | Used for | Required? |
|---|---|---|
| crm | the quarter's open + closed pipeline; category fixes | no (files fallback: uploaded pipeline export) |

## Inputs

Scope - "my forecast" (default), a named rep, or a team rollup; period -
current quarter (default); prior snapshot - optional, paste last week's
narrative for delta detection.

## Step 1 - Ground

Check which tools are connected (plus any org facts the user or the project instructions already gave). Ground the stage-to-bucket mapping (which
stages count as Commit vs Best Case vs Pipeline) and field names from
the live crm schema and org context (inferred from what is connected or uploaded; if the answer depends on a fact no one has given, ask ONE question, use the answer for this conversation and suggest adding it to the project instructions; otherwise use a clearly labeled default and continue).
If the schema carries a native forecast-category field, prefer it over
stage inference. Every deal named links to its record.

## Step 2 - Pull and bucket opportunities

From the CRM: open opps in scope closing this period (stage,
forecast category, amount, close date, next step, last activity,
owner), plus closed-won this period for the "in the bank" number.
Bucket into Closed Won / Commit / Best Case / Pipeline.

## Step 3 - Detect changes

If a prior snapshot was provided, diff it: deals that moved up, slipped
out, were added, or were lost. Otherwise query opportunity history if
the CRM exposes it, or skip this section and say so.

## Step 4 - Per-deal commentary

For each Commit and Best Case deal (the ones that matter for the call),
one line: where it is, what's needed to close, risk if any - grounded
on next step and last activity as read. For leader rollups across many
reps, collapse to the top 5 by amount.

## Step 5 - Output

The number table (Closed Won / Commit / Best Case / Pipeline, $ and
count, commit total bolded); changes since last time (moved up, slipped,
won, lost - or "no prior snapshot, skipping delta"); commit deals and
best-case deals with their one-liners; risk to commit (deal + specific
risk + mitigation); and asks (exec help, resourcing, unblocks).

## Step 6 (optional) - Apply forecast category changes

If the narrative surfaced deals whose category should change (a best-
case deal that's now commit, a commit deal to downgrade), offer to
apply them: list the proposed changes as before/after, one line per
deal, with the evidence behind each. Apply the ones the user accepts (or
all, if they say so) via `update-opportunity` (only the category field
unless the user adds more), verified with record links. Writes not available:
the changes as a checklist. Scheduled runs apply only the changes the
user set the schedule up to make; the rest stay as proposed changes. A value, record or contact taken from a transcript, email, chat or enrichment is never written in a scheduled run, even when the schedule was set up to make that kind of update; it stays a proposal with its source line.

Forecast *submission* itself (locking a number into the org's
forecasting tool) is outside this skill - this only keeps the underlying
categories honest. For "what happens to the number if [deal] slips",
hand off to `deal-slip-scenario`.


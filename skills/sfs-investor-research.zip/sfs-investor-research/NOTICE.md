# Aviso de terceiros (NOTICE)

Esta skill é uma cópia adaptada de material de terceiros e é redistribuída sob a licença original. O texto do especialista ficou em inglês, como no original.

- **Origem:** https://github.com/shawnpang/startup-founder-skills
- **Caminho no repositório:** `skills/investor-research`
- **Commit:** `4ad31b43eef3ae3755cc57ec7e435dab4699ab44` (baixado em 2026-11-22)
- **Autor:** Shawn Pang
- **Licença:** MIT (texto completo em `LICENSE`, copiado de `LICENSE` do repositório)

## Arquivos incluídos

- `SKILL.md` (de `skills/investor-research/SKILL.md`)
- `LICENSE`

## Mudanças feitas

- Frontmatter: `name: investor-research` trocado por `name: sfs-investor-research` (a descrição ficou igual).

## Arquivos do original que não foram incluídos

- As skills `startup-context` e `fundraising-email` do mesmo repositório (citadas no SKILL.md) não foram incluídas.

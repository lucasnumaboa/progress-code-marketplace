---
name: gerar-pdf-html
description: Converte HTML ou Markdown (renderizado para HTML) em PDF usando o Microsoft Edge headless já instalado no Windows (sem instalar programa novo), com CSS de impressão, quebras de página e margens. Use quando o usuário pedir "gerar PDF a partir desse HTML/relatório", "exportar essa página para PDF", "transformar esse markdown em PDF" — e não precisar de cabeçalho/rodapé com numeração dinâmica de página (nesse caso, ver a seção de limitações).
argument-hint: [caminho do .html ou .md] [caminho do .pdf de saída]
---

# Gerar PDF a partir de HTML/Markdown (sem instalar nada novo)

## Por que Edge headless e não wkhtmltopdf/Puppeteer
O Edge (baseado em Chromium) já vem instalado em qualquer Windows 10/11 e tem um modo `--headless` que imprime para
PDF com motor de renderização moderno (suporta CSS Grid/Flexbox, flexbox, fontes web). Isso evita instalar programa
novo (`wkhtmltopdf` usa um motor de renderização antigo e limitado; Puppeteer/Playwright exigem Node + download de
um Chromium próprio). Só considere essas alternativas se o usuário topar instalar algo a mais e precisar de
cabeçalho/rodapé com numeração de página dinâmica (limitação abaixo).

## Passo 1 — Se a entrada é Markdown, converta para HTML primeiro
Não escreva um conversor do zero. Se `markdown` (pip) já estiver disponível, use:
```python
import markdown
html = markdown.markdown(open("entrada.md", encoding="utf-8").read(), extensions=["tables", "fenced_code", "toc"])
```
Envolva o resultado num HTML completo com `<style>` de impressão (passo 2) antes de imprimir.

## Passo 2 — CSS de impressão
Inclua no `<head>` do HTML:
```css
@page { size: A4; margin: 2cm; }
@media print {
  h1, h2 { page-break-before: always; }
  table, figure { page-break-inside: avoid; }
}
body { font-family: Calibri, Arial, sans-serif; font-size: 11pt; }
```
`page-break-before`/`page-break-inside` controlam onde a página quebra — teste com o conteúdo real, títulos longos
podem precisar de ajuste manual.

## Passo 3 — Imprimir para PDF via linha de comando
Localize o executável (varia por instalação):
```
powershell -Command "(Get-Command msedge -ErrorAction SilentlyContinue).Source; if (-not $?) { 'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe' }"
```
Depois:
```
msedge --headless --disable-gpu --print-to-pdf="saida.pdf" --print-to-pdf-no-header --no-margins "caminho\entrada.html"
```
- `--print-to-pdf-no-header` remove o cabeçalho/rodapé padrão do Chromium (URL + data + número de página cru, feio
  para um documento profissional) — a paginação vira só o que estiver no CSS `@page`.
- Caminho do HTML **local** precisa ser absoluto; para HTML gerado em memória, grave em arquivo temporário primeiro.
- O comando roda e sai sozinho (não fica com janela aberta) — não precisa fechar processo depois.

## Limitações (quando considerar wkhtmltopdf/Puppeteer)
`--print-to-pdf` do Edge/Chromium **não** oferece cabeçalho/rodapé customizado com número de página dinâmico via
CSS puro (CSS Paged Media com `content: counter(page)` não é suportado neste modo). Se o usuário precisa de
"Página X de Y" de verdade no rodapé de cada página:
- Alternativa sem instalar nada: gere o PDF sem numeração e explique a limitação.
- Alternativa com instalação extra (perguntar antes ao usuário): Node.js + Puppeteer
  (`page.pdf({displayHeaderFooter: true, headerTemplate, footerTemplate})`) resolve isso nativamente.

## Regras
- Sempre teste o PDF gerado abrindo com `Read` (ferramenta de leitura de PDF) para conferir que o conteúdo saiu
  legível e sem cortes antes de entregar.
- CSS externo (`<link rel="stylesheet">`) com caminho relativo pode não carregar dependendo de onde o HTML está —
  prefira `<style>` inline ou caminho absoluto `file:///`.
- Imagens: use caminho absoluto ou `file:///C:/...`; URLs `http(s)://` externas exigem que a máquina tenha acesso à
  rede no momento da conversão.

## Arquivos desta skill
Nenhum script fixo — os comandos acima são executados diretamente via Bash/PowerShell conforme o caso.

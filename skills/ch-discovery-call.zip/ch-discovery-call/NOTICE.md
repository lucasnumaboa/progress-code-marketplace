# Aviso de terceiros (NOTICE)

Esta skill é uma cópia adaptada de material de terceiros e é redistribuída sob a licença original. O texto do especialista ficou em inglês, como no original.

- **Origem:** https://github.com/TheCraigHewitt/skills
- **Caminho no repositório:** `sales/discovery-call`
- **Commit:** `fdbf39b61fbc8cb7cea67949bfb5e8fc567bbc51` (baixado em 2026-11-22)
- **Autor:** Craig Hewitt
- **Licença:** MIT (texto completo em `LICENSE`, copiado de `LICENSE` do repositório)

## Arquivos incluídos

- `SKILL.md` (de `sales/discovery-call/SKILL.md`)
- `LICENSE`

## Mudanças feitas

- Frontmatter: `name: discovery-call` trocado por `name: ch-discovery-call` (a descrição ficou igual).

## Arquivos do original que não foram incluídos

- A skill `sales-context` do mesmo repositório (citada em "Before Starting") não foi incluída.

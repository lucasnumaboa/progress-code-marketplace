# Origem

Skill de especialista empacotada para o marketplace do Progress Code (id `sen-blog-writing-guide`).

- Repositório: https://github.com/getsentry/skills
- Caminho: `skills/blog-writing-guide`
- Autor: Sentry
- Copyright no arquivo de licença: "Copyright 2025 Functional Software, Inc. dba Sentry"
- Licença: Apache-2.0 (texto completo em `LICENSE`, copiado de `LICENSE` no repositório)
- Commit: `a582c51ee29d0f35e6ac321340796f77d43da733` (baixado em 2026-11-22)

## Arquivos incluídos

- `SKILL.md` (de `skills/blog-writing-guide/SKILL.md`)

## Mudanças feitas

1. Frontmatter: `name:` trocado de `blog-writing-guide` para `sen-blog-writing-guide` (a descrição foi mantida).

O texto do especialista foi mantido em inglês, sem tradução.
Conforme a Apache-2.0 (seção 4b), este aviso registra que os arquivos acima foram modificados.

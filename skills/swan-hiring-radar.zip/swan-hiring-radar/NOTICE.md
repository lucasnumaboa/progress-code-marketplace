# Aviso de terceiros (NOTICE)

Esta skill é uma cópia adaptada de material de terceiros e é redistribuída sob a licença original. O texto do especialista ficou em inglês, como no original.

- **Origem:** https://github.com/swan-gtm/gtm-skills
- **Caminho no repositório:** `skills/dusan-vystrcil/hiring-radar`
- **Commit:** `eb0026f469f90645e1a64168d08a3e0afb59ee12` (baixado em 2026-11-22)
- **Autor:** Dušan Vystrčil (autor da skill); copyright do repositório: Swan
- **Licença:** MIT (texto completo em `LICENSE`, copiado de `LICENSE` do repositório)

## Arquivos incluídos

- `SKILL.md` (de `skills/dusan-vystrcil/hiring-radar/SKILL.md`)
- `references/job-board-sourcing-and-actor-schemas.md` (de `skills/dusan-vystrcil/hiring-radar/references/job-board-sourcing-and-actor-schemas.md`)
- `author.md` (de `skills/dusan-vystrcil/author.md`, crédito do autor pedido pelo repositório)
- `LICENSE`

## Mudanças feitas

- Frontmatter: `name: hiring-radar` trocado por `name: swan-hiring-radar` (a descrição ficou igual).

## Crédito do autor (author.md)

O repositório pede que o crédito do autor acompanhe a skill. Conteúdo do `author.md` original:

```markdown
---
name: Dušan Vystrčil
avatarUrl: "https://github.com/vystrcild.png"
title: "Product Manager, Apify AI team"
linkedinUrl: "https://www.linkedin.com/in/dusanvystrcil/"
companyDomain: apify.com
---

Dušan is a Product Manager on the AI team at Apify — the platform where developers build, deploy, and publish web scraping, data extraction, and web automation tools. His skills encode how to turn scraped public data, like job postings, into disciplined GTM signals.
```

# Aviso de terceiros (NOTICE)

Esta skill é uma cópia adaptada de material de terceiros e é redistribuída sob a licença original. O texto do especialista ficou em inglês, como no original.

- **Origem:** https://github.com/anthropics/knowledge-work-plugins
- **Caminho no repositório:** `sales/skills/account-research`
- **Commit:** `0e0fcacddcc892eb92a1b7873ff9d68159c47571` (baixado em 2026-11-22)
- **Autor:** Anthropic
- **Licença:** Apache-2.0 (texto completo em `LICENSE`, copiado de `sales/LICENSE` do repositório)

## Arquivos incluídos

- `SKILL.md` (de `sales/skills/account-research/SKILL.md`)
- `LICENSE`

## Mudanças feitas

- Frontmatter: `name: account-research` trocado por `name: kwp-account-research` (a descrição ficou igual).
- `SKILL.md`: removido o bloco "**Rules (apply to every step of this skill):**" (regras de conectores, permissões, links e renderização próprias do Claude Cowork).
- `SKILL.md`: removida a seção final "## How it adapts" (níveis de conector do Claude Cowork: files-only / read-only / gated-writes).
- Conforme a seção 4(b) da Licença Apache 2.0: os arquivos acima foram modificados em relação ao original nos pontos listados. Fora esses pontos, o texto é o original.

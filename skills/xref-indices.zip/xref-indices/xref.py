#!/usr/bin/env python3
"""
Checagem de índice com XREF — compila fontes Progress/ABL com XREF (sem gravar .r) e aponta os acessos a banco que
varrem a tabela inteira (WHOLE-INDEX), com a linha do código, os campos usados no WHERE e os índices da tabela.

Comandos (sempre imprimem JSON):
  compilar <fonte|pasta>... [--pf arq.pf] [--db "-db x -H host -S porta ..."] [--propath "p1,p2"] [--recursivo]
                            [--saida pasta] [--extra "-cpinternal ISO8859-1 ..."]
  analisar <arquivo.xref|pasta>... [--relatorio relatorio.md]
  indices  <tabela>... [--pf arq.pf] [--db "..."]      índices da tabela com os campos (primário/único)
"""
import argparse
import glob
import json
import os
import re
import shlex
import subprocess
import sys
import tempfile
import time

NO_WINDOW = 0x08000000 if os.name == 'nt' else 0
FONTES = ('.p', '.w', '.cls', '.i')
COMPILAVEIS = ('.p', '.w', '.cls')


def falha(msg, **extra):
    print(json.dumps({'erro': msg, **extra}, ensure_ascii=False, indent=1))
    sys.exit(2)


# ---------------------------------------------------------------- Progress instalado

def achar_dlc():
    cands = [os.environ.get('DLC', '')]
    if os.name == 'nt':
        try:
            import winreg
            for raiz in (winreg.HKEY_LOCAL_MACHINE, winreg.HKEY_CURRENT_USER):
                for base in (r'SOFTWARE\PSC\PROGRESS', r'SOFTWARE\WOW6432Node\PSC\PROGRESS'):
                    try:
                        k = winreg.OpenKey(raiz, base)
                    except OSError:
                        continue
                    i = 0
                    while True:
                        try:
                            ver = winreg.EnumKey(k, i)
                        except OSError:
                            break
                        i += 1
                        try:
                            cands.append(winreg.QueryValueEx(winreg.OpenKey(k, ver + r'\Startup'), 'DLC')[0])
                        except OSError:
                            pass
        except ImportError:
            pass
        cands += [r'C:\Progress\OpenEdge', r'C:\OpenEdge', r'C:\Progress', r'C:\dlc', r'C:\DLC117', r'C:\DLC122', r'C:\DLC128']
        cands += glob.glob(r'C:\Progress\OpenEdge*') + glob.glob(r'C:\dlc*') + glob.glob(r'C:\Progress*\*')
    for c in cands:
        if c and os.path.exists(os.path.join(c, 'bin', 'prowin.exe' if os.name == 'nt' else '_progres')):
            return c
    return None


def cliente(dlc, gui=True):
    """prowin -b compila .w (GUI); _progres é o cliente caractere."""
    if os.name == 'nt' and gui and os.path.exists(os.path.join(dlc, 'bin', 'prowin.exe')):
        return os.path.join(dlc, 'bin', 'prowin.exe')
    for n in ('_progres.exe', '_progres', 'prowin.exe'):
        p = os.path.join(dlc, 'bin', n)
        if os.path.exists(p):
            return p
    return None


def args_banco(a):
    out = []
    if getattr(a, 'pf', None):
        if not os.path.exists(a.pf):
            falha(f'Arquivo .pf não encontrado: {a.pf}')
        out += ['-pf', os.path.abspath(a.pf)]
    if getattr(a, 'db', None):
        out += shlex.split(a.db, posix=False)
    return out


def abl_str(s):
    """Texto seguro dentro de aspas no ABL: ~ é o caractere de escape (caminho curto LUCASD~1 quebrava)."""
    return s.replace('~', '~~').replace('"', '~"')


def rodar_abl(dlc, codigo, args_extra, param='', gui=True, timeout=3600):
    """Grava o .p num temporário, roda em batch e devolve (saída do programa, log do cliente)."""
    tmp = tempfile.mkdtemp(prefix='xref-')
    prog = os.path.join(tmp, 'run.p')
    saida = os.path.join(tmp, 'saida.txt')
    open(prog, 'w', encoding='latin-1', errors='replace').write(codigo.replace('%SAIDA%', abl_str(saida.replace('\\', '/'))))
    exe = cliente(dlc, gui)
    env = {**os.environ, 'DLC': dlc, 'PATH': os.path.join(dlc, 'bin') + os.pathsep + os.environ.get('PATH', '')}
    cmd = [exe, '-b', '-p', prog, '-T', tmp] + (['-param', param] if param else []) + args_extra
    r = subprocess.run(cmd, cwd=tmp, env=env, capture_output=True, text=True, errors='replace', timeout=timeout, creationflags=NO_WINDOW)
    texto = open(saida, encoding='latin-1', errors='replace').read() if os.path.exists(saida) else ''
    return texto, (r.stdout or '') + (r.stderr or ''), tmp


# ---------------------------------------------------------------- compilar

COMPILA_P = r'''
DEFINE VARIABLE cLinha AS CHARACTER NO-UNDO.
DEFINE VARIABLE i      AS INTEGER   NO-UNDO.
DEFINE STREAM sIn.
DEFINE STREAM sOut.
PROPATH = "%PROPATH%" + "," + PROPATH.
INPUT STREAM sIn FROM VALUE(SESSION:PARAMETER).
OUTPUT STREAM sOut TO VALUE("%SAIDA%").
REPEAT:
  IMPORT STREAM sIn UNFORMATTED cLinha.
  IF cLinha = "" THEN NEXT.
  COMPILE VALUE(ENTRY(1, cLinha, "|")) XREF VALUE(ENTRY(2, cLinha, "|")) NO-ERROR.
  IF COMPILER:ERROR THEN DO:
    PUT STREAM sOut UNFORMATTED "ERRO|" ENTRY(1, cLinha, "|") SKIP.
    DO i = 1 TO COMPILER:NUM-MESSAGES:
      PUT STREAM sOut UNFORMATTED "MSG|" COMPILER:GET-MESSAGE(i) SKIP.
    END.
    DO i = 1 TO ERROR-STATUS:NUM-MESSAGES:
      PUT STREAM sOut UNFORMATTED "MSG|" ERROR-STATUS:GET-MESSAGE(i) SKIP.
    END.
  END.
  ELSE PUT STREAM sOut UNFORMATTED "OK|" ENTRY(1, cLinha, "|") SKIP.
END.
INPUT STREAM sIn CLOSE.
OUTPUT STREAM sOut CLOSE.
QUIT.
'''


def listar_fontes(alvos, recursivo):
    out = []
    for a in alvos:
        a = os.path.abspath(a)
        if os.path.isdir(a):
            padrao = os.path.join(a, '**', '*') if recursivo else os.path.join(a, '*')
            out += [p for p in glob.glob(padrao, recursive=recursivo) if p.lower().endswith(COMPILAVEIS)]
        elif os.path.isfile(a):
            out.append(a)
        else:
            falha(f'Não encontrado: {a}')
    return sorted(set(out))


def cmd_compilar(a):
    dlc = achar_dlc() or falha('Progress/OpenEdge não encontrado (DLC). Defina a variável DLC ou instale o OpenEdge.')
    fontes = listar_fontes(a.alvos, a.recursivo)
    if not fontes:
        falha('Nenhum fonte .p/.w/.cls para compilar.')
    saida = os.path.abspath(a.saida or os.path.join(tempfile.gettempdir(), 'xref-saida'))
    os.makedirs(saida, exist_ok=True)
    pastas = [p.strip() for p in (a.propath or '').split(',') if p.strip()]
    # a pasta de cada fonte e a pasta-mãe entram no PROPATH (includes relativos, como {inc/x.i})
    for f in fontes:
        for d in (os.path.dirname(f), os.path.dirname(os.path.dirname(f))):
            if d not in pastas:
                pastas.append(d)
    lista = os.path.join(saida, '_lista.txt')
    pares = []
    with open(lista, 'w', encoding='latin-1', errors='replace') as fh:
        for f in fontes:
            x = os.path.join(saida, re.sub(r'[^\w.-]+', '_', os.path.relpath(f, os.path.commonpath(fontes) if len(fontes) > 1 else os.path.dirname(f))) + '.xref')
            pares.append((f, x))
            fh.write(f'{f}|{x}\n')
    codigo = COMPILA_P.replace('%PROPATH%', abl_str(','.join(pastas)))
    extra = args_banco(a) + (shlex.split(a.extra, posix=False) if a.extra else [])
    t0 = time.time()
    texto, log, tmp = rodar_abl(dlc, codigo, extra, param=lista, gui=True)
    res, atual = [], None
    for ln in texto.splitlines():
        tipo, _, resto = ln.partition('|')
        if tipo in ('OK', 'ERRO'):
            atual = {'fonte': resto, 'ok': tipo == 'OK', 'xref': dict(pares).get(resto), 'mensagens': []}
            res.append(atual)
        elif tipo == 'MSG' and atual is not None and resto.strip() and resto not in atual['mensagens']:
            atual['mensagens'].append(resto.strip())
    meta = {'propath': pastas, 'dlc': dlc, 'fontes': fontes}
    json.dump(meta, open(os.path.join(saida, '_meta.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    sem_banco = any(re.search(r'não conectad|not connected|\(725\)|\(3695\)|database .* not', ' '.join(r['mensagens']), re.I) for r in res)
    out = {'pasta_xref': saida, 'segundos': round(time.time() - t0, 1), 'compilados': sum(r['ok'] for r in res), 'com_erro': sum(not r['ok'] for r in res), 'resultados': res}
    if not res:
        out['aviso'] = 'O Progress não rodou o compilador. Log do cliente: ' + log.strip()[-600:]
    if sem_banco:
        out['aviso'] = 'Fonte usa tabela de banco que não está conectado: passe --pf com os bancos do cliente (ou --db).'
    out['proximo_passo'] = f'analisar "{saida}"' if any(r['ok'] for r in res) else 'corrija os erros de compilação (PROPATH/bancos) e compile de novo'
    print(json.dumps(out, ensure_ascii=False, indent=1))


# ---------------------------------------------------------------- analisar

LINHA_XREF = re.compile(r'^(\S+)\s+(\S+)\s+(\d+)\s+(\S+)\s*(.*)$')


def ler_texto(p):
    for enc in ('utf-8', 'cp1252', 'latin-1'):
        try:
            return open(p, encoding=enc).read()
        except (UnicodeDecodeError, OSError):
            continue
    return ''


def achar_fonte(nome, meta_propath, base_xref):
    nome = nome.strip('"')
    if os.path.isabs(nome) and os.path.exists(nome):
        return nome
    for d in list(meta_propath) + [base_xref, os.getcwd()]:
        p = os.path.normpath(os.path.join(d, nome.lstrip('.\\/')))
        if os.path.exists(p):
            return p
    return None


def cmd_analisar(a):
    arquivos = []
    for alvo in a.alvos:
        if os.path.isdir(alvo):
            arquivos += glob.glob(os.path.join(alvo, '**', '*.xref'), recursive=True)
        elif os.path.isfile(alvo):
            arquivos.append(alvo)
    if not arquivos:
        falha('Nenhum arquivo .xref encontrado. Rode antes: compilar <fontes>.')
    achados, buscas, tabelas = [], 0, {}
    cache_linhas = {}
    for x in sorted(arquivos):
        base = os.path.dirname(os.path.abspath(x))
        try:
            propath = json.load(open(os.path.join(base, '_meta.json'), encoding='utf-8')).get('propath', [])
        except Exception:
            propath = []
        acessos = {}  # (fonte, linha, tabela) -> campos
        linhas = [LINHA_XREF.match(l) for l in ler_texto(x).splitlines()]
        for m in linhas:
            if m and m.group(4) == 'ACCESS':
                partes = m.group(5).split()
                if len(partes) >= 2:
                    acessos.setdefault((m.group(2), m.group(3), partes[0]), []).append(partes[1])
        for m in linhas:
            if not m or m.group(4) != 'SEARCH':
                continue
            partes = m.group(5).split()
            if len(partes) < 2:
                continue
            buscas += 1
            tabela, indice = partes[0], partes[1]
            temp = 'TEMPTABLE' in partes
            inteiro = 'WHOLE-INDEX' in partes
            tabelas.setdefault(tabela, {'buscas': 0, 'whole_index': 0})
            tabelas[tabela]['buscas'] += 1
            if not inteiro:
                continue
            tabelas[tabela]['whole_index'] += 1
            fonte, linha = m.group(2), int(m.group(3))
            caminho = achar_fonte(fonte, propath, base)
            codigo = ''
            if caminho:
                if caminho not in cache_linhas:
                    cache_linhas[caminho] = ler_texto(caminho).splitlines()
                ls = cache_linhas[caminho]
                codigo = '\n'.join(l.rstrip() for l in ls[max(0, linha - 1):linha + 2])
            achados.append({
                'programa': m.group(1), 'fonte': caminho or fonte, 'linha': linha, 'tabela': tabela, 'indice_usado': indice,
                'tipo': 'temp-table' if temp else 'banco', 'severidade': 'baixa' if temp else 'alta',
                'campos_no_where': sorted(set(acessos.get((fonte, m.group(3), tabela), []))), 'codigo': codigo
            })
    achados.sort(key=lambda f: (f['severidade'] != 'alta', f['fonte'], f['linha']))
    resumo = {'arquivos_xref': len(arquivos), 'buscas': buscas,
              'whole_index_banco': sum(f['tipo'] == 'banco' for f in achados), 'whole_index_temp_table': sum(f['tipo'] == 'temp-table' for f in achados)}
    out = {'resumo': resumo, 'achados': achados,
           'tabelas': dict(sorted(tabelas.items(), key=lambda kv: -kv[1]['whole_index'])),
           'proximo_passo': ('para cada achado "alta": indices <tabela> e proponha o WHERE que use os primeiros campos de um índice (ou diga que falta índice)'
                             if resumo['whole_index_banco'] else 'nenhum WHOLE-INDEX em tabela de banco')}
    if a.relatorio:
        escrever_relatorio(out, a.relatorio)
        out['relatorio'] = os.path.abspath(a.relatorio)
    print(json.dumps(out, ensure_ascii=False, indent=1))


def escrever_relatorio(out, destino):
    r = out['resumo']
    L = ['# Checagem de índice (XREF)', '',
         f"{r['arquivos_xref']} programa(s), {r['buscas']} busca(s) em tabela, **{r['whole_index_banco']} varredura(s) de tabela de banco** "
         f"(WHOLE-INDEX) e {r['whole_index_temp_table']} em temp-table.", '']
    for sev, titulo in (('alta', 'Tabelas de banco (varrem a tabela inteira)'), ('baixa', 'Temp-tables')):
        itens = [f for f in out['achados'] if f['severidade'] == sev]
        if not itens:
            continue
        L += [f'## {titulo}', '']
        for f in itens:
            L.append(f"### {os.path.basename(f['fonte'])}:{f['linha']} — `{f['tabela']}` (índice {f['indice_usado']})")
            if f['campos_no_where']:
                L.append(f"Campos usados: {', '.join(f['campos_no_where'])}")
            if f['codigo']:
                L += ['```', f['codigo'], '```']
            L.append('')
    os.makedirs(os.path.dirname(os.path.abspath(destino)), exist_ok=True)
    open(destino, 'w', encoding='utf-8').write('\n'.join(L))


# ---------------------------------------------------------------- índices da tabela

INDICES_P = r'''
DEFINE VARIABLE cTabs   AS CHARACTER NO-UNDO.
DEFINE VARIABLE cNome   AS CHARACTER NO-UNDO.
DEFINE VARIABLE cDb     AS CHARACTER NO-UNDO.
DEFINE VARIABLE cCampos AS CHARACTER NO-UNDO.
DEFINE VARIABLE i AS INTEGER NO-UNDO.
DEFINE VARIABLE j AS INTEGER NO-UNDO.
DEFINE VARIABLE hFile AS HANDLE NO-UNDO.
DEFINE VARIABLE hIdx  AS HANDLE NO-UNDO.
DEFINE VARIABLE hIf   AS HANDLE NO-UNDO.
DEFINE VARIABLE hFld  AS HANDLE NO-UNDO.
DEFINE VARIABLE hQ    AS HANDLE NO-UNDO.
DEFINE VARIABLE hQ2   AS HANDLE NO-UNDO.
cTabs = SESSION:PARAMETER.
OUTPUT TO VALUE("%SAIDA%").
DO i = 1 TO NUM-ENTRIES(cTabs):
  cNome = ENTRY(i, cTabs).
  DO j = 1 TO NUM-DBS:
    cDb = LDBNAME(j).
    IF NUM-ENTRIES(cNome, ".") = 2 AND ENTRY(1, cNome, ".") <> cDb THEN NEXT.
    CREATE BUFFER hFile FOR TABLE cDb + "._File".
    CREATE BUFFER hIdx  FOR TABLE cDb + "._Index".
    CREATE BUFFER hIf   FOR TABLE cDb + "._Index-Field".
    CREATE BUFFER hFld  FOR TABLE cDb + "._Field".
    hFile:FIND-FIRST("WHERE _File._File-name = " + QUOTER(ENTRY(NUM-ENTRIES(cNome, "."), cNome, ".")), NO-LOCK) NO-ERROR.
    IF hFile:AVAILABLE THEN DO:
      CREATE QUERY hQ.
      hQ:SET-BUFFERS(hIdx).
      hQ:QUERY-PREPARE("FOR EACH _Index NO-LOCK WHERE _Index._File-recid = " + STRING(hFile:RECID)).
      hQ:QUERY-OPEN().
      REPEAT:
        hQ:GET-NEXT().
        IF hQ:QUERY-OFF-END THEN LEAVE.
        cCampos = "".
        CREATE QUERY hQ2.
        hQ2:SET-BUFFERS(hIf).
        hQ2:QUERY-PREPARE("FOR EACH _Index-Field NO-LOCK WHERE _Index-Field._Index-recid = " + STRING(hIdx:RECID) + " BY _Index-Field._Index-Seq").
        hQ2:QUERY-OPEN().
        REPEAT:
          hQ2:GET-NEXT().
          IF hQ2:QUERY-OFF-END THEN LEAVE.
          hFld:FIND-FIRST("WHERE RECID(_Field) = " + STRING(hIf:BUFFER-FIELD("_Field-recid"):BUFFER-VALUE), NO-LOCK) NO-ERROR.
          IF hFld:AVAILABLE THEN cCampos = cCampos + (IF cCampos = "" THEN "" ELSE ",") + STRING(hFld:BUFFER-FIELD("_Field-name"):BUFFER-VALUE).
        END.
        hQ2:QUERY-CLOSE().
        DELETE OBJECT hQ2.
        PUT UNFORMATTED "IDX|" cDb "." STRING(hFile:BUFFER-FIELD("_File-name"):BUFFER-VALUE) "|"
          STRING(hIdx:BUFFER-FIELD("_Index-name"):BUFFER-VALUE) "|"
          STRING(hIdx:BUFFER-FIELD("_Unique"):BUFFER-VALUE) "|"
          STRING(hFile:BUFFER-FIELD("_Prime-Index"):BUFFER-VALUE = hIdx:RECID) "|" cCampos SKIP.
      END.
      hQ:QUERY-CLOSE().
      DELETE OBJECT hQ.
    END.
    DELETE OBJECT hFile. DELETE OBJECT hIdx. DELETE OBJECT hIf. DELETE OBJECT hFld.
  END.
END.
OUTPUT CLOSE.
QUIT.
'''


def cmd_indices(a):
    dlc = achar_dlc() or falha('Progress/OpenEdge não encontrado (DLC).')
    extra = args_banco(a)
    if not extra:
        falha('Informe os bancos: --pf arq.pf (ou --db "-db nome ...").')
    tabs = ','.join(a.tabelas)
    texto, log, _ = rodar_abl(dlc, INDICES_P, extra, param=tabs, gui=False, timeout=300)
    res = {}
    for ln in texto.splitlines():
        p = ln.split('|')
        if p[0] == 'IDX' and len(p) >= 6:
            res.setdefault(p[1], []).append({'indice': p[2], 'unico': p[3] == 'yes', 'primario': p[4] == 'yes', 'campos': [c for c in p[5].split(',') if c]})
    out = {'indices': res}
    faltando = [t for t in a.tabelas if not any(k.lower().endswith('.' + t.split('.')[-1].lower()) for k in res)]
    if faltando:
        out['nao_encontradas'] = faltando
    if not res:
        out['aviso'] = 'Nenhum índice lido. Os bancos estão conectados? Log: ' + log.strip()[-400:]
    print(json.dumps(out, ensure_ascii=False, indent=1))


def main():
    try:
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    except Exception:
        pass
    ap = argparse.ArgumentParser(description='Checagem de índice com XREF')
    sp = ap.add_subparsers(dest='cmd', required=True)
    p = sp.add_parser('compilar')
    p.add_argument('alvos', nargs='+')
    p.add_argument('--pf')
    p.add_argument('--db')
    p.add_argument('--propath')
    p.add_argument('--recursivo', action='store_true')
    p.add_argument('--saida')
    p.add_argument('--extra')
    p = sp.add_parser('analisar')
    p.add_argument('alvos', nargs='+')
    p.add_argument('--relatorio')
    p = sp.add_parser('indices')
    p.add_argument('tabelas', nargs='+')
    p.add_argument('--pf')
    p.add_argument('--db')
    a = ap.parse_args()
    {'compilar': cmd_compilar, 'analisar': cmd_analisar, 'indices': cmd_indices}[a.cmd](a)


if __name__ == '__main__':
    main()

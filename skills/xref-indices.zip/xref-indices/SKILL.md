---
name: xref-indices
description: Checagem de índice com XREF — compila fontes Progress/OpenEdge ABL (.p, .w, .cls) com XREF, sem gravar .r, e aponta cada FOR EACH/FIND/CAN-FIND que varre a tabela inteira (WHOLE-INDEX), com a linha do código (inclusive dentro de includes), os campos usados no WHERE e os índices da tabela, para propor o WHERE certo. Use quando o usuário pedir "checa os índices", "tem WHOLE-INDEX?", "análise de performance", "esse programa está lento", "revisa o acesso a banco", ou antes de entregar um programa Progress alterado.
---

# Checagem de índice com XREF

Tudo pronto nesta pasta: use só o `xref.cmd` pela ferramenta Bash (PowerShell). **Não escreva código de compilação.**
Precisa do Progress/OpenEdge instalado nesta máquina (o comando acha sozinho; se não achar, avisa).

| comando | para quê |
|---|---|
| `xref.cmd compilar "<fonte ou pasta>" --pf "<bancos.pf>" [--propath "p1,p2"] [--recursivo]` | compila com XREF (não grava .r) |
| `xref.cmd analisar "<pasta dos .xref>" --relatorio "<saida.md>"` | lista os WHOLE-INDEX com linha, campos do WHERE e código |
| `xref.cmd indices <tabela> [<tabela>...] --pf "<bancos.pf>"` | índices da tabela com os campos (primário/único) |

## Passo a passo

### 1. Bancos e PROPATH

O XREF só sai com os **bancos do cliente conectados** (o compilador precisa do dicionário). Procure um `.pf` no
projeto (`Glob **/*.pf`); o do ambiente de desenvolvimento do cliente costuma ter os `-db … -H … -S …`. Sem `.pf`,
pergunte ao usuário, ou use `--db "-db <banco> -H <host> -S <porta>"` (vários `-db` na mesma string).

Includes de produto (`{include/i-prgvrs.i}`, `{utp/ut-glob.i}`…) precisam do PROPATH do ambiente: passe as pastas de
fontes do produto/cliente em `--propath "C:\datasul\src,C:\cliente\esp"`. A pasta de cada fonte já entra sozinha.

### 2. Compile com XREF

```powershell
xref.cmd compilar "<programa.p ou pasta>" --pf "<bancos.pf>" --propath "<pastas>" --saida "$env:TEMP\xref"
```

Se algum fonte vier com `ok: false`, leia as `mensagens`: include não achado = falta pasta no `--propath`; tabela
desconhecida / banco não conectado = falta banco no `.pf`. Corrija e compile de novo. Não siga com fonte que não
compilou.

### 3. Analise

```powershell
xref.cmd analisar "$env:TEMP\xref" --relatorio "<pasta do projeto>\xref-indices.md"
```

Cada achado traz `fonte` (o include, quando a busca está nele), `linha`, `tabela`, `indice_usado`,
`campos_no_where` e o `codigo`. Severidade:
- **alta**: tabela de BANCO com `WHOLE-INDEX` — o Progress lê a tabela inteira pelo índice indicado.
- **baixa**: temp-table com `WHOLE-INDEX` — só importa se a temp-table for grande.

### 4. Proponha a correção (para cada achado "alta")

1. `xref.cmd indices <tabela> --pf "<bancos.pf>"` para ver os índices e seus campos.
2. Compare com `campos_no_where`. Um índice só é usado quando o WHERE compara, por igualdade (ou faixa no último),
   os **primeiros campos** dele. Causas comuns: campo sem índice; faltou o 1º campo do índice (ex.: a empresa ou o
   estabelecimento); `MATCHES`, `BEGINS` com curinga, função no campo (`SUBSTRING(campo…)`, `STRING(campo)`) ou
   `OR` entre campos, que impedem o índice.
3. Proponha o WHERE reescrito usando o índice certo (e `USE-INDEX` só se o compilador escolher mal). Se nenhum
   índice serve, diga que a tabela precisa de índice novo e qual (campos na ordem). **Não altere o fonte sem o
   usuário pedir.**
4. Depois de alterar, compile e analise de novo para confirmar que o `WHOLE-INDEX` sumiu.

### 5. Responda

Resumo (quantos programas, buscas e WHOLE-INDEX), a lista dos achados "alta" com arquivo:linha, o índice usado, a
correção proposta e o caminho do relatório `.md`.

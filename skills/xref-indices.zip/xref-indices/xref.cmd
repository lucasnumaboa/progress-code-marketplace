@echo off
setlocal
rem Checagem de indice com XREF - atalho: acha o Python e chama o xref.py desta pasta.
rem   xref.cmd compilar "<fonte ou pasta>" --pf "<bancos.pf>" [--propath "p1,p2"] [--recursivo] [--saida pasta]
rem   xref.cmd analisar "<pasta dos .xref>" [--relatorio saida.md]
rem   xref.cmd indices <tabela> [...] --pf "<bancos.pf>"
set "DIR=%~dp0"
set "PY="
where py >nul 2>nul && set "PY=py -3"
if not defined PY where python >nul 2>nul && set "PY=python"
if not defined PY (
  echo {"erro": "Python 3 nao encontrado. Instale com: winget install -e --id Python.Python.3.12  (depois feche e abra o Progress Code)"}
  exit /b 3
)
%PY% "%DIR%xref.py" %*
exit /b %errorlevel%

---
name: concorrencia-filas
description: Escolhe entre threads e async, e integra com filas de mensagem (RabbitMQ, Redis, Azure Service Bus) com idempotência, retries e dead-letter — assumindo que o broker já está provisionado (não instala servidor de fila). Use quando o usuário pedir para "processar isso em paralelo", "por que essa aplicação trava com múltiplas requisições", "consumir mensagens de uma fila", "essa mensagem foi processada duas vezes".
argument-hint: [linguagem] [o que precisa rodar concorrente/na fila]
---

# Programação concorrente e filas

## Threads vs. async — qual usar
- **I/O-bound** (esperando rede, disco, banco): `async`/`await` é mais eficiente — uma única thread lida com
  milhares de operações "em espera" simultâneas sem o overhead de criar threads.
- **CPU-bound** (cálculo pesado, processamento de imagem/dados): threads não ajudam em Python por causa do GIL
  (Global Interpreter Lock — só uma thread executa bytecode Python por vez); use `multiprocessing` (processos
  separados, cada um com seu próprio GIL) ou mova o cálculo pesado para uma biblioteca que libera o GIL
  internamente (numpy, a maioria das operações vetorizadas já fazem isso).
```python
# I/O-bound: async
import asyncio
async def buscar_varias(urls):
    async with aiohttp.ClientSession() as sessao:
        return await asyncio.gather(*[sessao.get(url) for url in urls])

# CPU-bound: multiprocessing
from multiprocessing import Pool
with Pool(processes=4) as pool:
    resultados = pool.map(processar_pesado, lista_de_itens)
```
Em .NET/Java/Node, o modelo é diferente (Node é single-thread com event loop, similar em espírito ao async Python
para I/O; .NET/Java têm threads "de verdade" sem GIL) — confirme a linguagem antes de aplicar esse raciocínio.

## Filas de mensagem — por que usar em vez de chamar direto
Desacopla quem produz do que consome: se o consumidor estiver lento/fora do ar, a mensagem espera na fila em vez de
a chamada falhar imediatamente. Assume-se aqui que o broker (RabbitMQ, Redis, Azure Service Bus) já está
provisionado (localmente para dev, ou como serviço gerenciado em nuvem) — esta skill não cobre instalar/administrar
o servidor da fila em si.

## RabbitMQ (Python, pika)
```python
import pika

conexao = pika.BlockingConnection(pika.ConnectionParameters("servidor"))
canal = conexao.channel()
canal.queue_declare(queue="pedidos", durable=True)  # durable = sobrevive a reinicio do broker

canal.basic_publish(exchange="", routing_key="pedidos", body=json.dumps(dados),
                     properties=pika.BasicProperties(delivery_mode=2))  # 2 = persistente em disco

def processar(ch, method, properties, body):
    try:
        tratar_mensagem(json.loads(body))
        ch.basic_ack(delivery_tag=method.delivery_tag)
    except Exception:
        ch.basic_nack(delivery_tag=method.delivery_tag, requeue=False)  # manda pra dead-letter em vez de tentar pra sempre

canal.basic_consume(queue="pedidos", on_message_callback=processar)
canal.start_consuming()
```

## Dead-letter (mensagens que falharam repetidamente)
```python
canal.queue_declare(queue="pedidos", durable=True, arguments={
    "x-dead-letter-exchange": "pedidos-dlx",
    "x-dead-letter-routing-key": "pedidos-falhou",
})
```
Sem uma fila de dead-letter, uma mensagem que falha repetidamente ou é perdida silenciosamente (se `requeue=False`
sem DLX) ou fica reentrando em loop infinito (se você reenfileirar sem limite) — sempre configure DLX e monitore
essa fila separadamente (mensagens ali são um alerta de algo quebrado no processamento).

## Idempotência no consumidor (mensagem pode chegar mais de uma vez — garantia "at-least-once" é o padrão)
```python
def processar(mensagem):
    if ja_processado(mensagem["id"]):  # checar num registro (banco/redis) de IDs ja processados
        return
    tratar_mensagem(mensagem)
    marcar_como_processado(mensagem["id"])
```
A maioria dos brokers garante entrega "pelo menos uma vez", não "exatamente uma vez" — o consumidor precisa ser
capaz de processar a mesma mensagem duas vezes sem duplicar o efeito (mesmo princípio da skill
`etl-agendado-windows`, passo 2, aplicado a mensagens em vez de lotes de dados).

## Regras
- Nunca use `requeue=True` (reenfileirar sem condição) num erro — se a mensagem sempre falha pelo mesmo motivo,
  isso cria um loop infinito de reprocessamento que consome recursos sem nunca ter sucesso.
- Sempre monitore o tamanho da fila e a fila de dead-letter — fila crescendo sem parar indica consumidor lento/
  parado; DLX com mensagens indica processamento quebrado.
- Confirme com o usuário se o broker (RabbitMQ/Redis/Service Bus) já está provisionado antes de escrever código de
  integração — não é escopo desta skill instalar/subir o servidor da fila.

## Arquivos desta skill
Nenhum script fixo — os trechos acima cobrem os casos mais comuns; adapte à linguagem/broker reais do usuário.

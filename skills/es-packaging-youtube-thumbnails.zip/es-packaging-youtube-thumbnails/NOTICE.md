# Origem e mudanças

- **Repositório:** https://github.com/ericosiu/ai-marketing-skills
- **Caminho no repositório:** `packaging-youtube-thumbnails`
- **Autor:** Single Grain
- **Licença:** MIT (texto em `LICENSE`)
- **Commit usado:** `c715f900e3a7c1f4274976ca851849d9a7c3fe55`
- **Arquivos copiados:** `SKILL.md`, `references/channel-profile-template.md`, `references/image-contracts.md`, `references/packaging-rubric.md`, `references/performance-learning.md`, `requirements.txt`, `scripts/thumbnail_guard.py`, `scripts/thumbnail_learning.py`

## Mudanças feitas

- no cabeçalho (frontmatter), `name:` passou de `packaging-youtube-thumbnails` para `es-packaging-youtube-thumbnails`; a descrição ficou igual
- removido o comando de checagem de versão e telemetria do bloco "Preamble"; a frase sobre `<skill-root>` ficou
- removido o bloco "Run this skill on live data" (chamada comercial para o Single Brain Gateway e contato da agência Single Grain)
- nenhuma outra alteração no texto do especialista (mantido em inglês)

## Observações

- incluídos `scripts/thumbnail_guard.py` e `scripts/thumbnail_learning.py` (Python local, só Pillow) e `requirements.txt`; testes e `agents/openai.yaml` não foram incluídos

Empacotada para o marketplace do Progress Code em 2026-11-22.

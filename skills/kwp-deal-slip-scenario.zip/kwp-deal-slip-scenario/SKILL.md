---
name: kwp-deal-slip-scenario
description: Model what happens to your number if a deal slips, shrinks, or dies - quota impact, coverage ratio change, and the substitute pipeline needed to stay on plan. Use when the user asks "what if [deal] slips", "what happens if [account] pushes to next quarter", "can I still hit my number without [deal]", or "model losing [deal]".
---

# Deal Slip Scenario

Run the math on a forecast shock before it
happens: if this deal moves, shrinks, or goes away, where does that
leave the number, and what has to backfill it.

## Tools used

| Tool type | Used for | Required? |
|---|---|---|
| crm | the quarter's open + closed-won pipeline | no (files fallback: uploaded pipeline export) |

Read-only throughout - scenario math never touches records.

## Inputs

Deal(s) - one or more opps by name, ID, or "[account]'s deal";
scenario - slips to next period (default), closes at a reduced amount,
or is lost; scope - the current user's quota (default), or a named rep /
team rollup.

## Step 1 - Ground

Check which tools are connected (plus any org facts the user or the project instructions already gave). Ground the stage-to-bucket mapping (Commit /
Best Case / Pipeline), field names, and the quota source from the live
crm schema and org context (inferred from what is connected or uploaded; if the answer depends on a fact no one has given, ask ONE question, use the answer for this conversation and suggest adding it to the project instructions; otherwise use a clearly labeled default and continue). Every
figure in the output ties to a record actually read.

## Step 2 - Establish the baseline

From the CRM: open opps in scope closing this quarter (stage,
forecast category, amount, close date, probability, next step, last
activity, owner) plus closed-won this quarter. Compute:

- **Booked** (closed won)
- **Commit total** (booked + commit-bucket open deals)
- **Best case total**
- **Open pipeline total** and **coverage ratio** (open pipeline / 
  remaining gap to quota)

If quota isn't in the crm or org context, ask the user for it - the
scenario is meaningless without the target.

## Step 3 - Apply the scenario

Remove or restate the named deal(s):

- **Slip:** subtract from this period's buckets; note it lands next
  period (not gone, but it does not help this number)
- **Reduced amount:** replace the amount with the revised figure
- **Lost:** subtract entirely

Recompute commit total, gap to quota, and coverage ratio.

## Step 4 - Find the substitute pipeline

What in the existing open pipeline could realistically backfill the gap
this period: best-case deals with recent activity (within 14 days) and
a close date inside the period; deals one stage from commit where the
exit criteria look achievable in the time remaining; anything the user
flagged as upside earlier this session. Be honest about timing: a deal
whose remaining steps take 6 weeks does not rescue a quarter with 3
weeks left (default realism bar: >1 stage advance needed in <2 weeks is
not realistic - tuned to the org's cycle).

## Step 5 - Output

Before/after table (booked, commit total, gap to quota, coverage ratio,
deltas); a one-sentence verdict (still on plan / at risk / not
recoverable this period without new pipeline); the substitute list
(account, amount, bucket, why plausible this period, what has to
happen, by when, and the realistic backfill total vs the gap); what to
do this week (highest-leverage actions to save the slipping deal or
accelerate a substitute); and the if-it-slips-anyway note (next-period
commit including this deal, plus knock-on risk like stacked renewals).


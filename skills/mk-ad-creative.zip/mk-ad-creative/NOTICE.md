# Origem e mudanças

- **Repositório:** https://github.com/coreyhaines31/marketingskills
- **Caminho no repositório:** `skills/ad-creative`
- **Autor:** Corey Haines
- **Licença:** MIT (texto em `LICENSE`)
- **Commit usado:** `5b2b400eec1e7e1cec76245a715d0b0d4fd2a9c1`
- **Arquivos copiados:** `SKILL.md`, `assets/creative-review-template.html`, `references/awareness-headlines.md`, `references/creative-review-page.md`, `references/creative-roadmap.md`, `references/generative-tools.md`, `references/hook-system.md`, `references/imessage-video-ads.md`, `references/meta-creative-formats.md`, `references/motion-video-ads.md`, `references/platform-specs.md`, `references/short-form-video-specs.md`, `references/static-ad-templates.md`

## Mudanças feitas

- no cabeçalho (frontmatter), `name:` passou de `ad-creative` para `mk-ad-creative`; a descrição ficou igual
- removida a seção "Tool Integrations": tabela e fluxo com as CLIs próprias do repositório (`node tools/clis/...`, `tools/SETUP.md`) e menção ao Magister, produto do mantenedor
- nenhuma outra alteração no texto do especialista (mantido em inglês)

Empacotada para o marketplace do Progress Code em 2026-11-22.

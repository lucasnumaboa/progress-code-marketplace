---
name: telegram-discord-bots
description: Cria um bot do Telegram ou Discord, recebe comandos e envia arquivos/mensagens — canal de notificação simples e barato. Use quando o usuário pedir para "criar um bot no Telegram/Discord", "mandar alerta pelo Telegram/Discord", "receber comandos por bot".
argument-hint: [Telegram|Discord] [o que o bot deve fazer]
---

# Telegram e Discord bots

## Telegram — criar e enviar mensagem (o caminho mais simples de todos os canais)
1. Fale com `@BotFather` no Telegram, `/newbot`, siga as perguntas — ele devolve um `token` (guarde como segredo).
2. Descubra o `chat_id` de destino: mande uma mensagem qualquer para o bot e acesse
   `https://api.telegram.org/bot<TOKEN>/getUpdates` — o `chat.id` aparece na resposta.
3. Enviar mensagem (só HTTP, sem biblioteca nem instalar nada):
```python
import requests
requests.post(
    f"https://api.telegram.org/bot{token}/sendMessage",
    json={"chat_id": chat_id, "text": "Alerta: build falhou."},
)
```
4. Enviar arquivo:
```python
with open("relatorio.pdf", "rb") as f:
    requests.post(f"https://api.telegram.org/bot{token}/sendDocument",
                  data={"chat_id": chat_id}, files={"document": f})
```

## Telegram — receber comandos (bot interativo)
```
pip install python-telegram-bot
```
```python
from telegram.ext import Application, CommandHandler

async def status(update, context):
    await update.message.reply_text("Sistema OK.")

app = Application.builder().token(token).build()
app.add_handler(CommandHandler("status", status))
app.run_polling()  # roda continuamente - precisa de um processo de longa duracao (servico/tarefa agendada "sempre ativa")
```
`run_polling()` mantém um processo rodando o tempo todo — para produção, registre como serviço do Windows (ver skill
`servicos-tarefas-agendadas-windows`) em vez de deixar um terminal aberto manualmente.

## Discord — criar e enviar mensagem via webhook (mais simples, sem bot completo)
1. No canal do Discord: Configurações do Canal → Integrações → Webhooks → Criar Webhook, copie a URL.
```python
requests.post(webhook_url, json={"content": "Alerta: build falhou.", "username": "CI Bot"})
```

## Discord — bot completo (recebe comandos, precisa de token de aplicação)
```
pip install discord.py
```
```python
import discord
from discord.ext import commands

intents = discord.Intents.default()
intents.message_content = True  # precisa habilitar no Discord Developer Portal tambem, nao so aqui
bot = commands.Bot(command_prefix="!", intents=intents)

@bot.command()
async def status(ctx):
    await ctx.send("Sistema OK.")

bot.run(token)
```
`intents.message_content` precisa estar habilitado **também** no painel do Discord Developer Portal (aba Bot →
Privileged Gateway Intents) — sem isso o bot não recebe o conteúdo das mensagens mesmo com o código certo.

## Regras
- Nunca deixe o `token` do bot em código versionado — variável de ambiente.
- Bot que roda continuamente (`run_polling`/`bot.run`) precisa de supervisão (reiniciar se cair) — combine com o
  usuário como isso vai ser mantido rodando (serviço do Windows, tarefa agendada com verificação, etc.).
- Webhook do Discord/Telegram: qualquer um com a URL/token pode postar — trate como segredo.

## Arquivos desta skill
Nenhum script fixo — os trechos acima cobrem os casos mais comuns; adapte ao comando/canal real do usuário.

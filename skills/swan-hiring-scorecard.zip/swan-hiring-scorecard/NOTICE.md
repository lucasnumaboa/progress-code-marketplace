# Origem

Skill de especialista empacotada para o marketplace do Progress Code (id `swan-hiring-scorecard`).

- Repositório: https://github.com/swan-gtm/gtm-skills
- Caminho: `skills/jason-mesiarik/hiring-scorecard`
- Autor: Jason Mesiarik / Swan (biblioteca Swan; autoria registrada em `author.md`, copiado do repositório)
- Detentor do copyright no arquivo de licença: Swan
- Licença: MIT (texto completo em `LICENSE`, copiado de `LICENSE` no repositório)
- Commit: `eb0026f469f90645e1a64168d08a3e0afb59ee12` (baixado em 2026-11-22)

## Arquivos incluídos

- `SKILL.md` (de `skills/jason-mesiarik/hiring-scorecard/SKILL.md`)
- `references/beyond-the-interview.md` (de `skills/jason-mesiarik/hiring-scorecard/references/beyond-the-interview.md`)
- `references/decision-package.md` (de `skills/jason-mesiarik/hiring-scorecard/references/decision-package.md`)
- `references/interview-kit.md` (de `skills/jason-mesiarik/hiring-scorecard/references/interview-kit.md`)
- `references/kit-rubric.md` (de `skills/jason-mesiarik/hiring-scorecard/references/kit-rubric.md`)
- `references/outcome-scorecard.md` (de `skills/jason-mesiarik/hiring-scorecard/references/outcome-scorecard.md`)
- `references/worked-examples.md` (de `skills/jason-mesiarik/hiring-scorecard/references/worked-examples.md`)
- `author.md` (de `skills/jason-mesiarik/author.md`)

## Mudanças feitas

1. Frontmatter: `name:` trocado de `hiring-scorecard` para `swan-hiring-scorecard` (a descrição foi mantida).

O texto do especialista foi mantido em inglês, sem tradução.

A biblioteca swan-gtm/gtm-skills é MIT (LICENSE "Copyright (c) 2026 Swan"; CONTRIBUTING: "Contributions are MIT-licensed"). O crédito ao autor de cada skill é mantido pelo `author.md`.

# Origem e licença

Esta skill é uma cópia, com as alterações listadas abaixo, de material de especialista com licença aberta.

- **Fonte:** https://github.com/coreyhaines31/marketingskills
- **Arquivos de origem:** `skills/pricing/SKILL.md`, `skills/pricing/references/pricing-models.md`, `skills/pricing/references/pricing-page-teardown.md`, `skills/pricing/references/research-methods.md`, `skills/pricing/references/tier-structure.md`
- **Autor:** Corey Haines
- **Licença:** MIT (texto completo em `LICENSE`)
- **Commit:** `5b2b400eec1e7e1cec76245a715d0b0d4fd2a9c1` (baixado em 2026-11-22)

## Alterações feitas

- `name:` do frontmatter trocado de `pricing` para `mk-pricing`.
- Fora isso, o texto do especialista está como no original (em inglês).

## Arquivos da skill original que não vieram

- `evals/evals.json` (casos de teste do autor, não usados pela skill).

# Origem

Skill de especialista empacotada para o marketplace do Progress Code (id `swan-panel-debrief-alignment`).

- Repositório: https://github.com/swan-gtm/gtm-skills
- Caminho: `skills/justin-blij/panel-debrief-alignment`
- Autor: Justin Blij / Swan (biblioteca Swan; autoria registrada em `author.md`, copiado do repositório)
- Detentor do copyright no arquivo de licença: Swan
- Licença: MIT (texto completo em `LICENSE`, copiado de `LICENSE` no repositório)
- Commit: `eb0026f469f90645e1a64168d08a3e0afb59ee12` (baixado em 2026-11-22)

## Arquivos incluídos

- `SKILL.md` (de `skills/justin-blij/panel-debrief-alignment/SKILL.md`)
- `references/alignment-states-and-scales.md` (de `skills/justin-blij/panel-debrief-alignment/references/alignment-states-and-scales.md`)
- `references/brokering-moves.md` (de `skills/justin-blij/panel-debrief-alignment/references/brokering-moves.md`)
- `references/setup-customization-checklist.md` (de `skills/justin-blij/panel-debrief-alignment/references/setup-customization-checklist.md`)
- `references/vague-positive-phrase-library.md` (de `skills/justin-blij/panel-debrief-alignment/references/vague-positive-phrase-library.md`)
- `references/worked-example.md` (de `skills/justin-blij/panel-debrief-alignment/references/worked-example.md`)
- `author.md` (de `skills/justin-blij/author.md`)

## Mudanças feitas

1. Frontmatter: `name:` trocado de `panel-debrief-alignment` para `swan-panel-debrief-alignment` (a descrição foi mantida).

O texto do especialista foi mantido em inglês, sem tradução.

A biblioteca swan-gtm/gtm-skills é MIT (LICENSE "Copyright (c) 2026 Swan"; CONTRIBUTING: "Contributions are MIT-licensed"). O crédito ao autor de cada skill é mantido pelo `author.md`.

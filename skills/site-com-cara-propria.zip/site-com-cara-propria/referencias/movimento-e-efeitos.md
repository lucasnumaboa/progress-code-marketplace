Adaptado de Impeccable (Paul Bakaus), Apache-2.0 — https://github.com/pbakaus/impeccable — traduzido e resumido.

# Movimento, efeitos ambiciosos, encanto e ousadia

## Para que serve o movimento
Movimento explica estado, relação e hierarquia, ou cria **um** momento autoral que a página mereceu. Decoração sem propósito é dívida de animação.
- Persuade/Experience: o movimento pode carregar a voz. Prefira uma sequência focal ensaiada a reveals repetidos por seção.
- Operate/Read: movimento serve feedback, estado e continuidade. Transições rotineiras rápidas; ninguém espera coreografia de carregamento.
- Anime só onde: confirma ação; torna legível estado ou relação espacial; mantém continuidade; dirige atenção num momento importante; encarna o mundo visual.

## Tese de movimento (escreva antes de implementar)
- **Momento focal**: a sequência ou interação que merece autoria, vinda deste produto. Fade-and-rise genérico, hover que levanta, camada de parallax ou reveal no scroll NÃO são tese.
- **Continuidade**: que mudanças de estado/layout/navegação precisam ser explicadas.
- **Feedback**: que controles e resultados precisam de confirmação.
- **Orçamento**: quais efeitos são caros e com que frequência rodam.

## Material pelo significado
Continuidade: elemento compartilhado, FLIP, View Transitions. Foco/profundidade: blur, filtro, backdrop, luz, sombra (limitados). Revelação: máscara, clip-path, recorte. Energia: cor, posição de gradiente, textura, distorção, shader. Feedback: a menor mudança que deixa causa e resultado inconfundíveis.
Vá além de transform e opacity quando fica suave. Não empilhe técnicas por espetáculo: uma ideia material forte na sequência focal, estados de apoio quietos. Stagger só quando uma lista aparece como lista, com atraso total limitado.

## Tempo e easing
| Duração | Uso |
|---|---|
| 100–150 ms | feedback imediato |
| 150–300 ms | mudança de estado rotineira |
| 300–500 ms | layout, overlay, transição de view |
| 500–800 ms | entrada focal deliberadamente autoral |
- Saída mais rápida que entrada. Desaceleração natural: `cubic-bezier(0.16, 1, 0.3, 1)` (ease-out exponencial: quart/quint/expo). Nada de bounce/elastic por reflexo. Feedback longo parece latência.
- Anime a partir de um estado padrão já visível.

## Hover
Hover nunca move o vizinho nem rouba o alvo do ponteiro. O elemento fica parado e um filho se move: `.card:hover .card-surface { transform: translateY(-2px) }` (o elemento que se move sozinho escapa do ponteiro perto da borda e pisca). Prévia opcional: `transition-delay` só no estado hover, para a saída não atrasar.

## Implementação
- CSS transitions/keyframes para estados e sequências limitadas; Web Animations API ou a lib do projeto para interrupção e valores dinâmicos; View Transitions para continuidade. Scroll-driven só quando a relação com o scroll tem significado, com fallback. Não adicione dependência para o que o stack já expressa.
- Conteúdo visível por padrão: se o script falhar, a página não some.
- Evite animar `width`, `height`, `top`, `left`, margens (use FLIP/transforms). Limite blur, filtro, sombra, canvas e shader a regiões isoladas. `will-change` só durante a animação. Meça nos aparelhos-alvo.

## Efeitos ambiciosos ("overdrive")
"Extraordinário" depende do contexto: partículas num portfólio impressionam; num painel de configurações, envergonham. Pergunte: o que faria um usuário DESTA interface dizer "nossa, que legal"?
- Superfícies visuais (hero, landing, portfólio): reveal guiado pelo scroll, fundo em shader, transição cinematográfica, arte generativa que responde ao cursor.
- UI funcional: diálogo que nasce do botão via View Transitions; tabela de 100 mil linhas a 60fps com scroll virtual; drag-and-drop com física de mola.
- Dados: Canvas/WebGL, transição animada entre estados do gráfico, grafos force-directed.
- Antes de construir: pense em 2–3 direções (técnica, nível de ambição, estética) com seus custos (suporte de navegador, desempenho, complexidade) e escolha uma. É o tipo de pedido que mais erra.
- O efeito serve a experiência, não o contrário. Se o mundo pede uma técnica (canvas, WebGL, view transitions, movimento generativo), construa a técnica de verdade, não uma imitação estática.

### Caixa de ferramentas
- **View Transitions API**: same-document em todos os navegadores; cross-document sem Firefox. Morfar elemento compartilhado (item de lista virando página de detalhe, botão virando diálogo).
- **`@starting-style`** (todos): animar de `display:none` para visível só com CSS.
- **Física de mola**: massa, tensão, amortecimento. Libs: motion (ex-Framer Motion), GSAP, ou um solver próprio.
- **Scroll-driven** (`animation-timeline: scroll()`): só CSS; Chrome/Edge/Safari; Firefox só com flag; sempre com fallback estático.
- **WebGL** (todos): shaders, pós-processamento, partículas. Libs: Three.js, OGL (leve), regl. Para o que CSS não expressa.
- **WebGPU**: Chrome/Edge, Safari 26+, Firefox em Windows/macOS. Sempre com fallback WebGL2; detecte a API e cheque `navigator.gpu.requestAdapter()` nulo.
- **Canvas 2D / OffscreenCanvas**: render customizado, manipulação de pixels; com Web Workers tira o render da thread principal.
- **Cadeias de filtro SVG**: displacement, turbulence, morphology para distorção orgânica; animáveis por CSS.
- **Scroll virtual** (TanStack Virtual nos casos complexos); **gráficos na GPU** (deck.gl, renderers com regl); **transições de dados** (`transition()` do D3 ou View Transitions).
- **`@property`** (todos): propriedades CSS tipadas, para animar gradientes e cores. **Web Workers / WASM** para computação pesada. **Web Audio** exige gesto do usuário.

```css
@supports (animation-timeline: scroll()) { .hero { animation-timeline: scroll(); } }
```
```js
if ('gpu' in navigator && await navigator.gpu.requestAdapter()) { /* WebGPU */ }
else if (canvas.getContext('webgl2')) { /* WebGL2 */ }
/* o fallback só-CSS também precisa ficar bonito */
```

### Disciplina
- Aprimoramento progressivo é inegociável: sem o efeito, a experiência continua boa.
- Alvo de 60fps (16ms por quadro); abaixo de 50fps, simplifique. `requestAnimationFrame` para animação em JS; throttle/debounce em handlers de scroll; IntersectionObserver para saber o que está visível.
- Inicialize recursos pesados (contexto WebGL, módulos WASM) só perto da viewport. Pause o render fora da tela. Teste em aparelho intermediário real, não só na sua máquina.
- A diferença entre "legal" e "extraordinário" está nos últimos 20%: a curva da mola, o deslocamento do stagger, o movimento secundário sutil.
- NUNCA: travar em aparelho intermediário; API de ponta sem fallback funcional; som sem opt-in; ambição técnica para esconder fundamentos fracos; vários momentos extraordinários competindo (foco gera impacto, excesso gera ruído).
- Testes: **uau** (alguém que nunca viu reage?), **remoção** (sem o efeito a experiência piora ou ninguém nota?), **aparelho** (celular, tablet, Chromebook), **contexto** (faz sentido para esta marca e público?).

## Acessibilidade e controle
- Respeite preferências de autoplay e som. Todo loop não essencial para quando sai da tela ou fica oculto.
- Toda animação web tem um caminho `prefers-reduced-motion` intencional: remova ou reduza o movimento espacial, mantendo opacidade, cor e transições de estado que carregam significado. Menos e mais suave, não "desligar tudo": o feedback de uma ação continua legível.

## Encanto (delight)
- Caráter do produto revelado numa interação útil ou num detalhe cuidadoso; não graça genérica. Defina numa frase o que o usuário deve sentir e por que pertence a este produto; use o menor sistema que entrega isso.
- Sucesso proporcional ao esforço (salvar rotineiro só parece certo). Espera: progresso verdadeiro, nunca encenado. Erro: problema e recuperação primeiro; sem piada com perda, dinheiro ou privacidade. Repetição: satisfatório na centésima vez.
- Teste: um produto vizinho poderia usar o mesmo momento sem mudar? Então não é específico.

## Ousadia (bolder)
- Pedir "mais ousado" não é pedir mais efeitos; rejeite esse reflexo primeiro.
- Amplifique o que o sistema já possui (tipo em força total, o motivo-assinatura), sem novas cores, fontes ou primitivos. Faça o movimento decisivo completo e aquiete o resto: se tudo ficou mais alto, ficou mais plano. A seção vira um pico no scroll (mudança de densidade ou ritmo).
- Teste do esqueleto: sem o texto, a estrutura ainda diz o que a seção é e por que importa? Se não, a ousadia está no tamanho da fonte, não no design.

## Verificar movimento
Nunca julgue movimento por um screenshot só: capture quadros (antes, primeiro animado, meio, último, assentado), uma vez normal e uma com reduced motion, entrada e saída separadas. Confira: interrupção e uso repetido funcionam; desktop, mobile e teclado usáveis; efeitos caros suaves no aparelho-alvo; remover uma animação perderia significado, não só decoração.

## (nota) Site sem etapa de build (HTML/CSS/JS que abre direto)
- three.js como módulo ES com `<script type="importmap">` apontando para `https://cdn.jsdelivr.net/npm/three@<versão>/build/three.module.js` (e `three/addons/` para `.../examples/jsm/`); GSAP por `https://cdn.jsdelivr.net/npm/gsap@<versão>/dist/gsap.min.js`. Sempre com a versão fixa.
- Abra no Browser e confira no console que a biblioteca carregou e que não há erro. Sem rede ou sem WebGL, a página mostra a alternativa estática (imagem ou composição em CSS), nunca um quadro em branco.
- Página aberta direto do disco (file://) não carrega módulos de outros arquivos locais em alguns navegadores: para testar, sirva a pasta (por exemplo `npx serve` ou `python -m http.server`) e diga isso no LEIA-ME.

Adaptado de Impeccable (Paul Bakaus), Apache-2.0 — https://github.com/pbakaus/impeccable — traduzido e resumido.

# Processo para site/página NOVA

## Princípios
- Trabalhe como diretor de design premiado: código de produção, ponto de vista claro, acabamento excepcional. Termine o trabalho; só faltam assets que só o usuário pode dar.
- O briefing vence: estética, época, materiais, fontes e paletas fixados são honrados. Redirecionar um briefing claro para o seu gosto é falha.
- Refinamento preserva; redesign substitui. No redesign o visual antigo é evidência e anti-referência; nunca fique no meio-termo (polir o visual descartado).
- Verifique olhando o render nos tamanhos reais, com checagens em lote: corrija tudo o que uma olhada mostrou antes de olhar de novo.

## Modos (decidem a ambição)
Escolha pela superfície pedida, não pelo produto (a landing de uma ferramenta é Persuade; a documentação de uma grife é Read).
- **Persuade** (landing, marketing, preços): o visitante decide e age; o design é o produto. Compromisso total, ponto de vista ousado, imagens reais quando o briefing pede.
- **Experience** (portfólio, galeria): a obra lidera desde a primeira viewport; a interface recua.
- **Operate** (app, dashboard, admin): escaneabilidade, consistência e convenções acima de expressão; a marca vive em detalhes precisos.
- **Read** (docs, artigos, changelog): estrutura para compreensão; depois, uma leitura que vale ficar.

## 1. O que já é verdade
Mundo visual coerente já no código: herde. Sem autoridade visual: crie um mundo. Seção dentro de página existente herda a página.

## 2. Perguntar só o que muda o trabalho (2 ou 3 perguntas)
- Persuade: quem precisa agir, no que deve acreditar, que prova/assets reais sustentam isso. Operate: tarefa, informação, estados, frequência. Read: a pergunta do leitor, material-fonte, estrutura. Experience: o que lidera, como a exploração se desenrola.
- Sempre: o que é sucesso, o que não pode mudar, o que faria um resultado polido parecer errado.
- Nunca peça valores de CSS nem "estilos prontos". Não proponha um visual antes de derivar direções: a direção citada na pergunta é a que a resposta confirma.

## 3. Derivar o mundo visual do assunto
1. Nomeie numa frase o mecanismo único do produto, a cena real do público, seu lar cultural e o que esta página precisa provar. Anote a página que a categoria sempre entrega e o oposto previsível dela: as duas são "a vala" e ficam fora. A leitura literal do nome do produto ou de uma metáfora ganha no máximo 1 candidato.
2. Liste **7** sistemas visuais, artefatos, lugares ou rituais concretos que o público conhece de cor. Para cada um: 1 linha de por que ressoa e carrega o mecanismo; 1 linha de como é (fundo e cores principais, vozes tipográficas, a assinatura reconhecível). Ordene por ressonância.
   - Vale a tradição gráfica do público: notação, publicações, programas de identidade, gráficos de dados, interfaces. Um sistema abstrato nomeável (escola de cartaz, padrão de documentação) é candidato válido.
   - Pergunte como isso seria como objeto físico e como era esse mundo antes da web.
   - Operate/Read: nunca tire o mundo das ferramentas que o público opera (terminal, osciloscópio, painel): vira fantasia. Persuade/Experience: ferramentas contam como vala, no máximo 1.
   - Se mais de 3 dos 7 são da mesma família material, você parou no óbvio: cave até cobrir pelo menos 3 famílias.
3. Transforme em direções completas: mundo visual reutilizável + experiência concreta da primeira página.
4. Não pegue automaticamente o 1º do ranking (nota: o Impeccable sorteia a direção para quebrar a convergência ao padrão da categoria). Pese alternativas em 2 eixos: identificação do público e clareza do produto. Da alternativa que perdeu, importe uma **disciplina** (compromisso total de paleta, coragem de densidade do grid, honestidade estrutural), nunca a "roupa" (sombra de botão, fonte display, motivo). Um mundo é dono da página.
5. Apresente uma direção comprometida: mundo, primeira viewport, caminho do visitante, interação-assinatura, alcance para outras páginas, risco honesto. A "saída padrão" (o padrão da categoria bem feito) existe só como escolha do usuário; se escolhida, iguale o acabamento de 2 ou 3 produtos de referência, sem ironia.

Verdade: dados de demonstração podem ser criados em fidelidade total, rotulados como sintéticos, com lista do que trocar. Alegações comerciais (preços, clientes, benchmarks, capacidades) nunca se inventam. Recusar uma direção ousada porque o dado de demo não existe é timidez vestida de honestidade.

## 4. Comprometer e registrar
- Estratégia de cor antes das cores (ver tipografia-cor-layout.md). Claro/escuro nunca é padrão: escreva uma frase da cena física (quem, onde, sob que luz) e deixe ela decidir. Fontes como objetos do mundo do assunto.
- Teste: se alguém adivinha sua estética só pela categoria (ou categoria + o que você evitou), refaça.
- Antes do código, escreva um contrato (~150 palavras): **THESIS** (a ideia que a página possui e o arranjo padrão que recusa), **OWN-WORLD** (paleta e linguagem de componentes reconhecíveis sem conteúdo), **STORY** (o que o visitante entende, acredita e faz), **FIRST VIEWPORT** (composição exata, escala, onde está a ação primária), **FORM** (a forma escolhida). Bloco que parece "um clima" = direção não decidida. Nunca copie o contrato para o código entregue.

## 5. Comps (se houver geração de imagem)
- Três comps de alta fidelidade da página real, na viewport dela (retrato para mobile-first, paisagem para desktop). Um só convida a carimbar. O usuário aprova antes do código.
- Prompt de 150–300 palavras: tipo de tela + produto, borda a borda, texto legível, sem janela de navegador; tarefa do visitante com conteúdo real (nomes, números com unidade, próxima ação); o que lidera; partes em ordem de leitura; frame (marca, navegação). Sem tamanhos/cores, salvo o que o usuário fixou.
- Reprove o render se: dá para pendurar como pôster; é foto com texto; o assunto sumiu; o modo não se lê sem legenda.
- Compromisso é profundidade: um movimento dominante, o resto quieto. "Busy" é mais alto, não mais ousado. Comps 2 e 3 vão mais longe, nunca mais limpos.
- Comp aprovado é contrato espacial medido: modelos acham que recriaram a imagem em HTML/CSS e não recriaram. Meça as regiões; o pintado vira raster, texto/controles são código; nada que o comp não mostra entra.
- (nota) O Impeccable diz que o caminho por comp é para modelos de ponta; modelos menores vão "code-led": a ambição fica escrita no FIRST VIEWPORT + interação-assinatura + gramática de movimento.

## 6. Construir com compromisso total
- Construa a direção escolhida, não uma versão mais segura. Todo átomo (nav, botões, inputs, links) no vocabulário da forma; componente de prateleira é lapso. Sem supervisão, a versão segura é o risco conhecido.
- **Primeira viewport é tese, não header.** Teste da memória: quem saísse após uma viewport, o que descreveria uma hora depois? Se for "um clima", não comprometeu.
- **Prove, não afirme**: o produto em ação, especificidades que o concorrente não copia.
- **Construa a alavanca web da forma**: se o mundo pede canvas, WebGL, view transitions ou movimento generativo, construa a técnica, não uma imitação estática.
- **Ritmo de scroll de estúdio**: varie densidade, escala, imagem, movimento e silêncio numa gramática; trecho denso ganha trecho quieto; termine com um fechamento real.
- Persuade: abertura torna a oferta inteligível e desejável e mostra a ação na forma funcional (busca de rota e datas da companhia aérea, horários livres da clínica, adicionar ao carrinho), não um link decorativo. O mundo carrega a página, nunca é uma pintura dela: nav numa fachada ainda lê como links.
- Operate: o mundo empresta só tipo, paleta, densidade e um movimento-assinatura concreto (saúde de serviços como mapa de metrô); nunca layout, navegação ou controles. Read: o mundo é dono da moldura (masthead, trilho, aberturas, código e tabelas); a coluna de leitura fica calma.

## 7. Inspecionar e terminar
- Capture cada breakpoint (desktop 1440, mobile 390, mais a largura real do usuário) e teste desktop de 1280 a 1600. Em algo interativo, percorra os estados (aberto, fechado, hover, foco, erro, vazio, texto longo) buscando sobreposição e corte.
- Captura válida: estabilize animações de entrada antes (elemento escondido por timing parece ausente), capture do topo, abra cada arquivo e confirme que não há região preta/branca nem estado meio carregado. Nunca julgue fidelidade por miniatura de página inteira.
- Critique contra pedido e contrato: a primeira viewport passa; toda ação prometida funciona; todo objeto desenhado em código se lê de relance no tamanho real. Persuade: um visitante novo sabe o que é, por que importa e o que fazer em segundos.
- Corrija em um lote, confirme uma vez. A revisão final vem de um contexto novo, sem o histórico do build.

Adaptado de Impeccable (Paul Bakaus), Apache-2.0 — https://github.com/pbakaus/impeccable — traduzido e resumido.

# Tipografia, cor e layout

## Tipografia

### Escolher as faces
- Escolha faces como objetos do mundo do assunto, no registro do modo. Operate/Read: stacks de sistema e faces de UI "burro de carga" servem bem. Persuade/Experience: faces com ponto de vista.
- Lista de padrões de treino a evitar sem motivo forte: Fraunces, Playfair Display, Cormorant, Lora, Crimson, Newsreader, Syne, Space Grotesk, Space Mono, IBM Plex, Inter como display, DM Sans, DM Serif, Outfit, Plus Jakarta Sans, Instrument Sans. Usar uma exige razão que nenhuma outra face satisfaz; associação com o assunto nunca é essa razão.
- Hospede a face escolhida (self-host com `@font-face`). Fonte de sistema como voz display de um mundo próprio é falha.
- Use o menor número de papéis e famílias que deixa a hierarquia inconfundível. Segunda família só com um papel que só ela cumpre. Tokens nomeados pelo propósito, não pelo valor.

### Escala e hierarquia
- Passos de tamanho e peso óbvios; papéis vizinhos parecidos demais não carregam funções diferentes. Pelo menos um salto ≥1,25× entre título e corpo.
- Display no máximo 6rem. Combine tamanho, peso, espaço e tom; não peça ao tamanho todo o trabalho.
- Título, corpo, rótulo, metadado e dado precisam ser distinguíveis de relance, sem ler. O mesmo papel fica idêntico em todas as telas e estados.
- Display de marketing pode responder ao espaço disponível (fluido); superfícies densas de produto e leitura ficam previsíveis.

### Leitura
- Corpo: piso de 1rem / 16px na web (exceto papel denso, convenção da plataforma ou ajuste do usuário).
- Medida: 45–75 caracteres (o piso de qualidade pede 65–75ch no corpo); acima de ~80 é falha. Use `max-width` de 65ch a 75ch.
- Entrelinha do corpo: 1,5 a 1,7; abaixo de 1,3 é falha. Linhas mais largas pedem mais entrelinha. Ajuste à face, largura, idioma e contraste, não a uma razão universal.
- Tracking: piso -0,04em; -0,02 a -0,03em costuma ler melhor em display. No corpo, nunca acima de 0,05em; tracking largo só em rótulos curtos em caixa alta.
- Texto claro em fundo escuro: compense nos três eixos: um pouco mais de entrelinha, um toque a mais de tracking e um passo a mais de peso se a face pedir.
- Ritmo de parágrafo: espaço entre parágrafos OU recuo da primeira linha, não os dois.
- Use recursos numéricos, tabulares, de código e de rótulo quando o conteúdo ganha com eles (numerais tabulares em tabelas).
- Em superfícies de leitura, monospace só para código, parâmetros e rótulos pequenos, nunca no texto corrido nem nos títulos.

### Quebras de linha e alinhamento óptico
- `text-wrap: balance` em títulos e blocos curtos centralizados; `text-wrap: pretty` no corpo. Ambos são progressivos.
- Quebra manual em título só entre frases, e conferida em toda largura onde ele aparece. Quebra irregular proposital (uma palavra sozinha para dar peso, linha de pôster) é rara e deliberada.
- Em coluna estreita demais para essas regras ajudarem, edite o texto ou alargue a coluna.
- Rótulo centralizado em botão: `text-box: trim-both cap alphabetic` no elemento do rótulo (um `<span>` com `display:block`), não no container flex. No `@font-face` de fallback, use `size-adjust` = altura de caixa da web font / altura do fallback. Julgue o render: maiúsculas centralizadas não são palavra centralizada.

### Entrega
- Carregue só os pesos usados; fallback com métricas compatíveis; `font-display: swap` ou `optional`; subset; preload só da fonte crítica. Sem texto invisível nem reflow ao carregar. Preserve zoom e configurações de fonte do usuário.

## Cor

### Estratégia antes das cores
Escolha uma:
- **Restrained**: neutros tingidos do mundo + um acento (comum em telas de operar e ler, onde a cor ainda faz trabalho real).
- **Committed**: uma cor saturada cobre 30–60% da superfície.
- **Full palette**: 3–4 papéis nomeados.
- **Drenched**: a superfície É a cor.
Persuade e Experience têm permissão para as estratégias ousadas; use quando o briefing permitir. A cor se compromete em escala de página: campos que ocupam regiões inteiras, não acentos espalhados sobre fundo neutro.

Antes de editar, nomeie: temperatura emocional, relação dominante, faixa de contraste, dosagem.

### Construção
- Papéis, não um saco de amostras: canvas e superfícies elevadas; texto primário e secundário; ação, foco e seleção; bordas e separadores; sucesso, aviso, erro e informação; categorias ou escalas de dados.
- Paleta web nova: prefira OKLCH (luminosidade e croma ajustáveis de forma previsível). Nas rampas, varie a luminosidade e reduza o croma perto do branco e do preto; não force croma alto nos extremos.
- Matiz vem do significado do produto e da direção visual, nunca de associação padrão da categoria.
- Prefira cores explícitas a cadeias de overlays translúcidos (o alfa deixa o contraste dependente do contexto).
- A cor mais forte possui uma região ou um papel. A ação primária fica fácil de achar: não gaste a cor dela em decoração. Em Operate/Read, a raridade dá força ao acento.
- Tinja neutros só quando o matiz da marca cria coesão; cinza neutro é válido quando serve ao mundo.
- Texto secundário sobre superfície colorida: derive do matiz da superfície ou do primeiro plano, nunca cinza genérico.
- Em app (Operate), a cor faz trabalho real: shell com paleta comprometida (trilho ou header colorido, fundo tingido), cores de estado (vermelho = crítico, âmbar = degradado) só onde carregam significado, séries de dados, seleção.
- Dados: diferencie também por luminosidade, croma, forma, rótulo ou padrão; cor nunca é o único código.
- Modo escuro: projete elevação e contraste explicitamente; não inverta o tema claro mecanicamente. Cada tema é composto.
- Com sistema de tokens: valores primitivos + tokens semânticos; trocar tema remapeia os semânticos.

### Contraste (WCAG AA)
- Corpo e placeholder: ≥4,5:1. Texto grande: ≥3:1. Controles, ícones, indicadores de foco: ≥3:1.
- Confira pares computados, não a olho: estados interativos, overlays, texto sobre imagem, desabilitado, os dois temas. Simule daltonismo. Informação por cor também precisa de texto, forma, ícone ou posição.

## Layout e composição espacial

### Por modo
- Persuade/Experience: composição pode ser assimétrica, fluida ou propositalmente disruptiva quando o mundo justifica.
- Operate/Read: estrutura previsível, densidade estável e linearidade navegável são affordances.

### Tese espacial (antes de editar)
Nomeie: o caminho principal de leitura/tarefa; o que fica junto e o que se separa; quem lidera e quem apoia; densidade e ritmo pretendidos; como a estrutura muda por container, viewport, modo de entrada e conteúdo extremo. Escolha o modelo estrutural mais simples que expressa isso.

### Regras
- Teste do olho semicerrado: com detalhes borrados, ainda se vê o elemento primário, o secundário e os grupos, em ordem.
- Agrupe por significado; proximidade antes de containers e decoração.
- Ritmo = contraste deliberado entre intervalos apertados e generosos. Mais espaço acima de um título que abaixo. Um só ritmo de espaçamento na página inteira.
- Escala de espaçamento documentada, sem valores avulsos; base 4 dá os passos intermediários que uma escala só de 8 perde.
- Hierarquia segue a prioridade do produto, não o padrão do framework. Cards, colunas ou seções repetidos só se forem de fato equivalentes.
- Densidade conforme frequência de uso, complexidade da decisão e modo.
- Responsivo é estrutural: reordenar, colapsar, refluir ou revelar conforme o que continua importante. Componentes que aparecem em contextos diferentes: prefira container-aware (nota: ex. container queries). `gap` para ritmo entre irmãos.
- Desktop de 1280 a 1600: colunas fluidas, sem grid em pixel fixo que quebra 100px mais estreito.
- Alvos de toque utilizáveis (44×44pt) mesmo com marca visual pequena.
- Profundidade só quando esclarece estado ou hierarquia. Elevação declarada uma vez (borda ou sombra); sombras com deslocamento e desfoque suave. Raio de card 12–16px.
- Variação não é objetivo: repetição ajuda o reconhecimento; quebre-a só quando conteúdo ou prioridade mudam.
- Ordem do DOM, do foco e do leitor de tela concorda com a ordem visual.
- Teste os extremos: texto longo, vazio, overlays, sticky, safe areas, tradução, zoom.
- Ritmo de scroll: varie densidade, escala, imagem, movimento e silêncio numa gramática; um trecho denso ganha um trecho quieto; a página fecha com um fechamento real.

### Carga cognitiva
- ≤4 itens por grupo; ≤4 opções visíveis em cada ponto de decisão (5–7 já força; 8+ sobrecarrega).
- Ações: 1 primária, 1–2 secundárias, o resto em menu. Navegação: ≤5 itens de topo.
- Hierarquia: um elemento primário, 2–3 secundários, todo o resto atenuado.

Adaptado de Impeccable (Paul Bakaus), Apache-2.0 — https://github.com/pbakaus/impeccable — traduzido e resumido.

# Imagens, ilustrações, ícones e placeholders

## Princípio: crie os assets, não os substitua por chrome
- Superfícies ótimas vivem de conteúdo feito com cuidado: nomes, entradas, textos, capas, miniaturas, texturas.
- Em trabalho do zero, todo espaço que as perguntas iniciais deixaram aberto é seu para criar em fidelidade de produção. Conteúdo pode ser criado, alegações podem ser rotuladas, nenhuma seção pode ser omitida.
- Gradientes, vidro, blocos de ícones genéricos e `clip-path` poligonal com muitos vértices onde caberia um asset autoral são "o buraco vestindo chrome".
- Em Persuade, entregue imagens reais quando o briefing pede; siga o mundo comprometido, não o hábito da categoria.

## Imagens reais (fotos, stock)
- Use imagens reais e verificadas quando o briefing implica. Procure o **objeto físico do assunto**, não a categoria. Uma foto decisiva vale mais que cinco medianas.
- Verifique que as URLs de stock respondem (não publique link quebrado).
- Guarde a origem de cada raster de stock, fonte externa ou já existente.
- Prova vale mais que alegação: mostre o produto trabalhando, o mecanismo dramatizado, especificidades que o concorrente não copia.

## Imagens geradas
- Imagem gerada é material, não alegação. A regra de evidência vale para afirmações, especificações, depoimentos e fotos apresentadas como reais; não para a fidelidade do render.
- Dados e material ilustrativo: crie em fidelidade total, rotule como sintético onde um visitante poderia confundir com o real, e entregue ao usuário a lista do que trocar por material real.
- Registre junto de cada imagem gerada o prompt exato usado (nota: o Impeccable embute o prompt no arquivo; o princípio é que todo raster tenha proveniência: o prompt, ou a origem se for stock/externo).
- Uma imagem que um ajuste abandona é apagada no mesmo lote.
- Imagens de referência/inspiração são inspiração rotulada, nunca a promessa do que será construído.

## O que é imagem (raster) e o que é código
Decida pelo que os pixels são, não pelo que parece fácil de construir:
- **Raster**: figura, objeto de produto, maquinário, qualquer ilustração com perspectiva, sombreamento ou habilidade de desenho, e qualquer textura com nome (tecido, grão de papel, couro, metal escovado).
- **Código semântico**: texto, controles, chrome, diagramas com elementos contáveis, sistemas de formas chapadas, e tudo que precisa se mover, escalar ou responder.
- Escrever "CSS" para o acabamento de um painel esculpido, ou um `clip-path` de muitos vértices para uma borda rasgada, é apagar o design em silêncio.
- SVG inline além do porte de um ícone (diagrama, notação, linhas de chamada com setas, "aproximação rápida" da arte) é desenho: vira raster. SVG do tamanho de ícone (<64px, poucos paths) tudo bem. Gráfico desenhado a partir de dados em runtime é gráfico, não ilustração.
- Nunca rasterize o texto central da UI nem os controles.

## Produzir o raster
- Gere em pelo menos 1,5× o tamanho da região onde vai ficar.
- Figura, objeto ou tinta isolados: PNG com transparência nativa, para assentar no fundo da própria página. Fotos e texturas: opacas.
- Textura (papel, tecido, grão): um trecho limpo espelhado em mosaico até o tamanho; gere só se não houver trecho limpo.
- Confira o alfa sobre fundo claro e escuro: bordas finas, brancos preservados, buracos limpos. Não faça chroma-key em saída que já tem alfa.
- Coloque com `object-fit: cover`, `<img>` ou background; a caixa precisa conter a arte inteira com margem, senão o `cover` corta um lado.
- Arquivo único: o raster é produzido igual e embutido como data URI.

## Ilustração
- **Ilustração real ou nenhuma.** Cenas SVG estilo esboço, classes `loose-sketch`/`doodle` e grão `feTurbulence` parecem amadoras.
- Isso proíbe SVG imitando figura, nunca SVG fazendo geometria: formas vetoriais nítidas, diagramas, traço animado e efeitos em shader são mídia de primeira classe. Ilustração com sombreamento, perspectiva ou figuras é "figura" mesmo em estilo traço; geometria = formas que se especificam com exatidão.
- Ilustração de hero montada com formas primitivas lê como clip-art. Ícones, logos e gráficos de dados vão bem na escala deles; um visual do tamanho do hero merece arte real, foto ou gráfico desenhado com intenção.
- Material de impressão na própria técnica: se o mundo é gravura, água-forte ou bico de pena, desenhe como linha. Traços dão a forma, hachura (padrões SVG recortados em cada forma) dá o tom, cor entra como aguada translúcida dentro das linhas. Preenchimento chapado sob contorno fino lê como clip-art. Use os assets do mundo ou um objeto desenhado por placa; nunca escreva um motor de desenho.

## Máscaras, fundos e opacidade
- Máscaras geométricas (círculo, polígono, recorte por gradiente radial) imitando o contorno de um objeto fotográfico são a versão barata e leem pior que nada. Derive uma máscara alfa da imagem real, ou produza um recorte. `clip-path` fica para geometria: cantos cortados, diagonais, hexágonos.
- Fundos são superfícies, texturizados só com coisas do mundo do assunto. Listras `repeating-linear-gradient` e grades de linhas só com canvas, mapa, planta ou instrumento de medida de verdade por baixo.
- Raster enterrado: imagem de fundo sob véu de gradiente quase opaco ou em opacidade quase zero nunca chega à tela. Deixe o material aparecer (tinta abaixo de 0,9 de alfa, blend mode, opacidade visível) ou remova o arquivo.

## Ícones
- Ícones são desenhados: de uma biblioteca real ou SVG autoral, em um único traço e peso. Nunca emoji nem glifo Unicode como sistema de ícones.
- Família coerente: traço, peso, tamanho e alinhamento óptico iguais.
- Controle só com ícone precisa de nome acessível. Navegação só com ícones, sem texto, falha com iniciantes: rotule.
- Se o usuário escolheu uma biblioteca de ícones, use exatamente ela.

## Placeholders: quando são aceitáveis
- O trabalho termina completo, exceto assets que só o usuário pode fornecer.
- Nunca publique `<img>` com `src` vazio ou placeholder: vira caixa de imagem quebrada. Use imagem real, asset gerado, ou remova a tag.
- Um espaço reservado para imagem nomeia um trabalho (âncora, evidência), não um convite para foto decorativa: preencha com o que o assunto realmente tem.
- Em telas de produto, use conteúdo realista (nome do produto, dados com valores e unidades plausíveis, rótulos reais, um estado interessante como um alerta), nunca blocos de placeholder.
- Marca: nunca invente um logotipo; peça ao usuário. Placeholders que o usuário deve preencher (conta, chave, texto legal) só com o acordo dele, dizendo exatamente quais linhas.
- Estado vazio: ilustração ou ícone, não só texto numa página em branco; diga o que vai aparecer ali, por que importa, e um botão claro para criar o primeiro item.

## Entrega técnica
- Formatos modernos (WebP, AVIF); tamanho certo (não carregue 3000px para exibir 300px); qualidade 80–85% costuma ser imperceptível.
- `srcset`/`sizes` ou `<picture>`; lazy load abaixo da dobra, nunca acima.
- Defina dimensões ou `aspect-ratio` para não gerar layout shift (CLS < 0,1). Otimize e pré-carregue a imagem do hero (LCP < 2,5s).
- Alt text transmite a informação da imagem; imagem decorativa leva `alt=""`.
- Imagem de compartilhamento social (`og:image`): mire em 1200×630. Favicon e ícone grande de app como arquivos de imagem.

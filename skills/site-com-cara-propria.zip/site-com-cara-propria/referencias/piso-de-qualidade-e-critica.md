Adaptado de Impeccable (Paul Bakaus), Apache-2.0 — https://github.com/pbakaus/impeccable — traduzido e resumido.

# Piso de qualidade, crítica e polimento

## Piso de qualidade (o mínimo, checado no render)
Leia antes de qualquer edição de UI, depois que a direção está decidida, e construa sem anunciar a lista. Briefing fixado ou mundo visual comprometido vencem tudo aqui, exceto o que é proibição; o seu hábito não vence. Cada item é uma checagem no resultado construído, não uma intenção; rode todas juntas na mesma olhada.
- **Contraste**: corpo e placeholder ≥4,5:1; texto grande ≥3:1. Em superfície colorida, texto secundário tingido do matiz ou do primeiro plano, nunca cinza.
- **Profundidade**: sombras com deslocamento e desfoque suave. Halo colorido sem deslocamento é decoração.
- **Espaçamento**: grupos apertados, separação generosa, mais espaço acima de um título que abaixo. Leia os valores computados.
- **Tipo**: corpo 65–75ch, display no máximo 6rem, tracking mínimo -0,04em, títulos balanceados, saltos óbvios de tamanho e peso. Rode o texto real em todo breakpoint e corrija o que transborda.
- **Movimento**: um momento autoral; nem efeitos espalhados nem a mesma entrada em toda seção. Ease-out exponencial a partir de um padrão já visível.
- **Estados**: hover, desabilitado, carregando, erro, vazio. Mais: conteúdo real, controles funcionando, composição responsiva, foco de teclado.
- **Superfícies do navegador**: seleção de texto, cursor, scrollbar, anel de foco, distância do sublinhado e numerais de tabela vêm no padrão do navegador. Tematize pela paleta: é o sinal mais barato de página construída (e não montada), e o que modelos mais pulam.
- **Texto**: a linguagem do próprio produto. Controles dizem a ação; erros dizem o problema e a recuperação.
- **Cobertura**: todo requisito do briefing presente e encontrável em segundos.
- O piso cuida da mecânica, nunca escolhe a direção. Com tudo verde, gaste a página no mundo comprometido. **Entre refinado e comprometido, comprometa.**
(A lista do que recusar está em sinais-de-ia.md.)

## Julgar a partir de screenshots
- Captura só vale se for válida: animações de entrada estabilizadas, página do topo, cada arquivo aberto e conferido (sem região preta/branca, sem seção errada, sem meio carregado). Nunca julgue fidelidade por miniatura de página inteira: ela esconde justamente as falhas que importam.
- Capture desktop e mobile (e a largura real do usuário). Em algo interativo, percorra cada estado (aberto, fechado, hover, foco, erro, vazio, texto longo) procurando sobreposição e corte.
- Perguntas de uma olhada:
  - **Especificidade (comece aqui)**: parece feito para este produto, ou um produto qualquer usaria sem mudar?
  - **Memória**: quem saísse após a primeira viewport descreveria o quê? Se for "um clima", falhou.
  - **Modo sem legenda**: dá para dizer pelo render se é página de persuadir, operar ou ler?
  - **Olho semicerrado**: com detalhe borrado, vê-se o primário, o secundário e os grupos, em ordem?
  - **Esqueleto**: sem o texto, a estrutura ainda diz o que cada seção é?
  - Persuade: um visitante novo sabe em segundos o que é, por que importa e o que fazer. Operate: com o nome coberto, lê como produto da categoria, tão limpo quanto o padrão e mais distinto que ele. Read: o leitor sabe onde está, para onde ir, e lê o corpo com conforto.
  - Toda ação prometida tem elemento funcionando; todo objeto desenhado em código se reconhece de relance no tamanho real.
- Faça a avaliação de design antes de olhar resultados de detectores automáticos: eles ancoram o julgamento. Detector limpo não prova hierarquia nem ritmo.

## Rubrica de crítica

### Carga cognitiva (8 itens; conte as falhas)
Foco único; agrupamento em pedaços (≤4 itens por grupo); itens relacionados agrupados visualmente; hierarquia imediata; uma decisão por vez; poucas escolhas (≤4 opções visíveis); nada a lembrar da tela anterior; complexidade revelada só quando necessária.
0–1 falhas = baixa (bom); 2–3 = moderada; 4+ = alta (correção crítica).
Memória de trabalho ≤4 itens (Cowan, 2001): ≤4 ok; 5–7 no limite; 8+ sobrecarga.
Violações típicas: parede de opções (10+ sem hierarquia), ponte de memória, navegação oculta (mostre onde o usuário está), barreira de jargão, chão de ruído (tudo com o mesmo peso: um primário, 2–3 secundários, resto atenuado), padrão inconsistente, multitarefa simultânea, troca de contexto para uma única decisão.

### Heurísticas de Nielsen (0–4 cada; 4 = genuinamente excelente)
1. Visibilidade do estado do sistema (loading, confirmação, progresso, onde estou, validação inline).
2. Correspondência com o mundo real (sem jargão, ordem natural).
3. Controle e liberdade (desfazer, cancelar, voltar, limpar filtros).
4. Consistência e padrões.
5. Prevenção de erros (confirmação destrutiva, restrições, bons padrões, autosave).
6. Reconhecer em vez de lembrar (opções visíveis, rótulos nos ícones).
7. Flexibilidade e eficiência (atalhos, ações em lote).
8. Estético e minimalista (todo elemento ganha seu pixel).
9. Recuperação de erros (linguagem clara, problema específico — "falta o @ no e-mail", não "entrada inválida" —, solução, perto da origem, sem apagar o formulário).
10. Ajuda e documentação (contextual, focada em tarefa).
Faixas (/40): 36–40 Excelente; 28–35 Bom; 20–27 Aceitável; 12–19 Ruim; 0–11 Crítico. A maioria das interfaces reais fica entre 20 e 32. Em Persuade/Experience, 7 e 10 podem ser n/a: renormalize e use percentual (90%+ Excelente, 70%+ Bom, 50%+ Aceitável, 30%+ Ruim).

### Personas (escolha 2–3)
- **Alex, usuário avançado impaciente**: tarefa central em <60s? Atalhos? Pular onboarding? Esc fecha modal? Alertas: tutorial forçado, animações lentas que não se pulam, confirmação redundante.
- **Jordan, iniciante confuso**: primeira ação clara em 5 segundos? Ícones com texto? Alertas: navegação só com ícones, jargão, sem confirmação de sucesso.
- **Sam, depende de acessibilidade**: fluxo todo por teclado, foco visível, alt text, 4,5:1, leitor de tela anuncia mudanças, zoom até 200%. Alertas: significado só por cor, campos sem rótulo.
- **Riley, testador de estresse**: 0 itens, 1000 itens, texto enorme, emoji, RTL, refresh no meio do fluxo. Alertas: falha silenciosa, vazio "Sem resultados" sem orientação, perda de dados.
- **Casey, mobile distraído**: ações na zona do polegar, estado preservado ao sair, 3G, alvos ≥44×44pt. Alertas: ação importante no topo, assets pesados sem lazy load.
Landing/marketing: Jordan, Riley, Casey. Dashboard/admin: Alex, Sam. Checkout: Casey, Riley, Jordan. Onboarding: Jordan, Casey. Formulários: Jordan, Sam, Casey.

### Severidade e relatório
- P0 bloqueante (impede a tarefa; corrigir já); P1 grave (antes do lançamento); P2 menor (há contorno); P3 polimento. Na dúvida: "o usuário abriria chamado por isso?" Se sim, é pelo menos P1.
- Estrutura: veredito de especificidade; impressão geral (o que funciona, o que não, a maior oportunidade); 2–3 acertos com o porquê; 3–5 problemas prioritários (o quê / por que importa / correção concreta); alertas por persona com elementos exatos; observações menores; perguntas provocativas.
- Seja direto e específico ("o botão de enviar", não "alguns elementos"); corte "considere explorar"; priorize sem dó; não suavize a crítica.

## Polimento (checklist final)
Polir é refinar, nunca redesenhar escondido; se o conceito está errado, diga.
1. Ordem de triagem: (1) tarefas quebradas, perda de dados, estado enganoso, caminho inacessível; (2) estados faltando: carregando, vazio, erro, sucesso, desabilitado, permissão; (3) fluxo, hierarquia, responsivo, desvio do sistema; (4) inconsistências visuais e de movimento; (5) limpeza de código e assets. Não aperfeiçoe um canto deixando o resto abaixo do nível.
2. Fluxo: mesma terminologia e modelo mental das áreas vizinhas; tarefa primária e estado atual óbvios sem achatar tudo.
3. Layout e tipo: alinhamento ao grid e à escala (óptico e matemático); mesmo papel = mesma tipografia; teste medida, quebra, tradução, zoom, carregamento de fonte em todo viewport.
4. Cor, imagem, ícones: tokens semânticos; contraste em todo estado; família de ícones coerente (traço, peso, tamanho, alinhamento óptico); imagens sem layout shift, proporção correta, fontes responsivas, alt útil.
5. Interação: todo controle com padrão, hover, foco, ativo, desabilitado, carregando, erro e sucesso; foco visível, ordem de tab lógica, rótulos, alvos de toque. Movimento coerente, interrompível, performático; não anime só para "mostrar polimento".
6. Conteúdo e código: terminologia, maiúsculas e pontuação consistentes; remova debug, código morto, imports e estilos órfãos.
7. Verifique de novo com mouse, teclado e toque: mobile, intermediário, largo; zoom; erros de console; layout shift; latência. Entregue só quando completo e consistente em todo o caminho.

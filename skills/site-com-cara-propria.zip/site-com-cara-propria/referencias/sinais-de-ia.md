Adaptado de Impeccable (Paul Bakaus), Apache-2.0 — https://github.com/pbakaus/impeccable — traduzido e resumido.

# Sinais de "feito por IA" e o que fazer no lugar

Regra geral: são os padrões da categoria, não proibições; as palavras do briefing podem justificar qualquer um. Itens marcados **BANIDO** nenhum briefing justifica. Usar um deles com o eixo livre significa que você não decidiu; a correção é reescrever o elemento, não suavizá-lo.

## Os 4 looks em que a IA cai (calibração)
1. Fundo creme quente + serifa display de alto contraste + acento terracota ou vermelho-sinal.
2. Quase-preto + um acento neon + bordas brilhando.
3. Editorial de jornal: filetes finos, serifa display itálica, rótulos pequenos em mono espaçado.
4. Tinta chapada saturada + caixas pretas + sombras duras deslocadas + display condensada pesada.
Todos são legítimos se o briefing pede. Com estética livre, cair num deles = autocrítica falhou. Assunto "livro/quente/infantil" não justifica creme + serifa: é o padrão vestindo a roupa do assunto.

## Tipografia
- Fontes saturadas (em Persuade/Experience): Fraunces, Playfair Display, Cormorant, Lora, Crimson, Newsreader, Syne, Space Grotesk, Space Mono, IBM Plex, Inter como display, DM Sans, DM Serif, Outfit, Plus Jakarta Sans, Instrument Sans; o detector também cita Inter, Roboto e Geist. → Escolha uma face com caráter vinda do mundo do assunto. Associação óbvia (livro→serifa, livraria→letra à mão, tech→mono) nunca é motivo.
- Serifa itálica enorme como headline do hero (Fraunces, Recoleta, Playfair, Newsreader itálico). → Romano, ou display não serifada (registro editorial pode querer; julgue pelo contexto).
- Hierarquia plana: títulos e corpo com menos de 1,25× de diferença em todos os passos. → Pelo menos um salto de tamanho forte.
- Tracking esmagado abaixo de -0,04em. → -0,02 a -0,03em costuma ler melhor.
- Frase inteira em tamanho display dominando a viewport. → Headline longa menor, ou copy mais curta (1–2 palavras gigantes tudo bem).
- Monospace como fantasia de "técnico". → Mono só para código, dados, medidas.
- Fonte de sistema (Impact, Arial Black, sans da plataforma) como voz display de um mundo próprio. → Hospede uma face que combine; "a fonte instalada mais parecida" é falha.
- **BANIDO**: kicker/eyebrow (rótulo pequeno em caixa alta espaçada) acima do título, inclusive em forma de pílula no hero. → Apague; o título carrega o próprio peso.
- Números de seção (01 / 02 / 03) repetidos. → Só se a sequência informa algo ao leitor.
- Legibilidade: corpo em caixa alta (≥80 caracteres), tracking >0,05em no corpo, corpo <12px, texto funcional <11px, entrelinha <1,3, linhas >~80 caracteres, justificado em coluna estreita sem hifenização, última linha com uma palavra, título com última linha muito curta.

## Cor
- Gradientes roxo/violeta e ciano sobre escuro; neon chapado em fundo escuro somado a outra cor-sinal. → Paleta distinta e intencional, matiz vindo do significado do produto.
- Fundo creme/bege como superfície "de bom gosto" por reflexo. → Fundo de uma paleta deliberada.
- Glow colorido: halo de deslocamento zero (box/text-shadow) ou sombra colorida borrada em fundo escuro. → Sombras neutras de elevação com deslocamento e desfoque.
- Halo radial saturado / "spotlight" radial atrás do hero flutuando sobre o texto. → Superfície sólida ou levemente variada; luz como acento material deliberado.
- Texto em gradiente. → Cor sólida; ênfase vem de peso ou tamanho.
- Texto cinza sobre fundo colorido. → Tom mais escuro da própria cor de fundo, ou branco/quase-branco.
- Claro/escuro escolhido pela categoria. → Escolha pela cena de uso (quem, onde, que luz).
- Acentos minúsculos espalhados sobre fundo neutro; em app, tela cinza com um acento. → Cor comprometida em escala de página: campos que ocupam regiões inteiras, shell colorido.

## Layout e estrutura
- Cards iguais de ícone + título + texto como estrutura da página. → Topologia que vem do conteúdo; cards são o container preguiçoso.
- Cards dentro de cards (sempre errado). → Espaçamento, tipografia e divisores.
- Template de "métrica herói": número grande, rótulo pequeno, stats de apoio, acento.
- Hero dividido (texto de um lado, produto do outro, fileira de badges embaixo) ou título centralizado sobre fileira de cards: é o template, seja qual for o mundo que o pinta.
- Página genérica de produto: título sobre subtítulo e botão, fileira de cards iguais abaixo.
- Espaçamento monótono (mesmo valor em tudo). → Grupos apertados, separações generosas.
- Título mais perto do bloco de cima do que do próprio conteúdo. → Mais espaço acima do título que abaixo.
- Modal para tarefa que não precisa de interrupção nem foco protegido.
- Texto colado na borda da viewport (<16px; <12px em telas ≤480px) ou do container (<8px; ideal 12–16px).
- Coluna que estica muito além da dobra ao lado de outra curta; cards cortados na borda de um carrossel; o mesmo texto repetido 3+ vezes num card.

## Componentes e superfícies
- Barra num lado de uma caixa arredondada (borda lateral, inset shadow ou pseudo-elemento), qualquer cor. → Borda inteira, fundo tingido, ou ícone/rótulo à frente.
- Borda grossa de acento num card arredondado.
- Vidro e blur como decoração, não como efeito específico.
- Sombra dura deslocada (`box-shadow: 4px 4px 0`) fora de um mundo de fato neobrutalista.
- Borda de 1px + sombra larga e difusa em toda uma fileira ("card fantasma"). → Declare elevação uma vez: borda OU sombra. Raio de card 12–16px; pílula só em controle pequeno.
- Quadradinho arredondado com ícone acima do título (o card-feature universal). → Ícone ao lado do título, ou solto no fluxo.
- Sparklines, anéis de progresso e retângulos com sombra suave no lugar de conteúdo.
- Emoji ou glifos Unicode como sistema de ícones. → Biblioteca real ou SVG autoral, traço e peso únicos.
- Listras `repeating-linear-gradient` e grade de linhas no fundo. → Só se houver canvas, mapa, planta ou instrumento de medida de verdade.
- Componente de prateleira dentro de uma forma comprometida.
- Partes do navegador no padrão: seleção de texto, cursor de texto, scrollbar, anel de foco, distância do sublinhado, numerais de tabela. → Tematize pela paleta; é o sinal mais barato de "construído, não montado" e o que modelos mais pulam.

## Movimento
- Easing bounce ou elastic. → Desaceleração exponencial (ease-out quart/quint/expo).
- Ponto de status pulsando para simular "ao vivo". → Pulso só para dado realmente vivo; senão indicador estático rotulado.
- Cursor piscando falso no hero simulando digitação.
- Marquee rolando sozinho.
- Mesma entrada (fade e subida) em toda seção; hover que levanta, parallax e reveal genéricos como "ideia". → Um momento autoral, orquestrado.
- Conteúdo invisível em repouso (reveal que falhou). → Conteúdo visível por padrão; JS só melhora a entrada.

## Texto (copy)
- Jargão de SaaS: streamline, empower, supercharge, world-class, enterprise-grade, next-generation, cutting-edge. → Verbo e substantivo específicos do que o produto faz.
- Cadência de aforismo em 3+ seções ("X. Sem Y." / "Não é um recurso. É uma plataforma."). Uma vez tudo bem; o padrão é o sinal.
- Excesso de travessão (≥8, cerca de 1 a cada 500 caracteres). → Vírgula, dois-pontos, ponto, parênteses.
- Desqualificar algo como "teatro". → Diga o que a coisa faz ou não faz.
- Alegações e números inventados. → Só verdade fornecida; valores ilustrativos rotulados.
- Botões "Sim/Não/OK/Enviar", placeholder como rótulo, erro "Algo deu errado". → Verbo + objeto; erro diz o que falhou e como recuperar.
- Humor genérico ("whimsy"). → Clareza neutra é melhor que graça genérica.

## Imagens
- Ilustração de hero montada com formas SVG primitivas (clip-art). → Arte real, foto ou gráfico desenhado com intenção.
- Cenas SVG estilo esboço, classes `doodle`/`loose-sketch`, grão `feTurbulence`.
- `clip-path` orgânico com muitos vértices, ou círculo/polígono imitando o contorno de uma foto. → Máscara alfa da imagem real ou recorte em raster.
- Imagem enterrada sob véu quase opaco ou opacidade quase zero. → Deixe o material aparecer, ou remova.
- `<img>` com src vazio ou placeholder.
- Gradiente, vidro, ícones genéricos onde deveria haver um asset autoral: é "o buraco vestindo chrome".

## Testes finais
- Especificidade: um produto vizinho poderia usar isto sem mudar nada? Então é genérico.
- Se o seu estilo é adivinhável pela categoria, refaça até não ser.

# Origem e licenças

Esta skill (texto em português, do Progress Code) é uma obra derivada, traduzida, resumida e reorganizada, de:

- **Impeccable**, de Paul Bakaus — https://github.com/pbakaus/impeccable — licença Apache-2.0
  (texto completo em `LICENSE-impeccable.txt`). Os arquivos em `referencias/` adaptam o SKILL.md e os arquivos
  `reference/*.md` do Impeccable (new-work, new-work-world, craft-floor, craft, animate, overdrive, bolder, delight,
  layout, typeset, colorize, critique-rubric, critique, polish, mode-persuade, foundations). As instruções ligadas às
  ferramentas do Impeccable (launcher, PRODUCT.md/DESIGN.md, scripts) foram removidas.
- **frontend-design**, da Anthropic — https://github.com/anthropics/skills (skills/frontend-design) — licença
  Apache-2.0 (texto completo em `LICENSE-frontend-design.txt`).

Alterações feitas: tradução para o português, resumo, reorganização em etapas, junção com a tabela de funcionalidades
por ramo e as regras próprias do Progress Code (perguntas antes de construir, nada inventado, conferência por captura).
Trechos marcados "(nota)" são acréscimos nossos.

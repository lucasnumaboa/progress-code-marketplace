---
name: site-com-cara-propria
description: Método para criar sites e landing pages que NÃO parecem modelo genérico — funcionalidades específicas do tipo de negócio (catálogo, agenda, cardápio, simulador…), identidade visual tirada do próprio negócio e checagem final anti-genérico. Use ao planejar, desenhar, construir ou revisar qualquer site ou página.
---

# Site com cara própria

Site genérico acontece por três motivos: começa pelo layout em vez do negócio, usa as mesmas funcionalidades para
qualquer ramo e escolhe visual "padrão de IA" (gradiente roxo, três cards iguais, ícones de linha, foto de banco).
Este método ataca os três. Siga as etapas na ordem e não pule a ficha do negócio.

## Etapa 1 — Ficha do negócio (antes de qualquer tela)
Levante e guarde num arquivo `site/ficha.md`:
- O que é vendido/oferecido, para quem, em que cidade/região, faixa de preço.
- A AÇÃO principal que o visitante deve fazer (comprar, agendar, pedir orçamento, chamar no WhatsApp, se inscrever).
- 3 diferenciais REAIS (com prova: número, prêmio, tempo de mercado, depoimento, garantia). Sem diferencial, pergunte.
- Concorrentes ou referências que o dono admira e que detesta (e por quê).
- Material que já existe: logo, fotos próprias, cores da fachada/embalagem/uniforme, tom de voz das redes.
- Restrições: hospedagem, domínio, quem vai atualizar, orçamento, prazo, LGPD (formulários, cookies).

## Etapa 2 — Mapa de funcionalidades do ramo
Escolha o ramo abaixo (ou o mais próximo) e trate os itens "essenciais" como obrigatórios. Funcionalidade é o que faz
o site parecer DO NEGÓCIO: um restaurante sem cardápio navegável ou uma clínica sem agendamento é site genérico.

| Ramo | Essenciais | Diferenciais que impressionam |
|---|---|---|
| Loja / produto | página de produto com galeria e zoom, variações (cor/tamanho) com preço e estoque, frete por CEP, carrinho, avaliações com foto, perguntas frequentes do produto | provador/guia de medidas, "compre junto", comparador de modelos, contador de estoque baixo verdadeiro, vídeo de uso |
| Restaurante / delivery | cardápio por categorias com fotos e preços, horário "aberto agora", pedido (WhatsApp ou app), mapa e como chegar | filtro (vegano, sem glúten), prato do dia, reserva de mesa, montagem de combo |
| Clínica / saúde / estética | especialidades e profissionais com registro (CRM/CRO…), agendamento por horário, convênios aceitos, endereço com mapa | preparo de exames, pré-consulta online, antes/depois com consentimento, teleconsulta |
| Serviços locais (reformas, oficina, limpeza) | orçamento rápido com fotos do problema, área atendida por bairro/CEP, prazos, garantia | calculadora de orçamento estimado, galeria antes/depois, acompanhamento do serviço |
| Imobiliária | busca com filtros (bairro, preço, quartos, vagas), ficha do imóvel com galeria, mapa, agendar visita | simulador de financiamento, tour 360, comparação de imóveis, alerta de novos imóveis |
| Academia / estúdio | planos e preços, grade de horários por modalidade, aula experimental, unidades | calculadora de objetivo, depoimentos com resultado, app/check-in |
| Escola / curso / infoproduto | grade do curso, professor com credenciais, preço e formas de pagamento, inscrição | aula grátis, simulado, depoimentos em vídeo, certificado de exemplo, garantia |
| Escritório (advocacia, contabilidade) | áreas de atuação explicadas em linguagem simples, equipe, contato para triagem | checklist de documentos, calculadora (rescisão, simples nacional), artigos que respondem dúvidas reais |
| SaaS / B2B | o problema e o resultado em números, demonstração (vídeo ou interativa), planos, integrações, segurança | ROI/economia calculada, casos por segmento, trial sem cartão, página de comparação |
| Evento | data, local, programação por horário, palestrantes, inscrição/ingresso com lotes | contagem regressiva real, mapa do local, agenda pessoal, transmissão |
| Turismo / hotel / pousada | quartos com fotos e capacidade, disponibilidade e reserva, localização e passeios | calendário de preços, pacotes, roteiro sugerido, clima da época |
| Beleza / salão / barbearia | serviços com duração e preço, agendamento com profissional, portfólio de cortes | escolha de profissional, pacote fidelidade, galeria por estilo |
| Pet | serviços (banho, tosa, vet) com agenda, produtos, emergência | ficha do pet, lembrete de vacina, leva-e-traz por bairro |
| ONG / causa | missão com números de impacto, como doar (Pix, recorrente), transparência (prestação de contas) | histórias de beneficiados, metas com barra real, voluntariado |
| Portfólio criativo | trabalhos com contexto (problema → solução → resultado), sobre, contato | estudo de caso aprofundado, filtro por tipo, depoimentos de clientes |
Sempre que fizer sentido no Brasil: botão de WhatsApp com mensagem pronta, Pix, frete/área por CEP, aviso de cookies
(LGPD) e política de privacidade quando houver formulário.

Registre em `site/funcionalidades.md`: essenciais (vão na primeira versão), diferenciais escolhidos (1 a 3) e o que
fica para depois. Cada funcionalidade com: onde aparece, o que o visitante faz, de onde vêm os dados.

## Etapa 3 — Direção visual tirada do negócio
Nunca comece por "um layout moderno". Tire a identidade do que o negócio já tem:
- **Cor:** parta da cor da marca, da fachada, da embalagem, do produto ou da paisagem da cidade. Uma cor dominante, uma
  de apoio e um neutro com temperatura (creme, areia, grafite quente), não o cinza padrão. Teste contraste (WCAG AA).
- **Tipografia:** um par com personalidade ligado ao ramo. Exemplos: padaria artesanal — serifada calorosa + sans
  humanista; oficina — sans condensada forte + mono para números; escritório — serifada clássica + sans neutra;
  estúdio criativo — display expressiva + sans simples. Defina escala (títulos grandes de verdade) e altura de linha.
- **Imagem:** fotos reais do negócio sempre que possível (peça). Sem foto, use ilustração/fotografia com uma direção
  única (luz, enquadramento, cor). Evite foto de banco com pessoas sorrindo para o nada.
- **Forma e textura:** um detalhe recorrente que vem do negócio (o recorte de uma etiqueta, o grid de azulejo, o traço
  de uma planta baixa, a costura de um tecido) usado em divisores, molduras, ícones.
- **Layout:** escolha um padrão que combine com o conteúdo — editorial (texto e foto grandes), catálogo em grade,
  mosaico (bento), dividido (split), linha do tempo. Varie o ritmo entre seções; não repita "título + 3 cards" em tudo.
- **Movimento:** 1 ou 2 microinterações com propósito (o carrinho que "pula", o horário que muda para "aberto agora",
  o contador de vagas). Nada de animação em tudo.
Proponha 2 ou 3 direções em `site/direcao-visual.md` (paleta com hex, par tipográfico, exemplos de seção, detalhe
recorrente) e peça ao usuário para escolher uma antes de construir.

## Etapa 4 — Conteúdo antes do design final
Escreva os textos de verdade (nada de lorem ipsum) seguindo a ação principal: título que diz o resultado para o
cliente, prova logo em seguida, objeções respondidas, chamada para ação repetida nos pontos certos. Use as palavras que
o cliente usa (veja avaliações do Google, comentários, perguntas no WhatsApp).

## Etapa 5 — Construção
- Componentes reaproveitáveis e tokens de design (cores, fontes, espaçamentos) num só lugar.
- Mobile primeiro: a maioria chega pelo celular; botão de ação sempre alcançável.
- Desempenho: imagens otimizadas (WebP/AVIF, tamanhos responsivos, lazy), fontes com `font-display: swap`, nada de
  biblioteca pesada para um efeito pequeno.
- SEO técnico: título e descrição por página, um H1, dados estruturados do ramo (schema.org LocalBusiness, Product,
  Restaurant, Event, Course…), sitemap, URLs legíveis, Open Graph.
- Acessibilidade: contraste, foco visível, textos alternativos, formulários com rótulos, navegação por teclado.
- Formulários e dados pessoais: consentimento, política de privacidade, nada de coletar o que não precisa.

## Etapa 6 — Checagem anti-genérico (obrigatória antes de entregar)
Responda "sim" a todos; se algum for "não", volte e corrija:
1. Se eu trocar o logo por outro de outro ramo, o site continua fazendo sentido? (Deve ficar estranho — sinal de que é específico.)
2. As funcionalidades essenciais do ramo estão funcionando (não só desenhadas)?
3. A paleta e a tipografia vêm de algo do próprio negócio, e eu sei dizer de onde?
4. Há pelo menos um detalhe visual recorrente que só este negócio teria?
5. Nenhuma seção é "título + 3 cards com ícone" sem motivo; o ritmo varia entre seções?
6. Os textos têm números, nomes, lugares e provas reais (nada de "soluções inovadoras de qualidade")?
7. A ação principal aparece acima da dobra no celular e se repete no fim?
8. Abri no celular e no desktop (Browser, captura de tela) e conferi visualmente cada seção?
9. Desempenho e acessibilidade básicos conferidos (imagens otimizadas, contraste, foco, alt)?
10. LGPD: aviso de cookies/política quando há rastreio ou formulário?

Entregue junto um `site/LEIA-ME.md` com: como rodar/publicar, onde editar textos e preços, e o que ficou para a próxima versão.

---
name: site-com-cara-propria
description: Método de estúdio para criar sites e landing pages que NÃO parecem feitos por IA — perguntas certas, mundo visual tirado do assunto, 2 ou 3 direções para escolher, um momento marcante (3D, animação, interação) construído de verdade, lista de sinais de IA para evitar e conferência por captura. Use ao planejar, desenhar, construir, criticar ou refazer qualquer site ou página.
---

# Site com cara própria (v2)

Método adaptado de duas fontes de especialistas, ambas Apache-2.0: **Impeccable** (Paul Bakaus,
github.com/pbakaus/impeccable) e **frontend-design** (Anthropic, github.com/anthropics/skills). Detalhes em
`referencias/` (veja o NOTICE.md). Arquivos desta skill: use Read em `<pasta da skill>/referencias/<arquivo>.md`.

Trabalhe como o diretor de um estúdio premiado que já teve propostas recusadas por parecerem modelo pronto: o cliente
está pagando por um ponto de vista. Código de produção, escolhas ousadas e acabamento conferido. Termine o trabalho;
só fica faltando o que só o usuário pode dar (fotos reais, preços, textos legais).

## Ordem obrigatória — não pule etapa, não junte etapa com a seguinte

### Etapa 0 — Perguntas (primeiro turno, sem criar arquivo)
Mande UMA mensagem com no máximo 5 perguntas curtas, cada uma já com uma sugestão de resposta, e PARE.
Pergunte só o que muda o trabalho: o que é vendido e para quem; o que o visitante deve fazer (comprar, agendar,
chamar no WhatsApp...); que prova e material real existem (fotos, logo, preços, avaliações); a sensação desejada e um
site admirado; onde vai rodar. Nunca peça valores de CSS nem "estilo pronto".
Se o usuário já respondeu tudo no pedido ou disse "decide você", siga direto e diga o que você assumiu.

### Etapa 1 — Ficha (`site/ficha.md`)
O que é vendido, para quem, onde, faixa de preço, ação principal, diferenciais com prova, material existente,
restrições. **Verdade:** dado de demonstração pode existir em alta fidelidade, sempre rotulado como exemplo e listado
no LEIA-ME para trocar. Alegação comercial (cliente, número de vendas, prêmio, avaliação, prazo, estoque) nunca se
inventa. Recusar uma direção ousada "porque falta dado" é timidez; inventar prova é mentira. Rotule e siga.

### Etapa 2 — Funcionalidades do ramo (`site/funcionalidades.md`)
Funcionalidade é o que faz o site ser DAQUELE negócio. Use a tabela no fim desta skill: essenciais vão na primeira
versão (funcionando, não desenhadas), escolha 1 a 3 diferenciais. No Brasil quase sempre: WhatsApp com mensagem pronta,
Pix, frete/área por CEP, aviso de cookies e privacidade quando há formulário.

### Etapa 3 — Mundo visual e direções (`site/direcao.md`) — depois PARE para o usuário escolher
1. Uma frase com: o mecanismo único do negócio, a cena real do cliente, o que a página precisa provar.
2. Anote "a vala": a página que essa categoria sempre entrega e o oposto previsível dela. As duas ficam fora.
3. Liste 7 mundos concretos que o público conhece de cor (sistemas visuais, objetos, lugares, rituais, tradições
   gráficas do ramo, como esse mundo era antes da web). Cubra pelo menos 3 famílias diferentes de material.
   A leitura literal do nome do negócio vale no máximo 1 candidato.
4. Transforme os melhores em 2 ou 3 direções BEM diferentes. Cada direção tem:
   - **Tese:** a ideia que a página possui e o arranjo padrão que ela recusa.
   - **Mundo:** paleta de 4 a 6 hex com nomes, fontes (veja `referencias/tipografia-cor-layout.md`), linguagem de
     componentes reconhecível sem o conteúdo. Claro ou escuro sai da cena de uso (quem, onde, que luz), nunca do ramo.
   - **Primeira tela:** composição exata em esboço ASCII, escala, onde está a ação principal.
   - **Momento marcante:** UMA coisa que o visitante vai lembrar, feita com a técnica da web que o mundo pede
     (WebGL/three.js, canvas, rolagem com narrativa, configurador ao vivo, transição de página...).
   - **Risco honesto:** o que pode dar errado com essa direção.
5. Teste cada direção: se alguém adivinha o visual só pela categoria, ou se é o que você faria para qualquer site
   parecido, refaça. Mostre as direções e PARE esperando a escolha.

### Etapa 4 — Construção com compromisso total
- Construa a direção escolhida, não uma versão mais segura. Todo elemento (navegação, botões, campos, links) no
  vocabulário do mundo; componente de prateleira é lapso.
- **Primeira tela é tese, não cabeçalho.** Teste da memória: uma hora depois, o que o visitante descreveria? Se a
  resposta é "um clima", não comprometeu.
- **Prove, não afirme:** a ação principal aparece funcionando logo no topo (o configurador, a busca, os horários, o
  carrinho), não um botão decorativo.
- **Construa a técnica, não a imitação:** se o mundo pede 3D, canvas ou movimento, construa de verdade. Leia
  `referencias/movimento-e-efeitos.md` antes (bibliotecas, desempenho, movimento reduzido, alternativa se falhar).
- **Ritmo:** varie densidade, escala, imagem, movimento e silêncio entre as seções; termine com um fechamento real.
  Coragem em um lugar só: o resto quieto e disciplinado.
- **Imagens:** leia `referencias/imagens.md`. Nunca desenhe produto ou cena com formas SVG primitivas fingindo
  ilustração.
- Piso de qualidade sem anunciar: responsivo, foco visível, `prefers-reduced-motion`, contraste AA, nada invisível em
  repouso, sem erro no console. Tokens (cor, fonte, escala, espaço, movimento) num lugar só.

### Etapa 5 — Olhar e corrigir (no mínimo 2 rodadas)
Capture desktop 1440 e celular 390 (espere as animações de entrada terminarem; capture do topo; abra cada imagem e
confira). Critique pela rubrica de `referencias/piso-de-qualidade-e-critica.md` e pela lista de sinais de IA.
Corrija tudo o que uma olhada mostrou, em lote, e capture de novo. Em algo interativo, percorra os estados
(hover, foco, aberto, erro, vazio, texto longo).

### Etapa 6 — Checagem final (responda sim a tudo antes de entregar) e `site/LEIA-ME.md`
1. Teste da troca: um concorrente do mesmo ramo poderia usar esta página sem mudar nada? (Tem de ser NÃO.)
2. A primeira tela diz o que é, por que importa e o que fazer, e o momento marcante funciona?
3. As funcionalidades essenciais funcionam de ponta a ponta?
4. Nenhum sinal de IA da lista abaixo ficou sem um motivo escrito em `site/direcao.md`?
5. Nenhum número, cliente, avaliação ou prova inventado; exemplos rotulados e listados no LEIA-ME?
6. Capturas de desktop e celular conferidas, sem erro no console, movimento reduzido respeitado?
O LEIA-ME diz como abrir, onde trocar textos, preços e imagens, e o que ficou para a próxima versão.

## Sinais de site feito por IA (resumo — lista completa em `referencias/sinais-de-ia.md`)
São o padrão da categoria, não proibição: o pedido do usuário pode justificar qualquer um. Com o eixo livre, usar um
deles é não ter decidido. **BANIDO** nenhum pedido justifica.
- Os looks de calibração: fundo creme + serifa display + acento terracota/laranja; quase-preto + um acento neon;
  editorial de jornal com filetes e mono; o kit SaaS de cards arredondados iguais com a mesma sombra.
- **BANIDO:** rótulo pequeno em CAIXA ALTA espaçada acima do título (eyebrow/kicker), inclusive em pílula.
- Números de seção 01/02/03 quando o conteúdo não é uma sequência real.
- Faixa de "métricas" (número grande + rótulo pequeno) e números de prova inventados.
- Topo dividido (texto de um lado, produto num card do outro) ou título centralizado sobre fileira de cards.
- Seções feitas de cards iguais com ícone + título + texto; card dentro de card.
- Fontes saturadas: Inter, Roboto, Space Grotesk, Space Mono, IBM Plex, DM Sans, Outfit, Plus Jakarta Sans, Syne,
  Fraunces, Playfair Display. Mono como fantasia de "técnico". Destacar uma palavra do título em outra cor.
- Gradiente roxo/ciano, texto em gradiente, brilho neon, halo radial atrás do título, vidro e blur de enfeite.
- Fundo com listras (`repeating-linear-gradient`) ou grade de linhas sem um motivo real (mapa, planta, régua).
- Ilustração de produto/cena montada com formas SVG primitivas; emoji como sistema de ícones.
- Mesma entrada (aparecer subindo) em toda seção; hover que levanta todo card; bounce/elastic; marquee; cursor
  piscando falso; ponto pulsando "ao vivo" sem dado vivo; conteúdo invisível até rolar.
- Texto de modelo: "soluções inovadoras", "qualidade e excelência", aforismos em série ("Não é X. É Y."), botões
  "Enviar/Saiba mais", erros "Algo deu errado", excesso de travessão.

## Tabela de funcionalidades por ramo
| Ramo | Essenciais | Diferenciais que impressionam |
|---|---|---|
| Loja / produto | produto com galeria e zoom, variações com preço e estoque, frete por CEP, carrinho, perguntas do produto | personalização com prévia ao vivo, guia de medidas, comparador, vídeo de uso |
| Restaurante / delivery | cardápio por categoria com fotos e preços, "aberto agora", pedido (WhatsApp/app), mapa | filtros (vegano, sem glúten), prato do dia, reserva, montar combo |
| Clínica / saúde / estética | especialidades e profissionais com registro, agendamento por horário, convênios, endereço | preparo de exames, pré-consulta online, teleconsulta |
| Serviços locais | orçamento com foto do problema, área por bairro/CEP, prazos, garantia | calculadora de orçamento, antes/depois, acompanhamento |
| Imobiliária | busca com filtros, ficha do imóvel com galeria e mapa, agendar visita | simulador de financiamento, tour 360, comparação |
| Academia / estúdio | planos e preços, grade de horários, aula experimental, unidades | calculadora de objetivo, check-in |
| Escola / curso | grade do curso, professor com credenciais, preço, inscrição | aula grátis, simulado, certificado de exemplo |
| Escritório (advocacia, contabilidade) | áreas explicadas em linguagem simples, equipe, triagem | checklist de documentos, calculadoras |
| SaaS / B2B | problema e resultado, demonstração interativa, planos, integrações, segurança | ROI calculado, casos por segmento, trial sem cartão |
| Evento | data, local, programação, palestrantes, ingressos por lote | contagem regressiva real, agenda pessoal |
| Turismo / hotel | quartos com fotos e capacidade, disponibilidade e reserva, localização | calendário de preços, roteiro sugerido |
| Beleza / barbearia | serviços com duração e preço, agendamento por profissional, portfólio | pacote fidelidade, galeria por estilo |
| Pet | serviços com agenda, produtos, emergência | ficha do pet, lembrete de vacina, leva-e-traz |
| ONG / causa | missão com impacto real, como doar (Pix, recorrente), prestação de contas | histórias, metas com barra real |
| Portfólio criativo | trabalhos com contexto (problema, solução, resultado), sobre, contato | estudo de caso, filtro por tipo |

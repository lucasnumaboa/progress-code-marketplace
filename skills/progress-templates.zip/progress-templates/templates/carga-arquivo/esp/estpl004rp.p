/*------------------------------------------------------------------------------
  Programa...: esp/estpl004rp.p
  Objetivo...: Carga de arquivos CSV - modelo. Roda on-line (chamado por uma
               tela w-relat) ou no RPW. Le todos os .csv de uma pasta, valida,
               grava e lista o resultado.
  Origem.....: template progress-templates
  Trocar.....: nome do programa, tt-param (igual ao da tela), layout do CSV
               (pi-le-linha), a gravacao (pi-grava) e a tabela de destino.

  Regras do modelo:
    - arquivo com qualquer linha invalida nao grava nada (tudo ou nada);
    - cada arquivo e renomeado para ".emproc" antes de ser lido: duas execucoes
      ao mesmo tempo nao importam o mesmo arquivo;
    - arquivo importado vai para a subpasta "processados"; arquivo com erro
      volta para a pasta com o nome original;
    - simulacao (tt-param.l-simula) valida e lista, sem gravar.

  Layout do CSV (separador ";", primeira linha = cabecalho):
    codigo;descricao;tipo;ativo(S/N)
------------------------------------------------------------------------------*/
{include/i-prgvrs.i ESTPL004RP 1.00.00.000}

{utp/ut-glob.i}

/* tt-param: campos e ORDEM identicos aos da tela (raw-transfer) */
define temp-table tt-param no-undo
    field destino              as integer
    field arquivo              as char format "x(35)"
    field usuario              as char format "x(12)"
    field data-exec            as date
    field hora-exec            as integer
    field classifica           as integer
    field desc-classifica      as char format "x(40)"
    field c-pasta              as char format "x(200)"
    field l-simula             as logical.

def temp-table tt-raw-digita
    field raw-digita as raw.

define temp-table tt-arq no-undo
    field nome    as character
    field caminho as character
    index id is primary nome.

define temp-table tt-linha no-undo
    field seq       as integer
    field codigo    as integer
    field descricao as character
    field tipo      as integer
    field ativo     as logical
    index id is primary seq.

define temp-table tt-log no-undo
    field ordem    as integer
    field arquivo  as character format "x(30)" column-label "Arquivo"
    field linha    as integer   format ">>>>>9" column-label "Linha"
    field situacao as character format "x(10)" column-label "Situa��o"
    field mensagem as character format "x(78)" column-label "Mensagem"
    index id is primary ordem.

def input parameter raw-param as raw no-undo.
def input parameter table for tt-raw-digita.

create tt-param.
/* pedido criado direto no RPW pode chegar sem raw-param */
if  length(raw-param) > 0 then
    raw-transfer raw-param to tt-param no-error.

{include/i-rpvar.i}

define variable h-acomp    as handle    no-undo.
define variable c-usuario  as character no-undo.
define variable c-pasta    as character no-undo.
define variable i-ordem    as integer   no-undo.
define variable i-arquivos as integer   no-undo.

define stream s-arq.

form tt-log.arquivo
     tt-log.linha
     tt-log.situacao
     tt-log.mensagem
     with down width 132 no-box stream-io frame f-relat.

assign c-programa     = "ESTPL004RP":U
       c-versao       = "1.00":U
       c-revisao      = "000":U
       c-sistema      = "Espec�fico"
       c-titulo-relat = "Carga de Ocorr�ncias por Arquivo".

find first param-global no-lock no-error.
if  avail param-global then
    assign c-empresa = param-global.grupo.

{include/i-rpcab.i &stream="str-rp"}
{include/i-rpout.i &stream="stream str-rp"}

view stream str-rp frame f-cabec.
view stream str-rp frame f-rodape.

run utp/ut-acomp.p persistent set h-acomp.
run pi-inicializar in h-acomp (input c-titulo-relat).

run pi-usuario.
run pi-lista-arquivos.

for each tt-arq:
    assign i-arquivos = i-arquivos + 1.
    run pi-acompanhar in h-acomp (input "Arquivo: " + tt-arq.nome).
    run pi-importa-arquivo (input tt-arq.nome, input tt-arq.caminho).
end.

if  i-arquivos = 0 and not can-find(first tt-log) then
    run pi-log (input "", input 0, input "AVISO", input "Nenhum arquivo .csv na pasta " + c-pasta).

/* resultado */
put stream str-rp unformatted
    "Pasta: " c-pasta "     Usu�rio: " c-usuario
    "     Modo: " (if tt-param.l-simula then "SIMULA��O (nada foi gravado)" else "Grava��o") skip(1).

for each tt-log:
    display stream str-rp tt-log.arquivo
            tt-log.linha
            tt-log.situacao
            tt-log.mensagem
            with frame f-relat.
    down stream str-rp with frame f-relat.
end.

{include/i-rpclo.i &stream="stream str-rp"}

run pi-finalizar in h-acomp.

return "OK":U.


/* ************************  Procedures internas  ************************ */

procedure pi-log:
    define input parameter p-arquivo  as character no-undo.
    define input parameter p-linha    as integer   no-undo.
    define input parameter p-situacao as character no-undo.
    define input parameter p-mensagem as character no-undo.

    assign i-ordem = i-ordem + 1.
    create tt-log.
    assign tt-log.ordem    = i-ordem
           tt-log.arquivo  = p-arquivo
           tt-log.linha    = p-linha
           tt-log.situacao = p-situacao
           tt-log.mensagem = p-mensagem.
end procedure.

procedure pi-usuario:
/*------------------------------------------------------------------------------
  Quem pediu a execucao. No RPW o usuario da conexao e o do agente, nao o de
  quem pediu: busca no pedido de execucao.
------------------------------------------------------------------------------*/
    assign c-usuario = "".
    if  i-num-ped-exec-rpw <> 0 then do:
        find first ped_exec no-lock
             where ped_exec.num_ped_exec = i-num-ped-exec-rpw no-error.
        if  avail ped_exec then
            assign c-usuario = trim(ped_exec.cod_usuario).
    end.
    if  c-usuario = "" or c-usuario = ? then assign c-usuario = tt-param.usuario.
    if  c-usuario = "" or c-usuario = ? then assign c-usuario = c-seg-usuario.
end procedure.

procedure pi-lista-arquivos:
    define variable c-nome as character no-undo.
    define variable c-full as character no-undo.
    define variable c-attr as character no-undo.

    assign file-info:file-name = tt-param.c-pasta.
    if  file-info:full-pathname = ? or index(file-info:file-type, "D") = 0 then do:
        assign c-pasta = tt-param.c-pasta.
        run pi-log (input "", input 0, input "ERRO", input "Pasta n�o encontrada: " + tt-param.c-pasta).
        return.
    end.
    assign c-pasta = replace(file-info:full-pathname, "~\", "/").

    input from os-dir(c-pasta) no-echo.
    repeat:
        import c-nome c-full c-attr.
        if  index(c-attr, "F") = 0 then next.
        if  length(c-nome) < 5 or substring(c-nome, length(c-nome) - 3) <> ".csv" then next.
        create tt-arq.
        assign tt-arq.nome    = c-nome
               tt-arq.caminho = replace(c-full, "~\", "/").
    end.
    input close.
end procedure.

procedure pi-importa-arquivo:
    define input parameter p-nome    as character no-undo.
    define input parameter p-caminho as character no-undo.

    define variable c-trab   as character no-undo.
    define variable c-dest   as character no-undo.
    define variable c-linha  as character no-undo.
    define variable i-linha  as integer   no-undo.
    define variable i-gravou as integer   no-undo.
    define variable l-erro   as logical   no-undo.

    /* trava: so uma execucao consegue renomear o arquivo */
    assign c-trab = p-caminho + ".emproc".
    os-rename value(p-caminho) value(c-trab).
    if  os-error <> 0 then do:
        run pi-log (input p-nome, input 0, input "AVISO",
                    input "Arquivo em uso por outra execu��o (os-error " + string(os-error) + ").").
        return.
    end.

    empty temp-table tt-linha.

    /* CSV salvo pelo Excel vem em ISO8859-1/Windows-1252; troque se for UTF-8 */
    input stream s-arq from value(c-trab) convert source "iso8859-1".
    repeat:
        import stream s-arq unformatted c-linha.
        assign i-linha = i-linha + 1.
        if  i-linha = 1 then next.              /* cabecalho */
        if  trim(c-linha) = "" then next.
        run pi-le-linha (input p-nome, input i-linha, input c-linha).
        if  return-value = "NOK":U then
            assign l-erro = yes.
    end.
    input stream s-arq close.

    if  not l-erro and not can-find(first tt-linha) then do:
        run pi-log (input p-nome, input 0, input "ERRO", input "Arquivo sem linhas de dados.").
        assign l-erro = yes.
    end.

    if  not l-erro and not tt-param.l-simula then do:
        run pi-grava (input p-nome, output i-gravou).
        if  return-value = "NOK":U then
            assign l-erro = yes.
    end.

    if  l-erro then do:
        os-rename value(c-trab) value(p-caminho).
        run pi-log (input p-nome, input 0, input "ERRO",
                    input "Arquivo n�o importado. Corrija as linhas indicadas e reenvie.").
        return.
    end.

    if  tt-param.l-simula then do:
        os-rename value(c-trab) value(p-caminho).
        for each tt-linha: assign i-gravou = i-gravou + 1. end.
        run pi-log (input p-nome, input 0, input "SIMULADO",
                    input string(i-gravou) + " linha(s) v�lida(s); nada gravado.").
        return.
    end.

    /* importado: guarda em "processados" com data e hora no nome */
    os-create-dir value(c-pasta + "/processados").
    assign c-dest = c-pasta + "/processados/" + p-nome + "."
                  + string(year(today), "9999") + string(month(today), "99") + string(day(today), "99")
                  + "-" + replace(string(time, "HH:MM:SS"), ":", "").
    os-rename value(c-trab) value(c-dest).
    run pi-log (input p-nome, input 0, input "OK",
                input string(i-gravou) + " registro(s) gravado(s) por " + c-usuario + "."
                    + (if os-error <> 0 then " Aten��o: n�o foi poss�vel mover para processados." else "")).
end procedure.

procedure pi-le-linha:
/*------------------------------------------------------------------------------
  Valida uma linha do CSV e guarda em tt-linha. Devolve "NOK" na linha invalida.
------------------------------------------------------------------------------*/
    define input parameter p-nome  as character no-undo.
    define input parameter p-seq   as integer   no-undo.
    define input parameter p-linha as character no-undo.

    define variable i-codigo as integer   no-undo.
    define variable i-tipo   as integer   no-undo.
    define variable c-descr  as character no-undo.
    define variable c-ativo  as character no-undo.

    if  num-entries(p-linha, ";") < 4 then do:
        run pi-log (input p-nome, input p-seq, input "ERRO", input "Linha com menos de 4 colunas.").
        return "NOK":U.
    end.

    assign i-codigo = integer(trim(entry(1, p-linha, ";"))) no-error.
    if  error-status:error or i-codigo = ? or i-codigo <= 0 then do:
        run pi-log (input p-nome, input p-seq, input "ERRO",
                    input "C�digo inv�lido: " + entry(1, p-linha, ";")).
        return "NOK":U.
    end.

    assign c-descr = trim(entry(2, p-linha, ";")).
    if  c-descr = "" then do:
        run pi-log (input p-nome, input p-seq, input "ERRO", input "Descri��o em branco.").
        return "NOK":U.
    end.

    assign i-tipo = integer(trim(entry(3, p-linha, ";"))) no-error.
    if  error-status:error or i-tipo = ? then do:
        run pi-log (input p-nome, input p-seq, input "ERRO",
                    input "Tipo inv�lido: " + entry(3, p-linha, ";")).
        return "NOK":U.
    end.

    assign c-ativo = caps(trim(entry(4, p-linha, ";"))).
    if  lookup(c-ativo, "S,N") = 0 then do:
        run pi-log (input p-nome, input p-seq, input "ERRO",
                    input "Ativo deve ser S ou N: " + entry(4, p-linha, ";")).
        return "NOK":U.
    end.

    if  can-find(first tt-linha where tt-linha.codigo = i-codigo) then do:
        run pi-log (input p-nome, input p-seq, input "ERRO",
                    input "C�digo repetido no arquivo: " + string(i-codigo)).
        return "NOK":U.
    end.

    create tt-linha.
    assign tt-linha.seq       = p-seq
           tt-linha.codigo    = i-codigo
           tt-linha.descricao = c-descr
           tt-linha.tipo      = i-tipo
           tt-linha.ativo     = (c-ativo = "S").

    return "OK":U.
end procedure.

procedure pi-grava:
/*------------------------------------------------------------------------------
  Grava o arquivo inteiro numa transacao: erro em qualquer linha desfaz tudo.
------------------------------------------------------------------------------*/
    define input  parameter p-nome   as character no-undo.
    define output parameter p-gravou as integer   no-undo.

    define variable l-erro as logical no-undo.

    grava:
    do transaction on error undo grava, leave grava:
        for each tt-linha:
            find es-tpl-ocor exclusive-lock
                 where es-tpl-ocor.codigo = tt-linha.codigo no-wait no-error.
            if  locked es-tpl-ocor then do:
                run pi-log (input p-nome, input tt-linha.seq, input "ERRO",
                            input "Registro " + string(tt-linha.codigo) + " em uso por outro usu�rio.").
                assign l-erro = yes.
                undo grava, leave grava.
            end.
            if  not avail es-tpl-ocor then do:
                create es-tpl-ocor.
                assign es-tpl-ocor.codigo = tt-linha.codigo.
            end.
            assign es-tpl-ocor.descricao = tt-linha.descricao
                   es-tpl-ocor.tipo      = tt-linha.tipo
                   es-tpl-ocor.ativo     = tt-linha.ativo
                   p-gravou              = p-gravou + 1.
        end.
    end.

    if  l-erro then do:
        assign p-gravou = 0.
        return "NOK":U.
    end.

    return "OK":U.
end procedure.

/*------------------------------------------------------------------------------
  Programa...: esp/estpl003rp.p
  Objetivo...: Relatorio modelo - listagem texto (padrao DDK) e planilha Excel
               (utp/utapi033.p). Chamado pela tela esp/estpl003.w.
  Origem.....: template progress-templates (DDK classico)
  Trocar.....: nome do programa, tt-param (igual ao da tela), tt-dados, a
               leitura principal e as colunas da listagem e da planilha.
------------------------------------------------------------------------------*/
{include/i-prgvrs.i ESTPL003RP 1.00.00.000}

{utp/ut-glob.i}
{method/dbotterr.i}   /* temp-table RowErrors: erros devolvidos pela utapi033 */

/* tt-param: os campos e a ORDEM tem de ser identicos aos da tela (raw-transfer) */
define temp-table tt-param no-undo
    field destino              as integer
    field arquivo              as char format "x(35)"
    field usuario              as char format "x(12)"
    field data-exec            as date
    field hora-exec            as integer
    field classifica           as integer
    field desc-classifica      as char format "x(40)"
    field cod-estabel-ini      as char format "x(05)"
    field cod-estabel-fim      as char format "x(05)"
    field cod-serie-ini        as char format "x(10)"
    field cod-serie-fim        as char format "x(10)"
    field desc-serie-ini       as char format "x(30)"
    field desc-serie-fim       as char format "x(30)"
    field data-ini             as date
    field data-fim             as date
    field l-excel              as logical
    field l-imp-param          as logical.

def temp-table tt-raw-digita
    field raw-digita as raw.

/* tt-dados: uma linha por registro listado. Alimenta a listagem e a planilha.
   O COLUMN-LABEL daqui vira titulo de coluna quando a planilha nao declara a
   coluna com piWorksheetColumn. */
define temp-table tt-dados no-undo
    field cod-estabel as character format "x(5)"            column-label "Estab"
    field cod-serie   as character format "x(10)"           column-label "S�rie"
    field desc-serie  as character format "x(30)"           column-label "Descri��o"
    field da-1        as date      format "99/99/9999"      column-label "Data"
    field int-1       as integer   format "->,>>>,>>9"      column-label "Quantidade"
    field dec-1       as decimal   format "->>>,>>>,>>9.99" column-label "Valor"
    index id is primary cod-estabel cod-serie.

/* linhas do cabecalho de parametros da planilha */
define temp-table tt-param-api no-undo
    field descricao as character
    field valor     as character.

def input parameter raw-param as raw no-undo.
def input parameter table for tt-raw-digita.

create tt-param.
raw-transfer raw-param to tt-param.

/* variaveis padrao do relatorio (c-programa, c-versao, c-empresa, c-titulo-relat...) */
{include/i-rpvar.i}

define variable h-acomp             as handle    no-undo.
define variable h-utapi033          as handle    no-undo.
define variable c-arq-excel         as character no-undo.
define variable c-lb-destino-impres as character no-undo.
define variable i-lidos             as integer   no-undo.
define variable de-total            as decimal   no-undo.
define variable l-erro-excel        as logical   no-undo.

/* layout da listagem: 132 colunas, STREAM-IO (obrigatorio em relatorio) */
form tt-dados.cod-estabel
     tt-dados.cod-serie
     tt-dados.desc-serie
     tt-dados.da-1
     tt-dados.int-1
     tt-dados.dec-1
     with down width 132 no-box stream-io frame f-relat.

assign c-programa     = "ESTPL003RP":U
       c-versao       = "1.00":U
       c-revisao      = "000":U
       c-sistema      = "Espec�fico"
       c-titulo-relat = "S�ries por Estabelecimento".

find first param-global no-lock no-error.
if  avail param-global then
    assign c-empresa = param-global.grupo.

/* cabecalho/rodape padrao e abertura da saida conforme tt-param.destino.
   Tudo na stream padrao str-rp: outro OUTPUT TO do programa nao desvia a listagem. */
{include/i-rpcab.i &stream="str-rp"}
{include/i-rpout.i &stream="stream str-rp"}

view stream str-rp frame f-cabec.
view stream str-rp frame f-rodape.

run utp/ut-acomp.p persistent set h-acomp.
run pi-inicializar in h-acomp (input c-titulo-relat).

/* ------------------------------------------------------------------------
   Leitura principal. As faixas seguem a ordem do indice primario
   (cod-estabel, cod-serie) para a leitura ir pelo indice.
   ------------------------------------------------------------------------ */
for each es-tpl-serie no-lock
    where es-tpl-serie.cod-estabel >= tt-param.cod-estabel-ini
      and es-tpl-serie.cod-estabel <= tt-param.cod-estabel-fim
      and es-tpl-serie.cod-serie   >= tt-param.cod-serie-ini
      and es-tpl-serie.cod-serie   <= tt-param.cod-serie-fim
      and es-tpl-serie.desc-serie  >= tt-param.desc-serie-ini
      and es-tpl-serie.desc-serie  <= tt-param.desc-serie-fim:

    /* data em branco entra na faixa completa; fora dela, so o que cair na faixa */
    if  es-tpl-serie.da-1 <> ?
    and (es-tpl-serie.da-1 < tt-param.data-ini or es-tpl-serie.da-1 > tt-param.data-fim) then
        next.
    if  es-tpl-serie.da-1 = ?
    and (tt-param.data-ini <> 01/01/0001 or tt-param.data-fim <> 12/31/9999) then
        next.

    assign i-lidos = i-lidos + 1.
    run pi-acompanhar in h-acomp (input "Estab: " + es-tpl-serie.cod-estabel
                                      + "  S�rie: " + es-tpl-serie.cod-serie).

    create tt-dados.
    assign tt-dados.cod-estabel = es-tpl-serie.cod-estabel
           tt-dados.cod-serie   = es-tpl-serie.cod-serie
           tt-dados.desc-serie  = es-tpl-serie.desc-serie
           tt-dados.da-1        = es-tpl-serie.da-1
           tt-dados.int-1       = es-tpl-serie.int-1
           tt-dados.dec-1       = es-tpl-serie.dec-1.
end.

/* ------------------------------------------------------------------------
   Listagem texto
   ------------------------------------------------------------------------ */
for each tt-dados
    break by tt-dados.cod-estabel
          by tt-dados.cod-serie:

    display stream str-rp tt-dados.cod-estabel
            tt-dados.cod-serie
            tt-dados.desc-serie
            tt-dados.da-1
            tt-dados.int-1
            tt-dados.dec-1
            with frame f-relat.
    down stream str-rp with frame f-relat.

    assign de-total = de-total + tt-dados.dec-1.
end.

put stream str-rp unformatted skip(1)
    "Registros listados: " i-lidos
    "     Valor total: " trim(string(de-total, "->>>,>>>,>>9.99")) skip.

if  i-lidos = 0 then
    put stream str-rp unformatted skip(1) "Nenhum registro encontrado para a sele��o informada." skip.

/* pagina de parametros */
if  tt-param.l-imp-param then do:
    page stream str-rp.
    put stream str-rp unformatted "SELE��O" skip(1).
    put stream str-rp unformatted
        "Estabelecimento" at 5  ": " at 22 tt-param.cod-estabel-ini  at 25 "|< >|" at 58 tt-param.cod-estabel-fim at 65 skip
        "S�rie"           at 5  ": " at 22 tt-param.cod-serie-ini    at 25 "|< >|" at 58 tt-param.cod-serie-fim   at 65 skip
        "Descri��o"       at 5  ": " at 22 tt-param.desc-serie-ini   at 25 "|< >|" at 58 substring(tt-param.desc-serie-fim, 1, 30) at 65 skip
        "Data"            at 5  ": " at 22 string(tt-param.data-ini, "99/99/9999") at 25
                                           "|< >|" at 58 string(tt-param.data-fim, "99/99/9999") at 65 skip(1).

    put stream str-rp unformatted "PAR�METROS" skip(1).
    put stream str-rp unformatted
        "Gerar planilha Excel" at 5 ": " at 30 (if tt-param.l-excel then "Sim" else "N�o") at 33 skip(1).

    put stream str-rp unformatted "IMPRESS�O" skip(1).
    case tt-param.destino:
        when 1 then assign c-lb-destino-impres = "Impressora".
        when 2 then assign c-lb-destino-impres = "Arquivo".
        when 3 then assign c-lb-destino-impres = "Terminal".
    end case.
    put stream str-rp unformatted
        "Destino"  at 5 ": " at 14 c-lb-destino-impres " - " tt-param.arquivo skip
        "Execu��o" at 5 ": " at 14 (if i-num-ped-exec-rpw = 0 then "On-Line" else "Batch") skip
        "Usu�rio"  at 5 ": " at 14 tt-param.usuario skip.
end.

/* fecha a saida da listagem */
{include/i-rpclo.i &stream="stream str-rp"}

/* ------------------------------------------------------------------------
   Planilha Excel
   ------------------------------------------------------------------------ */
if  tt-param.l-excel and i-lidos > 0 then do:
    run pi-acompanhar in h-acomp (input "Gerando planilha...").
    run pi-gera-excel.
end.

run pi-finalizar in h-acomp.

if  l-erro-excel then
    return "NOK":U.

return "OK":U.


/* ************************  Procedures internas  ************************ */

procedure pi-gera-excel:
/*------------------------------------------------------------------------------
  Gera a planilha pela utapi033 (XML de planilha, convertido para Excel quando
  ha Excel/LibreOffice na maquina que executa). Uma aba por piNewWorksheetByTT.
------------------------------------------------------------------------------*/
    define variable i-larg-param as integer extent 2 no-undo.

    /* nome unico: evita "arquivo em uso" quando a planilha anterior ficou aberta.
       On-line grava na pasta temporaria da sessao; no RPW passa so o nome e a
       utapi033 grava no spool do servidor de execucao. */
    assign c-arq-excel = "estpl003-"
                       + string(year(today), "9999") + string(month(today), "99") + string(day(today), "99")
                       + "-" + replace(string(time, "HH:MM:SS"), ":", "") + ".xml".
    if  i-num-ped-exec-rpw = 0 then
        assign c-arq-excel = session:temp-directory + c-arq-excel.

    run utp/utapi033.p persistent set h-utapi033.

    /* abre a planilha na tela so quando o destino e Terminal */
    run show         in h-utapi033 (input (tt-param.destino = 3)).
    run ConvertToXls in h-utapi033 (input yes).

    /* colunas da aba 1: aba, coluna, tipo (CHAR/INTE/DECI/DATE), titulo, formato, largura.
       Declaradas ANTES do piNewWorksheetByTT, valem no lugar do COLUMN-LABEL da tt. */
    run piWorksheetColumn in h-utapi033 (input 1, input 1, input "CHAR", input "Estab",      input "x(5)",            input 50).
    run piWorksheetColumn in h-utapi033 (input 1, input 2, input "CHAR", input "S�rie",      input "x(10)",           input 70).
    run piWorksheetColumn in h-utapi033 (input 1, input 3, input "CHAR", input "Descri��o",  input "x(30)",           input 180).
    run piWorksheetColumn in h-utapi033 (input 1, input 4, input "DATE", input "Data",       input "99/99/9999",      input 70).
    run piWorksheetColumn in h-utapi033 (input 1, input 5, input "INTE", input "Quantidade", input "->,>>>,>>9",      input 70).
    run piWorksheetColumn in h-utapi033 (input 1, input 6, input "DECI", input "Valor",      input "->>>,>>>,>>9.99", input 90).

    /* aba, titulo, buffer da tt, campos (na ordem das colunas), ordenacao */
    run piNewWorksheetByTT in h-utapi033 (input "S�ries",
                                          input c-titulo-relat,
                                          input buffer tt-dados:handle,
                                          input "cod-estabel,cod-serie,desc-serie,da-1,int-1,dec-1",
                                          input "cod-estabel,cod-serie").

    /* cabecalho de parametros da planilha */
    empty temp-table tt-param-api.
    create tt-param-api.
    assign tt-param-api.descricao = "Estabelecimento:"
           tt-param-api.valor     = tt-param.cod-estabel-ini + " at� " + tt-param.cod-estabel-fim.
    create tt-param-api.
    assign tt-param-api.descricao = "S�rie:"
           tt-param-api.valor     = tt-param.cod-serie-ini + " at� " + tt-param.cod-serie-fim.
    create tt-param-api.
    assign tt-param-api.descricao = "Usu�rio:"
           tt-param-api.valor     = tt-param.usuario.

    run setTTParam in h-utapi033 (input table tt-param-api).
    assign i-larg-param[1] = 150
           i-larg-param[2] = 200.
    run setParamColumnWidth in h-utapi033 (input i-larg-param).

    /* gera o arquivo; devolve em c-arq-excel o caminho final */
    run piProcessa in h-utapi033 (input-output c-arq-excel,
                                  input c-programa,
                                  input c-titulo-relat).

    if  return-value <> "OK":U then do:
        assign l-erro-excel = yes.
        run getRowErrors in h-utapi033 (output table RowErrors).
        for each RowErrors:
            /* em batch/RPW a mensagem vai para o log da execucao */
            message "Erro na gera��o da planilha:" RowErrors.ErrorNumber "-" RowErrors.ErrorDescription.
        end.
    end.

    if  valid-handle(h-utapi033) then
        delete procedure h-utapi033.
end procedure.

/*------------------------------------------------------------------------
    File        : esp/api/v1/estplOcorrencia.p
    Purpose     : Handler REST modelo (framework ut-api) para o backend de
                  uma tela PO-UI. A regra fica em estplOcorrenciaRules.p.
    Origem      : template progress-templates

    Rotas:
      GET  /           -> pi-lista     (todos os registros)
      POST /consulta   -> pi-consulta  (filtro: tipo, somenteAtivos, texto)
      POST /salvar     -> pi-salvar    (inclui ou altera pelo codigo)
      POST /excluir    -> pi-excluir   (elimina pelo codigo)

    Este handler NAO referencia tabela nenhuma: quem le e grava o banco e o
    BO (Rules). Assim o handler fica so com rota, resposta e tratamento de
    erro, e a regra pode ser testada chamando o BO direto.

    Trocar: nome do arquivo, rotas, nome do BO e das procedures.
------------------------------------------------------------------------*/

USING Progress.Lang.Error.
USING Progress.Json.ObjectModel.JsonObject.
USING Progress.Json.ObjectModel.JsonArray.
USING com.totvs.framework.api.JsonApiResponseBuilder.

{utp/ut-api.i}
{utp/ut-api-utils.i}

/* rota: procedure, verbo e caminho. "~*" aceita o que vier depois do caminho */
{utp/ut-api-action.i pi-lista    GET  / }
{utp/ut-api-action.i pi-consulta POST /consulta~* }
{utp/ut-api-action.i pi-salvar   POST /salvar~* }
{utp/ut-api-action.i pi-excluir  POST /excluir~* }

{utp/ut-api-notfound.i}

/* -------------------------------------------------------------------- */
/* Resposta padrao: { success, message, data }                          */
/* -------------------------------------------------------------------- */
PROCEDURE piResposta PRIVATE:
    DEFINE INPUT  PARAMETER plOk    AS LOGICAL    NO-UNDO.
    DEFINE INPUT  PARAMETER pcMsg   AS CHARACTER  NO-UNDO.
    DEFINE INPUT  PARAMETER poData  AS JsonObject NO-UNDO.
    DEFINE OUTPUT PARAMETER poOut   AS JsonObject NO-UNDO.

    poOut = NEW JsonObject().
    poOut:Add("success", plOk).
    IF pcMsg <> "" THEN poOut:Add("message", pcMsg).
    IF VALID-OBJECT(poData) THEN poOut:Add("data", poData).
    poOut = JsonApiResponseBuilder:ok(poOut, 200).
END PROCEDURE.

/* -------------------------------------------------------------------- */
/* Sobe o BO, chama a rotina e monta a resposta. Erro de regra volta em  */
/* pcErro (success = false); erro de execucao cai no CATCH.              */
/* -------------------------------------------------------------------- */
PROCEDURE piExecuta PRIVATE:
    DEFINE INPUT  PARAMETER pcRotina AS CHARACTER  NO-UNDO.
    DEFINE INPUT  PARAMETER poInput  AS JsonObject NO-UNDO.
    DEFINE OUTPUT PARAMETER poOutput AS JsonObject NO-UNDO.

    DEFINE VARIABLE hRules AS HANDLE     NO-UNDO.
    DEFINE VARIABLE oData  AS JsonObject NO-UNDO.
    DEFINE VARIABLE cErro  AS CHARACTER  NO-UNDO.

    RUN esp/api/v1/estplOcorrenciaRules.p PERSISTENT SET hRules.
    RUN VALUE(pcRotina) IN hRules (INPUT poInput, OUTPUT oData, OUTPUT cErro).
    RUN piResposta (cErro = "", cErro, oData, OUTPUT poOutput).

    CATCH oE AS Error:
        poOutput = JsonApiResponseBuilder:asError(oE).
    END CATCH.
    FINALLY:
        DELETE PROCEDURE hRules NO-ERROR.
    END FINALLY.
END PROCEDURE.

/* -------------------------------------------------------------------- */
/* Uma procedure por rota: parametros fixos do framework                 */
/* -------------------------------------------------------------------- */
PROCEDURE pi-lista:
    DEFINE INPUT  PARAM oInput  AS JsonObject NO-UNDO.
    DEFINE OUTPUT PARAM oOutput AS JsonObject NO-UNDO.

    RUN piExecuta (INPUT "pi-lista", INPUT oInput, OUTPUT oOutput).
END PROCEDURE.

PROCEDURE pi-consulta:
    DEFINE INPUT  PARAM oInput  AS JsonObject NO-UNDO.
    DEFINE OUTPUT PARAM oOutput AS JsonObject NO-UNDO.

    RUN piExecuta (INPUT "pi-consulta", INPUT oInput, OUTPUT oOutput).
END PROCEDURE.

PROCEDURE pi-salvar:
    DEFINE INPUT  PARAM oInput  AS JsonObject NO-UNDO.
    DEFINE OUTPUT PARAM oOutput AS JsonObject NO-UNDO.

    RUN piExecuta (INPUT "pi-salvar", INPUT oInput, OUTPUT oOutput).
END PROCEDURE.

PROCEDURE pi-excluir:
    DEFINE INPUT  PARAM oInput  AS JsonObject NO-UNDO.
    DEFINE OUTPUT PARAM oOutput AS JsonObject NO-UNDO.

    RUN piExecuta (INPUT "pi-excluir", INPUT oInput, OUTPUT oOutput).
END PROCEDURE.

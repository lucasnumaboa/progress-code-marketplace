/*------------------------------------------------------------------------
    File        : esp/api/v1/estplOcorrenciaRules.p
    Purpose     : BO modelo do handler estplOcorrencia.p - rodar PERSISTENT.
                  Toda leitura e gravacao de banco fica aqui.
    Origem      : template progress-templates

    Contrato de cada rotina publica:
      INPUT  poInput JsonObject  (corpo/consulta da requisicao)
      OUTPUT poData  JsonObject  (vai em "data" na resposta)
      OUTPUT pcErro  CHARACTER   (erro de regra; "" = sucesso)

    Chaves JSON x campos (tabela es-tpl-ocor):
      codigo -> codigo (integer)     descricao -> descricao (character)
      tipo   -> tipo   (integer)     ativo     -> ativo     (logical)

    Fonte em ASCII (sem acento): a resposta sai em UTF-8 e o fonte Datasul e
    CP850; texto acentuado no fonte chega errado na tela.

    Trocar: tabela, campos, chaves JSON e as validacoes de pi-salvar.
------------------------------------------------------------------------*/

USING Progress.Json.ObjectModel.JsonObject.
USING Progress.Json.ObjectModel.JsonArray.
USING Progress.Json.ObjectModel.JsonDataType.

/* ------------------------------------------------------------------ */
/* Corpo da requisicao. Conforme o ambiente o framework entrega o body  */
/* dentro de "payload", "requestBody" ou "body"; sem wrapper (teste     */
/* chamando o BO direto) usa o proprio objeto.                          */
/* ------------------------------------------------------------------ */
FUNCTION fnBody RETURNS JsonObject (INPUT po AS JsonObject):
    DEFINE VARIABLE oB AS JsonObject NO-UNDO.

    IF NOT VALID-OBJECT(po) THEN RETURN NEW JsonObject().
    IF po:Has("payload") THEN oB = po:GetJsonObject("payload") NO-ERROR.
    IF NOT VALID-OBJECT(oB) AND po:Has("requestBody") THEN oB = po:GetJsonObject("requestBody") NO-ERROR.
    IF NOT VALID-OBJECT(oB) AND po:Has("body") THEN oB = po:GetJsonObject("body") NO-ERROR.
    IF NOT VALID-OBJECT(oB) THEN oB = po.
    RETURN oB.
END FUNCTION.

/* Leitura tolerante: a tela pode mandar numero como texto e vice-versa. */
FUNCTION fnTexto RETURNS CHARACTER (INPUT po AS JsonObject, INPUT pcChave AS CHARACTER):
    IF NOT po:Has(pcChave) OR po:IsNull(pcChave) THEN RETURN "".
    CASE po:GetType(pcChave):
        WHEN JsonDataType:STRING  THEN RETURN po:GetCharacter(pcChave).
        WHEN JsonDataType:NUMBER  THEN RETURN STRING(po:GetDecimal(pcChave)).
        WHEN JsonDataType:BOOLEAN THEN RETURN STRING(po:GetLogical(pcChave), "true/false").
    END CASE.
    RETURN "".
END FUNCTION.

FUNCTION fnInteiro RETURNS INTEGER (INPUT po AS JsonObject, INPUT pcChave AS CHARACTER):
    DEFINE VARIABLE i AS INTEGER NO-UNDO.

    IF NOT po:Has(pcChave) OR po:IsNull(pcChave) THEN RETURN 0.
    IF po:GetType(pcChave) = JsonDataType:NUMBER THEN RETURN po:GetInteger(pcChave).
    ASSIGN i = INTEGER(TRIM(fnTexto(po, pcChave))) NO-ERROR.
    IF ERROR-STATUS:ERROR OR i = ? THEN RETURN 0.
    RETURN i.
END FUNCTION.

FUNCTION fnLogico RETURNS LOGICAL (INPUT po AS JsonObject, INPUT pcChave AS CHARACTER):
    IF NOT po:Has(pcChave) OR po:IsNull(pcChave) THEN RETURN NO.
    IF po:GetType(pcChave) = JsonDataType:BOOLEAN THEN RETURN po:GetLogical(pcChave).
    RETURN LOOKUP(LC(TRIM(fnTexto(po, pcChave))), "true,yes,sim,s,1") > 0.
END FUNCTION.

/* registro -> JSON (um lugar so para o mapeamento campo x chave) */
PROCEDURE piRegistroJson PRIVATE:
    DEFINE PARAMETER BUFFER b-ocor FOR es-tpl-ocor.
    DEFINE OUTPUT PARAMETER poItem AS JsonObject NO-UNDO.

    poItem = NEW JsonObject().
    poItem:Add("codigo",    b-ocor.codigo).
    poItem:Add("descricao", b-ocor.descricao).
    poItem:Add("tipo",      b-ocor.tipo).
    poItem:Add("ativo",     b-ocor.ativo).
END PROCEDURE.

/* ------------------------------------------------------------------ */
/* GET / : todos os registros                                          */
/* ------------------------------------------------------------------ */
PROCEDURE pi-lista:
    DEFINE INPUT  PARAMETER poInput AS JsonObject NO-UNDO.
    DEFINE OUTPUT PARAMETER poData  AS JsonObject NO-UNDO.
    DEFINE OUTPUT PARAMETER pcErro  AS CHARACTER  NO-UNDO.

    DEFINE VARIABLE oItens AS JsonArray  NO-UNDO.
    DEFINE VARIABLE oItem  AS JsonObject NO-UNDO.

    oItens = NEW JsonArray().
    FOR EACH es-tpl-ocor NO-LOCK BY es-tpl-ocor.codigo:
        RUN piRegistroJson (BUFFER es-tpl-ocor, OUTPUT oItem).
        oItens:Add(oItem).
    END.

    poData = NEW JsonObject().
    poData:Add("items", oItens).
    poData:Add("total", oItens:Length).
END PROCEDURE.

/* ------------------------------------------------------------------ */
/* POST /consulta : filtro { tipo, somenteAtivos, texto }              */
/* ------------------------------------------------------------------ */
PROCEDURE pi-consulta:
    DEFINE INPUT  PARAMETER poInput AS JsonObject NO-UNDO.
    DEFINE OUTPUT PARAMETER poData  AS JsonObject NO-UNDO.
    DEFINE OUTPUT PARAMETER pcErro  AS CHARACTER  NO-UNDO.

    DEFINE VARIABLE oBody  AS JsonObject NO-UNDO.
    DEFINE VARIABLE oItens AS JsonArray  NO-UNDO.
    DEFINE VARIABLE oItem  AS JsonObject NO-UNDO.
    DEFINE VARIABLE iTipo  AS INTEGER    NO-UNDO.
    DEFINE VARIABLE lAtivo AS LOGICAL    NO-UNDO.
    DEFINE VARIABLE cTexto AS CHARACTER  NO-UNDO.

    ASSIGN oBody  = fnBody(poInput)
           iTipo  = fnInteiro(oBody, "tipo")
           lAtivo = fnLogico(oBody, "somenteAtivos")
           cTexto = TRIM(fnTexto(oBody, "texto")).

    oItens = NEW JsonArray().

    /* com tipo informado a leitura vai pelo indice idx-tipo; sem tipo, pelo primario */
    IF iTipo <> 0 THEN
        FOR EACH es-tpl-ocor NO-LOCK
            WHERE es-tpl-ocor.tipo = iTipo
            BY es-tpl-ocor.codigo:
            IF lAtivo AND NOT es-tpl-ocor.ativo THEN NEXT.
            IF cTexto <> "" AND INDEX(es-tpl-ocor.descricao, cTexto) = 0 THEN NEXT.
            RUN piRegistroJson (BUFFER es-tpl-ocor, OUTPUT oItem).
            oItens:Add(oItem).
        END.
    ELSE
        FOR EACH es-tpl-ocor NO-LOCK BY es-tpl-ocor.codigo:
            IF lAtivo AND NOT es-tpl-ocor.ativo THEN NEXT.
            IF cTexto <> "" AND INDEX(es-tpl-ocor.descricao, cTexto) = 0 THEN NEXT.
            RUN piRegistroJson (BUFFER es-tpl-ocor, OUTPUT oItem).
            oItens:Add(oItem).
        END.

    poData = NEW JsonObject().
    poData:Add("items", oItens).
    poData:Add("total", oItens:Length).
END PROCEDURE.

/* ------------------------------------------------------------------ */
/* POST /salvar : inclui ou altera pelo codigo                         */
/* ------------------------------------------------------------------ */
PROCEDURE pi-salvar:
    DEFINE INPUT  PARAMETER poInput AS JsonObject NO-UNDO.
    DEFINE OUTPUT PARAMETER poData  AS JsonObject NO-UNDO.
    DEFINE OUTPUT PARAMETER pcErro  AS CHARACTER  NO-UNDO.

    DEFINE VARIABLE oBody   AS JsonObject NO-UNDO.
    DEFINE VARIABLE oItem   AS JsonObject NO-UNDO.
    DEFINE VARIABLE iCodigo AS INTEGER    NO-UNDO.
    DEFINE VARIABLE cDescr  AS CHARACTER  NO-UNDO.
    DEFINE VARIABLE lNovo   AS LOGICAL    NO-UNDO.

    ASSIGN oBody   = fnBody(poInput)
           iCodigo = fnInteiro(oBody, "codigo")
           cDescr  = TRIM(fnTexto(oBody, "descricao")).

    /* validacoes antes de abrir transacao */
    IF iCodigo <= 0 THEN DO:
        ASSIGN pcErro = "Informe o codigo (maior que zero).".
        RETURN.
    END.
    IF cDescr = "" THEN DO:
        ASSIGN pcErro = "Informe a descricao.".
        RETURN.
    END.

    DO TRANSACTION ON ERROR UNDO, LEAVE:
        FIND es-tpl-ocor EXCLUSIVE-LOCK
             WHERE es-tpl-ocor.codigo = iCodigo NO-WAIT NO-ERROR.
        IF LOCKED es-tpl-ocor THEN DO:
            ASSIGN pcErro = "Registro " + STRING(iCodigo) + " em uso por outro usuario. Tente de novo.".
            UNDO, LEAVE.
        END.
        IF NOT AVAILABLE es-tpl-ocor THEN DO:
            CREATE es-tpl-ocor.
            ASSIGN es-tpl-ocor.codigo = iCodigo
                   lNovo              = YES.
        END.
        ASSIGN es-tpl-ocor.descricao = cDescr
               es-tpl-ocor.tipo      = fnInteiro(oBody, "tipo")
               es-tpl-ocor.ativo     = fnLogico(oBody, "ativo").

        RUN piRegistroJson (BUFFER es-tpl-ocor, OUTPUT oItem).
    END.

    IF pcErro <> "" THEN RETURN.

    poData = NEW JsonObject().
    poData:Add("incluido", lNovo).
    IF VALID-OBJECT(oItem) THEN poData:Add("item", oItem).
END PROCEDURE.

/* ------------------------------------------------------------------ */
/* POST /excluir : elimina pelo codigo                                 */
/* ------------------------------------------------------------------ */
PROCEDURE pi-excluir:
    DEFINE INPUT  PARAMETER poInput AS JsonObject NO-UNDO.
    DEFINE OUTPUT PARAMETER poData  AS JsonObject NO-UNDO.
    DEFINE OUTPUT PARAMETER pcErro  AS CHARACTER  NO-UNDO.

    DEFINE VARIABLE oBody   AS JsonObject NO-UNDO.
    DEFINE VARIABLE iCodigo AS INTEGER    NO-UNDO.

    ASSIGN oBody   = fnBody(poInput)
           iCodigo = fnInteiro(oBody, "codigo").

    DO TRANSACTION ON ERROR UNDO, LEAVE:
        FIND es-tpl-ocor EXCLUSIVE-LOCK
             WHERE es-tpl-ocor.codigo = iCodigo NO-WAIT NO-ERROR.
        IF LOCKED es-tpl-ocor THEN DO:
            ASSIGN pcErro = "Registro " + STRING(iCodigo) + " em uso por outro usuario. Tente de novo.".
            UNDO, LEAVE.
        END.
        IF NOT AVAILABLE es-tpl-ocor THEN DO:
            ASSIGN pcErro = "Registro " + STRING(iCodigo) + " nao encontrado.".
            UNDO, LEAVE.
        END.
        DELETE es-tpl-ocor.
    END.

    IF pcErro <> "" THEN RETURN.

    poData = NEW JsonObject().
    poData:Add("excluido", iCodigo).
END PROCEDURE.

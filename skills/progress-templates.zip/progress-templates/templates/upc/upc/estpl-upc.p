/*------------------------------------------------------------------------------
  Programa...: upc/estpl-upc.p
  Objetivo...: UPC (EPC) de tela - modelo. A UPC e chamada pelo programa padrao
               em cada ponto de entrada (evento); ela decide em quais atua.
  Cadastro...: campo "UPC" do programa padrao (prog_dtsul.nom_prog_upc).
  Origem.....: template progress-templates
  Trocar.....: nome do programa, eventos tratados, tabela (p-cod-table), nomes
               dos widgets e as regras de pi-initialize / pi-validate.

  Retorno....: "OK" segue o fluxo do programa padrao; "NOK" interrompe (so tem
               efeito nos eventos em que o programa padrao testa o retorno,
               como VALIDATE).
  Cuidados...: - sair cedo do que nao interessa: a UPC roda em TODO evento;
               - nunca supor o nome do widget nem o evento: confirme no fonte ou
                 com uma UPC de log antes de construir em cima;
               - testar VALID-HANDLE antes de usar handle recebido ou achado.
------------------------------------------------------------------------------*/

/* parametros padrao de UPC: nesta ordem e com estes tipos */
DEFINE INPUT PARAMETER p-ind-event  AS CHARACTER     NO-UNDO.  /* evento             */
DEFINE INPUT PARAMETER p-ind-object AS CHARACTER     NO-UNDO.  /* objeto que chamou  */
DEFINE INPUT PARAMETER p-wgh-object AS HANDLE        NO-UNDO.  /* handle do objeto   */
DEFINE INPUT PARAMETER p-wgh-frame  AS WIDGET-HANDLE NO-UNDO.  /* frame do objeto    */
DEFINE INPUT PARAMETER p-cod-table  AS CHARACTER     NO-UNDO.  /* tabela do registro */
DEFINE INPUT PARAMETER p-row-table  AS ROWID         NO-UNDO.  /* rowid do registro  */

{utp/ut-glob.i}     /* c-seg-usuario e demais globais da sessao */

DEFINE VARIABLE h-widget AS WIDGET-HANDLE NO-UNDO.

DEFINE BUFFER b-estabelec FOR estabelec.

FUNCTION fnAchaWidget RETURNS WIDGET-HANDLE
    (INPUT p-pai AS WIDGET-HANDLE, INPUT p-nome AS CHARACTER) FORWARD.

/* 1. so atua nos eventos tratados aqui */
IF LOOKUP(p-ind-event, "INITIALIZE,VALIDATE":U) = 0 THEN
    RETURN "OK":U.

/* 2. so atua na tabela esperada (cada objeto da tela chama a UPC com a sua) */
IF p-cod-table <> "estabelec":U THEN
    RETURN "OK":U.

CASE p-ind-event:
    WHEN "INITIALIZE":U THEN
        RUN pi-initialize.
    WHEN "VALIDATE":U THEN DO:
        RUN pi-validate.
        IF RETURN-VALUE = "NOK":U THEN
            RETURN "NOK":U.
    END.
END CASE.

RETURN "OK":U.


/* ************************  Procedures internas  ************************ */

PROCEDURE pi-initialize:
/*------------------------------------------------------------------------------
  Exemplo de ajuste de tela: desabilita um botao pelo nome.
------------------------------------------------------------------------------*/
    IF NOT VALID-HANDLE(p-wgh-frame) THEN
        RETURN "OK":U.

    ASSIGN h-widget = fnAchaWidget(p-wgh-frame, "bt-exemplo":U).
    IF VALID-HANDLE(h-widget) THEN
        ASSIGN h-widget:SENSITIVE = NO.

    RETURN "OK":U.
END PROCEDURE.

PROCEDURE pi-validate:
/*------------------------------------------------------------------------------
  Exemplo de regra: le o registro pelo rowid recebido e barra a gravacao.
------------------------------------------------------------------------------*/
    IF p-row-table = ? THEN
        RETURN "OK":U.

    FIND b-estabelec NO-LOCK
         WHERE ROWID(b-estabelec) = p-row-table NO-ERROR.
    IF NOT AVAILABLE b-estabelec THEN
        RETURN "OK":U.

    IF NOT CAN-FIND(FIRST es-tpl-serie
                    WHERE es-tpl-serie.cod-estabel = b-estabelec.cod-estabel) THEN DO:
        /* 17006: mensagem generica "titulo~~texto de ajuda" */
        RUN utp/ut-msgs.p (INPUT "show":U,
                           INPUT 17006,
                           INPUT "Estabelecimento sem serie cadastrada~~"
                               + "Cadastre ao menos uma serie para o estabelecimento "
                               + b-estabelec.cod-estabel + " antes de gravar.").
        RETURN "NOK":U.
    END.

    RETURN "OK":U.
END PROCEDURE.

/* procura um widget pelo nome dentro do frame (e dos frames filhos) */
FUNCTION fnAchaWidget RETURNS WIDGET-HANDLE
    (INPUT p-pai AS WIDGET-HANDLE, INPUT p-nome AS CHARACTER):

    DEFINE VARIABLE h-filho AS WIDGET-HANDLE NO-UNDO.
    DEFINE VARIABLE h-achou AS WIDGET-HANDLE NO-UNDO.

    IF NOT VALID-HANDLE(p-pai) THEN RETURN ?.
    IF CAN-QUERY(p-pai, "NAME":U) AND p-pai:NAME = p-nome THEN RETURN p-pai.
    IF NOT CAN-QUERY(p-pai, "FIRST-CHILD":U) THEN RETURN ?.

    ASSIGN h-filho = p-pai:FIRST-CHILD.
    DO WHILE VALID-HANDLE(h-filho):
        ASSIGN h-achou = fnAchaWidget(h-filho, p-nome).
        IF VALID-HANDLE(h-achou) THEN RETURN h-achou.
        ASSIGN h-filho = h-filho:NEXT-SIBLING.
    END.
    RETURN ?.
END FUNCTION.

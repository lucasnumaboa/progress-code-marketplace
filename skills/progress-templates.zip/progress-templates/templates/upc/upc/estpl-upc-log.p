/*------------------------------------------------------------------------------
  Programa...: upc/estpl-upc-log.p
  Objetivo...: UPC de levantamento - grava em arquivo todos os pontos de entrada
               (evento, objeto, tabela, rowid) e os widgets do frame recebido.
               Use antes de escrever a UPC definitiva, para comprovar quais
               eventos o programa padrao dispara e como os widgets se chamam.
  Cadastro...: cadastre temporariamente como UPC do programa padrao, abra a
               tela, repita a operacao e leia o arquivo. Depois tire o cadastro.
  Origem.....: template progress-templates
  Saida......: <pasta temporaria da sessao>/upc-log-<usuario>.txt
------------------------------------------------------------------------------*/
DEFINE INPUT PARAMETER p-ind-event  AS CHARACTER     NO-UNDO.
DEFINE INPUT PARAMETER p-ind-object AS CHARACTER     NO-UNDO.
DEFINE INPUT PARAMETER p-wgh-object AS HANDLE        NO-UNDO.
DEFINE INPUT PARAMETER p-wgh-frame  AS WIDGET-HANDLE NO-UNDO.
DEFINE INPUT PARAMETER p-cod-table  AS CHARACTER     NO-UNDO.
DEFINE INPUT PARAMETER p-row-table  AS ROWID         NO-UNDO.

{utp/ut-glob.i}

DEFINE STREAM s-log.

OUTPUT STREAM s-log TO VALUE(SESSION:TEMP-DIRECTORY + "upc-log-" + c-seg-usuario + ".txt") APPEND.

PUT STREAM s-log UNFORMATTED
    STRING(TODAY, "99/99/9999") " " STRING(TIME, "HH:MM:SS")
    " evento=" p-ind-event
    " objeto=" p-ind-object
    " proc=" (IF VALID-HANDLE(p-wgh-object) THEN p-wgh-object:FILE-NAME ELSE "?")
    " frame=" (IF VALID-HANDLE(p-wgh-frame) THEN p-wgh-frame:NAME ELSE "?")
    " tabela=" p-cod-table
    " rowid=" (IF p-row-table = ? THEN "?" ELSE STRING(p-row-table)) SKIP.

/* lista os widgets do frame uma vez por evento de inicializacao */
IF p-ind-event = "INITIALIZE":U AND VALID-HANDLE(p-wgh-frame) THEN
    RUN pi-lista-widgets (INPUT p-wgh-frame, INPUT 1).

OUTPUT STREAM s-log CLOSE.

RETURN "OK":U.

PROCEDURE pi-lista-widgets:
    DEFINE INPUT PARAMETER p-pai   AS WIDGET-HANDLE NO-UNDO.
    DEFINE INPUT PARAMETER p-nivel AS INTEGER       NO-UNDO.

    DEFINE VARIABLE h-filho AS WIDGET-HANDLE NO-UNDO.

    IF NOT VALID-HANDLE(p-pai) OR NOT CAN-QUERY(p-pai, "FIRST-CHILD":U) THEN
        RETURN.

    ASSIGN h-filho = p-pai:FIRST-CHILD.
    DO WHILE VALID-HANDLE(h-filho):
        PUT STREAM s-log UNFORMATTED
            FILL("  ", p-nivel) "widget tipo=" h-filho:TYPE
            " nome=" (IF CAN-QUERY(h-filho, "NAME":U) AND h-filho:NAME <> ? THEN h-filho:NAME ELSE "")
            " label=" (IF CAN-QUERY(h-filho, "LABEL":U) AND h-filho:LABEL <> ? THEN h-filho:LABEL ELSE "") SKIP.
        RUN pi-lista-widgets (INPUT h-filho, INPUT p-nivel + 1).
        ASSIGN h-filho = h-filho:NEXT-SIBLING.
    END.
END PROCEDURE.

&ANALYZE-SUSPEND _VERSION-NUMBER UIB_v8r12 GUI ADM1
&ANALYZE-RESUME
/* Connected Databases 
         mgsor          PROGRESS
*/
&Scoped-define WINDOW-NAME CURRENT-WINDOW
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CUSTOM _DEFINITIONS V-table-Win 
/*:T *******************************************************************************
** Copyright TOTVS S.A. (2009)
** Todos os Direitos Reservados.
**
** Este fonte e de propriedade exclusiva da TOTVS, sua reproducao
** parcial ou total por qualquer meio, so podera ser feita mediante
** autorizacao expressa.
*******************************************************************************/
/*------------------------------------------------------------------------------
  Programa...: estpl002vf.w
  Objetivo...: Viewer de series por estabelecimento (SmartViewer)
  Origem.....: template progress-templates (DDK classico)
------------------------------------------------------------------------------*/
{include/i-prgvrs.i estpl002vf  2.00.00.001}

/* Chamada a include do gerenciador de licencas. Necessario alterar os parametros */
/* */
/* estpl002vf:  Nome do programa.                                 */
/* <modulo>:  Informar qual o modulo a qual o programa pertence.                  */
/* */
/* OBS: Para os smartobjects o parametro modulo devera ser MUT                    */

&IF "{&EMSFND_VERSION}" >= "1.00" &THEN
    {include/i-license-manager.i estpl002vf MUT}
&ENDIF

/* Create an unnamed pool to store all the widgets created 
     by this procedure. This is a good default which assures
     that this procedure's triggers and internal procedures 
     will execute in this procedure's storage, and that proper
     cleanup will occur on deletion of the procedure. */

CREATE WIDGET-POOL.

/* *************************** Definitions  ************************** */
&Scop adm-attribute-dlg support/viewerd.w

/* global variable definitions */

/* Parameters Definitions ---                                           */

/* Local Variable Definitions ---                                       */
def var v-row-parent as rowid no-undo.

DEF BUFFER bf-es-tpl-serie FOR es-tpl-serie.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&ANALYZE-SUSPEND _UIB-PREPROCESSOR-BLOCK 

/* ******************** Preprocessor Definitions  ******************** */

&Scoped-define PROCEDURE-TYPE SmartViewer
&Scoped-define DB-AWARE no

&Scoped-define ADM-SUPPORTED-LINKS Record-Source,Record-Target,TableIO-Target

/* Name of designated FRAME-NAME and/or first browse and/or first query */
&Scoped-define FRAME-NAME f-main

/* External Tables                                                      */
&Scoped-define EXTERNAL-TABLES es-tpl-serie
&Scoped-define FIRST-EXTERNAL-TABLE es-tpl-serie


/* Need to scope the external tables to this procedure                  */
DEFINE QUERY external_tables FOR es-tpl-serie.
/* Standard List Definitions                                            */
&Scoped-Define ENABLED-FIELDS es-tpl-serie.cod-serie 
&Scoped-define ENABLED-TABLES es-tpl-serie
&Scoped-define FIRST-ENABLED-TABLE es-tpl-serie
&Scoped-Define ENABLED-OBJECTS rt-key rt-mold 
&Scoped-Define DISPLAYED-FIELDS es-tpl-serie.cod-serie 
&Scoped-define DISPLAYED-TABLES es-tpl-serie
&Scoped-define FIRST-DISPLAYED-TABLE es-tpl-serie


/* Custom List Definitions                                              */
/* ADM-CREATE-FIELDS,ADM-ASSIGN-FIELDS,ADM-MODIFY-FIELDS,List-4,List-5,List-6 */
&Scoped-define ADM-CREATE-FIELDS es-tpl-serie.cod-serie 

/* _UIB-PREPROCESSOR-BLOCK-END */
&ANALYZE-RESUME


&ANALYZE-SUSPEND _UIB-CODE-BLOCK _XFTR "Foreign Keys" V-table-Win _INLINE
/* Actions: ? adm/support/keyedit.w ? ? ? */
/* STRUCTURED-DATA
<KEY-OBJECT>
THIS-PROCEDURE
</KEY-OBJECT>
<FOREIGN-KEYS>
</FOREIGN-KEYS> 
<EXECUTING-CODE>
**************************
* Set attributes related to FOREIGN KEYS
*/
RUN set-attribute-list (
    'Keys-Accepted = "",
     Keys-Supplied = ""':U).
/**************************
</EXECUTING-CODE> */   

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


/* *********************** Control Definitions  ********************** */


/* Definitions of the field level widgets                               */
DEFINE RECTANGLE rt-key
     EDGE-PIXELS 2 GRAPHIC-EDGE  NO-FILL   
     SIZE 80 BY 1.25.

DEFINE RECTANGLE rt-mold
     EDGE-PIXELS 2 GRAPHIC-EDGE  NO-FILL   
     SIZE 80 BY 1.25.


/* ************************ Frame Definitions  *********************** */

DEFINE FRAME f-main
     es-tpl-serie.cod-serie AT ROW 1.17 COL 15 COLON-ALIGNED WIDGET-ID 2
          VIEW-AS FILL-IN 
          SIZE 12 BY .88
     rt-key AT ROW 1 COL 1
     rt-mold AT ROW 2.5 COL 1
    WITH 1 DOWN NO-BOX KEEP-TAB-ORDER OVERLAY 
         SIDE-LABELS NO-UNDERLINE THREE-D 
         AT COL 1 ROW 1 SCROLLABLE  WIDGET-ID 100.

/* ************************ Control Triggers  ************************ */

&Scoped-define SELF-NAME es-tpl-serie.cod-serie
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL es-tpl-serie.cod-serie V-table-Win
ON LEAVE OF es-tpl-serie.cod-serie IN FRAME f-main
DO:
    /* Se o usu�rio deixou em branco, n�o valida nada ainda */
    IF SELF:SCREEN-VALUE = "" THEN RETURN.

    /* 1. Valida se a s�rie existe no cadastro mestre (tabela serie) */
    FIND FIRST serie NO-LOCK
         WHERE serie.serie = SELF:SCREEN-VALUE NO-ERROR.

    /* erro real de banco (diferente do "not found" 138) nao pode virar "serie nao encontrada" */
    IF ERROR-STATUS:ERROR AND ERROR-STATUS:NUM-MESSAGES > 0
       AND LOOKUP(STRING(ERROR-STATUS:GET-NUMBER(1)), "138,565") = 0 THEN DO:
        RUN utp/ut-msgs.p (INPUT "show":U, INPUT 7, INPUT "Erro ao consultar a serie: " + ERROR-STATUS:GET-MESSAGE(1)).
        APPLY "ENTRY" TO SELF.
        RETURN NO-APPLY.
    END.

    IF NOT AVAIL serie THEN DO:
        RUN utp/ut-msgs.p (INPUT "show":U, INPUT 7, INPUT "S�rie: " + SELF:SCREEN-VALUE + " n�o encontrada no cadastro de s�ries.").
        APPLY "ENTRY" TO SELF. /* Prende o cursor no campo */
        RETURN NO-APPLY.
    END.

    /* 2. Sem o pai nao existe como validar a duplicidade: avisa em vez de pular a validacao */
    IF v-row-parent = ? THEN DO:
        RUN utp/ut-msgs.p (INPUT "show":U, INPUT 7, INPUT "Estabelecimento pai nao informado. Selecione o estabelecimento antes de incluir a serie.").
        APPLY "ENTRY" TO SELF. /* Prende o cursor no campo */
        RETURN NO-APPLY.
    END.

    IF v-row-parent <> ? THEN DO:
        FIND FIRST estabelec NO-LOCK
            WHERE ROWID(estabelec) = v-row-parent NO-ERROR.

        IF NOT AVAILABLE estabelec THEN DO:
            RUN utp/ut-msgs.p (INPUT "show":U, INPUT 7, INPUT "Estabelecimento pai nao encontrado. Reabra a tela pelo cadastro de estabelecimento.").
            APPLY "ENTRY" TO SELF.
            RETURN NO-APPLY.
        END.

        FIND FIRST bf-es-tpl-serie NO-LOCK
            WHERE bf-es-tpl-serie.cod-estabel = estabelec.cod-estabel
              AND bf-es-tpl-serie.cod-serie = SELF:SCREEN-VALUE
              AND (NOT AVAILABLE es-tpl-serie OR ROWID(bf-es-tpl-serie) <> ROWID(es-tpl-serie))
              NO-ERROR.

        /* erro real de banco (diferente do "not found" 138) nao pode passar como "sem duplicata" */
        IF ERROR-STATUS:ERROR AND ERROR-STATUS:NUM-MESSAGES > 0
       AND LOOKUP(STRING(ERROR-STATUS:GET-NUMBER(1)), "138,565") = 0 THEN DO:
            RUN utp/ut-msgs.p (INPUT "show":U, INPUT 7, INPUT "Erro ao consultar as series do estabelecimento: " + ERROR-STATUS:GET-MESSAGE(1)).
            APPLY "ENTRY" TO SELF.
            RETURN NO-APPLY.
        END.

        IF AVAIL bf-es-tpl-serie THEN DO:
            RUN utp/ut-msgs.p (INPUT "show":U, INPUT 7, INPUT "S�rie: " + bf-es-tpl-serie.cod-serie + " j� cadastrada para o Estabelecimento: " + bf-es-tpl-serie.cod-estabel).
            APPLY "ENTRY" TO SELF. /* Prende o cursor no campo */
            RETURN NO-APPLY.
        END.
    END.
END.
/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


/* *********************** Procedure Settings ************************ */

&ANALYZE-SUSPEND _PROCEDURE-SETTINGS
/* Settings for THIS-PROCEDURE
   Type: SmartViewer
   External Tables: mgsor.es-tpl-serie
   Allow: Basic,DB-Fields
   Frames: 1
   Add Fields to: EXTERNAL-TABLES
   Other Settings: PERSISTENT-ONLY COMPILE
 */

/* This procedure should always be RUN PERSISTENT.  Report the error,  */
/* then cleanup and return.                                            */
IF NOT THIS-PROCEDURE:PERSISTENT THEN DO:
  MESSAGE "{&FILE-NAME} should only be RUN PERSISTENT.":U
          VIEW-AS ALERT-BOX ERROR BUTTONS OK.
  RETURN.
END.

&ANALYZE-RESUME _END-PROCEDURE-SETTINGS

/* ************************* Create Window  ************************** */

&ANALYZE-SUSPEND _CREATE-WINDOW
/* DESIGN Window definition (used by the UIB) 
  CREATE WINDOW V-table-Win ASSIGN
         HEIGHT             = 13
         WIDTH              = 88.57.
/* END WINDOW DEFINITION */
                                                                        */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CUSTOM _INCLUDED-LIB V-table-Win 
/* ************************* Included-Libraries *********************** */

{src/adm/method/viewer.i}
{include/c-viewer.i}
{utp/ut-glob.i}
{include/i_dbtype.i}

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


/* *********** Runtime Attributes and AppBuilder Settings  *********** */

&ANALYZE-SUSPEND _RUN-TIME-ATTRIBUTES
/* SETTINGS FOR WINDOW V-table-Win
  VISIBLE,,RUN-PERSISTENT                                               */
/* SETTINGS FOR FRAME f-main
   NOT-VISIBLE FRAME-NAME Size-to-Fit                                   */
ASSIGN 
       FRAME f-main:SCROLLABLE       = FALSE
       FRAME f-main:HIDDEN           = TRUE.

/* SETTINGS FOR FILL-IN es-tpl-serie.cod-serie IN FRAME f-main
   NO-ENABLE 1                                                          */
/* _RUN-TIME-ATTRIBUTES-END */
&ANALYZE-RESUME


/* Setting information for Queries and Browse Widgets fields            */

&ANALYZE-SUSPEND _QUERY-BLOCK FRAME f-main
/* Query rebuild information for FRAME f-main
     _Options          = "NO-LOCK"
     _Query            is NOT OPENED
*/  /* FRAME f-main */
&ANALYZE-RESUME


&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CUSTOM _MAIN-BLOCK V-table-Win 


/* *************************** Main Block  *************************** */

  &IF DEFINED(UIB_IS_RUNNING) <> 0 &THEN          
    RUN dispatch IN THIS-PROCEDURE ('initialize':U).        
  &ENDIF         
  
  /************************ INTERNAL PROCEDURES ********************/

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


/* ********************** Internal Procedures  *********************** */

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE adm-row-available V-table-Win  _ADM-ROW-AVAILABLE
PROCEDURE adm-row-available :
/*------------------------------------------------------------------------------
  Purpose:     Dispatched to this procedure when the Record-
               Source has a new row available.  This procedure
               tries to get the new row (or foriegn keys) from
               the Record-Source and process it.
  Parameters:  <none>
------------------------------------------------------------------------------*/

  /* Define variables needed by this internal procedure.             */
  {src/adm/template/row-head.i}

  /* Create a list of all the tables that we need to get.            */
  {src/adm/template/row-list.i "es-tpl-serie"}

  /* Get the record ROWID's from the RECORD-SOURCE.                  */
  {src/adm/template/row-get.i}

  /* FIND each record specified by the RECORD-SOURCE.                */
  {src/adm/template/row-find.i "es-tpl-serie"}

  /* Process the newly available records (i.e. display fields,
     open queries, and/or pass records on to any RECORD-TARGETS).    */
  {src/adm/template/row-end.i}

END PROCEDURE.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE disable_UI V-table-Win  _DEFAULT-DISABLE
PROCEDURE disable_UI :
/*------------------------------------------------------------------------------
  Purpose:     DISABLE the User Interface
  Parameters:  <none>
  Notes:       Here we clean-up the user-interface by deleting
               dynamic widgets we have created and/or hide 
               frames.  This procedure is usually called when
               we are ready to "clean-up" after running.
------------------------------------------------------------------------------*/
  /* Hide all frames. */
  HIDE FRAME f-main.
  IF THIS-PROCEDURE:PERSISTENT THEN DELETE PROCEDURE THIS-PROCEDURE.
END PROCEDURE.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE local-assign-record V-table-Win 
PROCEDURE local-assign-record :
/*------------------------------------------------------------------------------
  Purpose:     Override standard ADM method
  Notes:       
------------------------------------------------------------------------------*/

    /* Code placed here will execute PRIOR to standard behavior. */
    {include/i-valid.i}
    
    /*:T Ponha na pi-validate todas as validacoes */
    /*:T Nao gravar nada no registro antes do dispatch do assign-record e 
       nem na PI-validate. */
    
    /* Dispatch standard ADM method.                             */
    RUN dispatch IN THIS-PROCEDURE ( INPUT 'assign-record':U ) .
    if RETURN-VALUE = 'ADM-ERROR':U then 
        return 'ADM-ERROR':U.
    
    /*:T Todos os assigns nao feitos pelo assign-record devem ser feitos aqui */  
    /* Code placed here will execute AFTER standard behavior.    */


END PROCEDURE.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE local-create-record V-table-Win 
PROCEDURE local-create-record :
/*------------------------------------------------------------------------------
  Purpose:     
  Parameters:  <none>
  Notes:       
------------------------------------------------------------------------------*/
/* Code placed here will execute PRIOR to standard behavior.  */
/* Dispatch standard ADM method. */
RUN dispatch IN THIS-PROCEDURE ( INPUT 'create-record':U ).
/* Code placed here will execute AFTER standard behavior.     */

IF es-tpl-serie.cod-estabel = "" THEN DO:
    FIND FIRST estabelec NO-LOCK
        WHERE ROWID(estabelec) = v-row-parent NO-ERROR.

    IF AVAILABLE estabelec THEN
        ASSIGN es-tpl-serie.cod-estabel = estabelec.cod-estabel.
    ELSE DO:
        RUN utp/ut-msgs.p (INPUT "show":U, INPUT 7, INPUT "Estabelecimento pai nao informado ou nao encontrado. Reabra a tela pelo cadastro de estabelecimento.").
        RETURN 'ADM-ERROR':U.
    END.
END.

END PROCEDURE.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE local-disable-fields V-table-Win 
PROCEDURE local-disable-fields :
/*------------------------------------------------------------------------------
  Purpose:     Override standard ADM method
  Notes:       
------------------------------------------------------------------------------*/
    
    /* Code placed here will execute PRIOR to standard behavior. */
    
    /* Dispatch standard ADM method.                             */
    RUN dispatch IN THIS-PROCEDURE ( INPUT 'disable-fields':U ) .
    
    /* Code placed here will execute AFTER standard behavior.    */
    &if  defined(ADM-MODIFY-FIELDS) &then
    disable {&ADM-MODIFY-FIELDS} with frame {&frame-name}.
    &endif
    
END PROCEDURE.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE local-enable-fields V-table-Win 
PROCEDURE local-enable-fields :
/*------------------------------------------------------------------------------
  Purpose:     Override standard ADM method
  Notes:       
------------------------------------------------------------------------------*/
    
    /* Code placed here will execute PRIOR to standard behavior. */
    
    /* Dispatch standard ADM method.                             */
    RUN dispatch IN THIS-PROCEDURE ( INPUT 'enable-fields':U ) .
    
    /* Code placed here will execute AFTER standard behavior.    */
    &if  defined(ADM-MODIFY-FIELDS) &then
    if adm-new-record = yes then
        enable {&ADM-MODIFY-FIELDS} with frame {&frame-name}.
    &endif

END PROCEDURE.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE pi-atualiza-parent V-table-Win 
PROCEDURE pi-atualiza-parent :
/*------------------------------------------------------------------------------
  Purpose:     
  Parameters:  <none>
  Notes:       
------------------------------------------------------------------------------*/
    define input parameter v-row-parent-externo as rowid no-undo.
    
    assign v-row-parent = v-row-parent-externo.
    
END PROCEDURE.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE Pi-validate V-table-Win 
PROCEDURE Pi-validate :
/*:T------------------------------------------------------------------------------
  Purpose:Validar a viewer     
  Parameters:  <none>
  Notes: Nao fazer assign aqui. Nesta procedure
  devem ser colocadas apenas validacoes, pois neste ponto do programa o registro 
  ainda nao foi criado.        
------------------------------------------------------------------------------*/
    {include/i-vldfrm.i} /*:T Validacao de dicionario */

    
/*:T    Segue um exemplo de validacao de programa */
/* find tabela where tabela.campo1 = c-variavel and               */
/* tabela.campo2 > i-variavel no-lock no-error. */

    /* NOVA VALIDA��O: Verifica se a s�rie existe no cadastro mestre antes de prosseguir */
    FIND FIRST serie NO-LOCK
         WHERE serie.serie = es-tpl-serie.cod-serie:SCREEN-VALUE IN FRAME {&FRAME-NAME} NO-ERROR.
    
    IF ERROR-STATUS:ERROR AND ERROR-STATUS:NUM-MESSAGES > 0
       AND LOOKUP(STRING(ERROR-STATUS:GET-NUMBER(1)), "138,565") = 0 THEN DO:
        {include/i-vldprg.i}
        run utp/ut-msgs.p (input "show":U, input 7, input "Erro ao consultar a serie: " + ERROR-STATUS:GET-MESSAGE(1)).
        return 'ADM-ERROR':U.
    END.

    IF NOT AVAIL serie THEN DO:
        /*:T Este include deve ser colocado sempre antes do ut-msgs.p */
        {include/i-vldprg.i}
        run utp/ut-msgs.p (input "show":U, input 7, input "S�rie: " + es-tpl-serie.cod-serie:SCREEN-VALUE IN FRAME {&FRAME-NAME} + " n�o encontrada no cadastro de s�ries.").
        return 'ADM-ERROR':U.
    END.

    /* Se o pai nao foi informado, nao ha como validar a duplicidade */
    IF v-row-parent = ? THEN DO:
        {include/i-vldprg.i}
        run utp/ut-msgs.p (input "show":U, input 7, input "Estabelecimento pai nao informado. Nao e possivel validar a serie.").
        return 'ADM-ERROR':U.
    END.

    /* Pai inexistente nao pode pular a validacao de duplicidade */
    FIND FIRST estabelec NO-LOCK
        WHERE ROWID(estabelec) = v-row-parent NO-ERROR.

    IF NOT AVAILABLE estabelec THEN DO:
        {include/i-vldprg.i}
        run utp/ut-msgs.p (input "show":U, input 7, input "Estabelecimento pai nao encontrado. Reabra a tela pelo cadastro de estabelecimento.").
        return 'ADM-ERROR':U.
    END.

    FIND FIRST bf-es-tpl-serie NO-LOCK
    WHERE bf-es-tpl-serie.cod-estabel = estabelec.cod-estabel
      AND bf-es-tpl-serie.cod-serie = es-tpl-serie.cod-serie:SCREEN-VALUE IN FRAME {&FRAME-NAME}
      /* ignora o proprio registro em edicao (evita bloquear alteracao) */
      AND (NOT AVAILABLE es-tpl-serie OR ROWID(bf-es-tpl-serie) <> ROWID(es-tpl-serie)) NO-ERROR.
    
    IF ERROR-STATUS:ERROR AND ERROR-STATUS:NUM-MESSAGES > 0
       AND LOOKUP(STRING(ERROR-STATUS:GET-NUMBER(1)), "138,565") = 0 THEN DO:
    {include/i-vldprg.i}
    run utp/ut-msgs.p (input "show":U, input 7, input "Erro ao consultar as series do estabelecimento: " + ERROR-STATUS:GET-MESSAGE(1)).
    return 'ADM-ERROR':U.
        END.

        IF AVAIL bf-es-tpl-serie THEN DO:
        /*:T Este include deve ser colocado sempre antes do ut-msgs.p */
        {include/i-vldprg.i}
        run utp/ut-msgs.p (input "show":U, input 7, input  "S�rie: " + bf-es-tpl-serie.cod-serie + " j� cadastrada para o Estabelecimento: " + bf-es-tpl-serie.cod-estabel).
            return 'ADM-ERROR':U.
        END.        


END PROCEDURE.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE send-records V-table-Win  _ADM-SEND-RECORDS
PROCEDURE send-records :
/*------------------------------------------------------------------------------
  Purpose:     Send record ROWID's for all tables used by
               this file.
  Parameters:  see template/snd-head.i
------------------------------------------------------------------------------*/

  /* Define variables needed by this internal procedure.               */
  {src/adm/template/snd-head.i}

  /* For each requested table, put it's ROWID in the output list.      */
  {src/adm/template/snd-list.i "es-tpl-serie"}

  /* Deal with any unexpected table requests before closing.           */
  {src/adm/template/snd-end.i}

END PROCEDURE.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE state-changed V-table-Win 
PROCEDURE state-changed :
/* -----------------------------------------------------------
  Purpose:     
  Parameters:  <none>
  Notes:       
-------------------------------------------------------------*/
  DEFINE INPUT PARAMETER p-issuer-hdl AS HANDLE    NO-UNDO.
  DEFINE INPUT PARAMETER p-state      AS CHARACTER NO-UNDO.

  CASE p-state:
      /* Object instance CASEs can go here to replace standard behavior
         or add new cases. */
      {src/adm/template/vstates.i}
  END CASE.
  run pi-trata-state (p-issuer-hdl, p-state).
END PROCEDURE.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

/*------------------------------------------------------------------------------
  login-editor.p - Login do Datasul pelo Editor de Procedimentos.

  Valida o usuario e faz as demais conexoes de banco parametrizadas no
  btb962aa, deixando a sessao do editor igual a de um usuario logado (globais
  de usuario, empresa e bancos). Rode antes de testar um programa pelo editor.

  Trocar: <DOMINIO/USUARIO> e <SENHA>.
  Atencao: nao salve este arquivo com a senha preenchida em pasta de projeto,
  pacote de deploy ou repositorio. Preencha, rode e apague a senha.
------------------------------------------------------------------------------*/
define temp-table tt-erros
    field cod-erro  as integer
    field desc-erro as character format "x(256)"
    field desc-arq  as character.

/* API que valida o usuario e realiza as conexoes, conforme o btb962aa */
run btb/btapi910za.p (input  "<DOMINIO/USUARIO>",
                      input  "<SENHA>",
                      output table tt-erros).

if can-find(first tt-erros) then do:
    for each tt-erros:
        disp tt-erros.cod-erro  " - "
             tt-erros.desc-erro " - "
             tt-erros.desc-arq
             with down frame f1 width 600.
        down with frame f1.
    end.
end.
else
    message "Login realizado." view-as alert-box information.

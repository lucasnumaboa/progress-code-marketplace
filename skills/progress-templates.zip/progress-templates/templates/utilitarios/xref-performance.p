/*------------------------------------------------------------------------------
  xref-performance.p - Compila um programa com XREF e lista como cada leitura
  de tabela usa indice. Leitura marcada WHOLE-INDEX varre a tabela inteira
  (ou o indice inteiro): e o primeiro lugar para olhar quando o programa esta
  lento.

  Rodar numa sessao conectada aos bancos, com o programa no PROPATH.

  Trocar: cPrograma (caminho relativo ao PROPATH) e cSaida (pasta de saida).
  Tambem aceita -param "programa|pasta".

  Saida: <pasta>/<programa>.xrf (XREF completo) e <programa>.indices.txt com
  as linhas SEARCH: arquivo, linha, tabela, indice e o aviso WHOLE-INDEX.
  Nao grava .r: e so analise.
------------------------------------------------------------------------------*/
DEFINE VARIABLE cPrograma AS CHARACTER NO-UNDO INITIAL "esp/meu-programa.p".
DEFINE VARIABLE cSaida    AS CHARACTER NO-UNDO INITIAL "C:~\temp".
DEFINE VARIABLE cBase     AS CHARACTER NO-UNDO.
DEFINE VARIABLE cXref     AS CHARACTER NO-UNDO.
DEFINE VARIABLE cRel      AS CHARACTER NO-UNDO.
DEFINE VARIABLE cLinha    AS CHARACTER NO-UNDO.
DEFINE VARIABLE cResto    AS CHARACTER NO-UNDO.
DEFINE VARIABLE cEsq      AS CHARACTER NO-UNDO.
DEFINE VARIABLE cNumLin   AS CHARACTER NO-UNDO.
DEFINE VARIABLE cFonte    AS CHARACTER NO-UNDO.
DEFINE VARIABLE iPos      AS INTEGER   NO-UNDO.
DEFINE VARIABLE iLeituras AS INTEGER   NO-UNDO.
DEFINE VARIABLE iInteiras AS INTEGER   NO-UNDO.
DEFINE VARIABLE ix        AS INTEGER   NO-UNDO.

DEFINE STREAM sXrf.
DEFINE STREAM sRel.

IF SESSION:PARAMETER <> "" AND NUM-ENTRIES(SESSION:PARAMETER, "|") = 2 THEN
    ASSIGN cPrograma = ENTRY(1, SESSION:PARAMETER, "|")
           cSaida    = ENTRY(2, SESSION:PARAMETER, "|").

ASSIGN cBase = REPLACE(REPLACE(cPrograma, "~\", "_"), "/", "_")
       cXref = cSaida + "/" + cBase + ".xrf"
       cRel  = cSaida + "/" + cBase + ".indices.txt".

COMPILE VALUE(cPrograma) XREF VALUE(cXref) NO-ERROR.

OUTPUT STREAM sRel TO VALUE(cRel).

IF COMPILER:ERROR THEN DO:
    PUT STREAM sRel UNFORMATTED "ERRO DE COMPILACAO em " cPrograma SKIP.
    DO ix = 1 TO COMPILER:NUM-MESSAGES:
        PUT STREAM sRel UNFORMATTED "  " COMPILER:GET-FILE-NAME(ix) " (" COMPILER:GET-ROW(ix) "): "
            COMPILER:GET-MESSAGE(ix) SKIP.
    END.
    OUTPUT STREAM sRel CLOSE.
    IF NOT SESSION:BATCH-MODE THEN
        MESSAGE "Erro de compilacao. Veja" cRel VIEW-AS ALERT-BOX ERROR.
    RETURN.
END.

PUT STREAM sRel UNFORMATTED "Leituras de tabela de " cPrograma SKIP
    "fonte linha SEARCH banco.tabela indice [WHOLE-INDEX]" SKIP(1).

/* linha do XREF: <programa> <fonte> <linha> <tipo> <informacao> */
INPUT STREAM sXrf FROM VALUE(cXref).
REPEAT:
    IMPORT STREAM sXrf UNFORMATTED cLinha.
    ASSIGN iPos = INDEX(cLinha, " SEARCH ").
    IF iPos = 0 THEN NEXT.

    /* antes do SEARCH: "programa" "fonte" linha (nomes com espaco vem entre aspas) */
    ASSIGN iLeituras = iLeituras + 1
           cEsq      = TRIM(SUBSTRING(cLinha, 1, iPos - 1))
           cNumLin   = ENTRY(NUM-ENTRIES(cEsq, " "), cEsq, " ")
           cEsq      = TRIM(SUBSTRING(cEsq, 1, LENGTH(cEsq) - LENGTH(cNumLin))).
    IF SUBSTRING(cEsq, LENGTH(cEsq), 1) = '"' THEN
        ASSIGN cFonte = ENTRY(NUM-ENTRIES(cEsq, '"') - 1, cEsq, '"').
    ELSE
        ASSIGN cFonte = ENTRY(NUM-ENTRIES(cEsq, " "), cEsq, " ").
    ASSIGN cFonte = REPLACE(cFonte, "~\", "/")
           cFonte = ENTRY(NUM-ENTRIES(cFonte, "/"), cFonte, "/")
           cResto = cFonte + " " + cNumLin + " SEARCH " + TRIM(SUBSTRING(cLinha, iPos + 8)).
    /* temp-table lida inteira e normal: so conta e marca a tabela de banco */
    IF INDEX(cLinha, "WHOLE-INDEX") > 0 AND INDEX(cLinha, "TEMPTABLE") > 0 THEN
        PUT STREAM sRel UNFORMATTED " tt " cResto SKIP.
    ELSE IF INDEX(cLinha, "WHOLE-INDEX") > 0 THEN DO:
        ASSIGN iInteiras = iInteiras + 1.
        PUT STREAM sRel UNFORMATTED "*** " cResto SKIP.
    END.
    ELSE
        PUT STREAM sRel UNFORMATTED "    " cResto SKIP.
END.
INPUT STREAM sXrf CLOSE.

PUT STREAM sRel UNFORMATTED SKIP(1)
    "Total de leituras: " iLeituras "   WHOLE-INDEX em tabela de banco (***): " iInteiras
    "   (tt = temp-table lida inteira, normal)" SKIP.
OUTPUT STREAM sRel CLOSE.

IF NOT SESSION:BATCH-MODE THEN
    MESSAGE iLeituras "leitura(s)," iInteiras "com WHOLE-INDEX." SKIP cRel
        VIEW-AS ALERT-BOX INFORMATION.

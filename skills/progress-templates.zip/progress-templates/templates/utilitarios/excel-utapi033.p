/*------------------------------------------------------------------------------
  excel-utapi033.p - Exemplo isolado de planilha Excel pela utp/utapi033.p:
  duas abas montadas a partir de temp-tables, com cabecalho de parametros.
  Serve para testar a geracao no ambiente antes de levar para o relatorio.

  Rodar pelo editor, numa sessao com login do Datasul (ver login-editor.p).
  Trocar: o caminho de tt-param.arquivo e, no seu programa, as temp-tables,
  as colunas (piWorksheetColumn) e as listas de campos e de ordenacao.

  Regras da utapi033 comprovadas no fonte:
    - piWorksheetColumn so cria a coluna se ela ainda nao existe: declare
      ANTES do piNewWorksheetByTT para valer o seu titulo e a sua largura;
    - sem piWorksheetColumn, o titulo e o COLUMN-LABEL do campo da temp-table;
    - show(yes) abre a planilha; no RPW ela nunca abre;
    - no RPW, arquivo sem a pasta de spool e gravado no spool do servidor.
------------------------------------------------------------------------------*/
&SCOPED-DEFINE PROGRAMA ESTPL005
&SCOPED-DEFINE VERSAO 1.00.00.000

{utp/ut-glob.i}
{include/i-prgvrs.i {&PROGRAMA} {&VERSAO}}
{method/dbotterr.i}

/* Temp-table minimalista apenas com o necess�rio */
DEFINE TEMP-TABLE tt-param no-undo
    FIELD arquivo          AS CHAR FORMAT "x(35)".

DEFINE TEMP-TABLE tt-dados-res
    FIELD cod-emitente     AS INTEGER FORMAT ">>>>>>>>9" 
    FIELD nome-matriz      AS CHARACTER FORMAT "x(12)" 
    FIELD lim-credito      AS DECIMAL FORMAT ">>>,>>>,>>9.99" 
    FIELD dt-lim-cred      AS DATE FORMAT "99/99/9999" 
    FIELD vl-titulo        AS DECIMAL FORMAT ">>>,>>>,>>9.99" 
    FIELD vl-ped-apr       AS DECIMAL FORMAT ">>>,>>>,>>9.99" 
    FIELD vl-lim-consumido AS DECIMAL FORMAT "->>,>>>,>>9.99" 
    FIELD vl-saldo         AS DECIMAL FORMAT "->>,>>>,>>9.99" 
    FIELD vl-ped-nao-apr   AS DECIMAL FORMAT "->>,>>>,>>9.99".

DEFINE TEMP-TABLE tt-dados-det
    FIELD tipo-docto       AS CHARACTER FORMAT "X(25)"
    FIELD cod-emitente     AS INTEGER FORMAT ">>>>>>>>9"
    FIELD nome-matriz      AS CHARACTER FORMAT "x(12)"
    FIELD cod-emitente-fil AS INTEGER FORMAT ">>>>>>>>9"
    FIELD nome-abrev       AS CHARACTER FORMAT "x(12)"
    FIELD cod-estab        AS CHARACTER FORMAT "X(05)"
    FIELD cod_espec_docto  AS CHARACTER FORMAT "X(05)"
    FIELD cod_ser_docto    AS CHARACTER FORMAT "X(05)"
    FIELD cod_tit_acr      AS CHARACTER FORMAT "X(10)"
    FIELD cod_parcela      AS CHARACTER FORMAT "X(02)"
    FIELD dt-vencimento    AS DATE FORMAT "99/99/9999"
    FIELD vl-aberto        AS DECIMAL FORMAT ">>,>>>,>>>,>>9.99".
       
DEFINE TEMP-TABLE tt-param-api NO-UNDO
    FIELD descricao  AS CHARACTER
    FIELD valor      AS CHARACTER.

/* Variaveis do programa */
DEFINE VARIABLE h-utapi033              AS HANDLE    NO-UNDO.  
DEFINE VARIABLE l-erro                  AS LOGICAL   NO-UNDO.
DEFINE VARIABLE c-arquivo               AS CHARACTER NO-UNDO.

/* Include padr�o para vari�veis de controle Datasul (necess�rio para RPW) */
{include/i-rpvar.i}


/* ====================================================================
   BLOCO PRINCIPAL
   ==================================================================== */
ASSIGN c-programa      = "{&PROGRAMA}"
       c-versao        = SUBSTR("{&VERSAO}", 1, 4)
       c-revisao       = SUBSTR("{&VERSAO}", 5, -1)
       c-sistema       = "Pedidos"
       c-titulo-relat  = "Exemplo utapi033"
       l-erro          = NO.

/* Cria��o do par�metro de destino do arquivo */
CREATE tt-param.
ASSIGN tt-param.arquivo = "C:\temp\exemplo-utapi033.xml". /* ajuste o caminho */

/* 1. Inserindo 1 linha de dados na Aba Resumo */
CREATE tt-dados-res.
ASSIGN tt-dados-res.cod-emitente     = 1001
       tt-dados-res.nome-matriz      = "MATRIZ TESTE"
       tt-dados-res.lim-credito      = 150000.00
       tt-dados-res.dt-lim-cred      = TODAY
       tt-dados-res.vl-titulo        = 25000.00
       tt-dados-res.vl-ped-apr       = 5000.00
       tt-dados-res.vl-lim-consumido = 30000.00
       tt-dados-res.vl-saldo         = 120000.00
       tt-dados-res.vl-ped-nao-apr   = 1500.00.

/* 2. Inserindo 1 linha de dados na Aba Detalhe */
CREATE tt-dados-det.
ASSIGN tt-dados-det.tipo-docto       = "Duplicata"
       tt-dados-det.cod-emitente     = 1001
       tt-dados-det.nome-matriz      = "MATRIZ TESTE"
       tt-dados-det.cod-emitente-fil = 2002
       tt-dados-det.nome-abrev       = "FILIAL 01"
       tt-dados-det.cod-estab        = "101"
       tt-dados-det.cod_espec_docto  = "DP"
       tt-dados-det.cod_ser_docto    = "1"
       tt-dados-det.cod_tit_acr      = "123456"
       tt-dados-det.cod_parcela      = "01"
       tt-dados-det.dt-vencimento    = TODAY + 30
       tt-dados-det.vl-aberto        = 25000.00.

/* Invoca a gera��o do arquivo */
RUN PI-GeraXML.

RETURN "OK".


/*--- Procedures Internas --------------------------------------------*/
PROCEDURE PI-GeraXML :
    DEFINE VARIABLE iParamColumnWidth AS INTEGER EXTENT 2 NO-UNDO.

    /* Garante que estamos lendo o registro correto (evita o erro 232) */
    FIND FIRST tt-param NO-LOCK NO-ERROR.
    IF AVAIL tt-param THEN
        ASSIGN c-arquivo = tt-param.arquivo.
    ELSE
        ASSIGN c-arquivo = "C:\temp\relatorio_default.xml".
    
    RUN utp/utapi033.p PERSISTENT SET h-utapi033.

    RUN show IN h-utapi033 (TRUE).          /* abre a planilha ao terminar */
    RUN ConvertToXls IN h-utapi033 (TRUE).  /* converte o XML para Excel */

    /* === ABA 1: RESUMIDO === */
    RUN piWorksheetColumn IN h-utapi033(INPUT 1, INPUT 01, INPUT "INTE",INPUT "Cod Matriz"         , INPUT ">>>>>>>>9", INPUT 70). 
    RUN piWorksheetColumn IN h-utapi033(INPUT 1, INPUT 02, INPUT "CHAR",INPUT "Matriz"             , INPUT "x(12)", INPUT 100).
    RUN piWorksheetColumn IN h-utapi033(INPUT 1, INPUT 03, INPUT "DECI",INPUT "Limite"             , INPUT ">>>,>>>,>>9.99", INPUT 80). 
    RUN piWorksheetColumn IN h-utapi033(INPUT 1, INPUT 04, INPUT "DATE",INPUT "Dt.Atual Cr�d"      , INPUT "99/99/9999", INPUT 80). 
    RUN piWorksheetColumn IN h-utapi033(INPUT 1, INPUT 05, INPUT "DECI",INPUT "Duplicatas"         , INPUT ">>>,>>>,>>9.99", INPUT 80). 
    RUN piWorksheetColumn IN h-utapi033(INPUT 1, INPUT 06, INPUT "DECI",INPUT "Pedido Aprovado"    , INPUT ">>>,>>>,>>9.99", INPUT 100). 
    RUN piWorksheetColumn IN h-utapi033(INPUT 1, INPUT 07, INPUT "DECI",INPUT "Limite Consumido"   , INPUT "->>,>>>,>>9.99", INPUT 100). 
    RUN piWorksheetColumn IN h-utapi033(INPUT 1, INPUT 08, INPUT "DECI",INPUT "Saldo Limite"       , INPUT "->>,>>>,>>9.99", INPUT 100). 
    RUN piWorksheetColumn IN h-utapi033(INPUT 1, INPUT 09, INPUT "DECI",INPUT "Pedido n�o Aprovado", INPUT "->>,>>>,>>9.99", INPUT 120). 

    RUN piNewWorksheetbyTT IN h-utapi033(INPUT "RESUMIDO", 
                                         INPUT "Exemplo utapi033 (RESUMIDO)",
                                         INPUT BUFFER tt-dados-res:HANDLE, 
                                         "cod-emitente,nome-matriz,lim-credito,dt-lim-cred,vl-titulo,vl-ped-apr,vl-lim-consumido,vl-saldo,vl-ped-nao-apr",
                                         "cod-emitente,nome-matriz").

    /* === ABA 2: DETALHADO === */
    RUN piWorksheetColumn IN h-utapi033(INPUT 2, INPUT 01, INPUT "CHAR", INPUT "Tipo Documento"   , INPUT "X(20)",INPUT 120).                                      
    RUN piWorksheetColumn IN h-utapi033(INPUT 2, INPUT 02, INPUT "INTE", INPUT "Cod Matriz"       , INPUT ">>>>>>>>9",INPUT 60). 
    RUN piWorksheetColumn IN h-utapi033(INPUT 2, INPUT 03, INPUT "CHAR", INPUT "Matriz"           , INPUT "x(12)", INPUT 100).
    RUN piWorksheetColumn IN h-utapi033(INPUT 2, INPUT 04, INPUT "INTE", INPUT "Cod Filial"       , INPUT ">>>>>>>>9",INPUT 60). 
    RUN piWorksheetColumn IN h-utapi033(INPUT 2, INPUT 05, INPUT "CHAR", INPUT "Nome Abrev."      , INPUT "x(12)",INPUT 100).
    RUN piWorksheetColumn IN h-utapi033(INPUT 2, INPUT 06, INPUT "CHAR", INPUT "Estab"            , INPUT "X(05)",INPUT 30). 
    RUN piWorksheetColumn IN h-utapi033(INPUT 2, INPUT 07, INPUT "CHAR", INPUT "Esp"              , INPUT "X(05)",INPUT 30). 
    RUN piWorksheetColumn IN h-utapi033(INPUT 2, INPUT 08, INPUT "CHAR", INPUT "Ser"              , INPUT "X(05)",INPUT 30). 
    RUN piWorksheetColumn IN h-utapi033(INPUT 2, INPUT 09, INPUT "CHAR", INPUT "No. Documento"    , INPUT "X(10)",INPUT 80). 
    RUN piWorksheetColumn IN h-utapi033(INPUT 2, INPUT 10, INPUT "CHAR", INPUT "Pa"               , INPUT "X(02)",INPUT 30). 
    RUN piWorksheetColumn IN h-utapi033(INPUT 2, INPUT 11, INPUT "DATE", INPUT "Vencimento/Desejo", INPUT "99/99/9999", INPUT 80). 
    RUN piWorksheetColumn IN h-utapi033(INPUT 2, INPUT 12, INPUT "DECI", INPUT "Valor em Aberto"  , INPUT ">>>,>>>,>>9.99", INPUT 100). 

    RUN piNewWorksheetbyTT IN h-utapi033(INPUT "DETALHADO", 
                                         INPUT "Exemplo utapi033 (DETALHADO)",
                                         INPUT BUFFER tt-dados-det:HANDLE, 
                                         "tipo-docto,cod-emitente,nome-matriz,cod-emitente-fil,nome-abrev,cod-estab,cod_espec_docto,cod_ser_docto,cod_tit_acr,cod_parcela,dt-vencimento,vl-aberto",
                                         "cod-emitente,nome-matriz,cod-emitente-fil,nome-abrev,tipo-docto").

    /* Cabe�alho de Par�metros */
    EMPTY TEMP-TABLE tt-param-api.
    CREATE tt-param-api.
    ASSIGN tt-param-api.descricao = "Processamento:"
           tt-param-api.valor     = "Teste Unit�rio de Gera��o XML".
           
    RUN setTTParam IN h-utapi033 (INPUT TABLE tt-param-api).
    ASSIGN iParamColumnWidth[1] = 150
           iParamColumnWidth[2] = 200.
    RUN setParamColumnWidth IN h-utapi033 (INPUT iParamColumnWidth).

    RUN piProcessa IN h-utapi033 (INPUT-OUTPUT c-arquivo, 
                                  INPUT "ESTPL005",
                                  INPUT "Exemplo utapi033").

    IF RETURN-VALUE <> "OK" THEN DO:
        RUN getRowErrors IN h-utapi033 (output table RowErrors).
        FOR EACH RowErrors:
            MESSAGE RowErrors.ErrorNumber  "-"
                    RowErrors.ErrorDescription
                    VIEW-AS ALERT-BOX ERROR BUTTONS OK.
            ASSIGN l-erro = YES.
        END.
    END.

    IF VALID-HANDLE(h-utapi033) THEN
        DELETE OBJECT h-utapi033.

    RETURN "OK".
END PROCEDURE.

/*------------------------------------------------------------------------------
  importa-df.p - Carrega um .df (definicao de tabelas, campos e indices) no
  banco indicado e confere o resultado.

  Rodar numa sessao conectada ao banco de destino, sem outros usuarios usando
  as tabelas alteradas. Em producao a carga e feita pelo DBA do cliente; este
  script serve para base de teste/homologacao.

  Trocar: cArquivo (caminho do .df) e cBanco (nome logico do banco de destino).

  Antes de carregar confira o .df: tabela em AREA "Dados", indice em AREA
  "Indices" (nunca "Schema Area") e campo decimal com DECIMALS.

  Erros da carga ficam em <banco>.e na pasta de trabalho da sessao.
------------------------------------------------------------------------------*/
DEFINE VARIABLE cArquivo AS CHARACTER NO-UNDO INITIAL "C:~\temp~\meu-projeto.df".
DEFINE VARIABLE cBanco   AS CHARACTER NO-UNDO INITIAL "mgesp".
DEFINE VARIABLE cErros   AS CHARACTER NO-UNDO.
DEFINE VARIABLE cLinha   AS CHARACTER NO-UNDO.
DEFINE VARIABLE cResumo  AS CHARACTER NO-UNDO.
DEFINE VARIABLE iLinhas  AS INTEGER   NO-UNDO.

IF SESSION:PARAMETER <> "" AND NUM-ENTRIES(SESSION:PARAMETER, "|") = 2 THEN
    ASSIGN cArquivo = ENTRY(1, SESSION:PARAMETER, "|")
           cBanco   = ENTRY(2, SESSION:PARAMETER, "|").

IF SEARCH(cArquivo) = ? THEN DO:
    MESSAGE "Arquivo nao encontrado:" cArquivo VIEW-AS ALERT-BOX ERROR.
    RETURN.
END.

IF NOT CONNECTED(cBanco) THEN DO:
    MESSAGE "Banco" cBanco "nao esta conectado nesta sessao." VIEW-AS ALERT-BOX ERROR.
    RETURN.
END.

/* apaga o arquivo de erros de uma carga anterior */
ASSIGN cErros = LDBNAME(cBanco) + ".e".
OS-DELETE VALUE(cErros) NO-ERROR.

/* a carga do dicionario exige que o banco de destino seja o DICTDB */
CREATE ALIAS DICTDB FOR DATABASE VALUE(cBanco).
RUN prodict/load_df.p (INPUT cArquivo).
DELETE ALIAS DICTDB.

IF SEARCH(cErros) <> ? THEN DO:
    INPUT FROM VALUE(SEARCH(cErros)).
    REPEAT:
        IMPORT UNFORMATTED cLinha.
        ASSIGN iLinhas = iLinhas + 1.
        IF iLinhas <= 15 THEN
            ASSIGN cResumo = cResumo + cLinha + CHR(10).
    END.
    INPUT CLOSE.
    MESSAGE "Carga com ERRO. Veja" cErros SKIP(1) cResumo VIEW-AS ALERT-BOX ERROR.
END.
ELSE
    MESSAGE "DF carregado sem erros em" cBanco SKIP cArquivo VIEW-AS ALERT-BOX INFORMATION.

/* ------------------------------------------------------------------
   campos_e_indices.p
   Exporta CAMPOS e INDICES das tabelas informadas em cTabelas.
   Saida: c:\temp\campos_das_tabelas.txt   (delimitador ";")

   Layout do arquivo:
     CAMPO        ;tabela;campo ;tipo;formato;extent
     INDICE       ;tabela;indice;UNIQUE;PRIMARY;WORD;qtd-campos;campos-concatenados
     INDICE-CAMPO ;tabela;indice;seq;campo;ASC/DESC
   ------------------------------------------------------------------ */

DEFINE VARIABLE hBuffer  AS HANDLE    NO-UNDO.
DEFINE VARIABLE cTabelas AS CHARACTER NO-UNDO.
DEFINE VARIABLE cTabela  AS CHARACTER NO-UNDO.
DEFINE VARIABLE cInfo    AS CHARACTER NO-UNDO.
DEFINE VARIABLE cIndice  AS CHARACTER NO-UNDO.
DEFINE VARIABLE cUnico   AS CHARACTER NO-UNDO.
DEFINE VARIABLE cPrim    AS CHARACTER NO-UNDO.
DEFINE VARIABLE cWord    AS CHARACTER NO-UNDO.
DEFINE VARIABLE cOrdem   AS CHARACTER NO-UNDO.
DEFINE VARIABLE cCampos  AS CHARACTER NO-UNDO.
DEFINE VARIABLE iIni     AS INTEGER   NO-UNDO.
DEFINE VARIABLE iSeq     AS INTEGER   NO-UNDO.
DEFINE VARIABLE i        AS INTEGER   NO-UNDO.
DEFINE VARIABLE j        AS INTEGER   NO-UNDO.
DEFINE VARIABLE k        AS INTEGER   NO-UNDO.

/* basta acrescentar tabelas aqui, separadas por virgula */
ASSIGN cTabelas = "mapa_segment_element_edi,formul_edi".

OUTPUT TO VALUE("c:\temp\campos_das_tabelas.txt").

DO k = 1 TO NUM-ENTRIES(cTabelas):

    ASSIGN cTabela = ENTRY(k, cTabelas)
           hBuffer = ?.

    CREATE BUFFER hBuffer FOR TABLE cTabela NO-ERROR.

    IF NOT VALID-HANDLE(hBuffer) THEN DO:
        PUT UNFORMATTED "Tabela " cTabela " nao encontrada no escopo/banco." SKIP.
        NEXT.
    END.

    /* ---------------- campos ---------------- */
    DO i = 1 TO hBuffer:NUM-FIELDS:
        EXPORT DELIMITER ";"
            "CAMPO"
            cTabela
            hBuffer:BUFFER-FIELD(i):NAME
            hBuffer:BUFFER-FIELD(i):DATA-TYPE
            hBuffer:BUFFER-FIELD(i):FORMAT
            hBuffer:BUFFER-FIELD(i):EXTENT.
    END.

    /* ---------------- indices ----------------
       INDEX-INFORMATION(n) devolve:
         nome,unique(0/1),primary(0/1),word(0/1),campo1,ordem1,campo2,ordem2,...
       ordem: 0 = ascendente / 1 = descendente
       devolve ? quando o indice n nao existe -> encerra o loop        */
    DO i = 1 TO 500:

        ASSIGN cInfo = hBuffer:INDEX-INFORMATION(i).

        IF cInfo = ? OR cInfo = "" THEN LEAVE.

        ASSIGN cIndice = ENTRY(1, cInfo)
               cUnico  = ""
               cPrim   = ""
               cWord   = ""
               cCampos = ""
               iIni    = 0.

        /* onde comecam os nomes de campo: primeira entrada que nao e' flag */
        DO j = 2 TO NUM-ENTRIES(cInfo):
            IF ENTRY(j, cInfo) <> "0" AND ENTRY(j, cInfo) <> "1" THEN DO:
                ASSIGN iIni = j.
                LEAVE.
            END.
        END.

        IF iIni = 0 THEN ASSIGN iIni = NUM-ENTRIES(cInfo) + 1.

        IF iIni > 2 THEN ASSIGN cUnico = (IF ENTRY(2, cInfo) = "1" THEN "UNIQUE"  ELSE "").
        IF iIni > 3 THEN ASSIGN cPrim  = (IF ENTRY(3, cInfo) = "1" THEN "PRIMARY" ELSE "").
        IF iIni > 4 THEN ASSIGN cWord  = (IF ENTRY(4, cInfo) = "1" THEN "WORD"    ELSE "").

        /* detalhe campo a campo + monta a lista concatenada */
        ASSIGN iSeq = 0.

        DO j = iIni TO NUM-ENTRIES(cInfo) - 1 BY 2:

            ASSIGN iSeq    = iSeq + 1
                   cOrdem  = (IF ENTRY(j + 1, cInfo) = "1" THEN "DESC" ELSE "ASC")
                   cCampos = cCampos
                           + (IF cCampos = "" THEN "" ELSE " + ")
                           + ENTRY(j, cInfo)
                           + (IF cOrdem = "DESC" THEN " (DESC)" ELSE "").

            EXPORT DELIMITER ";"
                "INDICE-CAMPO"
                cTabela
                cIndice
                iSeq
                ENTRY(j, cInfo)
                cOrdem.
        END.

        /* linha resumo do indice, com todos os campos numa coluna so' */
        EXPORT DELIMITER ";"
            "INDICE"
            cTabela
            cIndice
            cUnico
            cPrim
            cWord
            iSeq
            cCampos.
    END.

    DELETE OBJECT hBuffer.
END.

OUTPUT CLOSE.

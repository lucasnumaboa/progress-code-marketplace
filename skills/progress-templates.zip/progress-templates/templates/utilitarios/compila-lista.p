/*------------------------------------------------------------------------------
  compila-lista.p - Compila uma lista de programas e grava o resultado em
  arquivo: OK, AVISO ou ERRO, com arquivo, linha e mensagem de cada ocorrencia.

  Rodar numa sessao conectada aos bancos, com os fontes no PROPATH.

  Trocar: cLista (programas separados por virgula, caminho relativo ao
  PROPATH), cDestino (pasta dos .r; em branco = so confere, nao grava .r) e
  cSaida (arquivo de resultado). Tambem aceita -param "lista=a.p,b.p".

  Ordem: compile primeiro os SmartObjects (viewer, browser, query) e depois o
  container que os usa.
------------------------------------------------------------------------------*/
DEFINE VARIABLE cLista   AS CHARACTER NO-UNDO INITIAL "esp/meu-programa.p".
DEFINE VARIABLE cDestino AS CHARACTER NO-UNDO INITIAL "".
DEFINE VARIABLE cSaida   AS CHARACTER NO-UNDO INITIAL "compila.txt".
DEFINE VARIABLE cProg    AS CHARACTER NO-UNDO.
DEFINE VARIABLE cPasta   AS CHARACTER NO-UNDO.
DEFINE VARIABLE k        AS INTEGER   NO-UNDO.
DEFINE VARIABLE i        AS INTEGER   NO-UNDO.
DEFINE VARIABLE ix       AS INTEGER   NO-UNDO.
DEFINE VARIABLE iErros   AS INTEGER   NO-UNDO.

/* a sessao do Datasul ja tem o seu -param: so aceita com o prefixo */
IF SESSION:PARAMETER BEGINS "lista=" THEN
    ASSIGN cLista = SUBSTRING(SESSION:PARAMETER, 7).

OUTPUT TO VALUE(cSaida).

DO i = 1 TO NUM-ENTRIES(cLista):
    ASSIGN cProg = TRIM(ENTRY(i, cLista)).
    IF cProg = "" THEN NEXT.

    IF SEARCH(cProg) = ? THEN DO:
        ASSIGN iErros = iErros + 1.
        PUT UNFORMATTED cProg ": ERRO" SKIP "   fonte nao encontrado no PROPATH" SKIP.
        NEXT.
    END.

    IF cDestino = "" THEN
        COMPILE VALUE(cProg) NO-ERROR.
    ELSE DO:
        /* SAVE INTO nao cria subpasta: sem ela da "Unable to create r-code file" (477) */
        ASSIGN cPasta = cDestino
               cProg  = REPLACE(cProg, "~\", "/").
        DO k = 1 TO NUM-ENTRIES(cProg, "/") - 1:
            ASSIGN cPasta = cPasta + "/" + ENTRY(k, cProg, "/").
            OS-CREATE-DIR VALUE(cPasta).
        END.
        COMPILE VALUE(cProg) SAVE INTO VALUE(cDestino) NO-ERROR.
    END.

    IF COMPILER:ERROR OR COMPILER:WARNING THEN DO:
        IF COMPILER:ERROR THEN ASSIGN iErros = iErros + 1.
        PUT UNFORMATTED cProg (IF COMPILER:ERROR THEN ": ERRO" ELSE ": AVISO") SKIP.
        DO ix = 1 TO COMPILER:NUM-MESSAGES:
            PUT UNFORMATTED "   " COMPILER:GET-FILE-NAME(ix) " (" COMPILER:GET-ROW(ix) "): "
                COMPILER:GET-MESSAGE(ix) SKIP.
        END.
    END.
    ELSE
        PUT UNFORMATTED cProg ": OK" SKIP.
END.

PUT UNFORMATTED SKIP(1) "Programas com erro: " iErros SKIP.
OUTPUT CLOSE.

IF NOT SESSION:BATCH-MODE THEN
    MESSAGE "Compilacao concluida." iErros "programa(s) com erro." SKIP cSaida
        VIEW-AS ALERT-BOX INFORMATION.

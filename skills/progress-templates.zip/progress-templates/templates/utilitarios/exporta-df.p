/*----------------------------------------------------------------------------------------------------------------------
  exporta_df.p - Exporta a definicao (.df) de todos os bancos Progress conectados na sessao.

  Rodar numa sessao ja conectada aos bancos do ambiente (Datasul aberto + Editor de Procedimentos, ou prowin com o
  .pf do ambiente):
      RUN "C:\caminho\exporta_df.p".

  Trocar: cDir (pasta de saida).

  Saida: C:\temp\df (criada se nao existir), com um <banco>.df por banco e um resumo.txt (banco
  logico, banco fisico, quantidade de tabelas e tamanho do .df). Rodar de novo substitui o .df dos bancos conectados e
  o resumo.txt; o .df de banco que nao estiver conectado na nova rodada fica la, fora do resumo.

  So le o dicionario (prodict/dump_df.p, o mesmo do Data Administration > Dump Data Definitions); nao altera nada.
----------------------------------------------------------------------------------------------------------------------*/
DEFINE VARIABLE i        AS INTEGER   NO-UNDO.
DEFINE VARIABLE cDir     AS CHARACTER NO-UNDO.
DEFINE VARIABLE cArq     AS CHARACTER NO-UNDO.
DEFINE VARIABLE cParc    AS CHARACTER NO-UNDO.
DEFINE VARIABLE k        AS INTEGER   NO-UNDO.
DEFINE VARIABLE iTabelas AS INTEGER   NO-UNDO.
DEFINE VARIABLE iBancos  AS INTEGER   NO-UNDO.
DEFINE VARIABLE hBuf     AS HANDLE    NO-UNDO.
DEFINE VARIABLE hQry     AS HANDLE    NO-UNDO.

DEFINE STREAM sRes.

IF SEARCH("prodict/dump_df.r") = ? AND SEARCH("prodict/dump_df.p") = ? THEN DO:
    MESSAGE "prodict/dump_df nao esta no PROPATH desta sessao." SKIP
            "Rode pelo Editor de Procedimentos do Progress (ou inclua o DLC\gui no PROPATH)."
            VIEW-AS ALERT-BOX ERROR.
    RETURN.
END.

/* pasta de saida fixa. Nao usar SESSION:PARAMETER: a sessao do Datasul ja tem o seu -param
   (algo como "<hash>,<servidor>,<porta>"), que uma versao anterior tomava como pasta */
cDir = "C:~\temp~\df".

/* OS-CREATE-DIR nao cria as pastas de cima: cria nivel por nivel */
cParc = ENTRY(1, cDir, "~\").
DO k = 2 TO NUM-ENTRIES(cDir, "~\"):
    cParc = cParc + "~\" + ENTRY(k, cDir, "~\").
    OS-CREATE-DIR VALUE(cParc).
END.
FILE-INFO:FILE-NAME = cDir.
IF FILE-INFO:FULL-PATHNAME = ? OR INDEX(FILE-INFO:FILE-TYPE, "D") = 0 THEN DO:
    MESSAGE "Nao foi possivel criar a pasta" cDir VIEW-AS ALERT-BOX ERROR.
    RETURN.
END.

OUTPUT STREAM sRes TO VALUE(cDir + "~\resumo.txt").
PUT STREAM sRes UNFORMATTED "exporta_df.p em " STRING(TODAY, "99/99/9999") " " STRING(TIME, "HH:MM:SS")
    " - Progress " PROVERSION SKIP
    "banco_logico;banco_fisico;tabelas;bytes_df;arquivo" SKIP.

DO i = 1 TO NUM-DBS:
    IF DBTYPE(i) <> "PROGRESS" THEN NEXT.

    /* tabelas de usuario, so para conferencia com o .df (sem o catalogo SQL: dono SYSPROGRESS, tipo V) */
    iTabelas = 0.
    CREATE BUFFER hBuf FOR TABLE LDBNAME(i) + "._File".
    CREATE QUERY hQry.
    hQry:SET-BUFFERS(hBuf).
    hQry:QUERY-PREPARE("FOR EACH " + LDBNAME(i) + "._File NO-LOCK WHERE " + LDBNAME(i) + "._File._File-Number > 0 AND "
                       + LDBNAME(i) + "._File._Tbl-Type = 'T'").
    hQry:QUERY-OPEN().
    REPEAT:
        hQry:GET-NEXT().
        IF hQry:QUERY-OFF-END THEN LEAVE.
        iTabelas = iTabelas + 1.
    END.
    hQry:QUERY-CLOSE().
    DELETE OBJECT hQry.
    DELETE OBJECT hBuf.

    cArq = cDir + "~\" + LDBNAME(i) + ".df".
    CREATE ALIAS DICTDB FOR DATABASE VALUE(LDBNAME(i)).
    RUN prodict/dump_df.p (INPUT "ALL", INPUT cArq, INPUT "").
    DELETE ALIAS DICTDB.

    FILE-INFO:FILE-NAME = cArq.
    PUT STREAM sRes UNFORMATTED LDBNAME(i) ";" PDBNAME(i) ";" iTabelas ";"
        (IF FILE-INFO:FULL-PATHNAME = ? THEN "NAO GERADO" ELSE STRING(FILE-INFO:FILE-SIZE)) ";" cArq SKIP.
    iBancos = iBancos + 1.
END.

OUTPUT STREAM sRes CLOSE.

MESSAGE iBancos "banco(s) exportado(s) para" SKIP cDir VIEW-AS ALERT-BOX INFORMATION.

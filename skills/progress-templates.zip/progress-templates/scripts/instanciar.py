# -*- coding: utf-8 -*-
"""Copia um modelo de programa Progress para uma pasta, trocando nomes.

Trabalha em bytes: a codificacao dos fontes (CP850) nao e alterada.

Uso:
  python instanciar.py --listar
  python instanciar.py <modelo> <destino> --de ANTIGO=NOVO [--de ANTIGO=NOVO ...]
                       [--sobrescrever] [--simular]

Exemplo:
  python instanciar.py cadastro-simples C:/projeto/fonte \
      --de estpl001=escd0901 --de es-tpl-ocor=es-motivo-bloqueio

A troca vale para o conteudo e para o nome dos arquivos, sem diferenciar
maiusculas de minusculas; onde o original estava todo em maiusculas, o novo
nome tambem sai em maiusculas. Nomes de campo NAO sao trocados aqui: ajuste
os campos a mao seguindo o guia do modelo (references/<modelo>.md).
"""
import argparse
import io
import json
import os
import re
import sys

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

RAIZ = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "templates")
MANIFESTO = os.path.join(RAIZ, "manifesto.json")


def carrega():
    with open(MANIFESTO, encoding="utf-8") as f:
        return json.load(f)


def troca(texto, pares):
    """troca cada ANTIGO por NOVO, sem diferenciar caixa"""
    for de, para in pares:
        def sub(m, para=para):
            achado = m.group(0)
            return para.upper() if achado.isupper() and any(c.isalpha() for c in achado) else para
        texto = re.sub(re.escape(de), sub, texto, flags=re.I)
    return texto


def listar(man):
    for nome, d in man.items():
        print(f"{nome}")
        print(f"   {d['descricao']}")
        if d["programa"]:
            print(f"   programa do modelo: {d['programa']}")
        if d["tabelas"]:
            print(f"   tabelas do modelo : {', '.join(d['tabelas'])}")
        pasta = os.path.join(RAIZ, nome)
        for p, _, fs in os.walk(pasta):
            for f in sorted(fs):
                print("     " + os.path.relpath(os.path.join(p, f), pasta).replace(os.sep, "/"))
        print(f"   guia: {d['guia']}")


def main():
    ap = argparse.ArgumentParser(description="Instancia um modelo de programa Progress.")
    ap.add_argument("modelo", nargs="?")
    ap.add_argument("destino", nargs="?")
    ap.add_argument("--de", action="append", default=[], metavar="ANTIGO=NOVO")
    ap.add_argument("--listar", action="store_true")
    ap.add_argument("--sobrescrever", action="store_true")
    ap.add_argument("--simular", action="store_true", help="mostra o que faria, sem gravar")
    a = ap.parse_args()

    man = carrega()
    if a.listar or not a.modelo:
        listar(man)
        return 0
    if a.modelo not in man:
        print(f"Modelo desconhecido: {a.modelo}. Use --listar.")
        return 2
    if not a.destino:
        print("Informe a pasta de destino.")
        return 2

    pares = []
    for item in a.de:
        if "=" not in item or not item.split("=", 1)[0] or not item.split("=", 1)[1]:
            print(f"--de invalido: {item} (use ANTIGO=NOVO)")
            return 2
        pares.append(tuple(item.split("=", 1)))
    # o mais comprido primeiro: evita trocar um pedaco de um nome maior
    pares.sort(key=lambda p: -len(p[0]))

    d = man[a.modelo]
    trocados = {p[0].lower() for p in pares}
    if d["programa"] and d["programa"].lower() not in trocados:
        print(f"AVISO: o nome do programa do modelo ({d['programa']}) nao esta em --de: "
              "os arquivos sairao com o nome do modelo.")
    for t in d["tabelas"]:
        if t.lower() not in trocados:
            print(f"AVISO: a tabela do modelo ({t}) nao esta em --de: o fonte continuara apontando para ela.")

    origem = os.path.join(RAIZ, a.modelo)
    plano = []
    for p, _, fs in os.walk(origem):
        for f in sorted(fs):
            rel = os.path.relpath(os.path.join(p, f), origem)
            plano.append((os.path.join(p, f), os.path.join(a.destino, troca(rel, pares))))

    existentes = [dst for _, dst in plano if os.path.exists(dst)]
    if existentes and not a.sobrescrever:
        print("Ja existe no destino (use --sobrescrever se for isso mesmo):")
        for e in existentes:
            print("   " + e)
        return 1

    for src, dst in plano:
        dados = open(src, "rb").read().decode("latin-1")
        novo = troca(dados, pares)
        ocorr = sum(len(re.findall(re.escape(de), dados, flags=re.I)) for de, _ in pares)
        print(f"{'(simulado) ' if a.simular else ''}{dst}  [{ocorr} troca(s)]")
        if a.simular:
            continue
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        with open(dst, "wb") as f:
            f.write(novo.encode("latin-1"))

    print()
    print(f"Proximo passo: ajuste campos, titulos e regras seguindo {d['guia']}.")
    if d["compilar"]:
        print("Ordem de compilacao: " + ", ".join(troca(c, pares) for c in d["compilar"]))
    return 0


if __name__ == "__main__":
    sys.exit(main())

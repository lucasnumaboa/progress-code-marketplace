# -*- coding: utf-8 -*-
"""Converte fontes Progress entre CP850 (codificacao dos fontes Datasul) e UTF-8.

As ferramentas de edicao de texto recusam arquivo que nao e UTF-8. Fluxo:
  1. python cp850.py para-utf8  <arquivo ou pasta>     (copia de trabalho)
  2. edite normalmente
  3. python cp850.py para-cp850 <arquivo ou pasta>     (antes de compilar/entregar)
  python cp850.py conferir <arquivo ou pasta>          (so informa a codificacao)

Converte no proprio arquivo, mantendo o fim de linha. Arquivo que ja esta na
codificacao pedida, ou so com ASCII, nao e tocado. Extensoes tratadas: .p .w
.i .cls .df. Nao converte para CP850 um texto com caractere que o CP850 nao
tem (ex.: travessao, aspas curvas): avisa e deixa o arquivo como esta.
"""
import io
import os
import sys

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
EXT = (".p", ".w", ".i", ".cls", ".df")


def arquivos(alvo):
    if os.path.isfile(alvo):
        yield alvo
        return
    for p, _, fs in os.walk(alvo):
        for f in sorted(fs):
            if os.path.splitext(f)[1].lower() in EXT:
                yield os.path.join(p, f)


def detecta(b):
    if all(x < 128 for x in b):
        return "ascii"
    try:
        b.decode("utf-8")
        return "utf-8"
    except UnicodeDecodeError:
        return "cp850"


def main():
    if len(sys.argv) != 3 or sys.argv[1] not in ("para-utf8", "para-cp850", "conferir"):
        print(__doc__)
        return 2
    modo, alvo = sys.argv[1], sys.argv[2]
    if not os.path.exists(alvo):
        print("Nao encontrado: " + alvo)
        return 2
    erro = 0
    for arq in arquivos(alvo):
        b = open(arq, "rb").read()
        cod = detecta(b)
        if modo == "conferir":
            print(f"{cod:6} {arq}")
            continue
        if cod == "ascii" or (modo == "para-utf8" and cod == "utf-8") or (modo == "para-cp850" and cod == "cp850"):
            print(f"sem mudanca ({cod}) {arq}")
            continue
        try:
            novo = b.decode("cp850").encode("utf-8") if modo == "para-utf8" else b.decode("utf-8").encode("cp850")
        except UnicodeError as e:
            erro = 1
            print(f"NAO CONVERTIDO {arq}: {e}")
            continue
        open(arq, "wb").write(novo)
        print(f"convertido para {'utf-8' if modo == 'para-utf8' else 'cp850'}: {arq}")
    return erro


if __name__ == "__main__":
    sys.exit(main())

# Utilitários

Scripts em `templates/utilitarios/`. Rodam pelo Editor de Procedimentos, numa
sessão conectada aos bancos do ambiente. Cada um tem no cabeçalho o que trocar.

| Script | Para quê | Altera algo? |
|---|---|---|
| `login-editor.p` | Fazer o login do Datasul dentro do editor (usuário, empresa e conexões do btb962aa), para testar programa como usuário logado. | Não |
| `exporta-campos-indices.p` | Listar campos (tipo, formato, extent) e índices (único, primário, campos na ordem) de uma lista de tabelas. | Não |
| `exporta-df.p` | Gerar o .df de todos os bancos conectados, com um resumo. | Não |
| `importa-df.p` | Carregar um .df num banco e mostrar os erros. | **Sim, o dicionário** |
| `xref-performance.p` | Compilar um programa com XREF e listar como cada leitura usa índice. | Não |
| `compila-lista.p` | Compilar uma lista de programas e gravar OK/AVISO/ERRO por programa. | Grava `.r` só se `cDestino` for informado |
| `excel-utapi033.p` | Exemplo isolado de planilha de duas abas pela utapi033. | Não |

## login-editor.p

Chama `btb/btapi910za.p (usuário, senha, OUTPUT TABLE tt-erros)`. O usuário vai
no formato `domínio/usuário` quando o ambiente usa domínio. Preencha, rode e
apague a senha: o arquivo não deve ficar salvo com ela.

## exporta-campos-indices.p

Troque `cTabelas` (lista separada por vírgula). Saída:
`c:\temp\campos_das_tabelas.txt`, separado por `;`, com três tipos de linha:

```
"CAMPO";tabela;campo;tipo;formato;extent
"INDICE-CAMPO";tabela;índice;seq;campo;ASC/DESC
"INDICE";tabela;índice;UNIQUE;PRIMARY;WORD;qtd-campos;campos concatenados
```

Tabela que não existe na sessão sai como "Tabela X nao encontrada". Use antes
de escrever `WHERE`: a linha `INDICE` mostra os campos na ordem do índice.

## exporta-df.p

Troque `cDir` (padrão `C:\temp\df`). Gera `<banco>.df` por banco conectado e
`resumo.txt` (banco lógico, físico, quantidade de tabelas, tamanho do .df).
Usa `prodict/dump_df.p`, o mesmo do Data Administration. Não usa
`SESSION:PARAMETER`, porque a sessão do Datasul já tem o seu.

## importa-df.p

Troque `cArquivo` e `cBanco` (ou `-param "arquivo.df|banco"`). Antes de
carregar, confira o .df ([df.md](df.md)). Depois da carga o script procura
`<banco>.e` na pasta de trabalho: se existir, a carga teve erro, e ele mostra
as primeiras linhas (no teste, o erro desfez a carga inteira: "All the changes
were backed out"). Carga sem erro não garante .df certo: área errada passa
calada. Em produção a carga é do DBA do cliente.

## xref-performance.p

Troque `cPrograma` e `cSaida` (ou `-param "programa|pasta"`). Gera o XREF
completo e `<programa>.indices.txt`:

```
*** fonte linha SEARCH banco.tabela índice WHOLE-INDEX    leitura da tabela inteira
    fonte linha SEARCH banco.tabela índice                leitura com faixa no índice
 tt fonte linha SEARCH temp-table ...                     temp-table lida inteira (normal)
```

Linha `***` em tabela grande é o primeiro suspeito de lentidão. Nem toda é
erro: `FIND FIRST` em tabela de um registro só (ex.: `param-global`) também
aparece assim.

## compila-lista.p

Troque `cLista`, `cDestino` e `cSaida`, ou passe `-param "lista=a.p,b.p"`.
Compile os SmartObjects antes do container. Com `cDestino` informado o script
cria as subpastas dos `.r`: `SAVE INTO` não cria, e sem elas a compilação
termina com "Unable to create r-code file (477)" mesmo com o fonte correto.

## excel-utapi033.p

Monta duas temp-tables com uma linha cada e gera a planilha. Serve para
confirmar, no ambiente do cliente, que a utapi033 e o Excel/LibreOffice da
máquina estão funcionando antes de levar a lógica para o relatório. As regras
da API estão em [relatorio.md](relatorio.md).

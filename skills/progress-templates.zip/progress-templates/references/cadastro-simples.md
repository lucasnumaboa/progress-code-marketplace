# Modelo: cadastro simples (w-cadsim)

Seis fontes em `templates/cadastro-simples/esp/`. O programa cadastrado no
Datasul é o container; os outros são carregados por ele.

| Arquivo | Tipo | Papel |
|---|---|---|
| `estpl001.w` | Container `w-cadsim` | Janela, menu, painéis (`p-navega`, `p-cadsim`, `p-exihel`) e ligação entre os objetos. |
| `estpl001-q01.w` | SmartQuery (`c-query.i`) | Lê a tabela e entrega o registro corrente. Recebe `ProgPesquisa` e `ProgVaPara`. |
| `estpl001-v01.w` | SmartViewer (`c-viewer.i`) | Campos da tela e validação (`Pi-validate`). |
| `estpl001-g01.w` | Vá-para (`d-vapara.i`) | Diálogo que posiciona pelo código. |
| `estpl001-z01.w` | Pesquisa (`w-pesqui.i`) | Janela de zoom, com folder. |
| `estpl001-b01.w` | SmartBrowser (`c-brwzoo.i`) | Browse da pesquisa; devolve o registro escolhido. |

Tabela de exemplo: `es-tpl-ocor` (`codigo`, `descricao`, `tipo`, `ativo`), chave
única `codigo`.

## O que trocar

**Container (`estpl001.w`)**
- `TITLE = "Manutenção <Insira o complemento>"`: o texto depois de "Manutenção".
- `adm-create-objects`: os caminhos `esp/estpl001-*.w` (o `instanciar.py` troca
  o nome; troque a pasta se não for `esp`). Aqui também estão a posição e o
  tamanho de cada objeto (`set-position`, `set-size`) e os `add-link`.
- `i-license-manager.i`: sigla do módulo.

**Viewer (`estpl001-v01.w`)** — é onde está a maior parte do trabalho.
- `DEFINE FRAME f-main`: um item por campo, com posição e tipo de widget. O
  modelo mostra os quatro mais comuns: `FILL-IN` (codigo), `EDITOR`
  (descricao), `RADIO-SET` (tipo) e `TOGGLE-BOX` (ativo).
- `&Scoped-define ADM-CREATE-FIELDS`: os campos da chave. Ficam habilitados só
  na inclusão.
- As listas `ENABLED-FIELDS`, `DISPLAYED-FIELDS` e as demais `&Scoped-define`
  do início: todo campo do frame tem de estar nelas. Campo fora da lista não é
  exibido nem gravado.
- `Pi-validate`: regras antes de gravar. Só validação: nesse ponto o registro
  ainda não foi criado, então nada de `ASSIGN`. O modelo barra chave repetida
  na inclusão (`adm-new-record`) com `{include/i-vldprg.i}` seguido de
  `ut-msgs.p` 17006 e `RETURN 'ADM-ERROR':U`, que cancela a gravação. O
  `i-vldprg.i` vem sempre antes do `ut-msgs.p`.
- `rt-key` e `rt-mold`: os retângulos da chave e do corpo. Ajuste o tamanho ao
  mexer nos campos.

**Query (`estpl001-q01.w`)**: tabela e, se precisar, o `WHERE` e a ordenação.

**Browser (`estpl001-b01.w`)**: colunas do browse (`FIELDS-IN-QUERY-br-table` e
a lista de campos do browse) e `pi-retorna-valor`, que devolve o campo
escolhido para quem chamou o zoom: tem um `WHEN "<campo>"` por campo, e campo
novo precisa do seu. `adm-open-query-cases` abre a query; no modelo não há
filtro, é ali que ele entra.

**Vá-para (`estpl001-g01.w`)**: campo(s) da chave no frame e o `FIND` do
gatilho de confirmação.

## Ao mudar de tabela

Os fontes de AppBuilder repetem o nome da tabela e dos campos em vários blocos
gerados (`&Scoped-define`, `_QUERY-BLOCK`, `_FLD-NAME`, `send-records`,
`adm-row-available`). Depois da troca, procure o nome do campo antigo em todos
os arquivos e só pare quando não sobrar nenhum:

```bash
grep -n "descricao\|tipo\|ativo" esp/<programa>*.w
```

Compile na ordem: query, viewer, browser, vá-para, pesquisa e, por último, o
container.

## Usar o zoom em outra tela

O par `-z01.w` + `-b01.w` serve de zoom para qualquer tela que tenha o campo
`codigo` dessa tabela. Como a tela chamadora dispara o zoom (`zoomvar.i`,
`method/zoomfields.i`) não foi exercitado neste modelo: copie de um programa
do cliente que já faça isso.

# O que foi testado e o que não foi

Montagem e testes em 20/11/2026. Leia antes de dizer a alguém que um modelo
"funciona": compilar não é rodar na tela.

## Ambiente do teste

- OpenEdge 12.8, sessão `prowin -b`, `-cpinternal ibm850 -cpstream ibm850`.
- PROPATH com o DDK e o framework (`ddk`, `fnd`) de um sandbox Datasul local.
- Banco descartável com as áreas `Dados` e `Indices`, carregado com
  `templates/df/es-tpl.df`; bancos `emsfnd`, `mgcad`, `movdis`, `movmov` e
  `mgdis` do sandbox conectados somente leitura.
- O sandbox com tela (execução interativa e print) não pôde ser usado: as
  portas dos brokers estavam ocupadas por outro sistema. Por isso nenhuma tela
  foi aberta.

## Comprovado

| Modelo | O que foi executado | Resultado |
|---|---|---|
| Todos | Compilação dos 30 fontes (`.w` e `.p`), telas com `i-license-manager.i` ativo | Todos OK |
| DF | Carga do `es-tpl.df`; conferência das áreas no dicionário | Tabelas em `Dados`, índices em `Indices` |
| DF | Carga de um .df sem a linha `AREA` | Carregou sem erro e a tabela e o índice foram para `Schema Area` |
| DF | Campo decimal sem `DECIMALS` | Valor 1234,56 gravado como 1235; com `DECIMALS 2`, gravado certo |
| Relatório | `estpl003rp.p` executado com 3 registros, destino Arquivo | Listagem com cabeçalho, rodapé, totais e página de parâmetros; registro sem data tratado |
| Relatório (Excel) | Chamadas à utapi033 exercitadas com um dublê de mesma assinatura, copiada do fonte real | Sequência e parâmetros aceitos; dados chegaram na ordem das colunas |
| Relatório (índice) | XREF do `rp.p` | Leitura principal usa o índice primário, sem `WHOLE-INDEX` |
| API REST | BO executado em 11 casos: incluir, incluir com corpo em `payload` e tipos como texto, alterar, duas validações, listar, consultar por ativo, por tipo e texto, excluir inexistente, excluir, listar | Todos com o resultado esperado |
| API REST | Handler compilado com o stub do framework REST do sandbox | OK |
| Carga | Execução em simulação e em gravação, com um CSV válido e um com 4 linhas inválidas | Válido gravado e movido para `processados`; inválido listado linha a linha e devolvido; nada gravado dele |
| UPC | `estpl-upc.p` chamado com evento não tratado, tabela diferente e `VALIDATE` de registro válido | `"OK"` nos três |
| UPC de log | Chamada com evento `INITIALIZE` | Linha gravada no arquivo de log |
| Utilitários | `exporta-campos-indices`, `exporta-df`, `importa-df` (arquivo bom e arquivo com erro), `xref-performance`, `compila-lista` (com e sem pasta de destino) | Saídas conferidas |
| Scripts da skill | `instanciar.py`: os dois cadastros instanciados com outro nome compilaram (16 fontes). `cp850.py`: ida e volta devolve arquivo idêntico | OK |
| SmartObjects | Viewer, query, browser de zoom, container w-cadsim e janela de pesquisa carregados em modo persistente | Carregaram |

## Não testado

| Item | Por quê | Como fechar |
|---|---|---|
| Abrir qualquer tela (`.w`) e navegar | Sandbox com tela indisponível no dia | Rodar no sandbox ou no ambiente do cliente e tirar print. Só o layout também pode ser conferido pela skill `appbuilder-web`, depois que o fonte estiver no catálogo do ProgressAdmin (ela renderiza arquivo do servidor, não aceita envio) |
| Layout da página de parâmetros do relatório (dois toggles acrescentados) | Idem. As outras telas vieram de programas em produção, só com nomes trocados | Abrir a tela |
| Geração real da planilha Excel | A utapi033 real não roda no ambiente local: faltam as classes `office.*` | Rodar `utilitarios/excel-utapi033.p` no ambiente do cliente |
| Relatório pelo RPW e destinos Impressora e Terminal | Só o destino Arquivo, on-line, foi executado | Agendar no RPW do cliente |
| Chamada HTTP da API pelo PASOE | Só o BO foi executado; o handler só compilou | Publicar e chamar a rota |
| Caminho `"NOK"` da UPC (mensagem na tela) e `pi-initialize` com frame real | Exige a tela do programa padrão | Cadastrar a UPC em ambiente de teste |
| Container pai e filho, browser dos filhos e pesquisa do pai em modo persistente | Ao carregar, o DDK pediu o login do Datasul (sessão de teste sem usuário logado) | Rodar no sandbox, com login |
| Tela do relatório em modo persistente | A sessão em lote caiu ao montar a janela | Rodar no sandbox |
| Vá-para e janela inclui/modifica em modo persistente | Exigem parâmetros de quem chama | Rodar pela tela |
| `login-editor.p` | Precisa de usuário e senha reais | Rodar no ambiente |
| Carga com execução simultânea e carga pelo RPW | Só uma execução on-line por vez foi feita | Testar no ambiente |

## Origem dos modelos

Os dois cadastros e a tela do relatório saíram de programas de um projeto em
produção, com troca de nome de programa e de tabela e limpeza de comentários.
O `rp.p` do relatório, a API, a carga, a UPC e parte dos utilitários foram
escritos para o modelo, seguindo a estrutura dos programas dos projetos.

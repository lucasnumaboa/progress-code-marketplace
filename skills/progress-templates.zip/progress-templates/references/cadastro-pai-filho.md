# Modelo: cadastro pai e filho (w-paifil)

Dez fontes em `templates/cadastro-pai-filho/esp/`. O exemplo é "séries por
estabelecimento": o pai é a tabela padrão `estabelec`, só navegada; o filho é
`es-tpl-serie`, mantido pela tela.

| Arquivo | Tipo | Papel |
|---|---|---|
| `estpl002.w` | Container `w-paifil` | Janela, menu, `p-navega`, `p-exihel`, viewer do pai, folder e browser dos filhos. |
| `estpl002q.w` | SmartQuery do pai | Lê `estabelec`. Recebe `ProgPesquisa` e `ProgVaPara`. |
| `estpl002v.w` | SmartViewer do pai | Mostra a chave e a descrição do pai (somente leitura). |
| `estpl002bf.w` | Browser dos filhos (`c-brows3.i`, tipo `BrowserCadastro2`) | Lista os filhos do pai corrente (`FOR EACH es-tpl-serie OF estabelec`) e tem os botões incluir, modificar, eliminar. Recebe `ProgIncMod`. |
| `estpl002f.w` | Janela inclui/modifica (`w-incsim.i`, tipo `w-incmod`) | Abre para incluir ou alterar um filho. Usa `okfil.i`, `salvafil.i`, `cancefil.i`. |
| `estpl002qf.w` | SmartQuery do filho | Usada pela janela inclui/modifica. |
| `estpl002vf.w` | SmartViewer do filho | Campos do filho e as validações. |
| `estpl002g.w` | Vá-para do pai (`d-vapara.i`) | |
| `estpl002p.w` | Pesquisa do pai (`w-pesqui.i`) | |
| `estpl002bp.w` | Browser da pesquisa (`c-brwzoo.i`) | |

## Como as peças se ligam

No container, `adm-create-objects` cria os objetos e faz os links:

```
query do pai --Record--> viewer do pai
query do pai --Record--> browser dos filhos      (o filho segue o pai)
p-navega --Navigation/State--> query do pai
p-exihel --State--> container e query do pai
folder --Page--> container
```

O browser dos filhos recebe no `init-object` o atributo
`ProgIncMod = esp/estpl002f.w`: é a janela que ele abre nos botões incluir e
modificar. A query do pai recebe `ProgPesquisa` e `ProgVaPara`.

O `OF estabelec` do browser funciona porque `es-tpl-serie` tem o campo
`cod-estabel` com o mesmo nome da chave do pai. Se a ligação não for por nome
igual, troque o `OF` por `WHERE filho.campo = pai.campo`.

## O que trocar

**Tabela do pai.** Se o pai for outra tabela, troque `estabelec` e
`cod-estabel` na query do pai, no viewer do pai, no browser dos filhos (a
cláusula `OF`), no vá-para e na pesquisa. O `instanciar.py` não troca
`estabelec` sozinho; passe `--de estabelec=<tabela-pai>` se quiser, e confira
os campos depois.

**Viewer do filho (`estpl002vf.w`)** concentra as regras:
- `DEFINE FRAME f-main` e as listas `&Scoped-define`: campos do filho.
- `ADM-CREATE-FIELDS`: chave do filho (no modelo, `cod-serie`).
- Gatilho `LEAVE` do campo-chave e `Pi-validate`: o modelo valida que a série
  existe na tabela padrão `serie` e que não está repetida para o
  estabelecimento. São dois exemplos de regra: existência em cadastro mestre e
  duplicidade. Troque pelas regras do seu caso, mantendo o tratamento de erro
  de banco separado do "não encontrado".
- `pi-atualiza-parent`: recebe o `ROWID` do pai (guardado em `v-row-parent`).
- `local-create-record`: depois do `dispatch 'create-record'`, acha o pai por
  `v-row-parent` e grava a chave dele no filho. Sem isso o filho é incluído
  sem pai. Se não achar o pai, devolve `'ADM-ERROR'`.

**Browser dos filhos (`estpl002bf.w`)**: colunas e a query (`OF`/`WHERE`).

**Container**: título, rótulo da aba (`FOLDER-LABELS`), caminhos dos objetos,
sigla do módulo no `i-license-manager.i`.

## Cuidados que vieram do programa de origem

Estão comentados no fonte com "Nota:".

- Chamar procedure em handle de SmartObject só depois de `VALID-HANDLE`.
- `i-vldprg.i` só dentro de procedure que já inclui `i-vldfrm.i`.
- Erro de banco numa consulta de validação não pode virar mensagem de "não
  encontrado": teste `ERROR-STATUS:ERROR` com código diferente de 138 antes.
- Pesquisa com faixa invertida devolvia browse vazio sem aviso: o browser da
  pesquisa trata isso.

Compile na ordem: queries, viewers, janela inclui/modifica, browsers, vá-para,
pesquisa e, por último, o container.

## Variações não cobertas

- Pai mantido na mesma tela (painel `p-cadpai`, template `w-paiamb`): veja um
  programa padrão que use, como `men002aa.w` ou `sec000aa.w`.
- Mais de uma aba de filhos: acrescente rótulos em `FOLDER-LABELS` e um bloco
  `WHEN n` em `adm-create-objects` por aba. O programa padrão `cd0705.w` usa
  `w-paifil`.

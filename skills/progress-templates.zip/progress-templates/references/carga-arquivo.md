# Modelo: carga de arquivo CSV (on-line ou RPW)

Arquivo: `templates/carga-arquivo/esp/estpl004rp.p`. Tabela de exemplo:
`es-tpl-ocor`.

É um programa no formato `rp.p` do DDK: recebe a `tt-param` por `RAW`, usa os
includes de relatório para abrir a saída e lista o resultado da carga. Assim a
mesma rotina serve para a tela on-line e para o agendamento no RPW.

## O que o modelo faz

1. Descobre quem pediu a execução. No RPW o usuário da conexão é o do agente,
   não o de quem agendou: o modelo busca em `ped_exec` pelo
   `i-num-ped-exec-rpw`.
2. Lista os `.csv` da pasta informada em `tt-param.c-pasta`.
3. Para cada arquivo:
   - renomeia para `<nome>.emproc`. Só uma execução consegue renomear, então
     duas execuções simultâneas não importam o mesmo arquivo;
   - lê e valida todas as linhas (`pi-le-linha`), guardando em `tt-linha`;
   - se alguma linha é inválida, não grava nada, devolve o arquivo com o nome
     original e lista cada erro com o número da linha;
   - se tudo é válido, grava numa transação só (`pi-grava`) e move o arquivo
     para `processados/<nome>.<data>-<hora>`.
4. Com `tt-param.l-simula`, valida e lista sem gravar.
5. Imprime o resultado: arquivo, linha, situação (OK, ERRO, AVISO, SIMULADO) e
   mensagem.

Layout do CSV de exemplo: separador `;`, primeira linha de cabeçalho,
`codigo;descricao;tipo;ativo(S/N)`.

## O que trocar

| Onde | O que fazer |
|---|---|
| `tt-param` | Campos depois dos sete fixos. Igual à tela que chamar. |
| `tt-linha` | Um campo por coluna do arquivo. |
| `pi-le-linha` | Número de colunas, conversão e validação de cada uma. Cada erro vira uma linha no log e `RETURN "NOK"`. |
| `pi-grava` | Tabela de destino e a regra de incluir ou alterar. |
| `CONVERT SOURCE "iso8859-1"` | Codificação do arquivo. CSV salvo pelo Excel vem em ISO-8859-1/Windows-1252; se o arquivo for UTF-8, troque. |
| Título e nome do programa | `c-programa`, `c-titulo-relat`. |

## Decisões embutidas (mude se a regra do cliente for outra)

- **Tudo ou nada por arquivo.** Para gravar as linhas boas e rejeitar as
  ruins, tire o teste de `l-erro` antes do `pi-grava` e trate linha a linha.
- **Registro existente é alterado.** Para rejeitar duplicado, troque o
  `IF NOT AVAIL ... CREATE` por erro.
- **Registro travado desfaz o arquivo** (`NO-WAIT` + `LOCKED`), em vez de
  esperar.

## Tela

O modelo não traz a tela. Ela é um w-relat: parta de
`relatorio/esp/estpl003.w`, troque a página de seleção por um campo de pasta e
um toggle de simulação, ajuste a `tt-param` e aponte o `i-rprun.i` para o
`rp.p` da carga.

## Cuidados

- No RPW não há tela: nada de `MESSAGE ... VIEW-AS ALERT-BOX`.
- A pasta precisa existir e ser gravável na máquina que executa (o servidor de
  RPW, não a estação do usuário).
- Arquivo `.emproc` esquecido numa pasta indica execução que caiu no meio.
  O modelo não o retoma sozinho: renomeie de volta para `.csv`.

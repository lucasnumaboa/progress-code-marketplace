# Modelo: API REST + BO (backend de PO-UI)

Arquivos em `templates/api-rest/esp/api/v1/`:

| Arquivo | Papel |
|---|---|
| `estplOcorrencia.p` | Handler. Declara as rotas, sobe o BO, monta a resposta e trata erro. Não referencia tabela. |
| `estplOcorrenciaRules.p` | BO. Toda leitura e gravação. Roda `PERSISTENT`. |

Tabela de exemplo: `es-tpl-ocor`.

## Por que separar handler e BO

O handler depende do framework REST da TOTVS (`utp/ut-api.i`,
`com.totvs.framework.api.*`), que só existe no PASOE do cliente ou num sandbox
com o stub habilitado. O BO não depende de nada disso: dá para testar a regra
inteira chamando as procedures dele direto, com `JsonObject` de entrada, num
editor comum. Foi assim que o modelo foi testado.

## Handler

```
{utp/ut-api.i}
{utp/ut-api-utils.i}
{utp/ut-api-action.i <procedure> <VERBO> <caminho> }     uma linha por rota
{utp/ut-api-notfound.i}
```

- Caminho com `~*` no fim aceita o que vier depois (`/consulta~*`).
- Cada rota é uma procedure com `INPUT oInput JsonObject` e
  `OUTPUT oOutput JsonObject`: assinatura fixa do framework.
- A resposta do modelo é `{ success, message, data }`, embrulhada por
  `JsonApiResponseBuilder:ok(obj, 200)`. Erro de execução cai no `CATCH` e
  vira `JsonApiResponseBuilder:asError(oE)`.
- `piExecuta` evita repetir o bloco de subir o BO em cada rota: recebe o nome
  da rotina e chama `RUN VALUE(nome) IN hRules`.

Para acrescentar uma rota: uma linha `ut-api-action.i`, uma procedure de três
linhas no handler e a rotina no BO.

## BO

Contrato de toda rotina pública:

```
INPUT  poInput JsonObject    corpo da requisição
OUTPUT poData  JsonObject    vai em "data"
OUTPUT pcErro  CHARACTER     erro de regra; "" = sucesso
```

Pontos do modelo que evitam erro conhecido:

- **`fnBody`**: conforme o ambiente, o corpo do POST chega dentro de
  `payload`, `requestBody` ou `body`. Lendo direto do `oInput`, os campos
  chegam vazios sem erro nenhum. Sempre leia por `fnBody(poInput)`.
- **`fnTexto`, `fnInteiro`, `fnLogico`**: a tela pode mandar número como texto
  e lógico como `"true"`. `GetInteger` numa chave que veio como texto estoura
  erro; estas funções leem pelo tipo que chegou.
- **`piRegistroJson`**: um lugar só para o mapeamento campo x chave JSON.
- **Validação antes da transação**, e `FIND ... EXCLUSIVE-LOCK NO-WAIT` com
  teste de `LOCKED`: requisição não fica presa esperando registro travado.
- **Leitura por índice**: `pi-consulta` usa o índice de `tipo` quando o filtro
  vem, e o primário quando não vem.

## O que trocar

1. Nome dos dois arquivos e o `RUN esp/api/v1/<nome>Rules.p` no handler.
2. Rotas e procedures.
3. No BO: tabela, campos, chaves JSON (no cabeçalho e em `piRegistroJson`),
   validações de `pi-salvar`.

## Cuidados

- Fonte em ASCII, sem acento. A resposta sai em UTF-8 e o fonte Datasul é
  CP850: acento no fonte chega errado na tela.
- Dois achados registrados nas instruções do sandbox Datasul (não retestados
  na montagem deste modelo): `Progress.Json.ObjectModel.JsonObject` não tem
  método `Read()`, o caminho é `ObjectModelParser:Parse()`; e em sessão
  `-cpinternal ibm850` o `Parse()` de `LONGCHAR` falha com erro 16063, sendo
  preciso converter antes para `MEMPTR` em UTF-8
  (`COPY-LOB ... CONVERT TARGET CODEPAGE "UTF-8"`).
- O cadastro da API no Datasul e a URL final dependem do ambiente do cliente:
  confirme com um serviço que já esteja no ar lá.

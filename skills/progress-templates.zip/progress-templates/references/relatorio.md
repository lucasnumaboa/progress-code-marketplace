# Modelo: relatório (w-relat + rp.p)

Arquivos em `templates/relatorio/esp/`:

| Arquivo | Papel |
|---|---|
| `estpl003.w` | Tela de seleção (template DDK w-relat). Páginas: Seleção, Parâmetros, Impressão. Monta a `tt-param` e executa o `rp.p` on-line ou agenda no RPW. |
| `estpl003rp.p` | Programa do relatório. Recebe a `tt-param` por `RAW`, lê os dados, imprime a listagem e, se pedido, gera a planilha. |

Tabela de exemplo: `es-tpl-serie` (definida em `templates/df/es-tpl.df`).

## Como as duas partes conversam

A tela grava os campos na `tt-param`, faz `RAW-TRANSFER` e passa para o
`rp.p`. **A definição da `tt-param` tem de ser idêntica nos dois fontes**:
mesmos campos, mesma ordem, mesmos tipos. Campo fora de ordem não dá erro de
compilação; o valor chega no campo errado. Ao acrescentar um parâmetro, altere
os dois arquivos juntos.

Os sete primeiros campos são fixos do DDK e ficam como estão:
`destino, arquivo, usuario, data-exec, hora-exec, classifica, desc-classifica`.
`destino`: 1 = Impressora, 2 = Arquivo, 3 = Terminal.

## O que trocar na tela (`estpl003.w`)

| Onde | O que fazer |
|---|---|
| Cabeçalho, `i-prgvrs.i`, `ut9000.i` | Nome do programa e versão (o `instanciar.py` troca o nome). |
| `define temp-table tt-param` | Campos de seleção e de parâmetro. |
| Variáveis `f-estab-ini/fim`, `f-serie-ini/fim`, `f-desc-ini/fim`, `f-data-ini/fim` | Uma faixa por campo de seleção: nome, `FORMAT`, `LABEL` e `INITIAL`. O fim da faixa começa com o maior valor (`"ZZZZZ"`, `12/31/9999`). |
| `DEFINE FRAME f-pg-sel` | Posição de cada campo. As imagens `IMAGE-n` (`im-fir`/`im-las`) são as setas entre o início e o fim da faixa: uma dupla por linha. Ao tirar uma faixa, tire as duas imagens dela. |
| `tg-excel`, `tg-imp-param` em `f-pg-par` | Parâmetros do relatório. Acrescente toggles, radio-sets ou campos aqui. |
| `PROCEDURE enable_UI` | Todo widget novo entra no `DISPLAY` e no `ENABLE` do frame dele. Widget fora dessas listas não aparece. |
| `PROCEDURE pi-executar` | Validações das páginas e a atribuição `tt-param.<campo> = input frame <frame> <widget>`. O modelo já valida faixa invertida. |
| `{include/i-rprun.i esp/estpl003rp.p}` | Caminho do `rp.p`. |

Os preprocessadores `PGSEL`, `PGCLA`, `PGPAR`, `PGDIG`, `PGIMP` no início dizem
quais páginas existem. Página que não existe fica com o valor em branco (no
modelo, `PGCLA` e `PGDIG`).

O título `"<Title>"` da janela é trocado em execução. Segundo o Manual de
Padrões do DDK (cópia não oficial, de 2007), o título vem do `utp/ut9000.i` e
o programador não intervém. Não foi conferido em execução: veja na tela do
cliente.

## O que trocar no `rp.p`

| Bloco | O que fazer |
|---|---|
| `tt-param` | Igual à da tela. |
| `tt-dados` | Uma linha por registro listado. Alimenta a listagem e a planilha. O `COLUMN-LABEL` vira título de coluna. |
| `form ... frame f-relat` | Colunas da listagem. Mantenha `STREAM-IO` e `WIDTH 132`. |
| `assign c-programa ...` | Nome, versão, sistema e título que saem no cabeçalho e no rodapé. |
| `for each es-tpl-serie` | A leitura principal. Deixe as faixas na ordem do índice. |
| Página de parâmetros | Uma linha por faixa e por parâmetro. |
| `pi-gera-excel` | Colunas (`piWorksheetColumn`), lista de campos e ordenação. |

A ordem dos includes é parte do modelo e não deve mudar:

```
{include/i-prgvrs.i ...}   {utp/ut-glob.i}
define temp-table tt-param ... / parâmetros de entrada / raw-transfer
{include/i-rpvar.i}                          variáveis do relatório (c-programa, c-empresa, c-titulo-relat...)
form ... frame f-relat                       layout
assign c-programa ...                        identificação
{include/i-rpcab.i &stream="str-rp"}         cabeçalho e rodapé (frames f-cabec e f-rodape)
{include/i-rpout.i &stream="stream str-rp"}  abre a saída conforme tt-param.destino
view stream str-rp frame f-cabec. view stream str-rp frame f-rodape.
... leitura e impressão, sempre com "stream str-rp" ...
{include/i-rpclo.i &stream="stream str-rp"}  fecha a saída
```

Toda a listagem sai pela stream padrão `str-rp` (`display stream str-rp`,
`put stream str-rp`, `page stream str-rp`, `down stream str-rp`). É a regra do
manual de padrões e evita que outro `OUTPUT TO` do programa desvie a listagem.
Repare na diferença dos argumentos: `i-rpcab.i` recebe `"str-rp"`, e
`i-rpout.i`/`i-rpclo.i` recebem `"stream str-rp"`. A stream não precisa de
`DEFINE STREAM` no programa: o modelo compila e roda sem ele.

## Planilha Excel

Gerada pela `utp/utapi033.p`, no estilo "aba a partir de temp-table". Regras
lidas no fonte da API:

- `piWorksheetColumn(aba, coluna, tipo, título, formato, largura)` só cria a
  coluna se ela ainda não existe. Por isso vem **antes** do
  `piNewWorksheetByTT`; se vier depois, vale o `COLUMN-LABEL` da temp-table.
  Tipos usados: `CHAR`, `INTE`, `DECI`, `DATE`.
- `piNewWorksheetByTT(aba, título, buffer:handle, campos, ordenação)`: cria a
  aba e as linhas. Para outra aba, repita com `piWorksheetColumn(2, ...)`.
- `show(yes)` abre a planilha ao terminar; no RPW ela nunca abre.
  `ConvertToXls(yes)` converte o XML para Excel na máquina que executa.
- `piProcessa(input-output arquivo, programa, título)` grava e devolve o
  caminho final. On-line o modelo usa a pasta temporária da sessão; no RPW
  passa só o nome, e a API grava no spool do servidor de execução.
- Erros voltam em `getRowErrors` (temp-table `RowErrors`, de
  `method/dbotterr.i`).

O nome do arquivo leva data e hora para não dar "arquivo em uso" quando a
planilha anterior ficou aberta.

## Cuidados

- O `rp.p` roda sem tela no RPW: nada de `MESSAGE ... VIEW-AS ALERT-BOX`
  para avisar o usuário. Avise pela própria listagem.
- A listagem sai em ISO-8859-1 (conversão feita pelo `i-rpout.i`), mesmo com
  o fonte em CP850.
- Campo de data em branco: o modelo só lista quando a faixa de data está
  completa (01/01/0001 a 31/12/9999). Decida a regra com o usuário.
- `c-empresa` vem de `param-global.grupo`, que pode estar em branco em base
  de teste.

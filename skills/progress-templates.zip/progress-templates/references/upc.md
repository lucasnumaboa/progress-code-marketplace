# Modelo: UPC de tela

Arquivos em `templates/upc/upc/`:

| Arquivo | Papel |
|---|---|
| `estpl-upc.p` | UPC de tela: parâmetros padrão, saída cedo, um evento de ajuste de tela e um de validação. |
| `estpl-upc-log.p` | UPC de levantamento: grava em arquivo cada chamada (evento, objeto, tabela, rowid) e os widgets do frame. |

## Parâmetros

Sempre estes seis, nesta ordem e com estes tipos:

```
p-ind-event   CHARACTER       evento (ponto de entrada)
p-ind-object  CHARACTER       objeto que chamou
p-wgh-object  HANDLE          handle do objeto
p-wgh-frame   WIDGET-HANDLE   frame do objeto
p-cod-table   CHARACTER       tabela do registro corrente
p-row-table   ROWID           rowid do registro corrente
```

## Como a UPC é chamada

O programa padrão chama a UPC em cada ponto de entrada, com um evento em
`p-ind-event`. **A mesma UPC roda dezenas de vezes por tela**, uma por evento e
por objeto (container, cada viewer, cada browser). Por isso o modelo começa
saindo cedo do que não trata:

```
IF LOOKUP(p-ind-event, "INITIALIZE,VALIDATE") = 0 THEN RETURN "OK".
IF p-cod-table <> "estabelec" THEN RETURN "OK".
```

Retorno `"OK"` segue o fluxo; `"NOK"` interrompe, mas só nos eventos em que o
programa padrão testa o retorno (validação, e pontos próprios de alguns
programas).

Eventos encontrados nos programas de UPC dos projetos, por frequência:
`INITIALIZE`, `BEFORE-INITIALIZE`, `AFTER-ENABLE`, `VALIDATE`, `DISPLAY`,
`ASSIGN`, `AFTER-INITIALIZE`, `BEFORE-DISPLAY`, `AFTER-DISABLE`, `CHOOSE`,
`ENABLE`, `CHANGE-PAGE`, `AFTER-DISPLAY`, `AFTER-CHANGE-PAGE`, `AFTER-ASSIGN`.
Vários programas têm eventos próprios (ex.: `ANTES-ESTORNO` e `DEPOIS-ESTORNO`
no CP0313, `valueChangedNFe` no RE0708).

## Não suponha o evento nem o nome do widget

Qual evento um programa dispara, com que tabela e como os widgets se chamam
varia de programa para programa. Antes de escrever a regra:

1. Cadastre `estpl-upc-log.p` como UPC do programa padrão, em ambiente de
   teste.
2. Abra a tela, faça a operação e leia
   `<pasta temporária da sessão>/upc-log-<usuário>.txt`.
3. Use o que o arquivo mostrou e tire o cadastro da UPC de log.

Se houver o fonte do programa padrão, confira nele o ponto de chamada.

## Cadastro

A UPC é informada no cadastro do programa padrão (campo de UPC;
`prog_dtsul.nom_prog_upc`). Se o programa já tiver uma UPC, não a substitua:
chame a sua a partir dela, com os mesmos parâmetros. Consulta pronta para ver
o que está cadastrado:

```
FIND FIRST prog_dtsul NO-LOCK WHERE prog_dtsul.cod_prog_dtsul = "<programa>" NO-ERROR.
IF AVAILABLE prog_dtsul THEN MESSAGE prog_dtsul.nom_prog_upc.
```

## O que trocar em `estpl-upc.p`

- A lista de eventos do `LOOKUP` e o `CASE`.
- A tabela esperada em `p-cod-table` e o buffer `b-estabelec`.
- `pi-initialize`: o nome do widget (`"bt-exemplo"`) e o que fazer com ele.
- `pi-validate`: a regra. O modelo lê o registro por um buffer nomeado
  (`b-estabelec`), como as UPCs dos projetos de origem.

`fnAchaWidget(frame, nome)` percorre o frame e os frames filhos. Teste
`VALID-HANDLE` no retorno: widget que não existe naquela página devolve `?`.

## Cuidados

- Variável que precisa sobreviver entre dois eventos (ex.: escolha feita no
  "antes" e usada no "depois") tem de ser `NEW GLOBAL SHARED`, com nome que não
  colida com outro programa.
- Em execução sem tela (RPW, integração) não há quem leia ou responda uma
  caixa de mensagem. Se o programa padrão também roda assim, teste
  `SESSION:BATCH-MODE` antes de avisar ou perguntar por `MESSAGE`.
- UPC lenta deixa a tela lenta em todo evento: nada de leitura pesada fora do
  evento que precisa dela.

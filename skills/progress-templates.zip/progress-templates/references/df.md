# Modelo: .df (definição de tabelas)

Arquivo: `templates/df/es-tpl.df`. Traz as duas tabelas usadas pelos modelos:

| Tabela | Campos | Índices |
|---|---|---|
| `es-tpl-ocor` | `codigo` (integer), `descricao` (char), `tipo` (integer), `ativo` (logical) | `idx-pri` (único, primário: `codigo`), `idx-ativo`, `idx-tipo` |
| `es-tpl-serie` | `cod-estabel`, `cod-serie`, `desc-serie` e campos livres `char-1/2`, `int-1/2`, `log-1/2`, `dec-1/2`, `da-1/2` | `idx-tpl-serie` (único, primário: `cod-estabel` + `cod-serie`) |

Serve de exemplo de formato e para criar as tabelas numa base de teste e
compilar os modelos antes de trocar pela tabela real.

## Conferência obrigatória de um .df

Isto não pode passar batido em pacote de deploy:

1. `ADD TABLE` com `AREA "Dados"`.
2. Todo `ADD INDEX` com `AREA "Indices"`.
3. Nenhuma ocorrência de `"Schema Area"`. Linha de `AREA` ausente também é
   falha: no teste, um .df sem `AREA` carregou **sem erro nenhum** e a tabela
   e o índice foram parar em `Schema Area`. A carga não avisa; só a
   conferência pega.
4. Campo `decimal` com `DECIMALS n`. Sem essa linha o campo fica com zero casas
   e o valor é gravado arredondado: no teste deste modelo, 1234,56 virou
   1.235,00 até a linha `DECIMALS 2` entrar no .df.
5. Um índice `PRIMARY`, e `UNIQUE` onde a chave não pode repetir.
6. `ORDER` sem repetição dentro da tabela, e `FORMAT` coerente com o tipo.
7. Campo novo em tabela que já existe no cliente vai em .df delta (só o
   `ADD FIELD`/`ADD INDEX`), não no .df completo da tabela.
8. Todo campo usado nos fontes existe no .df ou no dicionário do cliente.

O nome das áreas é o do padrão usado nos clientes atendidos. Se o banco do
cliente tiver outras áreas, vale a dele: confirme antes.

## Rodapé do arquivo

O .df termina com um bloco que informa a codificação:

```
.
PSC
cpstream=ibm850
.
0000003452
```

O número da última linha é a posição, em bytes, onde o rodapé começa. No
teste carregaram sem erro tanto o .df com o rodapé correto quanto .df sem
rodapé nenhum. Não foi testado rodapé com o número errado (o que acontece ao
editar o arquivo à mão): nesse caso, tire o rodapé ou gere o .df de novo pelo
dicionário (`exporta-df.p`).

## Carregar e conferir

`utilitarios/importa-df.p` carrega e mostra o arquivo de erros (`<banco>.e`).
`utilitarios/exporta-campos-indices.p` lista campos e índices de uma ou mais
tabelas, para conferir o que ficou no banco.

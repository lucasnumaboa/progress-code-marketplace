---
name: progress-templates
description: Modelos prontos e compilados de programas Progress 4GL/ABL para TOTVS Datasul (DDK clássico), para não começar programa novo do zero. Tem relatório com faixas de/até (tela .w + rp.p, saída texto e Excel pela utapi033), cadastro simples, cadastro pai e filho, zoom/pesquisa, UPC de tela, API REST + BO para PO-UI, carga de arquivo CSV on-line/RPW, .df de exemplo e utilitários (login pelo editor, exportar e importar DF, campos e índices, XREF de performance, compilar lista). Use sempre que o pedido for criar ou esboçar um programa Progress/Datasul novo, mesmo sem a palavra "template" - "cria um relatório", "preciso de um cadastro", "tela pai e filho", "faz uma UPC para o programa X", "cria a API dessa tela", "programa de carga", "gera Excel", "script para exportar o DF" - e também quando precisar de um exemplo comprovado de como um desses tipos é montado.
---

# Modelos de programas Progress / Datasul

Cada modelo é um programa completo que compila, saído de programa real em
produção e generalizado. O trabalho é copiar, trocar nomes e adaptar campos e
regras. Isso evita o erro mais caro nesse tipo de programa: montar a estrutura
do DDK de memória e descobrir na compilação, ou na tela do cliente, que faltou
um include, um link ou uma procedure.

## Como usar

1. **Escolha o modelo** na tabela abaixo e leia o guia dele em `references/`.
2. **Copie com os nomes novos**:
   ```bash
   python scripts/instanciar.py --listar
   python scripts/instanciar.py cadastro-simples <pasta-do-projeto> --de estpl001=<programa> --de es-tpl-ocor=<tabela>
   ```
   O script troca o nome do programa e da tabela no conteúdo e no nome dos
   arquivos, sem mexer na codificação. Campos não são trocados: isso é o passo 3.
3. **Adapte campos, títulos e regras** seguindo o guia do modelo. Antes de
   escrever um campo, confirme nome, tipo e índice no dicionário do cliente
   (skill `definicoes-tabela-cliente`, ou `exporta-campos-indices.p`). Não
   presuma campo pelo nome.
4. **Compile na ordem indicada** pelo script (SmartObjects antes do container)
   e teste no ambiente. Diga ao usuário o que foi comprovado e o que não foi.

Para dúvida sobre include, painel, ícone, evento de UPC ou variável global do
DDK, use a skill `ddk-datasul` se estiver disponível.

## Modelos

| Modelo | Pasta em `templates/` | O que traz | Guia |
|---|---|---|---|
| Relatório | `relatorio` | `estpl003.w` (w-relat: seleção com 4 faixas de/até, parâmetros, impressão) e `estpl003rp.p` (listagem texto 132 colunas, página de parâmetros, planilha pela utapi033) | [relatorio.md](references/relatorio.md) |
| Cadastro simples | `cadastro-simples` | Container w-cadsim, viewer, query, browser, vá-para e zoom (6 fontes) | [cadastro-simples.md](references/cadastro-simples.md) |
| Cadastro pai e filho | `cadastro-pai-filho` | Container w-paifil, pai navegável, filhos em browser com inclui/modifica/elimina, pesquisa e vá-para (10 fontes) | [cadastro-pai-filho.md](references/cadastro-pai-filho.md) |
| Zoom / pesquisa | dentro dos dois cadastros | `estpl001-z01.w` + `estpl001-b01.w`; `estpl002p.w` + `estpl002bp.w` | guia de cada cadastro |
| UPC | `upc` | UPC de tela e UPC de log para levantar eventos e widgets | [upc.md](references/upc.md) |
| API REST + BO | `api-rest` | Handler `ut-api` e BO de regra, para backend de PO-UI | [api-rest.md](references/api-rest.md) |
| Carga de arquivo | `carga-arquivo` | `estpl004rp.p`: lê CSV de uma pasta, valida, grava tudo ou nada, lista o resultado; roda on-line ou no RPW | [carga-arquivo.md](references/carga-arquivo.md) |
| DF | `df` | `es-tpl.df` com as duas tabelas de exemplo no padrão de áreas | [df.md](references/df.md) |
| Utilitários | `utilitarios` | Login pelo editor, exportar DF, importar DF, campos e índices, XREF de performance, compilar lista, Excel isolado pela utapi033 | [utilitarios.md](references/utilitarios.md) |

O que foi executado em cada modelo, e o que ficou sem prova, está em
[testes.md](references/testes.md). Leia antes de afirmar que algo funciona.

## Regras que valem para todos

**Codificação.** Fonte Datasul é CP850 (IBM850), não UTF-8 nem ISO-8859-1.
Arquivo com acento salvo em UTF-8 compila e mostra lixo na tela. As
ferramentas de edição recusam arquivo que não é UTF-8, então:

```bash
python scripts/cp850.py para-utf8  <arquivo ou pasta>    # antes de editar
python scripts/cp850.py para-cp850 <arquivo ou pasta>    # antes de compilar ou entregar
python scripts/cp850.py conferir   <arquivo ou pasta>    # só mostra a codificação
```

Fonte de API REST fica em ASCII, sem acento: a resposta sai em UTF-8.

**Versão e licença.** Todo programa começa com `{include/i-prgvrs.i <PROGRAMA>
<versão>}`. Tela (.w) leva também `{include/i-license-manager.i <programa>
<módulo>}` e `{utp/ut9000.i "<programa>" "<versão>"}`; confirme a sigla do
módulo com o usuário, o modelo traz a do projeto de origem (`MLA`). A cada
entrega a versão sobe: siga a regra do cliente.

**Nomes.** O programa cadastrado no Datasul é o container (`.w`) ou a tela do
relatório. Os SmartObjects são carregados por caminho relativo ao PROPATH
(`esp/...`): se a pasta do projeto mudar, troque o caminho dentro do container.

**DF.** Tabela em `AREA "Dados"`, índice em `AREA "Indices"`, nunca
`"Schema Area"`. Campo decimal precisa de `DECIMALS`: sem ele o valor é gravado
arredondado para inteiro (comprovado no teste do relatório). Detalhes em
[df.md](references/df.md).

**Leitura por índice.** Monte o `WHERE` na ordem dos campos de um índice
existente e confira com `utilitarios/xref-performance.p`, que marca leitura de
tabela inteira (`WHOLE-INDEX`).

**Credenciais.** `login-editor.p` e `exporta-df.p` não trazem usuário nem
senha. Não grave senha em arquivo de projeto, pacote ou repositório.

**Scripts de apoio no Datasul.** A sessão do Datasul já tem um `-param`
próprio. Utilitário que lê `SESSION:PARAMETER` precisa de um formato que não
se confunda com ele (os daqui usam `|` ou o prefixo `lista=`).

## O que estes modelos não cobrem

- ThinTemplate (`masterdetail/`, `maintenance/`, `window/`, `report/`): os
  modelos são do DDK clássico (`include/w-*.i`), que é o que os programas de
  origem usam. Se o projeto do cliente for ThinTemplate, parta de um programa
  dele.
- Tela para a carga de arquivo: o modelo traz só o `rp.p`. A tela é um
  w-relat; parta do `relatorio/estpl003.w` (ver o guia da carga).
- Pai e filho com manutenção do pai na mesma tela: no modelo o pai é uma
  tabela existente, só navegada.

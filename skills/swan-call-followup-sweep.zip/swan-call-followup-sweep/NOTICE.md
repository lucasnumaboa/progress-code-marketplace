# Aviso de terceiros (NOTICE)

Esta skill é uma cópia adaptada de material de terceiros e é redistribuída sob a licença original. O texto do especialista ficou em inglês, como no original.

- **Origem:** https://github.com/swan-gtm/gtm-skills
- **Caminho no repositório:** `skills/boaz-descalo/call-followup-sweep`
- **Commit:** `eb0026f469f90645e1a64168d08a3e0afb59ee12` (baixado em 2026-11-22)
- **Autor:** Boaz Descalo (autor da skill); copyright do repositório: Swan
- **Licença:** MIT (texto completo em `LICENSE`, copiado de `LICENSE` do repositório)

## Arquivos incluídos

- `SKILL.md` (de `skills/boaz-descalo/call-followup-sweep/SKILL.md`)
- `references/commitment-extraction.md` (de `skills/boaz-descalo/call-followup-sweep/references/commitment-extraction.md`)
- `references/draft-patterns.md` (de `skills/boaz-descalo/call-followup-sweep/references/draft-patterns.md`)
- `references/triage-rubric.md` (de `skills/boaz-descalo/call-followup-sweep/references/triage-rubric.md`)
- `author.md` (de `skills/boaz-descalo/author.md`, crédito do autor pedido pelo repositório)
- `LICENSE`

## Mudanças feitas

- Frontmatter: `name: call-followup-sweep` trocado por `name: swan-call-followup-sweep` (a descrição ficou igual).

## Crédito do autor (author.md)

O repositório pede que o crédito do autor acompanhe a skill. Conteúdo do `author.md` original:

```markdown
---
name: Boaz Descalo
avatarUrl: "https://www.gtmskills.com/authors/boaz-descalo.jpg"
title: Founder & CEO, Node8
linkedinUrl: https://www.linkedin.com/in/descalo/
companyDomain: node8.ai
---

I build and scale AI systems for B2B companies. Today I run Node8, where we partner with teams from early-stage startups to public companies to move from AI strategy to production implementation and measurable adoption. My skills encode the data-plumbing side of GTM — the unglamorous resolution, dedupe, and hygiene steps that decide whether enrichment and outreach downstream actually work.
```

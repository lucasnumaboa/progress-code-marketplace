---
name: monitoramento-maquina-windows
description: Monitora CPU/memória/disco/processos com contadores de desempenho do Windows, gera alertas e inventário de hardware via CIM/WMI, sem instalar programa externo. Use quando o usuário pedir para "ver o que está consumindo CPU/memória", "monitorar o disco cheio", "inventariar o hardware dessa máquina", "alertar se o processo X cair".
argument-hint: [métrica/processo a monitorar]
---

# Monitoramento de máquina (Windows, ferramentas embutidas)

## CPU, memória e disco — snapshot rápido
```powershell
Get-CimInstance Win32_Processor | Select-Object Name, LoadPercentage
Get-CimInstance Win32_OperatingSystem | Select-Object @{n="MemUsadaGB";e={[math]::Round(($_.TotalVisibleMemorySize-$_.FreePhysicalMemory)/1MB,1)}}, @{n="MemTotalGB";e={[math]::Round($_.TotalVisibleMemorySize/1MB,1)}}
Get-CimInstance Win32_LogicalDisk -Filter "DriveType=3" | Select-Object DeviceID, @{n="LivreGB";e={[math]::Round($_.FreeSpace/1GB,1)}}, @{n="TotalGB";e={[math]::Round($_.Size/1GB,1)}}
```

## Contadores de desempenho (série temporal, não só snapshot)
```powershell
Get-Counter '\Processor(_Total)\% Processor Time' -SampleInterval 2 -MaxSamples 10
Get-Counter '\Memory\Available MBytes'
Get-Counter '\PhysicalDisk(_Total)\% Disk Time'
```
Útil para "está lento agora" — colete alguns segundos de amostra em vez de confiar num único ponto no tempo (CPU
pode estar em pico momentâneo que não representa o problema real).

## Processos que mais consomem
```powershell
Get-Process | Sort-Object CPU -Descending | Select-Object -First 10 Name, CPU, WorkingSet, Id
Get-Process | Sort-Object WorkingSet -Descending | Select-Object -First 10 Name, @{n="MemMB";e={[math]::Round($_.WorkingSet/1MB,1)}}
```

## Alertar se um processo específico não estiver rodando
```powershell
if (-not (Get-Process -Name "NomeDoProcesso" -ErrorAction SilentlyContinue)) {
    # enviar alerta (ver skills de e-mail/Teams/Slack) e opcionalmente tentar reiniciar
    Start-Process "C:\app\programa.exe"
}
```
Combine com uma tarefa agendada rodando a cada poucos minutos (ver skill `servicos-tarefas-agendadas-windows`) para
monitoramento contínuo.

## Inventário de hardware
```powershell
Get-CimInstance Win32_ComputerSystem | Select-Object Manufacturer, Model, TotalPhysicalMemory
Get-CimInstance Win32_Processor | Select-Object Name, NumberOfCores, NumberOfLogicalProcessors
Get-CimInstance Win32_DiskDrive | Select-Object Model, @{n="TamanhoGB";e={[math]::Round($_.Size/1GB,1)}}
Get-CimInstance Win32_BIOS | Select-Object SerialNumber
```
Para inventariar várias máquinas de uma vez, combine com `Invoke-Command -ComputerName` (remoting, ver skill
`powershell-moderno`) numa lista de nomes de máquina.

## Regras
- Contadores de desempenho (`Get-Counter`) têm custo de coleta — não rode com intervalo muito curto
  (`-SampleInterval 1`) continuamente por longos períodos sem necessidade real, isso também consome recurso.
- Ao alertar sobre disco cheio, defina um limiar sensato com o usuário (ex.: "< 10% livre" ou "< 5GB livre") — não
  invente um número sem confirmar o que é crítico no contexto dele.
- Reiniciar um processo automaticamente ao detectar que caiu: só faça isso se o usuário explicitamente pediu esse
  comportamento — reinício automático pode mascarar um problema real que precisa de atenção humana.

## Arquivos desta skill
Nenhum script fixo — os comandos acima cobrem os casos mais comuns; adapte à métrica/processo reais do usuário.

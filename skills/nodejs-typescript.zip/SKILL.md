---
name: nodejs-typescript
description: Gerencia projetos Node.js/TypeScript — npm/pnpm, tsconfig.json, ESM vs. CommonJS, scripts de build, empacotar CLI, depurar com --inspect. Use quando o usuário pedir para "criar um projeto Node/TypeScript", "esse import está dando erro estranho", "empacotar isso como CLI", "depurar esse script Node".
argument-hint: [operação/dúvida Node.js ou TypeScript]
---

# Node.js e TypeScript

## Pré-requisito
Precisa do Node.js instalado (`node --version`). Se não estiver, `winget install OpenJS.NodeJS.LTS` (ver skill
`instalar-software-ambientes`; para várias versões lado a lado, `nvm-windows`, também na mesma skill).

## npm vs. pnpm
```
npm install pacote
pnpm add pacote   # instala mais rapido e economiza espaco (link simbolico compartilhado entre projetos)
```
`pnpm` precisa ser instalado separadamente (`npm install -g pnpm`) — só proponha se o projeto já usa ou o usuário
topar; `npm` já vem junto do Node, sem instalação extra.

## ESM vs. CommonJS — a fonte mais comum de erro de import
```json
// package.json
{ "type": "module" }   // ativa ESM: import/export de verdade, __dirname NAO existe (use import.meta.url)
```
Sem `"type": "module"`, Node trata `.js` como CommonJS (`require`/`module.exports`). Misturar os dois estilos no
mesmo projeto sem entender qual está ativo é a causa mais comum de `ERR_REQUIRE_ESM`/`Cannot use import statement
outside a module`. Regra prática: projeto novo, prefira ESM (`"type": "module"`); ao integrar com uma lib antiga
que só suporta CommonJS, use `import pacote from "pacote"` (interop automático do Node para a maioria dos casos) ou
`createRequire` quando precisar de `require` dentro de um módulo ESM.

## TypeScript — tsconfig mínimo sensato
```json
{
  "compilerOptions": {
    "target": "ES2022",
    "module": "NodeNext",
    "moduleResolution": "NodeNext",
    "strict": true,
    "outDir": "dist",
    "esModuleInterop": true
  }
}
```
`"strict": true` desde o início de um projeto novo — ativar depois, com código já escrito, gera uma avalanche de
erros de tipo para corrigir de uma vez; é bem mais barato manter estrito desde o começo.
```
npm install -D typescript
npx tsc --init
npx tsc      # compila conforme tsconfig
```

## Scripts do package.json
```json
{
  "scripts": {
    "build": "tsc",
    "start": "node dist/index.js",
    "dev": "tsx watch src/index.ts"
  }
}
```
`tsx` (`npm install -D tsx`) roda TypeScript direto sem precisar compilar antes a cada mudança — bom para
desenvolvimento; para produção, sempre compile (`tsc`) e rode o `.js` gerado, não dependa de `tsx` em produção.

## Empacotar como CLI instalável
```json
{ "bin": { "meu-comando": "./dist/cli.js" } }
```
```
npm link   # instala localmente para testar como comando global
npm publish   # publica no npm de verdade - confirme com o usuario antes, e' uma acao publica e permanente
```
Arquivo `cli.js` precisa começar com `#!/usr/bin/env node` na primeira linha para funcionar como executável.

## Depurar com --inspect
```
node --inspect-brk dist/index.js
```
Abre uma porta de debug (padrão 9229) — conecte com `chrome://inspect` no Chrome/Edge, ou anexe o debugger do VS
Code (configuração `"type": "node", "request": "attach"`). `--inspect-brk` pausa na primeira linha (dá tempo de
conectar o debugger antes do código rodar); `--inspect` sozinho não pausa.

## Regras
- Nunca rode `npm publish` sem confirmação explícita do usuário — publicação no registro npm público é
  praticamente irreversível (nome fica reservado, versão publicada não pode ser removida de verdade).
- Ao misturar ESM/CommonJS, sempre confirme qual o projeto já usa (`"type"` no `package.json`) antes de escrever
  código novo — não assuma.
- `node_modules` nunca vai para o controle de versão — confirme que `.gitignore` já cobre isso antes do primeiro
  commit de um projeto novo.

## Arquivos desta skill
Nenhum script fixo — os trechos acima cobrem os casos mais comuns; adapte ao projeto real do usuário.

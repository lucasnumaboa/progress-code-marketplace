# Origem e mudanças

- **Repositório:** https://github.com/anthropics/skills
- **Caminho no repositório:** `skills/webapp-testing`
- **Autor:** Anthropic
- **Licença:** Apache-2.0 (texto em `LICENSE.txt`)
- **Commit usado:** `e4bb5d960d87126ff3b3a8af1a104b7db67560ba`
- **Arquivos copiados:** `SKILL.md`, `examples/console_logging.py`, `examples/element_discovery.py`, `examples/static_html_automation.py`, `scripts/with_server.py`

## Mudanças feitas

- no cabeçalho (frontmatter), `name:` passou de `webapp-testing` para `as-webapp-testing`; a descrição ficou igual
- nenhuma outra alteração no texto do especialista (mantido em inglês)

Empacotada para o marketplace do Progress Code em 2026-11-22.

# Origem e licença

Esta skill é uma cópia, com as alterações listadas abaixo, de material de especialista com licença aberta.

- **Fonte:** https://github.com/getsentry/skills
- **Arquivos de origem:** `skills/pr-writer/SKILL.md`
- **Autor:** Sentry (Functional Software, Inc.)
- **Licença:** Apache-2.0 (texto completo em `LICENSE`)
- **Commit:** `a582c51ee29d0f35e6ac321340796f77d43da733` (baixado em 2026-11-22)

## Alterações feitas

- `name:` do frontmatter trocado de `pr-writer` para `sen-pr-writer`.
- Fora isso, o texto do especialista está como no original (em inglês).

## Arquivos da skill original que não vieram

- `SPEC.md`, `EVAL.md` e `evals/` (especificação interna e casos de teste do autor).

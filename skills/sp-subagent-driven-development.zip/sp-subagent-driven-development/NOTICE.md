# Origem

Skill de especialista empacotada para o marketplace do Progress Code (id `sp-subagent-driven-development`).

- Repositório: https://github.com/obra/superpowers
- Caminho: `skills/subagent-driven-development`
- Autor: Jesse Vincent
- Detentor do copyright no arquivo de licença: Jesse Vincent
- Licença: MIT (texto completo em `LICENSE`, copiado de `LICENSE` no repositório)
- Commit: `22f0b463e7a5e579904dd6211a520321035526f7` (baixado em 2026-11-22)

## Arquivos incluídos

- `SKILL.md` (de `skills/subagent-driven-development/SKILL.md`)
- `implementer-prompt.md` (de `skills/subagent-driven-development/implementer-prompt.md`)
- `re-review-prompt.md` (de `skills/subagent-driven-development/re-review-prompt.md`)
- `task-reviewer-prompt.md` (de `skills/subagent-driven-development/task-reviewer-prompt.md`)
- `references/batching.md` (de `skills/subagent-driven-development/references/batching.md`)
- `references/cannot-verify.md` (de `skills/subagent-driven-development/references/cannot-verify.md`)
- `references/final-review.md` (de `skills/subagent-driven-development/references/final-review.md`)
- `references/fix-loop.md` (de `skills/subagent-driven-development/references/fix-loop.md`)
- `references/handling-reports.md` (de `skills/subagent-driven-development/references/handling-reports.md`)
- `references/preflight.md` (de `skills/subagent-driven-development/references/preflight.md`)
- `references/resuming.md` (de `skills/subagent-driven-development/references/resuming.md`)
- `scripts/review-package` (de `skills/subagent-driven-development/scripts/review-package`)
- `scripts/sdd-repo` (de `skills/subagent-driven-development/scripts/sdd-repo`)
- `scripts/sdd-workspace` (de `skills/subagent-driven-development/scripts/sdd-workspace`)
- `scripts/task-brief` (de `skills/subagent-driven-development/scripts/task-brief`)

## Mudanças feitas

1. Frontmatter: `name:` trocado de `subagent-driven-development` para `sp-subagent-driven-development` (a descrição foi mantida).
2. Os scripts em `scripts/` são bash locais (git), sem serviço externo; foram copiados como estão.

O texto do especialista foi mantido em inglês, sem tradução.

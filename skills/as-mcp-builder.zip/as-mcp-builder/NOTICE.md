# Origem e licença

Esta skill é uma cópia, com as alterações listadas abaixo, de material de especialista com licença aberta.

- **Fonte:** https://github.com/anthropics/skills
- **Arquivos de origem:** `skills/mcp-builder/SKILL.md`, `skills/mcp-builder/reference/evaluation.md`, `skills/mcp-builder/reference/mcp_best_practices.md`, `skills/mcp-builder/reference/node_mcp_server.md`, `skills/mcp-builder/reference/node_mcp_server_v2.md`, `skills/mcp-builder/reference/python_mcp_server.md`
- **Autor:** Anthropic
- **Licença:** Apache-2.0 (texto completo em `LICENSE`)
- **Commit:** `e4bb5d960d87126ff3b3a8af1a104b7db67560ba` (baixado em 2026-11-22)

## Alterações feitas

- `name:` do frontmatter trocado de `mcp-builder` para `as-mcp-builder`.
- Fora isso, o texto do especialista está como no original (em inglês).

## Arquivos da skill original que não vieram

- `scripts/` (`evaluation.py`, `connections.py`, exemplo XML): o harness de avaliação chama a API paga da Anthropic com chave própria. O método de avaliação continua em `reference/evaluation.md`.

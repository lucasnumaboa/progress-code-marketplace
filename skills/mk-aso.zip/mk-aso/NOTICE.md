# Origem e mudanças

- **Repositório:** https://github.com/coreyhaines31/marketingskills
- **Caminho no repositório:** `skills/aso`
- **Autor:** Corey Haines
- **Licença:** MIT (texto em `LICENSE`)
- **Commit usado:** `5b2b400eec1e7e1cec76245a715d0b0d4fd2a9c1`
- **Arquivos copiados:** `SKILL.md`, `references/apple-specs.md`, `references/benchmarks.md`, `references/google-play-specs.md`, `references/report-template.md`, `references/scoring-criteria.md`

## Mudanças feitas

- no cabeçalho (frontmatter), `name:` passou de `aso` para `mk-aso`; a descrição ficou igual
- nenhuma outra alteração no texto do especialista (mantido em inglês)

Empacotada para o marketplace do Progress Code em 2026-11-22.

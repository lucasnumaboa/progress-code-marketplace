---
name: slack-web-api
description: Envia mensagens formatadas (Block Kit), responde em threads e sobe arquivos no Slack via Web API, e monta slash commands. Use quando o usuário pedir para "mandar mensagem no Slack", "montar um card formatado no Slack", "criar um slash command", "responder numa thread do Slack".
argument-hint: [canal] [conteúdo]
---

# Slack (Web API e Block Kit)

## Passo 1 — Instalar e autenticar
```
pip install slack_sdk
```
Token de bot (`xoxb-...`) gerado em `api.slack.com/apps` → OAuth & Permissions, com os escopos necessários
(`chat:write`, `files:write`, etc. conforme a operação).
```python
from slack_sdk import WebClient
client = WebClient(token=bot_token)
```

## Passo 2 — Mensagem simples
```python
client.chat_postMessage(channel="#alertas", text="Build #1234 falhou.")
```

## Passo 3 — Block Kit (cartão formatado)
```python
client.chat_postMessage(
    channel="#alertas",
    text="Build #1234 falhou.",  # fallback para notificacoes que nao renderizam blocks
    blocks=[
        {"type": "header", "text": {"type": "plain_text", "text": "Build #1234 falhou"}},
        {"type": "section", "text": {"type": "mrkdwn", "text": "*Branch:* main\n*Erro:* timeout no teste X"}},
        {"type": "actions", "elements": [
            {"type": "button", "text": {"type": "plain_text", "text": "Ver log"}, "url": "https://ci.exemplo.com/1234"}
        ]},
    ],
)
```
Sempre inclua `text` além de `blocks` — é o que aparece em notificações push e para integrações que não renderizam
Block Kit; nunca deixe só `blocks` sem um `text` de fallback sensato.

## Passo 4 — Responder em thread
```python
resp = client.chat_postMessage(channel="#canal", text="Mensagem original")
client.chat_postMessage(channel="#canal", thread_ts=resp["ts"], text="Resposta na thread")
```

## Passo 5 — Upload de arquivo
```python
client.files_upload_v2(channel="#canal", file="relatorio.pdf", title="Relatório mensal")
```

## Passo 6 — Slash command (o usuário digita `/comando` no Slack)
Precisa de um endpoint HTTPS público registrado no app do Slack (Slash Commands). O Slack faz `POST` para esse
endpoint a cada uso:
```python
@app.route("/slack/comando", methods=["POST"])
def comando():
    texto = request.form.get("text")
    return jsonify({"response_type": "ephemeral", "text": f"Recebido: {texto}"})
```
`response_type: "ephemeral"` mostra a resposta só para quem digitou o comando; `"in_channel"` mostra para todos.
Slack exige resposta em até 3 segundos — para processamento demorado, responda rápido com "processando..." e envie
o resultado depois via `response_url` (incluída no payload recebido).

## Regras
- Nunca exponha o `bot_token` em código versionado — variável de ambiente.
- Verifique a assinatura das requisições recebidas do Slack (`X-Slack-Signature` + `X-Slack-Request-Timestamp`)
  antes de processar um slash command/webhook — sem isso, qualquer um que descobrir a URL pode forjar comandos.
- Rate limit: Slack limita chamadas por método (`chat.postMessage` tem limite por workspace) — trate `429` com
  retry respeitando `Retry-After` (mesmo padrão da skill `chamar-apis-http`).

## Arquivos desta skill
Nenhum script fixo — os trechos acima cobrem os casos mais comuns; adapte ao canal/formato reais do usuário.

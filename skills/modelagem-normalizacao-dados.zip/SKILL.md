---
name: modelagem-normalizacao-dados
description: Vai do requisito ao modelo entidade-relacionamento, decide chaves e índices, quando normalizar e quando desnormalizar de propósito, e gera o DDL para o banco-alvo. Use quando o usuário pedir para "modelar esse banco de dados", "essa tabela está mal desenhada, como melhoro", "gerar o CREATE TABLE disso", "isso deveria ser uma tabela só ou várias".
argument-hint: [domínio/requisito a modelar] [banco-alvo]
---

# Modelagem e normalização

## Do requisito ao modelo (perguntas antes de desenhar)
Antes de propor tabelas, confirme: quais entidades existem de verdade (coisas com identidade própria: cliente,
produto, pedido) vs. atributos de uma entidade (um cliente tem um endereço — é atributo ou merece tabela própria
porque um cliente pode ter vários endereços?); quais relacionamentos são 1-para-muitos vs. muitos-para-muitos
(um pedido tem vários itens = 1-N; um produto pode estar em várias categorias e uma categoria tem vários produtos =
N-N, precisa de tabela associativa).

## As três primeiras formas normais (na prática, não na teoria)
- **1FN**: cada célula um valor só (nunca `"produto1,produto2,produto3"` numa coluna de texto — isso deveria ser
  uma tabela `pedido_item` separada).
- **2FN**: numa tabela com chave composta, todo atributo depende da chave **inteira**, não só de parte dela (ex.:
  numa tabela `pedido_item(pedido_id, produto_id, nome_produto, quantidade)`, `nome_produto` depende só de
  `produto_id`, não da chave composta inteira — deveria estar na tabela `produto`, não repetida aqui).
- **3FN**: nenhum atributo depende de outro atributo não-chave (ex.: `cidade` e `estado` na mesma tabela, onde
  `estado` pode ser derivado de `cidade` via uma tabela de cidades — se `estado` for gravado direto na tabela de
  clientes, uma cidade mudar de estado por erro de digitação em uma linha não afeta as outras, gerando
  inconsistência).

## Quando desnormalizar de propósito (não é sempre errado)
Desnormalização é uma troca consciente de "reduzir duplicação" por "performance de leitura" — vale quando:
- Relatório/dashboard lê a mesma junção pesada repetidamente e a tabela de origem muda pouco (ex.: manter
  `nome_cliente` copiado na tabela de pedido histórico, para não juntar com `cliente` numa consulta que roda
  milhares de vezes por dia, aceitando que o nome "congelado" no pedido reflete o nome **na data do pedido**, o que
  às vezes é até o comportamento correto de negócio, não um bug).
- Data warehouse / modelo para BI (ver skill `preparar-dados-powerbi`) — modelo estrela é desnormalizado por
  design, de propósito, para performance de consulta analítica.
Nunca desnormalize "porque sim" — documente a razão específica, porque isso é dívida técnica consciente que alguém
vai perguntar "por que está duplicado aqui" no futuro.

## Chaves e índices
- Chave primária: prefira uma chave substituta (`id` autoincremento/`uuid`) a uma chave natural (CPF, código de
  produto) quando a chave natural pode, na prática, mudar ou ter erro de digitação corrigido depois — mudar uma
  chave primária referenciada por FK em várias tabelas é doloroso.
- Índice único (não só índice comum) em toda coluna que deveria ser única de fato (CPF, e-mail de login, código de
  produto) — sem isso, um bug na aplicação pode inserir duplicado e ninguém percebe até virar problema de negócio.

## Gerar DDL para o banco-alvo
```sql
CREATE TABLE cliente (
    id SERIAL PRIMARY KEY,                 -- PostgreSQL: SERIAL; SQL Server: INT IDENTITY(1,1); MySQL: INT AUTO_INCREMENT
    nome VARCHAR(200) NOT NULL,
    cpf CHAR(11) NOT NULL UNIQUE,
    criado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE endereco (
    id SERIAL PRIMARY KEY,
    cliente_id INT NOT NULL REFERENCES cliente(id),
    logradouro VARCHAR(200) NOT NULL,
    cep CHAR(8) NOT NULL
);
```
Ver skill `migrar-dados-entre-bancos` para a tabela de equivalência de tipos entre SQL Server/PostgreSQL/MySQL/
Progress ao adaptar o DDL para um banco específico.

## Regras
- Sempre desenhe o diagrama (mesmo que em texto/ASCII, ou com a skill de diagramas quando disponível) antes de
  gerar o DDL — é muito mais barato corrigir um erro de modelo no diagrama do que depois de dados carregados.
- Nunca proponha eliminar uma FK "para simplificar" sem entender por que ela existia — integridade referencial
  existe para prevenir dado órfão, removê-la é perder uma proteção real.
- Índice único em CPF/e-mail: confirme com o usuário se realmente deve ser único no domínio dele (ex.: um sistema
  pode legitimamente ter o mesmo CPF em contextos diferentes, como titular e dependente) antes de assumir.

## Arquivos desta skill
Nenhum script fixo — o processo acima é o ponto de partida; adapte ao domínio/banco-alvo reais do usuário.

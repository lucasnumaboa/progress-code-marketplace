---
name: ler-enviar-email
description: Lê, filtra, baixa anexos e responde e-mail via IMAP/SMTP (biblioteca padrão do Python, sem instalar nada) ou via Microsoft Graph (Outlook 365, sem precisar do Outlook instalado), e lida com arquivos .msg/.eml. Use quando o usuário pedir para "ler os e-mails da caixa X", "baixar os anexos desses e-mails", "responder automaticamente", "abrir esse arquivo .msg/.eml".
argument-hint: [conta/caixa de e-mail] [operação: ler|filtrar|responder|anexos]
---

# Ler e enviar e-mail (IMAP/SMTP/Graph)

## Quando usar cada caminho
- **IMAP/SMTP** (`imaplib`/`smtplib`, biblioteca padrão do Python — nada a instalar): funciona com qualquer provedor
  que exponha IMAP/SMTP (Gmail, Outlook.com, servidores corporativos tradicionais). Simples, mas cada provedor tem
  suas particularidades de autenticação (Gmail exige "senha de app" ou OAuth2, não a senha normal, desde 2022).
- **Microsoft Graph** (Outlook 365 corporativo): mais robusto para ambiente corporativo Microsoft, suporta OAuth2
  de aplicação (sem precisar de senha de usuário), e não depende do Outlook estar instalado.
- **COM/Outlook instalado**: ver skill `automatizar-office-com` — quando o objetivo é controlar o Outlook que já
  está aberto na tela do usuário (ex.: aproveitar uma sessão já logada).

## IMAP: ler e filtrar
```python
import imaplib
import email

imap = imaplib.IMAP4_SSL("imap.gmail.com")
imap.login(usuario, senha_de_app)
imap.select("INBOX")

status, dados = imap.search(None, '(UNSEEN FROM "financeiro@empresa.com")')
for num in dados[0].split():
    status, msg_dados = imap.fetch(num, "(RFC822)")
    msg = email.message_from_bytes(msg_dados[0][1])
    print(msg["Subject"], msg["From"])
```
Critérios de busca IMAP comuns: `UNSEEN` (não lido), `SINCE "01-Jan-2026"`, `SUBJECT "palavra"`, `FROM "endereco"` —
combine entre parênteses como no exemplo.

## Baixar anexos
```python
for parte in msg.walk():
    if parte.get_content_disposition() == "attachment":
        nome = parte.get_filename()
        with open(nome, "wb") as f:
            f.write(parte.get_payload(decode=True))
```

## SMTP: enviar
```python
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication

msg = MIMEMultipart()
msg["From"] = remetente
msg["To"] = destinatario
msg["Subject"] = "Assunto"
msg.attach(MIMEText("Corpo do e-mail", "plain"))
with open("anexo.pdf", "rb") as f:
    parte = MIMEApplication(f.read(), Name="anexo.pdf")
    parte["Content-Disposition"] = 'attachment; filename="anexo.pdf"'
    msg.attach(parte)

with smtplib.SMTP_SSL("smtp.gmail.com", 465) as smtp:
    smtp.login(remetente, senha_de_app)
    smtp.send_message(msg)
```

## Microsoft Graph (Outlook 365)
```python
resp = requests.get(
    "https://graph.microsoft.com/v1.0/me/messages?$filter=isRead eq false",
    headers={"Authorization": f"Bearer {token}"},
)
```
Autenticação via OAuth2 client credentials (aplicação) ou authorization code (usuário) — ver skill
`oauth2-login-servicos`.

## Arquivos .msg/.eml
```python
# .eml: e' o formato padrao MIME - abre direto com o modulo email
with open("mensagem.eml", "rb") as f:
    msg = email.message_from_binary_file(f)

# .msg: formato proprietario da Microsoft - precisa de biblioteca separada
# pip install extract-msg
import extract_msg
msg = extract_msg.Message("mensagem.msg")
print(msg.subject, msg.sender, msg.body)
```

## Regras
- **Nunca envie e-mail automaticamente sem confirmação do usuário sobre o conteúdo** — use um passo de revisão
  (mostrar o rascunho) antes de chamar `send_message`/`smtp.send`.
- Senha de e-mail: nunca peça para colar a senha normal da conta na conversa — oriente a gerar uma "senha de app"
  (Gmail/Outlook.com) ou usar OAuth2, e guardar com `keyring` (ver skill `oauth2-login-servicos`).
- Ao processar caixa de entrada em lote (marcar como lido, mover, deletar), sempre confirme o filtro com o usuário
  antes de aplicar em massa — ações em e-mail são difíceis de desfazer em escala.

## Arquivos desta skill
Nenhum script fixo — os trechos acima cobrem os casos mais comuns; adapte ao provedor/conta real do usuário.

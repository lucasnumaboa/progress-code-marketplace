---
name: azure-para-desenvolvedores
description: Usa o Azure CLI (az) para App Service, Storage, Key Vault e Functions, autentica aplicações e monitora custos. Use quando o usuário pedir para "fazer deploy no Azure", "criar uma conta de Storage", "guardar um segredo no Key Vault", "por que essa fatura do Azure veio alta".
argument-hint: [recurso Azure] [operação]
---

# Azure para desenvolvedores

## Instalar e autenticar
```
winget install Microsoft.AzureCLI
az login
az account set --subscription "Nome ou ID da assinatura"
```

## App Service (deploy de aplicação web)
```
az group create --name meu-grupo --location brazilsouth
az appservice plan create --name meu-plano --resource-group meu-grupo --sku B1
az webapp create --name meu-app --resource-group meu-grupo --plan meu-plano --runtime "PYTHON:3.12"
az webapp deploy --name meu-app --resource-group meu-grupo --src-path app.zip
```
`--sku B1` (Basic) é o menor nível pago com recursos completos — `F1` (Free) tem limitações severas (sem domínio
customizado com SSL, hiberna após inatividade); confirme com o usuário o nível adequado antes de criar.

## Storage (blobs, arquivos)
```
az storage account create --name meustorage --resource-group meu-grupo --sku Standard_LRS
az storage container create --name meucontainer --account-name meustorage
az storage blob upload --account-name meustorage --container-name meucontainer --name arquivo.pdf --file ./arquivo.pdf
```
`Standard_LRS` (redundância local, mais barato) vs. `Standard_GRS` (redundância geográfica, mais caro, protege
contra perda de uma região inteira) — confirme o nível de redundância necessário com o usuário, não assuma o mais
caro nem o mais barato sem essa conversa.

## Key Vault (segredos)
```
az keyvault create --name meu-vault --resource-group meu-grupo
az keyvault secret set --vault-name meu-vault --name "MinhaChave" --value "valor-secreto"
az keyvault secret show --vault-name meu-vault --name "MinhaChave" --query value -o tsv
```
Nunca mostre (`secret show`) um segredo real na conversa/log — use isso só para confirmar que o valor existe, ou
para uma aplicação ler programaticamente via SDK (`azure-keyvault-secrets` no Python), não via terminal para humano
ler.

## Functions (serverless)
```
az functionapp create --name minha-function --resource-group meu-grupo --storage-account meustorage --consumption-plan-location brazilsouth --runtime python
func azure functionapp publish minha-function
```
`func` (Azure Functions Core Tools) é uma ferramenta separada (`npm install -g azure-functions-core-tools@4`) —
confirme se já está instalada antes de assumir que o comando `func` existe.

## Autenticação de aplicação (Service Principal, sem usuário humano)
```
az ad sp create-for-rbac --name meu-app-sp --role Contributor --scopes /subscriptions/{id}/resourceGroups/meu-grupo
```
Devolve `appId`/`password`/`tenant` — use com `ClientSecretCredential` do SDK (`azure-identity`), nunca com login
interativo, para automação sem usuário. Guarde o `password` como segredo (ver skill `oauth2-login-servicos`).

## Monitorar custos
```
az consumption usage list --start-date 2026-03-01 --end-date 2026-03-31
```
Ou, mais prático para uma visão rápida: portal Azure → Cost Management + Billing → Cost analysis, filtrando por
grupo de recursos — a CLI é melhor para automação/relatório recorrente, o portal é melhor para investigação
exploratória pontual.

## Regras
- Sempre confirme a assinatura ativa (`az account show`) antes de criar recursos — criar em assinatura errada
  (ex.: produção em vez de teste) gera custo e confusão real.
- Nunca crie recursos de custo significativo (VM grande, banco gerenciado) sem confirmar o nível/SKU com o usuário
  — muitos desses recursos custam por hora mesmo parados.
- `az group delete` apaga **tudo** dentro do grupo de recursos de uma vez — sempre confirme explicitamente antes de
  rodar, e liste o conteúdo do grupo (`az resource list --resource-group nome`) antes de apagar.

## Arquivos desta skill
Nenhum script fixo — os comandos acima cobrem os casos mais comuns; adapte ao recurso/assinatura reais do usuário.

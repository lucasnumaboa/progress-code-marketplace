# Origem e mudanças

- **Repositório:** https://github.com/anthropics/knowledge-work-plugins
- **Caminho no repositório:** `marketing/skills/performance-report`
- **Autor:** Anthropic
- **Licença:** Apache-2.0 (texto em `LICENSE`)
- **Commit usado:** `0e0fcacddcc892eb92a1b7873ff9d68159c47571`
- **Arquivos copiados:** `SKILL.md`

## Mudanças feitas

- no cabeçalho (frontmatter), `name:` passou de `performance-report` para `kwp-performance-report`; a descrição ficou igual
- removida a linha que manda consultar `CONNECTORS.md` (arquivo de conectores do Claude Cowork, outro produto)
- nenhuma outra alteração no texto do especialista (mantido em inglês)

Empacotada para o marketplace do Progress Code em 2026-11-22.

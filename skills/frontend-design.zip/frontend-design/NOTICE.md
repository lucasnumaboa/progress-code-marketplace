# Origem

Esta skill é a "frontend-design" publicada pela Anthropic em https://github.com/anthropics/skills
(skills/frontend-design), sob a licença Apache-2.0 (texto completo em LICENSE.txt).
O SKILL.md foi mantido sem alterações. Empacotada para o marketplace do Progress Code.

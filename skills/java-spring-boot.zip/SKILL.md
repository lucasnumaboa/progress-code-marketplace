---
name: java-spring-boot
description: Gerencia projetos Java/Spring Boot — Maven/Gradle, perfis (application-{perfil}.yml), Actuator, logs estruturados e empacotamento como jar/war, rodando como serviço no Windows. Use quando o usuário pedir para "criar um projeto Spring Boot", "configurar perfil de ambiente", "esse erro do Maven/Gradle não faz sentido", "rodar esse jar como serviço".
argument-hint: [operação/dúvida Java ou Spring Boot]
---

# Java e Spring Boot

## Pré-requisito
Precisa do JDK instalado (`java -version`). Se não estiver, `winget install EclipseAdoptium.Temurin.21.JDK` (ver
skill `instalar-software-ambientes`).

## Maven vs. Gradle
```
mvn clean package          # gera o jar/war em target/
mvn dependency:tree         # ver arvore de dependencias (util para achar conflito de versao)
```
```
gradlew build
gradlew dependencies
```
Use o wrapper (`mvnw`/`gradlew`, incluído no projeto) em vez do `mvn`/`gradle` global instalado — garante a mesma
versão da ferramenta de build para todo mundo que roda o projeto, independente do que está instalado na máquina.

## Perfis por ambiente
```yaml
# application.yml (comum a todos os perfis)
spring:
  profiles:
    active: dev

---
# application-dev.yml
spring:
  datasource:
    url: jdbc:postgresql://localhost:5432/dev

---
# application-prod.yml
spring:
  datasource:
    url: ${DATASOURCE_URL}   # variavel de ambiente, nunca hardcoded em producao
```
```
java -jar app.jar --spring.profiles.active=prod
```

## Actuator (saúde e métricas da aplicação)
```
implementation 'org.springframework.boot:spring-boot-starter-actuator'
```
```yaml
management:
  endpoints:
    web:
      exposure:
        include: health, info, metrics
```
`/actuator/health` para checagem de vida (útil para monitoramento, ver skill `monitorar-paginas-sistemas`);
**nunca** exponha `/actuator/env`/`/actuator/heapdump` publicamente — vazam configuração e memória da aplicação
(inclusive segredos), restrinja com Spring Security se precisar habilitar.

## Logs estruturados
```yaml
logging:
  level:
    com.minhaempresa: DEBUG
  pattern:
    console: "%d{ISO8601} %-5level [%thread] %logger{36} - %msg%n"
```
Para log em JSON (mais fácil de consumir por ferramenta de agregação de log), adicione `logstash-logback-encoder`
e configure o encoder no `logback-spring.xml`.

## Empacotar e rodar como serviço no Windows
```
mvn clean package
java -jar target/meuapp-0.0.1.jar
```
Ver skill `servicos-tarefas-agendadas-windows` para rodar o `.jar` como tarefa agendada com gatilho de inicialização
(caminho sem instalar NSSM), ou como serviço de verdade se o usuário já tiver ferramenta de wrapper.

## Regras
- Nunca coloque credencial de banco/API em `application.yml` versionado — variável de ambiente ou um cofre de
  segredos, referenciado via `${VARIAVEL}`.
- Sempre confira `mvn dependency:tree`/`gradlew dependencies` antes de "forçar" uma versão de dependência — conflito
  de versão transitiva é a causa mais comum de `NoSuchMethodError`/`ClassNotFoundException` em runtime que não
  aparece em tempo de compilação.
- Actuator exposto: sempre restrinja endpoints sensíveis antes de considerar o deploy pronto.

## Arquivos desta skill
Nenhum script fixo — os trechos acima cobrem os casos mais comuns; adapte ao projeto real do usuário.

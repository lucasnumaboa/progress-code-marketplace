# Origem e licença

Esta skill é uma cópia, com as alterações listadas abaixo, de material de especialista com licença aberta.

- **Fonte:** https://github.com/swan-gtm/gtm-skills
- **Arquivos de origem:** `skills/alon-goldenberg/competitor-monitoring/SKILL.md`, `skills/alon-goldenberg/competitor-monitoring/references/briefing-format.md`, `skills/alon-goldenberg/competitor-monitoring/references/query-patterns.md`, `skills/alon-goldenberg/competitor-monitoring/references/signal-validation.md`
- **Autor:** Alon Goldenberg (Nimbleway), na biblioteca Swan GTM Skills
- **Licença:** MIT (texto completo em `LICENSE`)
- **Commit:** `eb0026f469f90645e1a64168d08a3e0afb59ee12` (baixado em 2026-11-22)
- **Crédito do autor da skill:** `author.md` (incluído), como pede o repositório Swan.

## Alterações feitas

- `name:` do frontmatter trocado de `competitor-monitoring` para `swan-competitor-monitoring`.
- Fora isso, o texto do especialista está como no original (em inglês).

---
name: regex-multiplataforma
description: Escreve e testa expressões regulares que funcionam de verdade, com padrões prontos para CPF/CNPJ/CEP/datas/valores brasileiros e as diferenças de sintaxe entre engines (.NET/PowerShell, JavaScript, Python, Progress 4GL). Use quando o usuário pedir "uma regex para validar CPF/CNPJ", "expressão regular para extrair isso", "essa regex não funciona no PowerShell/Progress".
argument-hint: [o que a regex precisa capturar/validar] [linguagem/engine de destino]
---

# Expressões regulares que funcionam

## Padrões prontos (dados brasileiros)
```
CPF (so digitos, sem validar digito verificador): ^\d{3}\.?\d{3}\.?\d{3}-?\d{2}$
CNPJ (so digitos, sem validar digito verificador): ^\d{2}\.?\d{3}\.?\d{3}\/?\d{4}-?\d{2}$
CEP: ^\d{5}-?\d{3}$
Data dd/mm/aaaa: ^(0[1-9]|[12]\d|3[01])\/(0[1-9]|1[0-2])\/\d{4}$
Valor em reais: ^R?\$?\s?\d{1,3}(\.\d{3})*(,\d{2})?$
Telefone BR (fixo/celular, com/sem DDD e 9): ^(\(?\d{2}\)?\s?)?9?\d{4}-?\d{4}$
E-mail (pragmatico, nao 100% RFC): ^[^\s@]+@[^\s@]+\.[^\s@]+$
```
**Importante**: regex de CPF/CNPJ acima só confere o *formato* (quantidade de dígitos), não o dígito verificador —
para validar de verdade, calcule o dígito verificador em código (não dá para fazer isso só com regex); ver a skill
`validar-cpf-cnpj-cep` para o algoritmo completo.

## Diferenças de engine que mordem
| Recurso | .NET/PowerShell | JavaScript | Python (`re`) | Progress 4GL |
|---|---|---|---|---|
| Grupo nomeado | `(?<nome>...)` | `(?<nome>...)` | `(?P<nome>...)` | não suportado |
| Lookbehind | suportado, tamanho variável ok | suportado (motores modernos) | suportado, **tamanho fixo apenas** | não suportado |
| Case-insensitive | `(?i)` ou opção `-i` | flag `i` | `re.IGNORECASE`/`(?i)` | função `MATCHES()` só faz match simples, sem regex completa |
| Unicode `\w` | inclui acentuados por padrão | depende da flag `u` | inclui acentuados por padrão (`re.UNICODE` já é padrão no Python 3) | N/A |

Em **Progress 4GL/ABL** não existe motor de regex completo embutido — `MATCHES()` usa um padrão de glob simplificado
(`*`, `~`, não regex de verdade); para regex real em ABL é preciso chamar uma função .NET/Java externa ou tratar o
texto caractere a caractere. Sempre avise isso antes de escrever uma "regex" para código Progress.

## Testar antes de aplicar em produção
Nunca entregue uma regex sem testar contra pelo menos: um caso que deveria bater, um caso que não deveria bater, e
um caso "quase igual" que é a armadilha mais comum (ex.: para CPF, um CNPJ não deveria bater e vice-versa).
```python
import re
padrao = re.compile(r"^\d{3}\.?\d{3}\.?\d{3}-?\d{2}$")
for teste in ["123.456.789-00", "12345678900", "123.456.789-0", "abc"]:
    print(teste, bool(padrao.match(teste)))
```

## Regras
- Nunca use regex para validar dígito verificador de CPF/CNPJ — isso é aritmética, não correspondência de padrão;
  uma regex que "parece" validar isso está apenas conferindo formato e vai aceitar números inválidos.
- Cuidado com regex gulosa (`.*`) em texto com múltiplas ocorrências do delimitador — prefira `.*?` (não-gulosa)
  quando a intenção é "até a primeira ocorrência", não "até a última".
- Ao portar uma regex entre linguagens, sempre teste de novo na linguagem de destino — sintaxe visualmente igual
  pode ter semântica diferente (ex.: `\d` inclui dígitos não-ASCII em algumas engines Unicode e não em outras).

## Arquivos desta skill
Nenhum script fixo — os padrões acima são o ponto de partida; adapte à validação/extração real pedida.

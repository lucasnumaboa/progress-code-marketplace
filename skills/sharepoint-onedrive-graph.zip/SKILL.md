---
name: sharepoint-onedrive-graph
description: Lista, baixa, sobe e versiona documentos e itens de lista do SharePoint/OneDrive via Microsoft Graph API, com atenção a permissões. Use quando o usuário pedir para "buscar esse arquivo no SharePoint", "subir esses arquivos para o OneDrive", "ler os itens dessa lista do SharePoint".
argument-hint: [site/pasta do SharePoint ou OneDrive] [operação]
---

# SharePoint e OneDrive via Graph API

## Autenticação
Ver skill `oauth2-login-servicos` — normalmente client credentials (aplicação, sem usuário) para automação em
background, ou authorization code se a ação deve ser "em nome do usuário logado" (aparece como ele no histórico de
versão).

## Passo 1 — Encontrar o site/drive certo
```python
resp = requests.get("https://graph.microsoft.com/v1.0/sites?search=nome-do-site",
                     headers={"Authorization": f"Bearer {token}"})
site_id = resp.json()["value"][0]["id"]

resp = requests.get(f"https://graph.microsoft.com/v1.0/sites/{site_id}/drives",
                     headers={"Authorization": f"Bearer {token}"})
drive_id = resp.json()["value"][0]["id"]
```
Confirme com o usuário qual site/biblioteca é o certo antes de prosseguir — nomes parecidos entre sites diferentes
são comuns em organizações grandes.

## Passo 2 — Listar arquivos de uma pasta
```python
requests.get(f"https://graph.microsoft.com/v1.0/drives/{drive_id}/root:/{caminho_pasta}:/children",
             headers={"Authorization": f"Bearer {token}"})
```

## Passo 3 — Baixar
```python
resp = requests.get(f"https://graph.microsoft.com/v1.0/drives/{drive_id}/root:/{caminho_arquivo}:/content",
                     headers={"Authorization": f"Bearer {token}"})
with open(nome_local, "wb") as f:
    f.write(resp.content)
```

## Passo 4 — Subir (pequeno vs. grande)
```python
# arquivos ate 4MB - PUT direto
with open(caminho_local, "rb") as f:
    requests.put(f"https://graph.microsoft.com/v1.0/drives/{drive_id}/root:/{caminho_destino}:/content",
                 headers={"Authorization": f"Bearer {token}"}, data=f)
```
Acima de 4MB, crie uma "upload session" (`POST .../createUploadSession`) e envie em pedaços — ver skill
`downloads-uploads-em-massa`, passo 4, para o mesmo padrão.

## Passo 5 — Ler itens de uma lista do SharePoint (não biblioteca de documentos)
```python
requests.get(f"https://graph.microsoft.com/v1.0/sites/{site_id}/lists/{list_id}/items?expand=fields",
             headers={"Authorization": f"Bearer {token}"})
```

## Passo 6 — Versionamento
```python
requests.get(f"https://graph.microsoft.com/v1.0/drives/{drive_id}/items/{item_id}/versions",
             headers={"Authorization": f"Bearer {token}"})
```
Todo `PUT`/upload de conteúdo sobre um arquivo existente já cria uma nova versão automaticamente (se o
versionamento estiver habilitado na biblioteca) — não é preciso um passo separado para "versionar".

## Regras
- Antes de sobrescrever um arquivo existente, confirme com o usuário — mesmo com versionamento, restaurar uma
  versão anterior no meio de um fluxo automatizado gera confusão.
- Permissões: a aplicação/usuário usado no token precisa ter acesso ao site/biblioteca específica — erro `403`
  geralmente é isso, não bug de código; confirme o acesso antes de assumir que a API está com problema.
- Caminhos com caracteres especiais/acentos: sempre faça URL-encode do `caminho_pasta`/`caminho_arquivo` antes de
  montar a URL.

## Arquivos desta skill
Nenhum script fixo — os trechos acima cobrem os casos mais comuns; adapte ao site/biblioteca reais do usuário.

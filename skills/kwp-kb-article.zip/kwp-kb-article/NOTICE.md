# Origem

Skill de especialista empacotada para o marketplace do Progress Code (id `kwp-kb-article`).

- Repositório: https://github.com/anthropics/knowledge-work-plugins
- Caminho: `customer-support/skills/kb-article`
- Autor: Anthropic
- Titular: Anthropic (o texto Apache-2.0 em `LICENSE` não traz linha de copyright preenchida)
- Licença: Apache-2.0 (texto completo em `LICENSE`, copiado de `customer-support/LICENSE` no repositório)
- Commit: `0e0fcacddcc892eb92a1b7873ff9d68159c47571` (baixado em 2026-11-22)

## Arquivos incluídos

- `SKILL.md` (de `customer-support/skills/kb-article/SKILL.md`)

## Mudanças feitas

1. Frontmatter: `name:` trocado de `kb-article` para `kwp-kb-article` (a descrição foi mantida).
2. Removida a linha que manda consultar `CONNECTORS.md` (regras de conectores do Cowork).
3. A notação `~~email`, `~~chat`, `~~knowledge base` etc. do texto original significa "a ferramenta dessa categoria que estiver disponível"; foi mantida como está.

O texto do especialista foi mantido em inglês, sem tradução.
Conforme a Apache-2.0 (seção 4b), este aviso registra que os arquivos acima foram modificados.

# Aviso de terceiros (NOTICE)

Esta skill é uma cópia adaptada de material de terceiros e é redistribuída sob a licença original. O texto do especialista ficou em inglês, como no original.

- **Origem:** https://github.com/swan-gtm/gtm-skills
- **Caminho no repositório:** `skills/alex-vacca/signal-sourcer`
- **Commit:** `eb0026f469f90645e1a64168d08a3e0afb59ee12` (baixado em 2026-11-22)
- **Autor:** Alex Vacca (autor da skill); copyright do repositório: Swan
- **Licença:** MIT (texto completo em `LICENSE`, copiado de `LICENSE` do repositório)

## Arquivos incluídos

- `SKILL.md` (de `skills/alex-vacca/signal-sourcer/SKILL.md`)
- `references/buying-signals.md` (de `skills/alex-vacca/signal-sourcer/references/buying-signals.md`)
- `references/company-events.md` (de `skills/alex-vacca/signal-sourcer/references/company-events.md`)
- `references/competitor-signals.md` (de `skills/alex-vacca/signal-sourcer/references/competitor-signals.md`)
- `references/content-engagement.md` (de `skills/alex-vacca/signal-sourcer/references/content-engagement.md`)
- `references/funding.md` (de `skills/alex-vacca/signal-sourcer/references/funding.md`)
- `references/gtm-plays.md` (de `skills/alex-vacca/signal-sourcer/references/gtm-plays.md`)
- `references/hiring.md` (de `skills/alex-vacca/signal-sourcer/references/hiring.md`)
- `references/job-change-tracking.md` (de `skills/alex-vacca/signal-sourcer/references/job-change-tracking.md`)
- `references/job-changes.md` (de `skills/alex-vacca/signal-sourcer/references/job-changes.md`)
- `references/multi-signal.md` (de `skills/alex-vacca/signal-sourcer/references/multi-signal.md`)
- `references/signal-detection-tools.md` (de `skills/alex-vacca/signal-sourcer/references/signal-detection-tools.md`)
- `references/signal-scoring.md` (de `skills/alex-vacca/signal-sourcer/references/signal-scoring.md`)
- `references/signal-taxonomy.md` (de `skills/alex-vacca/signal-sourcer/references/signal-taxonomy.md`)
- `references/tech-changes.md` (de `skills/alex-vacca/signal-sourcer/references/tech-changes.md`)
- `references/tool-setup-guides.md` (de `skills/alex-vacca/signal-sourcer/references/tool-setup-guides.md`)
- `references/website-visitors.md` (de `skills/alex-vacca/signal-sourcer/references/website-visitors.md`)
- `author.md` (de `skills/alex-vacca/author.md`, crédito do autor pedido pelo repositório)
- `LICENSE`

## Mudanças feitas

- Frontmatter: `name: signal-sourcer` trocado por `name: swan-signal-sourcer` (a descrição ficou igual).
- `SKILL.md`: removido o rodapé de divulgação "_Part of [Frontal](https://frontal.so) — free, open GTM skills for your AI agent. [Browse the library →](...)_" (chamada para a biblioteca da empresa do autor).
- `references/company-events.md`: removido o rodapé de divulgação "_Part of [Frontal](https://frontal.so) — free, open GTM skills for your AI agent. [Browse the library →](...)_" (chamada para a biblioteca da empresa do autor).
- `references/competitor-signals.md`: removido o rodapé de divulgação "_Part of [Frontal](https://frontal.so) — free, open GTM skills for your AI agent. [Browse the library →](...)_" (chamada para a biblioteca da empresa do autor).
- `references/content-engagement.md`: removido o rodapé de divulgação "_Part of [Frontal](https://frontal.so) — free, open GTM skills for your AI agent. [Browse the library →](...)_" (chamada para a biblioteca da empresa do autor).
- `references/funding.md`: removido o rodapé de divulgação "_Part of [Frontal](https://frontal.so) — free, open GTM skills for your AI agent. [Browse the library →](...)_" (chamada para a biblioteca da empresa do autor).
- `references/hiring.md`: removido o rodapé de divulgação "_Part of [Frontal](https://frontal.so) — free, open GTM skills for your AI agent. [Browse the library →](...)_" (chamada para a biblioteca da empresa do autor).
- `references/job-changes.md`: removido o rodapé de divulgação "_Part of [Frontal](https://frontal.so) — free, open GTM skills for your AI agent. [Browse the library →](...)_" (chamada para a biblioteca da empresa do autor).
- `references/multi-signal.md`: removido o rodapé de divulgação "_Part of [Frontal](https://frontal.so) — free, open GTM skills for your AI agent. [Browse the library →](...)_" (chamada para a biblioteca da empresa do autor).
- `references/tech-changes.md`: removido o rodapé de divulgação "_Part of [Frontal](https://frontal.so) — free, open GTM skills for your AI agent. [Browse the library →](...)_" (chamada para a biblioteca da empresa do autor).
- `references/website-visitors.md`: removido o rodapé de divulgação "_Part of [Frontal](https://frontal.so) — free, open GTM skills for your AI agent. [Browse the library →](...)_" (chamada para a biblioteca da empresa do autor).

## Crédito do autor (author.md)

O repositório pede que o crédito do autor acompanhe a skill. Conteúdo do `author.md` original:

```markdown
---
name: Alex Vacca
avatarUrl: "https://www.gtmskills.com/authors/alex-vacca.jpg"
title: "Founder & CEO @ Frontal"
linkedinUrl: "https://linkedin.com/in/alex-vacca"
companyDomain: frontal.so
---

Founder and CEO of Frontal (formerly ColdIQ) — the revenue-systems team behind 275+ B2B companies and one of four Clay Elite Studio partners worldwide. Frontal builds signal-driven revenue engines: clean data, buying signals, and triggered plays wired into HubSpot, Salesforce, and Clay, with results like $7.83M in qualified pipeline for AirOps. Alex's open outbound skills encode how Frontal actually runs cold email, Clay, list building, and signal-based selling.
```

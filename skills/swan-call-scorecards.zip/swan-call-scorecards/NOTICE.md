# Aviso de terceiros (NOTICE)

Esta skill é uma cópia adaptada de material de terceiros e é redistribuída sob a licença original. O texto do especialista ficou em inglês, como no original.

- **Origem:** https://github.com/swan-gtm/gtm-skills
- **Caminho no repositório:** `skills/kevin-kd-dorsey/call-scorecards`
- **Commit:** `eb0026f469f90645e1a64168d08a3e0afb59ee12` (baixado em 2026-11-22)
- **Autor:** Kevin \ (autor da skill); copyright do repositório: Swan
- **Licença:** MIT (texto completo em `LICENSE`, copiado de `LICENSE` do repositório)

## Arquivos incluídos

- `SKILL.md` (de `skills/kevin-kd-dorsey/call-scorecards/SKILL.md`)
- `references/closing-scorecard.md` (de `skills/kevin-kd-dorsey/call-scorecards/references/closing-scorecard.md`)
- `references/prospecting-scorecard.md` (de `skills/kevin-kd-dorsey/call-scorecards/references/prospecting-scorecard.md`)
- `author.md` (de `skills/kevin-kd-dorsey/author.md`, crédito do autor pedido pelo repositório)
- `LICENSE`

## Mudanças feitas

- Frontmatter: `name: call-scorecards` trocado por `name: swan-call-scorecards` (a descrição ficou igual).

## Crédito do autor (author.md)

O repositório pede que o crédito do autor acompanhe a skill. Conteúdo do `author.md` original:

```markdown
---
name: "Kevin \"KD\" Dorsey"
avatarUrl: "https://www.gtmskills.com/authors/kevin-kd-dorsey.jpg"
title: CRO
linkedinUrl: "https://linkedin.com/in/kddorsey3"
companyDomain: leanscaper.com
---

CRO at LeanScaper and founder of the Sales Leadership Accelerator. Teaches sales leaders the systems behind scale — playbooks, call scorecards, coaching, and hiring — built over years of running SaaS sales orgs.
```

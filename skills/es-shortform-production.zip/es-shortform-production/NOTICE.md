# Origem e mudanças

- **Repositório:** https://github.com/ericosiu/ai-marketing-skills
- **Caminho no repositório:** `shortform-production`
- **Autor:** Single Grain
- **Licença:** MIT (texto em `LICENSE`)
- **Commit usado:** `c715f900e3a7c1f4274976ca851849d9a7c3fe55`
- **Arquivos copiados:** `SKILL.md`, `references/creative-formats.md`, `references/eval/judge-prompt.md`, `references/eval/references.json`, `references/eval/rubric.json`, `references/eval/scorecard.schema.json`, `references/metricool.md`, `references/next-batch.md`, `references/review-and-learning.md`, `references/v5-style.md`

## Mudanças feitas

- no cabeçalho (frontmatter), `name:` passou de `shortform-production` para `es-shortform-production`; a descrição ficou igual
- removido o bloco "Preamble" (checagem de versão e telemetria do repositório)
- removido o bloco "Run this skill on live data" (chamada comercial para o Single Brain Gateway e contato da agência Single Grain)
- nenhuma outra alteração no texto do especialista (mantido em inglês)

## Observações

- não foi incluído `scripts/metricool.py` (entrega pela API paga do Metricool); `references/metricool.md` ficou só como referência

Empacotada para o marketplace do Progress Code em 2026-11-22.

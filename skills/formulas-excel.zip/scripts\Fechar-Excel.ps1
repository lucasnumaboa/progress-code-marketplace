<#
.SYNOPSIS
    Salva e fecha a pasta de trabalho com seguranca. Por padrao NAO fecha o aplicativo Excel inteiro,
    so a pasta de trabalho, para nao derrubar outras planilhas que o usuario tenha abertas.
.PARAMETER Arquivo
    Caminho completo do arquivo aberto.
.PARAMETER Salvar
    Se presente, salva antes de fechar (recomendado). Sem este switch, as alteracoes sao DESCARTADAS -
    so use assim se o usuario pediu explicitamente para nao salvar.
.PARAMETER FecharExcel
    Se presente, fecha o aplicativo Excel inteiro depois de fechar a pasta de trabalho (so se nao houver
    mais nenhuma outra pasta de trabalho aberta). Use somente se o usuario pedir para fechar o Excel.
.EXAMPLE
    powershell -File Fechar-Excel.ps1 -Arquivo "C:\dados\vendas.xlsx" -Salvar
#>
param(
    [Parameter(Mandatory = $true)][string]$Arquivo,
    [switch]$Salvar,
    [switch]$FecharExcel
)

$ErrorActionPreference = 'Stop'
$Arquivo = (Resolve-Path -LiteralPath $Arquivo -ErrorAction Stop).Path

try {
    $excel = [Runtime.InteropServices.Marshal]::GetActiveObject("Excel.Application")
} catch {
    Write-Error "Nao ha instancia do Excel aberta."
    exit 1
}

$wb = $null
foreach ($w in $excel.Workbooks) {
    if ($w.FullName -ieq $Arquivo) { $wb = $w; break }
}
if (-not $wb) {
    Write-Error "O arquivo '$Arquivo' nao esta entre as pastas de trabalho abertas."
    exit 1
}

if ($Salvar) {
    $wb.Save()
    Write-Host "Salvo: $Arquivo"
} else {
    Write-Warning "Fechando SEM salvar - alteracoes desde a ultima gravacao serao perdidas."
}

$wb.Close($Salvar.IsPresent)
Write-Host "Pasta de trabalho fechada."

if ($FecharExcel) {
    if ($excel.Workbooks.Count -eq 0) {
        $excel.Quit()
        Write-Host "Excel encerrado (nenhuma outra pasta de trabalho estava aberta)."
    } else {
        Write-Host "Excel NAO encerrado: ainda ha $($excel.Workbooks.Count) outra(s) pasta(s) de trabalho aberta(s)."
    }
}

[System.Runtime.InteropServices.Marshal]::ReleaseComObject($wb) | Out-Null

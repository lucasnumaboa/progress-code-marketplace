<#
.SYNOPSIS
    Grava uma formula numa celula (ou preenche um intervalo com a mesma formula relativa) numa pasta de
    trabalho ja aberta pelo Excel, e devolve o resultado calculado.
.PARAMETER Arquivo
    Caminho completo do arquivo ja aberto (rode Abrir-Planilha.ps1 antes).
.PARAMETER Aba
    Nome da aba/planilha.
.PARAMETER Celula
    Celula onde a formula sera escrita primeiro, ex.: "D2".
.PARAMETER Formula
    Formula em INGLES com VIRGULA como separador de argumentos, ex.: "=IFERROR(VLOOKUP(A2,Table1,3,FALSE),\"\")".
    Nunca use nomes de funcao em portugues aqui, mesmo que o Excel esteja em portugues.
.PARAMETER Matricial
    Use quando a formula precisa ser confirmada como formula de matriz classica (equivalente a Ctrl+Shift+Enter),
    porque o teste em Testar-Funcoes.ps1 mostrou que esta instalacao NAO tem matrizes dinamicas. Nao use em
    instalacoes com matrizes dinamicas (o spill automatico ja resolve).
.PARAMETER Preencher
    Intervalo opcional (ex.: "D2:D500") para copiar a mesma formula (com referencias relativas ajustadas) para
    varias linhas de uma vez, em vez de chamar o script repetidas vezes.
.EXAMPLE
    powershell -File Escrever-Formula.ps1 -Arquivo "C:\dados\vendas.xlsx" -Aba "Plan1" -Celula "D2" `
        -Formula "=IFERROR(VLOOKUP(A2,Table1,3,FALSE),\"\")" -Preencher "D2:D500"
#>
param(
    [Parameter(Mandatory = $true)][string]$Arquivo,
    [Parameter(Mandatory = $true)][string]$Aba,
    [Parameter(Mandatory = $true)][string]$Celula,
    [Parameter(Mandatory = $true)][string]$Formula,
    [switch]$Matricial,
    [string]$Preencher
)

$ErrorActionPreference = 'Stop'
$Arquivo = (Resolve-Path -LiteralPath $Arquivo -ErrorAction Stop).Path

try {
    $excel = [Runtime.InteropServices.Marshal]::GetActiveObject("Excel.Application")
} catch {
    Write-Error "Nao ha instancia do Excel aberta. Rode Abrir-Planilha.ps1 primeiro, na mesma sessao de terminal."
    exit 1
}

$wb = $null
foreach ($w in $excel.Workbooks) {
    if ($w.FullName -ieq $Arquivo) { $wb = $w; break }
}
if (-not $wb) {
    Write-Error "O arquivo '$Arquivo' nao esta entre as pastas de trabalho abertas. Rode Abrir-Planilha.ps1 primeiro."
    exit 1
}

$ws = $null
foreach ($s in $wb.Worksheets) {
    if ($s.Name -ieq $Aba) { $ws = $s; break }
}
if (-not $ws) {
    Write-Error "Aba '$Aba' nao encontrada. Abas disponiveis: $(($wb.Worksheets | ForEach-Object { $_.Name }) -join ', ')"
    exit 1
}

$range = $ws.Range($Celula)

try {
    if ($Matricial) {
        $range.FormulaArray = $Formula
    } else {
        $range.Formula = $Formula
    }
} catch {
    Write-Error "Excel rejeitou a formula (sintaxe invalida ou funcao inexistente nesta instalacao): $($_.Exception.Message)"
    exit 1
}

if ($Preencher) {
    $destino = $ws.Range($Preencher)
    $range.AutoFill($ws.Range($range.Address(), $destino), 0) | Out-Null  # 0 = xlFillDefault
}

Start-Sleep -Milliseconds 30
$texto = [string]$range.Text
$ehErro = $texto.StartsWith("#")

Write-Host "Formula gravada em $Aba!$Celula"
Write-Host "Texto calculado    : $texto"
Write-Host "Formula (ingles)   : $($range.Formula)"
Write-Host "Formula (traduzida): $($range.FormulaLocal)"
if ($ehErro) {
    Write-Warning "A celula retornou um erro ($texto). Consulte referencia/erros-comuns.md antes de tentar de novo."
} else {
    Write-Host "OK: sem erro."
}
if ($Preencher) {
    Write-Host "Preenchido em $Preencher (AutoFill a partir de $Celula)."
}

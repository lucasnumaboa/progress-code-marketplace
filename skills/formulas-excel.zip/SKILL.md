---
name: formulas-excel
description: Abre uma planilha Excel de verdade (via automação COM no Windows) e cria, corrige ou explica fórmulas nela, testando ao vivo se cada função existe naquela instalação específica antes de usá-la — assim funciona tanto no Excel 2007/2010/2013/2016/2019 quanto no 2021, 2024 ou Microsoft 365, e tanto em instalação em português quanto em inglês. Use quando o usuário pedir para "criar uma fórmula no Excel", "montar um PROCV/XLOOKUP", "corrigir #REF!/#NAME?/#VALUE!", "abrir essa planilha e preencher a coluna com fórmula", "essa fórmula não funciona no Excel dele", ou citar arquivos .xlsx/.xlsm/.xls.
argument-hint: [caminho da planilha] [o que a fórmula deve calcular]
---

# Fórmulas de Excel (dinâmico por versão e idioma)

## Por que essa skill existe

Duas armadilhas matam fórmulas feitas "de cabeça":

1. **Versão do Excel.** `XLOOKUP`, `FILTRO`/`FILTER`, `ÚNICO`/`UNIQUE`, `LET`, `LAMBDA`, `SES`/`IFS`, `SOMASES`/`MAXIFS`/`MINIFS`,
   `UNIRTEXTO`/`TEXTJOIN`, matrizes dinâmicas (spill) — nada disso existe em qualquer Excel. `Application.Version`
   sozinho **não resolve**: Excel 2016, 2019, 2021, 2024 e Microsoft 365 todos reportam `"16.0"`. A única forma
   confiável de saber se uma função existe é **testar ao vivo na instalação real** (passo 3).
2. **Idioma da interface.** Em Excel português (pt-BR), o usuário vê `SE`, `PROCV`, `SOMASE` na tela e usa `;` como
   separador de argumentos. Mas ao escrever fórmulas por automação (COM), você **sempre** usa a propriedade
   `.Formula` com nomes em **inglês** e **vírgula** — o Excel exibe traduzido para o usuário sozinho. Isso elimina o
   problema do idioma na escrita; ele só volta quando você precisa **ler em voz alta** ou **explicar** uma fórmula
   para o usuário (aí sim traduza, ver `referencia/funcoes-pt-br.md`).

Regra de ouro: **nunca declare "essa função existe nessa versão" de memória.** Teste (passo 3) ou consulte
`referencia/funcoes-por-versao.md` e, na dúvida, teste mesmo assim — a tabela é um guia, o teste ao vivo é a verdade.

Todos os scripts desta skill já estão no PATH da ferramenta Bash/PowerShell da conversa — chame pelo nome do arquivo.
São PowerShell (`.ps1`) porque a automação COM do Excel só existe no Windows.

## Passo 1 — Confirmar o arquivo e abrir o Excel

1. Confirme com Glob/Read que o arquivo existe. Se o usuário não deu caminho, PARE e pergunte qual arquivo (não
   invente um caminho).
2. Se o arquivo pode ter alterações não salvas de outra fonte, avise o usuário antes de abrir por automação.
3. Execute:
   ```
   powershell -File Abrir-Planilha.ps1 -Arquivo "<caminho completo>"
   ```
   Isso abre o Excel **visível** (o usuário acompanha na tela) e reaproveita uma instância já aberta com esse
   arquivo, se existir. A saída lista as abas e a versão bruta do Excel (`Application.Version`).
4. Se o script falhar com "Excel não está instalado" ou erro de COM, PARE: essa skill não funciona sem o Excel
   instalado no Windows local. Nesse caso, ofereça a skill `xlsx` (edição de planilha sem abrir o Excel de verdade,
   mas sem conseguir calcular nem testar fórmulas ao vivo) como alternativa e explique a diferença ao usuário.

## Passo 2 — Descobrir a edição instalada (contexto, não decisão)

Execute:
```
powershell -File Detectar-Excel.ps1
```
Isso devolve `Application.Version`, o idioma da interface (via `LanguageSettings`) e, quando possível, a edição via
registro do Windows (Click-to-Run = Microsoft 365 / assinatura; MSI + `ProPlus20XXVolume`/`Retail` = versão perpetua
de um ano fixo — 2019, 2021, 2024). Use isso só como **contexto** para a conversa com o usuário ("parece ser Microsoft
365" / "parece ser Excel 2019 perpétuo"). **Não decida quais funções usar com base só nisso** — vá para o passo 3.

## Passo 3 — Testar ao vivo quais funções modernas existem (o passo que importa)

Antes de usar qualquer função lançada depois do Excel 2007, teste-a nessa instalação:
```
powershell -File Testar-Funcoes.ps1 -Arquivo "<caminho completo>" -Funcoes XLOOKUP,LET,LAMBDA,FILTER,UNIQUE,IFS,TEXTJOIN
```
Sem `-Funcoes`, o script testa a lista inteira em `referencia/testes-de-funcao.json` (todas as funções pós-2007 com
teste conhecido) e imprime uma linha por função: `NOME: suportada` ou `NOME: NAO suportada (#NAME?)`. Internamente ele
cria uma aba temporária oculta, escreve cada fórmula de teste, lê o resultado e apaga a aba — não altera a planilha
do usuário nem salva nada.

**Interpretação:** o script usa `.Text` da célula. Se começar com `#NAME?`, a função não existe nessa instalação —
qualquer outro resultado (número, texto, `#N/A`, `#VALUE!` etc.) significa que a função **existe** (o erro, se houver,
é por causa dos argumentos de teste, não por a função ser desconhecida).

Se uma função não estiver disponível, abra `referencia/funcoes-por-versao.md`, ache a linha da função e use o
"equivalente clássico" listado lá (ex.: sem `XLOOKUP` → `INDEX+MATCH`; sem `IFS` → `IF` aninhado; sem `TEXTJOIN` →
`CONCATENATE`/`&`; sem matriz dinâmica → fórmula de matriz clássica com `-Matricial` no passo 4).

## Passo 4 — Escrever a fórmula

```
powershell -File Escrever-Formula.ps1 -Arquivo "<caminho>" -Aba "Plan1" -Celula "D2" -Formula "=SEERRO(PROCV(A2,Tabela1,3,FALSO),\"\")"
```
Regras de uso:
- `-Formula` sempre em **inglês, com vírgula** (`IFERROR`, `VLOOKUP`, `,`), nunca em português — é isso que a
  propriedade `.Formula` exige, mesmo com o Excel em pt-BR. O exemplo acima está errado de propósito: o certo é
  `-Formula "=IFERROR(VLOOKUP(A2,Table1,3,FALSE),\"\")"`.
- Fórmula que deve se replicar por uma coluna inteira: escreva uma vez com `-Celula "D2"` e depois use
  `-Preencher "D2:D500"` (ver a ajuda do próprio script, `Get-Help .\Escrever-Formula.ps1 -Full`) em vez de chamar o
  script centenas de vezes.
- Fórmula de matriz **numa versão sem matrizes dinâmicas** (passo 3 disse que `FILTER`/`UNIQUE`/etc. não existem):
  adicione `-Matricial`. O script usa `Range.FormulaArray` (equivalente a digitar e confirmar com Ctrl+Shift+Enter).
  Em versão com matrizes dinâmicas, nunca use `-Matricial` — a fórmula normal já "derrama" (spill) sozinha.
- O script sempre imprime de volta o texto calculado da célula (`Range.Text`) e avisa se é um erro. Leia essa saída;
  não assuma que a fórmula funcionou só porque o script não retornou código de erro do PowerShell.

## Passo 5 — Se der erro, diagnosticar antes de tentar de novo

Abra `referencia/erros-comuns.md`, ache o erro exato (`#REF!`, `#N/A`, `#VALUE!`, `#NAME?`, `#SPILL!`, `#CALC!`...) e
siga a causa mais provável listada. Use `Ler-Celula.ps1` para inspecionar células vizinhas/dependências antes de
mudar a fórmula:
```
powershell -File Ler-Celula.ps1 -Arquivo "<caminho>" -Aba "Plan1" -Celula "A2"
```
Ele mostra valor calculado, texto exibido, a fórmula em inglês (`.Formula`) e a fórmula traduzida como o usuário vê
(`.FormulaLocal`) — útil para conferir com o usuário "é isso que você digitou?".

Não repita a mesma tentativa mais de 3 vezes seguidas sem mudar de abordagem. Se travar, mostre o erro completo ao
usuário e pergunte antes de tentar um caminho bem diferente (ex.: trocar a estrutura da planilha).

## Passo 6 — Salvar e fechar com cuidado

```
powershell -File Fechar-Excel.ps1 -Arquivo "<caminho>" -Salvar
```
- Por padrão o script **fecha só a pasta de trabalho**, não o Excel inteiro — assim não derruba outras planilhas que
  o usuário possa ter abertas. Só use `-FecharExcel` se o usuário pedir para fechar o Excel de vez.
- Nunca use `-Salvar:$false` (descartar alterações) sem confirmar antes com o usuário, a menos que ele já tenha
  pedido explicitamente para não salvar.
- Se o arquivo original é `.xls` (formato antigo) e você usou função introduzida depois do Excel 2007, avise: o
  `.xls` binário não suporta essas fórmulas e o Excel vai gravar `#NAME?` ao reabrir em outra máquina com Excel
  antigo. Sugira salvar como `.xlsx`.

## Regras gerais

- **Nunca invente se uma função existe.** Teste (passo 3) ou consulte a tabela; se não puder testar (Excel não
  instalado), diga isso ao usuário em vez de afirmar.
- **Nunca escreva fórmula em português na automação.** `.Formula` é sempre inglês/vírgula. Só traduza para explicar
  ao usuário em conversa, usando `referencia/funcoes-pt-br.md`.
- **Não peça para o usuário digitar nada manualmente** quando for possível fazer por automação — exceção: senhas,
  proteção de planilha, ou passos que exigem interação visual que a automação não alcança (ex.: um suplemento de
  terceiros). Nesses casos, explique exatamente o que clicar.
- **Backup antes de mudanças grandes**: se for alterar dezenas de fórmulas de uma vez numa planilha existente, copie
  o arquivo (`Copy-Item`) para `<nome>.bak.xlsx` antes, e diga ao usuário onde está o backup.
- **Sem Excel instalado / Linux / Mac / servidor**: esta skill não se aplica (COM é Windows+Excel instalado). Use a
  skill `xlsx` para editar o arquivo diretamente sem abrir o Excel — mas deixe claro que, sem o Excel de verdade,
  não dá para calcular nem confirmar se uma função existe naquela versão; só para gravar o texto da fórmula.
- **Planilhas protegidas/compartilhadas**: se `Escrever-Formula.ps1` falhar por proteção de planilha ou arquivo
  somente leitura, PARE e pergunte a senha/permissão ao usuário — nunca tente contornar proteção.

## Arquivos desta skill

- `scripts/Abrir-Planilha.ps1` — abre/anexa o Excel a um arquivo.
- `scripts/Detectar-Excel.ps1` — versão bruta, idioma, edição (Microsoft 365 vs perpétuo) por registro do Windows.
- `scripts/Testar-Funcoes.ps1` — testa ao vivo quais funções existem, usando `referencia/testes-de-funcao.json`.
- `scripts/Escrever-Formula.ps1` — grava uma fórmula (normal, matricial ou preenchendo um intervalo) e devolve o
  resultado calculado.
- `scripts/Ler-Celula.ps1` — lê valor, texto, fórmula em inglês e fórmula traduzida de uma célula.
- `scripts/Fechar-Excel.ps1` — salva e fecha com segurança.
- `referencia/funcoes-por-versao.md` — em qual ano/versão cada função apareceu, e o equivalente clássico para
  versões antigas.
- `referencia/funcoes-pt-br.md` — tradução inglês ↔ português das funções mais usadas, para explicar ao usuário.
- `referencia/erros-comuns.md` — o que significa e como corrigir cada erro de fórmula do Excel.
- `referencia/testes-de-funcao.json` — tabela usada por `Testar-Funcoes.ps1` (função, ano aproximado, fórmula de
  teste segura).

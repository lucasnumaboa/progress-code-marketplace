# Tradução de funções: inglês ↔ português (pt-BR)

Use esta tabela só para **explicar/ler** fórmulas com o usuário em conversa, ou para entender uma fórmula que ele
colou (que pode estar em `FormulaLocal`, isto é, em português com `;`). **Nunca** use os nomes em português no
parâmetro `-Formula` dos scripts desta skill — a propriedade `.Formula` do COM exige inglês + vírgula, mesmo com o
Excel instalado em português. O próprio Excel traduz para exibição sozinho.

Separador de argumentos: em inglês é vírgula `,`; em português (pt-BR) é ponto e vírgula `;` (porque a vírgula já é
o separador decimal em pt-BR). Separador de linha em constante de matriz: `\` em inglês vira `;` em português, e o
separador de coluna `,` em inglês vira `;` também em algumas versões — ao digitar direto na UI em pt-BR, sempre teste;
ao automatizar via `.Formula`, use sempre a sintaxe em inglês (vírgula para colunas, `;` para linhas em matrizes).

| Inglês | Português (pt-BR) | Categoria |
|---|---|---|
| IF | SE | Lógica |
| IFS | SES | Lógica |
| SWITCH | SWITCH / SE.VALOR | Lógica |
| IFERROR | SEERRO | Lógica |
| IFNA | SEND | Lógica |
| AND | E | Lógica |
| OR | OU | Lógica |
| NOT | NÃO | Lógica |
| VLOOKUP | PROCV | Busca |
| HLOOKUP | PROCH | Busca |
| LOOKUP | PROC | Busca |
| XLOOKUP | PROCX | Busca |
| XMATCH | CORRESPX | Busca |
| INDEX | ÍNDICE | Busca |
| MATCH | CORRESP | Busca |
| OFFSET | DESLOC | Busca |
| INDIRECT | INDIRETO | Busca |
| SUM | SOMA | Matemática |
| SUMIF | SOMASE | Matemática |
| SUMIFS | SOMASES | Matemática |
| SUMPRODUCT | SOMARPRODUTO | Matemática |
| AVERAGE | MÉDIA | Estatística |
| AVERAGEIF | MÉDIASE | Estatística |
| AVERAGEIFS | MÉDIASES | Estatística |
| MAX / MAXIFS | MÁXIMO / MÁXIMOSES | Estatística |
| MIN / MINIFS | MÍNIMO / MÍNIMOSES | Estatística |
| COUNT | CONT.NÚM | Estatística |
| COUNTA | CONT.VALORES | Estatística |
| COUNTBLANK | CONTAR.VAZIO | Estatística |
| COUNTIF | CONT.SE | Estatística |
| COUNTIFS | CONT.SES | Estatística |
| ROUND | ARRED | Matemática |
| ROUNDUP | ARREDONDAR.PARA.CIMA | Matemática |
| ROUNDDOWN | ARREDONDAR.PARA.BAIXO | Matemática |
| ABS | ABS | Matemática |
| SQRT | RAIZ | Matemática |
| RAND | ALEATÓRIO | Matemática |
| RANDBETWEEN | ALEATÓRIOENTRE | Matemática |
| TEXT | TEXTO | Texto |
| CONCATENATE / CONCAT | CONCATENAR / CONCAT | Texto |
| TEXTJOIN | UNIRTEXTO | Texto |
| LEFT | ESQUERDA | Texto |
| RIGHT | DIREITA | Texto |
| MID | EXT.TEXTO | Texto |
| LEN | NÚM.CARACT | Texto |
| UPPER | MAIÚSCULA | Texto |
| LOWER | MINÚSCULA | Texto |
| PROPER | PRI.MAIÚSCULA | Texto |
| TRIM | ARRUMAR | Texto |
| SUBSTITUTE | SUBSTITUIR | Texto |
| SEARCH | LOCALIZAR | Texto |
| FIND | PROCURAR | Texto |
| TEXTSPLIT | DIVIDIR.TEXTO | Texto |
| TEXTBEFORE | TEXTOANTES | Texto |
| TEXTAFTER | TEXTODEPOIS | Texto |
| TODAY | HOJE | Data/Hora |
| NOW | AGORA | Data/Hora |
| DATE | DATA | Data/Hora |
| DAY / MONTH / YEAR | DIA / MÊS / ANO | Data/Hora |
| DAYS | DIAS | Data/Hora |
| WEEKDAY | DIA.DA.SEMANA | Data/Hora |
| NETWORKDAYS | DIATRABALHOTOTAL | Data/Hora |
| WORKDAY | DIATRABALHO | Data/Hora |
| EDATE | DATAM | Data/Hora |
| ISERROR | ÉERROS | Informação |
| ISERR | ÉERRO | Informação |
| ISNA | É.NÃO.DISP | Informação |
| ISNUMBER | ÉNÚM | Informação |
| ISTEXT | ÉTEXTO | Informação |
| ISBLANK | ÉCÉL.VAZIA | Informação |
| TYPE | TIPO | Informação |
| FILTER | FILTRO | Matriz dinâmica |
| SORT | CLASSIFICAR | Matriz dinâmica |
| SORTBY | CLASSIFICARPOR | Matriz dinâmica |
| UNIQUE | ÚNICO | Matriz dinâmica |
| SEQUENCE | SEQUÊNCIA | Matriz dinâmica |
| RANDARRAY | MATRIZALEATÓRIA | Matriz dinâmica |
| LET | LET | Matriz/Lógica (nome igual) |
| LAMBDA | LAMBDA | Matriz/Lógica (nome igual) |
| VSTACK / HSTACK | EMPILHARV / EMPILHARH | Matriz dinâmica |
| TAKE / DROP | PEGAR / SOLTAR | Matriz dinâmica |
| CHOOSEROWS / CHOOSECOLS | ESCOLHERLINS / ESCOLHERCOLS | Matriz dinâmica |
| AGGREGATE | AGREGAR | Matemática |
| FORMULATEXT | FÓRMULATEXTO | Informação |

Para qualquer função não listada aqui, o nome em português normalmente aparece em **Fórmulas → Inserir Função**
dentro do próprio Excel, ou lendo `Range.FormulaLocal` numa célula com a fórmula já digitada pelo usuário
(`scripts/Ler-Celula.ps1` mostra os dois).

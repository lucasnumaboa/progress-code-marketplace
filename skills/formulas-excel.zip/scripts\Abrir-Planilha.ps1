<#
.SYNOPSIS
    Abre o Excel (ou reaproveita uma instância já aberta) e carrega a pasta de trabalho indicada.
.PARAMETER Arquivo
    Caminho completo do arquivo .xlsx/.xlsm/.xls.
.PARAMETER Visivel
    Se $true (padrão), o Excel fica visível na tela para o usuário acompanhar.
.EXAMPLE
    powershell -File Abrir-Planilha.ps1 -Arquivo "C:\dados\vendas.xlsx"
#>
param(
    [Parameter(Mandatory = $true)][string]$Arquivo,
    [bool]$Visivel = $true
)

$ErrorActionPreference = 'Stop'
$Arquivo = (Resolve-Path -LiteralPath $Arquivo -ErrorAction Stop).Path

try {
    $excel = [Runtime.InteropServices.Marshal]::GetActiveObject("Excel.Application")
    Write-Host "Reaproveitando instância do Excel já aberta."
} catch {
    try {
        $excel = New-Object -ComObject Excel.Application
        Write-Host "Nova instância do Excel criada."
    } catch {
        Write-Error "Excel não está instalado ou não pôde ser iniciado via COM neste computador. $($_.Exception.Message)"
        exit 1
    }
}

$excel.Visible = $Visivel
$excel.DisplayAlerts = $false

$wb = $null
foreach ($w in $excel.Workbooks) {
    if ($w.FullName -ieq $Arquivo) { $wb = $w; break }
}

if (-not $wb) {
    $wb = $excel.Workbooks.Open($Arquivo)
    Write-Host "Arquivo aberto: $Arquivo"
} else {
    Write-Host "Arquivo já estava aberto, reaproveitado: $Arquivo"
}

$excel.DisplayAlerts = $true

Write-Host "---"
Write-Host "Versao do Excel (Application.Version): $($excel.Version)"
Write-Host "Abas na pasta de trabalho:"
foreach ($ws in $wb.Worksheets) {
    Write-Host "  - $($ws.Name)"
}
Write-Host "---"
Write-Host "OK: planilha pronta para uso. Use Detectar-Excel.ps1 e Testar-Funcoes.ps1 antes de escrever formulas novas."

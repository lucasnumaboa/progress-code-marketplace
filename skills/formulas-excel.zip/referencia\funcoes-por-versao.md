# Funções por versão/ano do Excel

Esta tabela é um **guia de contexto**, não a fonte da verdade — o Excel 2016, 2019, 2021, 2024 e Microsoft 365 todos
reportam `Application.Version = "16.0"`, então a única forma confiável de saber se uma função existe numa instalação
específica é testar ao vivo com `scripts/Testar-Funcoes.ps1`. Use esta tabela para escolher o **equivalente clássico**
quando o teste mostrar que a função moderna não existe.

Legenda de "introduzida": ano da primeira aparição em qualquer canal. "Microsoft 365" quer dizer que só existe em
assinatura (recebe atualizações contínuas) e não em nenhuma versão perpétua até a data indicada.

## Excel 2007 (primeira versão .xlsx)
Introduziu: `IFERROR`, `SUMIFS`, `COUNTIFS`, `AVERAGEIFS`, tabelas formatadas (Tabela1[Coluna]), formatação
condicional avançada. Antes disso (2003 e anteriores, `.xls`), use `IF(ISERROR(...),...)` no lugar de `IFERROR`, e
`SUMPRODUCT` no lugar de `SUMIFS`/`COUNTIFS` com múltiplos critérios.

## Excel 2010
Introduziu `AGGREGATE` (agrega ignorando erros/linhas ocultas), `NETWORKDAYS.INTL`, `WORKDAY.INTL`, Sparklines
(não é fórmula), Slicers para tabelas dinâmicas.

## Excel 2013
Introduziu `FORMULATEXT`, `ISOWEEKNUM`, `DAYS`, `NUMBERVALUE`, `SHEET`, `SHEETS`, `UNICHAR`, `UNICODE`,
`FLASH FILL` (recurso, não função), Power Query como suplemento separado (nativo só a partir do 2016).

## Excel 2016
Introduziu (para assinantes Microsoft 365 primeiro, depois no 2016 perpétuo): `IFS`, `SWITCH`, `MAXIFS`, `MINIFS`,
`TEXTJOIN`, `CONCAT` (substitui `CONCATENATE`, que continua funcionando mas está "descontinuada"), Power Query /
"Obter e Transformar" nativo, novos tipos de gráfico (Mapa de árvore, Cascata).

**Equivalentes clássicos se `IFS`/`SWITCH`/`TEXTJOIN`/`MAXIFS`/`MINIFS`/`CONCAT` não existirem:**
- `IFS(cond1,val1,cond2,val2,...)` → `IF(cond1,val1,IF(cond2,val2,...))` aninhado.
- `SWITCH(valor,c1,r1,c2,r2,padrao)` → `IF(valor=c1,r1,IF(valor=c2,r2,padrao))`.
- `TEXTJOIN(",",TRUE,A1:A5)` → `A1&","&A2&","&A3&","&A4&","&A5` (ou `CONCATENATE`), sem opção de ignorar vazios.
- `MAXIFS(intervalo,crit_intervalo,crit)` → `{=MAX(IF(crit_intervalo=crit,intervalo))}` como fórmula de matriz
  clássica (Ctrl+Shift+Enter / `-Matricial`).
- `MINIFS(...)` → mesma ideia com `MIN` no lugar de `MAX`.
- `CONCAT(a,b,c)` → `CONCATENATE(a,b,c)` ou `a&b&c`.

## Excel 2019 (perpétuo)
Empacota as funções lançadas antes disso para assinantes 365: `IFS`, `MAXIFS`, `MINIFS`, `SWITCH`, `TEXTJOIN`,
`CONCAT`, `TEXTJOIN`. **Não tem** `XLOOKUP` nem matrizes dinâmicas — essas só chegam no 2021 perpétuo.

## Excel 2021 (perpétuo)
Primeira versão perpétua com **matrizes dinâmicas** (spill automático, sem Ctrl+Shift+Enter) e: `XLOOKUP`, `XMATCH`,
`FILTER`, `SORT`, `SORTBY`, `UNIQUE`, `SEQUENCE`, `RANDARRAY`. **Não tem** `LET` nem `LAMBDA` perpétuos completos
(chegaram via atualização posterior/365 primeiro).

**Equivalentes clássicos se `XLOOKUP`/`FILTER`/`UNIQUE`/`SORT`/`SEQUENCE` não existirem:**
- `XLOOKUP(valor,array_busca,array_retorno,[se_nao_achou])` → `INDEX(array_retorno,MATCH(valor,array_busca,0))`,
  envolvendo em `IFERROR(...,se_nao_achou)` para o comportamento de "não achou".
- `FILTER(intervalo,condicao)` → fórmula de matriz clássica com `IF`+`SMALL`+`INDEX` (bem mais verboso) ou,
  preferencialmente, filtro de tabela/AutoFiltro manual, ou Power Query.
- `UNIQUE(intervalo)` → Remover Duplicatas (recurso) ou fórmula de matriz com `COUNTIF` para marcar a 1ª ocorrência.
- `SORT(intervalo)` → Classificar (recurso) manual, não há fórmula clássica direta equivalente.
- `SEQUENCE(n)` → `ROW(INDIRECT("1:"&n))` como fórmula de matriz, ou preencher manualmente com alça de preenchimento.

## Excel 2024 (perpétuo)
Congela um subconjunto do que o Microsoft 365 tinha até 2024: inclui `LET`, `LAMBDA`, `XLOOKUP`, matrizes dinâmicas,
`TEXTSPLIT`, `TEXTBEFORE`, `TEXTAFTER`. Não recebe as funções lançadas no 365 depois do lançamento do 2024 (ex.:
`GROUPBY`, `PIVOTBY` chegaram por atualização no 365 e não em toda instalação 2024 imediatamente).

## Microsoft 365 (assinatura, atualização contínua)
Sempre a versão mais completa; recebe funções novas mensalmente. Além de tudo acima, inclui a família de funções de
matriz "modernas": `LET`, `LAMBDA` (+ `BYROW`, `BYCOL`, `MAP`, `REDUCE`, `SCAN`, `MAKEARRAY`), `TEXTSPLIT`,
`TEXTBEFORE`, `TEXTAFTER`, `VSTACK`, `HSTACK`, `TAKE`, `DROP`, `EXPAND`, `CHOOSEROWS`, `CHOOSECOLS`, `TOROW`, `TOCOL`,
e, em canais mais recentes, `GROUPBY`, `PIVOTBY`, `IMAGE`, `STOCKHISTORY`, `FIELDVALUE`. Essas últimas mudam de mês a
mês — **sempre teste ao vivo antes de usar**, mesmo em 365.

## Compatibilidade entre Windows/Mac/Web
- Excel para Mac normalmente recebe as mesmas funções do 365 Windows com alguns meses de atraso.
- Excel na Web (Microsoft 365 online) costuma ter paridade quase total com o 365 Windows, mas automação COM (esta
  skill) **não funciona na Web** — só Windows Desktop.
- Google Sheets **não é Excel**: mesmo quando o nome da função é igual (`XLOOKUP`, `FILTER`), pequenos detalhes de
  comportamento podem diferir. Não presuma compatibilidade sem testar.

## Fórmulas de matriz clássicas vs. dinâmicas
Em qualquer versão **sem** matrizes dinâmicas (pré-2021 perpétuo, ou 2019/2016 mesmo em canal 365 se a organização
travou a atualização), uma fórmula que retorna vários valores precisa ser confirmada como matriz clássica
(equivalente a Ctrl+Shift+Enter). Ao automatizar, isso é `Range.FormulaArray` em vez de `Range.Formula` — use
`-Matricial` em `Escrever-Formula.ps1`. Em versão **com** matrizes dinâmicas, nunca use `FormulaArray`/`-Matricial`:
a fórmula normal já "derrama" (spill) sozinha, e forçar `FormulaArray` pode causar comportamento antigo/errado
(fórmula "CSE" legada em vez de matriz dinâmica).

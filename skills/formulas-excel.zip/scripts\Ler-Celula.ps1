<#
.SYNOPSIS
    Le o conteudo de uma celula ja aberta no Excel: valor calculado, texto exibido, formula em ingles (a que
    a automacao usa) e formula traduzida (a que o usuario ve na tela).
.PARAMETER Arquivo
    Caminho completo do arquivo ja aberto (rode Abrir-Planilha.ps1 antes).
.PARAMETER Aba
    Nome da aba/planilha.
.PARAMETER Celula
    Celula ou intervalo pequeno a ler, ex.: "A2" ou "A2:A10".
.EXAMPLE
    powershell -File Ler-Celula.ps1 -Arquivo "C:\dados\vendas.xlsx" -Aba "Plan1" -Celula "A2"
#>
param(
    [Parameter(Mandatory = $true)][string]$Arquivo,
    [Parameter(Mandatory = $true)][string]$Aba,
    [Parameter(Mandatory = $true)][string]$Celula
)

$ErrorActionPreference = 'Stop'
$Arquivo = (Resolve-Path -LiteralPath $Arquivo -ErrorAction Stop).Path

try {
    $excel = [Runtime.InteropServices.Marshal]::GetActiveObject("Excel.Application")
} catch {
    Write-Error "Nao ha instancia do Excel aberta. Rode Abrir-Planilha.ps1 primeiro, na mesma sessao de terminal."
    exit 1
}

$wb = $null
foreach ($w in $excel.Workbooks) {
    if ($w.FullName -ieq $Arquivo) { $wb = $w; break }
}
if (-not $wb) {
    Write-Error "O arquivo '$Arquivo' nao esta entre as pastas de trabalho abertas. Rode Abrir-Planilha.ps1 primeiro."
    exit 1
}

$ws = $null
foreach ($s in $wb.Worksheets) {
    if ($s.Name -ieq $Aba) { $ws = $s; break }
}
if (-not $ws) {
    Write-Error "Aba '$Aba' nao encontrada. Abas disponiveis: $(($wb.Worksheets | ForEach-Object { $_.Name }) -join ', ')"
    exit 1
}

$range = $ws.Range($Celula)

foreach ($cell in $range) {
    Write-Host "--- $($cell.Address($false, $false)) ---"
    Write-Host "Valor (Value2)     : $($cell.Value2)"
    Write-Host "Texto exibido      : $($cell.Text)"
    Write-Host "Formula (ingles)   : $($cell.Formula)"
    Write-Host "Formula (traduzida): $($cell.FormulaLocal)"
    $texto = [string]$cell.Text
    if ($texto.StartsWith("#")) {
        Write-Warning "Celula em erro: $texto - veja referencia/erros-comuns.md"
    }
}

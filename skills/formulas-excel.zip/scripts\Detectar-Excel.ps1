<#
.SYNOPSIS
    Reporta versao bruta, idioma da interface e edicao (Microsoft 365 vs versao perpetua de um ano fixo)
    do Excel instalado/em execucao. Use como CONTEXTO para a conversa - a decisao de quais funcoes usar
    deve vir do teste ao vivo em Testar-Funcoes.ps1, nao so deste script.
.EXAMPLE
    powershell -File Detectar-Excel.ps1
#>
param()

$ErrorActionPreference = 'Stop'

try {
    $excel = [Runtime.InteropServices.Marshal]::GetActiveObject("Excel.Application")
    $criadoAgora = $false
} catch {
    try {
        $excel = New-Object -ComObject Excel.Application
        $criadoAgora = $true
    } catch {
        Write-Error "Excel nao esta instalado ou nao pode ser iniciado via COM neste computador."
        exit 1
    }
}

Write-Host "Application.Version : $($excel.Version)"
Write-Host "Application.Build   : (Excel nao expoe build por COM de forma direta; ver ClickToRun abaixo)"

# Idioma da interface (MsoLanguageID). msoLanguageIDUI = 2
$idiomas = @{
    1033 = "Ingles (EUA)"
    1046 = "Portugues (Brasil)"
    2070 = "Portugues (Portugal)"
    3082 = "Espanhol"
    1036 = "Frances"
    1031 = "Alemao"
}
try {
    $langId = $excel.LanguageSettings.LanguageID(2)  # msoLanguageIDUI
    $nomeIdioma = $idiomas[$langId]
    if (-not $nomeIdioma) { $nomeIdioma = "desconhecido (codigo $langId)" }
    Write-Host "Idioma da interface : $nomeIdioma (LanguageID=$langId)"
} catch {
    Write-Host "Idioma da interface : nao foi possivel detectar ($($_.Exception.Message))"
}

Write-Host "Application.Path    : $($excel.Path)"

# Edicao: Click-to-Run (Microsoft 365 / assinatura) x MSI (versao perpetua: 2016/2019/2021/2024)
Write-Host "---"
$c2rKey = "HKLM:\SOFTWARE\Microsoft\Office\ClickToRun\Configuration"
if (Test-Path $c2rKey) {
    $cfg = Get-ItemProperty -Path $c2rKey -ErrorAction SilentlyContinue
    Write-Host "Instalacao Click-to-Run detectada (assinatura ou perpetua moderna):"
    Write-Host "  VersionToReport   : $($cfg.VersionToReport)"
    Write-Host "  ProductReleaseIds : $($cfg.ProductReleaseIds)"
    Write-Host "  Platform          : $($cfg.Platform)"
    Write-Host ""
    Write-Host "Dica de leitura: 'O365ProPlusRetail'/'O365BusinessRetail' = Microsoft 365 (recebe funcoes novas todo mes)."
    Write-Host "                 'ProPlus2019Retail'/'ProPlus2021Retail'/'ProPlus2024Retail' = versao perpetua travada naquele ano."
} else {
    Write-Host "Nenhuma chave ClickToRun encontrada - provavelmente instalacao MSI antiga (Excel 2007 a 2016 pre-Click-to-Run)."
}

Write-Host "---"
Write-Host "LEMBRETE: isto e so contexto. Para saber se uma funcao especifica (XLOOKUP, LET, LAMBDA, FILTER...) esta"
Write-Host "disponivel de fato, rode Testar-Funcoes.ps1 apontando para o arquivo real."

if ($criadoAgora) {
    $excel.Quit()
    [System.Runtime.InteropServices.Marshal]::ReleaseComObject($excel) | Out-Null
}

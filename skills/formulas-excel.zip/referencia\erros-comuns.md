# Erros comuns de fórmula no Excel — o que significam e como corrigir

Ordem de diagnóstico recomendada: leia `Range.Text` (o erro exato), depois `Range.Formula` e as células referenciadas
com `scripts/Ler-Celula.ps1`, e só então altere a fórmula.

## `#NAME?`
A função (ou nome definido) não é reconhecida por esta instalação do Excel. Causas mais comuns:
- Função lançada em versão mais nova do que a instalação atual (ex.: `XLOOKUP` num Excel 2019) → confirme com
  `Testar-Funcoes.ps1` e use o equivalente clássico em `funcoes-por-versao.md`.
- Erro de digitação no nome da função, ou nome de função em português passado para `.Formula` (que espera inglês).
- Faltou um suplemento (add-in) que fornecia aquela função.
- Texto não está entre aspas (`=A1&Nome` em vez de `=A1&"Nome"`) — o Excel tenta interpretar `Nome` como nome
  definido/função.

## `#REF!`
A fórmula referencia uma célula/intervalo que não existe mais (linha, coluna ou aba apagada, ou fórmula copiada para
fora dos limites da planilha). Corrija apontando para a referência correta; não há como "recuperar" a referência
antiga automaticamente — normalmente precisa perguntar ao usuário qual era a intenção original.

## `#VALUE!`
Tipo de dado incompatível com a operação (ex.: somar texto, ou uma função de texto recebendo um número onde esperava
texto, ou um argumento vazio quando a função exige um valor). Verifique com `Ler-Celula.ps1` o tipo real do valor nas
células de entrada; frequentemente basta envolver com `VALUE(...)`, `TEXT(...)` ou tratar célula vazia com `IF(A1="",...)`.

## `#DIV/0!`
Divisão por zero ou por célula vazia (vazio é tratado como zero na divisão). Proteja com
`=IFERROR(A1/B1,0)` ou `=IF(B1=0,0,A1/B1)`.

## `#N/A`
Um valor de busca (`VLOOKUP`/`INDEX`+`MATCH`/`XLOOKUP`) não foi encontrado no intervalo. Confirme: o valor buscado
existe exatamente igual (sem espaços extras, mesmo tipo — texto vs. número) no intervalo de busca? Trate o "não
encontrado" explicitamente com `IFERROR(...,"não encontrado")` ou o 4º argumento de `XLOOKUP` (`[se_não_achou]`) em
vez de deixar `#N/A` aparecer para o usuário final.

## `#NULL!`
Interseção de intervalos que não se cruzam, geralmente por um espaço digitado por engano no lugar de `,` ou `:`
(ex.: `=SOMA(A1:A5 C1:C5)` sem operador entre os intervalos). Corrija a sintaxe do intervalo.

## `#NUM!`
Um cálculo matemático não tem resultado válido (raiz quadrada de negativo, iteração que não converge, número grande
demais). Verifique se os argumentos numéricos fazem sentido para a função usada.

## `#SPILL!`
Fórmula de **matriz dinâmica** (`FILTER`, `UNIQUE`, `SORT`, `SEQUENCE`...) não consegue "derramar" o resultado
porque há algo (valor, formatação, célula mesclada) no caminho das células vizinhas. Limpe o intervalo de destino
antes de escrever a fórmula, ou confirme com o usuário que pode sobrescrever aquelas células.

## `#CALC!`
Erro interno de cálculo de matriz dinâmica (ex.: array vazio resultante, ou combinação de funções que a engine de
cálculo não consegue resolver). Simplifique a fórmula por partes (quebre em células auxiliares) para achar qual
sub-parte causa o erro.

## `#GETTING_DATA`
Aparece temporariamente enquanto o Excel busca dados externos (ex.: fonte de dados em nuvem, tipos de dados
vinculados). Não é erro definitivo — espere o cálculo terminar antes de ler o valor (`Start-Sleep` alguns segundos
antes de `Ler-Celula.ps1`).

## Fórmula aparece como texto (não calcula)
Se `Range.Text` mostra a fórmula literal (`=SOMA(A1:A5)` como texto, sem calcular), a célula está formatada como
"Texto" antes de a fórmula ser digitada. Corrija o formato da célula para "Geral"/"Número" e regrave a fórmula
(`.NumberFormat = "General"` antes de definir `.Formula`).

## Resultado errado sem erro nenhum (o mais perigoso)
Não há mensagem de erro, mas o número está errado. Suspeitos comuns:
- Referência relativa que deveria ser absoluta (`A1` em vez de `$A$1`) ao arrastar/preencher a fórmula por várias
  linhas — confira com `Ler-Celula.ps1` se a fórmula em cada linha referencia a célula certa.
- `VLOOKUP`/`XLOOKUP` com correspondência aproximada (`TRUE`/`1` em vez de `FALSE`/`0`) quando o usuário queria
  correspondência exata.
- Cálculo manual ativado (`Application.Calculation = xlCalculationManual`) — force recálculo com
  `$excel.CalculateFullRebuild()` antes de ler o resultado.
- Ordem de operadores (`AND`/`OR` dentro de `IF` sem parênteses suficientes, precedência de `*`/`+`).

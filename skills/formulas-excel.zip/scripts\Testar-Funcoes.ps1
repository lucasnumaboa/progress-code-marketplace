<#
.SYNOPSIS
    Testa ao vivo, na instalacao real do Excel que tem o arquivo aberto, se cada funcao da lista existe.
    Cria uma aba temporaria oculta, escreve uma formula de teste conhecida para cada funcao, le o resultado
    e apaga a aba - nao altera nem salva a planilha do usuario.
.PARAMETER Arquivo
    Caminho completo do arquivo ja aberto (rode Abrir-Planilha.ps1 antes, na mesma sessao).
.PARAMETER Funcoes
    Lista de nomes de funcao (em ingles) a testar. Se omitido, testa todas as funcoes de
    referencia/testes-de-funcao.json.
.EXAMPLE
    powershell -File Testar-Funcoes.ps1 -Arquivo "C:\dados\vendas.xlsx" -Funcoes XLOOKUP,LET,LAMBDA,FILTER
#>
param(
    [Parameter(Mandatory = $true)][string]$Arquivo,
    [string[]]$Funcoes
)

$ErrorActionPreference = 'Stop'
$Arquivo = (Resolve-Path -LiteralPath $Arquivo -ErrorAction Stop).Path

$jsonPath = Join-Path $PSScriptRoot "..\referencia\testes-de-funcao.json"
if (-not (Test-Path $jsonPath)) {
    Write-Error "Nao encontrei referencia/testes-de-funcao.json ao lado desta skill."
    exit 1
}
$tabela = Get-Content -LiteralPath $jsonPath -Raw | ConvertFrom-Json

if ($Funcoes -and $Funcoes.Count -gt 0) {
    $alvo = $tabela | Where-Object { $Funcoes -icontains $_.nome }
    $faltando = $Funcoes | Where-Object { $_ -inotin $tabela.nome }
    foreach ($f in $faltando) {
        Write-Warning "Funcao '$f' nao tem teste conhecido em testes-de-funcao.json - pulei. Adicione uma formula de teste na tabela se precisar dela."
    }
} else {
    $alvo = $tabela
}

try {
    $excel = [Runtime.InteropServices.Marshal]::GetActiveObject("Excel.Application")
} catch {
    Write-Error "Nao ha instancia do Excel aberta. Rode Abrir-Planilha.ps1 primeiro, na mesma sessao de terminal."
    exit 1
}

$wb = $null
foreach ($w in $excel.Workbooks) {
    if ($w.FullName -ieq $Arquivo) { $wb = $w; break }
}
if (-not $wb) {
    Write-Error "O arquivo '$Arquivo' nao esta entre as pastas de trabalho abertas. Rode Abrir-Planilha.ps1 primeiro."
    exit 1
}

$nomeAba = "_probe_$([guid]::NewGuid().ToString('N').Substring(0,8))"
$probeSheet = $wb.Worksheets.Add()
$probeSheet.Name = $nomeAba
$probeSheet.Visible = 0  # xlSheetHidden

$refCell = $probeSheet.Range("Z1")  # celula vazia usada como referencia por funcoes que exigem um intervalo
$refCell.Value2 = $null

$resultados = @()
$linha = 1
foreach ($item in $alvo) {
    $cell = $probeSheet.Range("A$linha")
    try {
        $cell.Formula = $item.teste
        Start-Sleep -Milliseconds 20
        $texto = [string]$cell.Text
        $suportada = -not $texto.StartsWith("#NAME?")
        $resultados += [pscustomobject]@{
            Nome      = $item.nome
            Suportada = $suportada
            Detalhe   = $texto
        }
    } catch {
        # Erro ao ATRIBUIR a formula (nao ao calcular) tambem indica funcao/sintaxe nao reconhecida
        $resultados += [pscustomobject]@{
            Nome      = $item.nome
            Suportada = $false
            Detalhe   = "erro ao definir a formula: $($_.Exception.Message)"
        }
    }
    $linha++
}

# Limpa: apaga a aba temporaria sem salvar o arquivo
$excel.DisplayAlerts = $false
$probeSheet.Delete()
$excel.DisplayAlerts = $true

Write-Host "Resultado do teste ao vivo em '$Arquivo':"
Write-Host "---"
foreach ($r in ($resultados | Sort-Object Nome)) {
    if ($r.Suportada) {
        Write-Host ("{0,-14} suportada" -f $r.Nome)
    } else {
        Write-Host ("{0,-14} NAO suportada  ({1})" -f $r.Nome, $r.Detalhe)
    }
}
Write-Host "---"
Write-Host "Para funcao NAO suportada, veja o equivalente classico em referencia/funcoes-por-versao.md."
Write-Host "A pasta de trabalho nao foi salva por este script - nenhuma alteracao permanente foi feita."

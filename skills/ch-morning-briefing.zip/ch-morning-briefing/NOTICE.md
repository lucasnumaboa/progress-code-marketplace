# Origem

Skill de especialista empacotada para o marketplace do Progress Code (id `ch-morning-briefing`).

- Repositório: https://github.com/TheCraigHewitt/skills
- Caminho: `cowork/morning-briefing`
- Autor: Craig Hewitt
- Detentor do copyright no arquivo de licença: Craig Hewitt
- Licença: MIT (texto completo em `LICENSE`, copiado de `LICENSE` no repositório)
- Commit: `fdbf39b61fbc8cb7cea67949bfb5e8fc567bbc51` (baixado em 2026-11-22)

## Arquivos incluídos

- `SKILL.md` (de `cowork/morning-briefing/SKILL.md`)

## Mudanças feitas

1. Frontmatter: `name:` trocado de `morning-briefing` para `ch-morning-briefing` (a descrição foi mantida).

O texto do especialista foi mantido em inglês, sem tradução.

---
name: logs-windows-event-log
description: Filtra o Visualizador de Eventos do Windows por origem/ID/período, correlaciona falhas de aplicação e exporta evidências para chamados, usando Get-WinEvent (embutido, sem instalar nada). Use quando o usuário pedir para "ver o log de erro dessa aplicação", "por que esse programa travou", "gerar evidência desse erro para o chamado".
argument-hint: [aplicação/serviço] [período aproximado do problema]
---

# Logs do Windows (Event Log)

## Consultar por período e nível (o ponto de partida mais comum)
```powershell
Get-WinEvent -FilterHashtable @{
    LogName   = 'Application'
    Level     = 2, 3          # 2=Erro, 3=Aviso (1=Critico, 4=Informacao)
    StartTime = (Get-Date).AddHours(-2)
} | Select-Object TimeCreated, Id, LevelDisplayName, ProviderName, Message
```
`-FilterHashtable` é muito mais rápido que `Get-EventLog` (obsoleto) ou filtrar depois com `Where-Object` — sempre
filtre no próprio `Get-WinEvent`, não traga tudo para filtrar em memória depois (log do Windows pode ter dezenas de
milhares de entradas).

## Filtrar por origem específica (nome do provedor/aplicação)
```powershell
Get-WinEvent -FilterHashtable @{ LogName = 'Application'; ProviderName = 'NomeDaAplicacao' } -MaxEvents 50
```
Descobrir o nome exato do provedor quando não souber:
```powershell
Get-WinEvent -ListLog Application | Select-Object -ExpandProperty LogName
Get-WinEvent -ListProvider "*nome-parcial*"
```

## Filtrar por ID de evento específico
```powershell
Get-WinEvent -FilterHashtable @{ LogName = 'System'; Id = 41 }   # 41 = reinicio inesperado (kernel-power)
```
IDs comuns úteis: `41` (reinício inesperado/queda de energia), `1000`/`1001` (falha de aplicação, no log
Application), `6008` (desligamento inesperado anterior).

## Log do Agendador de Tarefas (para diagnosticar tarefa agendada que falhou)
```powershell
Get-WinEvent -LogName "Microsoft-Windows-TaskScheduler/Operational" -MaxEvents 30
```

## Correlacionar falha de aplicação (crash) com a causa
Uma falha de aplicação geralmente gera **dois** eventos próximos no tempo: `Application Error` (ID 1000, o
crash em si) e às vezes `Windows Error Reporting` (ID 1001, com detalhes do módulo que causou). Busque os dois
juntos, próximos no horário do problema relatado pelo usuário:
```powershell
Get-WinEvent -FilterHashtable @{ LogName = 'Application'; Id = 1000, 1001; StartTime = (Get-Date).AddHours(-1) }
```

## Exportar evidência para um chamado
```powershell
Get-WinEvent -FilterHashtable @{...} | Export-Csv "evidencia.csv" -NoTypeInformation -Encoding UTF8
# ou o log inteiro, formato nativo (abre no Visualizador de Eventos de outra maquina)
wevtutil epl Application "C:\evidencia\Application.evtx" /q:"*[System[TimeCreated[@SystemTime>='2026-03-10T00:00:00']]]"
```
`.evtx` preserva toda a estrutura e metadados do evento (melhor para enviar a suporte técnico/fabricante);
`.csv` é mais fácil de ler rapidamente ou colar num chamado.

## Regras
- Sempre filtre por período relevante antes de exportar — logs sem filtro de data podem ter milhões de entradas
  irrelevantes e demorar muito para processar.
- Ao correlacionar falha com causa, confirme o fuso horário/hora local do evento reportado pelo usuário bate com
  `TimeCreated` (que já vem em hora local da máquina, não UTC).
- Nunca apague/limpe log (`Clear-EventLog`) para "resolver" um alerta — isso destrói evidência que pode ser
  necessária depois; investigue e resolva a causa, não o registro dela.

## Arquivos desta skill
Nenhum script fixo — os comandos acima cobrem os casos mais comuns; adapte à origem/ID reais do problema.

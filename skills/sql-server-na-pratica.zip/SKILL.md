---
name: sql-server-na-pratica
description: Consulta e administra SQL Server via sqlcmd/Invoke-Sqlcmd, lê plano de execução, identifica bloqueios, faz backup/restore e cria jobs do Agent, com os erros mais comuns e a correção de cada um. Use quando o usuário pedir para "rodar essa query no SQL Server", "por que essa consulta está lenta", "tem bloqueio no banco", "fazer backup/restore do banco", "criar um job agendado no SQL Server".
argument-hint: [servidor/banco] [operação]
---

# SQL Server na prática

## Conectar e rodar consulta
```powershell
Invoke-Sqlcmd -ServerInstance "SERVIDOR\INSTANCIA" -Database "MeuBanco" -Query "SELECT TOP 10 * FROM Clientes"
```
Se `Invoke-Sqlcmd` não existir (módulo `SqlServer` não instalado): `Install-Module SqlServer -Scope CurrentUser`
(módulo do PowerShell Gallery, não é um programa externo pesado). Alternativa via `sqlcmd.exe` (vem com
ferramentas cliente do SQL Server, se instaladas): `sqlcmd -S SERVIDOR\INSTANCIA -d MeuBanco -Q "SELECT ..."`.

## Ler plano de execução (por que a consulta está lenta)
```sql
SET STATISTICS IO ON;
SET STATISTICS TIME ON;
SELECT ... -- a consulta em questao
```
`STATISTICS IO` mostra `logical reads` por tabela — número alto indica falta de índice ou consulta trazendo mais
dados que o necessário. Para o plano visual, no SSMS: Ctrl+M antes de rodar, ou `SET SHOWPLAN_XML ON` via código.
Sinais comuns de problema no plano: **Table Scan**/**Clustered Index Scan** numa tabela grande (geralmente falta
índice na coluna do `WHERE`/`JOIN`), **Key Lookup** repetido em excesso (índice existe mas não é "covering").

## Índices — quando criar
```sql
CREATE INDEX IX_Clientes_CPF ON Clientes(CPF);
CREATE INDEX IX_Pedidos_ClienteId_Data ON Pedidos(ClienteId, DataPedido) INCLUDE (Valor);
```
Índice composto: ordem das colunas importa — a coluna mais seletiva (mais valores distintos) e mais usada em
igualdade (`=`) geralmente vai primeiro. `INCLUDE` adiciona colunas ao índice só para evitar Key Lookup, sem entrar
na ordenação da chave.

## Bloqueios (quem está travando quem)
```sql
SELECT blocking_session_id, session_id, wait_type, wait_time, wait_resource
FROM sys.dm_exec_requests
WHERE blocking_session_id <> 0;
```
`blocking_session_id` é a sessão que está segurando o recurso; `session_id` é quem está esperando. Para ver o texto
da query que está bloqueando:
```sql
SELECT text FROM sys.dm_exec_sql_text((SELECT sql_handle FROM sys.dm_exec_requests WHERE session_id = <blocking_session_id>));
```
Nunca mate uma sessão (`KILL <session_id>`) sem entender o que ela está fazendo — pode ser uma transação legítima
em andamento; confirme com o usuário antes.

## Backup e restore
```sql
BACKUP DATABASE MeuBanco TO DISK = 'D:\Backup\MeuBanco.bak' WITH COMPRESSION, CHECKSUM;
RESTORE DATABASE MeuBancoTeste FROM DISK = 'D:\Backup\MeuBanco.bak' WITH MOVE 'MeuBanco' TO 'D:\Data\MeuBancoTeste.mdf', MOVE 'MeuBanco_log' TO 'D:\Data\MeuBancoTeste.ldf', REPLACE;
```
`WITH MOVE` é necessário ao restaurar com nome diferente do original (senão tenta sobrescrever os arquivos do banco
de origem). `CHECKSUM` detecta corrupção durante o backup — sempre inclua.

## Jobs do SQL Server Agent
```sql
EXEC msdb.dbo.sp_add_job @job_name = 'MeuJob';
EXEC msdb.dbo.sp_add_jobstep @job_name = 'MeuJob', @step_name = 'Passo1', @command = 'EXEC dbo.MinhaProc';
EXEC msdb.dbo.sp_add_schedule @schedule_name = 'Diario6h', @freq_type = 4, @active_start_time = 060000;
EXEC msdb.dbo.sp_attach_schedule @job_name = 'MeuJob', @schedule_name = 'Diario6h';
EXEC msdb.dbo.sp_add_jobserver @job_name = 'MeuJob';
```

## Erros comuns
- `Timeout expired` (do lado da aplicação): consulta lenta ou bloqueio — não aumente o timeout como primeira
  resposta, investigue plano/bloqueio antes.
- `Cannot insert duplicate key`: violação de índice único/chave primária — confira se a lógica está tentando
  inserir um registro que já existe (upsert mal feito).
- `Deadlock victim`: duas transações se bloquearam mutuamente e o SQL Server matou uma — revise a ordem de acesso
  às tabelas nas transações envolvidas para serem consistentes entre si.

## Regras
- Nunca rode `DELETE`/`UPDATE` sem `WHERE` (ou com `WHERE` que pode estar errado) sem antes rodar o mesmo filtro
  como `SELECT` para conferir quantas linhas seriam afetadas.
- Sempre inclua `CHECKSUM` em backup e valide (`RESTORE VERIFYONLY`) periodicamente.
- Alterações de schema em produção: sempre teste em ambiente de homologação primeiro quando disponível.

## Arquivos desta skill
Nenhum script fixo — os trechos acima cobrem os casos mais comuns; adapte ao servidor/banco reais do usuário.

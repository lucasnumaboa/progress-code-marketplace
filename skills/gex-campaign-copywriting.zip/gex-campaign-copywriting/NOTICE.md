# Aviso de terceiros (NOTICE)

Esta skill é uma cópia adaptada de material de terceiros e é redistribuída sob a licença original. O texto do especialista ficou em inglês, como no original.

- **Origem:** https://github.com/growthenginenowoslawski/coldoutboundskills
- **Caminho no repositório:** `skills/campaign-copywriting`
- **Commit:** `25c5d85fbb5dd3efec97b0ca457cbbc286547476` (baixado em 2026-11-22)
- **Autor:** GrowthEngineX
- **Licença:** MIT (texto completo em `LICENSE`, copiado de `LICENSE` do repositório)

## Arquivos incluídos

- `SKILL.md` (de `skills/campaign-copywriting/SKILL.md`)
- `LICENSE`

## Mudanças feitas

- Frontmatter: `name: campaign-copywriting` trocado por `name: gex-campaign-copywriting` (a descrição ficou igual).

## Arquivos do original que não foram incluídos

- As skills citadas em "What to do next" e "Related skills" (`spam-word-checker`, `smartlead-campaign-upload-public`, `icp-onboarding`, listas) não fazem parte deste pacote; `campaign-strategy` está empacotada à parte como `gex-campaign-strategy`.

# Origem e mudanças

- **Repositório:** https://github.com/swan-gtm/gtm-skills
- **Caminho no repositório:** `skills/ivan-falco/meta-reporting`
- **Autor:** Ivan Falco (biblioteca Swan GTM Skills)
- **Licença:** MIT (texto em `LICENSE`)
- **Commit usado:** `eb0026f469f90645e1a64168d08a3e0afb59ee12`
- **Arquivos copiados:** `SKILL.md`, `author.md`

O arquivo `author.md` é o crédito do autor pedido pela biblioteca Swan GTM Skills (contribuições sob MIT, segundo o CONTRIBUTING do repositório).

## Mudanças feitas

- no cabeçalho (frontmatter), `name:` passou de `meta-reporting` para `swan-meta-reporting`; a descrição ficou igual
- nenhuma outra alteração no texto do especialista (mantido em inglês)

## Observações

- o SKILL.md cita scripts de uma skill `meta-ads` da mesma biblioteca (`account_overview.py`, `generate_dashboard.py` etc.), que exigem token da API da Meta; esses scripts não foram incluídos

Empacotada para o marketplace do Progress Code em 2026-11-22.

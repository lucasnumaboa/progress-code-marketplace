---
name: transcrever-audio-whisper
description: Transcreve áudio para texto com Whisper local (faster-whisper, instala sozinho) ou via API, escolhendo o tamanho do modelo pelo hardware disponível, gerando SRT com tempos e resumo. Use quando o usuário pedir para "transcrever essa reunião/áudio", "gerar legenda SRT a partir do áudio", "resumir essa gravação".
argument-hint: [arquivo de áudio/vídeo] [local|API]
---

# Transcrever áudio para texto (Whisper)

## Passo 0 — Verificar/instalar (ffmpeg + faster-whisper)
Whisper precisa do ffmpeg para decodificar áudio de qualquer formato. Se este ambiente já tem a skill
`cortar-converter-legendar-video` instalada, reaproveite o `ffmpeg.exe` empacotado nela; senão:
```
winget install Gyan.FFmpeg
```
```
python -c "import faster_whisper" 2>nul || pip install faster-whisper
```
**Primeira execução baixa os pesos do modelo** (não empacotado — o tamanho varia muito, de 75MB a 3GB, ver
tabela abaixo) — avise o usuário antes que isso vai acontecer e pode demorar dependendo da internet.

## Passo 1 — Escolher o tamanho do modelo pelo hardware/necessidade
| Modelo | Tamanho | Quando usar |
|---|---|---|
| `tiny` | ~75MB | Teste rápido, transcrição grosseira, sem GPU |
| `base` | ~145MB | Bom equilíbrio para a maioria dos casos sem GPU |
| `small` | ~480MB | Melhor precisão, ainda razoável em CPU |
| `medium` | ~1.5GB | Precisão boa, prefere GPU (lento em CPU) |
| `large-v3` | ~3GB | Melhor precisão, precisa de GPU decente para tempo aceitável |
Sem GPU dedicada, comece com `base`/`small` — `medium`/`large` em CPU pode levar muito mais tempo que a duração do
próprio áudio.

## Passo 2 — Transcrever
```python
from faster_whisper import WhisperModel

modelo = WhisperModel("small", device="cpu", compute_type="int8")  # "cuda" no lugar de "cpu" se tiver GPU NVIDIA
segmentos, info = modelo.transcribe("audio.mp3", language="pt")

print(f"Idioma detectado: {info.language} (confiança {info.language_probability:.0%})")
for segmento in segmentos:
    print(f"[{segmento.start:.1f}s -> {segmento.end:.1f}s] {segmento.text}")
```
`language="pt"` força português (mais rápido e preciso que deixar o modelo detectar sozinho, se você já sabe o
idioma). `compute_type="int8"` é mais rápido em CPU com perda de precisão mínima — bom padrão sem GPU.

## Passo 3 — Gerar SRT com tempos
```python
def formatar_tempo_srt(segundos):
    h, resto = divmod(segundos, 3600)
    m, s = divmod(resto, 60)
    ms = int((s % 1) * 1000)
    return f"{int(h):02d}:{int(m):02d}:{int(s):02d},{ms:03d}"

with open("legenda.srt", "w", encoding="utf-8") as f:
    for i, seg in enumerate(segmentos, start=1):
        f.write(f"{i}\n{formatar_tempo_srt(seg.start)} --> {formatar_tempo_srt(seg.end)}\n{seg.text.strip()}\n\n")
```
Para queimar a legenda gerada no vídeo, use a skill `cortar-converter-legendar-video`, passo 7.

## Passo 4 — Resumo do conteúdo transcrito
Depois de ter o texto completo, passe para o modelo de IA que está conduzindo esta conversa resumir/extrair pontos
— não é preciso nenhuma ferramenta adicional para isso, é só usar o texto já transcrito como entrada.

## Alternativa: API em vez de modelo local
Se o usuário preferir não baixar modelo/não tem hardware adequado, use a API oficial (OpenAI Whisper API ou
equivalente) — ver skill `chamar-apis-de-ia` para o padrão de chamada. Envolve custo por minuto de áudio, mas não
precisa de download de modelo nem hardware local.

## Regras
- Sempre avise antes de baixar um modelo grande (`medium`/`large`, GB de download) — confirme que o usuário quer
  isso antes de iniciar, especialmente em conexão limitada.
- Áudio de baixa qualidade (muito ruído, múltiplas pessoas falando ao mesmo tempo): avise que a precisão da
  transcrição cai bastante — não apresente o resultado como certeza absoluta nesses casos.
- Conteúdo sensível (reunião confidencial): trate o áudio e a transcrição gerada com o mesmo cuidado de qualquer
  dado sensível — não deixe em pasta compartilhada sem necessidade.

## Arquivos desta skill
Nenhum script fixo — os trechos acima cobrem o fluxo completo; adapte ao áudio/modelo reais do usuário.

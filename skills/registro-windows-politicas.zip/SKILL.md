---
name: registro-windows-politicas
description: Lê e grava chaves do Registro do Windows com segurança (sempre com backup antes), configura políticas locais (GPO local) e ajusta configurações comuns (proxy, associações de arquivo, autostart). Use quando o usuário pedir para "mudar essa configuração no registro", "definir esse programa como padrão para abrir X", "configurar proxy via registro", "adicionar/remover um programa da inicialização".
argument-hint: [chave/configuração desejada]
---

# Registro do Windows e políticas

## Regra de ouro: backup antes de qualquer alteração
```powershell
reg export "HKCU\Software\Caminho\Da\Chave" "C:\backups\antes-da-mudanca.reg"
```
Sempre exporte a chave (ou a subárvore inteira, se a mudança for ampla) antes de alterar — permite reverter
(`reg import arquivo.reg`) se algo der errado. Nunca altere registro de produção sem esse passo.

## Ler e gravar via PowerShell (mais seguro que editar .reg à mão)
```powershell
Get-ItemProperty -Path "HKCU:\Software\Caminho\Da\Chave" -Name "NomeValor"
New-ItemProperty -Path "HKCU:\Software\Caminho\Da\Chave" -Name "NomeValor" -Value "novo-valor" -PropertyType String -Force
Remove-ItemProperty -Path "HKCU:\Software\Caminho\Da\Chave" -Name "NomeValor"
```
`HKCU:` afeta só o usuário atual (não precisa de admin); `HKLM:` afeta a máquina inteira (precisa de admin, e
afeta todos os usuários — confirme que é isso mesmo que o usuário quer antes de alterar `HKLM`).

## Autostart (programa iniciar com o Windows)
```powershell
New-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Run" -Name "MeuApp" -Value "C:\app\meuapp.exe" -PropertyType String
```
Alternativa mais gerenciável (recomendada em vez de mexer direto no Run): colocar um atalho na pasta
`shell:startup` (`$env:APPDATA\Microsoft\Windows\Start Menu\Programs\Startup`) — mais fácil de o próprio usuário
encontrar e remover depois pela interface do Windows, sem precisar saber que existe uma chave de registro.

## Associação de arquivo (programa padrão para abrir uma extensão)
Fazer isso via registro direto é complexo e frágil no Windows 10/11 (o sistema tem proteções contra alteração
automática de associação "para evitar sequestro de navegador/programa padrão" — a partir do Windows 10, Microsoft
bloqueia mudança silenciosa via registro). O caminho suportado é `Configurações → Aplicativos → Aplicativos
padrão`, ou o comando:
```powershell
Start-Process ms-settings:defaultapps
```
Avise o usuário que a mudança de programa padrão frequentemente exige confirmação manual dele na tela — não é algo
que a automação consiga forçar silenciosamente por design do Windows.

## Proxy (configuração comum via registro, quando não há GPO de domínio controlando isso)
```powershell
Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings" -Name "ProxyEnable" -Value 1
Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings" -Name "ProxyServer" -Value "proxy.empresa.com:8080"
```
Se a máquina é gerenciada por domínio/Intune, essas configurações provavelmente são sobrescritas por política de
grupo — confirme antes de gastar tempo tentando ajustar via registro local.

## Política de grupo local (gpedit.msc, só edições Pro/Enterprise)
`gpedit.msc` não existe no Windows Home. Para máquina de domínio, a política vem do controlador de domínio, não faz
sentido alterar localmente — confirme com o usuário se a máquina é de domínio antes de propor GPO local.

## Regras
- Sempre `reg export` antes de qualquer alteração em chave existente.
- Nunca altere `HKLM` sem confirmar que a mudança deve valer para todos os usuários da máquina.
- Se a chave/valor não existir ainda, confirme que o caminho e o tipo (`String`/`DWord`/`Binary`) estão corretos
  antes de criar — um tipo errado pode fazer o programa que lê aquela chave se comportar de forma inesperada.

## Arquivos desta skill
Nenhum script fixo — os comandos acima cobrem os casos mais comuns; adapte à chave/configuração real pedida.

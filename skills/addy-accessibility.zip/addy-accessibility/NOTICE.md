# Origem e mudanças

- **Repositório:** https://github.com/addyosmani/web-quality-skills
- **Caminho no repositório:** `skills/accessibility`
- **Autor:** Addy Osmani
- **Licença:** MIT (texto em `LICENSE`)
- **Commit usado:** `afa8da942115f2961fdbfa80807ea0b232ff6c00`
- **Arquivos copiados:** `SKILL.md`, `references/A11Y-PATTERNS.md`, `references/WCAG.md`

## Mudanças feitas

- no cabeçalho (frontmatter), `name:` passou de `accessibility` para `addy-accessibility`; a descrição ficou igual
- nenhuma outra alteração no texto do especialista (mantido em inglês)

Empacotada para o marketplace do Progress Code em 2026-11-22.

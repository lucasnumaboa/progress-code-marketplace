# Aviso de terceiros (NOTICE)

Esta skill é uma cópia adaptada de material de terceiros e é redistribuída sob a licença original. O texto do especialista ficou em inglês, como no original.

- **Origem:** https://github.com/swan-gtm/gtm-skills
- **Caminho no repositório:** `skills/rutger-katz/expansion-revenue-architect`
- **Commit:** `eb0026f469f90645e1a64168d08a3e0afb59ee12` (baixado em 2026-11-22)
- **Autor:** Rutger Katz (autor da skill); copyright do repositório: Swan
- **Licença:** MIT (texto completo em `LICENSE`, copiado de `LICENSE` do repositório)

## Arquivos incluídos

- `SKILL.md` (de `skills/rutger-katz/expansion-revenue-architect/SKILL.md`)
- `references/90-day-nrr-program.md` (de `skills/rutger-katz/expansion-revenue-architect/references/90-day-nrr-program.md`)
- `references/advocacy-as-expansion-multiplier.md` (de `skills/rutger-katz/expansion-revenue-architect/references/advocacy-as-expansion-multiplier.md`)
- `references/benchmarks-sourced.md` (de `skills/rutger-katz/expansion-revenue-architect/references/benchmarks-sourced.md`)
- `references/health-scoring-effectiveness.md` (de `skills/rutger-katz/expansion-revenue-architect/references/health-scoring-effectiveness.md`)
- `references/ttv-benchmarks.md` (de `skills/rutger-katz/expansion-revenue-architect/references/ttv-benchmarks.md`)
- `references/whitespace-and-scoring-mechanics.md` (de `skills/rutger-katz/expansion-revenue-architect/references/whitespace-and-scoring-mechanics.md`)
- `author.md` (de `skills/rutger-katz/author.md`, crédito do autor pedido pelo repositório)
- `LICENSE`

## Mudanças feitas

- Frontmatter: `name: expansion-revenue-architect` trocado por `name: swan-expansion-revenue-architect` (a descrição ficou igual).

## Crédito do autor (author.md)

O repositório pede que o crédito do autor acompanhe a skill. Conteúdo do `author.md` original:

```markdown
---
name: Rutger Katz
avatarUrl: "https://www.gtmskills.com/authors/rutger-katz.jpg"
title: "Founder @ Neon Triforce — AI-Ready Revenue Systems"
linkedinUrl: "https://www.linkedin.com/in/rutgerkatz"
companyDomain: neontriforce.com
---

Helps B2B scale-ups (€15–150M) build AI-ready revenue systems — diagnostics first, then the operating system: forecasting, pipeline architecture, handoffs, and the tooling to run it.
```

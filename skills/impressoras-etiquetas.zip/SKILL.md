---
name: impressoras-etiquetas
description: Instala/define impressora, imprime PDF por linha de comando e gera etiquetas ZPL para impressoras Zebra, sem instalar programa externo. Use quando o usuário pedir para "imprimir esse PDF automaticamente", "gerar etiqueta para a Zebra", "definir essa impressora como padrão", "listar as impressoras instaladas".
argument-hint: [impressora] [arquivo/etiqueta a imprimir]
---

# Impressoras e etiquetas

## Listar e definir impressora padrão
```powershell
Get-Printer
Get-CimInstance -ClassName Win32_Printer | Select-Object Name, Default
(Get-CimInstance -ClassName Win32_Printer -Filter "Name='NomeDaImpressora'").SetDefaultPrinter()
```

## Instalar impressora de rede
```powershell
Add-Printer -ConnectionName "\\servidor\NomeDaImpressora"
```

## Imprimir PDF por linha de comando (sem instalar nada — usa o Edge já no Windows)
```powershell
Start-Process -FilePath "msedge.exe" -ArgumentList "--headless", "--disable-gpu", "--print-to-pdf-no-header", `
    "--print-to-printer=`"NomeDaImpressora`"", "C:\caminho\arquivo.pdf" -Wait
```
Alternativa mais direta para imprimir sem abrir visualizador: `Start-Process -FilePath "arquivo.pdf" -Verb Print`
usa o handler padrão do Windows para PDF (o que estiver associado) e manda para a impressora padrão — mais simples,
mas menos controle sobre qual impressora usar.

## Etiquetas ZPL (impressoras Zebra) — enviar comando direto para a impressora
ZPL é um protocolo de texto simples — não precisa de driver especial nem programa de etiqueta, só enviar a string
ZPL direto para a porta da impressora (USB compartilhado como impressora Windows, ou rede na porta 9100):
```powershell
$zpl = @"
^XA
^FO50,50^A0N,50,50^FDPedido 12345^FS
^FO50,120^BY2^BCN,100,Y,N,N^FD12345^FS
^XZ
"@

# via rede (impressora com IP proprio, porta padrao Zebra 9100)
$cliente = New-Object System.Net.Sockets.TcpClient("192.168.1.50", 9100)
$stream = $cliente.GetStream()
$bytes = [System.Text.Encoding]::ASCII.GetBytes($zpl)
$stream.Write($bytes, 0, $bytes.Length)
$cliente.Close()
```
`^FO` posiciona (x,y), `^A0N` define fonte, `^BCN` gera código de barras Code128. Sempre teste o ZPL primeiro num
simulador online (buscar "ZPL viewer online") antes de mandar para a impressora física, para não desperdiçar
etiquetas físicas em tentativa e erro.

## Tamanho de etiqueta
Configure o tamanho físico da etiqueta na própria impressora (menu Zebra) ou via comando `^PW` (largura em pontos,
203 dpi = ~8 pontos/mm) e `^LL` (comprimento) no início do ZPL — se o tamanho configurado na impressora não bater
com o ZPL enviado, o conteúdo corta ou sobra espaço em branco.

## Regras
- Sempre confirme o nome exato da impressora (`Get-Printer`) antes de mandar imprimir — nome errado falha
  silenciosamente ou manda para a impressora padrão errada.
- Ao gerar código de barras (`^BC` no ZPL, ou qualquer outro), valide visualmente/com leitor antes de considerar
  pronto para produção — ver skill `gerar-qrcode-codigo-barras` para o mesmo cuidado aplicado a QR/EAN.
- Impressão em massa (centenas de etiquetas): teste uma unidade primeiro, sempre.

## Arquivos desta skill
Nenhum script fixo — os comandos acima cobrem os casos mais comuns; adapte à impressora/etiqueta reais do usuário.

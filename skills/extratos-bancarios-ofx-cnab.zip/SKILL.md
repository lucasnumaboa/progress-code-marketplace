---
name: extratos-bancarios-ofx-cnab
description: Lê extratos bancários em OFX e arquivos de retorno CNAB 240/400, e concilia automaticamente com contas a receber/pagar. Use quando o usuário pedir para "ler esse extrato OFX/CNAB", "conciliar esses pagamentos com o retorno do banco", "por que esse boleto não está batendo com o extrato".
argument-hint: [arquivo OFX ou CNAB] [o que conciliar]
---

# Leitura de extratos e arquivos bancários

## OFX (extrato bancário, formato padrão de vários bancos)
```
pip install ofxparse
```
```python
from ofxparse import OfxParser

with open("extrato.ofx", "rb") as f:
    ofx = OfxParser.parse(f)

for transacao in ofx.account.statement.transactions:
    print(transacao.date, transacao.amount, transacao.memo, transacao.id)
```
`transacao.id` (`FITID` no padrão OFX) é o identificador único da transação **segundo o banco** — use-o para
detectar reimportação do mesmo extrato (evitar duplicar lançamentos ao processar o mesmo arquivo duas vezes).

## CNAB 400 (formato mais antigo, ainda comum, um banco por vez, layout de posições fixas)
```python
def ler_cnab400_retorno(caminho):
    registros = []
    with open(caminho, "r", encoding="latin-1") as f:  # CNAB tradicionalmente em latin-1/ASCII, nao UTF-8
        for linha in f:
            tipo_registro = linha[0]
            if tipo_registro == "1":  # registro de detalhe (varia a posicao exata por banco/versao - confirmar manual)
                nosso_numero = linha[62:70].strip()
                codigo_ocorrencia = linha[108:110].strip()  # ex.: "06" = liquidado, "02" = confirmacao de entrada
                valor_pago = int(linha[253:266]) / 100  # CNAB grava valor sem separador decimal - ULTIMOS 2 DIGITOS SAO OS CENTAVOS
                registros.append({"nosso_numero": nosso_numero, "ocorrencia": codigo_ocorrencia, "valor": valor_pago})
    return registros
```
**As posições exatas de cada campo variam por banco** (o CNAB 400 tem um layout "base" mas cada banco tem
variações) — sempre confirme o manual de layout do banco específico antes de assumir as posições; não generalize
de um banco para outro sem checar.

## CNAB 240 (padrão mais novo, multi-banco, estrutura de segmentos)
Estrutura mais rica com "segmentos" (`A`, `B`, `J`, etc.) por registro de detalhe — a posição 14 da linha indica o
segmento, que determina como interpretar o restante da linha. Mais padronizado entre bancos que o CNAB 400, mas
ainda com particularidades por banco em campos específicos — mesma regra: confirme o manual antes de assumir.

## Conciliação automática (o padrão comum, qualquer que seja o formato de origem)
```python
def conciliar(retorno_banco, contas_a_receber):
    conciliados, nao_encontrados, divergentes = [], [], []
    por_nosso_numero = {c["nosso_numero"]: c for c in contas_a_receber}
    for registro in retorno_banco:
        conta = por_nosso_numero.get(registro["nosso_numero"])
        if not conta:
            nao_encontrados.append(registro)
        elif abs(conta["valor_esperado"] - registro["valor"]) > 0.01:
            divergentes.append({"conta": conta, "registro": registro})
        else:
            conciliados.append(conta)
    return conciliados, nao_encontrados, divergentes
```
Sempre separe em três categorias (conciliado, não encontrado, divergente) — nunca só "bateu"/"não bateu"; um valor
que bate mas não acha a conta correspondente é um problema diferente de uma conta que acha mas o valor diverge
(ex.: juros/multa aplicados), e cada caso precisa de tratamento humano diferente.

## Regras
- Nunca concilie automaticamente e já dê baixa definitiva sem revisão humana em divergências (valor diferente,
  registro não encontrado) — só concilie automaticamente os casos que batem exatamente.
- CNAB é sensível a encoding (`latin-1` é o mais comum historicamente) e a posições fixas de coluna — um único
  caractere de diferença desalinha a leitura inteira da linha; se os valores saírem sem sentido (data impossível,
  valor absurdo), suspeite de encoding ou posição errada antes de qualquer outra coisa.
- Sempre gere um relatório do resultado da conciliação (quantos batidos/não encontrados/divergentes) para o
  usuário revisar, não apenas aplique e siga em frente.

## Arquivos desta skill
Nenhum script fixo — os trechos acima cobrem os casos mais comuns; adapte ao layout exato do banco do usuário.

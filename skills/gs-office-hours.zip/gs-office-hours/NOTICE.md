# Aviso de terceiros (NOTICE)

Esta skill é uma cópia adaptada de material de terceiros e é redistribuída sob a licença original. O texto do especialista ficou em inglês, como no original.

- **Origem:** https://github.com/garrytan/gstack
- **Caminho no repositório:** `office-hours`
- **Commit:** `79f3052f3589563d92e4bef12a5a68be936ddd8c` (baixado em 2026-11-22)
- **Autor:** Garry Tan
- **Licença:** MIT (texto completo em `LICENSE`, copiado de `LICENSE` do repositório)

## Arquivos incluídos

- `SKILL.md` (de `office-hours/SKILL.md`)
- `sections/phase-2a-startup-diagnostic.md` (de `office-hours/sections/phase-2a-startup-diagnostic.md`)
- `LICENSE`

## Mudanças feitas

- Frontmatter: `name: office-hours` trocado por `name: gs-office-hours` (a descrição ficou igual).
- `SKILL.md`: frontmatter reduzido a `name` e `description` (a descrição original foi mantida); saíram `preamble-tier`, `version`, `allowed-tools` (com binário do gstack), `triggers` e o bloco `gbrain` (consultas à base local do gstack).
- `SKILL.md`: mantidas só as seções de método: "# YC Office Hours" (papel e HARD GATE), "Phase 2A: Startup Mode" (com o apontador para `sections/phase-2a-startup-diagnostic.md` trocado do caminho `~/.claude/skills/gstack/office-hours/sections/` para o caminho relativo da skill), "Phase 3: Premise Challenge", "Phase 4: Alternatives Generation", "Phase 4.5: Founder Signal Synthesis" (só a lista de sinais) e "Important Rules". Saíram, por dependerem do binário, da telemetria ou da base local do gstack: comentário de arquivo gerado, "Shared preamble", "Preamble (run first)", "AskUserQuestion Format", "Question Tuning", "Repo Ownership", "Search Before Building", "Telemetry (run last)", "Third-Party Web Actions", "Brain Context (preflight)", "Phase 1: Context Gathering" (comandos do gstack e de git), "Prior Learnings", "Section index", o apontador da Phase 2C, "Phase 2B: Builder Mode", "Phase 2.5", "Web research runs in Aside", "Phase 2.75", "Phase 3.5: Cross-Model Second Opinion", "Phase 4.25: Visual design", "Builder Profile Read/Append", "Section self-check", "Before telemetry", "Capture Learnings".
- `sections/phase-2a-startup-diagnostic.md`: removidos o parágrafo "**Open commitment:**" (roda `~/.claude/skills/gstack/bin/gstack-developer-profile`) e a linha sobre guardar nomes de clientes na cópia privada `~/.gstack` (base local do gstack).

## Arquivos do original que não foram incluídos

- As demais seções de `office-hours/sections/` (phase-2b-builder-brainstorm, phase-2c-pivot-discovery, landscape, second-opinion, visual-design, design-and-handoff) e `manifest.json`: dependem do binário, da base local ou de outros provedores do gstack.
- Os arquivos são gerados a partir de `office-hours/SKILL.md.tmpl` e `office-hours/sections/phase-2a-startup-diagnostic.md.tmpl` (fonte editável no repositório original).

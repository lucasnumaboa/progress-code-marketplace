---
name: cicd-pipelines
description: Escreve pipelines de CI/CD (GitHub Actions, GitLab CI, Azure DevOps) com segredos, cache, artefatos, matrizes e deploy condicional — rodam em runner hospedado, sem instalar nada localmente. Use quando o usuário pedir para "criar um pipeline de CI/CD", "essa Action/pipeline está falhando", "cachear as dependências no CI", "fazer deploy só quando mergear na main".
argument-hint: [plataforma: GitHub Actions|GitLab CI|Azure DevOps] [o que o pipeline deve fazer]
---

# CI/CD (GitHub Actions, GitLab CI, Azure DevOps)

## GitHub Actions
```yaml
name: CI
on:
  push:
    branches: [main]
  pull_request:

jobs:
  testar:
    runs-on: windows-latest
    strategy:
      matrix:
        versao-python: ["3.11", "3.12"]
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: ${{ matrix.versao-python }}
      - name: Cache de dependencias
        uses: actions/cache@v4
        with:
          path: ~/.cache/pip
          key: ${{ runner.os }}-pip-${{ hashFiles('requirements.txt') }}
      - run: pip install -r requirements.txt
      - run: pytest --junitxml=resultado.xml
      - uses: actions/upload-artifact@v4
        if: always()
        with:
          name: resultado-testes
          path: resultado.xml

  deploy:
    needs: testar
    if: github.ref == 'refs/heads/main' && github.event_name == 'push'
    runs-on: ubuntu-latest
    environment: producao   # exige aprovacao manual se configurado em Settings > Environments
    steps:
      - run: echo "Deploy so roda apos merge na main, com os testes passando"
```
`if: always()` no upload de artefato garante que o resultado do teste seja salvo mesmo se o teste falhar — sem
isso, um job que falha não deixa evidência de artefato para diagnosticar depois.

## GitLab CI
```yaml
stages: [testar, deploy]

testar:
  stage: testar
  image: python:3.12
  cache:
    key: ${CI_COMMIT_REF_SLUG}
    paths: [.cache/pip]
  script:
    - pip install -r requirements.txt
    - pytest

deploy_producao:
  stage: deploy
  script: echo "deploy"
  rules:
    - if: '$CI_COMMIT_BRANCH == "main"'
  environment: producao
```

## Azure DevOps Pipelines
```yaml
trigger:
  branches: { include: [main] }

pool: { vmImage: 'windows-latest' }

steps:
  - task: UsePythonVersion@0
    inputs: { versionSpec: '3.12' }
  - script: pip install -r requirements.txt
  - script: pytest --junitxml=resultado.xml
  - task: PublishTestResults@2
    condition: always()
    inputs: { testResultsFiles: 'resultado.xml' }
```

## Segredos (nunca em texto no YAML)
- GitHub: Settings → Secrets and variables → Actions; use como `${{ secrets.MINHA_CHAVE }}`.
- GitLab: Settings → CI/CD → Variables (marcar como "Masked" e "Protected" se só deve valer em branch protegida).
- Azure DevOps: Pipelines → Library → Variable groups, ou "Secret variable" direto na definição.
Nunca imprima (`echo`/`Write-Host`) um valor de segredo no log do pipeline — mesmo mascarado pela plataforma,
concatenar/transformar o valor antes de imprimir pode vazar (mascaramento é por correspondência exata de string).

## Regras
- Nunca faça deploy de produção sem um gate (aprovação manual, ou pelo menos "só após testes passarem na branch
  principal") — confirme com o usuário a regra de quando o deploy deve realmente rodar.
- Cache mal invalidado (chave que não muda quando deveria) é a causa mais comum de "funcionava local, falha no CI"
  — sempre inclua no hash da chave de cache os arquivos que definem a versão exata das dependências.
- Pipeline lento: paralelize com matriz/jobs independentes antes de tentar otimizar um job monolítico sequencial.

## Arquivos desta skill
Nenhum script fixo — os exemplos acima cobrem os casos mais comuns; adapte à plataforma/projeto reais do usuário.

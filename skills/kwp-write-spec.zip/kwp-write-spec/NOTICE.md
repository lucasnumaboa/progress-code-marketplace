# Origem e licença

Esta skill é uma cópia, com as alterações listadas abaixo, de material de especialista com licença aberta.

- **Fonte:** https://github.com/anthropics/knowledge-work-plugins
- **Arquivos de origem:** `product-management/skills/write-spec/SKILL.md`
- **Autor:** Anthropic
- **Licença:** Apache-2.0 (texto completo em `LICENSE`)
- **Commit:** `0e0fcacddcc892eb92a1b7873ff9d68159c47571` (baixado em 2026-11-22)

## Alterações feitas

- `name:` do frontmatter trocado de `write-spec` para `kwp-write-spec`.
- Removida a linha que aponta para `CONNECTORS.md` e a seção "If Connectors Available" (regras de conectores do Claude Cowork, que não existem no Progress Code).
- Removidos os blocos "If **~~...** is connected:" (mesmo motivo).
- Removida a subseção "### 3. Pull Context from Connected Tools" (só tratava de conectores do Cowork); a numeração do fluxo pula de 2 para 4.
- Fora isso, o texto do especialista está como no original (em inglês).

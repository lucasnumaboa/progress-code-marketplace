---
name: mensagens-microsoft-teams
description: Envia mensagens para canais do Microsoft Teams via webhook (cartões adaptativos, menções, anexos) ou via Graph API, para status de builds e alertas. Use quando o usuário pedir para "mandar um alerta no Teams", "postar o status do build no canal", "montar um cartão adaptativo".
argument-hint: [canal/webhook] [conteúdo da mensagem]
---

# Mensagens no Microsoft Teams

## Opção 1 — Webhook de canal (mais simples, sem OAuth2)
Um webhook é configurado uma vez no canal do Teams (Conectores → Webhook de Entrada, ou Workflows no Teams novo) e
gera uma URL — guarde essa URL como segredo, não em código versionado.
```python
import requests

payload = {
    "@type": "MessageCard",
    "@context": "http://schema.org/extensions",
    "summary": "Status do build",
    "themeColor": "0078D7",
    "title": "Build #1234 concluído",
    "text": "Todos os testes passaram.",
}
requests.post(webhook_url, json=payload)
```
**Atenção**: o formato `MessageCard` clássico está sendo descontinuado pela Microsoft em favor de "Adaptive Cards"
via Workflows do Power Automate — se o webhook foi criado como "Workflow" (Teams novo), use o formato abaixo.

## Opção 2 — Cartão adaptativo (Adaptive Card, formato atual)
```python
payload = {
    "type": "message",
    "attachments": [{
        "contentType": "application/vnd.microsoft.card.adaptive",
        "content": {
            "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
            "type": "AdaptiveCard",
            "version": "1.4",
            "body": [
                {"type": "TextBlock", "text": "Build #1234 concluído", "weight": "bolder", "size": "medium"},
                {"type": "TextBlock", "text": "Todos os testes passaram.", "wrap": True},
            ],
            "actions": [
                {"type": "Action.OpenUrl", "title": "Ver detalhes", "url": "https://ci.exemplo.com/1234"}
            ],
        },
    }],
}
requests.post(webhook_url, json=payload)
```

## Opção 3 — Graph API (mensagem em nome de um usuário/aplicação, precisa de OAuth2)
```python
requests.post(
    f"https://graph.microsoft.com/v1.0/teams/{team_id}/channels/{channel_id}/messages",
    headers={"Authorization": f"Bearer {token}"},
    json={"body": {"content": "Mensagem de texto ou <b>HTML simples</b>."}},
)
```
Use Graph só quando precisar de algo que webhook não faz (ler mensagens, mencionar usuário específico por ID,
postar como uma identidade de aplicação) — ver skill `oauth2-login-servicos` para o fluxo de autenticação.

## Menções (só funciona via Graph, não via webhook simples)
```python
payload = {
    "body": {"content": "<at id=\"0\">Fulano</at>, o build falhou."},
    "mentions": [{"id": 0, "mentionText": "Fulano", "mentioned": {"user": {"id": user_id, "displayName": "Fulano"}}}],
}
```

## Regras
- Nunca poste alertas em excesso (a cada checagem) — só em mudança de estado relevante (ver skill
  `monitorar-paginas-sistemas` para o mesmo princípio aplicado a monitoramento).
- URL do webhook é um segredo (qualquer um com a URL pode postar no canal) — trate como senha, nunca em código
  versionado.
- Teste o cartão num canal de teste antes de usar no canal real — erro de schema no Adaptive Card falha
  silenciosamente em alguns clientes Teams (mensagem não aparece, sem erro óbvio do lado de quem envia).

## Arquivos desta skill
Nenhum script fixo — os payloads acima cobrem os casos mais comuns; adapte ao conteúdo real da mensagem.

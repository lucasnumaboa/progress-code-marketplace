# Aviso de terceiros (NOTICE)

Esta skill é uma cópia adaptada de material de terceiros e é redistribuída sob a licença original. O texto do especialista ficou em inglês, como no original.

- **Origem:** https://github.com/coreyhaines31/marketingskills
- **Caminho no repositório:** `skills/cold-email`
- **Commit:** `5b2b400eec1e7e1cec76245a715d0b0d4fd2a9c1` (baixado em 2026-11-22)
- **Autor:** Corey Haines
- **Licença:** MIT (texto completo em `LICENSE`, copiado de `LICENSE` do repositório)

## Arquivos incluídos

- `SKILL.md` (de `skills/cold-email/SKILL.md`)
- `references/benchmarks.md` (de `skills/cold-email/references/benchmarks.md`)
- `references/deliverability.md` (de `skills/cold-email/references/deliverability.md`)
- `references/follow-up-sequences.md` (de `skills/cold-email/references/follow-up-sequences.md`)
- `references/frameworks.md` (de `skills/cold-email/references/frameworks.md`)
- `references/linkedin-outreach.md` (de `skills/cold-email/references/linkedin-outreach.md`)
- `references/multichannel-cadence.md` (de `skills/cold-email/references/multichannel-cadence.md`)
- `references/outbound-plays.md` (de `skills/cold-email/references/outbound-plays.md`)
- `references/personalization.md` (de `skills/cold-email/references/personalization.md`)
- `references/reply-handling.md` (de `skills/cold-email/references/reply-handling.md`)
- `references/subject-lines.md` (de `skills/cold-email/references/subject-lines.md`)
- `LICENSE`

## Mudanças feitas

- Frontmatter: `name: cold-email` trocado por `name: mk-cold-email` (a descrição ficou igual).
- `SKILL.md`: removida a seção "## Tool Integrations" (tabela de links para o registro de ferramentas do repositório original, que não acompanha a skill, com marcações de parceiro e ferramenta do próprio mantenedor).

## Arquivos do original que não foram incluídos

- `evals/evals.json` (casos de teste do autor, não usados pela skill).
- A referência de conformidade por país citada em "Before You Send" fica na skill `mk-prospecting` (`references/compliance.md`).

## Observação

O original informa que a ferramenta Truelist (citada em `references/deliverability.md` como opção de verificação e de domínios) é feita pelo mantenedor do repositório. A citação foi mantida como no original; ela não é recomendação do Progress Code.

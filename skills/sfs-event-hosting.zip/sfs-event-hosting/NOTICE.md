# Origem

Skill de especialista empacotada para o marketplace do Progress Code (id `sfs-event-hosting`).

- Repositório: https://github.com/shawnpang/startup-founder-skills
- Caminho: `skills/event-hosting`
- Autor: Shawn Pang
- Detentor do copyright no arquivo de licença: Shawn Pang
- Licença: MIT (texto completo em `LICENSE`, copiado de `LICENSE` no repositório)
- Commit: `4ad31b43eef3ae3755cc57ec7e435dab4699ab44` (baixado em 2026-11-22)

## Arquivos incluídos

- `SKILL.md` (de `skills/event-hosting/SKILL.md`)

## Mudanças feitas

1. Frontmatter: `name:` trocado de `event-hosting` para `sfs-event-hosting` (a descrição foi mantida).

O texto do especialista foi mantido em inglês, sem tradução.

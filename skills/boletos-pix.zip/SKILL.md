---
name: boletos-pix
description: Calcula a linha digitável e o código de barras de boleto (padrão FEBRABAN, com dígito verificador Módulo 10/11) e monta o QR Code PIX. Use quando o usuário pedir para "gerar/validar um boleto", "calcular a linha digitável", "montar o código de barras do boleto" — para o QR Code do PIX propriamente dito, ver a skill `gerar-qrcode-codigo-barras` (já inclui o gerador completo); para ler retorno bancário/conciliar pagamentos, ver a skill `extratos-bancarios-ofx-cnab`.
argument-hint: [dados do boleto: banco, valor, vencimento, nosso número]
---

# Boletos e PIX

## Código de barras do boleto (44 dígitos, padrão FEBRABAN)
Estrutura: `banco(3) + moeda(1) + DV geral(1) + fator de vencimento(4) + valor(10) + campo livre(25)`.
```python
from datetime import date

def fator_vencimento(data_vencimento):
    # base FEBRABAN: 07/10/1997 = fator 1000 (o fator "zera"/recomeça periodicamente - confirmar regra vigente do banco)
    base = date(1997, 7, 10)
    return (data_vencimento - base).days + 1000

def calcular_dv_modulo11_boleto(campos_sem_dv):
    pesos = [2, 3, 4, 5, 6, 7, 8, 9]
    soma = 0
    peso_idx = 0
    for c in reversed(campos_sem_dv):
        soma += int(c) * pesos[peso_idx % len(pesos)]
        peso_idx += 1
    resto = soma % 11
    dv = 11 - resto
    return 1 if dv in (0, 10, 11) else dv   # regras especiais do Modulo 11 para boleto: DV 0, 10 ou 11 viram 1
```
O campo livre (25 posições) tem estrutura **específica de cada banco** (posição do nosso número, carteira,
agência/conta variam) — nunca monte o campo livre "genérico"; sempre confirme o layout exato do banco emissor
(cada banco publica seu manual de padrões de arquivo, geralmente disponível no ambiente de desenvolvedor do banco
ou solicitado ao gerente).

## Linha digitável (a partir do código de barras)
A linha digitável reorganiza os 44 dígitos do código de barras em 5 campos com dígitos verificadores próprios
(Módulo 10 simples, diferente do Módulo 11 do código de barras) — a lógica exata de reagrupamento é detalhada e
específica; não tente derivar de memória, use uma biblioteca já testada (`pip install boleto` ou equivalente
mantido) em vez de reimplementar essa parte especificamente, o risco de um boleto com linha digitável errada
(usuário não consegue pagar, ou pior, paga errado) é alto para algo replicado de memória.

## Registro de boleto (API do banco, não é mais "gerar o PDF sozinho")
A maioria dos bancos hoje exige **registro do boleto via API** antes de emitir (o boleto "não registrado" está
sendo descontinuado no mercado brasileiro) — isso significa chamar a API REST do banco (ver skill
`chamar-apis-http` para o padrão de autenticação/chamada) para registrar os dados e receber de volta o código de
barras/linha digitável já validados pelo banco, em vez de calcular tudo localmente. Prefira esse caminho quando
disponível — é mais confiável que cálculo manual.

## PIX
O gerador completo do payload EMV (QR estático, com CRC16) já está na skill `gerar-qrcode-codigo-barras`,
`scripts/gerar_pix.py` — reaproveite de lá em vez de duplicar. Para PIX **dinâmico** (cobrança com API do banco,
QR que expira, webhook de confirmação de pagamento), é uma integração à parte com o PSP/banco (API própria de
cada instituição) — bem mais envolvida que o payload estático, avise o usuário se for esse o caso.

## Regras
- Nunca calcule a linha digitável "na mão" reimplementando a lógica de reagrupamento — use biblioteca testada; um
  erro aqui gera boleto impagável ou, pior, com valor/beneficiário incorreto.
- Sempre confirme o layout do campo livre com a documentação oficial do banco específico — não existe um campo
  livre "padrão" universal entre bancos.
- Boleto com valor/vencimento: sempre confirme esses dois campos com o usuário antes de gerar — são os dados mais
  sensíveis a erro de digitação com impacto financeiro direto.

## Arquivos desta skill
Nenhum script fixo — a lógica de código de barras acima é o ponto de partida; para linha digitável e registro via
API, prefira a biblioteca/API do banco específico em vez de reimplementar.

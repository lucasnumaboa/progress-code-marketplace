---
name: gerar-graficos-matplotlib
description: Gera gráficos (barras, linhas, pizza, Gantt) como imagem PNG/SVG com matplotlib/plotly, com tema visual consistente, para embutir em relatórios/documentos. Use quando o usuário pedir "gerar um gráfico", "visualizar esses dados", "gráfico de Gantt do cronograma", e o destino for uma imagem estática (para dashboard interativo web, prefira uma abordagem de dataviz em HTML/artifact, não esta skill).
argument-hint: [tipo de gráfico] [dados]
---

# Gráficos como imagem (matplotlib/plotly)

## Passo 1 — Instalar
```
pip install matplotlib
```
Use `plotly` (`pip install plotly kaleido`) só se o gráfico precisar de interatividade real (hover, zoom) num HTML —
para imagem estática em relatório/documento, matplotlib é mais simples e não precisa do pacote extra `kaleido` para
exportar PNG.

## Passo 2 — Tema consistente (definir uma vez, reaproveitar em todos os gráficos)
```python
import matplotlib.pyplot as plt

plt.rcParams.update({
    "figure.facecolor": "white",
    "axes.facecolor": "white",
    "axes.edgecolor": "#333333",
    "axes.grid": True,
    "grid.color": "#e0e0e0",
    "font.size": 11,
    "axes.prop_cycle": plt.cycler(color=["#2b579a", "#217346", "#d24726", "#6d4de6", "#e0a800"]),
})
```
Isso evita que cada gráfico gerado numa mesma conversa/relatório pareça de uma fonte diferente.

## Passo 3 — Barras, linhas, pizza
```python
fig, ax = plt.subplots(figsize=(8, 5))
ax.bar(categorias, valores)
ax.set_title("Vendas por região")
ax.set_ylabel("R$")
fig.tight_layout()
fig.savefig("grafico.png", dpi=150)
plt.close(fig)
```
Pizza: evite mais de 5-6 fatias (fica ilegível) — se houver mais categorias, agrupe as menores em "Outros" antes de
plotar. Linha: use `ax.plot(x, y, marker="o")` para séries curtas (o marcador ajuda a ver pontos exatos).

## Passo 4 — Gráfico de Gantt (cronograma)
Matplotlib não tem um tipo "Gantt" pronto — monta-se com `ax.barh` (barras horizontais) usando data de início como
posição e duração como largura:
```python
import matplotlib.dates as mdates

fig, ax = plt.subplots(figsize=(10, 4))
for i, tarefa in enumerate(tarefas):
    ax.barh(i, tarefa["fim"] - tarefa["inicio"], left=tarefa["inicio"])
ax.set_yticks(range(len(tarefas)))
ax.set_yticklabels([t["nome"] for t in tarefas])
ax.xaxis.set_major_formatter(mdates.DateFormatter("%d/%m"))
fig.autofmt_xdate()
```
`inicio`/`fim` precisam ser `datetime.date`/`datetime.datetime` (matplotlib converte automaticamente para o eixo).

## Regras
- Sempre feche a figura (`plt.close(fig)`) depois de salvar — gerar muitos gráficos numa sessão sem fechar consome
  memória e pode deixar o processo lento.
- `dpi=150` é um bom padrão para relatório impresso/PDF; para tela apenas, `dpi=96-100` já basta e gera arquivo
  menor.
- Não invente dados para "completar" um gráfico quando faltam pontos — deixe o buraco visível (`None`/`NaN`) e
  avise o usuário, nunca interpole silenciosamente sem que ele saiba.

## Arquivos desta skill
Nenhum script fixo — os trechos acima cobrem os tipos mais comuns; adapte às colunas/dados reais do usuário.

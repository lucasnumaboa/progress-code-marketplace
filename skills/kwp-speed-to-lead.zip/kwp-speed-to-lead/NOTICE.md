# Aviso de terceiros (NOTICE)

Esta skill é uma cópia adaptada de material de terceiros e é redistribuída sob a licença original. O texto do especialista ficou em inglês, como no original.

- **Origem:** https://github.com/anthropics/knowledge-work-plugins
- **Caminho no repositório:** `small-business/skills/speed-to-lead`
- **Commit:** `0e0fcacddcc892eb92a1b7873ff9d68159c47571` (baixado em 2026-11-22)
- **Autor:** Anthropic
- **Licença:** Apache-2.0 (texto completo em `LICENSE`, copiado de `LICENSE` do repositório)
- Os arquivos `shared/voice-profile.md`, `shared/untrusted-content.md` e `shared/tenant-scope.md` vêm de `small-business/shared/` no mesmo repositório e commit.

## Arquivos incluídos

- `SKILL.md` (de `small-business/skills/speed-to-lead/SKILL.md`)
- `reference/approval.md` (de `small-business/skills/speed-to-lead/reference/approval.md`)
- `reference/gotchas.md` (de `small-business/skills/speed-to-lead/reference/gotchas.md`)
- `reference/qualification.md` (de `small-business/skills/speed-to-lead/reference/qualification.md`)
- `reference/response_patterns.md` (de `small-business/skills/speed-to-lead/reference/response_patterns.md`)
- `shared/voice-profile.md` (de `small-business/shared/voice-profile.md`)
- `shared/untrusted-content.md` (de `small-business/shared/untrusted-content.md`)
- `shared/tenant-scope.md` (de `small-business/shared/tenant-scope.md`)
- `LICENSE`

## Mudanças feitas

- Frontmatter: `name: speed-to-lead` trocado por `name: kwp-speed-to-lead` (a descrição ficou igual).
- `SKILL.md`: removido o item "- **RingEx Chat** — ..." da lista de canais (conector de parceiro do plugin original).
- `SKILL.md`: removida a subseção "### What RingEx Chat is for here" (regras do conector RingEx Chat do plugin original).
- `SKILL.md`: no Step 8, removido o parágrafo "**Deliver the digest ... per the owner's stored output preference**" e seus itens (preferência de saída do plugin: artefato HTML, Canva, Notion, `shared/artifact-style.md`).
- `SKILL.md`: removida a seção "## Scheduled chain mode" (encadeamento com as skills `outreach-composer` e `crm-autopilot` e com o conector RingEx Chat do plugin original).
- `SKILL.md`: removida a seção final "## Using a tool that isn't listed" (oferta da skill `build-connector` e de conexão via Zapier, próprias do plugin original).
- `SKILL.md`: caminhos `../../shared/` trocados por `shared/`, porque os três arquivos compartilhados usados pela skill foram copiados para a pasta `shared/` do pacote.
- Conforme a seção 4(b) da Licença Apache 2.0: os arquivos acima foram modificados em relação ao original nos pontos listados. Fora esses pontos, o texto é o original.

## Arquivos do original que não foram incluídos

- Os demais arquivos de `small-business/shared/` (estilo de artefato, formatos de documento, armadilhas de conectores), específicos do plugin original.
- As skills `lead-triage`, `outreach-composer` e `crm-autopilot` do plugin `small-business` citadas no texto; `lead-triage` de vendas está empacotada à parte como `kwp-lead-triage`.

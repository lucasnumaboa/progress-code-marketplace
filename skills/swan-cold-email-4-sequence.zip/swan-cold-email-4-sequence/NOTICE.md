# Aviso de terceiros (NOTICE)

Esta skill é uma cópia adaptada de material de terceiros e é redistribuída sob a licença original. O texto do especialista ficou em inglês, como no original.

- **Origem:** https://github.com/swan-gtm/gtm-skills
- **Caminho no repositório:** `skills/alex-vacca/cold-email-4-sequence`
- **Commit:** `eb0026f469f90645e1a64168d08a3e0afb59ee12` (baixado em 2026-11-22)
- **Autor:** Alex Vacca (autor da skill); copyright do repositório: Swan
- **Licença:** MIT (texto completo em `LICENSE`, copiado de `LICENSE` do repositório)

## Arquivos incluídos

- `SKILL.md` (de `skills/alex-vacca/cold-email-4-sequence/SKILL.md`)
- `author.md` (de `skills/alex-vacca/author.md`, crédito do autor pedido pelo repositório)
- `LICENSE`

## Mudanças feitas

- Frontmatter: `name: cold-email-4-sequence` trocado por `name: swan-cold-email-4-sequence` (a descrição ficou igual).
- `SKILL.md`: removido o rodapé de divulgação "_Part of [Frontal](https://frontal.so) — free, open GTM skills for your AI agent. [Browse the library →](...)_" (chamada para a biblioteca da empresa do autor).

## Crédito do autor (author.md)

O repositório pede que o crédito do autor acompanhe a skill. Conteúdo do `author.md` original:

```markdown
---
name: Alex Vacca
avatarUrl: "https://www.gtmskills.com/authors/alex-vacca.jpg"
title: "Founder & CEO @ Frontal"
linkedinUrl: "https://linkedin.com/in/alex-vacca"
companyDomain: frontal.so
---

Founder and CEO of Frontal (formerly ColdIQ) — the revenue-systems team behind 275+ B2B companies and one of four Clay Elite Studio partners worldwide. Frontal builds signal-driven revenue engines: clean data, buying signals, and triggered plays wired into HubSpot, Salesforce, and Clay, with results like $7.83M in qualified pipeline for AirOps. Alex's open outbound skills encode how Frontal actually runs cold email, Clay, list building, and signal-based selling.
```

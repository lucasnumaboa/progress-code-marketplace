# Aviso de terceiros (NOTICE)

Esta skill é uma cópia adaptada de material de terceiros e é redistribuída sob a licença original. O texto do especialista ficou em inglês, como no original.

- **Origem:** https://github.com/growthenginenowoslawski/coldoutboundskills
- **Caminho no repositório:** `skills/perfect-company-list`
- **Commit:** `25c5d85fbb5dd3efec97b0ca457cbbc286547476` (baixado em 2026-11-22)
- **Autor:** GrowthEngineX
- **Licença:** MIT (texto completo em `LICENSE`, copiado de `LICENSE` do repositório)

## Arquivos incluídos

- `SKILL.md` (de `skills/perfect-company-list/SKILL.md`)
- `LICENSE`

## Mudanças feitas

- Frontmatter: `name: perfect-company-list` trocado por `name: gex-perfect-company-list` (a descrição ficou igual).

## Arquivos do original que não foram incluídos

- `clay-workflow.md`: fluxos na ferramenta paga Clay.
- `scripts/jev_judge.py`: chama a API paga Jev e exige chave (`TYPESAFE_API_KEY`). O método (perguntar uma pergunta de sim/não por empresa) funciona com qualquer modelo.

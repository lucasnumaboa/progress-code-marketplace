# Origem e mudanças

- **Repositório:** https://github.com/swan-gtm/gtm-skills
- **Caminho no repositório:** `skills/ivan-falco/ads-optimization-signals`
- **Autor:** Ivan Falco (biblioteca Swan GTM Skills)
- **Licença:** MIT (texto em `LICENSE`)
- **Commit usado:** `eb0026f469f90645e1a64168d08a3e0afb59ee12`
- **Arquivos copiados:** `SKILL.md`, `author.md`

O arquivo `author.md` é o crédito do autor pedido pela biblioteca Swan GTM Skills (contribuições sob MIT, segundo o CONTRIBUTING do repositório).

## Mudanças feitas

- no cabeçalho (frontmatter), `name:` passou de `ads-optimization-signals` para `swan-ads-optimization-signals`; a descrição ficou igual
- nenhuma outra alteração no texto do especialista (mantido em inglês)

Empacotada para o marketplace do Progress Code em 2026-11-22.

---
name: apis-rest-bem-desenhadas
description: Projeta APIs REST com versionamento, status codes corretos, paginação, filtros e formato de erro padronizado, e gera um cliente a partir do contrato OpenAPI. Use quando o usuário pedir para "desenhar essa API", "revisar esse contrato de API", "qual status code usar aqui", "gerar um cliente a partir dessa OpenAPI".
argument-hint: [recurso/domínio da API]
---

# APIs REST bem desenhadas

## Versionamento
```
/api/v1/pedidos
```
Versionar na URL (`v1`) é o mais simples de entender e de rotear; versionar por header (`Accept:
application/vnd.empresa.v1+json`) é mais "correto" segundo REST puro mas mais difícil de testar/debugar
manualmente — prefira URL a menos que o usuário já tenha um padrão estabelecido diferente.

## Status codes — os que realmente importam na prática
| Código | Quando usar |
|---|---|
| `200 OK` | Sucesso com corpo de resposta (GET, PUT que retorna o recurso atualizado) |
| `201 Created` | Recurso criado com sucesso (POST) — inclua header `Location` com a URL do novo recurso |
| `204 No Content` | Sucesso sem corpo (DELETE, ou PUT que não retorna o recurso) |
| `400 Bad Request` | Requisição malformada (JSON inválido, campo obrigatório faltando) |
| `401 Unauthorized` | Não autenticado (token ausente/inválido) |
| `403 Forbidden` | Autenticado, mas sem permissão para essa ação específica |
| `404 Not Found` | Recurso não existe |
| `409 Conflict` | Conflito de estado (ex.: criar algo que já existe com a mesma chave única) |
| `422 Unprocessable Entity` | Sintaticamente válido, mas semanticamente inválido (regra de negócio violada) |
| `429 Too Many Requests` | Rate limit — inclua header `Retry-After` |
| `500 Internal Server Error` | Erro não tratado do servidor — nunca vaze stack trace/detalhe interno no corpo |
Confusão comum: `401` vs `403` — `401` é "eu não sei quem você é" (ou o token expirou), `403` é "eu sei quem você é,
e você não pode fazer isso". Trocar os dois confunde quem consome a API sobre se precisa logar de novo ou pedir
permissão.

## Paginação e filtros
```
GET /api/v1/pedidos?status=aberto&page=2&per_page=50&sort=-criado_em
```
Sempre devolva metadados de paginação no corpo ou em headers (`X-Total-Count`, `Link` no estilo GitHub) — sem isso,
quem consome não sabe se há mais páginas sem tentar a próxima e ver se vem vazia.

## Formato de erro padronizado (o mesmo formato para toda a API, sempre)
```json
{
  "error": {
    "code": "CAMPO_INVALIDO",
    "message": "O campo 'email' não é um e-mail válido.",
    "details": [{ "field": "email", "reason": "formato_invalido" }]
  }
}
```
`code` é uma string estável que o cliente pode usar para lógica (`if error.code == "CAMPO_INVALIDO"`); `message` é
para humano ler, pode mudar de texto sem quebrar integração. Nunca misture os dois papéis num campo só.

## Idempotência em escrita
`PUT`/`DELETE` devem ser idempotentes por definição (chamar duas vezes tem o mesmo efeito que chamar uma vez);
`POST` não é idempotente por padrão — se precisar (ex.: evitar pedido duplicado por reenvio de rede), aceite um
header `Idempotency-Key` (ver skill `chamar-apis-http`).

## Gerar cliente a partir do contrato OpenAPI
```
npx @openapitools/openapi-generator-cli generate -i openapi.yaml -g typescript-fetch -o cliente-gerado/
```
Manter o `openapi.yaml` como fonte de verdade (gerado a partir do código com `springdoc-openapi`/`drf-spectacular`/
`FastAPI` automático, ou escrito à mão) evita que o cliente gerado saia dessincronizado da API real.

## Regras
- Nunca devolva `200 OK` para uma operação que falhou (mesmo que o corpo diga `{"success": false}`) — isso quebra
  qualquer cliente HTTP que decide sucesso/falha pelo status code, que é a maioria.
- Nunca vaze stack trace, mensagem de exceção interna ou caminho de arquivo no corpo de erro `500` para o cliente
  — logue no servidor, devolva uma mensagem genérica com um ID de rastreamento (`trace_id`) para correlacionar com
  o log interno depois.
- Breaking change (remover campo, mudar tipo) exige nova versão (`v2`) — nunca altere o contrato de uma versão já
  publicada e em uso.

## Arquivos desta skill
Nenhum script fixo — os trechos acima cobrem os casos mais comuns; adapte ao domínio real da API do usuário.

---
name: preencher-formularios-web-lote
description: Preenche um formulário web repetidas vezes a partir de uma planilha (uma submissão por linha), com verificação de sucesso e relatório de erros, reexecutando só as linhas que falharam. Use quando o usuário pedir para "cadastrar essas 200 linhas nesse sistema web", "preencher esse formulário em lote a partir da planilha", "reenviar só os que falharam da última vez".
argument-hint: [planilha de dados] [URL do formulário]
---

# Preencher formulários web em lote

Esta skill combina `automatizar-navegador-playwright` (preenchimento) com `ler-escrever-xlsx`/`analisar-dados-pandas`
(ler a planilha de origem) — leia essas primeiro se ainda não conhece os detalhes de cada parte.

## Passo 1 — Ler a planilha e validar antes de começar
```python
import pandas as pd
df = pd.read_excel("dados.xlsx")
```
Sempre confirme com o usuário: as colunas da planilha batem com os campos reais do formulário? Rode **1 linha de
teste** primeiro e mostre o resultado antes de processar o lote inteiro — nunca envie 200 submissões reais sem
validar o mapeamento de campos primeiro.

## Passo 2 — Coluna de controle de status (evita reenviar linha já processada)
Adicione (ou use se já existir) uma coluna `status` na planilha: vazia/pendente, `ok`, ou `erro: <motivo>`.
```python
if "status" not in df.columns:
    df["status"] = ""
```

## Passo 3 — Laço de preenchimento com tratamento de erro por linha
```python
from playwright.sync_api import sync_playwright

with sync_playwright() as p:
    navegador = p.chromium.launch(headless=True)
    pagina = navegador.new_page()

    for indice, linha in df.iterrows():
        if linha["status"] == "ok":
            continue  # ja processado com sucesso, pula (permite reexecutar so os que falharam)
        try:
            pagina.goto(url_formulario)
            pagina.get_by_label("Nome").fill(str(linha["nome"]))
            pagina.get_by_label("E-mail").fill(str(linha["email"]))
            pagina.get_by_role("button", name="Enviar").click()
            pagina.wait_for_selector("text=Cadastro realizado", timeout=10000)
            df.at[indice, "status"] = "ok"
        except Exception as e:
            df.at[indice, "status"] = f"erro: {e}"
        df.to_excel("dados.xlsx", index=False)  # salva o progresso a cada linha - nao perde tudo se travar no meio

    navegador.close()
```
Salvar a planilha a cada linha (não só no final) é o que permite parar/retomar sem perder o progresso já feito —
se o processo travar na linha 150 de 200, as 149 já processadas não precisam ser refeitas.

## Passo 4 — Reexecutar só as linhas que falharam
Como o laço acima já pula linhas com `status == "ok"`, rodar o script de novo automaticamente reprocessa só as
que ficaram `erro:` ou vazias — não precisa filtrar manualmente antes de rodar de novo.

## Passo 5 — Relatório final
```python
sucesso = (df["status"] == "ok").sum()
falha = df["status"].str.startswith("erro:", na=False).sum()
print(f"Sucesso: {sucesso} | Falhas: {falha} de {len(df)}")
if falha:
    print(df[df["status"].str.startswith("erro:", na=False)][["nome", "status"]])
```
Sempre entregue esse resumo ao usuário — nunca só "terminei", sem dizer quantos falharam e por quê.

## Regras
- Nunca rode o lote inteiro sem antes confirmar com 1-2 linhas de teste que o mapeamento de campos está certo.
- Sempre salve o progresso incrementalmente (a cada linha, não só no final) — processo longo que trava no meio não
  pode forçar reprocessar tudo de novo.
- Verificação de sucesso real (passo 3, `wait_for_selector` de uma mensagem de confirmação) é obrigatória — não
  assuma sucesso só porque o clique não gerou erro; o formulário pode ter rejeitado silenciosamente por validação.
- Volume alto de submissões pode ser tratado como abuso pelo site de destino — confirme com o usuário se há um
  limite/ritmo esperado (intervalo entre envios) antes de rodar em lote grande.

## Arquivos desta skill
Nenhum script fixo — o laço acima é o ponto de partida; adapte aos campos/planilha reais do usuário.

---
name: comfyui
description: ComfyUI — montar, entender, corrigir e rodar workflows de geração de imagem/vídeo (SD 1.5, SDXL, Flux, vídeo), saber onde colocar cada modelo (checkpoint, LoRA, VAE, text encoder, ControlNet, upscaler), escrever prompts e ajustar seed/steps/CFG/sampler/scheduler/denoise, e automatizar pela API (Python, n8n). Use quando o usuário falar de ComfyUI, workflow de nodes, KSampler, LoRA, ControlNet, inpainting, img2img, upscale, "Missing Node Types", "CUDA out of memory", "modelo não aparece", imagem preta/lavada, ou pedir para gerar imagem por um ComfyUI local.
argument-hint: [o que fazer: diagnosticar workflow, rodar, onde colocar modelo…]
---

# ComfyUI

Pedido: $ARGUMENTS

Nesta pasta:
- `comfy.cmd` — conversa com um ComfyUI rodando (API HTTP). Chame pela ferramenta Bash. Saída sempre em JSON.
- `manual-comfyui.md` — manual completo (38 seções + apêndices). **Não leia inteiro**: use Grep nele pelo assunto
  (ex.: `Grep "Inpainting" manual-comfyui.md`) e leia só a seção que precisar.

| comando | para quê |
|---|---|
| `comfy.cmd status [--url http://host:porta]` | confirma que o ComfyUI está no ar; versões, GPU e VRAM |
| `comfy.cmd modelos` / `comfy.cmd modelos <pasta>` | pastas de modelos / arquivos que o servidor enxerga (checkpoints, loras, vae…) |
| `comfy.cmd nodes --busca <texto>` | nodes instalados (nativos e custom) |
| `comfy.cmd node <Classe> [...]` | entradas (tipo, opções válidas, padrão) e saídas de um node |
| `comfy.cmd validar <workflow_api.json>` | confere o workflow contra o servidor antes de rodar |
| `comfy.cmd rodar <workflow_api.json> [--set NO.entrada=valor] [--seed N] [--saida <pasta>]` | executa, espera e baixa as imagens |
| `comfy.cmd enviar <imagem>` | sobe uma imagem para `input/` (para o Load Image) |
| `comfy.cmd fila` / `comfy.cmd interromper` | fila / para a geração atual |

Endereço padrão `http://127.0.0.1:8188` (a versão desktop do ComfyUI costuma usar a porta `8000`). Outro endereço: `--url` ou a variável `COMFYUI_URL`.

## Passo a passo

### 1. Descubra o ambiente antes de responder
1. Rode `comfy.cmd status`. Se não responder, pergunte ao usuário se o ComfyUI está aberto e em qual endereço. Sem servidor, ainda dá para explicar e revisar JSON, mas **diga que não conferiu no servidor**.
2. Anote a VRAM livre: ela decide resolução, batch e se o modelo cabe.
3. Precisa saber quais modelos existem? `comfy.cmd modelos checkpoints` (ou `loras`, `vae`, `text_encoders`, `diffusion_models`, `controlnet`, `upscale_models`…). Nunca invente nome de arquivo de modelo: use um que apareceu na lista.

### 2. Workflow para rodar ou corrigir
1. A API só aceita o **formato API** (`{"3": {"class_type": "KSampler", "inputs": {...}}}`). O JSON salvo da tela (com `nodes` e `links`) não serve: peça ao usuário **Workflow → Export (API)** (em versões antigas, ative o modo desenvolvedor nas configurações). O `validar` detecta e avisa.
2. `comfy.cmd validar wf.json` e corrija cada erro:
   - `node não instalado` → falta custom node. Diga qual classe falta; o usuário instala pelo ComfyUI Manager e reinicia. Não instale custom nodes por conta própria.
   - `valor não está entre as opções` → o arquivo de modelo não existe com esse nome: troque por um da lista que o erro traz (ou `comfy.cmd node <Classe>`), ou peça para baixar o modelo e pôr na pasta certa (seção 4 do manual).
   - `ligado ao node X, que não existe` / `entrada obrigatória sem valor` → conexão quebrada.
3. Para mudar prompt, seed, tamanho etc. sem editar o arquivo: `--set 6.text="..." --set 5.width=1024 --seed 42` (o número é o id do node no JSON).
4. `comfy.cmd rodar wf.json --saida "<pasta>"` e mostre as imagens salvas com ViewImage antes de dizer que ficou bom.

### 3. Montar um workflow novo
Siga os **tipos de dado**, não os nomes dos nodes: texto → Text Encoder → `CONDITIONING`; imagem → `IMAGE`; a difusão acontece em `LATENT`; o `VAE` faz `IMAGE ⇄ LATENT`; o `MODEL` vai no sampler.
Mínimo text-to-image: `CheckpointLoaderSimple` → (`MODEL`, `CLIP`, `VAE`); `CLIPTextEncode` positivo e negativo; `EmptyLatentImage`; `KSampler`; `VAEDecode`; `SaveImage`. Confira as entradas reais com `comfy.cmd node <Classe>` antes de escrever o JSON. Receitas prontas (LoRA, img2img, inpainting, ControlNet, upscale): seção 34 do manual.
Faça o mínimo funcionar primeiro, depois acrescente uma coisa por vez (LoRA, depois ControlNet…).

### 4. Diagnóstico (ordem que evita perder tempo)
Arquitetura → modelos → loaders → conexões → conditioning → sampler → decode → parâmetros → qualidade. Não comece mexendo em 20 parâmetros. Fluxo de 60 segundos: Apêndice B do manual; problemas comuns: seção 32.

## Armadilhas
- **Compatibilidade manda mais que o nome do arquivo.** LoRA, ControlNet, embedding e VAE têm de ser da mesma família do modelo base (SD 1.5 ≠ SDXL ≠ Flux). `.safetensors` pode ser checkpoint, LoRA, VAE, ControlNet ou encoder: a pasta e o loader dependem do **tipo**, não da extensão.
- **Flux não é "outro checkpoint"**: costuma vir modular (diffusion model + text encoders separados + VAE), com loaders próprios; responde melhor a frases em linguagem natural; o CFG clássico e o negative prompt podem não se comportar igual.
- **Negative prompt e pesos `(termo:1.2)` não são universais.** Dependem do parser/encoder. Use pesos moderados (1.1–1.2) e teste.
- **Imagem preta, lavada ou com cores estranhas** → suspeite primeiro do VAE (errado ou incompatível), depois do dtype. Não é o prompt.
- **LoRA sem efeito** → família errada, strength 0, `MODEL`/`CLIP` não passam pelo Load LoRA, ou falta a trigger word.
- **`CUDA out of memory`** → nesta ordem: resolução, batch, frames (vídeo), modelos auxiliares, quantização/offload, VAE tiled. 2048² tem 4× os pixels de 1024²: gere menor e faça upscale.
- **Denoise** em img2img/upscale é "quanto pode se afastar da entrada", não qualidade: baixo preserva, alto transforma.
- **Modelo não aparece no dropdown** → pasta errada, arquivo de outro tipo, falta atualizar/reiniciar, ou o workflow usa outro loader. `comfy.cmd modelos <pasta>` mostra o que o servidor enxerga.
- Automação: mantenha um workflow-modelo e troque só prompt/seed/tamanho/LoRA (`--set`), em vez de montar o JSON do zero a cada pedido.
- Pastas extras (biblioteca de modelos compartilhada com outras UIs) vão no `extra_model_paths.yaml`; siga o `.example` da versão instalada (seção 5.1).

## Verificação
- `validar` sem erros antes de `rodar`.
- `rodar` com `"ok": true` e os arquivos em `salvo_em`; abra ao menos um com ViewImage e confira se atende ao pedido.
- Ao explicar pasta, loader ou parâmetro sem o servidor, diga que é pelo manual e que o ComfyUI muda rápido (confira o `folder_paths.py` da versão instalada).

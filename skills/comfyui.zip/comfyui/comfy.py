"""ComfyUI pela API HTTP (só biblioteca padrão do Python).

  comfy.py status                                  versões, GPU e VRAM do servidor
  comfy.py modelos [pasta]                         pastas de modelos ou os arquivos de uma pasta (checkpoints, loras…)
  comfy.py nodes [--busca texto]                   nodes instalados (nativos + custom nodes)
  comfy.py node <Classe> [<Classe>...]             entradas (tipo, opções, padrão) e saídas de um node
  comfy.py validar <workflow_api.json>             confere o workflow contra o servidor (nodes, ligações, arquivos de modelo)
  comfy.py rodar <workflow_api.json> [--set NO.entrada=valor ...] [--seed N] [--saida pasta] [--timeout s]
  comfy.py enviar <imagem> [--subpasta x]          sobe uma imagem para a pasta input/ (para Load Image)
  comfy.py fila                                    fila de execução
  comfy.py interromper                             interrompe a geração atual

Servidor: --url http://127.0.0.1:8188 (padrão), ou a variável COMFYUI_URL.
Saída: sempre JSON em stdout (para o agente ler).
"""
import json
import mimetypes
import os
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid

URL = os.environ.get('COMFYUI_URL', 'http://127.0.0.1:8188').rstrip('/')


def out(obj, code=0):
    sys.stdout.write(json.dumps(obj, ensure_ascii=False, indent=1) + '\n')
    sys.exit(code)


def http(method, path, body=None, headers=None, raw=False, timeout=60):
    data = None
    h = dict(headers or {})
    if body is not None and not isinstance(body, (bytes, bytearray)):
        data = json.dumps(body).encode('utf-8')
        h.setdefault('Content-Type', 'application/json')
    elif body is not None:
        data = body
    req = urllib.request.Request(URL + path, data=data, headers=h, method=method)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            b = r.read()
            return b if raw else (json.loads(b.decode('utf-8')) if b.strip() else None)
    except urllib.error.HTTPError as e:
        txt = e.read().decode('utf-8', 'replace')
        try:
            return {'__erro_http': e.code, 'detalhe': json.loads(txt)}
        except Exception:
            return {'__erro_http': e.code, 'detalhe': txt[:2000]}
    except (urllib.error.URLError, ConnectionError, TimeoutError) as e:
        out({'erro': f'ComfyUI não respondeu em {URL} ({getattr(e, "reason", e)}).',
             'proximo_passo': 'Confirme se o ComfyUI está aberto e em qual endereço (padrão http://127.0.0.1:8188; na versão desktop a porta pode ser 8000). Use --url ou COMFYUI_URL.'}, 2)


def args_opts(argv):
    pos, opts = [], {}
    i = 0
    while i < len(argv):
        a = argv[i]
        if a.startswith('--'):
            k = a[2:]
            v = argv[i + 1] if i + 1 < len(argv) and not argv[i + 1].startswith('--') else True
            if k == 'set':
                opts.setdefault('set', []).append(v)
            else:
                opts[k] = v
            i += 2 if v is not True else 1
        else:
            pos.append(a)
            i += 1
    return pos, opts


# ------------------------------------------------------------------ comandos

def cmd_status(_pos, _o):
    s = http('GET', '/system_stats')
    if isinstance(s, dict) and '__erro_http' in s:
        out({'erro': 'o servidor respondeu mas não é um ComfyUI (sem /system_stats)', 'detalhe': s}, 2)
    devs = [{'nome': d.get('name'), 'tipo': d.get('type'), 'vram_total_gb': round((d.get('vram_total') or 0) / 1024 ** 3, 1),
             'vram_livre_gb': round((d.get('vram_free') or 0) / 1024 ** 3, 1)} for d in (s.get('devices') or [])]
    out({'url': URL, 'sistema': s.get('system', {}), 'dispositivos': devs})


def cmd_modelos(pos, _o):
    if not pos:
        pastas = http('GET', '/models')
        out({'pastas': pastas, 'dica': 'comfy.py modelos <pasta> lista os arquivos (ex.: checkpoints, loras, vae)'})
    pasta = pos[0]
    arqs = http('GET', f'/models/{urllib.parse.quote(pasta)}')
    if isinstance(arqs, dict) and '__erro_http' in arqs:
        out({'erro': f'pasta de modelos "{pasta}" não existe neste ComfyUI', 'pastas': http('GET', '/models')}, 1)
    out({'pasta': pasta, 'total': len(arqs or []), 'arquivos': arqs})


_info_cache = None


def object_info():
    global _info_cache
    if _info_cache is None:
        _info_cache = http('GET', '/object_info', timeout=120) or {}
    return _info_cache


def cmd_nodes(_pos, o):
    info = object_info()
    busca = str(o.get('busca', '')).lower()
    itens = []
    for nome, d in info.items():
        txt = f"{nome} {d.get('display_name', '')} {d.get('category', '')}".lower()
        if busca and busca not in txt:
            continue
        itens.append({'classe': nome, 'nome': d.get('display_name'), 'categoria': d.get('category'), 'custom': d.get('python_module', '').startswith('custom_nodes')})
    out({'total': len(itens), 'nodes': itens[:300], 'cortado': len(itens) > 300})


def spec_inputs(d, full=False):
    res = {}
    for grupo in ('required', 'optional'):
        for k, v in (d.get('input', {}).get(grupo) or {}).items():
            tipo = v[0] if isinstance(v, list) and v else v
            extra = v[1] if isinstance(v, list) and len(v) > 1 and isinstance(v[1], dict) else {}
            item = {'obrigatorio': grupo == 'required'}
            if isinstance(tipo, list):
                item['tipo'] = 'COMBO'
                item['opcoes'] = tipo if full else tipo[:60]
                if not full and len(tipo) > 60:
                    item['opcoes_total'] = len(tipo)
            elif tipo == 'COMBO' and isinstance(extra.get('options'), list):
                item['tipo'] = 'COMBO'
                item['opcoes'] = extra['options'] if full else extra['options'][:60]
            else:
                item['tipo'] = tipo
            for kk in ('default', 'min', 'max', 'step'):
                if kk in extra:
                    item[kk] = extra[kk]
            res[k] = item
    return res


def cmd_node(pos, _o):
    if not pos:
        out({'erro': 'informe a classe do node (ex.: KSampler)'}, 1)
    info = object_info()
    res = {}
    for c in pos:
        d = info.get(c)
        if not d:
            parecidos = [n for n in info if c.lower() in n.lower()][:15]
            res[c] = {'erro': 'node não instalado', 'parecidos': parecidos}
            continue
        res[c] = {'nome': d.get('display_name'), 'categoria': d.get('category'), 'entradas': spec_inputs(d),
                  'saidas': list(zip(d.get('output_name') or d.get('output') or [], d.get('output') or [])), 'modulo': d.get('python_module')}
    out(res)


def load_workflow(path):
    try:
        wf = json.load(open(path, encoding='utf-8'))
    except Exception as e:
        out({'erro': f'não li o JSON {path}: {e}'}, 1)
    if isinstance(wf, dict) and 'nodes' in wf and 'links' in wf:
        out({'erro': 'este JSON é o formato da TELA (nodes/links), não o formato da API.',
             'proximo_passo': 'No ComfyUI: menu Workflow → Export (API) (ou ative o modo desenvolvedor nas configurações para ver a opção) e use o arquivo exportado.'}, 1)
    if isinstance(wf, dict) and 'prompt' in wf and isinstance(wf['prompt'], dict):
        wf = wf['prompt']
    if not isinstance(wf, dict) or not all(isinstance(v, dict) and 'class_type' in v for v in wf.values()):
        out({'erro': 'JSON não parece um workflow no formato da API ({"id": {"class_type": ..., "inputs": {...}}})'}, 1)
    return wf


def check(wf):
    info = object_info()
    erros, avisos = [], []
    for nid, n in wf.items():
        ct = n.get('class_type')
        d = info.get(ct)
        if not d:
            erros.append({'no': nid, 'classe': ct, 'problema': 'node não instalado (Missing Node Type)', 'dica': 'instale o custom node que fornece esta classe (ComfyUI Manager) e reinicie'})
            continue
        spec = spec_inputs(d, full=True)
        inputs = n.get('inputs', {})
        for k, s in spec.items():
            if s['obrigatorio'] and k not in inputs:
                erros.append({'no': nid, 'classe': ct, 'entrada': k, 'problema': 'entrada obrigatória sem valor nem ligação'})
        for k, v in inputs.items():
            if isinstance(v, list) and len(v) == 2 and isinstance(v[0], str):
                if v[0] not in wf:
                    erros.append({'no': nid, 'classe': ct, 'entrada': k, 'problema': f'ligado ao node {v[0]}, que não existe no workflow'})
                continue
            s = spec.get(k)
            if s and s.get('tipo') == 'COMBO' and s.get('opcoes') and v not in s['opcoes']:
                erros.append({'no': nid, 'classe': ct, 'entrada': k, 'valor': v, 'problema': 'valor não está entre as opções do servidor (arquivo de modelo ausente ou nome diferente?)', 'opcoes': s['opcoes'][:20]})
    # saída: qualquer node que o servidor marca como output_node
    saidas = [x for x in wf.values() if (info.get(x.get('class_type')) or {}).get('output_node')]
    if not saidas:
        avisos.append('nenhum node de saída conhecido (SaveImage/PreviewImage/…): o servidor pode recusar ("Prompt has no outputs")')
    return erros, avisos


def cmd_validar(pos, _o):
    if not pos:
        out({'erro': 'informe o arquivo do workflow (formato API)'}, 1)
    wf = load_workflow(pos[0])
    erros, avisos = check(wf)
    out({'ok': not erros, 'nodes': len(wf), 'erros': erros, 'avisos': avisos})


def set_value(wf, expr):
    if '=' not in expr or '.' not in expr.split('=', 1)[0]:
        out({'erro': f'--set "{expr}" inválido; use NO.entrada=valor (ex.: 6.text="um gato", 3.seed=42)'}, 1)
    k, v = expr.split('=', 1)
    nid, campo = k.split('.', 1)
    if nid not in wf:
        out({'erro': f'--set: node {nid} não existe no workflow', 'nodes': {i: n.get('class_type') for i, n in wf.items()}}, 1)
    try:
        val = json.loads(v)
    except Exception:
        val = v
    wf[nid].setdefault('inputs', {})[campo] = val


def cmd_rodar(pos, o):
    if not pos:
        out({'erro': 'informe o arquivo do workflow (formato API)'}, 1)
    wf = load_workflow(pos[0])
    for s in o.get('set', []):
        set_value(wf, s)
    if 'seed' in o:
        for n in wf.values():
            for k in ('seed', 'noise_seed'):
                if k in n.get('inputs', {}) and not isinstance(n['inputs'][k], list):
                    n['inputs'][k] = int(o['seed'])
    erros, avisos = check(wf)
    if erros:
        out({'ok': False, 'etapa': 'validacao', 'erros': erros, 'avisos': avisos, 'proximo_passo': 'corrija os erros (comfy.py node <Classe> mostra as opções válidas) antes de rodar'}, 1)
    client = str(uuid.uuid4())
    r = http('POST', '/prompt', {'prompt': wf, 'client_id': client})
    if not isinstance(r, dict) or 'prompt_id' not in r:
        out({'ok': False, 'etapa': 'envio', 'resposta': r}, 1)
    pid = r['prompt_id']
    if r.get('node_errors'):
        out({'ok': False, 'etapa': 'envio', 'prompt_id': pid, 'node_errors': r['node_errors']}, 1)
    limite = time.time() + float(o.get('timeout', 900))
    hist = None
    while time.time() < limite:
        h = http('GET', f'/history/{pid}')
        if isinstance(h, dict) and pid in h:
            hist = h[pid]
            st = hist.get('status', {})
            if st.get('completed') or st.get('status_str') in ('success', 'error'):
                break
        time.sleep(1.5)
    if hist is None:
        out({'ok': False, 'etapa': 'execucao', 'prompt_id': pid, 'erro': f'não terminou em {o.get("timeout", 900)} s (continua na fila do ComfyUI)'}, 1)
    st = hist.get('status', {})
    if st.get('status_str') == 'error':
        msgs = [m for m in st.get('messages', []) if m and m[0] in ('execution_error', 'execution_interrupted')]
        out({'ok': False, 'etapa': 'execucao', 'prompt_id': pid, 'erros': [m[1] for m in msgs][:5] or st}, 1)
    saida = o.get('saida')
    if saida and saida is not True:
        os.makedirs(saida, exist_ok=True)
    arquivos = []
    for nid, res in (hist.get('outputs') or {}).items():
        for grupo in ('images', 'gifs', 'videos', 'audio'):
            for f in res.get(grupo, []) or []:
                item = {'no': nid, 'arquivo': f.get('filename'), 'subpasta': f.get('subfolder', ''), 'tipo': f.get('type', 'output')}
                if saida and saida is not True:
                    q = urllib.parse.urlencode({'filename': item['arquivo'], 'subfolder': item['subpasta'], 'type': item['tipo']})
                    b = http('GET', f'/view?{q}', raw=True, timeout=300)
                    dest = os.path.join(saida, item['arquivo'])
                    with open(dest, 'wb') as fh:
                        fh.write(b)
                    item['salvo_em'] = os.path.abspath(dest)
                arquivos.append(item)
    out({'ok': True, 'prompt_id': pid, 'arquivos': arquivos, 'avisos': avisos})


def cmd_enviar(pos, o):
    if not pos or not os.path.isfile(pos[0]):
        out({'erro': 'informe uma imagem que exista'}, 1)
    p = pos[0]
    bnd = uuid.uuid4().hex
    mime = mimetypes.guess_type(p)[0] or 'application/octet-stream'
    partes = [f'--{bnd}\r\nContent-Disposition: form-data; name="image"; filename="{os.path.basename(p)}"\r\nContent-Type: {mime}\r\n\r\n'.encode(), open(p, 'rb').read(), b'\r\n']
    if o.get('subpasta'):
        partes.append(f'--{bnd}\r\nContent-Disposition: form-data; name="subfolder"\r\n\r\n{o["subpasta"]}\r\n'.encode())
    partes.append(f'--{bnd}--\r\n'.encode())
    r = http('POST', '/upload/image', b''.join(partes), {'Content-Type': f'multipart/form-data; boundary={bnd}'})
    out({'enviado': r, 'uso': 'no Load Image, use o "name" devolvido (com a subpasta, se houver)'})


def cmd_fila(_pos, _o):
    q = http('GET', '/queue') or {}
    out({'rodando': len(q.get('queue_running', [])), 'esperando': len(q.get('queue_pending', []))})


def cmd_interromper(_pos, _o):
    http('POST', '/interrupt', {})
    out({'ok': True})


CMDS = {'status': cmd_status, 'modelos': cmd_modelos, 'nodes': cmd_nodes, 'node': cmd_node, 'validar': cmd_validar, 'rodar': cmd_rodar,
        'enviar': cmd_enviar, 'fila': cmd_fila, 'interromper': cmd_interromper}

if __name__ == '__main__':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass
    pos, opts = args_opts(sys.argv[1:])
    if 'url' in opts:
        URL = str(opts.pop('url')).rstrip('/')
    if not pos or pos[0] not in CMDS:
        out({'erro': 'comando inválido', 'uso': __doc__.strip()}, 1)
    CMDS[pos[0]](pos[1:], opts)

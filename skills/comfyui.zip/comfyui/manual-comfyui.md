# ComfyUI — Manual Completo de Workflows, Modelos, Prompts e Configuração

> **Status:** guia de referência para uso local do ComfyUI, revisado em setembro de 2026.
>
> **Objetivo:** servir como uma “bíblia prática” para entender o ComfyUI desde a estrutura de pastas até workflows avançados, prompts, modelos, LoRAs, ControlNet, inpainting, upscaling, vídeo, automação e troubleshooting.
>
> **Nota importante:** o ComfyUI é altamente extensível. Nodes e modelos adicionados por custom nodes podem usar nomes, loaders, pastas e parâmetros diferentes. Para modelos de terceiros, a documentação do projeto que publicou o modelo/node continua sendo a referência final.

---

# Sumário

1. [O que é o ComfyUI](#1-o-que-é-o-comfyui)
2. [Como pensar em um workflow](#2-como-pensar-em-um-workflow)
3. [Estrutura de diretórios](#3-estrutura-de-diretórios)
4. [Onde colocar cada tipo de modelo](#4-onde-colocar-cada-tipo-de-modelo)
5. [Como o ComfyUI encontra os modelos](#5-como-o-comfyui-encontra-os-modelos)
6. [Anatomia dos principais tipos de modelo](#6-anatomia-dos-principais-tipos-de-modelo)
7. [Arquitetura interna: MODEL, CLIP, CONDITIONING, LATENT e IMAGE](#7-arquitetura-interna-model-clip-conditioning-latent-e-image)
8. [Workflow mínimo de Text-to-Image](#8-workflow-mínimo-de-text-to-image)
9. [Prompt positivo e negativo](#9-prompt-positivo-e-negativo)
10. [Engenharia de prompts](#10-engenharia-de-prompts)
11. [Pesos e sintaxe de prompt](#11-pesos-e-sintaxe-de-prompt)
12. [Seed, Steps, CFG, Sampler, Scheduler e Denoise](#12-seed-steps-cfg-sampler-scheduler-e-denoise)
13. [Checkpoints e loaders](#13-checkpoints-e-loaders)
14. [VAE](#14-vae)
15. [Text Encoders: CLIP, T5 e variantes](#15-text-encoders-clip-t5-e-variantes)
16. [LoRA](#16-lora)
17. [Embeddings](#17-embeddings)
18. [ControlNet e controle estrutural](#18-controlnet-e-controle-estrutural)
19. [IP-Adapter e referência visual](#19-ip-adapter-e-referência-visual)
20. [Img2Img](#20-img2img)
21. [Inpainting](#21-inpainting)
22. [Upscaling](#22-upscaling)
23. [Flux e arquiteturas modernas](#23-flux-e-arquiteturas-modernas)
24. [SD 1.5 e SDXL](#24-sd-15-e-sdxl)
25. [Modelos de vídeo](#25-modelos-de-vídeo)
26. [Custom Nodes](#26-custom-nodes)
27. [ComfyUI Manager e dependências](#27-comfyui-manager-e-dependências)
28. [Performance e VRAM](#28-performance-e-vram)
29. [Organização profissional de workflows](#29-organização-profissional-de-workflows)
30. [API e automação](#30-api-e-automação)
31. [Integração com Python e n8n](#31-integração-com-python-e-n8n)
32. [Troubleshooting](#32-troubleshooting)
33. [Metodologia para analisar um workflow desconhecido](#33-metodologia-para-analisar-um-workflow-desconhecido)
34. [Receitas de workflows](#34-receitas-de-workflows)
35. [Checklist de instalação](#35-checklist-de-instalação)
36. [Checklist de geração](#36-checklist-de-geração)
37. [Glossário](#37-glossário)
38. [Referências oficiais](#38-referências-oficiais)

---

# 1. O que é o ComfyUI

O ComfyUI é uma interface gráfica baseada em **grafos de nodes** para execução de modelos generativos. Em vez de esconder o processo atrás de uma única tela de “Prompt + Generate”, ele expõe as etapas do pipeline como blocos conectados.

A ideia central é:

```text
ENTRADA
   ↓
PROCESSAMENTO / CONDICIONAMENTO
   ↓
MODELO
   ↓
SAMPLING
   ↓
LATENT
   ↓
DECODIFICAÇÃO
   ↓
IMAGEM / VÍDEO / ÁUDIO / OUTRO RESULTADO
```

Isso permite montar desde um workflow simples:

```text
Checkpoint
   ↓
CLIP Text Encode
   ↓
KSampler
   ↓
VAE Decode
   ↓
Save Image
```

até pipelines complexos:

```text
Prompt
   ↓
Text Encoder ─────────┐
                       │
Reference Image → IP Adapter
                       │
Pose Image → ControlNet
                       │
LoRA ───────────────→ MODEL
                       │
                       ↓
                    KSampler
                       ↓
                    Latent
                       ↓
                  Hires / Upscale
                       ↓
                  Face/Detail Pass
                       ↓
                  Save / Preview
```

## 1.1 Por que workflows são diferentes entre modelos

Nem todo modelo moderno funciona da mesma maneira.

Exemplos conceituais:

- Um checkpoint “all-in-one” pode entregar modelo + text encoders + VAE no mesmo arquivo.
- Um pipeline modular pode exigir um **diffusion model** separado.
- Outro pode usar CLIP + T5.
- Outro pode usar loaders específicos fornecidos por custom nodes.
- Um modelo de vídeo pode exigir encoder de texto, VAE de vídeo, componentes temporais e nodes próprios.

Portanto, não existe um único “workflow universal”.

---

# 2. Como pensar em um workflow

A maneira mais importante de aprender ComfyUI é parar de pensar primeiro nos nomes dos nodes e começar a pensar nos **tipos de dados**.

Alguns tipos que aparecem com frequência:

| Tipo | Significado |
|---|---|
| `MODEL` | Modelo que será usado pelo sampler |
| `CLIP` | Encoder de texto ou componente responsável por transformar texto em representação utilizável pelo pipeline |
| `CONDITIONING` | Informação condicionante produzida pelo encoder |
| `LATENT` | Representação comprimida da imagem, antes/depois do sampling |
| `IMAGE` | Imagem decodificada |
| `MASK` | Máscara para controlar regiões |
| `VAE` | Encoder/decoder entre imagem e espaço latente |
| `SIGMAS` | Agenda de níveis de ruído utilizada por certos samplers/workflows |
| `CONTROL_NET` | Modelo/componente de controle estrutural |
| `CLIP_VISION` | Encoder visual usado em pipelines de referência de imagem |

Uma regra mental útil:

> **Texto normalmente vira CONDITIONING.**
>
> **Imagem normalmente entra como IMAGE.**
>
> **O processo de difusão acontece em LATENT.**
>
> **O VAE faz a ponte entre IMAGE e LATENT.**
>
> **O MODEL é o componente que efetivamente participa da geração.**

---

# 3. Estrutura de diretórios

Em uma instalação típica, a estrutura pode se parecer com:

```text
ComfyUI/
├── models/
│   ├── checkpoints/
│   ├── configs/
│   ├── loras/
│   ├── vae/
│   ├── text_encoders/
│   ├── clip/
│   ├── diffusion_models/
│   ├── unet/
│   ├── clip_vision/
│   ├── style_models/
│   ├── embeddings/
│   ├── diffusers/
│   ├── vae_approx/
│   ├── controlnet/
│   ├── t2i_adapter/
│   ├── gligen/
│   ├── upscale_models/
│   ├── latent_upscale_models/
│   ├── hypernetworks/
│   ├── photomaker/
│   ├── classifiers/
│   ├── model_patches/
│   ├── audio_encoders/
│   ├── background_removal/
│   ├── frame_interpolation/
│   ├── geometry_estimation/
│   ├── optical_flow/
│   └── detection/
│
├── custom_nodes/
├── input/
├── output/
├── temp/
└── user/
```

A estrutura acima representa os diretórios reconhecidos pelo código atual do ComfyUI. Alguns diretórios podem não estar criados em uma instalação recém-instalada; eles passam a ser necessários conforme os modelos/features usados.

## 3.1 `models/`

É onde ficam os modelos.

A subpasta **não é apenas organização visual**. O ComfyUI associa tipos de modelo a categorias de caminho.

Exemplos:

```text
models/checkpoints/
models/loras/
models/vae/
models/controlnet/
models/upscale_models/
```

## 3.2 `custom_nodes/`

É onde ficam extensões que adicionam nodes, recursos e integrações.

Exemplo:

```text
ComfyUI/
└── custom_nodes/
    ├── ComfyUI-Manager/
    ├── ComfyUI-Impact-Pack/
    ├── outro-custom-node/
    └── ...
```

Nem todo custom node é somente um node visual. Algumas extensões adicionam dependências Python, recursos do frontend, APIs, loaders e outras integrações.

## 3.3 `input/`

Arquivos que serão utilizados como entrada:

```text
input/
├── foto.jpg
├── referencia.png
└── pose.png
```

Nodes como `Load Image` podem trabalhar com esses arquivos.

## 3.4 `output/`

Onde resultados são normalmente salvos:

```text
output/
├── imagem_001.png
├── imagem_002.png
└── ...
```

Workflows ou nodes especializados podem criar subpastas.

## 3.5 `temp/`

Arquivos temporários.

Não trate essa pasta como armazenamento permanente de resultados.

## 3.6 `user/`

Área de dados/configuração do usuário e elementos associados à aplicação.

---

# 4. Onde colocar cada tipo de modelo

Esta é uma das referências mais úteis.

## 4.1 Tabela principal

| Tipo | Pasta comum |
|---|---|
| Checkpoint | `models/checkpoints/` |
| LoRA | `models/loras/` |
| VAE | `models/vae/` |
| Text Encoder | `models/text_encoders/` |
| CLIP legado | `models/clip/` |
| Diffusion Model / UNet modular | `models/diffusion_models/` ou `models/unet/` |
| CLIP Vision | `models/clip_vision/` |
| Embedding | `models/embeddings/` |
| ControlNet | `models/controlnet/` |
| T2I Adapter | `models/t2i_adapter/` via configuração correspondente |
| Upscaler | `models/upscale_models/` |
| Latent Upscaler | `models/latent_upscale_models/` |
| VAE Approx | `models/vae_approx/` |
| Hypernetwork | `models/hypernetworks/` |
| Style model | `models/style_models/` |
| GLIGEN | `models/gligen/` |
| PhotoMaker | `models/photomaker/` |
| Model patches | `models/model_patches/` |
| Audio encoders | `models/audio_encoders/` |
| Background removal | `models/background_removal/` |
| Frame interpolation | `models/frame_interpolation/` |
| Optical flow | `models/optical_flow/` |
| Geometry estimation | `models/geometry_estimation/` |
| Detection | `models/detection/` |

## 4.2 Atenção: o nome do arquivo não determina o loader

Não pense:

> “O arquivo termina em `.safetensors`, então pode ir para qualquer pasta.”

Não.

O formato do arquivo é apenas uma parte da informação.

Um arquivo `.safetensors` pode representar:

- checkpoint;
- LoRA;
- VAE;
- ControlNet;
- CLIP;
- UNet/diffusion model;
- outro componente.

O **tipo funcional do modelo** determina o loader e o local adequado.

---

# 5. Como o ComfyUI encontra os modelos

O ComfyUI mantém internamente uma lista de categorias e caminhos.

A implementação atual possui entradas como:

```python
folder_names_and_paths["checkpoints"]
folder_names_and_paths["loras"]
folder_names_and_paths["vae"]
folder_names_and_paths["text_encoders"]
folder_names_and_paths["diffusion_models"]
folder_names_and_paths["controlnet"]
folder_names_and_paths["upscale_models"]
```

Para usar um modelo, o fluxo geral é:

```text
1. Baixar o modelo
        ↓
2. Identificar o tipo
        ↓
3. Colocar na categoria correta
        ↓
4. Abrir/atualizar o ComfyUI
        ↓
5. Usar o loader correspondente
        ↓
6. Selecionar o arquivo
```

## 5.1 `extra_model_paths.yaml`

Quando você não quer duplicar modelos entre diferentes interfaces, pode configurar caminhos externos.

A função é especialmente útil para situações como:

```text
SSD 1:
  ComfyUI
  apenas aplicação

SSD 2:
  AI Models
      checkpoints/
      loras/
      vae/
      controlnet/
```

O ComfyUI possui um exemplo oficial de `extra_model_paths.yaml`.

Conceito:

```yaml
comfyui:
  base_path: D:/AI/Models

  checkpoints: checkpoints
  loras: loras
  vae: vae
  text_encoders:
    - text_encoders
    - clip
  diffusion_models:
    - diffusion_models
    - unet
  controlnet:
    - controlnet
    - t2i_adapter
  upscale_models: upscale_models
```

A sintaxe exata deve seguir o arquivo exemplo da versão em uso.

## 5.2 Compartilhar modelos com outras UIs

Esse recurso é especialmente útil para evitar:

```text
ComfyUI/checkpointA.safetensors
A1111/checkpointA.safetensors
FooUI/checkpointA.safetensors
```

em três locais diferentes.

A ideia melhor é:

```text
D:/AI-MODELS/
├── checkpoints/
├── loras/
├── vae/
├── controlnet/
└── ...
```

e apontar as interfaces para essa biblioteca central.

---

# 6. Anatomia dos principais tipos de modelo

## 6.1 Checkpoint

Um checkpoint tradicional pode conter vários componentes em um único arquivo.

Mentalmente:

```text
CHECKPOINT
├── MODEL
├── CLIP
└── VAE
```

Na prática, a estrutura interna depende da arquitetura.

### Exemplos de uso

```text
Checkpoint Loader
    ├── MODEL
    ├── CLIP
    └── VAE
```

Isso explica por que um único node pode alimentar várias partes do workflow.

---

## 6.2 Diffusion Model / UNet

Em pipelines modulares, o componente principal do modelo pode estar separado.

Conceito:

```text
Diffusion Model
        ↓
     MODEL
```

Esses pipelines podem exigir componentes adicionais.

---

## 6.3 LoRA

LoRA é uma adaptação relativamente pequena aplicada ao modelo/base para alterar comportamento.

Conceito:

```text
BASE MODEL
     +
   LoRA
     ↓
MODEL MODIFICADO
```

Também pode haver LoRAs que afetam o componente de texto/conditioning dependendo da arquitetura.

---

## 6.4 VAE

VAE faz a ponte entre:

```text
IMAGE ⇄ LATENT
```

Em um fluxo típico:

```text
LATENT
  ↓
VAE Decode
  ↓
IMAGE
```

E no sentido contrário:

```text
IMAGE
  ↓
VAE Encode
  ↓
LATENT
```

---

## 6.5 Text Encoder

Transforma linguagem em representações que podem ser usadas para condicionamento.

Exemplo conceitual:

```text
"homem andando em uma cidade futurista"
                  ↓
             TEXT ENCODER
                  ↓
             CONDITIONING
```

---

## 6.6 ControlNet

Usado para controlar aspectos estruturais da geração.

Pode receber, por exemplo:

```text
imagem de pose
       ↓
   OpenPose
       ↓
 ControlNet
       ↓
 CONDITIONING
```

---

## 6.7 Upscaler Model

Modelo especializado para super-resolução.

```text
imagem pequena
      ↓
upscale model
      ↓
imagem maior
```

Isso não é a mesma coisa que “gerar uma imagem do zero”.

---

# 7. Arquitetura interna: MODEL, CLIP, CONDITIONING, LATENT e IMAGE

Essa parte é fundamental para entender qualquer workflow.

## 7.1 `IMAGE`

É a imagem que você normalmente vê.

Exemplo:

```text
Load Image
    ↓
IMAGE
```

## 7.2 `LATENT`

É uma representação comprimida usada pelo pipeline de difusão.

Em vez de trabalhar diretamente com milhões de valores RGB, o pipeline trabalha com uma representação mais adequada ao processo de geração.

## 7.3 `CONDITIONING`

É a informação utilizada para orientar o processo.

Frequentemente vem do texto:

```text
Prompt
  ↓
Text Encoder
  ↓
Conditioning
```

Também pode incorporar controles adicionais.

## 7.4 `MODEL`

É o modelo de difusão usado para prever/transformar estados durante o sampling.

## 7.5 `CLIP`

No contexto de muitos workflows clássicos, é o componente usado para converter texto em uma representação que possa ser utilizada pelo modelo.

Em arquiteturas modernas, o sistema pode utilizar mais de um encoder ou encoders diferentes.

---

# 8. Workflow mínimo de Text-to-Image

O workflow clássico pode ser representado assim:

```text
                 ┌─────────────────┐
                 │ Load Checkpoint │
                 └────────┬────────┘
                          │
               ┌──────────┴──────────┐
               │                     │
             MODEL                 CLIP
               │                     │
               │          ┌──────────┴─────────┐
               │          │                    │
               │    Positive Prompt      Negative Prompt
               │          │                    │
               │    CLIP Text Encode     CLIP Text Encode
               │          │                    │
               │          └──────────┬─────────┘
               │                     │
               │                  CONDITIONING
               │                     │
         ┌─────┴─────────────────────┴─────┐
         │             KSampler             │
         └────────────────┬─────────────────┘
                          │
                       LATENT
                          │
                      VAE Decode
                          │
                        IMAGE
                          │
                     Save Image
```

## 8.1 Nodes básicos

### Load Checkpoint

Saídas típicas:

```text
MODEL
CLIP
VAE
```

### CLIP Text Encode

Entrada:

```text
CLIP
TEXT
```

Saída:

```text
CONDITIONING
```

### Empty Latent Image

Cria o espaço latente inicial.

Parâmetros comuns:

```text
width
height
batch_size
```

### KSampler

Recebe:

```text
MODEL
POSITIVE CONDITIONING
NEGATIVE CONDITIONING
LATENT
```

e parâmetros de sampling.

### VAE Decode

Recebe:

```text
VAE
LATENT
```

e produz:

```text
IMAGE
```

### Save Image

Grava o resultado.

---

# 9. Prompt positivo e negativo

## 9.1 Prompt positivo

Descreve o que você quer.

Exemplo conceitual:

```text
A futuristic Brazilian city at night,
wet streets, neon signs, cinematic lighting,
high detail, realistic photography
```

## 9.2 Prompt negativo

Em arquiteturas/workflows que utilizam negative conditioning, descreve características a evitar.

Exemplo:

```text
blurry, low quality, distorted,
deformed anatomy, unwanted artifacts
```

Mas:

> Negative prompt não é universal.

Alguns modelos respondem melhor com um negative prompt tradicional; outros quase não se beneficiam dele; outros workflows sequer possuem uma etapa separada de negative conditioning.

---

# 10. Engenharia de prompts

Uma estrutura prática é:

```text
[SUJEITO]
+
[CARACTERÍSTICAS]
+
[AÇÃO/POSE]
+
[ROUPA]
+
[AMBIENTE]
+
[ILUMINAÇÃO]
+
[CÂMERA]
+
[ESTILO]
+
[QUALIDADE]
```

Exemplo:

```text
young man,
short dark hair,
black jacket,
standing on a rainy street,
cyberpunk city background,
neon reflections,
cinematic lighting,
35mm photography,
shallow depth of field,
high detail
```

## 10.1 Sujeito

Perguntas:

- quem/qual objeto?
- quantos?
- características relevantes?
- posição?

## 10.2 Ação

Exemplos:

```text
standing
walking
running
sitting
looking at the camera
holding a guitar
```

## 10.3 Ambiente

```text
city street
studio
forest
office
space station
beach
```

## 10.4 Iluminação

```text
soft light
rim light
backlight
golden hour
dramatic lighting
neon lighting
```

## 10.5 Câmera

```text
close-up
medium shot
wide shot
low angle
high angle
35mm lens
85mm lens
shallow depth of field
```

Não trate esses termos como comandos mágicos. O comportamento depende do modelo e do treinamento.

---

# 11. Pesos e sintaxe de prompt

Uma sintaxe comum em workflows baseados em CLIP é o uso de pesos:

```text
(word:1.2)
```

Conceitualmente:

```text
normal:
red jacket

mais peso:
(red jacket:1.2)
```

Alguns ambientes também aceitam formas abreviadas, mas isso depende do parser utilizado.

## 11.1 Não existe “peso universal”

Uma das confusões mais frequentes é assumir:

```text
(termo:2.0)
```

significa a mesma coisa em todos os modelos.

Não necessariamente.

O significado prático depende de:

- parser de prompt;
- encoder;
- arquitetura;
- loader;
- workflow;
- implementação do node.

## 11.2 Regra prática

Use pesos moderados primeiro.

Exemplo:

```text
(subject:1.1)
(style:1.15)
```

Depois teste.

Evite empilhar:

```text
(subject:2)
(style:2)
(light:2)
(...)
```

sem motivo, porque você pode tornar o conditioning excessivamente concentrado.

---

# 12. Seed, Steps, CFG, Sampler, Scheduler e Denoise

Essa é uma das partes mais importantes do KSampler.

## 12.1 Seed

O seed controla o ponto inicial pseudoaleatório utilizado pelo processo.

Conceito:

```text
seed 12345 → resultado A
seed 12345 → resultado reproduzível
seed 98765 → resultado B
```

Mesmo seed + mesmas condições + mesmo workflow tende a produzir resultado reproduzível.

Mudanças no ambiente, modelo ou implementação podem quebrar a reprodução exata.

## 12.2 Steps

Número de etapas do processo de sampling.

Mais steps:

- podem permitir refinamento adicional;
- aumentam o custo computacional;
- não garantem automaticamente melhor resultado.

Exemplo conceitual:

```text
10 steps
20 steps
30 steps
40 steps
```

A relação entre qualidade e steps depende do sampler, scheduler e modelo.

## 12.3 CFG

CFG controla, de maneira simplificada, a força com que o processo segue a orientação textual.

Valor maior:

```text
mais pressão para seguir o conditioning
```

Valor menor:

```text
mais liberdade / menos pressão
```

Valores excessivamente altos podem introduzir resultados pouco naturais, artefatos ou “estourar” determinadas características.

> **Importante:** arquiteturas modernas podem utilizar mecanismos de guidance diferentes. Não assuma que o CFG tradicional se comporta identicamente em todos os modelos.

## 12.4 Sampler

O sampler define o algoritmo pelo qual o processo percorre os estados de ruído.

Exemplos comuns em famílias clássicas:

```text
euler
euler_ancestral
heun
dpmpp_2m
dpmpp_sde
```

Os nomes e disponibilidades podem variar conforme a versão.

## 12.5 Scheduler

O scheduler determina como os níveis/sigmas de ruído são distribuídos pelo processo.

Mesmo sampler + mesmo número de steps pode produzir resultado diferente ao trocar o scheduler.

## 12.6 Denoise

Muito importante em img2img, upscale e etapas de refinamento.

Conceito:

```text
denoise = 1.0
    ↓
transformação máxima

denoise = 0.3
    ↓
transformação mais limitada
```

Valores baixos tendem a preservar mais a estrutura de entrada.

Valores altos permitem mudanças maiores.

---

# 13. Checkpoints e loaders

## 13.1 Checkpoint Loader

Usado quando o arquivo reúne componentes esperados pelo loader.

Saídas:

```text
MODEL
CLIP
VAE
```

## 13.2 Por que o checkpoint aparece no dropdown?

Porque o ComfyUI rastreia os arquivos registrados na categoria correspondente.

Se o arquivo não aparece:

1. confira a pasta;
2. confira a extensão;
3. confira se o arquivo realmente é do tipo esperado;
4. atualize/reinicie o ComfyUI;
5. veja se algum custom node interfere;
6. verifique se o workflow usa outro loader.

## 13.3 `CheckpointLoaderSimple`

É um dos loaders mais comuns.

Conceito:

```text
arquivo de checkpoint
        ↓
CheckpointLoaderSimple
        ↓
 ┌──────┼──────┐
MODEL  CLIP   VAE
```

## 13.4 Loader de diffusion model

Arquiteturas modulares podem usar:

```text
Load Diffusion Model
```

em vez de um checkpoint completo.

A partir daí, text encoders e VAE podem ser conectados separadamente.

---

# 14. VAE

## 14.1 O que o VAE faz

O VAE funciona como ponte entre imagem e latent.

```text
IMAGE
  ↓
VAE Encode
  ↓
LATENT
```

e:

```text
LATENT
  ↓
VAE Decode
  ↓
IMAGE
```

## 14.2 VAE separado

Alguns workflows usam:

```text
Checkpoint
   ↓
MODEL + CLIP

Load VAE
   ↓
VAE
```

Isso permite trocar o VAE independentemente.

## 14.3 Sintomas possíveis de VAE inadequado

Dependendo do caso:

- cores estranhas;
- contraste diferente;
- imagem lavada;
- detalhes ruins;
- resultado inesperado.

Nunca conclua imediatamente que “o prompt está ruim” sem verificar VAE.

---

# 15. Text Encoders: CLIP, T5 e variantes

O termo “CLIP” aparece muito no mundo Stable Diffusion, mas pipelines modernos podem utilizar outras arquiteturas de texto.

Um pipeline pode ser conceitualmente:

```text
Prompt
 ├── CLIP
 └── T5
       ↓
  Conditioning
```

Isso é particularmente relevante em famílias de modelos que foram projetadas para usar mais de um encoder.

## 15.1 Por que o workflow pode ter vários encoders?

Porque cada encoder pode contribuir com uma representação diferente.

O workflow pode conter:

```text
Load CLIP
Load T5
Encode Prompt
```

ou nodes especializados que escondem essa complexidade.

## 15.2 Consequência prática

Não copie apenas:

```text
models/clip/
```

de um workflow antigo e espere que um modelo moderno funcione.

Confira os loaders requeridos pelo workflow.

---

# 16. LoRA

LoRA é um dos componentes mais úteis para personalização.

## 16.1 Modelo mental

```text
MODEL BASE
     +
   LoRA
     ↓
MODEL MODIFICADO
```

## 16.2 Pasta

Normalmente:

```text
ComfyUI/models/loras/
```

## 16.3 Fluxo

Exemplo:

```text
Load Checkpoint
       │
       ▼
Load LoRA
       │
       ▼
Model Patch
       │
       ▼
KSampler
```

Dependendo do node, CLIP também pode ser afetado.

## 16.4 Strength

Conceito:

```text
LoRA strength = 0.0
    praticamente sem efeito

LoRA strength = 0.5
    influência moderada

LoRA strength = 1.0
    influência forte
```

Não considere esses números como universais.

Cada LoRA é treinada de forma diferente.

## 16.5 Várias LoRAs

Exemplo:

```text
Base
  ↓
LoRA personagem
  ↓
LoRA roupa
  ↓
LoRA estilo
  ↓
Sampler
```

Ao combinar várias:

- as influências podem competir;
- uma LoRA pode reduzir o efeito percebido de outra;
- ordem e arquitetura podem importar;
- strengths muito altos podem produzir conflito.

Uma técnica eficiente é começar com uma LoRA, validar, e somente depois adicionar outra.

---

# 17. Embeddings

Embeddings são representações pequenas que podem ser usadas em workflows compatíveis para introduzir conceitos aprendidos durante treinamento.

Pasta típica:

```text
models/embeddings/
```

Em sistemas compatíveis, o prompt pode referenciar o embedding pelo nome.

Porém:

> embeddings não são intercambiáveis entre arquiteturas.

Um embedding treinado para uma família de encoder pode não funcionar corretamente em outra.

---

# 18. ControlNet e controle estrutural

ControlNet é usado para condicionar a geração com informação estrutural.

## 18.1 Exemplos de controle

```text
OpenPose
Canny
Depth
Lineart
SoftEdge
Scribble
```

## 18.2 Pipeline conceitual

```text
IMAGEM DE CONTROLE
        ↓
PREPROCESSOR
        ↓
CONTROL IMAGE
        ↓
CONTROLNET
        ↓
CONDITIONING
        ↓
SAMPLER
```

## 18.3 OpenPose

Pode extrair:

```text
cabeça
ombros
braços
mãos
tronco
pernas
```

e produzir um mapa estrutural.

Depois o ControlNet usa esse mapa para orientar a pose.

## 18.4 Canny

Detecta contornos.

Útil para preservar:

- silhueta;
- bordas;
- geometria aproximada.

## 18.5 Depth

Usa informação de profundidade para preservar a estrutura espacial.

## 18.6 Quando usar ControlNet

Use quando você quer controlar a **estrutura**.

Exemplo:

```text
“quero este personagem nessa posição”
```

Um prompt pode pedir uma pose, mas o ControlNet fornece uma restrição estrutural explícita.

---

# 19. IP-Adapter e referência visual

IP-Adapter pertence a uma categoria diferente de controle.

Enquanto ControlNet frequentemente controla estrutura:

```text
pose
edges
depth
```

uma referência visual pode controlar:

```text
aparência
estilo
identidade visual
composição de referência
```

A implementação exata depende do pipeline.

Fluxo conceitual:

```text
REFERENCE IMAGE
       ↓
CLIP VISION
       ↓
IP-ADAPTER
       ↓
CONDITIONING / MODEL MODIFICATION
       ↓
SAMPLER
```

---

# 20. Img2Img

Img2Img começa a partir de uma imagem existente.

Pipeline:

```text
Load Image
    ↓
VAE Encode
    ↓
LATENT
    ↓
KSampler
    ↓
VAE Decode
    ↓
IMAGE
```

## 20.1 Denoise é decisivo

Pense em uma escala conceitual:

```text
0.1 ──────────────── 1.0
mais preservação      mais transformação
```

Não é uma escala “qualidade”.

É uma escala de **quanto o processo pode se afastar da imagem de entrada**.

## 20.2 Exemplos de intenção

### Pequena alteração

```text
denoise baixo
```

Objetivo:

```text
preservar composição,
mudar pequenos detalhes
```

### Alteração maior

```text
denoise médio/alto
```

Objetivo:

```text
mudar roupa,
cenário,
estilo,
iluminação
```

---

# 21. Inpainting

Inpainting permite editar uma região específica.

Pipeline conceitual:

```text
IMAGE
  +
MASK
  ↓
INPAINT LATENT
  ↓
KSampler
  ↓
IMAGE
```

## 21.1 Máscara

Normalmente uma máscara diferencia:

```text
área a alterar
```

de:

```text
área a preservar
```

A convenção exata pode variar por node.

## 21.2 Casos úteis

- corrigir rosto;
- substituir roupa;
- remover objeto;
- alterar fundo;
- corrigir mãos;
- inserir detalhe.

## 21.3 Feather

Suavizar bordas da máscara ajuda a evitar cortes artificiais.

---

# 22. Upscaling

Existem várias estratégias.

## 22.1 Upscale tradicional por modelo

```text
IMAGE
  ↓
Upscale Model
  ↓
IMAGE maior
```

## 22.2 Latent upscale

```text
IMAGE
  ↓
VAE Encode
  ↓
LATENT
  ↓
Latent Upscale
  ↓
KSampler
  ↓
VAE Decode
  ↓
IMAGE
```

## 22.3 Híbrido

Um workflow avançado pode fazer:

```text
Geração inicial
      ↓
Latent Upscale
      ↓
Refino por sampling
      ↓
Image Upscaler
      ↓
Detalhamento final
```

## 22.4 Por que não gerar tudo já enorme?

Porque a memória e o custo crescem significativamente com resolução.

Às vezes é mais eficiente:

```text
1024×1024
   ↓
refino
   ↓
2048×2048
   ↓
upscale
```

do que gerar diretamente em resolução muito alta.

---

# 23. Flux e arquiteturas modernas

Flux representa uma mudança importante em relação a muitos workflows clássicos.

O erro comum é pensar:

> “Flux = checkpoint diferente.”

Mais corretamente:

> Flux possui uma arquitetura e um ecossistema de componentes que podem exigir uma montagem diferente do pipeline.

## 23.1 Flux modular

Um workflow pode ter algo como:

```text
Diffusion Model
      ↓
MODEL

Text Encoder A ─┐
                ├→ Conditioning
Text Encoder B ─┘

VAE
 ↓
Decode
```

## 23.2 Arquivos podem estar separados

Você pode encontrar:

```text
diffusion model
text encoder
VAE
LoRA
```

em arquivos diferentes.

## 23.3 Prompting

Modelos modernos podem responder melhor a descrições em linguagem natural do que a “listas de tags” tradicionais.

Exemplo:

```text
A cinematic photograph of a man standing beside
a motorcycle on a rainy urban street at night.
The pavement reflects blue and orange neon lights.
The camera is positioned at street level...
```

Isso não significa que tags deixaram de funcionar. Significa que o modelo pode interpretar linguagem natural de maneira mais rica.

---

# 24. SD 1.5 e SDXL

## 24.1 SD 1.5

Ecossistema clássico:

```text
Checkpoint
CLIP
VAE
LoRA
ControlNet
Embeddings
```

Muitos tutoriais antigos são baseados nessa família.

## 24.2 SDXL

Workflow mais pesado e com mudanças no condicionamento.

Um workflow pode envolver:

```text
SDXL Checkpoint
     ↓
CLIP / text conditioning
     ↓
KSampler
     ↓
VAE
```

Em alguns setups, componentes específicos podem aparecer separadamente.

## 24.3 Não misture componentes aleatoriamente

Erros comuns:

```text
LoRA de arquitetura A
+
checkpoint de arquitetura B
```

ou:

```text
ControlNet de família incompatível
```

ou:

```text
embedding treinado para outro encoder
```

compatibilidade é mais importante que o nome do arquivo.

---

# 25. Modelos de vídeo

ComfyUI também pode executar workflows para vídeo.

A lógica geral adiciona uma dimensão temporal:

```text
IMAGE / TEXT
      ↓
VIDEO MODEL
      ↓
LATENT VIDEO
      ↓
VAE VIDEO DECODE
      ↓
FRAMES
      ↓
VIDEO OUTPUT
```

## 25.1 Conceito de frames

Uma imagem é:

```text
H × W × C
```

Um vídeo adiciona tempo:

```text
T × H × W × C
```

Isso aumenta muito a exigência de memória e processamento.

## 25.2 Workflow de imagem para vídeo

Conceito:

```text
IMAGE
  ↓
VIDEO CONDITIONING
  ↓
VIDEO MODEL
  ↓
FRAMES
  ↓
ENCODE VIDEO
```

## 25.3 Problemas comuns

- VRAM insuficiente;
- sequência temporal instável;
- movimento excessivo;
- flickering;
- inconsistência de personagem;
- duração alta demais;
- resolução alta demais.

---

# 26. Custom Nodes

Custom Nodes são extensões que adicionam funcionalidades ao ComfyUI.

Podem fornecer:

- nodes novos;
- loaders;
- preprocessors;
- ferramentas de vídeo;
- ferramentas de máscara;
- integração com APIs;
- processamento de imagens;
- recursos de frontend.

## 26.1 Estrutura típica

```text
custom_nodes/
└── MeuCustomNode/
    ├── __init__.py
    ├── nodes.py
    ├── requirements.txt
    └── ...
```

A estrutura varia.

## 26.2 O maior risco: dependências

Um custom node pode exigir:

```text
Python package A
Python package B
versão específica do torch
versão específica do CUDA
DLL
modelo adicional
```

Por isso:

> instalar dezenas de custom nodes sem controle aumenta muito a chance de conflitos.

---

# 27. ComfyUI Manager e dependências

Uma instalação organizada deve conhecer:

```text
ComfyUI
├── core
├── custom nodes
├── Python dependencies
├── model files
└── workflow JSON
```

Se um workflow acusa:

```text
Missing Node Types
```

normalmente faltou:

- um custom node;
- uma versão compatível;
- uma atualização;
- um node que mudou de nome.

## 27.1 Estratégia para instalar workflow de terceiros

Faça nesta ordem:

```text
1. Abrir o workflow
2. Identificar nodes ausentes
3. Descobrir o projeto que fornece os nodes
4. Instalar dependência
5. Reiniciar ComfyUI
6. Conferir os modelos exigidos
7. Conferir caminhos
8. Executar
```

Não comece baixando “todos os nodes que aparecerem”.

---

# 28. Performance e VRAM

A VRAM é frequentemente o principal limitador.

Uma GPU de 24 GB, por exemplo, pode executar muitos modelos locais, mas não significa que **qualquer workflow** caiba em 24 GB.

## 28.1 O que consome VRAM

Principalmente:

- modelo;
- text encoder;
- VAE;
- latents;
- batch size;
- resolução;
- número de componentes carregados;
- caches;
- modelos auxiliares;
- vídeo/frame count.

## 28.2 Resolução

Área de imagem:

```text
1024 × 1024 = 1.048.576 pixels
```

Enquanto:

```text
2048 × 2048 = 4.194.304 pixels
```

A segunda possui 4 vezes a quantidade de pixels.

Isso ajuda a entender por que “só dobrar a resolução” pode ter impacto enorme.

## 28.3 Batch size

Comparação:

```text
batch = 1
```

versus:

```text
batch = 4
```

Você potencialmente aumenta bastante a memória necessária.

Para uma máquina limitada por VRAM:

```text
prefira batch pequeno
```

e aumente somente quando houver margem.

## 28.4 Otimização

Possíveis estratégias, dependendo do modelo e da versão:

- reduzir resolução;
- reduzir batch;
- usar offload;
- usar VAE tiled;
- usar quantização;
- usar versões menores do modelo;
- reduzir quantidade de frames;
- reduzir contexto/processamento auxiliar;
- evitar manter componentes desnecessários carregados.

---

# 29. Organização profissional de workflows

Workflows grandes rapidamente viram uma “teia de macarrão”.

A organização importa.

## 29.1 Use regiões visuais

Exemplo:

```text
[INPUT]
[MODEL]
[TEXT]
[CONTROL]
[SAMPLING]
[UPSCALE]
[OUTPUT]
```

## 29.2 Nomeie nodes

Em vez de:

```text
Load Image
```

pode usar:

```text
REFERENCE — PERSON
```

ou:

```text
INPUT — POSE
```

## 29.3 Use reroute

Quando uma conexão atravessa metade do canvas, use reroutes para manter o fluxo legível.

## 29.4 Tenha workflow “base”

Uma boa biblioteca:

```text
workflows/
├── 00_base_sd15.json
├── 01_sdxl_txt2img.json
├── 02_flux_txt2img.json
├── 03_img2img.json
├── 04_inpainting.json
├── 05_controlnet_pose.json
├── 06_upscale.json
└── 07_video.json
```

## 29.5 Versionamento

Adote nomes:

```text
flux_character_v01.json
flux_character_v02.json
flux_character_v03.json
```

e, se possível:

```text
Git
```

para workflows e scripts.

---

# 30. API e automação

O ComfyUI pode funcionar como backend.

Conceitualmente:

```text
CLIENTE
  ↓ HTTP
COMFYUI SERVER
  ↓
WORKFLOW
  ↓
EXECUTION
  ↓
OUTPUT
```

Isso abre espaço para:

- Python;
- aplicações web;
- n8n;
- bots;
- interfaces próprias;
- filas de geração.

## 30.1 Workflow API

Um workflow pode ser representado em JSON.

A ideia geral é:

```json
{
  "1": {
    "class_type": "KSampler",
    "inputs": {
      "seed": 123,
      "steps": 20
    }
  }
}
```

O JSON real depende da forma de exportação e da versão/workflow.

## 30.2 Por que isso é importante

Você pode ter:

```text
WhatsApp
   ↓
Backend
   ↓
ComfyUI API
   ↓
Geração
   ↓
Imagem
   ↓
WhatsApp
```

---

# 31. Integração com Python e n8n

Para automação local, a arquitetura pode ser:

```text
[n8n]
   ↓
HTTP Request
   ↓
[ComfyUI]
   ↓
Workflow
   ↓
[Output]
   ↓
n8n
   ↓
WhatsApp / Web / App
```

## 31.1 Exemplo de uso

Entrada:

```json
{
  "prompt": "uma cidade futurista à noite",
  "seed": 12345
}
```

Seu backend pode montar ou modificar um workflow.

## 31.2 Melhor prática

Não reconstrua um workflow inteiro toda vez.

Prefira manter um template:

```text
workflow_template.json
```

e modificar apenas:

```text
prompt
negative prompt
seed
width
height
steps
cfg
LoRA
strength
```

Isso reduz erros.

---

# 32. Troubleshooting

## 32.1 “Meu modelo não aparece”

Checklist:

```text
[ ] pasta correta
[ ] extensão correta
[ ] arquivo não corrompido
[ ] categoria correta
[ ] workflow usa o loader correto
[ ] ComfyUI atualizado/recarregado
[ ] custom node carregado
```

## 32.2 Node vermelho após abrir workflow

Normalmente indica node ausente ou problema no carregamento.

Analise:

```text
nome do node
↓
qual extensão fornece?
↓
custom_nodes?
↓
dependência instalada?
```

## 32.3 `CUDA out of memory`

Prioridade:

```text
1. reduzir resolução
2. reduzir batch
3. reduzir frames
4. verificar modelos auxiliares
5. verificar quantização/offload
6. revisar VAE / upscale / ControlNet
```

## 32.4 Workflow abre mas imagem fica preta

Investigue:

```text
VAE
↓
compatibilidade de modelo
↓
dtype
↓
latent
↓
decode
```

## 32.5 Imagem lavada

Possíveis suspeitos:

```text
VAE
color space
decode
modelo incompatível
```

## 32.6 LoRA não altera a imagem

Cheque:

```text
[ ] LoRA correta
[ ] arquitetura compatível
[ ] strength diferente de zero
[ ] conexão MODEL correta
[ ] conexão CLIP correta quando aplicável
[ ] trigger words quando exigidas pelo treinamento
```

## 32.7 Prompt parece ser ignorado

Cheque:

```text
Prompt
 ↓
Text Encoder
 ↓
Conditioning
 ↓
KSampler
```

Uma conexão errada pode fazer o texto não chegar ao sampler.

## 32.8 Controle de pose não funciona

Cheque:

```text
imagem de entrada
      ↓
preprocessor
      ↓
ControlNet compatível
      ↓
conditioning
      ↓
KSampler
```

Não basta carregar “qualquer ControlNet”.

---

# 33. Metodologia para analisar um workflow desconhecido

Quando alguém entrega um workflow enorme, não tente entender todos os nodes de uma vez.

Use esta ordem.

## Passo 1 — descubra a saída

Ache:

```text
Save Image
Preview Image
Video Combine
```

e siga para trás.

## Passo 2 — descubra o sampler

Procure:

```text
KSampler
SamplerCustom
KSamplerAdvanced
ou equivalente
```

## Passo 3 — descubra o MODEL

Siga a entrada:

```text
MODEL
```

até o loader.

## Passo 4 — descubra o conditioning

Procure:

```text
positive
negative
conditioning
```

## Passo 5 — descubra o latent

Pergunte:

```text
de onde o latent veio?
```

Pode ser:

```text
Empty Latent
VAE Encode
latent upscale
video latent
```

## Passo 6 — descubra os modificadores

Procure:

```text
LoRA
ControlNet
IP Adapter
attention
model patch
```

## Passo 7 — descubra o decode

Normalmente:

```text
VAE Decode
```

## Passo 8 — só então olhe para nodes auxiliares

Isso evita perder tempo.

---

# 34. Receitas de workflows

## 34.1 Receita A — SD clássico Text-to-Image

```text
Checkpoint
   ├── MODEL ────────────────┐
   ├── CLIP → Positive ──┐   │
   └── VAE               │   │
        CLIP → Negative ─┤   │
                         │   │
Empty Latent ────────────┴───┤
                             ▼
                         KSampler
                             │
                             ▼
                         VAE Decode
                             │
                             ▼
                        Save Image
```

---

## 34.2 Receita B — Text-to-Image + LoRA

```text
Checkpoint
   ↓
Load LoRA
   ↓
MODEL + CLIP modificados
   ↓
Positive / Negative
   ↓
KSampler
   ↓
VAE Decode
   ↓
Save
```

---

## 34.3 Receita C — Img2Img

```text
Load Image
     ↓
VAE Encode
     ↓
LATENT
     ↓
KSampler
  ↑  ↑  ↑
  │  │  └── Negative
  │  └───── Positive
  └──────── MODEL
     ↓
VAE Decode
     ↓
Save
```

---

## 34.4 Receita D — Inpainting

```text
Load Image
     ↓
Mask
     ↓
Inpaint Encode
     ↓
LATENT
     ↓
KSampler
     ↓
VAE Decode
     ↓
Output
```

---

## 34.5 Receita E — Pose + ControlNet

```text
Reference Image
      ↓
OpenPose Preprocessor
      ↓
Pose Map
      ↓
ControlNet
      ↓
Positive Conditioning
      ↓
KSampler
```

---

## 34.6 Receita F — Img2Img + ControlNet + LoRA

```text
INPUT IMAGE
   ↓
VAE Encode
   ↓
LATENT ───────────────┐
                      │
MODEL → Load LoRA ────┤
                      │
TEXT → Conditioning ──┤
                      │
POSE → ControlNet ────┤
                      ▼
                   KSampler
                      ↓
                 VAE Decode
                      ↓
                    IMAGE
```

---

## 34.7 Receita G — Geração + upscale

```text
Txt2Img
  ↓
Base Image
  ↓
VAE Encode
  ↓
Latent Upscale
  ↓
KSampler
  ↓
VAE Decode
  ↓
Image Upscaler
  ↓
Final
```

---

# 35. Checklist de instalação

## ComfyUI

```text
[ ] GPU reconhecida
[ ] driver atualizado
[ ] ComfyUI iniciando
[ ] navegador abrindo interface
[ ] geração simples funcionando
```

## Modelos

```text
[ ] checkpoint
[ ] VAE
[ ] LoRA
[ ] ControlNet
[ ] upscale model
[ ] text encoder quando necessário
```

## Custom Nodes

```text
[ ] instalado
[ ] dependências instaladas
[ ] sem erro no terminal
[ ] node aparece na busca
```

## Primeiro teste

Faça sempre um workflow mínimo antes de configurar 30 extensões.

---

# 36. Checklist de geração

Antes de procurar “por que a imagem ficou ruim”, confira:

```text
[ ] modelo correto
[ ] arquitetura correta
[ ] VAE correto
[ ] prompt correto
[ ] negative prompt correto, quando aplicável
[ ] seed
[ ] steps
[ ] CFG/guidance apropriado ao modelo
[ ] sampler
[ ] scheduler
[ ] resolução
[ ] LoRA
[ ] ControlNet
[ ] denoise
```

---

# 37. Glossário

## A1111 / Automatic1111

Outra interface/ecossistema para Stable Diffusion.

## Checkpoint

Arquivo que pode conter componentes de um modelo de geração.

## CLIP

Família de modelos/encoders usada em muitos pipelines para relacionar texto e imagem.

## Conditioning

Informação usada para orientar o processo generativo.

## ControlNet

Tecnologia/ecossistema para controle estrutural adicional.

## Denoise

Quanto o sampling pode modificar a entrada, especialmente relevante em img2img e workflows de refinamento.

## Diffusion Model

Modelo principal que participa do processo de difusão.

## Embedding

Representação vetorial aprendida para introduzir um conceito em sistemas compatíveis.

## Latent

Representação compacta usada durante parte do processo generativo.

## LoRA

Adaptação de baixa dimensão usada para modificar ou especializar um modelo.

## Sampler

Algoritmo que percorre as etapas do processo de sampling.

## Scheduler

Define o agendamento/distribuição dos níveis de ruído ou sigmas utilizados pelo sampling.

## Seed

Valor usado para determinar o ruído pseudoaleatório inicial.

## Text Encoder

Componente que transforma texto em representações usadas no conditioning.

## VAE

Componente para codificar/decodificar entre imagem e espaço latente.

---

# 38. Referências oficiais

As referências abaixo são especialmente importantes porque o ComfyUI muda rapidamente.

## Código principal

- [ComfyUI — repositório oficial](https://github.com/Comfy-Org/ComfyUI)
- [folder_paths.py — caminhos oficiais de modelos](https://github.com/Comfy-Org/ComfyUI/blob/master/folder_paths.py)
- [extra_model_paths.yaml.example](https://github.com/Comfy-Org/ComfyUI/blob/master/extra_model_paths.yaml.example)

## Documentação

- [Documentação oficial do ComfyUI](https://docs.comfy.org/)
- [Modelos — conceitos básicos](https://docs.comfy.org/development/core-concepts/models)
- [Custom Nodes](https://docs.comfy.org/development/core-concepts/custom-nodes)
- [Workflow Templates](https://docs.comfy.org/)
- [Documentação geral de nodes](https://docs.comfy.org/)

---

# Apêndice A — Mapa mental rápido

```text
                         COMFYUI
                            │
       ┌────────────────────┼────────────────────┐
       │                    │                    │
     MODELOS             PROMPT              INPUTS
       │                    │                    │
       │                    │                    ├── IMAGE
       │                    │                    ├── MASK
       │                    │                    └── VIDEO
       │                    │
       │                    ├── POSITIVE
       │                    └── NEGATIVE
       │
       ├── CHECKPOINT
       ├── DIFFUSION MODEL
       ├── VAE
       ├── TEXT ENCODER
       ├── LoRA
       ├── CONTROLNET
       ├── IP ADAPTER
       └── UPSCALER
                            │
                            ▼
                        CONDITIONING
                            │
                            ▼
                          SAMPLER
                            │
                            ▼
                          LATENT
                            │
                            ▼
                           VAE
                            │
                            ▼
                          IMAGE
                            │
                            ▼
                          OUTPUT
```

---

# Apêndice B — Fluxo de diagnóstico em 60 segundos

Quando algo não funcionar:

```text
MODELO APARECE?
 ├─ NÃO → verificar pasta / extensão / loader / refresh
 └─ SIM
     ↓
NODE EXISTE?
 ├─ NÃO → verificar custom node / dependência
 └─ SIM
     ↓
MODEL CONECTADO?
 ├─ NÃO → corrigir conexão
 └─ SIM
     ↓
CONDITIONING CHEGA AO SAMPLER?
 ├─ NÃO → corrigir prompt/encoder
 └─ SIM
     ↓
LATENT EXISTE?
 ├─ NÃO → corrigir Empty Latent / VAE Encode
 └─ SIM
     ↓
SAMPLER EXECUTA?
 ├─ NÃO → verificar VRAM / modelo / parâmetros
 └─ SIM
     ↓
VAE DECODE EXECUTA?
 ├─ NÃO → verificar VAE
 └─ SIM
     ↓
RESULTADO RUIM?
     ↓
comparar:
modelo → prompt → seed → sampler → scheduler
→ CFG/guidance → denoise → LoRA → ControlNet
```

---

# Apêndice C — Como montar uma biblioteca de modelos organizada

Uma estrutura recomendada:

```text
D:/AI/
├── Models/
│   ├── checkpoints/
│   │   ├── SD15/
│   │   ├── SDXL/
│   │   ├── Flux/
│   │   └── Other/
│   │
│   ├── diffusion_models/
│   │   ├── Flux/
│   │   ├── Wan/
│   │   └── Other/
│   │
│   ├── text_encoders/
│   ├── vae/
│   ├── loras/
│   │   ├── characters/
│   │   ├── styles/
│   │   ├── clothing/
│   │   └── concepts/
│   │
│   ├── controlnet/
│   ├── clip_vision/
│   ├── upscale_models/
│   └── embeddings/
│
└── Workflows/
    ├── txt2img/
    ├── img2img/
    ├── inpainting/
    ├── controlnet/
    ├── upscale/
    └── video/
```

A organização interna por subpastas é principalmente para você. O que importa para o ComfyUI é que essas localizações estejam registradas no sistema de caminhos.

---

# Apêndice D — Regra de ouro

Quando um workflow não funciona:

> **Não comece alterando 20 parâmetros. Primeiro descubra se o pipeline está montado corretamente.**

Use esta sequência:

```text
ARQUITETURA
    ↓
MODELOS
    ↓
LOADERS
    ↓
CONEXÕES
    ↓
CONDITIONING
    ↓
SAMPLER
    ↓
DECODE
    ↓
PARÂMETROS
    ↓
QUALIDADE
```

Essa ordem evita gastar horas tentando resolver com prompt um problema que na verdade era:

```text
VAE errado
```

ou:

```text
LoRA incompatível
```

ou:

```text
ControlNet da arquitetura errada
```

ou:

```text
text encoder ausente
```

---

# Apêndice E — Modelo de documentação para cada workflow

Use este template para registrar seus próprios workflows:

```markdown
# Nome do Workflow

## Objetivo

Descrever o que o workflow faz.

## Arquitetura

- SD 1.5 / SDXL / Flux / outro
- resolução base
- tipo de geração

## Modelos

### Checkpoint
`nome_do_modelo.safetensors`

### VAE
`nome_do_vae.safetensors`

### LoRA
`nome_da_lora.safetensors`

### ControlNet
`nome_do_controlnet.safetensors`

## Prompt

```text
...
```

## Negative Prompt

```text
...
```

## Sampling

- Steps:
- CFG / Guidance:
- Sampler:
- Scheduler:
- Denoise:
- Seed:

## Resolução

- Width:
- Height:
- Batch:

## Custom Nodes

- Node A
- Node B

## Observações

- ...
```

---

# Apêndice F — Princípios para criação de workflows robustos

## 1. Faça o mínimo funcionar primeiro

Comece com:

```text
MODEL
+
TEXT
+
LATENT
+
SAMPLER
+
VAE
```

Depois adicione complexidade.

## 2. Uma variável por vez

Ao otimizar:

```text
seed constante
modelo constante
prompt constante
```

e altere apenas:

```text
steps
```

Depois:

```text
sampler
```

Depois:

```text
CFG
```

Assim você sabe o que realmente causou a mudança.

## 3. Salve o workflow junto com a imagem

Uma imagem sem:

```text
seed
modelo
prompt
sampler
scheduler
```

é muito mais difícil de reproduzir.

## 4. Não trate “mais parâmetros” como “mais qualidade”

Workflow complexo não é automaticamente workflow melhor.

A pergunta correta é:

> “Esse node adiciona controle que eu realmente preciso?”

---

# Apêndice G — Resumo de bolso

```text
CHECKPOINT
= base do modelo

LORA
= especialização/adaptação

VAE
= IMAGE ⇄ LATENT

TEXT ENCODER
= texto → representação

CONDITIONING
= instruções usadas pelo pipeline

LATENT
= espaço onde a difusão acontece

KSampler
= processo de sampling

SEED
= ponto inicial aleatório

STEPS
= quantidade de etapas

CFG / GUIDANCE
= força do condicionamento, quando aplicável

SAMPLER
= algoritmo do sampling

SCHEDULER
= agenda de ruído/sigmas

DENOISE
= quanto uma entrada pode ser alterada

CONTROLNET
= controle estrutural

IP-ADAPTER
= referência visual

UPSCALER
= aumento/refino de resolução

CUSTOM NODE
= extensão do ComfyUI

WORKFLOW
= grafo inteiro que conecta tudo
```

---

# Nota de manutenção deste manual

O ComfyUI é um projeto em evolução rápida. Pastas, loaders, nodes, APIs e workflows podem mudar.

Para manter este documento correto:

1. consulte o `folder_paths.py` da versão instalada;
2. confira o `extra_model_paths.yaml.example`;
3. leia o README do custom node;
4. confira a documentação do modelo;
5. abra o workflow e identifique os loaders realmente utilizados;
6. evite assumir que um tutorial antigo continua válido para uma arquitetura nova.

**Referência técnica principal para caminhos de modelos:** o próprio código `folder_paths.py` do ComfyUI.

---

# Fim

Este manual foi pensado para ser expandido.

Próximas extensões naturais desta documentação:

```text
01. Biblioteca de nodes nativos, node por node
02. Guia dedicado a Flux
03. Guia dedicado a SDXL
04. Guia dedicado a vídeo
05. Catálogo de samplers/schedulers
06. Guia de LoRAs
07. Guia de ControlNet
08. Guia de API JSON
09. Guia de performance para RTX 3090
10. Guia de integração ComfyUI + n8n
11. Guia de criação de custom nodes
12. Guia de treinamento de LoRA
```

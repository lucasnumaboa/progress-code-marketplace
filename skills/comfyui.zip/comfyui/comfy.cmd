@echo off
setlocal
rem ComfyUI pela API - atalho: acha o Python e chama o comfy.py desta pasta.
rem   comfy.cmd status ^| modelos [pasta] ^| nodes [--busca x] ^| node Classe ^| validar wf.json ^| rodar wf.json [--set 6.text=...] [--saida pasta]
set "DIR=%~dp0"
set "PY="
where py >nul 2>nul && set "PY=py -3"
if not defined PY where python >nul 2>nul && set "PY=python"
if not defined PY (
  echo {"erro": "Python 3 nao encontrado. Instale com: winget install -e --id Python.Python.3.12  (depois feche e abra o Progress Code)"}
  exit /b 3
)
%PY% "%DIR%comfy.py" %*
exit /b %errorlevel%

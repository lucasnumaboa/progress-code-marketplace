# Aviso de terceiros (NOTICE)

Esta skill é uma cópia adaptada de material de terceiros e é redistribuída sob a licença original. O texto do especialista ficou em inglês, como no original.

- **Origem:** https://github.com/swan-gtm/gtm-skills
- **Caminho no repositório:** `skills/din-arbel/warm-intro-intelligence`
- **Commit:** `eb0026f469f90645e1a64168d08a3e0afb59ee12` (baixado em 2026-11-22)
- **Autor:** Din Arbel (autor da skill); copyright do repositório: Swan
- **Licença:** MIT (texto completo em `LICENSE`, copiado de `LICENSE` do repositório)

## Arquivos incluídos

- `SKILL.md` (de `skills/din-arbel/warm-intro-intelligence/SKILL.md`)
- `references/evidence-rules-and-confidence-scoring.md` (de `skills/din-arbel/warm-intro-intelligence/references/evidence-rules-and-confidence-scoring.md`)
- `references/node-registry-and-edge-discovery.md` (de `skills/din-arbel/warm-intro-intelligence/references/node-registry-and-edge-discovery.md`)
- `references/warm-intro-output-card-format.md` (de `skills/din-arbel/warm-intro-intelligence/references/warm-intro-output-card-format.md`)
- `references/warm-relationship-intake.md` (de `skills/din-arbel/warm-intro-intelligence/references/warm-relationship-intake.md`)
- `author.md` (de `skills/din-arbel/author.md`, crédito do autor pedido pelo repositório)
- `LICENSE`

## Mudanças feitas

- Frontmatter: `name: warm-intro-intelligence` trocado por `name: swan-warm-intro-intelligence` (a descrição ficou igual).

## Crédito do autor (author.md)

O repositório pede que o crédito do autor acompanhe a skill. Conteúdo do `author.md` original:

```markdown
---
name: Din Arbel
avatarUrl: "https://www.gtmskills.com/authors/din-arbel.jpg"
title: "GTM @ Utila"
linkedinUrl: "https://linkedin.com/in/din-arbel"
companyDomain: utila.io
---

Din leads GTM at Utila, the enterprise platform for stablecoin and digital-asset operations — MPC wallets, treasury, and tokenization infrastructure used by fintechs, banks, and payment providers, SOC 2 Type II compliant and spanning 100+ blockchains.
```

# Origem e licença

Esta skill é uma cópia, com as alterações listadas abaixo, de material de especialista com licença aberta.

- **Fonte:** https://github.com/mattpocock/skills
- **Arquivos de origem:** `skills/engineering/diagnosing-bugs/SKILL.md`, `skills/engineering/diagnosing-bugs/scripts/hitl-loop.template.sh`
- **Autor:** Matt Pocock
- **Licença:** MIT (texto completo em `LICENSE`)
- **Commit:** `abeeaf95660ba9e8b7c753eb38f441ca707a8823` (baixado em 2026-11-22)

## Alterações feitas

- `name:` do frontmatter trocado de `diagnosing-bugs` para `mp-diagnosing-bugs`.
- Fora isso, o texto do especialista está como no original (em inglês).

## Arquivos da skill original que não vieram

- `agents/openai.yaml` (metadado de outro produto).

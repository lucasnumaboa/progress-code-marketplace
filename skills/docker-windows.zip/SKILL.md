---
name: docker-windows
description: Cria Dockerfile multi-stage, docker-compose, gerencia volumes/redes/logs e depura container que não sobe, instalando o Docker Desktop sozinho (via winget) quando possível — mas para no ponto em que exigir reiniciar a máquina, já que isso não pode ser automatizado com segurança no meio de uma sessão. Use quando o usuário pedir para "containerizar essa aplicação", "criar um Dockerfile", "esse container não sobe, por quê", "rodar Postgres/Redis local via Docker".
argument-hint: [aplicação a containerizar] [imagem-base, se souber]
---

# Docker no Windows

## Passo 0 — Verificar/instalar (com ponto de parada real para reinício)
```
docker --version
```
Se não existir, o Docker Desktop no Windows precisa do **WSL2** como backend — isso pode exigir reiniciar a
máquina, o que uma automação não pode "atravessar" sozinha (a sessão para, o processo é interrompido). Passos:
```powershell
wsl --status   # confere se o WSL2 ja esta instalado/habilitado
```
Se o WSL2 **já estiver pronto**, instale o Docker Desktop direto:
```
winget install Docker.DockerDesktop
```
Se o WSL2 **não estiver instalado**:
```
wsl --install
```
**PARE aqui e avise o usuário**: este comando exige reiniciar o Windows para concluir a instalação do WSL2. Depois
do reinício, o usuário (ou uma nova sessão) precisa rodar `winget install Docker.DockerDesktop` e depois abrir o
Docker Desktop manualmente pelo menos uma vez (ele pede para aceitar os termos de uso na primeira execução, uma
etapa interativa que não dá para automatizar). Só prossiga com os passos abaixo depois que `docker --version`
funcionar de verdade.

## Passo 1 — Dockerfile multi-stage (build menor, sem ferramentas de build na imagem final)
```dockerfile
FROM python:3.12-slim AS build
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir --user -r requirements.txt

FROM python:3.12-slim
WORKDIR /app
COPY --from=build /root/.local /root/.local
COPY . .
ENV PATH=/root/.local/bin:$PATH
CMD ["python", "app.py"]
```
O estágio `build` tem tudo que precisa para instalar dependências; o estágio final copia só o resultado — a imagem
final não carrega compilador/ferramentas de build que só serviram para montar as dependências.

## Passo 2 — docker-compose (múltiplos serviços juntos)
```yaml
services:
  app:
    build: .
    ports: ["8080:8080"]
    depends_on: [banco]
    environment:
      DATABASE_URL: postgresql://usuario:senha@banco:5432/meubanco
  banco:
    image: postgres:16
    volumes: ["dados_banco:/var/lib/postgresql/data"]
    environment:
      POSTGRES_PASSWORD: senha
volumes:
  dados_banco:
```
```
docker compose up -d
docker compose logs -f app
docker compose down
```

## Passo 3 — Volumes e redes
```
docker volume ls
docker volume inspect dados_banco
docker network ls
```
Volume nomeado (`dados_banco` acima) sobrevive a `docker compose down` — só é apagado com `docker compose down -v`
ou `docker volume rm` explícito. **Confirme com o usuário antes de usar `-v`** — apaga dados persistidos (ex.:
banco de dados) sem chance de desfazer.

## Passo 4 — Logs e depuração de container que não sobe
```
docker logs nome-do-container --tail 100
docker logs nome-do-container -f          # acompanhar em tempo real
docker inspect nome-do-container --format='{{.State.Status}} {{.State.ExitCode}}'
docker exec -it nome-do-container sh      # entrar no container para investigar (se ainda estiver rodando)
```
Container que reinicia em loop (`docker ps` mostra `Restarting`): o log (`docker logs`) quase sempre mostra o erro
de inicialização da aplicação — leia antes de qualquer outra tentativa.

## Passo 5 — Limpeza (espaço em disco)
```
docker system prune          # remove containers parados, redes nao usadas, imagens sem tag
docker system prune -a        # tambem remove imagens nao usadas por nenhum container (mais agressivo)
docker volume prune           # remove volumes nao referenciados por nenhum container - CONFIRME antes, pode ter dado importante
```

## Regras
- Nunca rode `docker volume prune`/`compose down -v` sem confirmar explicitamente com o usuário — é a forma mais
  comum de perder dado de banco/persistência sem querer.
- `wsl --install` exigindo reinício: sempre pare e informe claramente, nunca tente prosseguir como se tivesse
  terminado — a sessão de automação não sobrevive a um reinício do Windows.
- Imagem em produção: nunca use a tag `latest` para deploy reproduzível — fixe uma versão/tag específica.

## Arquivos desta skill
Nenhum script fixo — os comandos acima cobrem os casos mais comuns; adapte à aplicação real do usuário.

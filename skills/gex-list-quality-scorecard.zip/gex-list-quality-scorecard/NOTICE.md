# Aviso de terceiros (NOTICE)

Esta skill é uma cópia adaptada de material de terceiros e é redistribuída sob a licença original. O texto do especialista ficou em inglês, como no original.

- **Origem:** https://github.com/growthenginenowoslawski/coldoutboundskills
- **Caminho no repositório:** `skills/list-quality-scorecard`
- **Commit:** `25c5d85fbb5dd3efec97b0ca457cbbc286547476` (baixado em 2026-11-22)
- **Autor:** GrowthEngineX
- **Licença:** MIT (texto completo em `LICENSE`, copiado de `LICENSE` do repositório)

## Arquivos incluídos

- `SKILL.md` (de `skills/list-quality-scorecard/SKILL.md`)
- `scripts/score-list.ts` (de `skills/list-quality-scorecard/scripts/score-list.ts`)
- `LICENSE`

## Mudanças feitas

- Frontmatter: `name: list-quality-scorecard` trocado por `name: gex-list-quality-scorecard` (a descrição ficou igual).

## Observação

`scripts/score-list.ts` foi conferido: só lê e grava arquivos locais (módulo `fs`), sem rede, chave de API ou telemetria. Roda com `npx tsx`.

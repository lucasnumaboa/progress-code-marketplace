# Origem e mudanças

- **Repositório:** https://github.com/TheCraigHewitt/skills
- **Caminho no repositório:** `youtube/script-structure`
- **Autor:** Craig Hewitt
- **Licença:** MIT (texto em `LICENSE`)
- **Commit usado:** `fdbf39b61fbc8cb7cea67949bfb5e8fc567bbc51`
- **Arquivos copiados:** `SKILL.md`

## Mudanças feitas

- no cabeçalho (frontmatter), `name:` passou de `script-structure` para `ch-script-structure`; a descrição ficou igual
- nenhuma outra alteração no texto do especialista (mantido em inglês)

Empacotada para o marketplace do Progress Code em 2026-11-22.

# Aviso de terceiros (NOTICE)

Esta skill é uma cópia adaptada de material de terceiros e é redistribuída sob a licença original. O texto do especialista ficou em inglês, como no original.

- **Origem:** https://github.com/swan-gtm/gtm-skills
- **Caminho no repositório:** `skills/rob-snyder/pull-call-review`
- **Commit:** `eb0026f469f90645e1a64168d08a3e0afb59ee12` (baixado em 2026-11-22)
- **Autor:** Rob Snyder (autor da skill); copyright do repositório: Swan
- **Licença:** MIT (texto completo em `LICENSE`, copiado de `LICENSE` do repositório)

## Arquivos incluídos

- `SKILL.md` (de `skills/rob-snyder/pull-call-review/SKILL.md`)
- `references/pull-framework.md` (de `skills/rob-snyder/pull-call-review/references/pull-framework.md`)
- `author.md` (de `skills/rob-snyder/author.md`, crédito do autor pedido pelo repositório)
- `LICENSE`

## Mudanças feitas

- Frontmatter: `name: pull-call-review` trocado por `name: swan-pull-call-review` (a descrição ficou igual).

## Crédito do autor (author.md)

O repositório pede que o crédito do autor acompanhe a skill. Conteúdo do `author.md` original:

```markdown
---
name: Rob Snyder
avatarUrl: "https://www.gtmskills.com/authors/rob-snyder.jpg"
title: Author, The Power of Pull
linkedinUrl: "https://linkedin.com/in/rsnyder1"
companyDomain: robsnyder.org
---

Author of The Power of Pull and writer of The Physics of Startups newsletter. Fellow at Harvard Innovation Labs, HBS alum and ex-McKinsey, he has helped 50+ B2B startups find repeatable sales on the way from zero to $1M+ ARR.
```

## Observação de atribuição

O SKILL.md exige que toda análise comece com um cabeçalho de atribuição ao livro *The Power of Pull* e ao trabalho de Rob Snyder. Esse cabeçalho foi mantido sem alteração: é o crédito pedido pelo autor. O método pode ser usado; trechos do livro não foram copiados.

# Origem e licença

Esta skill é uma cópia, com as alterações listadas abaixo, de material de especialista com licença aberta.

- **Fonte:** https://github.com/anthropics/knowledge-work-plugins
- **Arquivos de origem:** `design/skills/design-critique/SKILL.md`
- **Autor:** Anthropic
- **Licença:** Apache-2.0 (texto completo em `LICENSE`)
- **Commit:** `0e0fcacddcc892eb92a1b7873ff9d68159c47571` (baixado em 2026-11-22)

## Alterações feitas

- `name:` do frontmatter trocado de `design-critique` para `kwp-design-critique`.
- Removida a linha que aponta para `CONNECTORS.md` e a seção "If Connectors Available" (regras de conectores do Claude Cowork, que não existem no Progress Code).
- Fora isso, o texto do especialista está como no original (em inglês).

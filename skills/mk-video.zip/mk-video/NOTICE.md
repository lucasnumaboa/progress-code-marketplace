# Origem e mudanças

- **Repositório:** https://github.com/coreyhaines31/marketingskills
- **Caminho no repositório:** `skills/video`
- **Autor:** Corey Haines
- **Licença:** MIT (texto em `LICENSE`)
- **Commit usado:** `5b2b400eec1e7e1cec76245a715d0b0d4fd2a9c1`
- **Arquivos copiados:** `SKILL.md`, `references/ai-video-prompting.md`, `references/code-rendered-product-films.md`, `references/edit-anatomy.md`, `references/product-demo-recording.md`

## Mudanças feitas

- no cabeçalho (frontmatter), `name:` passou de `video` para `mk-video`; a descrição ficou igual
- nenhuma outra alteração no texto do especialista (mantido em inglês)

Empacotada para o marketplace do Progress Code em 2026-11-22.

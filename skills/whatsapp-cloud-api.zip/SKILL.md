---
name: whatsapp-cloud-api
description: Envia mensagens de WhatsApp via API oficial (Cloud API da Meta) com templates aprovados, mídia e recebimento de respostas via webhook — nunca automação não-oficial (que viola os termos e derruba o número). Use quando o usuário pedir para "mandar aviso pelo WhatsApp para clientes", "integrar WhatsApp Business", "responder mensagens do WhatsApp automaticamente".
argument-hint: [template/mensagem] [destinatário(s)]
---

# WhatsApp via API oficial (Cloud API)

## Por que só a API oficial
Automação via WhatsApp Web/navegador (não oficial) viola os Termos de Serviço da Meta e o número pode ser banido
sem aviso — **nunca proponha esse caminho**. A Cloud API oficial (gratuita até certo volume, paga acima disso)
exige uma conta comercial (WhatsApp Business Platform) já configurada — se o usuário ainda não tem, isso precisa
ser resolvido no Meta Business Suite antes de qualquer código.

## Passo 1 — Enviar mensagem de template (fora da janela de 24h)
Fora de uma conversa iniciada pelo cliente nas últimas 24h, **só é permitido enviar um template pré-aprovado** pela
Meta (não texto livre) — regra da plataforma, não limitação técnica desta skill:
```python
import requests

requests.post(
    f"https://graph.facebook.com/v19.0/{phone_number_id}/messages",
    headers={"Authorization": f"Bearer {token}"},
    json={
        "messaging_product": "whatsapp",
        "to": "5511999998888",
        "type": "template",
        "template": {
            "name": "confirmacao_pedido",
            "language": {"code": "pt_BR"},
            "components": [{
                "type": "body",
                "parameters": [{"type": "text", "text": "12345"}],  # preenche {{1}} no template
            }],
        },
    },
)
```
O template (`confirmacao_pedido` no exemplo) precisa já existir e estar **aprovado** no Meta Business Manager —
esta skill não cria/aprova templates, só envia.

## Passo 2 — Texto livre (só dentro da janela de 24h após mensagem do cliente)
```python
json={"messaging_product": "whatsapp", "to": numero, "type": "text", "text": {"body": "Mensagem livre."}}
```

## Passo 3 — Mídia (imagem, PDF, etc.)
```python
json={"messaging_product": "whatsapp", "to": numero, "type": "document",
      "document": {"link": "https://.../boleto.pdf", "filename": "boleto.pdf"}}
```
`link` precisa ser uma URL pública acessível pela Meta no momento do envio (ou faça upload prévio pelo endpoint de
mídia da API e use o `media_id` retornado em vez de `link`).

## Passo 4 — Receber respostas (webhook)
Configure um endpoint HTTPS público (ex.: Azure Functions, servidor próprio) e registre no Meta Developer Console.
A Meta envia `POST` para esse endpoint a cada mensagem recebida:
```python
# endpoint que recebe o webhook
@app.route("/webhook", methods=["POST"])
def webhook():
    dados = request.json
    mensagem = dados["entry"][0]["changes"][0]["value"]["messages"][0]
    print(mensagem["from"], mensagem["text"]["body"])
    return "", 200
```
A verificação inicial do webhook (`GET` com `hub.challenge`) precisa ser respondida corretamente ou a Meta não
ativa o webhook — siga exatamente o passo de verificação da documentação oficial.

## Regras
- Nunca envie template fora do que foi aprovado (texto/variáveis diferentes do aprovado é rejeitado pela API).
- Respeite a janela de 24h — texto livre fora dela falha com erro específico da API; trate isso como esperado, não
  bug.
- Números de teste vs. produção: confirme com o usuário qual ambiente está usando antes de disparar em massa —
  mensagem real para cliente não tem "desfazer".
- Envio em massa: sempre confirme a lista de destinatários com o usuário antes de disparar — WhatsApp é canal
  sensível (spam gera denúncia e pode banir o número da empresa).

## Arquivos desta skill
Nenhum script fixo — os trechos acima cobrem os casos mais comuns; adapte ao template/fluxo real já aprovado.

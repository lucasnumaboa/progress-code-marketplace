# Origem

Skill de especialista empacotada para o marketplace do Progress Code (id `mk-events`).

- Repositório: https://github.com/coreyhaines31/marketingskills
- Caminho: `skills/events`
- Autor: Corey Haines
- Detentor do copyright no arquivo de licença: Corey Haines
- Licença: MIT (texto completo em `LICENSE`, copiado de `LICENSE` no repositório)
- Commit: `5b2b400eec1e7e1cec76245a715d0b0d4fd2a9c1` (baixado em 2026-11-22)

## Arquivos incluídos

- `SKILL.md` (de `skills/events/SKILL.md`)
- `references/event-portfolio-strategy.md` (de `skills/events/references/event-portfolio-strategy.md`)
- `references/speaking.md` (de `skills/events/references/speaking.md`)
- `references/sponsorship-roi.md` (de `skills/events/references/sponsorship-roi.md`)
- `references/webinar-funnel.md` (de `skills/events/references/webinar-funnel.md`)

## Mudanças feitas

1. Frontmatter: `name:` trocado de `events` para `mk-events` (a descrição foi mantida).

O texto do especialista foi mantido em inglês, sem tradução.

## Não incluído

- `evals/evals.json` (casos de teste do autor, sem uso em tempo de execução).

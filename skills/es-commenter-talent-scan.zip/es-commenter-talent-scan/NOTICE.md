# Origem

Skill de especialista empacotada para o marketplace do Progress Code (id `es-commenter-talent-scan`).

- Repositório: https://github.com/ericosiu/ai-marketing-skills
- Caminho: `commenter-talent-scan`
- Autor: Single Grain
- Detentor do copyright no arquivo de licença: Single Grain
- Licença: MIT (texto completo em `LICENSE`, copiado de `LICENSE` no repositório)
- Commit: `c715f900e3a7c1f4274976ca851849d9a7c3fe55` (baixado em 2026-11-22)

## Arquivos incluídos

- `SKILL.md` (de `commenter-talent-scan/SKILL.md`)
- `references/sieve-domain-template/CASES_README.md` (de `commenter-talent-scan/references/sieve-domain-template/CASES_README.md`)

## Mudanças feitas

1. Frontmatter: `name:` trocado de `commenter-talent-scan` para `es-commenter-talent-scan` (a descrição foi mantida).
2. Removido o bloco comercial entre `<!-- gateway-cta:start -->` e `<!-- gateway-cta:end -->` (convite para conectar o "Single Brain Gateway" e contratar a agência).

O texto do especialista foi mantido em inglês, sem tradução.

## Não incluído

- `README.md` (repete o SKILL.md e traz o mesmo bloco comercial).
- `references/sieve-domain-template/build_states.py`, `route.py` e `config.json`: dependem da API paga Jev (TypeSafe) e do Apify. O método (perguntas, rotas, portão de calibração) está descrito no SKILL.md.

# Origem

Skill de especialista empacotada para o marketplace do Progress Code (id `sp-writing-plans`).

- Repositório: https://github.com/obra/superpowers
- Caminho: `skills/writing-plans`
- Autor: Jesse Vincent
- Detentor do copyright no arquivo de licença: Jesse Vincent
- Licença: MIT (texto completo em `LICENSE`, copiado de `LICENSE` no repositório)
- Commit: `22f0b463e7a5e579904dd6211a520321035526f7` (baixado em 2026-11-22)

## Arquivos incluídos

- `SKILL.md` (de `skills/writing-plans/SKILL.md`)

## Mudanças feitas

1. Frontmatter: `name:` trocado de `writing-plans` para `sp-writing-plans` (a descrição foi mantida).

O texto do especialista foi mantido em inglês, sem tradução.

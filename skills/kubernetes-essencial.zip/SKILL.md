---
name: kubernetes-essencial
description: Usa kubectl para aplicar manifests, gerenciar ConfigMap/Secret, ler logs e eventos, port-forward e Helm básico, instalando sozinho kubectl e um cluster local (minikube) se necessário. Use quando o usuário pedir para "aplicar esse manifest no Kubernetes", "por que esse pod está em CrashLoopBackOff", "criar um ConfigMap/Secret", "testar isso num cluster local".
argument-hint: [cluster] [operação]
---

# Kubernetes essencial

## Passo 0 — Verificar/instalar kubectl e um cluster
```
kubectl version --client
```
Se não existir:
```
winget install Kubernetes.kubectl
```
Isso só instala o **cliente** — ainda precisa de um cluster para apontar. Se o usuário não tem um cluster
corporativo/em nuvem já configurado e só quer testar localmente:
```
winget install Kubernetes.minikube
minikube start
```
`minikube start` baixa uma imagem de VM/container na primeira vez (algumas centenas de MB) — avise antes. Depois
de rodar, confirme que `kubectl` já aponta para ele: `kubectl config current-context` deve mostrar `minikube`.

## Passo 1 — Aplicar manifests
```yaml
# deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata: { name: minha-app }
spec:
  replicas: 2
  selector: { matchLabels: { app: minha-app } }
  template:
    metadata: { labels: { app: minha-app } }
    spec:
      containers:
        - name: minha-app
          image: minha-app:1.0
          ports: [{ containerPort: 8080 }]
          envFrom:
            - configMapRef: { name: minha-app-config }
            - secretRef: { name: minha-app-secrets }
```
```
kubectl apply -f deployment.yaml
kubectl get pods
kubectl get deployments
```

## Passo 2 — ConfigMap e Secret
```
kubectl create configmap minha-app-config --from-literal=NIVEL_LOG=info
kubectl create secret generic minha-app-secrets --from-literal=DB_SENHA=senha-real
```
`Secret` do Kubernetes é **apenas codificado em base64, não criptografado** por padrão — não é o mesmo nível de
proteção de um cofre de segredos de verdade (ver skill `gerenciar-segredos-windows`/Key Vault); trate como
"ligeiramente ofuscado", não como seguro contra quem tem acesso ao cluster.

## Passo 3 — Logs e eventos (diagnosticar pod com problema)
```
kubectl logs nome-do-pod
kubectl logs nome-do-pod --previous          # logs do container anterior, se ele reiniciou
kubectl describe pod nome-do-pod              # eventos: por que nao subiu, imagem nao encontrada, etc.
kubectl get events --sort-by='.lastTimestamp'
```
`CrashLoopBackOff`: o container inicia e morre repetidamente — `kubectl logs --previous` quase sempre mostra o
erro real da aplicação antes de morrer; `describe pod` mostra causas de infraestrutura (imagem não encontrada,
falta de recurso, falha de probe de saúde).

## Passo 4 — Port-forward (acessar um serviço interno do cluster da sua máquina)
```
kubectl port-forward svc/minha-app 8080:8080
```
Útil para depurar um serviço que não está exposto publicamente, sem precisar mudar a configuração do cluster.

## Passo 5 — Helm básico (pacotes de manifests parametrizados)
```
winget install Helm.Helm
helm repo add bitnami https://charts.bitnami.com/bitnami
helm install meu-postgres bitnami/postgresql --set auth.password=senha
helm list
helm uninstall meu-postgres
```

## Regras
- Nunca aplique manifest em cluster de produção sem revisar (`kubectl diff -f arquivo.yaml` antes de `apply`,
  quando disponível) — mesmo princípio do `terraform plan` (ver skill `infra-como-codigo-terraform`).
- `Secret` do Kubernetes não é criptografia forte — não trate como suficiente sozinho para dado muito sensível.
- Confirme sempre o **contexto ativo** (`kubectl config current-context`) antes de qualquer comando — aplicar no
  cluster errado (produção em vez de teste) é um erro caro e comum quando há múltiplos contextos configurados.

## Arquivos desta skill
Nenhum script fixo — os comandos acima cobrem os casos mais comuns; adapte ao manifest/cluster real do usuário.

---
name: active-directory-usuarios
description: Consulta usuários/grupos, reseta senha, gera relatório de contas inativas e cria usuários em lote via CSV no Active Directory, habilitando sozinho o módulo RSAT (recurso do Windows) se ainda não estiver presente. Use quando o usuário pedir para "consultar/criar usuários no AD", "resetar senha de um usuário do domínio", "listar contas inativas há mais de X dias", "importar usuários de uma planilha para o AD".
argument-hint: [operação] [usuário(s)/critério]
---

# Active Directory e usuários

## Passo 0 — Verificar/habilitar o módulo (RSAT — recurso do Windows, não um programa para baixar)
```powershell
Get-Module -ListAvailable ActiveDirectory
```
Se não aparecer, habilite o recurso (funciona em Windows 10/11 Pro/Enterprise já ligados a um domínio, ou num
servidor com essa role já disponível):
```powershell
Add-WindowsCapability -Online -Name Rsat.ActiveDirectory.DS-LDS.Tools~~~~0.0.1.0
Import-Module ActiveDirectory
```
Não exige reinício normalmente, mas pode levar um minuto para instalar. **Pré-requisito real**: isso só funciona
numa máquina com permissão de rede para acessar um controlador de domínio — não faz sentido numa máquina fora do
domínio/sem rede corporativa; confirme esse contexto com o usuário antes de tentar.

## Passo 1 — Consultar usuário/grupo
```powershell
Get-ADUser -Identity "fulano.silva" -Properties EmailAddress, Department, LastLogonDate
Get-ADGroupMember -Identity "TI-Suporte" | Select-Object Name, SamAccountName
Get-ADUser -Filter {Department -eq "Financeiro"} -Properties Department
```

## Passo 2 — Resetar senha
```powershell
Set-ADAccountPassword -Identity "fulano.silva" -Reset -NewPassword (ConvertTo-SecureString "SenhaTemp!2026" -AsPlainText -Force)
Set-ADUser -Identity "fulano.silva" -ChangePasswordAtLogon $true   # forca trocar no proximo login
```
Nunca defina uma senha temporária sem `-ChangePasswordAtLogon $true` — deixar uma senha fixa conhecida sem forçar
troca é um risco de segurança real, mesmo que "temporária".

## Passo 3 — Relatório de contas inativas
```powershell
$limite = (Get-Date).AddDays(-90)
Get-ADUser -Filter {LastLogonDate -lt $limite -and Enabled -eq $true} -Properties LastLogonDate, Department |
    Select-Object Name, SamAccountName, LastLogonDate, Department |
    Export-Csv "contas_inativas.csv" -NoTypeInformation -Encoding UTF8
```
`LastLogonDate` não é replicado em tempo real entre controladores de domínio em todo ambiente — em domínios com
múltiplos DCs, o valor pode ter alguns dias de defasagem dependendo da configuração; trate o resultado como
aproximado, não como verdade absoluta ao segundo.

## Passo 4 — Criar usuários em lote a partir de CSV
```powershell
Import-Csv "novos_usuarios.csv" | ForEach-Object {
    New-ADUser -Name "$($_.Nome) $($_.Sobrenome)" `
        -SamAccountName $_.Login `
        -UserPrincipalName "$($_.Login)@empresa.com.br" `
        -Path $_.UnidadeOrganizacional `
        -AccountPassword (ConvertTo-SecureString $_.SenhaInicial -AsPlainText -Force) `
        -Enabled $true -ChangePasswordAtLogon $true
}
```
Sempre rode primeiro com `-WhatIf` (`New-ADUser ... -WhatIf`) para conferir o que seria criado, antes de rodar de
verdade em lote — criação de usuário no AD tem efeito em todo o domínio, corrigir 50 usuários criados errado é
bem mais trabalhoso que revisar antes.

## Regras
- Nunca resete senha ou crie usuário em lote sem confirmação explícita do usuário sobre os dados exatos — efeito
  em produção de domínio corporativo, não ambiente de teste isolado.
- Sempre use `-WhatIf` antes de qualquer operação em lote (criação, desabilitação, exclusão) pela primeira vez.
- Conta desabilitada/excluída: confirme se a intenção é desabilitar (reversível, `Disable-ADAccount`) ou excluir
  (`Remove-ADUser`, mais difícil de reverter) — nunca assuma qual das duas sem perguntar.

## Arquivos desta skill
Nenhum script fixo — os comandos acima cobrem os casos mais comuns; adapte à estrutura/domínio real do usuário.

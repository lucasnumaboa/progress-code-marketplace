import { NgModule, LOCALE_ID } from '@angular/core';
import { CommonModule, registerLocaleData } from '@angular/common';
import localePt from '@angular/common/locales/pt';
import { FormsModule } from '@angular/forms';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';

import { PoModule, PoI18nModule, PoI18nConfig } from '@po-ui/ng-components';

import { ConsultaNotasComponent } from './consulta-notas.component';
import { ConsultaNotasService } from './consulta-notas.service';
import { DatasulAuthInterceptor } from './auth.interceptor';

// pt-BR para as colunas type:'date' do po-table não inverterem dia/mês
registerLocaleData(localePt, 'pt-BR');

/**
 * i18n mínimo do PO-UI: alguns componentes (e a dts-backoffice-util, se usada) precisam do
 * token I18N_CONFIG no injetor. Não precisa de arquivos de tradução.
 */
const i18nConfig: PoI18nConfig = {
  default: { language: 'pt', context: 'general', cache: true },
  contexts: { general: { pt: {} } }
};

@NgModule({
  declarations: [ConsultaNotasComponent],
  imports: [
    CommonModule,
    FormsModule,
    HttpClientModule,
    PoModule,
    PoI18nModule.config(i18nConfig)
  ],
  providers: [
    ConsultaNotasService,
    { provide: LOCALE_ID, useValue: 'pt-BR' },
    // token JWT do Datasul em todas as chamadas
    { provide: HTTP_INTERCEPTORS, useClass: DatasulAuthInterceptor, multi: true }
  ],
  exports: [ConsultaNotasComponent]
})
export class ConsultaNotasModule { }

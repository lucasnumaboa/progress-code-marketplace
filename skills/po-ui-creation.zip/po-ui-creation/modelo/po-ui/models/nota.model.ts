/** Situação calculada pelo backend a partir das datas de confirmação e cancelamento. */
export type SituacaoNota = 'processada' | 'pendente' | 'cancelada';

/** Uma linha da lista, no formato devolvido por esp/api/v1/esnf0001ws.p. */
export interface Nota {
  nota: string;
  emitente: string;
  /** data ISO (aaaa-mm-dd) */
  emissao: string;
  valor: number;
  situacao: SituacaoNota;
}

/** Lista paginada no padrão da API TOTVS. */
export interface ListaNotas {
  items: Nota[];
  hasNext: boolean;
}

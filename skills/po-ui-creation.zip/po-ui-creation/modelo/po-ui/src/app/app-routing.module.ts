import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { ConsultaNotasComponent } from '../../consulta-notas.component';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'consulta-notas',
    pathMatch: 'full'
  },
  {
    path: 'consulta-notas',
    component: ConsultaNotasComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

import { Component, OnInit } from '@angular/core';
import { PoNotificationService, PoTableColumn } from '@po-ui/ng-components';

import { ConsultaNotasService } from './consulta-notas.service';
import { Nota } from './models/nota.model';

/**
 * Tela de exemplo do modelo: consulta paginada com filtro.
 * Serve de ponto de partida — troque pelos campos e pela API da funcionalidade real,
 * mantendo o padrão: componente na RAIZ do projeto, chamadas HTTP só pelo service.
 */
@Component({
  selector: 'app-consulta-notas',
  templateUrl: './consulta-notas.component.html',
  styleUrls: ['./consulta-notas.component.scss']
})
export class ConsultaNotasComponent implements OnInit {

  readonly pageSize = 20;

  readonly colunas: PoTableColumn[] = [
    { property: 'nota', label: 'Nota', width: '14%' },
    { property: 'emitente', label: 'Emitente' },
    { property: 'emissao', label: 'Emissão', type: 'date', format: 'dd/MM/yyyy', width: '14%' },
    { property: 'valor', label: 'Valor', type: 'currency', format: 'BRL', width: '16%' },
    {
      property: 'situacao',
      label: 'Situação',
      type: 'label',
      width: '16%',
      labels: [
        { value: 'processada', label: 'Processada', color: 'color-11' },
        { value: 'pendente', label: 'Pendente', color: 'color-08' },
        { value: 'cancelada', label: 'Cancelada', color: 'color-07' }
      ]
    }
  ];

  notas: Nota[] = [];
  emitente = '';
  pagina = 1;
  temMais = false;
  carregando = false;

  constructor(private service: ConsultaNotasService, private notification: PoNotificationService) { }

  ngOnInit(): void {
    this.pesquisar();
  }

  /** Nova busca (filtro mudou): volta para a primeira página. */
  pesquisar(): void {
    this.pagina = 1;
    this.notas = [];
    this.carregar();
  }

  /** "Carregar mais resultados" do po-table. */
  carregarMais(): void {
    this.pagina++;
    this.carregar();
  }

  private carregar(): void {
    this.carregando = true;
    this.service.listar(this.emitente, this.pagina, this.pageSize).subscribe({
      next: (resp) => {
        this.notas = [...this.notas, ...(resp.items ?? [])];
        this.temMais = !!resp.hasNext;
        this.carregando = false;
      },
      error: (err) => {
        this.carregando = false;
        // a API TOTVS devolve { code, message, detailedMessage }
        this.notification.error(err?.error?.message || 'Não foi possível consultar as notas.');
      }
    });
  }
}

/**
 * Ambiente: PRODUÇÃO — Tomcat TOTVS Datasul
 *
 * Build de produção:  npm run build:prod
 * O Angular troca environment.ts por este arquivo (fileReplacements no angular.json).
 *
 * Use caminho RELATIVO: a tela é publicada no mesmo servidor que responde a API. Endereço
 * diferente por ambiente vai em assets/app-config.json no Tomcat, sem rebuild — nunca
 * escreva IP ou servidor do cliente aqui.
 */
export const environment = {
  production: true,

  /** API customizada (esp/api/v1/<programa>) no PASOE. */
  apiBase: '/api/esp/v1/esnf0001ws',

  /** Endpoints nativos RPW do Datasul (ex.: Datasul 12.1.x/12.2.x → /api/cdp/v1). */
  rpwBase: '/api/cdp/v1',
};

/**
 * Ambiente: DESENVOLVIMENTO LOCAL
 *
 * As URLs da API usadas pela tela vêm de src/assets/app-config.json (lido em runtime pelo
 * AppConfigService). Este arquivo fica para configurações de build.
 *
 * Para rodar localmente com proxy para o PASOE (ou para a API do po-ui-backend-local):
 *   npm start   (= ng serve --proxy-config proxy.conf.json)
 */
export const environment = {
  production: false,

  /** API customizada (esp/api/v1/<programa>) — o proxy de desenvolvimento leva /api ao PASOE. */
  apiBase: '/api/esp/v1/esnf0001ws',

  /** Endpoints nativos RPW do Datasul (o proxy leva /rpw ao PASOE). */
  rpwBase: '/rpw/api/cdp/v1',
};

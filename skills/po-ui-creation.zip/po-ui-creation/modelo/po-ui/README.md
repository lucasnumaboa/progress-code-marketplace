# Projeto PO-UI — TOTVS Datasul

Angular 17 + PO-UI 17, publicado no Tomcat do Datasul e consumindo uma API Progress (PASOE).
Criado a partir do modelo da skill **po-ui-creation**. Vem com uma tela de exemplo
(**Consulta de Notas**) e o programa Progress de exemplo que ela chama.

## Rodar

```bash
npm install --legacy-peer-deps   # obrigatório: @totvs/thf-ui declara peer do Angular 8
npm start                        # ng serve com o proxy (proxy.conf.json)
npm run build:prod               # dist/<nome>/ com base-href e web.xml em WEB-INF/
npm run build:war                # empacota o dist/ como <nome>.war para o Tomcat
```

Ou `..\build_projeto.bat` (uma pasta acima): instala se faltar e faz o build de produção;
`build_projeto.bat war` também gera o `.war`.

## Estrutura

```
po-ui/
├── src/                        casca Angular (main, index, app.module, rotas, tema, AppConfigService)
│   └── assets/app-config.json  URLs da API, lidas em RUNTIME (troca sem rebuild)
├── consulta-notas.*            a tela — fica na RAIZ do projeto, não em src/app/
├── models/nota.model.ts        interfaces
├── auth.interceptor.ts         token JWT do Datasul em todas as chamadas
├── environments/               environment.ts / environment.prod.ts
├── web.xml                     descritor do WAR (vai para WEB-INF, com o filtro SSO)
├── scripts/build-war.js        empacota o dist/ como .war
├── proxy.conf.json             dev: /api e /rpw → PASOE local
└── backend/ems2/esp/api/v1/    fonte Progress de exemplo (esnf0001ws.p) — referência, não é buildado aqui
```

## Fluxo

```
componente → service → AppConfigService.apiBase → proxy (dev) / Tomcat (prod) → PASOE → esp/api/v1/<programa>.p
```

`assets/app-config.json` no Tomcat define o endereço da API em cada ambiente:

```json
{ "apiBase": "/api/esp/v1/<programa>", "rpwBase": "/api/cdp/v1" }
```

## Testar sem o servidor do cliente

Com a skill **po-ui-backend-local**, o `esnf0001ws.p` roda na máquina com um banco local e a
tabela de exemplo (`--exemplo --carga teste`), e o proxy do `npm start` passa a apontar para ela.

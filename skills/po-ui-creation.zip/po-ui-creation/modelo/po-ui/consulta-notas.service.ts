import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';

import { AppConfigService } from './src/app/app-config.service';
import { ListaNotas } from './models/nota.model';

/**
 * Todas as chamadas HTTP da tela ficam aqui.
 * A URL base vem do AppConfigService (assets/app-config.json, lido em runtime):
 * nunca escreva endereço absoluto no componente.
 *
 * Backend de exemplo: backend/ems2/esp/api/v1/esnf0001ws.p
 *   GET /api/esp/v1/esnf0001ws?emitente=<início do nome>&page=<n>&pageSize=<n>
 *   → { items: [...], hasNext: true|false }   (padrão de lista da API TOTVS)
 */
@Injectable({ providedIn: 'root' })
export class ConsultaNotasService {

  private get API_BASE(): string { return this.config.apiBase; }

  constructor(private http: HttpClient, private config: AppConfigService) { }

  listar(emitente: string, page: number, pageSize: number): Observable<ListaNotas> {
    let params = new HttpParams()
      .set('page', String(page))
      .set('pageSize', String(pageSize));
    if (emitente.trim()) params = params.set('emitente', emitente.trim().toUpperCase());
    return this.http.get<ListaNotas>(this.API_BASE, { params });
  }
}

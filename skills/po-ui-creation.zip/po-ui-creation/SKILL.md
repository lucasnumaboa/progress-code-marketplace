---
name: po-ui-creation
description: Cria um projeto NOVO de frontend Angular 17 + PO-UI 17 para rodar dentro do TOTVS Datasul (tela nova, módulo novo, integração nova com backend Progress/PASOE), a partir de um modelo pronto que vem nesta skill — casca Angular, tema Datasul, AppConfigService com URL da API em runtime, interceptor do token JWT, web.xml com SSO, build de produção e .war para o Tomcat — e uma tela de exemplo com o programa Progress que ela chama. Use quando o usuário pedir "cria um projeto PO-UI", "tela nova em PO-UI para o Datasul", "front Angular para essa API Progress", ou para começar do zero antes de escrever a tela.
argument-hint: [pasta de destino e nome do projeto]
---

# po-ui-creation

Pedido: $ARGUMENTS

O modelo do projeto vem nesta pasta (`modelo/`). Não baixe nada e não escreva a casca do
Angular à mão: use o `criar-projeto.js`. Precisa de **Node 18+** (e rede para o `npm install`).

## 1. Criar o projeto

```
node "<pasta desta skill>\criar-projeto.js" --destino "<pasta>" --nome <nome-do-projeto> [--titulo "Título"] [--instalar] [--build]
```

- `<pasta desta skill>` é a pasta informada no topo quando a skill carrega.
- `--nome`: minúsculas e hífen (`consulta-pedidos`). Vira o nome em `package.json`/`angular.json`,
  o `dist/<nome>`, o `.war` e o base-href `/dts/custom/<nome>/`.
- Cria `<pasta>\po-ui\` (o projeto) e `<pasta>\build_projeto.bat` (uma pasta acima de `po-ui`).
- `--instalar` roda `npm install --legacy-peer-deps` (leva alguns minutos); `--build` também gera o
  build de produção para conferir que compila.
- Saída em JSON: confira `"ok": true`.

## 2. Construir a funcionalidade pedida

O modelo traz a tela **Consulta de Notas** (`consulta-notas.*`) e o `backend/ems2/esp/api/v1/esnf0001ws.p`
só como exemplo do padrão. Troque pela funcionalidade real:

1. **Tela na RAIZ do projeto**, não em `src/app/`: `<tela>.component.ts/html/scss`, `<tela>.module.ts`,
   `<tela>.service.ts`, `models/`. Por isso os imports em `src/app/` sobem dois níveis
   (`'../../<tela>.module'`) — funciona porque `tsconfig.app.json` usa `"files": ["src/main.ts"]`.
2. Registre o módulo da tela em `src/app/app.module.ts` e a rota em `src/app/app-routing.module.ts`
   (troque as referências a `ConsultaNotas…`). Apague os `consulta-notas.*` e o `models/nota.model.ts`
   quando não servirem mais.
3. **HTTP só pelo service**, com `this.API_BASE` (vem do `AppConfigService`). Nunca URL absoluta.
4. **Endereço da API** em `src/assets/app-config.json` (`apiBase: "/api/esp/v1/<programa>"`). É lido em
   runtime: em cada ambiente o sysadmin edita o arquivo no Tomcat, sem rebuild.
5. **Endpoint novo no Progress**, nesta ordem: rota no handler `esp/api/v1/<programa>.p` com
   `{utp/ut-api-action.i <procedure> <VERBO> <rota>}` (use `GET /~*` para a raiz), a regra no Business
   Object (`*Rules.p`), e o método no service. A resposta segue o padrão TOTVS: lista em
   `{ items, hasNext }`, erro em `{ code, message, detailedMessage }` (`JsonApiResponseBuilder`).
   Os fontes em `backend/` são referência: não são buildados nem publicados por este projeto.

## 3. Rodar e publicar

```bash
npm install --legacy-peer-deps   # OBRIGATÓRIO: @totvs/thf-ui@4 declara peer do Angular 8 → ERESOLVE sem a flag
npm start                        # ng serve com o proxy.conf.json (/api e /rpw → PASOE local, porta 31003)
npm run build:prod               # dist/<nome>/ com o web.xml em WEB-INF/
npm run build:war                # <nome>.war para $TOMCAT_HOME/webapps
```

`build_projeto.bat` faz o mesmo sozinho (`build_projeto.bat war` também gera o `.war`). Antes do deploy,
confirme com o usuário o Tomcat do Datasul e o `app-config.json` do ambiente.

**Sem servidor do cliente**: a skill `po-ui-backend-local` (se instalada) sobe banco e API local no
formato do PASOE e ajusta o proxy; com o modelo intacto, `--exemplo --carga teste` já faz a Consulta de
Notas funcionar.

## Armadilhas

- `npm install` sem `--legacy-peer-deps` falha com `ERESOLVE` — não "resolva" subindo ou removendo pacotes.
- Colunas `type: 'date'` do `po-table` invertem dia/mês se faltar `LOCALE_ID` pt-BR no módulo da tela.
- Erro de `I18N_CONFIG` no injetor: falta `PoI18nModule.config(...)` no módulo da tela.
- Tema: mude `src/app/theme/totvs-datasul.theme.ts`, não CSS solto.
- Nunca escreva IP, servidor ou nome de cliente em `environment*.ts` ou no código: endereço vai no
  `app-config.json` do ambiente.
- Avisos esperados no build de produção (não são erro): bundle inicial um pouco acima de 2 MB e avisos de
  seletor CSS do próprio PO-UI.
- A API do PO-UI muda entre versões e o projeto está na 17: antes de usar uma propriedade de que não tem
  certeza, leia o `.md` do componente em `https://po-ui.io/llms-generated/<componente>.md`
  (índice: `https://po-ui.io/llms.txt`).

## Verificação

- `criar-projeto.js` com `"ok": true` (e `build.ok: true` quando usar `--build`).
- `npm run build:prod` sem erro depois da tela nova.
- A tela abre no `npm start` e a chamada da API chega ao programa certo (aba Rede do navegador, ou o log
  do backend local).

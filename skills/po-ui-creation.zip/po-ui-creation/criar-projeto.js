'use strict';
/* po-ui-creation - cria um projeto Angular 17 + PO-UI 17 para o TOTVS Datasul a partir do modelo
   que vem nesta skill (pasta "modelo").

   node criar-projeto.js --destino <pasta> --nome <nome-do-projeto> [--titulo "Titulo da tela"]
                         [--instalar] [--build] [--forcar]

   Cria <destino>\po-ui (o projeto) e <destino>\build_projeto.bat, troca o nome do projeto
   (package.json, package-lock.json, angular.json, base-href, titulo) e, com --instalar, roda
   npm install --legacy-peer-deps. Saida em JSON. Node puro, sem npm install. */
const fs = require('fs');
const path = require('path');
const cp = require('child_process');

const MODELO = path.join(__dirname, 'modelo');
const NOME_MODELO = 'meu-projeto';

function sai(obj, codigo) {
  process.stdout.write(JSON.stringify(obj, null, 1) + '\n');
  process.exit(codigo || 0);
}

function args(argv) {
  const a = {};
  for (let i = 0; i < argv.length; i++) {
    const k = argv[i];
    if (!k.startsWith('--')) continue;
    const nome = k.slice(2);
    const prox = argv[i + 1];
    if (prox !== undefined && !prox.startsWith('--')) { a[nome] = prox; i++; } else a[nome] = true;
  }
  return a;
}

function copia(origem, destino) {
  fs.mkdirSync(destino, { recursive: true });
  for (const it of fs.readdirSync(origem, { withFileTypes: true })) {
    const o = path.join(origem, it.name);
    const d = path.join(destino, it.name);
    if (it.isDirectory()) copia(o, d);
    else fs.copyFileSync(o, d);
  }
}

function troca(arquivo, de, para) {
  if (!fs.existsSync(arquivo)) return false;
  const t = fs.readFileSync(arquivo, 'utf8');
  const n = t.split(de).join(para);
  if (n !== t) fs.writeFileSync(arquivo, n);
  return n !== t;
}

const a = args(process.argv.slice(2));
if (a.ajuda || !a.destino || !a.nome) {
  sai({ uso: 'node criar-projeto.js --destino <pasta> --nome <nome-do-projeto> [--titulo "Titulo"] [--instalar] [--build] [--forcar]' }, a.ajuda ? 0 : 1);
}
const nome = String(a.nome).trim().toLowerCase();
if (!/^[a-z][a-z0-9-]*$/.test(nome)) sai({ erro: `nome "${a.nome}" invalido: use letras minusculas, numeros e hifen (ex.: consulta-pedidos)` }, 1);
const destino = path.resolve(String(a.destino));
const projeto = path.join(destino, 'po-ui');
if (fs.existsSync(path.join(projeto, 'package.json')) && !a.forcar) {
  sai({ erro: `ja existe um projeto em ${projeto}`, proximo_passo: 'use outra pasta, ou --forcar para sobrescrever os arquivos do modelo' }, 1);
}
if (!fs.existsSync(path.join(MODELO, 'po-ui', 'package.json'))) sai({ erro: `modelo nao encontrado em ${MODELO}` }, 2);

copia(path.join(MODELO, 'po-ui'), projeto);
fs.copyFileSync(path.join(MODELO, 'build_projeto.bat'), path.join(destino, 'build_projeto.bat'));

const alterados = [];
for (const rel of ['package.json', 'package-lock.json', 'angular.json', 'src/app/app-config.service.ts']) {
  if (troca(path.join(projeto, rel), NOME_MODELO, nome)) alterados.push(rel);
}
const titulo = a.titulo && a.titulo !== true ? String(a.titulo) : nome.split('-').map((p) => p[0].toUpperCase() + p.slice(1)).join(' ');
if (troca(path.join(projeto, 'src', 'index.html'), 'Meu Projeto', titulo)) alterados.push('src/index.html');

const resultado = {
  ok: true,
  projeto,
  nome,
  titulo,
  build_bat: path.join(destino, 'build_projeto.bat'),
  alterados,
  base_href: `/dts/custom/${nome}/`,
  proximos_passos: [
    'Troque a tela de exemplo (consulta-notas.*) pela funcionalidade pedida, mantendo o componente na RAIZ do projeto.',
    'Ajuste src/assets/app-config.json (apiBase) para a API do programa esp/api/v1 da funcionalidade.',
    'npm install --legacy-peer-deps (ou --instalar aqui) e npm start para testar; npm run build:prod para o Tomcat.'
  ]
};

const npm = process.platform === 'win32' ? 'npm.cmd' : 'npm';
if (a.instalar || a.build) {
  const r = cp.spawnSync(npm, ['install', '--legacy-peer-deps', '--no-audit', '--no-fund'], { cwd: projeto, encoding: 'utf8', shell: true, maxBuffer: 64 * 1024 * 1024 });
  resultado.instalar = { ok: r.status === 0, saida: ((r.stdout || '') + (r.stderr || '')).trim().split(/\r?\n/).slice(-8).join('\n') };
  if (r.status !== 0) { resultado.ok = false; sai(resultado, 1); }
}
if (a.build) {
  const r = cp.spawnSync(npm, ['run', 'build:prod'], { cwd: projeto, encoding: 'utf8', shell: true, maxBuffer: 64 * 1024 * 1024 });
  const saida = ((r.stdout || '') + (r.stderr || '')).trim();
  resultado.build = { ok: r.status === 0, dist: path.join(projeto, 'dist', nome), saida: saida.split(/\r?\n/).slice(-12).join('\n') };
  if (r.status !== 0) resultado.ok = false;
}
sai(resultado, resultado.ok ? 0 : 1);

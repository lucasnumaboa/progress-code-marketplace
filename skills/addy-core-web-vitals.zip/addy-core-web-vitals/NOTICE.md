# Origem e mudanças

- **Repositório:** https://github.com/addyosmani/web-quality-skills
- **Caminho no repositório:** `skills/core-web-vitals`
- **Autor:** Addy Osmani
- **Licença:** MIT (texto em `LICENSE`)
- **Commit usado:** `afa8da942115f2961fdbfa80807ea0b232ff6c00`
- **Arquivos copiados:** `SKILL.md`, `references/CLS.md`, `references/INP.md`, `references/LCP.md`, `references/MEASUREMENT.md`, `references/RUM.md`

## Mudanças feitas

- no cabeçalho (frontmatter), `name:` passou de `core-web-vitals` para `addy-core-web-vitals`; a descrição ficou igual
- links para `../performance/references/` (outra skill do repositório) passaram a apontar para as cópias incluídas em `references/`
- nenhuma outra alteração no texto do especialista (mantido em inglês)

## Observações

- `references/MEASUREMENT.md` e `references/RUM.md` foram copiados da skill `skills/performance` do mesmo repositório, porque o SKILL.md manda lê-los

Empacotada para o marketplace do Progress Code em 2026-11-22.

---
name: chamar-apis-http
description: Chama APIs HTTP corretamente — autenticação (Bearer/Basic/OAuth2/API key), paginação, retry com backoff exponencial, rate limit e idempotência — com exemplos em Python, PowerShell e curl. Use quando o usuário pedir para "integrar com essa API", "essa chamada está dando erro 429/401", "como faço paginação nessa API", "chamar esse endpoint com autenticação".
argument-hint: [documentação/endpoint da API] [operação desejada]
---

# Chamar APIs HTTP corretamente

## Autenticação — os 4 padrões mais comuns
```python
import requests

# Bearer token
requests.get(url, headers={"Authorization": f"Bearer {token}"})

# Basic auth
requests.get(url, auth=(usuario, senha))

# API key em header customizado (varia por API - confira a doc)
requests.get(url, headers={"X-API-Key": chave})

# API key em query string (menos comum, evite se a API oferecer alternativa em header - fica no log do servidor)
requests.get(url, params={"api_key": chave})
```
```powershell
Invoke-RestMethod -Uri $url -Headers @{ Authorization = "Bearer $token" }
```
```bash
curl -H "Authorization: Bearer $TOKEN" "$URL"
```

## Paginação — 3 estilos comuns
```python
# 1) Baseada em pagina/offset
pagina = 1
while True:
    resp = requests.get(url, params={"page": pagina, "per_page": 100}).json()
    if not resp["items"]:
        break
    processar(resp["items"])
    pagina += 1

# 2) Baseada em cursor (token da proxima pagina vem na resposta)
cursor = None
while True:
    resp = requests.get(url, params={"cursor": cursor}).json()
    processar(resp["items"])
    cursor = resp.get("next_cursor")
    if not cursor:
        break

# 3) Baseada em Link header (padrao GitHub/muitas APIs REST maduras)
resp = requests.get(url)
processar(resp.json())
proxima = resp.links.get("next", {}).get("url")
```
Sempre confira a documentação da API específica para saber qual estilo ela usa — não assuma, os três são comuns.

## Retry com backoff exponencial (erros transitórios: 429, 500, 502, 503, timeout)
```python
import time

def chamar_com_retry(func, tentativas=5):
    for tentativa in range(tentativas):
        try:
            resp = func()
            if resp.status_code == 429:
                espera = int(resp.headers.get("Retry-After", 2 ** tentativa))
                time.sleep(espera)
                continue
            resp.raise_for_status()
            return resp
        except requests.exceptions.RequestException:
            if tentativa == tentativas - 1:
                raise
            time.sleep(2 ** tentativa)
```
Respeite o header `Retry-After` quando a API mandar (mais preciso que backoff genérico). Erros `4xx` que não sejam
`429` (ex.: `400`, `404`) geralmente **não** devem ter retry — são erro do pedido, tentar de novo não resolve.

## Idempotência (evitar duplicar ao reenviar)
Para operações de escrita (`POST` que cria algo), se a API suportar `Idempotency-Key` (header comum em APIs de
pagamento e várias modernas), sempre envie uma chave única por operação de negócio — assim, se a chamada falhar por
timeout mas tiver sido processada do lado do servidor, reenviar com a mesma chave não duplica o efeito.
```python
requests.post(url, json=payload, headers={"Idempotency-Key": id_operacao_unico})
```

## Regras
- Nunca deixe uma chamada sem `timeout` — `requests.get(url)` sem timeout pode travar para sempre se o servidor
  não responder; sempre `timeout=15` (ajuste conforme a API).
- Nunca coloque token/senha direto no código — leia de variável de ambiente ou de um cofre de segredos (ver skill
  `gerenciar-segredos-windows`).
- Sempre trate o corpo de erro da API (`resp.json()` ou `resp.text` quando `resp.status_code >= 400`) antes de só
  reportar o código HTTP — a mensagem de erro da API costuma explicar exatamente o que está errado no pedido.

## Arquivos desta skill
Nenhum script fixo — os trechos acima cobrem o padrão de uso; adapte à API real do usuário.

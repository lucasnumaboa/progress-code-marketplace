# Origem e mudanças

- **Repositório:** https://github.com/coreyhaines31/marketingskills
- **Caminho no repositório:** `skills/ads`
- **Autor:** Corey Haines
- **Licença:** MIT (texto em `LICENSE`)
- **Commit usado:** `5b2b400eec1e7e1cec76245a715d0b0d4fd2a9c1`
- **Arquivos copiados:** `SKILL.md`, `references/abm-playbook.md`, `references/ad-copy-templates.md`, `references/audience-targeting.md`, `references/audit-guardrails.md`, `references/b2b-paid-playbook.md`, `references/creative-research-automation.md`, `references/google-ads-audit-checklist.md`, `references/google-search-playbook.md`, `references/linkedin-b2b-playbook.md`, `references/meta-andromeda-playbook.md`, `references/meta-decision-system.md`, `references/operating-check.md`, `references/payback-period.md`, `references/platform-setup-checklists.md`, `references/reading-google-ads-data.md`, `references/rsa-output-spec.md`

## Mudanças feitas

- no cabeçalho (frontmatter), `name:` passou de `ads` para `mk-ads`; a descrição ficou igual
- removida a menção ao Magister, produto do próprio mantenedor do repositório (propaganda)
- ajuste de redação ("and") na frase de onde saiu o Magister
- removida a menção a "Verified Partner"/parceiro comercial do repositório (◆), que é colocação paga/propaganda (em `references/abm-playbook.md`)
- nenhuma outra alteração no texto do especialista (mantido em inglês)

Empacotada para o marketplace do Progress Code em 2026-11-22.

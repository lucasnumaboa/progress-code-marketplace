# Origem e mudanças

- **Repositório:** https://github.com/coreyhaines31/marketingskills
- **Caminho no repositório:** `skills/social`
- **Autor:** Corey Haines
- **Licença:** MIT (texto em `LICENSE`)
- **Commit usado:** `5b2b400eec1e7e1cec76245a715d0b0d4fd2a9c1`
- **Arquivos copiados:** `SKILL.md`, `references/carousel-frameworks.md`, `references/chinese-platforms.md`, `references/listening.md`, `references/platform-limits.md`, `references/platforms.md`, `references/post-templates.md`, `references/reverse-engineering.md`, `references/ship-post.md`, `references/short-form-video.md`, `references/x-algorithm.md`

## Mudanças feitas

- no cabeçalho (frontmatter), `name:` passou de `social` para `mk-social`; a descrição ficou igual
- removida a menção ao Magister, produto do próprio mantenedor do repositório (propaganda)
- nenhuma outra alteração no texto do especialista (mantido em inglês)

Empacotada para o marketplace do Progress Code em 2026-11-22.

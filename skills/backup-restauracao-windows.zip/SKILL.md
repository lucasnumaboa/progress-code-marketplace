---
name: backup-restauracao-windows
description: Faz backup espelhado com robocopy, versionamento por data, backup de bancos e — o passo que quase todo mundo pula — testa a restauração de verdade, sem instalar programa externo. Use quando o usuário pedir para "fazer backup dessa pasta/banco", "configurar backup automático", "restaurar esse backup", "verificar se o backup está funcionando de verdade".
argument-hint: [origem] [destino do backup] [frequência/retenção]
---

# Backup e restauração

## robocopy — espelho de pastas (já embutido, muito mais robusto que Copy-Item para isso)
```powershell
robocopy "C:\Dados" "D:\Backup\Dados" /MIR /R:3 /W:5 /LOG:"C:\backup\log_$(Get-Date -Format yyyyMMdd).txt"
```
`/MIR` espelha (cria, atualiza **e apaga** no destino o que sumiu na origem — cuidado: isso propaga exclusões
acidentais da origem para o backup, o oposto do que backup geralmente deve fazer). `/R:3 /W:5` limita tentativas
de retry em arquivo travado (padrão do robocopy é tentar 1 milhão de vezes, o que trava o script para sempre num
arquivo bloqueado).

**Atenção com `/MIR`**: se o objetivo é um backup histórico (poder voltar a uma versão de dias atrás), `/MIR` sozinho
**não** serve — ele sincroniza, não versiona. Para isso, use o padrão de pasta por data (abaixo).

## Versionamento por data (backup incremental simples, sem programa especial)
```powershell
$data = Get-Date -Format "yyyy-MM-dd"
robocopy "C:\Dados" "D:\Backup\$data" /E /R:3 /W:5
```
Cada execução cria uma pasta nova com a data — simples de entender e restaurar (só copiar a pasta da data
desejada de volta), ao custo de mais espaço em disco que um backup incremental "de verdade" (que só grava o que
mudou). Para economizar espaço em pastas grandes que mudam pouco, use `/MIR` para um espelho "atual" **mais**
cópias periódicas versionadas por data separadas, em vez de versionar tudo todo dia.

## Backup de banco de dados
Não copie o arquivo do banco direto enquanto ele está em uso (`.mdf`/`.sqlite` etc.) — o arquivo pode estar em
estado inconsistente no meio de uma transação. Use o comando de backup nativo do banco:
```sql
-- SQL Server
BACKUP DATABASE MeuBanco TO DISK = 'D:\Backup\MeuBanco.bak'
```
```powershell
# SQLite - o proprio arquivo pode ser copiado com seguranca SE nao houver escrita concorrente,
# mas o mais seguro e' usar o comando de backup do sqlite3 (consistente mesmo com uso concorrente)
sqlite3 banco.db ".backup 'D:\Backup\banco_backup.db'"
```

## Retenção (apagar backups antigos automaticamente)
```powershell
Get-ChildItem "D:\Backup" -Directory | Where-Object { $_.Name -match '^\d{4}-\d{2}-\d{2}$' -and [datetime]$_.Name -lt (Get-Date).AddDays(-30) } | Remove-Item -Recurse -Force
```
Confirme a regra de retenção com o usuário antes de automatizar exclusão (30 dias é só um exemplo) — apagar backup
antigo sem confirmação é uma ação difícil de reverter.

## O passo que quase todo mundo pula: testar a restauração
Um backup nunca testado não é um backup confiável — é só uma cópia que **pode** funcionar. Periodicamente:
1. Restaure (copie de volta) para uma pasta/ambiente de teste, nunca sobre o original.
2. Abra/valide o conteúdo (arquivo abre? banco restaura sem erro? contagem de registros bate?).
3. Registre a data do último teste de restauração bem-sucedido — isso é o dado que realmente importa quando
   perguntarem "o backup funciona?".

## Regras
- Nunca configure `/MIR` sem deixar claro para o usuário que exclusões na origem se propagam ao destino.
- Nunca copie arquivo de banco de dados em uso sem usar o mecanismo de backup nativo do banco.
- Backup sem teste de restauração periódico não deve ser reportado como "backup funcionando" — só como "backup
  configurado, restauração não verificada".

## Arquivos desta skill
Nenhum script fixo — os comandos acima cobrem os casos mais comuns; adapte à origem/retenção reais do usuário.

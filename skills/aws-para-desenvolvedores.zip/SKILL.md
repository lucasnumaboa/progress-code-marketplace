---
name: aws-para-desenvolvedores
description: Usa o AWS CLI para S3, Lambda, EC2 e IAM mínimo necessário, com atenção a custos. Use quando o usuário pedir para "subir isso no S3", "criar uma Lambda", "configurar uma instância EC2", "criar um usuário IAM com permissão mínima".
argument-hint: [serviço AWS] [operação]
---

# AWS para desenvolvedores

## Instalar e autenticar
```
winget install Amazon.AWSCLI
aws configure   # pede Access Key ID, Secret Access Key, região padrão, formato de saída
```
Nunca gere/use a Access Key do usuário **root** da conta AWS para uso diário — crie um usuário IAM específico com
permissão mínima (abaixo) e use as chaves dele.

## S3 (armazenamento de objetos)
```
aws s3 mb s3://meu-bucket-unico-no-mundo
aws s3 cp arquivo.pdf s3://meu-bucket/pasta/arquivo.pdf
aws s3 sync ./pasta-local s3://meu-bucket/pasta/
aws s3 ls s3://meu-bucket/pasta/
```
Nome de bucket precisa ser único **globalmente** (entre todos os clientes AWS do mundo), não só na sua conta — erro
`BucketAlreadyExists` não significa que você já tem esse bucket, significa que alguém, em algum lugar, já usou esse
nome exato.

## Lambda (serverless)
```
aws lambda create-function --function-name minha-funcao \
    --runtime python3.12 --handler app.handler \
    --role arn:aws:iam::123456789012:role/minha-role-lambda \
    --zip-file fileb://funcao.zip
aws lambda invoke --function-name minha-funcao saida.json
```
A `--role` precisa já existir com a permissão certa (ver IAM abaixo) — Lambda não roda sem uma role de execução
válida, e o erro de permissão insuficiente só aparece **em runtime** (na invocação), não na criação da função.

## EC2 (máquina virtual)
```
aws ec2 run-instances --image-id ami-0abcdef1234567890 --instance-type t3.micro \
    --key-name minha-chave --security-group-ids sg-0123456789abcdef0
aws ec2 describe-instances --filters "Name=instance-state-name,Values=running"
aws ec2 stop-instances --instance-ids i-0123456789abcdef0
```
**Instância parada (`stop`) ainda gera custo de armazenamento (EBS)** — só `terminate-instances` para de cobrar
por completo. Confirme com o usuário se a intenção é pausar temporariamente (`stop`, mais caro manter) ou remover
de vez (`terminate`, apaga o disco também, geralmente irreversível).

## IAM — permissão mínima necessária
```
aws iam create-user --user-name app-leitura-s3
aws iam put-user-policy --user-name app-leitura-s3 --policy-name SoLeituraS3 --policy-document '{
  "Version": "2012-10-17",
  "Statement": [{ "Effect": "Allow", "Action": ["s3:GetObject", "s3:ListBucket"], "Resource": ["arn:aws:s3:::meu-bucket", "arn:aws:s3:::meu-bucket/*"] }]
}'
aws iam create-access-key --user-name app-leitura-s3
```
Nunca conceda `"Action": "*"`/`"Resource": "*"` (acesso total) "para simplificar" — defina exatamente as ações e
recursos necessários; é muito mais fácil ampliar depois do que descobrir um vazamento de dados causado por
permissão ampla demais.

## Regras
- Nunca use as credenciais da conta root para uso diário/automação — sempre um usuário IAM com permissão mínima.
- EC2/RDS e outros recursos com custo por hora: sempre confirme com o usuário o tipo de instância antes de criar, e
  lembre que **parar não é o mesmo que terminar** em termos de custo.
- Chaves de acesso (`Access Key ID`/`Secret Access Key`): nunca em código versionado — variável de ambiente,
  arquivo de credenciais (`~/.aws/credentials`, já fora do projeto por padrão) ou um cofre de segredos.

## Arquivos desta skill
Nenhum script fixo — os comandos acima cobrem os casos mais comuns; adapte ao serviço/conta reais do usuário.

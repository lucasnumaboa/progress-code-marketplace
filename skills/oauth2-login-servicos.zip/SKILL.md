---
name: oauth2-login-servicos
description: Implementa os fluxos OAuth2 (authorization code, client credentials, device code), renovação de token e armazenamento seguro de tokens no Windows Credential Manager. Use quando o usuário pedir para "fazer login OAuth2 nessa API", "renovar o token que expirou", "guardar esse token com segurança", "autenticar aplicação sem interação do usuário".
argument-hint: [serviço/API] [tipo de fluxo, se souber]
---

# OAuth2 e login em serviços

## Qual fluxo usar
- **Authorization Code** (com navegador): há um usuário humano fazendo login interativamente (ex.: "conectar minha
  conta do Google"). É o mais comum para integrações onde a ação é feita "em nome de uma pessoa".
- **Client Credentials**: aplicação para aplicação, sem usuário humano envolvido (ex.: um serviço automatizado
  chamando uma API do próprio backend da empresa). Mais simples — troca `client_id`/`client_secret` direto por
  token, sem navegador.
- **Device Code**: dispositivo sem navegador acessível fácil (terminal, CLI) — mostra um código para o usuário
  digitar em `https://.../device` de outro aparelho. Útil para scripts de linha de comando.

## Client Credentials (mais simples, sem usuário)
```python
import requests

resp = requests.post(token_url, data={
    "grant_type": "client_credentials",
    "client_id": client_id,
    "client_secret": client_secret,
    "scope": "escopo.necessario",
})
token = resp.json()["access_token"]
expira_em = resp.json()["expires_in"]  # segundos - agende renovar ANTES de expirar, nao depois
```

## Authorization Code (com navegador, para login de usuário)
1. Redirecione o usuário para `authorize_url` com `client_id`, `redirect_uri`, `scope`, `state` (valor aleatório
   para conferir contra CSRF) e `response_type=code`.
2. O serviço redireciona de volta para `redirect_uri` com um `code` na query string.
3. Troque o `code` por tokens:
```python
resp = requests.post(token_url, data={
    "grant_type": "authorization_code",
    "code": code,
    "redirect_uri": redirect_uri,
    "client_id": client_id,
    "client_secret": client_secret,
})
tokens = resp.json()  # access_token, refresh_token, expires_in
```
Guarde o `refresh_token` — ele é o que permite renovar sem o usuário logar de novo.

## Device Code (CLI/terminal)
```python
resp = requests.post(device_code_url, data={"client_id": client_id, "scope": scope})
dados = resp.json()
print(f"Acesse {dados['verification_uri']} e digite o código: {dados['user_code']}")
# depois, faca polling no token_url com grant_type=device_code ate o usuario confirmar
```

## Renovar token (todos os fluxos com refresh_token)
```python
resp = requests.post(token_url, data={
    "grant_type": "refresh_token",
    "refresh_token": refresh_token,
    "client_id": client_id,
    "client_secret": client_secret,
})
```
Renove **antes** de expirar (ex.: quando faltar menos de 5 minutos), não só depois de receber `401` — evita falhar
a chamada real por causa de token vencido.

## Armazenar tokens com segurança no Windows
Nunca grave `refresh_token`/`client_secret` em texto puro num arquivo do projeto. Use o Gerenciador de Credenciais
do Windows via `keyring` (pip):
```python
import keyring
keyring.set_password("minha-integracao", "refresh_token", refresh_token)
token_salvo = keyring.get_password("minha-integracao", "refresh_token")
```

## Regras
- Nunca coloque `client_secret` em código versionado no Git — variável de ambiente ou Credential Manager.
- Sempre valide o parâmetro `state` no retorno do Authorization Code antes de trocar o `code` por token — sem essa
  checagem, a aplicação fica vulnerável a CSRF no login.
- Trate token expirado como caso esperado (renovar automaticamente), não como erro fatal que precisa de
  intervenção manual toda vez.

## Arquivos desta skill
Nenhum script fixo — os trechos acima cobrem os três fluxos; adapte às URLs/parâmetros reais do serviço do usuário.

---
name: transformar-json-yaml-xml
description: Filtra, reestrutura, valida e converte entre JSON, YAML e XML usando bibliotecas Python puras (json, PyYAML, lxml/xmltodict) — sem depender de instalar jq/yq/xmllint como programa externo. Use quando o usuário pedir para "extrair esse campo do JSON", "converter YAML para JSON", "validar esse XML contra o schema", "reestruturar essa resposta de API".
argument-hint: [arquivo] [operação]
---

# Transformar JSON/YAML/XML (sem instalar jq/yq/xmllint)

## Por que Python puro em vez de jq/yq/xmllint
`jq`, `yq` e `xmllint` são ótimos, mas são **programas externos** que não vêm instalados por padrão no Windows —
precisam de `winget`/`choco`. Tudo que essas ferramentas fazem também dá para fazer com bibliotecas Python
(`json` já embutido, `PyYAML`/`lxml` via pip), sem depender de instalar nada além de pacotes Python. Só proponha
`jq`/`yq` se o usuário já os tiver instalados e pedir explicitamente a sintaxe deles.

## Passo 1 — Instalar (quando precisar de YAML/XML)
```
pip install pyyaml lxml xmltodict
```
JSON não precisa de instalação (`json` é da biblioteca padrão).

## Passo 2 — Filtrar/reestruturar JSON
```python
import json

with open("dados.json", encoding="utf-8") as f:
    dados = json.load(f)

# equivalente a um filtro jq '.items[] | select(.ativo) | .nome'
nomes_ativos = [item["nome"] for item in dados["items"] if item.get("ativo")]
```
Para JSON aninhado muito profundo, escreva uma função recursiva pequena em vez de tentar uma expressão só — mais
fácil de revisar e depurar do que replicar sintaxe de `jq` complexa em uma linha.

## Passo 3 — YAML
```python
import yaml

with open("config.yaml", encoding="utf-8") as f:
    dados = yaml.safe_load(f)  # SEMPRE safe_load, nunca yaml.load (yaml.load executa codigo arbitrario com tags !!python/object)

with open("saida.yaml", "w", encoding="utf-8") as f:
    yaml.safe_dump(dados, f, allow_unicode=True, sort_keys=False)
```
`sort_keys=False` preserva a ordem original das chaves (o padrão do PyYAML reordena alfabeticamente, o que
bagunça arquivos de configuração feitos para humanos lerem em uma ordem lógica).

## Passo 4 — XML
```python
import xmltodict

with open("dados.xml", encoding="utf-8") as f:
    dados = xmltodict.parse(f.read())  # vira dict aninhado, facil de navegar como JSON
```
Para manipulação estrutural mais fina (namespaces, XPath) use `lxml`:
```python
from lxml import etree
arvore = etree.parse("dados.xml")
for no in arvore.xpath("//item[@ativo='true']"):
    print(no.get("nome"))
```

## Passo 5 — Validar XML contra XSD (sem xmllint)
```python
from lxml import etree

schema = etree.XMLSchema(etree.parse("schema.xsd"))
doc = etree.parse("dados.xml")
if not schema.validate(doc):
    for erro in schema.error_log:
        print(erro)
```

## Regras
- `yaml.load` sem `Loader=yaml.SafeLoader` (ou `safe_load`) é uma vulnerabilidade real — pode desserializar e
  executar objetos Python arbitrários de um YAML malicioso. Nunca use `yaml.load` puro.
- Ao converter XML→JSON com `xmltodict`, atenção a elementos repetidos: se só houver **um**, ele vira um dict; se
  houver **mais de um**, vira uma lista — código que assume sempre-lista quebra silenciosamente com um único item.
  Normalize com `dados = dados if isinstance(dados, list) else [dados]` antes de iterar.
- Sempre valide que o arquivo de saída é sintaticamente válido (recarregando com o próprio parser) antes de
  entregar como pronto.

## Arquivos desta skill
Nenhum script fixo — os trechos acima cobrem os casos mais comuns; adapte à estrutura real dos dados do usuário.

# Origem e licença

Esta skill é uma cópia, com as alterações listadas abaixo, de material de especialista com licença aberta.

- **Fonte:** https://github.com/phuryn/pm-skills
- **Arquivos de origem:** `pm-execution/skills/pre-mortem/SKILL.md`
- **Autor:** Paweł Huryn (The Product Compass)
- **Licença:** MIT (texto completo em `LICENSE`)
- **Commit:** `9af7bfd0bc47fdad43c2eaa7a43cd13918e7aaef` (baixado em 2026-11-22)

## Alterações feitas

- `name:` do frontmatter trocado de `pre-mortem` para `ph-pre-mortem`.
- Fora isso, o texto do especialista está como no original (em inglês).

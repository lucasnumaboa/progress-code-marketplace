/*------------------------------------------------------------------------
    compila.p -- skill po-ui-backend-local.
    Compila os programas do projeto com o framework simulado no PROPATH.

    -param "<lista.txt>|<relatorio.json>": cada linha da lista traz
    "<fonte>|<pasta onde gravar o .r>". O relatorio sai em JSON.
------------------------------------------------------------------------*/
USING Progress.Json.ObjectModel.*.

DEFINE VARIABLE cLista   AS CHARACTER  NO-UNDO.
DEFINE VARIABLE cRelat   AS CHARACTER  NO-UNDO.
DEFINE VARIABLE cLinha   AS CHARACTER  NO-UNDO.
DEFINE VARIABLE cFonte   AS CHARACTER  NO-UNDO.
DEFINE VARIABLE cDestino AS CHARACTER  NO-UNDO.
DEFINE VARIABLE i        AS INTEGER    NO-UNDO.
DEFINE VARIABLE aRelat   AS JsonArray  NO-UNDO.
DEFINE VARIABLE aMsgs    AS JsonArray  NO-UNDO.
DEFINE VARIABLE oItem    AS JsonObject NO-UNDO.

ASSIGN cLista = ENTRY(1, SESSION:PARAMETER, "|")
       cRelat = ENTRY(2, SESSION:PARAMETER, "|")
       aRelat = NEW JsonArray().
IF OS-GETENV("API_LOCAL_PROPATH") <> ? AND OS-GETENV("API_LOCAL_PROPATH") <> "" THEN
    PROPATH = OS-GETENV("API_LOCAL_PROPATH") + "," + PROPATH.

INPUT FROM VALUE(cLista).
REPEAT:
    IMPORT UNFORMATTED cLinha.
    IF TRIM(cLinha) = "" THEN NEXT.
    ASSIGN cFonte   = ENTRY(1, cLinha, "|")
           cDestino = ENTRY(2, cLinha, "|")
           aMsgs    = NEW JsonArray()
           oItem    = NEW JsonObject().
    COMPILE VALUE(cFonte) SAVE INTO VALUE(cDestino) NO-ERROR.
    DO i = 1 TO COMPILER:NUM-MESSAGES:
        aMsgs:Add(COMPILER:GET-MESSAGE(i)
                  + (IF COMPILER:GET-ROW(i) > 0 THEN " (linha " + STRING(COMPILER:GET-ROW(i)) + ")" ELSE "")
                  + (IF COMPILER:GET-FILE-NAME(i) <> ? AND COMPILER:GET-FILE-NAME(i) <> ""
                     THEN " [" + COMPILER:GET-FILE-NAME(i) + "]" ELSE "")).
    END.
    IF aMsgs:Length = 0 THEN
        DO i = 1 TO ERROR-STATUS:NUM-MESSAGES:
            aMsgs:Add(ERROR-STATUS:GET-MESSAGE(i)).
        END.
    oItem:Add("arquivo", cFonte).
    oItem:Add("ok", NOT COMPILER:ERROR).
    oItem:Add("mensagens", aMsgs).
    aRelat:Add(oItem).
END.
INPUT CLOSE.

aRelat:WriteFile(cRelat, TRUE, "UTF-8").
QUIT.

/*------------------------------------------------------------------------
    utp/ut-api-notfound.i -- SIMULADOR LOCAL (skill po-ui-backend-local).
    NAO e' o include da TOTVS.

    No Datasul ele cria a resposta "Method not found" para chamada sem
    rota. Aqui essa resposta sai do ut-api.i, entao este include fica
    vazio de proposito: ele existe para o programa compilar igual.
------------------------------------------------------------------------*/

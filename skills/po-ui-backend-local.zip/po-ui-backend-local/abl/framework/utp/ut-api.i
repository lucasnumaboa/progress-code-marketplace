/*------------------------------------------------------------------------
    utp/ut-api.i -- SIMULADOR LOCAL do framework de API do Datasul
    (skill po-ui-backend-local). NAO e' o include da TOTVS.

    Serve so' para compilar e rodar, na maquina local, os programas da
    pasta esp/api/v1 escritos para o Datasul. No Datasul (PASOE) o include
    real faz este papel: nunca copie a pasta "framework" para la'.

    Contrato simulado (o mesmo usado pelo codigo de producao):
      - as rotas sao declaradas com utp/ut-api-action.i (procedure,
        verbo e padrao de rota);
      - cada procedure recebe INPUT JsonObject e devolve OUTPUT JsonObject;
      - a temp-table RowErrors e' o erro estruturado padrao do Datasul.
------------------------------------------------------------------------*/
USING Progress.Json.ObjectModel.*.
USING com.totvs.framework.api.*.

DEFINE TEMP-TABLE RowErrors NO-UNDO
    FIELD ErrorSequence    AS INTEGER
    FIELD ErrorNumber      AS INTEGER
    FIELD ErrorDescription AS CHARACTER
    FIELD ErrorParameters  AS CHARACTER
    FIELD ErrorType        AS CHARACTER
    FIELD ErrorHelp        AS CHARACTER
    FIELD ErrorSubType     AS CHARACTER.

/* rotas declaradas pelo programa, na ordem em que aparecem no fonte */
DEFINE TEMP-TABLE ttApiLocalRota NO-UNDO
    FIELD iOrdem     AS INTEGER
    FIELD cVerbo     AS CHARACTER
    FIELD cPadrao    AS CHARACTER CASE-SENSITIVE
    FIELD cProcedure AS CHARACTER
    INDEX idxOrdem IS PRIMARY iOrdem.

DEFINE VARIABLE iApiLocalOrdem AS INTEGER NO-UNDO.

FUNCTION fnApiLocalCasaRota RETURNS LOGICAL (pcPadrao AS CHARACTER, pcRota AS CHARACTER):
    /* Padroes aceitos: so' a barra (a raiz), "/x" (exato), barra seguida de
       asterisco (qualquer rota, inclusive a raiz), "/x" seguido de barra e
       asterisco ("/x" e tudo abaixo dele) e asterisco no meio do trecho.
       Diferencia maiusculas de minusculas, como uma URL. */
    DEFINE VARIABLE cPadrao AS CHARACTER CASE-SENSITIVE NO-UNDO.
    DEFINE VARIABLE cRota   AS CHARACTER CASE-SENSITIVE NO-UNDO.
    DEFINE VARIABLE cBase   AS CHARACTER CASE-SENSITIVE NO-UNDO.

    ASSIGN cPadrao = TRIM(pcPadrao)
           cRota   = TRIM(pcRota).
    IF cPadrao = "" THEN cPadrao = "/".
    IF cRota   = "" THEN cRota   = "/".
    IF cRota <> "/" THEN cRota = RIGHT-TRIM(cRota, "/").

    IF LENGTH(cPadrao) >= 2 AND SUBSTRING(cPadrao, LENGTH(cPadrao) - 1) = "/*" THEN DO:
        cBase = SUBSTRING(cPadrao, 1, LENGTH(cPadrao) - 2).
        IF cBase = "" OR cRota = cBase THEN RETURN TRUE.
    END.
    RETURN cRota MATCHES REPLACE(cPadrao, ".", "~~.").
END FUNCTION.

PROCEDURE piApiLocalExecuta:
    /* chamada pelo runner.p da API local: acha a rota e roda a procedure dela */
    DEFINE INPUT  PARAMETER pcVerbo  AS CHARACTER  NO-UNDO.
    DEFINE INPUT  PARAMETER pcRota   AS CHARACTER  NO-UNDO.
    DEFINE INPUT  PARAMETER poInput  AS JsonObject NO-UNDO.
    DEFINE OUTPUT PARAMETER poOutput AS JsonObject NO-UNDO.

    FOR EACH ttApiLocalRota WHERE ttApiLocalRota.cVerbo = pcVerbo BY ttApiLocalRota.iOrdem:
        IF fnApiLocalCasaRota(ttApiLocalRota.cPadrao, pcRota) THEN DO:
            RUN VALUE(ttApiLocalRota.cProcedure) IN THIS-PROCEDURE (INPUT poInput, OUTPUT poOutput).
            RETURN.
        END.
    END.

    poOutput = NEW JsonObject().
    poOutput:Add("code", "404").
    poOutput:Add("message", "Method not found: " + pcVerbo + " " + pcRota).
    poOutput:Add("detailedMessage", "Nenhuma rota declarada com ut-api-action.i neste programa casa com a chamada.").
    poOutput:Add("_httpStatus", 404).
END PROCEDURE.

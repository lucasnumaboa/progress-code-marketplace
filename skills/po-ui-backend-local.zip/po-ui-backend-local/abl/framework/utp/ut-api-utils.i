/*------------------------------------------------------------------------
    utp/ut-api-utils.i -- SIMULADOR LOCAL (skill po-ui-backend-local).
    NAO e' o include da TOTVS.

    parseInputParameters tem a assinatura usada em codigo de producao:
    entrada, headers, pathParams, queryParams, startRow, pageSize,
    fieldList, expandables e payload.
------------------------------------------------------------------------*/
PROCEDURE parseInputParameters:
    DEFINE INPUT  PARAMETER poInput       AS Progress.Json.ObjectModel.JsonObject NO-UNDO.
    DEFINE OUTPUT PARAMETER poHeaders     AS Progress.Json.ObjectModel.JsonObject NO-UNDO.
    DEFINE OUTPUT PARAMETER poPathParams  AS Progress.Json.ObjectModel.JsonArray  NO-UNDO.
    DEFINE OUTPUT PARAMETER poQueryParams AS Progress.Json.ObjectModel.JsonObject NO-UNDO.
    DEFINE OUTPUT PARAMETER piStartRow    AS INTEGER   NO-UNDO.
    DEFINE OUTPUT PARAMETER piPageSize    AS INTEGER   NO-UNDO.
    DEFINE OUTPUT PARAMETER pcFieldList   AS CHARACTER NO-UNDO.
    DEFINE OUTPUT PARAMETER pcExpandables AS CHARACTER NO-UNDO.
    DEFINE OUTPUT PARAMETER plcPayload    AS LONGCHAR  NO-UNDO.

    IF poInput = ? THEN RETURN.
    IF poInput:Has("headers") THEN
        poHeaders = poInput:GetJsonObject("headers").
    IF poInput:Has("pathParams") THEN
        poPathParams = poInput:GetJsonArray("pathParams").
    IF poInput:Has("queryParams") THEN
        poQueryParams = poInput:GetJsonObject("queryParams").
    IF poInput:Has("startRow") THEN
        piStartRow = poInput:GetInteger("startRow").
    IF poInput:Has("pageSize") THEN
        piPageSize = poInput:GetInteger("pageSize").
    IF poInput:Has("fields") THEN
        pcFieldList = poInput:GetCharacter("fields").
    IF poInput:Has("expandables") THEN
        pcExpandables = poInput:GetCharacter("expandables").
    IF poInput:Has("payload") THEN DO:
        CASE poInput:GetType("payload"):
            WHEN Progress.Json.ObjectModel.JsonDataType:OBJECT THEN
                poInput:GetJsonObject("payload"):Write(INPUT-OUTPUT plcPayload).
            WHEN Progress.Json.ObjectModel.JsonDataType:ARRAY THEN
                poInput:GetJsonArray("payload"):Write(INPUT-OUTPUT plcPayload).
            WHEN Progress.Json.ObjectModel.JsonDataType:STRING THEN
                plcPayload = poInput:GetLongchar("payload").
        END CASE.
    END.
END PROCEDURE.

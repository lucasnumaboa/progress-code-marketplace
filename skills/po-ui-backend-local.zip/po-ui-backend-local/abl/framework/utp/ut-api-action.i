/*------------------------------------------------------------------------
    utp/ut-api-action.i -- SIMULADOR LOCAL (skill po-ui-backend-local).
    NAO e' o include da TOTVS; no Datasul o real faz este papel.

    Recebe tres argumentos: a procedure, o verbo HTTP e o padrao de rota.
    Aqui ele so' registra a rota; quem casa a chamada e' o ut-api.i.
------------------------------------------------------------------------*/
ASSIGN iApiLocalOrdem = iApiLocalOrdem + 1.
CREATE ttApiLocalRota.
ASSIGN ttApiLocalRota.iOrdem     = iApiLocalOrdem
       ttApiLocalRota.cVerbo     = CAPS("{2}")
       ttApiLocalRota.cPadrao    = "{3}"
       ttApiLocalRota.cProcedure = "{1}".

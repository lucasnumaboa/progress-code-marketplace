/*------------------------------------------------------------------------
    runner.p -- API local da skill po-ui-backend-local.
    Executa UMA chamada REST no programa esp/api/v1/<programa>.p.

    -param "<requisicao.json>|<resposta.json>": arquivos escritos e lidos
    pelo api-local.js. A entrada da procedure segue o formato do Datasul:
    headers, pathParams (lista), queryParams (cada valor em lista) e payload.

    Fica so' na maquina local: no Datasul quem faz este papel e' o PASOE.
------------------------------------------------------------------------*/
USING Progress.Json.ObjectModel.*.

DEFINE VARIABLE cArqReq   AS CHARACTER  NO-UNDO.
DEFINE VARIABLE cArqResp  AS CHARACTER  NO-UNDO.
DEFINE VARIABLE cPrograma AS CHARACTER  NO-UNDO.
DEFINE VARIABLE cVerbo    AS CHARACTER  NO-UNDO.
DEFINE VARIABLE cRota     AS CHARACTER  NO-UNDO.
DEFINE VARIABLE cErro     AS CHARACTER  NO-UNDO.
DEFINE VARIABLE iStatus   AS INTEGER    NO-UNDO INITIAL 200.
DEFINE VARIABLE i         AS INTEGER    NO-UNDO.
DEFINE VARIABLE lRodou    AS LOGICAL    NO-UNDO.
DEFINE VARIABLE hApi      AS HANDLE     NO-UNDO.
DEFINE VARIABLE oReq      AS JsonObject NO-UNDO.
DEFINE VARIABLE oInput    AS JsonObject NO-UNDO.
DEFINE VARIABLE oOutput   AS JsonObject NO-UNDO.
DEFINE VARIABLE oCorpo    AS JsonObject NO-UNDO.
DEFINE VARIABLE oResp     AS JsonObject NO-UNDO.
DEFINE VARIABLE oQuery    AS JsonObject NO-UNDO.

FUNCTION fnErro RETURNS JsonObject (piStatus AS INTEGER, pcMensagem AS CHARACTER,
                                    pcDetalhe AS CHARACTER):
    DEFINE VARIABLE oErro AS JsonObject NO-UNDO.
    oErro = NEW JsonObject().
    oErro:Add("code", STRING(piStatus)).
    oErro:Add("message", pcMensagem).
    oErro:Add("detailedMessage", pcDetalhe).
    RETURN oErro.
END FUNCTION.

FUNCTION fnPrimeiro RETURNS CHARACTER (poQuery AS JsonObject, pcNome AS CHARACTER):
    IF NOT poQuery:Has(pcNome) THEN RETURN ?.
    IF poQuery:GetType(pcNome) = JsonDataType:ARRAY THEN
        RETURN poQuery:GetJsonArray(pcNome):GetCharacter(1).
    RETURN poQuery:GetCharacter(pcNome).
END FUNCTION.

ASSIGN cArqReq  = ENTRY(1, SESSION:PARAMETER, "|")
       cArqResp = ENTRY(2, SESSION:PARAMETER, "|").
IF OS-GETENV("API_LOCAL_PROPATH") <> ? AND OS-GETENV("API_LOCAL_PROPATH") <> "" THEN
    PROPATH = OS-GETENV("API_LOCAL_PROPATH") + "," + PROPATH.

blk-exec:
DO ON ERROR UNDO, LEAVE ON STOP UNDO, LEAVE:
    oReq = CAST(NEW ObjectModelParser():ParseFile(cArqReq), JsonObject).
    ASSIGN cPrograma = oReq:GetCharacter("program")
           cVerbo    = CAPS(oReq:GetCharacter("method"))
           cRota     = oReq:GetCharacter("route").

    /* a URL so' escolhe programas de esp/api/v1, com nome simples */
    DO i = 1 TO LENGTH(cPrograma):
        IF INDEX("abcdefghijklmnopqrstuvwxyz0123456789-_", LC(SUBSTRING(cPrograma, i, 1))) = 0 THEN DO:
            ASSIGN iStatus = 400
                   oCorpo  = fnErro(400, "Nome de programa invalido: " + cPrograma, "").
            LEAVE blk-exec.
        END.
    END.
    IF cPrograma = "" OR (SEARCH("esp/api/v1/" + cPrograma + ".r") = ?
                          AND SEARCH("esp/api/v1/" + cPrograma + ".p") = ?) THEN DO:
        ASSIGN iStatus = 404
               oCorpo  = fnErro(404, "Programa nao encontrado: esp/api/v1/" + cPrograma + ".p",
                                "Confira o nome na URL e a pasta backend do projeto.").
        LEAVE blk-exec.
    END.

    oInput = NEW JsonObject().
    oInput:Add("headers", CAST(oReq:GetJsonObject("headers"):Clone(), JsonObject)).
    oInput:Add("pathParams", CAST(oReq:GetJsonArray("pathParams"):Clone(), JsonArray)).
    oQuery = CAST(oReq:GetJsonObject("queryParams"):Clone(), JsonObject).
    oInput:Add("queryParams", oQuery).
    IF oReq:Has("payload") THEN
        CASE oReq:GetType("payload"):
            WHEN JsonDataType:OBJECT THEN
                oInput:Add("payload", CAST(oReq:GetJsonObject("payload"):Clone(), JsonObject)).
            WHEN JsonDataType:ARRAY THEN
                oInput:Add("payload", CAST(oReq:GetJsonArray("payload"):Clone(), JsonArray)).
            WHEN JsonDataType:STRING THEN
                oInput:Add("payload", oReq:GetLongchar("payload")).
        END CASE.
    IF fnPrimeiro(oQuery, "pageSize") <> ? THEN
        oInput:Add("pageSize", INTEGER(fnPrimeiro(oQuery, "pageSize"))) NO-ERROR.
    IF fnPrimeiro(oQuery, "startRow") <> ? THEN
        oInput:Add("startRow", INTEGER(fnPrimeiro(oQuery, "startRow"))) NO-ERROR.
    IF fnPrimeiro(oQuery, "fields") <> ? THEN
        oInput:Add("fields", fnPrimeiro(oQuery, "fields")).
    IF fnPrimeiro(oQuery, "expand") <> ? THEN
        oInput:Add("expandables", fnPrimeiro(oQuery, "expand")).

    RUN VALUE("esp/api/v1/" + cPrograma + ".p") PERSISTENT SET hApi.
    RUN piApiLocalExecuta IN hApi (INPUT cVerbo, INPUT cRota, INPUT oInput, OUTPUT oOutput).
    lRodou = TRUE.

    CATCH oErr AS Progress.Lang.Error:
        cErro = "".
        DO i = 1 TO oErr:NumMessages:
            cErro = cErro + (IF cErro = "" THEN "" ELSE " | ") + oErr:GetMessage(i).
        END.
        ASSIGN iStatus = 500
               oCorpo  = fnErro(500, (IF oErr:NumMessages > 0 THEN oErr:GetMessage(1)
                                      ELSE "Erro ao executar o programa"), cErro).
    END CATCH.
END.

IF lRodou THEN DO:
    oCorpo = (IF oOutput = ? THEN NEW JsonObject() ELSE oOutput).
    IF oCorpo:Has("_httpStatus") THEN DO:
        iStatus = oCorpo:GetInteger("_httpStatus").
        oCorpo:Remove("_httpStatus").
    END.
END.
ELSE IF oCorpo = ? THEN DO:
    /* STOP (programa que nao compila, include faltando...) nao chega no CATCH */
    cErro = "".
    DO i = 1 TO ERROR-STATUS:NUM-MESSAGES:
        cErro = cErro + (IF cErro = "" THEN "" ELSE " | ") + ERROR-STATUS:GET-MESSAGE(i).
    END.
    ASSIGN iStatus = 500
           oCorpo  = fnErro(500, "O programa parou antes de responder (erro de compilacao ou execucao).",
                            (IF cErro <> "" THEN cErro ELSE "Veja backend-local\logs\api-local.log.")).
END.

IF VALID-HANDLE(hApi) THEN DELETE PROCEDURE hApi NO-ERROR.

oResp = NEW JsonObject().
oResp:Add("status", iStatus).
oResp:Add("body", oCorpo).
oResp:WriteFile(cArqResp, FALSE, "UTF-8").
QUIT.

/*------------------------------------------------------------------------
    carrega-df.p -- skill po-ui-backend-local.
    Carrega um .df no banco conectado (monousuario). -param "<arquivo.df>".
    Os erros, se houver, o proprio load_df grava num arquivo .e.
------------------------------------------------------------------------*/
DEFINE VARIABLE cDf AS CHARACTER NO-UNDO.

cDf = SESSION:PARAMETER.
RUN prodict/load_df.p (INPUT cDf).
PUT UNFORMATTED "load_df terminou: " cDf SKIP.
QUIT.

# Levar o programa para o Datasul (PASOE)

O que vai para o cliente e so o que e do projeto: os programas `esp/...` e o front. Nada da pasta
`backend-local` vai junto.

## Backend

1. **Copie so os programas do projeto** (a pasta `esp\api\v1` e o que mais o programa usar, como o
   `*Rules.p`) para a pasta de fontes do Datasul que esta no PROPATH do PASOE, mantendo o caminho
   `esp\api\v1\<programa>.p`.
2. **Nao copie** `backend-local\runtime\framework` (`utp\ut-api*.i` e `com\totvs\framework\api`).
   La o framework e o da TOTVS; o simulado por cima dele quebraria as APIs do produto.
3. **Compile no ambiente do cliente**, com os bancos do Datasul conectados. O `.r` gerado localmente
   foi compilado contra o framework simulado e contra os bancos locais: nao serve para o servidor.
4. **Cadastre o servico REST**, se o ambiente exigir. No codigo de producao do pacote-base, o
   cabecalho do handler registra o cadastro em Administracao > Servicos REST > Programas, com Nome
   (`importaTituloAcr`), Programa, Versao (`v1`) e Modulo (`esp`). Confirme com o administrador do
   Datasul como e no cliente.
5. **Confirme o endereco**. O pacote-base chama `/api/esp/v1/<programa>` no PASOE. As APIs do
   proprio produto usam `/dts/datasul-rest/resources/prg/<modulo>/v1/<programa>`. Qual vale depende
   da instalacao; se for o segundo, o caminho do service no front muda.

## Front

- Em producao o `environment.ts` usa o endereco da propria pagina: a tela precisa ser publicada no
  mesmo servidor e porta que respondem a API.
- Gere o build e o `.war` e publique no Tomcat como nos Passos 31 a 33 do procedimento do
  treinamento (`ng build --base-href=/html-<nome>/`, `jar -cvf`, pasta `webapps`).
- O `proxy.conf.json` e so do `ng serve`: nao vai para o servidor.

## Antes de publicar

- As rotas estao como no codigo de producao (`/~*`)?
- O programa usa so os metodos do framework listados em `framework-simulado.md`?
- Testou numa base de homologacao do cliente, com usuario e dados reais?

# Problemas comuns

| Sintoma | Causa provavel | O que fazer |
|---|---|---|
| `nao achei o Progress OpenEdge` | OpenEdge nao instalado, ou em pasta fora do padrao | Instale o OpenEdge 12, ou defina a variavel `DLC` com a pasta da instalacao |
| `o servidor de banco nao subiu` na checagem | Licenca sem banco multiusuario | Use uma licenca com RDBMS (a de desenvolvimento costuma ter o Personal RDBMS) |
| `a porta 38600 ja esta em uso` | Outro projeto ou programa na porta | `--porta-api <outra>`; para os bancos, `--porta-banco <outra>` |
| Windows pergunta se libera o `_mprosrv` no firewall | Primeira vez que o Progress abre uma porta | Pode permitir so em redes privadas: o banco atende so `localhost` |
| `a carga do .df falhou` | `.df` de outra versao do OpenEdge, codepage diferente ou campo com tipo que nao existe | Veja o arquivo `.e` mostrado na mensagem; exporte o `.df` de novo pelo Dicionario de Dados |
| Compilacao: `Unknown Field or Variable` / tabela desconhecida | Falta tabela ou campo no `.df` | Exporte o `.df` com a tabela; rode de novo com `--recriar` |
| Compilacao: include nao encontrado (`utp/ut-glob.i`...) | Include do Datasul, nao do framework de API | `--propath-extra` com a pasta de fontes do cliente |
| Chamada responde 404 `Programa nao encontrado` | Nome errado na URL, ou o `.p` nao esta em `esp\api\v1` | A URL e `/api/esp/v1/<nome do arquivo sem .p>` |
| Chamada responde 404 `Method not found: GET /...` | Nenhuma rota do `ut-api-action.i` casa com a chamada | Veja o verbo e o padrao; para a raiz use `GET /~*` |
| Chamada responde 500 | Erro no programa | A mensagem do Progress vem no `detailedMessage` e em `backend-local\logs\api-local.log` |
| Tela: `Nao foi possivel consultar` / erro de rede | API parada, ou `ng serve` sem o proxy | `backend-local\status.bat`; suba a tela com `ng serve --proxy-config proxy.conf.json` |
| Tela chama o endereco antigo (porta 31003, sandbox) | `apiUrl` de desenvolvimento com endereco fixo | Deixe `apiUrl: '/'` no `environment.development.ts` |
| Cada chamada demora 1 a 2 segundos | Normal: cada chamada abre um Progress novo | Para medir desempenho, teste no PASOE |
| `parar.bat` nao derruba o banco | Alguma sessao ainda conectada | Feche o `ng serve`/API e rode `parar.bat` de novo |
| `o caminho do projeto tem N caracteres` | O Windows e o Progress nao abrem arquivos com mais de 260 caracteres de caminho | Use uma pasta de projeto com ate 160 caracteres (ex.: `C:\OpenEdge\TOTVS\PO-UI\<projeto>`) |
| Aviso de que o banco ficou em `%LOCALAPPDATA%\pbl\...` | O servidor de banco do Progress nao sobe com o `.db` a mais de ~200 caracteres de profundidade | Funciona normal; para o banco ficar no projeto, use uma pasta mais curta. O arquivo `backend-local\db\ONDE-ESTA-O-BANCO-*.txt` diz onde ele esta |
| Aviso sobre `~` no caminho | Nome curto do Windows (ex.: `LUCASD~1`); no `.pf` o `~` e escape | A skill ja converte para o caminho longo; se o nome da pasta tiver `~` de verdade, renomeie |
| 500 com `Unconvertable character ... (12009)` | O corpo da chamada tem caractere que nao existe no ISO8859-1 da sessao Progress (emoji, alguns simbolos) | Troque o caractere. O Datasul costuma ter a mesma limitacao, entao vale tratar no front |

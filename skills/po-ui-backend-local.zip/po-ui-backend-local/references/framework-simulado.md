# Framework simulado: o que existe e como se comporta

O framework de API do Datasul (includes `utp/ut-api*.i` e classes `com.totvs.framework.api`) vem
criptografado e so roda dentro do Datasul. A skill traz uma versao propria, com o mesmo contrato,
para compilar e rodar os programas na maquina local. Ela foi montada a partir do que o codigo de
producao usa: o handler real do pacote-base (`importaTituloAcr.p`) compila contra ela sem nenhum
ajuste.

## Includes

| Include | O que faz aqui |
|---|---|
| `utp/ut-api.i` | `USING` de `Progress.Json.ObjectModel.*` e `com.totvs.framework.api.*`, temp-table `RowErrors` (padrao Datasul) e o despacho das rotas |
| `utp/ut-api-action.i <procedure> <VERBO> <rota>` | Registra uma rota. A ordem do fonte vale: a primeira que casar atende |
| `utp/ut-api-notfound.i` | Vazio. Rota nao encontrada responde 404 `Method not found: <VERBO> <rota>` |
| `utp/ut-api-utils.i` | `parseInputParameters` (entrada, headers, pathParams, queryParams, startRow, pageSize, fieldList, expandables, payload) |

## Classes

| Classe | Metodos |
|---|---|
| `JsonApiResponseBuilder` (tambem escrita `JsonAPIResponseBuilder`) | `ok(JsonObject)`, `ok(JsonObject, status)`, `ok(JsonArray, hasNext)`, `asError(Progress.Lang.Error)`, `asError(handle da RowErrors)`, `asWarning(JsonObject, status, handle)`, `empty()`, `empty(status)` |
| `JsonAPIRequestParser` | construtor com a entrada da procedure, `getQueryParams()` |
| `JsonAPIUtils` | `convertLongcharToJsonObject(LONGCHAR)` |

Qualquer outro metodo nao existe no simulador. Se o codigo precisar de um, confirme antes que ele
existe no framework real do Datasul do cliente; senao o programa vai compilar num lado e nao no outro.

## Como a chamada chega na procedure

`GET /api/esp/v1/esnf0001ws/contadores?empresa=1&empresa=2` roda `esp/api/v1/esnf0001ws.p` e
entrega na procedure da rota:

```
{
  "headers":     { "accept": "application/json", ... },
  "pathParams":  [ "contadores" ],
  "queryParams": { "empresa": [ "1", "2" ] },
  "payload":     { ... }                          (corpo JSON do POST/PUT, quando houver)
}
```

Quando a URL traz `pageSize`, `startRow`, `fields` ou `expand`, eles tambem aparecem no nivel de cima
(`pageSize`, `startRow`, `fields`, `expandables`), como o `parseInputParameters` espera.

## Rotas

| Padrao no fonte | Casa com |
|---|---|
| `GET /~*` | a raiz (`/api/esp/v1/<programa>`) e qualquer sub-caminho |
| `GET /empresas/~*` | `/empresas` e `/empresas/...` |
| `GET /empresas` | so `/empresas` |
| `GET /` | so a raiz |

A comparacao diferencia maiusculas, como uma URL. O `~*` do fonte chega ao include como `*`.

## Resposta

| Chamada no programa | Resposta HTTP |
|---|---|
| `ok(lista, hasNext)` | 200 `{ "items": [...], "hasNext": true/false }` |
| `ok(objeto)` / `ok(objeto, status)` | o proprio objeto, com o status pedido |
| `asError(erro)` | 500 `{ code, message, detailedMessage }` |
| `asError(RowErrors)` | 400 `{ code, message, detailedMessage, details: [...] }` |
| `asWarning(objeto, status, RowErrors)` | o objeto com `_messages` |
| `empty()` | 204 sem corpo |
| erro nao tratado no programa | 500 com a mensagem do Progress |

## O que o simulador NAO tem

- Login, SSO e seguranca de programa: toda chamada e aceita.
- Triggers e regras do produto: as tabelas vem so do `.df`, sem os programas do Datasul.
- O formato exato do envelope da rede do PASOE (cabecalhos, codigos de erro internos da TOTVS).
- Includes e programas do Datasul que nao sao do framework de API (`utp/ut-glob.i`, `btb/...`).
  Esses vem dos fontes do cliente, com `--propath-extra`.

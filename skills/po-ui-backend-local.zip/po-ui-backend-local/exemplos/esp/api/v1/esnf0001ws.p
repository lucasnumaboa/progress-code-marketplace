/* esp/api/v1/esnf0001ws.p - API da tela Consulta de Notas (treinamento PO-UI) */
BLOCK-LEVEL ON ERROR UNDO, THROW.
USING Progress.Json.ObjectModel.*.
USING com.totvs.framework.api.*.

{utp/ut-api.i}
{utp/ut-api-utils.i}
{utp/ut-api-action.i pi-listar GET /~*}
{utp/ut-api-notfound.i}

FUNCTION fnParametro RETURNS CHARACTER (poInput AS JsonObject, pcNome AS CHARACTER):
    DEFINE VARIABLE oQuery AS JsonObject NO-UNDO.
    IF NOT poInput:Has("queryParams") THEN RETURN "".
    oQuery = poInput:GetJsonObject("queryParams").
    IF NOT oQuery:Has(pcNome) THEN RETURN "".
    IF oQuery:GetType(pcNome) = JsonDataType:ARRAY THEN
        RETURN oQuery:GetJsonArray(pcNome):GetCharacter(1).
    RETURN oQuery:GetCharacter(pcNome).
END FUNCTION.

FUNCTION fnInteiro RETURNS INTEGER (pcValor AS CHARACTER, piPadrao AS INTEGER):
    DEFINE VARIABLE iValor AS INTEGER NO-UNDO.
    IF pcValor = "" THEN RETURN piPadrao.
    iValor = INTEGER(pcValor) NO-ERROR.
    IF ERROR-STATUS:ERROR OR iValor = ? THEN RETURN piPadrao.
    RETURN iValor.
END FUNCTION.

PROCEDURE pi-listar:
    /* ?emitente= filtra pelo inicio do nome; ?page= e ?pageSize= paginam no padrao TOTVS.
       pageSize=0 devolve todas as notas de uma vez. */
    DEFINE INPUT  PARAMETER oInput  AS JsonObject NO-UNDO.
    DEFINE OUTPUT PARAMETER oOutput AS JsonObject NO-UNDO.
    DEFINE VARIABLE oItens    AS JsonArray  NO-UNDO.
    DEFINE VARIABLE oNota     AS JsonObject NO-UNDO.
    DEFINE VARIABLE cEmitente AS CHARACTER  NO-UNDO.
    DEFINE VARIABLE iTamanho  AS INTEGER    NO-UNDO.
    DEFINE VARIABLE iPular    AS INTEGER    NO-UNDO.
    DEFINE VARIABLE lTemMais  AS LOGICAL    NO-UNDO.
    ASSIGN cEmitente = fnParametro(oInput, "emitente")
           iTamanho  = MAXIMUM(0, fnInteiro(fnParametro(oInput, "pageSize"), 50))
           iPular    = (MAXIMUM(1, fnInteiro(fnParametro(oInput, "page"), 1)) - 1) * iTamanho
           oItens    = NEW JsonArray().
    blk-notas:
    FOR EACH nota-fiscal
        FIELDS(nr-nota-fis nome-ab-cli dt-emis-nota vl-tot-nota dt-confirma dt-cancela)
        NO-LOCK WHERE nota-fiscal.nome-ab-cli BEGINS cEmitente:
        IF iPular > 0 THEN DO:
            iPular = iPular - 1.
            NEXT blk-notas.
        END.
        IF iTamanho > 0 AND oItens:Length = iTamanho THEN DO:
            lTemMais = TRUE. LEAVE blk-notas.
        END.
        oNota = NEW JsonObject().
        oNota:Add("nota",     nota-fiscal.nr-nota-fis).
        oNota:Add("emitente", nota-fiscal.nome-ab-cli).
        oNota:Add("emissao",  nota-fiscal.dt-emis-nota).
        oNota:Add("valor",    nota-fiscal.vl-tot-nota).
        oNota:Add("situacao", (IF nota-fiscal.dt-cancela <> ? THEN "cancelada"
                               ELSE IF nota-fiscal.dt-confirma <> ? THEN "processada"
                               ELSE "pendente")).
        oItens:Add(oNota).
    END.
    oOutput = JsonAPIResponseBuilder:ok(oItens, lTemMais).
    CATCH oErro AS Progress.Lang.Error:
        oOutput = JsonAPIResponseBuilder:asError(oErro).
    END CATCH.
END PROCEDURE.

/* esp/treinamento/cria-notas-teste.p - carga de teste do treinamento (so sandbox) */
DISABLE TRIGGERS FOR LOAD OF nota-fiscal.

DEFINE VARIABLE iCriadas AS INTEGER NO-UNDO.

PROCEDURE pi-cria-nota:
    DEFINE INPUT PARAMETER pcNota     AS CHARACTER NO-UNDO.
    DEFINE INPUT PARAMETER pcEmitente AS CHARACTER NO-UNDO.
    DEFINE INPUT PARAMETER pdEmissao  AS DATE      NO-UNDO.
    DEFINE INPUT PARAMETER pdeValor   AS DECIMAL   NO-UNDO.
    DEFINE INPUT PARAMETER pdConfirma AS DATE      NO-UNDO.
    DEFINE INPUT PARAMETER pdCancela  AS DATE      NO-UNDO.

    IF CAN-FIND(nota-fiscal WHERE nota-fiscal.cod-estabel = "1"
                              AND nota-fiscal.serie       = "TRE"
                              AND nota-fiscal.nr-nota-fis = pcNota) THEN
        RETURN.

    CREATE nota-fiscal.
    ASSIGN nota-fiscal.cod-estabel  = "1"
           nota-fiscal.serie        = "TRE"
           nota-fiscal.nr-nota-fis  = pcNota
           nota-fiscal.nome-ab-cli  = pcEmitente
           nota-fiscal.dt-emis-nota = pdEmissao
           nota-fiscal.vl-tot-nota  = pdeValor
           nota-fiscal.dt-confirma  = pdConfirma
           nota-fiscal.dt-cancela   = pdCancela.
    iCriadas = iCriadas + 1.
END PROCEDURE.

/*                 nota       emitente   emissao          valor
                   confirmacao        cancelamento                         */
RUN pi-cria-nota ("0000123", "ANDRADE", DATE(9, 2, 2026),  12850.40,
                  DATE(9, 3, 2026),  ?).
RUN pi-cria-nota ("0000124", "SOUZA",   DATE(9, 11, 2026),  3420.00,
                  ?,                 ?).
RUN pi-cria-nota ("0000125", "LIMA",    DATE(9, 18, 2026),   980.75,
                  ?,                 ?).
RUN pi-cria-nota ("0000126", "SOUZA",   DATE(9, 20, 2026),  7315.90,
                  DATE(9, 21, 2026), DATE(9, 22, 2026)).

MESSAGE "Notas criadas nesta execucao:" iCriadas.

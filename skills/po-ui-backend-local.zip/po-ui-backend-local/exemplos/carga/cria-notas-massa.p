/* cria-notas-massa.p - carga de 100 mil notas com dados aleatorios (treinamento, so sandbox)
   Grava na nota-fiscal (banco movdis) a serie MAS, notas 0000001 a 0100000, estabelecimento 1.
   Pode rodar de novo: continua a partir da ultima nota MAS que ja existe. */
DISABLE TRIGGERS FOR LOAD OF nota-fiscal.

DEFINE VARIABLE iTotal    AS INTEGER   NO-UNDO INITIAL 100000.
DEFINE VARIABLE iLote     AS INTEGER   NO-UNDO INITIAL 1000.  /* notas por transacao */
DEFINE VARIABLE iLimiteMs AS INTEGER   NO-UNDO INITIAL 0.     /* 0 = sem limite de tempo */
DEFINE VARIABLE iProx     AS INTEGER   NO-UNDO.
DEFINE VARIABLE iNoLote   AS INTEGER   NO-UNDO.
DEFINE VARIABLE iCriadas  AS INTEGER   NO-UNDO.
DEFINE VARIABLE iSituacao AS INTEGER   NO-UNDO.
DEFINE VARIABLE iSemente  AS INT64     NO-UNDO.
DEFINE VARIABLE cNomes    AS CHARACTER NO-UNDO INITIAL
    "ANDRADE,SOUZA,LIMA,OLIVEIRA,SANTOS,PEREIRA,COSTA,RODRIGUES,ALMEIDA,NASCIMENTO,CARVALHO,ARAUJO,RIBEIRO,MARTINS,ROCHA,GOMES,BARBOSA,MELO,CARDOSO,TEIXEIRA,CORREIA,MOREIRA,CAVALCANTI,DIAS,CASTRO,CAMPOS,FREITAS,PINTO,MONTEIRO,MENDES".
DEFINE BUFFER bUltima FOR nota-fiscal.

FUNCTION fnSorteia RETURNS INTEGER (piMin AS INTEGER, piMax AS INTEGER):
    /* gerador congruente linear: sequencia diferente a cada execucao */
    iSemente = (iSemente * 1103515245 + 12345) MODULO 2147483648.
    RETURN piMin + INTEGER(iSemente MODULO (piMax - piMin + 1)).
END FUNCTION.

iSemente = TIME * 1000 + ETIME.
FIND LAST bUltima NO-LOCK USE-INDEX ch-nota
    WHERE bUltima.cod-estabel = "1" AND bUltima.serie = "MAS" NO-ERROR.
iProx = (IF AVAILABLE bUltima THEN INTEGER(bUltima.nr-nota-fis) ELSE 0) + 1.
ETIME(TRUE).

blk-lotes:
DO WHILE iProx <= iTotal:
    IF iLimiteMs > 0 AND ETIME > iLimiteMs THEN LEAVE blk-lotes.
    DO TRANSACTION:
        DO iNoLote = 1 TO iLote WHILE iProx <= iTotal:
            CREATE nota-fiscal.
            ASSIGN nota-fiscal.cod-estabel  = "1"
                   nota-fiscal.serie        = "MAS"
                   nota-fiscal.nr-nota-fis  = STRING(iProx, "9999999")
                   nota-fiscal.nome-ab-cli  = ENTRY(fnSorteia(1, NUM-ENTRIES(cNomes)), cNomes)
                   nota-fiscal.dt-emis-nota = DATE(1, 1, 2025) + fnSorteia(0, 633)
                   nota-fiscal.vl-tot-nota  = fnSorteia(5000, 5000000) / 100
                   iSituacao                = fnSorteia(1, 100).
            /* 60% processada, 25% pendente, 15% cancelada (mesma regra da API esnf0001ws) */
            IF iSituacao <= 60 THEN
                nota-fiscal.dt-confirma = nota-fiscal.dt-emis-nota + fnSorteia(0, 3).
            ELSE IF iSituacao > 85 THEN
                ASSIGN nota-fiscal.dt-confirma = nota-fiscal.dt-emis-nota + fnSorteia(0, 2)
                       nota-fiscal.dt-cancela  = nota-fiscal.dt-confirma + fnSorteia(0, 5).
            ASSIGN iProx    = iProx + 1
                   iCriadas = iCriadas + 1.
        END.
    END.
END.

PUT UNFORMATTED "Notas criadas nesta execucao: " iCriadas
    " | ultima nota MAS: " STRING(iProx - 1, "9999999")
    " | " (IF iProx > iTotal THEN "carga completa" ELSE "rode de novo para continuar") SKIP.

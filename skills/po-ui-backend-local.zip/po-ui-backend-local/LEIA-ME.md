# po-ui-backend-local

Skill (Progress Code / Claude) que sobe, dentro da pasta de um projeto PO-UI, um backend Progress local: banco(s)
OpenEdge e uma API REST no mesmo formato do Datasul com PASOE (`/api/esp/v1/<programa>`). Serve para
desenvolver e testar os programas `esp/api/v1/*.p` e a tela sem sandbox e sem servidor do cliente,
e depois levar o mesmo codigo para o Datasul sem mudar nada.

## Instalar

- **No Progress Code**: Marketplace > **Backend local PO-UI** > Instalar.
- **Pelo arquivo `.skill`**: abra o arquivo no Claude e clique em **Salvar skill**.
- **No Claude Code, a mao**: extraia a pasta `po-ui-backend-local` em
  `%USERPROFILE%\.claude\skills\` (fica `...\.claude\skills\po-ui-backend-local\SKILL.md`).

Para criar o projeto a partir do pacote-base, instale tambem a skill **po-ui-creation**: esta skill
cuida so do backend.

## Precisa ter na maquina

| O que | Por que | Como conferir |
|---|---|---|
| Windows | Os scripts usam os executaveis Windows do Progress | - |
| Progress OpenEdge 12 (testado no 12.8) com licenca de banco | Cria e serve os bancos e roda os `.p` | `node scripts\configurar.js --checar` |
| Node 18 ou maior | Roda a API local e os scripts (sem npm install) | `node -v` |
| Portas 38600 (API) e 38700+ (bancos) livres | Onde a API e os bancos atendem | o `--checar` avisa; troque com `--porta-api` / `--porta-banco` |
| Pasta do projeto com ate 160 caracteres | O Windows e o Progress nao abrem arquivos com caminho acima de 260 caracteres | a skill confere e avisa |

A licenca de desenvolvimento do OpenEdge costuma incluir o Personal RDBMS, que basta. O `--checar`
cria, sobe e derruba um banco de teste para provar.

## Usar com o Progress Code (ou o Claude)

Exemplos de pedido:

- "Sobe o backend local do projeto C:\OpenEdge\TOTVS\PO-UI\esnf0001 com o exemplo da aula e 4 notas de teste."
- "Cria um projeto PO-UI em C:\projetos\esnf0003 pelo pacote-base e ja deixa a API rodando local com o
  movdis.df que esta em C:\dfs."
- "Recompila os programas do backend local e me diz o que nao compilou."

## Usar sem a IA

```
node "<pasta da skill>\scripts\configurar.js" --projeto "<pasta do projeto>" --df "<arquivo.df ou pasta>"
```

| Opcao | Para que |
|---|---|
| `--exemplo` | Tabela nota-fiscal reduzida (banco movdis) e o programa esnf0001ws.p, se o projeto nao tiver |
| `--carga teste` / `--carga massa` | Grava 4 notas ou 100 mil notas de exemplo |
| `--df <arquivo ou pasta>` | `.df` com as tabelas; um arquivo por banco, com o nome do banco (`movdis.df`) |
| `--propath-extra <pasta>` | Fontes do Datasul do cliente (includes `utp/`, programas `btb/`...) |
| `--todas-tabelas` | Carrega o `.df` inteiro, e nao so as tabelas usadas nos programas |
| `--recriar` | Apaga e recria os bancos do projeto |
| `--porta-api` / `--porta-banco` | Outras portas |
| `--sem-subir` / `--sem-front` | Nao deixa no ar / nao mexe no front |

Depois, no dia a dia, use os atalhos em `<projeto>\backend-local`: `subir.bat`, `parar.bat`,
`status.bat` e `compilar.bat`.

## O que fica no projeto

```
<projeto>\backend-local\
  api-local.config.json   portas, bancos, PROPATH
  api.pf                  conexao com os bancos
  configuracao.json       resumo da ultima configuracao (tabelas, compilacao, avisos)
  subir.bat parar.bat status.bat compilar.bat
  db\<banco>\             os bancos
  df\<banco>.df           o .df carregado (so as tabelas usadas)
  runtime\                API local, runner e framework simulado (o projeto nao depende mais da skill)
  logs\ tmp\ backup-front\
```

A skill tambem ajusta o `proxy.conf.json` do front (`/api/esp/v1` -> API local) e, no projeto do
procedimento, a `apiUrl` de desenvolvimento para `'/'`. As copias originais ficam em `backup-front`.

## Observacoes importantes

- **Nao e o Datasul.** O framework de API e simulado com o mesmo contrato do codigo de producao,
  mas nao tem login, SSO, seguranca de programa nem triggers do produto. Teste o resultado final numa
  homologacao do cliente.
- **Os `.df` sao do cliente.** Eles saem do Dicionario de Dados do ambiente dele (Admin > Dump Data
  and Definitions > Data Definitions). A skill carrega so as tabelas usadas e tira as linhas `AREA`.
  O unico `.df` que vem na skill e a nota-fiscal reduzida da aula.
- **Includes e programas do Datasul** que nao sao do framework de API (`utp/ut-glob.i`, `btb/...`)
  nao vem na skill. Aponte os fontes do cliente com `--propath-extra`, senao os programas que
  dependem deles nao compilam. O business object do pacote-base e um desses casos.
- **Velocidade**: cada chamada abre um Progress novo e leva 1 a 2 segundos. Serve para desenvolver,
  nao para medir desempenho.
- **Nunca leve `backend-local` para o servidor.** Para publicar no Datasul veja
  `references\levar-para-datasul.md`.

## Documentacao

- `SKILL.md`: passo a passo que o Claude segue.
- `references\framework-simulado.md`: o que o framework simulado tem e como a chamada chega no `.p`.
- `references\levar-para-datasul.md`: publicar no Datasul com PASOE.
- `references\problemas-comuns.md`: erros comuns e o que fazer.

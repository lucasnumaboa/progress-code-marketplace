---
name: po-ui-backend-local
description: Sobe, dentro da pasta de um projeto PO-UI, um backend Progress LOCAL - banco(s) OpenEdge criados a partir de .df e uma API REST no mesmo formato do Datasul/PASOE (/api/esp/v1/nome-do-programa) - para rodar e testar os programas esp/api/v1 sem sandbox e sem servidor do cliente. Use sempre que o usuario pedir backend local, banco local, API local, "rodar sem o sandbox", "testar o .p na minha maquina", "subir a API do projeto PO-UI" ou criar um projeto PO-UI ja com backend rodando. Para criar o projeto a partir do pacote-base, use antes a skill po-ui-creation (se instalada); esta skill cuida so do backend.
---

# po-ui-backend-local

Monta na pasta do projeto um backend que responde igual ao Datasul:

- **banco(s) OpenEdge** em `<projeto>\backend-local\db`, criados a partir de `.df`, so com as
  tabelas que os programas usam;
- **API REST** em `http://localhost:38600/api/esp/v1/<programa>`, o mesmo caminho do PASOE.
  Cada chamada roda o `esp/api/v1/<programa>.p` do projeto com um **framework simulado** que tem o
  mesmo contrato do framework de API da TOTVS (`utp/ut-api*.i`, `JsonApiResponseBuilder`...);
- **proxy do front** apontado para essa API.

O objetivo e que o mesmo `.p` e o mesmo front funcionem sem mudar uma linha quando forem para o
Datasul com PASOE. Por isso o simulador so tem o que o codigo de producao usa (lista em
`references/framework-simulado.md`). Ele nao e o Datasul: nao tem SSO, seguranca de programa nem
triggers do produto. Diga isso ao usuario quando fizer diferenca.

Os scripts ficam na pasta desta skill: e a pasta informada no topo quando a skill carrega
("Arquivos e scripts desta skill estao localizados em ..."). Nos comandos abaixo, `<skill>` e essa
pasta. Rode os comandos pela ferramenta Bash.

## Antes de comecar

Precisa de Windows, **Progress OpenEdge 12** instalado com licenca que inclua banco (a de
desenvolvimento costuma trazer o Personal RDBMS) e **Node 18+**. Confira antes de qualquer coisa:

```
node "<skill>\scripts\configurar.js" --checar
```

Ele acha o Progress (variavel DLC, registro ou `C:\Progress\OpenEdge`), cria e sobe um banco de
teste para provar a licenca e confere as portas. Se falhar, explique ao usuario o que falta e pare:
sem Progress nao ha como rodar os `.p`.

A pasta do projeto precisa ter ate 160 caracteres de caminho: o Windows e o Progress nao abrem
arquivos acima de 260, e o backend local cria pastas dentro do projeto. Se o `.db` ficaria a mais de
~190 caracteres, a skill guarda o banco em `%LOCALAPPDATA%\pbl\<id>` e avisa: o servidor de banco do
Progress nao sobe (e fica se relancando) com o banco num caminho mais longo que isso.

Nao suba o servidor de banco chamando `_mprosrv.exe` direto de um processo sem console: ele se
relanca sem parar e enche a maquina de processos. Use sempre os scripts da skill (eles usam o
`proserve.bat` e derrubam o broker se ele nao abrir a porta).

## Passo a passo

### 1. Ter o projeto

- **Projeto novo a partir do pacote-base**: use a skill `po-ui-creation`, se estiver instalada, para
  baixar e montar o projeto, e volte aqui com a pasta criada. Sem ela, peca ao usuario a pasta do
  projeto ja criado.
- **Projeto que ja existe** (ex.: o do procedimento do treinamento, com `backend\esp\api\v1`):
  use a pasta como esta.

A skill acha sozinha os programas: toda pasta que tem `esp\api\v1` vira uma raiz do PROPATH
(no pacote-base e `po-ui\backend\ems2`; no projeto do treinamento e `backend`).

### 2. Descobrir de onde vem cada tabela

Os programas leem tabelas do Datasul, e o banco local precisa delas. A skill le os `.df`, cruza
com os fontes e carrega so as tabelas que aparecem nos programas. Pergunte ao usuario de onde vem o
`.df`, se nao estiver claro:

| Situacao | O que usar |
|---|---|
| Aula / demonstracao da tela de notas | `--exemplo` (nota-fiscal reduzida no banco movdis, ja vem na skill) |
| Tabelas de um cliente | `.df` exportado pelo Dicionario de Dados do cliente (Admin > Dump Data and Definitions > Data Definitions), um arquivo por banco |
| Tabela nova, so do projeto | um `.df` escrito para ela |

**Um `.df` por banco, e o nome do arquivo e o nome do banco** (`movdis.df` vira o banco `movdis`).
Isso importa porque programas do Datasul as vezes qualificam a tabela com o banco
(`movdis.nota-fiscal`). As linhas `AREA` do `.df` sao removidas: tudo vai para a Schema Area.

### 3. Configurar

```
node "<skill>\scripts\configurar.js" --projeto "<pasta do projeto>" --df "<arquivo.df ou pasta>" [opcoes]
```

Opcoes mais usadas: `--exemplo`, `--carga teste` (4 notas) ou `--carga massa` (100 mil notas, uns
3 minutos), `--propath-extra "<fontes do Datasul do cliente>"`, `--recriar`, `--porta-api`,
`--porta-banco`. `--ajuda` lista todas.

Ele cria o banco, compila os programas com o framework simulado, sobe banco e API, ajusta o proxy
do front e deixa `subir.bat`, `parar.bat`, `status.bat` e `compilar.bat` em `backend-local`. O
projeto passa a funcionar mesmo sem a skill instalada: tudo que ele precisa fica em
`backend-local\runtime`.

Exemplo do treinamento, num projeto criado pelo procedimento:

```
node "<skill>\scripts\configurar.js" --projeto "C:\OpenEdge\TOTVS\PO-UI\esnf0001" --exemplo --carga teste
```

### 4. Ler o resultado

O resumo sai no terminal e em `backend-local\configuracao.json`. Olhe nesta ordem:

1. **includesFaltando / programasFaltando**: includes (`utp/ut-glob.i`...) ou programas (`RUN
   btb/...`) do Datasul que nao estao no projeto. Peca ao usuario a pasta com os fontes do cliente e
   rode de novo com `--propath-extra`. Sem eles, esses programas nao compilam localmente. E o caso do
   business object do pacote-base.
2. **compilacao**: erro de tabela ou campo desconhecido quer dizer que falta tabela no `.df` (ou o
   `.df` e de outra versao). Erro de sintaxe e do programa.
3. **avisos**: portas em uso, front nao encontrado etc.

Teste a API com o navegador ou `curl.exe` (ex.: `http://localhost:38600/api/esp/v1/esnf0001ws`)
antes de subir a tela. Cada chamada leva por volta de 1 a 2 segundos: cada uma abre um Progress novo.

### 5. Subir a tela

O proxy (`proxy.conf.json`) ja aponta `/api/esp/v1` para a API local, na frente de qualquer regra
mais geral como `/api`. No projeto do treinamento a `apiUrl` de desenvolvimento passa a ser `'/'`.
Copias dos arquivos originais ficam em `backend-local\backup-front`.

- Projeto do treinamento: `ng serve --proxy-config proxy.conf.json`
- Pacote-base: `npm start` (o script ja usa o proxy)

### 6. Dia a dia

`backend-local\subir.bat` sobe bancos e API; `parar.bat` para os dois; `status.bat` mostra o que
esta no ar; `compilar.bat` recompila depois de mudar um `.p`. Mudou so o codigo do `.p`? Nem
precisa recompilar: sem o `.r` o Progress compila na hora (o `.r` so deixa mais rapido).

## Para o programa funcionar tambem no PASOE

Explique ao usuario quando ele for escrever ou mudar um `.p`:

- Declare rotas como no codigo de producao: `GET /~*` para a raiz (e sub-caminhos) e
  `/recurso/~*` para sub-rotas. O simulador tambem aceita `GET /`, mas o padrao comprovado em
  producao e o `/~*`.
- Leia a entrada como o Datasul entrega: `queryParams` com cada valor em lista
  (`GetJsonArray("x"):GetCharacter(1)`), `pathParams` em lista, `payload` como objeto.
- Use do framework so o que esta em `references/framework-simulado.md`. Metodo que so existe no
  simulador compila aqui e quebra no Datasul, e o contrario tambem pode acontecer.
- Nunca leve `backend-local` nem a pasta `framework` para o Datasul: la o framework e o da TOTVS.

Para publicar, siga `references/levar-para-datasul.md`.

## Quando algo der errado

Veja `references/problemas-comuns.md`. Os logs ficam em `backend-local\logs` (`api-local.log` tem
uma linha por chamada; erro 500 traz a mensagem do Progress) e em `backend-local\db\<banco>\*.lg`.

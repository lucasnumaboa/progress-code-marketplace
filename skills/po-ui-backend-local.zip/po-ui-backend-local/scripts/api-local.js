'use strict';
/* po-ui-backend-local - API REST local no mesmo formato do Datasul (PASOE):
     http://localhost:<porta>/api/esp/v1/<programa>[/<rota>]  ->  esp/api/v1/<programa>.p
   Cada chamada roda um Progress em lote (runner.p) conectado aos bancos do projeto.
   Uso: node api-local.js <api-local.config.json> */
const fs = require('fs');
const path = require('path');
const http = require('http');
const cp = require('child_process');
const lib = require('./lib');

const cfg = lib.lerConfig(process.argv[2]);
const PREFIXO = (cfg.prefixo || '/api/esp/v1').replace(/\/+$/, '');
const LIMITE_CORPO = 50 * 1024 * 1024;
let sequencia = 0;

function responde(res, status, corpo, extraHeaders) {
  const headers = Object.assign({
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, PATCH, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': '*',
  }, extraHeaders || {});
  if (status === 204 || corpo === undefined) {
    res.writeHead(status, headers);
    res.end();
    return;
  }
  const texto = typeof corpo === 'string' ? corpo : JSON.stringify(corpo);
  headers['Content-Type'] = 'application/json; charset=utf-8';
  res.writeHead(status, headers);
  res.end(texto);
}

function erro(status, mensagem, detalhe) {
  return { code: String(status), message: mensagem, detailedMessage: detalhe || '' };
}

function executa(requisicao) {
  return new Promise((resolve) => {
    const id = process.pid + '-' + Date.now() + '-' + (++sequencia);
    const arqReq = path.join(cfg.pastaTmp, 'req-' + id + '.json');
    const arqResp = path.join(cfg.pastaTmp, 'resp-' + id + '.json');
    fs.writeFileSync(arqReq, JSON.stringify(requisicao), 'utf8');
    const args = ['-b', '-pf', cfg.pf, '-p', path.join(cfg.pastaRuntime, 'runner.p'),
                  '-param', arqReq + '|' + arqResp];
    const proc = cp.spawn(lib.exe(cfg.dlc, '_progres.exe'), args, {
      cwd: cfg.pastaTmp,
      env: lib.envProgress(cfg.dlc, { API_LOCAL_PROPATH: cfg.propath.join(',') }),
      windowsHide: true,
    });
    let saida = '';
    proc.stdout.on('data', (c) => { saida += c.toString('latin1'); });
    proc.stderr.on('data', (c) => { saida += c.toString('latin1'); });
    const relogio = setTimeout(() => { proc.kill(); }, cfg.timeoutMs || 120000);
    proc.on('close', (codigo) => {
      clearTimeout(relogio);
      let resultado = null;
      try { resultado = JSON.parse(fs.readFileSync(arqResp, 'utf8')); } catch (e) { resultado = null; }
      for (const f of [arqReq, arqResp]) { try { fs.unlinkSync(f); } catch (e) { /* ja apagado */ } }
      if (!resultado) {
        resolve({ status: 500, body: erro(500, 'O Progress terminou sem responder (codigo ' + codigo + ').',
                                           saida.trim().slice(-2000)), saida });
        return;
      }
      if (resultado.status >= 500 && saida.trim() && resultado.body && typeof resultado.body === 'object') {
        /* mensagens do Progress (ex.: erro de compilacao) ajudam a achar o problema */
        resultado.body.detailedMessage = [resultado.body.detailedMessage, saida.trim().slice(-2000)]
          .filter(Boolean).join(' | ');
      }
      resolve({ status: resultado.status, body: resultado.body, saida });
    });
  });
}

const servidor = http.createServer((req, res) => {
  const inicio = Date.now();
  const url = new URL(req.url, 'http://localhost');
  if (req.method === 'OPTIONS') { responde(res, 204); return; }
  if (url.pathname === '/api-local/status') {
    responde(res, 200, { ok: true, projeto: cfg.projeto, porta: cfg.portaApi,
                         bancos: cfg.bancos.map((b) => b.nome), prefixo: PREFIXO });
    return;
  }
  if (!(url.pathname === PREFIXO || url.pathname.startsWith(PREFIXO + '/'))) {
    responde(res, 404, erro(404, 'Caminho fora da API local: ' + url.pathname,
                            'A API local responde em ' + PREFIXO + '/<programa>.'));
    return;
  }
  const segmentos = url.pathname.slice(PREFIXO.length).split('/').filter(Boolean).map(decodeURIComponent);
  if (!segmentos.length) {
    responde(res, 404, erro(404, 'Informe o programa: ' + PREFIXO + '/<programa>'));
    return;
  }
  const programa = segmentos[0];
  const pathParams = segmentos.slice(1);
  const queryParams = {};
  for (const [k, v] of url.searchParams) {
    if (!queryParams[k]) queryParams[k] = [];
    queryParams[k].push(v);
  }
  const partes = [];
  let tamanho = 0;
  req.on('data', (c) => {
    tamanho += c.length;
    if (tamanho > LIMITE_CORPO) { req.destroy(); return; }
    partes.push(c);
  });
  req.on('end', async () => {
    const texto = Buffer.concat(partes).toString('utf8');
    const requisicao = {
      method: req.method,
      program: programa,
      route: '/' + pathParams.join('/'),
      pathParams,
      queryParams,
      headers: req.headers,
    };
    if (texto.trim()) {
      try { requisicao.payload = JSON.parse(texto); } catch (e) { requisicao.payload = texto; }
    }
    const r = await executa(requisicao);
    responde(res, r.status, r.body);
    lib.log(cfg, req.method + ' ' + req.url + ' -> ' + r.status + ' (' + (Date.now() - inicio) + ' ms)'
      + (r.status >= 500 ? ' | ' + String(r.saida || '').replace(/\s+/g, ' ').slice(0, 500) : ''));
  });
});

fs.mkdirSync(cfg.pastaTmp, { recursive: true });
servidor.on('error', (e) => {
  lib.log(cfg, 'API local nao subiu: ' + e.message);
  console.error('API local nao subiu: ' + e.message);
  process.exit(1);
});
servidor.listen(cfg.portaApi, '127.0.0.1', () => {
  lib.log(cfg, 'API local no ar em http://localhost:' + cfg.portaApi + PREFIXO);
  console.log('API local no ar em http://localhost:' + cfg.portaApi + PREFIXO);
});

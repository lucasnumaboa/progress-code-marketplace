'use strict';
/* po-ui-backend-local - liga, desliga e confere o backend local de UM projeto.
   Fica em <projeto>\backend-local\runtime e le ..\api-local.config.json.
   Uso: node controle.js subir | parar | status | reiniciar | compilar | carga <arquivo.p> */
const fs = require('fs');
const path = require('path');
const cp = require('child_process');
const lib = require('./lib');

const PASTA = path.resolve(__dirname, '..');
const ARQ_CONFIG = path.join(PASTA, 'api-local.config.json');
const ARQ_PID = path.join(PASTA, 'api-local.pid');

async function subirBancos(cfg) {
  let ok = true;
  for (const b of cfg.bancos) {
    if (await lib.portaAberta(b.porta)) { console.log('  banco ' + b.nome + ': ja estava no ar (porta ' + b.porta + ')'); continue; }
    const r = await lib.sobeBroker(cfg.dlc, path.dirname(b.arquivo), b.nome, b.porta);
    console.log('  banco ' + b.nome + ': ' + (r.ok ? 'no ar (porta ' + b.porta + ')' : 'NAO SUBIU'));
    if (!r.ok) { ok = false; console.log('    ' + r.msg); }
  }
  return ok;
}

function pararBancos(cfg) {
  for (const b of cfg.bancos) {
    const r = lib.paraBroker(cfg.dlc, path.dirname(b.arquivo), b.nome);
    console.log('  banco ' + b.nome + ': ' + (/Shutdown complete/i.test(r.saida) ? 'parado' : 'ja estava parado'));
  }
}

async function apiNoAr(cfg) {
  const r = await lib.getJson('http://127.0.0.1:' + cfg.portaApi + '/api-local/status', 2000);
  return !!(r && r.status === 200 && r.body && r.body.ok);
}

async function subirApi(cfg) {
  if (await apiNoAr(cfg)) { console.log('  API: ja estava no ar em http://localhost:' + cfg.portaApi + cfg.prefixo); return true; }
  if (await lib.portaAberta(cfg.portaApi)) {
    console.log('  API: a porta ' + cfg.portaApi + ' esta ocupada por outro programa. Troque portaApi em api-local.config.json.');
    return false;
  }
  fs.mkdirSync(cfg.pastaLogs, { recursive: true });
  const saida = fs.openSync(path.join(cfg.pastaLogs, 'api-local.out'), 'a');
  const filho = cp.spawn(process.execPath, [path.join(__dirname, 'api-local.js'), ARQ_CONFIG],
    { detached: true, stdio: ['ignore', saida, saida], windowsHide: true });
  filho.unref();
  fs.writeFileSync(ARQ_PID, String(filho.pid));
  const limite = Date.now() + 20000;
  while (Date.now() < limite) {
    if (await apiNoAr(cfg)) { console.log('  API: no ar em http://localhost:' + cfg.portaApi + cfg.prefixo + '/<programa>'); return true; }
    await new Promise((r) => setTimeout(r, 500));
  }
  console.log('  API: NAO SUBIU. Veja ' + path.join(cfg.pastaLogs, 'api-local.out'));
  return false;
}

function pararApi(cfg) {
  let pid = null;
  try { pid = parseInt(fs.readFileSync(ARQ_PID, 'utf8'), 10); } catch (e) { pid = null; }
  if (pid) {
    lib.roda('taskkill', ['/PID', String(pid), '/T', '/F']);
    try { fs.unlinkSync(ARQ_PID); } catch (e) { /* ja apagado */ }
    console.log('  API: parada');
  } else {
    console.log('  API: ja estava parada');
  }
}

async function status(cfg) {
  for (const b of cfg.bancos) {
    console.log('  banco ' + b.nome + ' (porta ' + b.porta + '): ' + ((await lib.portaAberta(b.porta)) ? 'no ar' : 'parado'));
  }
  console.log('  API (porta ' + cfg.portaApi + '): ' + ((await apiNoAr(cfg)) ? 'no ar' : 'parada'));
}

function compilar(cfg) {
  const relat = lib.compilaProgramas(cfg);
  let falhas = 0;
  for (const it of relat) {
    console.log('  ' + (it.ok ? 'ok    ' : 'ERRO  ') + it.arquivo);
    if (!it.ok) { falhas++; for (const m of it.mensagens.slice(0, 5)) console.log('        ' + m); }
  }
  return falhas === 0;
}

function carga(cfg, arquivo) {
  const r = lib.rodaAbl(cfg, path.resolve(arquivo));
  console.log(r.saida || '(sem mensagens)');
  return r.status === 0;
}

async function main() {
  const cmd = (process.argv[2] || 'status').toLowerCase();
  const cfg = lib.lerConfig(ARQ_CONFIG);
  console.log('po-ui-backend-local - ' + cfg.projeto);
  let ok = true;
  if (cmd === 'subir') {
    ok = (await subirBancos(cfg)) && (await subirApi(cfg));
  } else if (cmd === 'subir-bancos') {
    ok = await subirBancos(cfg);
  } else if (cmd === 'parar') {
    pararApi(cfg);
    pararBancos(cfg);
  } else if (cmd === 'reiniciar') {
    pararApi(cfg);
    ok = await subirApi(cfg);
  } else if (cmd === 'status') {
    await status(cfg);
  } else if (cmd === 'compilar') {
    ok = compilar(cfg);
  } else if (cmd === 'carga') {
    ok = carga(cfg, process.argv[3]);
  } else {
    console.log('Uso: node controle.js subir | subir-bancos | parar | status | reiniciar | compilar | carga <arquivo.p>');
    ok = false;
  }
  process.exitCode = ok ? 0 : 1;
}

if (require.main === module) main();
module.exports = { subirBancos, pararBancos, subirApi, pararApi, apiNoAr, status, compilar, carga };

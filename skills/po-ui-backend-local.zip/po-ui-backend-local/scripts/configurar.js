'use strict';
/* po-ui-backend-local - configura o backend local de um projeto PO-UI:
     banco(s) Progress dentro de <projeto>\backend-local\db
     + API REST no formato do Datasul em http://localhost:<porta>/api/esp/v1/<programa>
   Node puro, sem npm install. Rode "node configurar.js --ajuda" para as opcoes. */
const fs = require('fs');
const path = require('path');
const cp = require('child_process');
const lib = require('./lib');

const SKILL = path.resolve(__dirname, '..');
const PORTA_API = 38600;
const PORTA_BANCO = 38700;
const LIMITE_PROJETO = 160;   /* o arquivo mais fundo criado fica ~85 caracteres abaixo da pasta do projeto */

function ajuda() {
  console.log(`Uso: node configurar.js --projeto <pasta> [opcoes]

  --checar                  so confere o ambiente (Progress, licenca de banco, Node, portas)
  --df <arquivo ou pasta>   .df com as tabelas. Um .df por banco: o nome do arquivo vira o
                            nome do banco (movdis.df -> banco movdis). Pode repetir.
  --exemplo                 usa o exemplo do treinamento: tabela nota-fiscal reduzida (banco
                            movdis) e o programa esnf0001ws.p, se o projeto nao tiver um.
  --carga teste|massa       grava dados de exemplo na nota-fiscal (4 notas ou 100 mil notas)
  --propath-extra <pasta>   fontes do Datasul do cliente (includes utp/, programas btb/ etc.)
  --todas-tabelas           carrega todas as tabelas dos .df, e nao so as usadas nos programas
  --porta-api <n>           porta da API local (padrao ${PORTA_API})
  --porta-banco <n>         porta do primeiro banco (padrao ${PORTA_BANCO}; os outros +1, +2...)
  --recriar                 apaga e recria os bancos que ja existirem no projeto
  --sem-subir               prepara tudo, mas deixa banco e API parados
  --sem-front               nao mexe no proxy.conf.json nem no environment do front`);
}

function argumentos(argv) {
  const a = { df: [], propathExtra: [], portaApi: PORTA_API, portaBanco: PORTA_BANCO };
  for (let i = 0; i < argv.length; i++) {
    const k = argv[i];
    const v = () => { i++; if (argv[i] === undefined) throw new Error('faltou o valor de ' + k); return argv[i]; };
    if (k === '--projeto') a.projeto = path.resolve(v());
    else if (k === '--df') a.df.push(path.resolve(v()));
    else if (k === '--propath-extra') a.propathExtra.push(path.resolve(v()));
    else if (k === '--porta-api') a.portaApi = parseInt(v(), 10);
    else if (k === '--porta-banco') a.portaBanco = parseInt(v(), 10);
    else if (k === '--carga') a.carga = v();
    else if (k === '--exemplo') a.exemplo = true;
    else if (k === '--checar') a.checar = true;
    else if (k === '--todas-tabelas') a.todasTabelas = true;
    else if (k === '--recriar') a.recriar = true;
    else if (k === '--sem-subir') a.semSubir = true;
    else if (k === '--sem-front') a.semFront = true;
    else if (k === '--ajuda' || k === '-h' || k === '--help') a.ajuda = true;
    else throw new Error('opcao desconhecida: ' + k);
  }
  return a;
}

const avisos = [];
function passo(t) { console.log('\n== ' + t); }
function info(t) { console.log('   ' + t); }
function aviso(t) { avisos.push(t); console.log('   ATENCAO: ' + t); }
function para(t) { console.log('\nERRO: ' + t); process.exit(1); }

/* ------------------------------------------------------------ ambiente --- */
async function checaAmbiente(a) {
  passo('Ambiente');
  const node = parseInt(process.versions.node.split('.')[0], 10);
  info('Node ' + process.versions.node + (node >= 18 ? '' : '  <- precisa do 18 ou maior'));
  if (node < 18) para('atualize o Node (Capitulo 2 do procedimento).');
  const dlc = lib.achaDlc();
  if (!dlc) para('nao achei o Progress OpenEdge (procurei DLC, o registro e C:\\Progress\\OpenEdge). '
    + 'Instale o OpenEdge com licenca de desenvolvimento, ou defina a variavel DLC.');
  info('Progress: ' + lib.versaoDlc(dlc) + '  (' + dlc + ')');
  for (const e of ['_progres.exe', 'prodb.exe', 'proserve.bat', '_mprosrv.exe', '_mprshut.exe', 'jvmStart.exe']) {
    if (!fs.existsSync(lib.exe(dlc, e))) para('falta ' + lib.exe(dlc, e) + ' - a instalacao do OpenEdge esta incompleta.');
  }
  for (const [nome, porta] of [['API', a.portaApi], ['banco', a.portaBanco]]) {
    if (await lib.portaAberta(porta)) aviso('a porta ' + porta + ' (' + nome + ') ja esta em uso. Se nao for deste projeto, '
      + 'rode de novo com ' + (nome === 'API' ? '--porta-api' : '--porta-banco') + ' <outra>.');
  }
  return dlc;
}

/* cria um banco de teste, sobe e derruba: prova que a licenca tem banco multiusuario */
async function checaLicenca(dlc, pastaTmp, porta) {
  const dir = path.join(pastaTmp, 'checa-licenca');
  fs.rmSync(dir, { recursive: true, force: true });
  fs.mkdirSync(dir, { recursive: true });
  const env = lib.envProgress(dlc);
  const c = lib.roda(lib.exe(dlc, 'prodb.exe'), ['teste', 'empty'], { cwd: dir, env });
  if (!fs.existsSync(path.join(dir, 'teste.db'))) return 'prodb falhou: ' + c.saida.slice(-400);
  const s = await lib.sobeBroker(dlc, dir, 'teste', porta);
  lib.paraBroker(dlc, dir, 'teste');
  await lib.esperaPorta(porta, false, 15000);
  fs.rmSync(dir, { recursive: true, force: true });
  return s.ok ? null : 'o servidor de banco nao subiu: ' + s.msg;
}

/* ---------------------------------------------------------------- .df --- */
function listaDfs(a) {
  const dfs = [];
  for (const d of a.df) {
    if (!fs.existsSync(d)) para('nao achei ' + d);
    if (fs.statSync(d).isDirectory()) {
      for (const f of fs.readdirSync(d)) if (/\.df$/i.test(f)) dfs.push(path.join(d, f));
    } else dfs.push(d);
  }
  if (a.exemplo) dfs.push(path.join(SKILL, 'exemplos', 'df', 'movdis.df'));
  const vistos = new Map();
  for (const f of dfs) {
    const nome = path.basename(f, path.extname(f)).toLowerCase();
    if (!/^[a-z][a-z0-9_-]*$/.test(nome)) para('nome de banco invalido vindo do arquivo ' + f + ' (use letras, numeros, - e _).');
    if (vistos.has(nome)) para('dois .df para o mesmo banco "' + nome + '": ' + vistos.get(nome) + ' e ' + f);
    vistos.set(nome, f);
  }
  return [...vistos.entries()].map(([nome, arquivo]) => ({ nome, arquivo }));
}

/* ---------------------------------------------------------------- front --- */
function ajustaFront(projeto, portaApi, pastaBackup) {
  const alterados = [];
  const angulares = lib.listaArquivos(projeto, /^angular\.json$/, 3).map((f) => path.dirname(f));
  for (const dir of angulares) {
    const guarda = (arq) => {
      const copia = path.join(pastaBackup, path.relative(projeto, arq));
      if (!fs.existsSync(copia) && fs.existsSync(arq)) {
        fs.mkdirSync(path.dirname(copia), { recursive: true });
        fs.copyFileSync(arq, copia);
      }
    };
    /* proxy: /api/esp/v1 vai para a API local, antes de qualquer entrada mais geral (/api) */
    const arqProxy = path.join(dir, 'proxy.conf.json');
    let proxy = {};
    if (fs.existsSync(arqProxy)) {
      try { proxy = JSON.parse(fs.readFileSync(arqProxy, 'utf8')); } catch (e) { aviso(arqProxy + ' nao e JSON valido; nao mexi nele.'); continue; }
    }
    guarda(arqProxy);
    const novo = { '/api/esp/v1': { target: 'http://localhost:' + portaApi, changeOrigin: true, secure: false } };
    for (const [k, v] of Object.entries(proxy)) if (k !== '/api/esp/v1') novo[k] = v;
    fs.writeFileSync(arqProxy, JSON.stringify(novo, null, 2) + '\n');
    alterados.push(arqProxy);
    /* projeto do procedimento (Parte 1): a apiUrl de desenvolvimento precisa ser '/' para usar o proxy */
    const arqEnv = path.join(dir, 'src', 'environments', 'environment.development.ts');
    if (fs.existsSync(arqEnv)) {
      const t = fs.readFileSync(arqEnv, 'utf8');
      const t2 = t.replace(/apiUrl\s*:\s*'https?:\/\/[^']*'/, "apiUrl: '/'");
      if (t2 !== t) { guarda(arqEnv); fs.writeFileSync(arqEnv, t2); alterados.push(arqEnv); }
    }
  }
  return { angulares, alterados };
}

/* ---------------------------------------------------------------- main --- */
async function main() {
  let a;
  try { a = argumentos(process.argv.slice(2)); } catch (e) { console.log(e.message); ajuda(); process.exit(1); }
  if (a.ajuda || (!a.projeto && !a.checar)) { ajuda(); return; }

  const dlc = await checaAmbiente(a);
  const pastaTmpChecagem = path.join(fs.realpathSync.native(require('os').tmpdir()), 'po-ui-backend-local');
  fs.mkdirSync(pastaTmpChecagem, { recursive: true });
  passo('Licenca do banco (cria, sobe e derruba um banco de teste)');
  const portaTeste = a.portaBanco + 90;
  const probLicenca = await checaLicenca(dlc, pastaTmpChecagem, portaTeste);
  if (probLicenca) para('o Progress desta maquina nao conseguiu servir um banco: ' + probLicenca
    + '\nA licenca precisa incluir banco de dados (a de desenvolvimento normalmente inclui o Personal RDBMS).');
  info('ok');
  if (a.checar && !a.projeto) { console.log('\nAmbiente pronto para o po-ui-backend-local.'); return; }

  if (!fs.existsSync(a.projeto)) para('a pasta do projeto nao existe: ' + a.projeto);
  /* caminho longo de verdade: nome curto do Windows (LUCASD~1) quebra o .pf, onde ~ e' escape */
  const projeto = fs.realpathSync.native(a.projeto);
  a.df = a.df.map((f) => (fs.existsSync(f) ? fs.realpathSync.native(f) : f));
  a.propathExtra = a.propathExtra.map((f) => (fs.existsSync(f) ? fs.realpathSync.native(f) : f));
  if (projeto.includes('~')) aviso('o caminho do projeto tem "~", que o Progress le como escape nos arquivos .pf. '
    + 'Se a conexao com o banco falhar, use uma pasta sem "~".');
  if (projeto.length > LIMITE_PROJETO) para('o caminho do projeto tem ' + projeto.length + ' caracteres. O Windows e o '
    + 'Progress nao abrem arquivos com mais de 260 caracteres de caminho, e o backend local cria pastas dentro do '
    + 'projeto. Use uma pasta de projeto com ate ' + LIMITE_PROJETO + ' caracteres (ex.: C:\\OpenEdge\\TOTVS\\PO-UI\\<projeto>).');
  const base = path.join(projeto, 'backend-local');
  const cfg = {
    versao: 1,
    projeto,
    dlc,
    portaApi: a.portaApi,
    prefixo: '/api/esp/v1',
    timeoutMs: 120000,
    pastaBase: base,
    pastaRuntime: path.join(base, 'runtime'),
    pastaTmp: path.join(base, 'tmp'),
    pastaLogs: path.join(base, 'logs'),
    pf: path.join(base, 'api.pf'),
    raizes: [],
    propath: [],
    bancos: [],
  };
  for (const p of [cfg.pastaBase, cfg.pastaRuntime, cfg.pastaTmp, cfg.pastaLogs]) fs.mkdirSync(p, { recursive: true });

  passo('Programas do backend (pastas com esp\\api\\v1)');
  cfg.raizes = lib.achaRaizesBackend(projeto);
  if (!cfg.raizes.length && a.exemplo) {
    const raiz = path.join(projeto, 'backend');
    fs.mkdirSync(path.join(raiz, 'esp', 'api', 'v1'), { recursive: true });
    fs.copyFileSync(path.join(SKILL, 'exemplos', 'esp', 'api', 'v1', 'esnf0001ws.p'),
                    path.join(raiz, 'esp', 'api', 'v1', 'esnf0001ws.p'));
    info('o projeto nao tinha backend: copiei o exemplo para ' + path.join(raiz, 'esp', 'api', 'v1', 'esnf0001ws.p'));
    cfg.raizes = [raiz];
  }
  if (!cfg.raizes.length) para('nao achei nenhuma pasta esp\\api\\v1 dentro de ' + projeto
    + '. Os programas da API ficam em <raiz>\\esp\\api\\v1\\<programa>.p (use --exemplo para o do treinamento).');
  const programasApi = [];
  for (const r of cfg.raizes) {
    for (const f of lib.listaArquivos(path.join(r, 'esp', 'api', 'v1'), /\.p$/i, 0)) programasApi.push(f);
    info(r);
  }
  info(programasApi.length + ' programa(s) em esp\\api\\v1: ' + programasApi.map((f) => path.basename(f, '.p')).join(', '));

  /* runtime do projeto: o projeto passa a funcionar sem a skill instalada */
  lib.copiaPasta(path.join(SKILL, 'abl', 'framework'), path.join(cfg.pastaRuntime, 'framework'));
  for (const f of ['runner.p', 'compila.p', 'carrega-df.p']) fs.copyFileSync(path.join(SKILL, 'abl', f), path.join(cfg.pastaRuntime, f));
  for (const f of ['lib.js', 'api-local.js', 'controle.js']) fs.copyFileSync(path.join(SKILL, 'scripts', f), path.join(cfg.pastaRuntime, f));
  cfg.propath = [path.join(cfg.pastaRuntime, 'framework'), ...cfg.raizes, ...a.propathExtra];

  passo('O que os programas usam');
  const fontes = [];
  for (const r of cfg.raizes) fontes.push(...lib.listaArquivos(r, lib.EXT_FONTES));
  const analise = lib.analisaFontes(fontes);
  const incFaltando = [...analise.includes.keys()].filter((inc) => !lib.achaNoPropath(inc, cfg.propath)).sort();
  const runFaltando = [...analise.runs.keys()].filter((p) => !lib.achaNoPropath(p, cfg.propath)).sort();
  info(fontes.length + ' fonte(s) lidos');
  if (incFaltando.length) aviso('includes que nao estao no projeto nem no framework simulado: ' + incFaltando.join(', ')
    + '. Sao do Datasul do cliente: aponte a pasta com --propath-extra, ou os programas que usam nao vao compilar.');
  if (runFaltando.length) aviso('programas chamados com RUN que nao estao no projeto: ' + runFaltando.join(', ')
    + '. Se forem do Datasul, aponte a pasta com --propath-extra; se nao, a rota que chama vai falhar.');

  passo('Bancos');
  const dfs = listaDfs(a);
  if (!dfs.length) para('nenhum .df informado. Use --df <arquivo.df> (um por banco) ou --exemplo. '
    + 'O .df sai do Dicionario de Dados do cliente (Admin > Dump Data and Definitions > Data Definitions).');
  const pastaDf = path.join(base, 'df');
  fs.mkdirSync(pastaDf, { recursive: true });
  let porta = a.portaBanco;
  const tabelasPorBanco = {};
  for (const d of dfs) {
    const df = lib.lerDf(d.arquivo);
    const todas = lib.tabelasDoDf(df);
    const usadas = a.todasTabelas ? todas : todas.filter((t) => analise.tokens.has(t.toLowerCase()));
    const seqs = lib.sequenciasDoDf(df).filter((s) => a.todasTabelas || analise.tokens.has(s.toLowerCase()));
    if (!usadas.length && !seqs.length) { info(d.nome + ': nenhuma tabela deste .df aparece nos programas - banco nao criado'); continue; }
    tabelasPorBanco[d.nome] = usadas;
    const arqDf = path.join(pastaDf, d.nome + '.df');
    lib.gravaDfReduzido(df, usadas, seqs, arqDf);
    const onde = lib.pastaDoBanco(path.join(base, 'db'), projeto, d.nome);
    const dirDb = onde.pasta;
    const arqDb = path.join(dirDb, d.nome + '.db');
    if (onde.curta) {
      aviso('o caminho do projeto e longo demais para o servidor de banco do Progress (passa de '
        + lib.LIMITE_CAMINHO_BANCO + ' caracteres ate o .db). O banco ' + d.nome + ' fica em ' + dirDb
        + '. Para ele ficar dentro do projeto, use uma pasta de projeto com caminho mais curto.');
      fs.mkdirSync(path.join(base, 'db'), { recursive: true });
      fs.writeFileSync(path.join(base, 'db', 'ONDE-ESTA-O-BANCO-' + d.nome + '.txt'),
        'O caminho deste projeto e longo demais para o servidor de banco do Progress.\r\n'
        + 'O banco ' + d.nome + ' esta em:\r\n' + dirDb + '\r\n', 'latin1');
    }
    const banco = { nome: d.nome, arquivo: arqDb, porta, df: arqDf, tabelas: usadas };
    porta++;
    cfg.bancos.push(banco);
    info(d.nome + ': ' + usadas.length + ' tabela(s) de ' + todas.length + ' do .df -> ' + usadas.join(', '));
    if (fs.existsSync(arqDb) && !a.recriar) { info('   banco ja existe, mantido (use --recriar para refazer)'); continue; }
    if (await lib.portaAberta(banco.porta)) lib.paraBroker(dlc, dirDb, d.nome);
    await lib.esperaPorta(banco.porta, false, 15000);
    fs.rmSync(dirDb, { recursive: true, force: true });
    fs.mkdirSync(dirDb, { recursive: true });
    const c = lib.roda(lib.exe(dlc, 'prodb.exe'), [d.nome, 'empty'], { cwd: dirDb, env: lib.envProgress(dlc) });
    if (!fs.existsSync(arqDb)) para('prodb nao criou ' + arqDb + ': ' + c.saida.slice(-500));
    const l = lib.roda(lib.exe(dlc, '_progres.exe'), ['-b', '-db', d.nome, '-1', '-p', path.join(cfg.pastaRuntime, 'carrega-df.p'), '-param', arqDf],
      { cwd: dirDb, env: lib.envProgress(dlc) });
    const errosDf = [arqDf.replace(/\.df$/i, '.e'), path.join(dirDb, d.nome + '.e')].filter((f) => fs.existsSync(f));
    if (errosDf.length || !/load_df terminou/.test(l.saida)) {
      para('a carga do .df de ' + d.nome + ' falhou.\n' + l.saida.slice(-800) + '\n'
        + errosDf.map((f) => fs.readFileSync(f, 'latin1').slice(0, 1500)).join('\n'));
    }
    info('   banco criado em ' + dirDb);
  }
  if (!cfg.bancos.length) para('nenhum banco foi criado: nenhuma tabela dos .df informados aparece nos programas.');

  /* conexao da API e da compilacao com os bancos */
  const pf = ['# gerado pelo po-ui-backend-local: conexao com os bancos deste projeto'];
  for (const b of cfg.bancos) pf.push('-db "' + b.arquivo + '" -ld ' + b.nome + ' -S ' + b.porta + ' -H localhost');
  pf.push('-T "' + cfg.pastaTmp + '"');
  fs.writeFileSync(cfg.pf, pf.join('\r\n') + '\r\n', 'latin1');
  fs.writeFileSync(path.join(base, 'api-local.config.json'), JSON.stringify(cfg, null, 2) + '\n');

  const controle = path.join(cfg.pastaRuntime, 'controle.js');
  const rodaControle = (...args) => cp.spawnSync(process.execPath, [controle, ...args], { stdio: 'inherit' }).status === 0;

  passo('Subindo os bancos');
  if (!rodaControle('subir-bancos')) para('os bancos nao subiram (veja as mensagens acima).');

  passo('Compilando os programas com o framework simulado');
  const relat = lib.compilaProgramas(cfg);
  let falhas = 0;
  for (const it of relat) {
    info((it.ok ? 'ok    ' : 'ERRO  ') + (/^\(/.test(it.arquivo) ? it.arquivo : path.relative(projeto, it.arquivo)));
    if (!it.ok) { falhas++; for (const m of it.mensagens.slice(0, 4)) info('        ' + m); }
  }
  if (falhas) aviso(falhas + ' programa(s) nao compilaram. As rotas deles vao responder erro 500 ate isso ser resolvido.');

  if (a.carga) {
    passo('Carga de dados de exemplo');
    const arq = { teste: 'cria-notas-teste.p', massa: 'cria-notas-massa.p' }[a.carga];
    if (!arq) para('--carga aceita teste ou massa');
    if (!cfg.bancos.some((b) => b.tabelas.map((t) => t.toLowerCase()).includes('nota-fiscal'))) {
      aviso('a carga de exemplo grava na nota-fiscal, que nao esta nos bancos deste projeto; pulei.');
    } else {
      const pastaCarga = path.join(base, 'carga');
      fs.mkdirSync(pastaCarga, { recursive: true });
      fs.copyFileSync(path.join(SKILL, 'exemplos', 'carga', arq), path.join(pastaCarga, arq));
      const r = lib.rodaAbl(cfg, path.join(pastaCarga, arq));
      if (/\*\*|Unable to|error \d+|\(\d{2,}\)/i.test(r.saida)) aviso('a carga mostrou erro: ' + r.saida.slice(-600));
      else info(r.saida || '(sem mensagens)');
    }
  }

  let front = { angulares: [], alterados: [] };
  if (!a.semFront) {
    passo('Front (proxy do ng serve)');
    front = ajustaFront(projeto, cfg.portaApi, path.join(base, 'backup-front'));
    if (!front.angulares.length) aviso('nao achei angular.json no projeto: ajuste o proxy do front a mao (veja o LEIA-ME da skill).');
    for (const f of front.alterados) info('ajustado: ' + path.relative(projeto, f));
  }

  /* atalhos para o dia a dia */
  const bat = (nome, cmd, desc) => fs.writeFileSync(path.join(base, nome),
    '@echo off\r\nREM ' + desc + ' (po-ui-backend-local)\r\nnode "%~dp0runtime\\controle.js" ' + cmd + '\r\nif "%~1"=="" pause\r\n', 'latin1');
  bat('subir.bat', 'subir', 'Sobe os bancos e a API local deste projeto');
  bat('parar.bat', 'parar', 'Para a API local e os bancos deste projeto');
  bat('status.bat', 'status', 'Mostra se os bancos e a API local estao no ar');
  bat('compilar.bat', 'compilar', 'Recompila os programas esp/api/v1 com o framework simulado');

  if (!a.semSubir) {
    passo('Subindo a API local');
    if (!rodaControle('subir')) aviso('a API local nao subiu: veja backend-local\\logs\\api-local.out');
  } else {
    rodaControle('parar');
  }

  const resumo = {
    projeto, api: 'http://localhost:' + cfg.portaApi + cfg.prefixo + '/<programa>',
    bancos: cfg.bancos.map((b) => ({ nome: b.nome, porta: b.porta, tabelas: b.tabelas })),
    programas: programasApi.map((f) => path.basename(f, '.p')),
    compilacao: relat.map((r) => ({ arquivo: /^\(/.test(r.arquivo) ? r.arquivo : path.relative(projeto, r.arquivo),
                                    ok: r.ok, mensagens: r.mensagens.slice(0, 5) })),
    includesFaltando: incFaltando, programasFaltando: runFaltando,
    frontAjustado: front.alterados.map((f) => path.relative(projeto, f)),
    avisos,
  };
  fs.writeFileSync(path.join(base, 'configuracao.json'), JSON.stringify(resumo, null, 2) + '\n');

  console.log('\n==========================================================================');
  console.log(' Backend local pronto: ' + resumo.api);
  for (const p of resumo.programas) console.log('   http://localhost:' + cfg.portaApi + cfg.prefixo + '/' + p);
  console.log(' Dia a dia: ' + path.join(base, 'subir.bat') + ' / parar.bat / status.bat');
  if (front.alterados.length) console.log(' Front: suba com o proxy (npm start no pacote-base, ou ng serve --proxy-config proxy.conf.json)');
  if (avisos.length) console.log(' ' + avisos.length + ' aviso(s) acima - resumo em ' + path.join(base, 'configuracao.json'));
  console.log('==========================================================================');
}

main().catch((e) => { console.log('\nERRO inesperado: ' + (e && e.stack || e)); process.exit(1); });

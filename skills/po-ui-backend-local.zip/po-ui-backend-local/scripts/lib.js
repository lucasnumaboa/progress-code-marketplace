'use strict';
/* po-ui-backend-local - funcoes comuns (Node puro, sem npm install).
   Usado pelo configurar.js (na skill) e pelo controle.js e api-local.js (copiados
   para <projeto>\backend-local\runtime). */
const fs = require('fs');
const path = require('path');
const net = require('net');
const http = require('http');
const cp = require('child_process');

const PASTAS_IGNORADAS = new Set(['node_modules', '.angular', 'dist', '.git', 'backend-local', '.vscode']);
const EXT_FONTES = /\.(p|w|i|i\d+|cls|t)$/i;

/* ------------------------------------------------------------ Progress --- */
function achaDlc() {
  const candidatos = [];
  if (process.env.DLC) candidatos.push(process.env.DLC);
  try {
    const saida = cp.execFileSync('reg', ['query', 'HKLM\\SOFTWARE\\PSC\\PROGRESS', '/s', '/v', 'DLC'],
      { encoding: 'latin1', stdio: ['ignore', 'pipe', 'ignore'], windowsHide: true });
    for (const ln of saida.split(/\r?\n/)) {
      const m = ln.match(/^\s+DLC\s+REG_\w+\s+(.+?)\s*$/);
      if (m) candidatos.push(m[1]);
    }
  } catch (e) { /* sem registro: tenta as pastas comuns */ }
  candidatos.push('C:\\Progress\\OpenEdge', 'C:\\OpenEdge', 'C:\\Progress\\OpenEdge128',
                  'C:\\Progress\\OpenEdge122', 'C:\\dlc');
  for (const c of candidatos) {
    if (c && fs.existsSync(path.join(c, 'bin', '_progres.exe'))) return path.resolve(c);
  }
  return null;
}

function versaoDlc(dlc) {
  try { return fs.readFileSync(path.join(dlc, 'version'), 'latin1').trim(); } catch (e) { return '?'; }
}

function exe(dlc, nome) { return path.join(dlc, 'bin', nome); }

function envProgress(dlc, extra) {
  return Object.assign({}, process.env, { DLC: dlc }, extra || {});
}

function roda(programa, args, opcoes) {
  const r = cp.spawnSync(programa, args, Object.assign(
    { encoding: 'latin1', windowsHide: true, maxBuffer: 64 * 1024 * 1024 }, opcoes || {}));
  return { status: r.status, saida: ((r.stdout || '') + (r.stderr || '')).trim(), erro: r.error };
}

/* sobe o servidor do banco pelo proserve.bat oficial: ele usa o jvmStart, que desliga o broker
   da sessao de quem chamou. Nao chame o _mprosrv.exe direto de um processo sem console: ele se
   relanca sem parar. A saida vai para arquivo (em pipe o broker herdaria o pipe e o comando nao
   voltaria). */
async function sobeBroker(dlc, pastaBanco, nome, porta) {
  const log = path.join(pastaBanco, 'broker.out');
  try { fs.unlinkSync(log); } catch (e) { /* primeira vez */ }
  const saida = fs.openSync(log, 'a');
  cp.spawnSync('cmd.exe', ['/d', '/c', 'call', exe(dlc, 'proserve.bat'), nome, '-S', String(porta),
                           '-H', 'localhost', '-ServerType', '4GL'],
    { cwd: pastaBanco, env: envProgress(dlc), stdio: ['ignore', saida, saida], windowsHide: true, timeout: 120000 });
  fs.closeSync(saida);
  const ok = await esperaPorta(porta, true, 45000);
  let msg = '';
  if (!ok) {
    /* broker que nao abre a porta pode ficar se relancando: derruba tudo desta porta */
    limpaBrokers(porta);
    try { msg = fs.readFileSync(log, 'latin1').split(/\r?\n/).filter(Boolean).slice(-6).join(' | '); } catch (e) { msg = ''; }
  }
  return { ok, msg };
}

/* derruba os _mprosrv que atendem esta porta (so' os do projeto: cada banco tem porta propria) */
function limpaBrokers(porta) {
  const filtro = "Get-CimInstance Win32_Process -Filter \"Name='_mprosrv.exe'\" | Where-Object { $_.CommandLine -match '-S "
    + String(porta) + "( |$)' }";
  for (let i = 0; i < 10; i++) {
    const r = cp.spawnSync('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command',
      '$p = @(' + filtro + '); $p | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }; $p.Count'],
      { encoding: 'utf8', windowsHide: true });
    if (parseInt((r.stdout || '0').trim(), 10) === 0) return;
    cp.spawnSync('powershell.exe', ['-NoProfile', '-Command', 'Start-Sleep -Milliseconds 800'], { windowsHide: true });
  }
}

/* O servidor de banco do Progress nao sobe (e entra em laco) quando o caminho do .db passa de
   uns 200 caracteres. Nesses casos o banco fica numa pasta curta, fora do projeto. */
const LIMITE_CAMINHO_BANCO = 190;

function pastaDoBanco(pastaProjetoDb, projeto, nome) {
  const noProjeto = path.join(pastaProjetoDb, nome);
  if (path.join(noProjeto, nome + '.db').length <= LIMITE_CAMINHO_BANCO) return { pasta: noProjeto, curta: false };
  const id = require('crypto').createHash('md5').update(projeto.toLowerCase()).digest('hex').slice(0, 8);
  const raiz = process.env.LOCALAPPDATA || require('os').tmpdir();
  return { pasta: path.join(raiz, 'pbl', id, nome), curta: true };
}

function paraBroker(dlc, pastaBanco, nome) {
  return roda(exe(dlc, '_mprshut.exe'), [nome, '-by'], { cwd: pastaBanco, env: envProgress(dlc) });
}

/* roda um .p em lote (-b) com os parametros de conexao do projeto */
function rodaAbl(cfg, programa, parametro, opcoes) {
  const args = ['-b'];
  if (cfg.pf && fs.existsSync(cfg.pf)) args.push('-pf', cfg.pf);
  args.push('-p', programa);
  if (parametro !== undefined) args.push('-param', parametro);
  return roda(exe(cfg.dlc, '_progres.exe'), args, Object.assign({
    cwd: cfg.pastaTmp || process.cwd(),
    env: envProgress(cfg.dlc, { API_LOCAL_PROPATH: (cfg.propath || []).join(',') }),
  }, opcoes || {}));
}

/* --------------------------------------------------------------- rede ---- */
function portaAberta(porta, ms) {
  return new Promise((resolve) => {
    const s = net.connect({ port: porta, host: '127.0.0.1' });
    const fim = (ok) => { s.destroy(); resolve(ok); };
    s.setTimeout(ms || 800, () => fim(false));
    s.once('connect', () => fim(true));
    s.once('error', () => fim(false));
  });
}

async function esperaPorta(porta, aberta, ms) {
  const limite = Date.now() + (ms || 60000);
  while (Date.now() < limite) {
    if ((await portaAberta(porta)) === aberta) return true;
    await new Promise((r) => setTimeout(r, 700));
  }
  return false;
}

function getJson(url, ms) {
  return new Promise((resolve) => {
    const req = http.get(url, { timeout: ms || 5000 }, (res) => {
      let dados = '';
      res.setEncoding('utf8');
      res.on('data', (c) => { dados += c; });
      res.on('end', () => {
        let corpo = null;
        try { corpo = JSON.parse(dados); } catch (e) { corpo = dados; }
        resolve({ status: res.statusCode, body: corpo });
      });
    });
    req.on('timeout', () => { req.destroy(); resolve(null); });
    req.on('error', () => resolve(null));
  });
}

/* ------------------------------------------------------------- arquivos -- */
function listaArquivos(raiz, filtro, profundidade) {
  const limite = profundidade === undefined ? 12 : profundidade;
  const saida = [];
  const anda = (dir, nivel) => {
    let itens = [];
    try { itens = fs.readdirSync(dir, { withFileTypes: true }); } catch (e) { return; }
    for (const it of itens) {
      const p = path.join(dir, it.name);
      if (it.isDirectory()) {
        if (!PASTAS_IGNORADAS.has(it.name) && nivel < limite) anda(p, nivel + 1);
      } else if (!filtro || filtro.test(it.name)) {
        saida.push(p);
      }
    }
  };
  anda(raiz, 0);
  return saida;
}

/* pastas que contem esp\api\v1 viram raizes de PROPATH (o programa e' esp/api/v1/<nome>.p) */
function achaRaizesBackend(projeto) {
  const raizes = [];
  const anda = (dir, nivel) => {
    if (nivel > 7) return;
    let itens = [];
    try { itens = fs.readdirSync(dir, { withFileTypes: true }); } catch (e) { return; }
    for (const it of itens) {
      if (!it.isDirectory() || PASTAS_IGNORADAS.has(it.name)) continue;
      const p = path.join(dir, it.name);
      if (it.name.toLowerCase() === 'esp' && fs.existsSync(path.join(p, 'api', 'v1'))) raizes.push(dir);
      else anda(p, nivel + 1);
    }
  };
  anda(projeto, 0);
  return [...new Set(raizes)];
}

function copiaPasta(origem, destino) {
  fs.mkdirSync(destino, { recursive: true });
  for (const it of fs.readdirSync(origem, { withFileTypes: true })) {
    const o = path.join(origem, it.name);
    const d = path.join(destino, it.name);
    if (it.isDirectory()) copiaPasta(o, d);
    else fs.copyFileSync(o, d);
  }
}

/* ------------------------------------------------ leitura dos fontes ABL --- */
/* tira comentarios (que podem ser aninhados) e comentarios de linha, sem mexer em strings */
function semComentarios(texto) {
  let out = '';
  let i = 0;
  let prof = 0;
  let aspas = null;
  while (i < texto.length) {
    const c = texto[i];
    const d = texto[i + 1];
    if (prof > 0) {
      if (c === '/' && d === '*') { prof++; i += 2; continue; }
      if (c === '*' && d === '/') { prof--; i += 2; if (prof === 0) out += ' '; continue; }
      i++; continue;
    }
    if (aspas) {
      out += c;
      if (c === '~' && d !== undefined) { out += d; i += 2; continue; }
      if (c === aspas) aspas = null;
      i++; continue;
    }
    if (c === '"' || c === "'") { aspas = c; out += c; i++; continue; }
    if (c === '/' && d === '*') { prof = 1; i += 2; continue; }
    if (c === '/' && d === '/') { while (i < texto.length && texto[i] !== '\n') i++; continue; }
    out += c; i++;
  }
  return out;
}

function analisaFontes(arquivos) {
  const tokens = new Set();
  const includes = new Map();
  const runs = new Map();
  for (const arq of arquivos) {
    let texto;
    try { texto = semComentarios(fs.readFileSync(arq, 'latin1')); } catch (e) { continue; }
    for (const m of texto.matchAll(/[A-Za-z_][A-Za-z0-9_#$%&-]*/g)) tokens.add(m[0].toLowerCase());
    for (const m of texto.matchAll(/\{\s*([A-Za-z0-9_\/\\.-]+\.[A-Za-z0-9]+)/g)) {
      const inc = m[1].replace(/\\/g, '/');
      if (!includes.has(inc)) includes.set(inc, new Set());
      includes.get(inc).add(arq);
    }
    for (const m of texto.matchAll(/\bRUN\s+([A-Za-z0-9_\/\\.-]+\.(?:p|r|w))\b/gi)) {
      const prog = m[1].replace(/\\/g, '/');
      if (!runs.has(prog)) runs.set(prog, new Set());
      runs.get(prog).add(arq);
    }
  }
  return { tokens, includes, runs };
}

function achaNoPropath(relativo, propath) {
  for (const dir of propath) {
    if (fs.existsSync(path.join(dir, relativo))) return true;
    /* .p pedido e so' o .r existe (ou o contrario) */
    const alt = relativo.replace(/\.p$/i, '.r');
    if (alt !== relativo && fs.existsSync(path.join(dir, alt))) return true;
  }
  return false;
}

/* ------------------------------------------------------------------ .df --- */
function lerDf(arquivo) {
  const texto = fs.readFileSync(arquivo).toString('latin1');
  const m = texto.match(/\r?\nPSC\r?\ncpstream=([^\r\n]+)/);
  const codepage = m ? m[1].trim() : null;
  const fimCorpo = texto.search(/\r?\n\.\r?\nPSC\r?\n/);
  const corpo = fimCorpo >= 0 ? texto.slice(0, fimCorpo) : texto;
  const blocos = [];
  let atual = null;
  for (const ln of corpo.split(/\r?\n/)) {
    if (/^(ADD|UPDATE|DROP|RENAME) /.test(ln)) {
      atual = { cabecalho: ln, linhas: [ln] };
      blocos.push(atual);
    } else if (atual) {
      atual.linhas.push(ln);
    }
  }
  for (const b of blocos) {
    let r;
    if ((r = b.cabecalho.match(/^ADD TABLE "([^"]+)"/))) { b.tipo = 'tabela'; b.tabela = r[1]; }
    else if ((r = b.cabecalho.match(/^ADD FIELD "[^"]+" OF "([^"]+)"/))) { b.tipo = 'campo'; b.tabela = r[1]; }
    else if ((r = b.cabecalho.match(/^ADD INDEX "[^"]+" ON "([^"]+)"/))) { b.tipo = 'indice'; b.tabela = r[1]; }
    else if ((r = b.cabecalho.match(/^ADD SEQUENCE "([^"]+)"/))) { b.tipo = 'sequencia'; b.sequencia = r[1]; }
    else b.tipo = 'outro';
  }
  return { arquivo, codepage, blocos };
}

function tabelasDoDf(df) {
  return [...new Set(df.blocos.filter((b) => b.tipo === 'tabela').map((b) => b.tabela))];
}

function sequenciasDoDf(df) {
  return [...new Set(df.blocos.filter((b) => b.tipo === 'sequencia').map((b) => b.sequencia))];
}

/* grava so' as tabelas/sequencias pedidas, sem AREA (tudo vai para a Schema Area) */
function gravaDfReduzido(df, tabelas, sequencias, destino) {
  const querT = new Set([...tabelas].map((t) => t.toLowerCase()));
  const querS = new Set([...sequencias].map((s) => s.toLowerCase()));
  const saida = [];
  for (const b of df.blocos) {
    const quer = (b.tabela && querT.has(b.tabela.toLowerCase()))
      || (b.sequencia && querS.has(b.sequencia.toLowerCase()));
    if (!quer) continue;
    const linhas = b.linhas.filter((ln) => !/^\s+(AREA|LOB-AREA) "/.test(ln));
    while (linhas.length && linhas[linhas.length - 1].trim() === '') linhas.pop();
    saida.push(linhas.join('\r\n'), '');
  }
  let corpo = saida.join('\r\n') + '\r\n.\r\n';
  const posicao = Buffer.byteLength(corpo, 'latin1');
  corpo += 'PSC\r\ncpstream=' + (df.codepage || 'ISO8859-1') + '\r\n.\r\n'
    + String(posicao).padStart(10, '0') + '\r\n';
  fs.writeFileSync(destino, Buffer.from(corpo, 'latin1'));
}

/* ------------------------------------------------------------ config ----- */
function lerConfig(arquivo) {
  return JSON.parse(fs.readFileSync(arquivo, 'utf8'));
}

function log(cfg, texto) {
  try {
    fs.mkdirSync(cfg.pastaLogs, { recursive: true });
    fs.appendFileSync(path.join(cfg.pastaLogs, 'api-local.log'),
      new Date().toISOString() + ' ' + texto + '\r\n');
  } catch (e) { /* log e' so' ajuda */ }
}

/* ---------------------------------------------------------- compilacao --- */
function compilaProgramas(cfg) {
  const lista = [];
  for (const raiz of cfg.raizes) {
    const pasta = path.join(raiz, 'esp', 'api', 'v1');
    for (const arq of listaArquivos(pasta, /\.p$/i, 0)) lista.push(arq + '|' + path.dirname(arq));
  }
  if (!lista.length) return [];
  fs.mkdirSync(cfg.pastaTmp, { recursive: true });
  const arqLista = path.join(cfg.pastaTmp, 'compila-lista.txt');
  const arqRelat = path.join(cfg.pastaTmp, 'compila-relatorio.json');
  fs.writeFileSync(arqLista, lista.join('\r\n') + '\r\n', 'latin1');
  try { fs.unlinkSync(arqRelat); } catch (e) { /* nao existia */ }
  const r = rodaAbl(cfg, path.join(cfg.pastaRuntime, 'compila.p'), arqLista + '|' + arqRelat);
  if (!fs.existsSync(arqRelat)) {
    return [{ arquivo: '(compila.p)', ok: false, mensagens: [r.saida || 'compila.p nao gerou relatorio'] }];
  }
  return JSON.parse(fs.readFileSync(arqRelat, 'utf8'));
}

module.exports = {
  achaDlc, versaoDlc, exe, envProgress, roda, rodaAbl, sobeBroker, paraBroker, limpaBrokers,
  pastaDoBanco, LIMITE_CAMINHO_BANCO,
  portaAberta, esperaPorta, getJson,
  listaArquivos, achaRaizesBackend, copiaPasta, analisaFontes, achaNoPropath, EXT_FONTES,
  lerDf, tabelasDoDf, sequenciasDoDf, gravaDfReduzido,
  lerConfig, log, compilaProgramas,
};

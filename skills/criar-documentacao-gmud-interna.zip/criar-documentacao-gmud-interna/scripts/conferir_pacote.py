#!/usr/bin/env python3
"""Confere o pacote da GMUD antes de gerar o documento.

Uso:
  python conferir_pacote.py --input entrada.json --propath "D:\\fontes\\esp;D:\\fontes" [opções]

Opções:
  --propath DIRS     pastas do PROPATH, separadas por ";" (pode repetir a opção). Obrigatório.
  --projeto DIR      pasta do projeto (git e busca de .df). Padrão: a 1ª pasta do PROPATH.
  --git-desde REF    commit/branch de antes do trabalho; compara REF com o estado atual (inclui não commitado).
                     Sem ela, usa só o que está alterado e ainda não commitado.
  --df ARQ           arquivo .df a considerar além dos achados na pasta do projeto (pode repetir).
  --pf ARQ           arquivo .pf com a conexão dos bancos, para compilar de verdade.
  --dlc DIR          instalação do OpenEdge (padrão: variável DLC ou C:\\Progress\\OpenEdge*, C:\\DLC*).
  --cp CODEPAGE      codepage dos fontes (padrão ISO8859-1).
  --sem-compilar     não tenta compilar.
  --sem-includes     não procura quem usa os includes alterados.
  --texto            imprime a lista numerada em vez do JSON.

Nada é alterado: o .r compilado vai para uma pasta temporária que é apagada no fim.
Sai com 1 quando há erro (fonte não achado ou que não compila), 0 caso contrário.
"""

from __future__ import annotations

import argparse
import glob
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from typing import Any

EXT_FONTE = {".p", ".w", ".i", ".cls", ".t"}
EXT_COMPILAVEL = {".p", ".w", ".cls"}
IGNORAR_PASTAS = {".git", "node_modules", ".svn", "__pycache__"}
LIMITE_ARQUIVOS_INCLUDE = 200_000
LIMITE_SEGUNDOS_INCLUDE = 120


def chave(caminho: str) -> str:
    """forma de comparar caminhos do PROPATH: barra normal, sem ./ e sem caixa"""
    return caminho.replace("\\", "/").lstrip("./").casefold()


def rel_propath(arquivo: Path, raizes: list[Path]) -> str | None:
    """caminho do arquivo relativo à pasta do PROPATH mais específica que o contém"""
    melhor = None
    for raiz in raizes:
        try:
            rel = arquivo.resolve().relative_to(raiz.resolve())
        except ValueError:
            continue
        if melhor is None or len(rel.parts) < len(melhor.parts):
            melhor = rel
    return str(melhor).replace("\\", "/") if melhor is not None else None


def achar_no_propath(propath: str, raizes: list[Path]) -> list[Path]:
    achados = []
    for raiz in raizes:
        alvo = raiz / propath.replace("\\", "/")
        if alvo.is_file():
            achados.append(alvo)
            continue
        # o Windows já ignora caixa; em outro sistema, procura pedaço a pedaço
        if os.name != "nt":
            atual = raiz
            ok = True
            for parte in Path(propath.replace("\\", "/")).parts:
                cand = [p for p in atual.iterdir()] if atual.is_dir() else []
                prox = next((p for p in cand if p.name.casefold() == parte.casefold()), None)
                if prox is None:
                    ok = False
                    break
                atual = prox
            if ok and atual.is_file():
                achados.append(atual)
    vistos, unicos = set(), []
    for a in achados:
        k = str(a.resolve()).casefold()
        if k not in vistos:
            vistos.add(k)
            unicos.append(a)
    return unicos


def ler(arquivo: Path) -> str:
    try:
        return arquivo.read_text(encoding="latin-1", errors="replace")
    except OSError:
        return ""


# ----------------------------------------------------------------- compilação
COMPILA_P = r"""
DEFINE STREAM sIn.
DEFINE STREAM sOut.
DEFINE VARIABLE cLista AS CHARACTER NO-UNDO.
DEFINE VARIABLE cSaida AS CHARACTER NO-UNDO.
DEFINE VARIABLE cDest  AS CHARACTER NO-UNDO.
DEFINE VARIABLE cArq   AS CHARACTER NO-UNDO.
DEFINE VARIABLE i      AS INTEGER   NO-UNDO.
ASSIGN cLista = ENTRY(1, SESSION:PARAMETER, "|")
       cSaida = ENTRY(2, SESSION:PARAMETER, "|")
       cDest  = ENTRY(3, SESSION:PARAMETER, "|").
/* o prowin le o PROPATH do progress.ini, nao da variavel de ambiente: define aqui */
PROPATH = ENTRY(4, SESSION:PARAMETER, "|") + "," + PROPATH.
INPUT STREAM sIn FROM VALUE(cLista).
OUTPUT STREAM sOut TO VALUE(cSaida).
PUT STREAM sOut UNFORMATTED "#BANCOS " NUM-DBS SKIP.
REPEAT:
  IMPORT STREAM sIn UNFORMATTED cArq.
  IF cArq = "" THEN NEXT.
  COMPILE VALUE(cArq) SAVE INTO VALUE(cDest) NO-ERROR.
  PUT STREAM sOut UNFORMATTED "#ARQ " cArq SKIP.
  PUT STREAM sOut UNFORMATTED (IF COMPILER:ERROR THEN "#ERRO" ELSE "#OK") SKIP.
  DO i = 1 TO COMPILER:NUM-MESSAGES:
    PUT STREAM sOut UNFORMATTED "#MSG " COMPILER:GET-MESSAGE-TYPE(i) "|" COMPILER:GET-NUMBER(i) "|"
        COMPILER:GET-ROW(i) "|" COMPILER:GET-FILE-NAME(i) "|"
        REPLACE(REPLACE(COMPILER:GET-MESSAGE(i), "~n", " "), "~r", " ") SKIP.
  END.
  IF COMPILER:NUM-MESSAGES = 0 THEN
  DO i = 1 TO ERROR-STATUS:NUM-MESSAGES:
    PUT STREAM sOut UNFORMATTED "#MSG 1|" ERROR-STATUS:GET-NUMBER(i) "|0||"
        REPLACE(REPLACE(ERROR-STATUS:GET-MESSAGE(i), "~n", " "), "~r", " ") SKIP.
  END.
END.
OUTPUT STREAM sOut CLOSE.
INPUT STREAM sIn CLOSE.
QUIT.
"""

# erros que, sem banco conectado, indicam só falta de banco (e não erro do fonte):
# 725 tabela desconhecida, 1006/1009 banco não conectado/desconhecido
ERROS_SEM_BANCO = {"725", "1006", "1009"}
SINAIS_SEM_BANCO = re.compile(r"(?i)(not connected|n[aã]o (est[aá] )?conectad|unknown database|banco .*desconhecid)")


def so_falta_banco(mensagens: list[dict]) -> bool:
    """o PRIMEIRO erro é de banco: o resto costuma ser consequência dele"""
    erros = [m for m in mensagens if m["tipo"] == "erro"] or mensagens
    if not erros:
        return False
    m = erros[0]
    return m["numero"] in ERROS_SEM_BANCO or bool(SINAIS_SEM_BANCO.search(m["texto"]))


def achar_dlc(opcao: str | None) -> Path | None:
    cands = [opcao] if opcao else []
    cands += [os.environ.get("DLC", "")]
    cands += sorted(glob.glob(r"C:\Progress\OpenEdge*"), reverse=True)
    cands += sorted(glob.glob(r"C:\DLC*"), reverse=True)
    for c in cands:
        if c and (Path(c) / "bin" / "_progres.exe").is_file() or (c and (Path(c) / "bin" / "_progres").is_file()):
            return Path(c)
    return None


def compilar(arquivos: list[Path], raizes: list[Path], dlc: Path, pf: str | None, cp: str) -> tuple[dict[str, dict], str]:
    exe = None
    for nome in ("prowin.exe", "prowin32.exe", "_progres.exe", "_progres"):
        if (dlc / "bin" / nome).is_file():
            exe = dlc / "bin" / nome
            break
    if exe is None:
        return {}, f"nenhum executável do Progress em {dlc}\\bin"
    resultados: dict[str, dict] = {}
    with tempfile.TemporaryDirectory(prefix="gmud-compila-") as tmp:
        tmpd = Path(tmp)
        (tmpd / "compila.p").write_text(COMPILA_P, encoding="latin-1")
        lista = tmpd / "lista.txt"
        lista.write_text("\n".join(str(a) for a in arquivos) + "\n", encoding="latin-1")
        saida = tmpd / "saida.txt"
        dest = tmpd / "r"
        dest.mkdir()
        env = dict(os.environ)
        env["DLC"] = str(dlc)
        propath = ",".join(str(r) for r in raizes)
        env["PROPATH"] = ",".join([str(tmpd), propath])
        cmd = [str(exe), "-b", "-p", str(tmpd / "compila.p"), "-param", f"{lista}|{saida}|{dest}|{propath}",
               "-cpinternal", cp, "-cpstream", cp, "-T", str(tmpd)]
        if pf:
            cmd += ["-pf", pf]
        try:
            proc = subprocess.run(cmd, env=env, capture_output=True, timeout=900, cwd=str(tmpd))
        except subprocess.TimeoutExpired:
            return {}, "a compilação passou de 15 minutos e foi interrompida"
        except OSError as exc:
            return {}, f"não consegui rodar o Progress: {exc}"
        if not saida.is_file():
            extra = (proc.stdout or b"").decode("latin-1", "replace")[-400:]
            return {}, "o Progress não gerou o resultado da compilação" + (f": {extra.strip()}" if extra.strip() else "")
        atual = None
        bancos = 0
        for linha in saida.read_text(encoding="latin-1", errors="replace").splitlines():
            if linha.startswith("#BANCOS "):
                bancos = int(linha.split()[1] or 0)
            elif linha.startswith("#ARQ "):
                atual = linha[5:].strip()
                resultados[atual] = {"ok": True, "mensagens": []}
            elif atual and linha == "#ERRO":
                resultados[atual]["ok"] = False
            elif atual and linha.startswith("#MSG "):
                tipo, num, lin, arq, msg = (linha[5:].split("|", 4) + ["", "", "", "", ""])[:5]
                resultados[atual]["mensagens"].append({
                    "tipo": "erro" if tipo.strip() == "1" else "aviso",
                    "numero": num.strip(), "linha": lin.strip(), "arquivo": arq.strip(), "texto": msg.strip(),
                })
        for r in resultados.values():
            r["bancos_conectados"] = bancos
    return resultados, f"{exe.name} ({dlc})"


# --------------------------------------------------------------------- git
def git(projeto: Path, *args: str) -> tuple[int, str]:
    try:
        p = subprocess.run(["git", "-C", str(projeto), *args], capture_output=True, timeout=60)
        return p.returncode, p.stdout.decode("utf-8", "replace")
    except (OSError, subprocess.TimeoutExpired):
        return 1, ""


def alterados_no_git(projeto: Path, desde: str | None) -> tuple[list[Path] | None, str]:
    rc, raiz = git(projeto, "rev-parse", "--show-toplevel")
    if rc != 0:
        return None, "a pasta do projeto não é um repositório git"
    raiz_git = Path(raiz.strip())
    nomes: set[str] = set()
    if desde:
        rc, out = git(projeto, "diff", "--name-only", desde)
        if rc != 0:
            return None, f"git não reconheceu '{desde}'"
        nomes.update(l for l in out.splitlines() if l.strip())
        origem = f"alterados desde {desde}"
    else:
        rc, out = git(projeto, "diff", "--name-only", "HEAD")
        nomes.update(l for l in out.splitlines() if l.strip())
        origem = "alterados e ainda não commitados"
    rc, out = git(projeto, "ls-files", "--others", "--exclude-standard")
    nomes.update(l for l in out.splitlines() if l.strip())
    arqs = [raiz_git / n for n in sorted(nomes) if Path(n).suffix.casefold() in EXT_FONTE]
    return [a for a in arqs if a.is_file()], origem


# ----------------------------------------------------------------- includes
def quem_inclui(includes: dict[str, Path], raizes: list[Path]) -> tuple[dict[str, list[str]], str]:
    """procura {include.i} nos fontes do PROPATH; devolve include -> lista de quem o usa"""
    padroes = {}
    for prop, arq in includes.items():
        nomes = {re.escape(prop.replace("\\", "/")), re.escape(prop.replace("/", "\\"))}
        # quem inclui só pelo nome (sem pasta) também conta
        nomes.add(r"(?:[\w.-]+[\\/])*" + re.escape(Path(prop).name))
        padroes[prop] = re.compile(r"\{\s*(?:" + "|".join(nomes) + r")[\s}]", re.IGNORECASE)
    usos: dict[str, set[str]] = {p: set() for p in includes}
    inicio, contados, cortado = time.time(), 0, False
    vistos: set[str] = set()
    for raiz in raizes:
        for pasta, dirs, arquivos in os.walk(raiz):
            dirs[:] = [d for d in dirs if d not in IGNORAR_PASTAS]
            for nome in arquivos:
                if Path(nome).suffix.casefold() not in EXT_FONTE:
                    continue
                full = Path(pasta) / nome
                k = str(full).casefold()
                if k in vistos:
                    continue
                vistos.add(k)
                contados += 1
                if contados > LIMITE_ARQUIVOS_INCLUDE or time.time() - inicio > LIMITE_SEGUNDOS_INCLUDE:
                    cortado = True
                    break
                texto = ler(full)
                if "{" not in texto:
                    continue
                for prop, rx in padroes.items():
                    if rx.search(texto) and full.resolve() != includes[prop].resolve():
                        usos[prop].add(rel_propath(full, raizes) or str(full))
            if cortado:
                break
        if cortado:
            break
    info = f"{contados} fontes lidos" + (" (busca interrompida pelo limite: resultado parcial)" if cortado else "")
    return {k: sorted(v) for k, v in usos.items()}, info


# ---------------------------------------------------------------------- .df
DF_RX = [
    ("tabela", re.compile(r'^\s*(ADD|UPDATE|DROP)\s+TABLE\s+"?([\w-]+)"?', re.I)),
    ("renomeia_tabela", re.compile(r'^\s*RENAME\s+TABLE\s+"?([\w-]+)"?\s+TO\s+"?([\w-]+)"?', re.I)),
    ("campo", re.compile(r'^\s*(ADD|UPDATE|DROP)\s+FIELD\s+"?([\w-]+)"?\s+OF\s+"?([\w-]+)"?', re.I)),
    ("renomeia_campo", re.compile(r'^\s*RENAME\s+FIELD\s+"?([\w-]+)"?\s+OF\s+"?([\w-]+)"?\s+TO\s+"?([\w-]+)"?', re.I)),
    ("indice", re.compile(r'^\s*(ADD|UPDATE|DROP)\s+INDEX\s+"?([\w-]+)"?\s+ON\s+"?([\w-]+)"?', re.I)),
    ("sequencia", re.compile(r'^\s*(ADD|UPDATE|DROP)\s+SEQUENCE\s+"?([\w-]+)"?', re.I)),
]


def ler_df(arq: Path) -> dict[str, Any]:
    tabelas: dict[str, set[str]] = {}
    campos_novos: list[tuple[str, str]] = []
    sequencias: list[str] = []
    for linha in ler(arq).splitlines():
        for tipo, rx in DF_RX:
            m = rx.match(linha)
            if not m:
                continue
            if tipo == "tabela":
                tabelas.setdefault(m.group(2), set()).add(f"{m.group(1).upper()} TABLE")
            elif tipo == "renomeia_tabela":
                tabelas.setdefault(m.group(2), set()).add(f"RENAME TABLE de {m.group(1)}")
            elif tipo == "campo":
                tabelas.setdefault(m.group(3), set()).add(f"{m.group(1).upper()} FIELD {m.group(2)}")
                if m.group(1).upper() == "ADD":
                    campos_novos.append((m.group(3), m.group(2)))
            elif tipo == "renomeia_campo":
                tabelas.setdefault(m.group(2), set()).add(f"RENAME FIELD {m.group(1)} -> {m.group(3)}")
            elif tipo == "indice":
                tabelas.setdefault(m.group(3), set()).add(f"{m.group(1).upper()} INDEX {m.group(2)}")
            elif tipo == "sequencia":
                sequencias.append(f"{m.group(1).upper()} SEQUENCE {m.group(2)}")
            break
    return {"tabelas": {t: sorted(o) for t, o in tabelas.items()}, "campos_novos": campos_novos, "sequencias": sequencias}


def achar_dfs(projeto: Path, extras: list[str]) -> list[Path]:
    achados = [Path(e) for e in extras if Path(e).is_file()]
    for pasta, dirs, arquivos in os.walk(projeto):
        dirs[:] = [d for d in dirs if d not in IGNORAR_PASTAS]
        achados += [Path(pasta) / a for a in arquivos if a.casefold().endswith(".df")]
    vistos, unicos = set(), []
    for a in achados:
        k = str(a.resolve()).casefold()
        if k not in vistos:
            vistos.add(k)
            unicos.append(a)
    return unicos


# --------------------------------------------------------------------- main
def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--input", required=True, type=Path)
    ap.add_argument("--propath", action="append", required=True)
    ap.add_argument("--projeto", type=Path)
    ap.add_argument("--git-desde")
    ap.add_argument("--df", action="append", default=[])
    ap.add_argument("--pf")
    ap.add_argument("--dlc")
    ap.add_argument("--cp", default="ISO8859-1")
    ap.add_argument("--sem-compilar", action="store_true")
    ap.add_argument("--sem-includes", action="store_true")
    ap.add_argument("--texto", action="store_true")
    a = ap.parse_args()

    dados = json.loads(a.input.read_text(encoding="utf-8"))
    raizes = [Path(p) for item in a.propath for p in item.split(";") if p.strip()]
    faltando_raiz = [str(r) for r in raizes if not r.is_dir()]
    raizes = [r for r in raizes if r.is_dir()]
    if not raizes:
        print("ERRO: nenhuma pasta do --propath existe", file=sys.stderr)
        return 1
    projeto = a.projeto or raizes[0]

    itens: list[dict[str, Any]] = []

    def item(nivel: str, texto: str, **extra):
        itens.append({"nivel": nivel, "texto": texto, **extra})

    for r in faltando_raiz:
        item("aviso", f"pasta do PROPATH não existe e foi ignorada: {r}")

    # 1) os fontes da lista existem?
    fontes = dados.get("changed_sources") or []
    if not fontes and not dados.get("no_changed_sources"):
        item("aviso", "changed_sources está vazio: confirme se há fontes no pacote")
    listados: dict[str, Path] = {}
    for f in fontes:
        prop = str(f.get("propath") or "").strip()
        if not prop:
            continue
        achados = achar_no_propath(prop, raizes)
        if not achados:
            item("erro", f"{prop}: NÃO achado no PROPATH", fonte=prop)
            continue
        if len(achados) > 1:
            item("aviso", f"{prop}: existe em mais de uma pasta do PROPATH; vale a primeira ({achados[0]})",
                 fonte=prop, caminhos=[str(x) for x in achados])
        listados[chave(prop)] = achados[0]
        arq = achados[0]
        if arq.suffix.casefold() == ".w":
            texto = ler(arq)
            if re.search(r"(?i)\.wrx|OCXFile|CONTROL-FRAME", texto) and not arq.with_suffix(".wrx").is_file():
                item("aviso", f"{prop}: usa controle OCX mas o {arq.with_suffix('.wrx').name} não está ao lado (vai no deploy junto)",
                     fonte=prop)

    # 2) compila?
    compilacao_info = "não pedida"
    compilaveis = [p for p in listados.values() if p.suffix.casefold() in EXT_COMPILAVEL]
    if not a.sem_compilar and compilaveis:
        dlc = achar_dlc(a.dlc)
        if dlc is None:
            compilacao_info = "OpenEdge não encontrado nesta máquina (use --dlc ou compile no ambiente do cliente)"
            item("aviso", "não compilado: " + compilacao_info)
        else:
            res, compilacao_info = compilar(compilaveis, raizes, dlc, a.pf, a.cp)
            if not res:
                item("aviso", "não compilado: " + compilacao_info)
            for prop_k, arq in listados.items():
                if arq not in compilaveis:
                    continue
                r = res.get(str(arq))
                prop = next((f["propath"] for f in fontes if chave(str(f.get("propath"))) == prop_k), str(arq))
                if r is None:
                    continue
                erros = [m for m in r["mensagens"] if m["tipo"] == "erro"]
                if r["ok"]:
                    avisos = [m for m in r["mensagens"] if m["tipo"] == "aviso"]
                    item("ok", f"{prop}: compila" + (f" ({len(avisos)} aviso(s) do compilador)" if avisos else ""), fonte=prop)
                elif not r.get("bancos_conectados") and so_falta_banco(r["mensagens"]):
                    item("aviso", f"{prop}: não deu para compilar sem banco conectado (passe --pf com os bancos, "
                                  "ou compile no ambiente do cliente)", fonte=prop,
                         mensagens=[m["texto"] for m in (erros or r["mensagens"])][:3])
                else:
                    primeiro = (erros or r["mensagens"] or [{"texto": "erro de compilação", "linha": ""}])[0]
                    onde = f" linha {primeiro['linha']}" if primeiro.get("linha") not in ("", "0", None) else ""
                    item("erro", f"{prop}: NÃO compila —{onde} {primeiro['texto']}", fonte=prop,
                         mensagens=[m["texto"] for m in (erros or r["mensagens"])][:5])

    # 3) git: falta fonte na lista? sobra fonte que não mudou?
    git_info = "não usado"
    alterados, git_info = alterados_no_git(projeto, a.git_desde)
    if alterados is not None:
        props_git = {}
        for arq in alterados:
            rel = rel_propath(arq, raizes)
            if rel:
                props_git[chave(rel)] = rel
        for k, rel in props_git.items():
            if k not in listados:
                item("aviso", f"{rel}: alterado no git ({git_info}) e fora da lista de fontes — incluir?", fonte=rel)
        if props_git:
            for k, arq in listados.items():
                if k not in props_git:
                    prop = next((f["propath"] for f in fontes if chave(str(f.get("propath"))) == k), str(arq))
                    item("aviso", f"{prop}: está na lista mas não aparece alterado no git ({git_info}) — confirme", fonte=prop)

    # 4) includes alterados: quem precisa recompilar
    includes_info = "nenhum include no pacote"
    incs = {f["propath"]: listados[chave(f["propath"])] for f in fontes
            if chave(str(f.get("propath"))) in listados and Path(f["propath"]).suffix.casefold().startswith(".i")}
    if incs and not a.sem_includes:
        usos, includes_info = quem_inclui(incs, raizes)
        for inc, quem in usos.items():
            fora = [q for q in quem if chave(q) not in listados]
            if fora:
                item("aviso", f"include {inc} alterado: {len(fora)} programa(s) que o usam precisam ser recompilados "
                              f"e ir no deploy (.r)", include=inc, programas=fora[:50])
            elif quem:
                item("ok", f"include {inc}: todos os {len(quem)} programa(s) que o usam já estão na lista", include=inc)

    # 5) .df: delta
    dfs = achar_dfs(projeto, a.df)
    sugestao_dict: list[dict[str, str]] = []
    acoes = dados.get("actions") or {}
    tem_delta = bool(acoes.get("has_dictionary_change") or acoes.get("apply_delta") or dados.get("dictionary_changes"))
    no_json = {(str(d.get("table") or "")).casefold() for d in dados.get("dictionary_changes") or []}
    for df in dfs:
        info = ler_df(df)
        if not info["tabelas"] and not info["sequencias"]:
            continue
        banco_palpite = re.sub(r"(?i)^(delta[-_]?|df[-_]?)|([-_]?delta)$", "", df.stem)
        for t, ops in info["tabelas"].items():
            sugestao_dict.append({"database": f"? (confirmar; palpite pelo nome do arquivo: {banco_palpite})",
                                  "table": t, "df": str(df), "operacoes": "; ".join(ops)})
            if tem_delta and t.casefold() not in no_json:
                item("aviso", f"{df.name}: mexe na tabela {t} ({'; '.join(ops)}) e ela não está em dictionary_changes",
                     df=str(df), tabela=t)
        if info["sequencias"]:
            item("aviso", f"{df.name}: tem {', '.join(info['sequencias'])} — cite em Estrutura", df=str(df))
        # fonte que usa campo que só nasce no .df
        for tabela, campo in info["campos_novos"]:
            rx = re.compile(rf"(?i)\b{re.escape(tabela)}\.{re.escape(campo)}\b")
            for k, arq in listados.items():
                if rx.search(ler(arq)):
                    item("aviso", f"{arq.name} usa {tabela}.{campo}, que só existe depois do delta {df.name}: "
                                  "aplicar o delta ANTES do deploy", df=str(df))
    if sugestao_dict and not tem_delta:
        item("aviso", f"achei {len(dfs)} .df com alteração de dicionário, mas o delta está marcado como Não — confirme",
             dfs=[str(d) for d in dfs])
    if tem_delta and not dfs:
        item("aviso", "delta marcado como Sim, mas não achei nenhum .df na pasta do projeto (use --df para indicar)")

    # "tabela desconhecida" de uma tabela que nasce num .df do pacote: falta aplicar o delta no banco usado
    tabelas_df = {s["table"].casefold(): s["df"] for s in sugestao_dict}
    for i in itens:
        if i["nivel"] != "erro":
            continue
        for msg in i.get("mensagens") or []:
            m = re.search(r"(?i)table ([\w-]+)\.? \(725\)", msg)
            if m and m.group(1).casefold() in tabelas_df:
                i["texto"] += (f" — a tabela {m.group(1)} vem do delta {Path(tabelas_df[m.group(1).casefold()]).name}: "
                               "aplique-o no banco do --pf e compile de novo")
                break

    erros = [i for i in itens if i["nivel"] == "erro"]
    saida = {
        "ok": not erros,
        "propath": [str(r) for r in raizes],
        "projeto": str(projeto),
        "compilacao": compilacao_info,
        "git": git_info,
        "includes": includes_info,
        "dfs": [str(d) for d in dfs],
        "itens": sorted(itens, key=lambda i: {"erro": 0, "aviso": 1, "ok": 2}[i["nivel"]]),
        "sugestao_dictionary_changes": sugestao_dict,
    }
    if a.texto:
        marca = {"erro": "ERRO", "aviso": "VERIFICAR", "ok": "ok"}
        for n, i in enumerate(saida["itens"], start=1):
            print(f"{n}. [{marca[i['nivel']]}] {i['texto']}")
            for p in (i.get("programas") or [])[:15]:
                print(f"     - {p}")
        if sugestao_dict:
            print("Delta sugerido pelos .df:")
            for s in sugestao_dict:
                print(f"   banco {s['database']} / tabela {s['table']}  ({s['operacoes']})")
        print(f"(compilação: {compilacao_info} | git: {git_info} | includes: {includes_info})")
    else:
        print(json.dumps(saida, ensure_ascii=False, indent=1))
    return 0 if not erros else 1


if __name__ == "__main__":
    raise SystemExit(main())

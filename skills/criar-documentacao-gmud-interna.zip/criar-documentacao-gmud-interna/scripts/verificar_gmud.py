#!/usr/bin/env python3
"""Confere a Documentação GMUD Interna gerada: auditoria estrutural e, se possível, render em PNG.

Uso:
  python verificar_gmud.py <arquivo.docx> [--render <pasta-png>]

A auditoria sempre roda. O render tenta, nesta ordem, Microsoft Word (COM, via PowerShell)
e LibreOffice (soffice) para gerar o PDF, e o PyMuPDF para virar PNG por página.
Sai com código 1 quando há problema bloqueante; avisos não bloqueiam.
"""

from __future__ import annotations

import argparse
import json
import re
import shutil
import subprocess
import sys
import tempfile
import unicodedata
import zipfile
from pathlib import Path

from docx import Document

# textos do modelo em branco que precisam ter sido substituídos
TEXTOS_DO_MODELO = [
    "Descrição sobre o que foi elaborado para solução do usuário",
    "Rotina de negócio relacionada a solução elaborada",
    "Descrição do nome e estrutura dos programas conforme o que deve ser atualizado em produção",
]
# o documento vai para a GMUD: nada do processo interno de geração
PROIBIDOS = [
    r"\bcodex\b", r"\bchatgpt\b", r"\bopenai\b", r"\bclaude\b", r"\bprogress code\b",
    r"intelig[eê]ncia artificial", r"\bIA\b", r"\bprompts?\b", r"n[aã]o informado",
]
PRODUTOS = ["Específicos", "Produto Padrão EMS2", "Produto Padrão EMS5", "Outro"]


def textos(doc: Document) -> list[str]:
    out = [p.text for p in doc.paragraphs]
    for t in doc.tables:
        for row in t.rows:
            for cell in row.cells:
                out.extend(p.text for p in cell.paragraphs)
    for s in doc.sections:
        for part in (s.header, s.footer, s.first_page_header, s.even_page_header):
            out.extend(p.text for p in part.paragraphs)
    return out


def sem_acento(s: str) -> str:
    return unicodedata.normalize("NFKD", s).encode("ascii", "ignore").decode().casefold()


def auditar(caminho: Path) -> tuple[list[str], list[str], dict]:
    erros: list[str] = []
    avisos: list[str] = []
    doc = Document(caminho)
    linhas = [l for l in textos(doc)]
    tudo = "\n".join(linhas)

    for t in TEXTOS_DO_MODELO:
        if t in tudo:
            erros.append(f"texto do modelo em branco não foi substituído: '{t[:50]}...'")
    if "[INSERIR PRINT" in tudo:
        n = tudo.count("[INSERIR PRINT")
        avisos.append(f"{n} marcador(es) [INSERIR PRINT] - só vale se o usuário autorizou finalizar com lacunas")
    for padrao in PROIBIDOS:
        flags = 0 if padrao == r"\bIA\b" else re.IGNORECASE
        m = re.search(padrao, tudo, flags)
        if m:
            trecho = tudo[max(0, m.start() - 40): m.end() + 40].replace("\n", " ")
            erros.append(f"termo proibido '{m.group(0)}' em: ...{trecho}...")

    marcados = [p for p in PRODUTOS if any(re.match(r"^\s*\[X\]\s*" + re.escape(p) + (r"\s*:" if p == "Outro" else ""), l) for l in linhas)]
    if len(marcados) != 1:
        erros.append(f"Produto: esperado exatamente 1 marcado, achei {len(marcados)} ({', '.join(marcados) or 'nenhum'})")

    desc = next((l for l in linhas if l.strip().startswith("Descrição:")), "")
    if not desc.split(":", 1)[-1].strip():
        erros.append("campo Descrição (topo) vazio")
    base = next((l for l in linhas if "Base de Teste utilizada para homologação" in l), "")
    if not base.split(":", 1)[-1].strip():
        erros.append("Base de Teste utilizada para homologação vazia")

    acoes = [l.strip() for l in linhas if re.match(r"^\s*\[[X ]\]\s", l)]
    radios = [l.strip() for l in linhas if re.match(r"^\s*\([X ]\)", l)]

    # metadados: sem autor, sem comentários, sem menção ao processo
    with zipfile.ZipFile(caminho) as z:
        core = z.read("docProps/core.xml").decode("utf-8", "ignore")
        app = z.read("docProps/app.xml").decode("utf-8", "ignore") if "docProps/app.xml" in z.namelist() else ""
        imagens = [n for n in z.namelist() if n.startswith("word/media/")]
    for tag in ("dc:creator", "cp:lastModifiedBy", "dc:description"):
        m = re.search(rf"<{tag}>([^<]*)</{tag}>", core)
        if m and m.group(1).strip():
            erros.append(f"metadado {tag} preenchido: '{m.group(1).strip()}' (deve ficar vazio)")
    meta = sem_acento(core + app)
    for termo in ("codex", "openai", "chatgpt", "claude", "progress code"):
        if termo in meta:
            erros.append(f"metadado menciona '{termo}'")

    resumo = {
        "produto": marcados,
        "acoes": acoes,
        "respostas": radios,
        "imagens_no_docx": len(imagens),
        "tabelas": len(doc.tables),
    }
    return erros, avisos, resumo


def para_pdf(docx: Path, pasta: Path) -> tuple[Path | None, str]:
    pdf = pasta / (docx.stem + ".pdf")
    # 1) Word por COM (não depende de pywin32: PowerShell cria o objeto)
    ps = (
        "$ErrorActionPreference='Stop';"
        "$w=New-Object -ComObject Word.Application;$w.Visible=$false;"
        "try{$d=$w.Documents.Open($env:GMUD_DOCX,$false,$true);$d.SaveAs([ref]$env:GMUD_PDF,[ref]17);$d.Close($false)}"
        "finally{$w.Quit()}"
    )
    env = dict(**__import__("os").environ, GMUD_DOCX=str(docx), GMUD_PDF=str(pdf))
    try:
        r = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", ps],
                           env=env, capture_output=True, text=True, timeout=180)
        if r.returncode == 0 and pdf.is_file():
            return pdf, "Microsoft Word"
    except Exception:
        pass
    # 2) LibreOffice
    soffice = shutil.which("soffice") or next(
        (str(p) for p in (Path(r"C:\Program Files\LibreOffice\program\soffice.exe"),
                          Path(r"C:\Program Files (x86)\LibreOffice\program\soffice.exe")) if p.is_file()), None)
    if soffice:
        try:
            subprocess.run([soffice, "--headless", "--convert-to", "pdf", "--outdir", str(pasta), str(docx)],
                           capture_output=True, timeout=180)
            if pdf.is_file():
                return pdf, "LibreOffice"
        except Exception:
            pass
    return None, "nem Microsoft Word nem LibreOffice disponíveis para converter o DOCX"


def renderizar(docx: Path, saida: Path) -> tuple[list[str], str]:
    saida.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory() as tmp:
        pdf, via = para_pdf(docx, Path(tmp))
        if not pdf:
            return [], via
        try:
            import pymupdf  # type: ignore
        except ImportError:
            try:
                import fitz as pymupdf  # type: ignore
            except ImportError:
                destino = saida / pdf.name
                shutil.copy2(pdf, destino)
                return [str(destino)], f"PDF gerado via {via}; PyMuPDF ausente, então não virou PNG"
        pngs = []
        with pymupdf.open(pdf) as d:
            for i, pagina in enumerate(d, start=1):
                arq = saida / f"pagina-{i:02d}.png"
                pagina.get_pixmap(dpi=96).save(arq)  # 96 dpi = 100% de zoom
                pngs.append(str(arq))
        return pngs, f"via {via}"


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("docx", type=Path)
    ap.add_argument("--render", type=Path, help="pasta onde salvar um PNG por página")
    a = ap.parse_args()
    if not a.docx.is_file():
        print(f"ERRO: arquivo não encontrado: {a.docx}", file=sys.stderr)
        return 1
    erros, avisos, resumo = auditar(a.docx)
    resultado = {"arquivo": str(a.docx.resolve()), "ok": not erros, "erros": erros, "avisos": avisos, **resumo}
    if a.render:
        pngs, info = renderizar(a.docx.resolve(), a.render.resolve())
        resultado["render"] = {"paginas": pngs, "info": info}
        if not pngs:
            resultado["avisos"].append("validação visual não concluída: " + info)
    print(json.dumps(resultado, ensure_ascii=False, indent=1))
    return 0 if not erros else 1


if __name__ == "__main__":
    raise SystemExit(main())

#!/usr/bin/env python3
"""Gera a Documentação GMUD Interna a partir do modelo QualiIT homologado."""

from __future__ import annotations

import argparse
import json
import re
import shutil
import sys
import unicodedata
from copy import deepcopy
from pathlib import Path
from typing import Any, Iterable

from docx import Document
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.section import WD_SECTION
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.opc.constants import RELATIONSHIP_TYPE as RT
from docx.shared import Inches, Pt, RGBColor
from docx.table import Table
from docx.text.paragraph import Paragraph


SKILL_DIR = Path(__file__).resolve().parents[1]
DEFAULT_TEMPLATE = SKILL_DIR / "assets" / "modelo-homologado.docx"
CHECKED = "X"
EMPTY = " "
ESTI0101_LABEL_COLOR = RGBColor(128, 100, 162)


def fail(message: str) -> None:
    raise ValueError(message)


def clean(value: Any) -> str:
    return "" if value is None else str(value).strip()


def normalize(text: str) -> str:
    folded = unicodedata.normalize("NFKD", text)
    folded = "".join(char for char in folded if not unicodedata.combining(char))
    return re.sub(r"\s+", " ", folded).strip().casefold()


def checkbox(selected: bool) -> str:
    return f"[{CHECKED if selected else EMPTY}]"


def radio(selected: bool) -> str:
    return f"({CHECKED if selected else EMPTY})"


def truthy(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return value != 0
    return clean(value).casefold() in {"1", "sim", "s", "yes", "true", "x"}


def resolve_input_path(value: Any, base_dir: Path) -> Any:
    text = clean(value)
    if not text:
        return value
    path = Path(text).expanduser()
    if not path.is_absolute():
        path = base_dir / path
    return str(path.resolve())


def resolve_evidence_paths(data: dict[str, Any], base_dir: Path) -> None:
    data["script_screen_images"] = [
        resolve_input_path(value, base_dir)
        for value in data.get("script_screen_images") or []
    ]

    for item in data.get("new_programs") or []:
        screenshots = item.get("screenshots") or {}
        if isinstance(screenshots, dict):
            for key, value in list(screenshots.items()):
                screenshots[key] = resolve_input_path(value, base_dir)

    for collection_name in (
        "esti0101_parameters",
        "new_upcs",
        "new_triggers_or_other_registrations",
    ):
        for item in data.get(collection_name) or []:
            item["screenshots"] = [
                resolve_input_path(value, base_dir)
                for value in item.get("screenshots") or []
            ]


def find_paragraph(doc: Document, fragment: str) -> Paragraph:
    target = normalize(fragment)
    for paragraph in doc.paragraphs:
        if target in normalize(paragraph.text):
            return paragraph
    fail(f"Campo do modelo não encontrado: {fragment}")


def paragraph_index(paragraphs: list[Paragraph], target: Paragraph) -> int:
    for index, paragraph in enumerate(paragraphs):
        if paragraph._p is target._p:
            return index
    fail("Parágrafo do modelo não pôde ser localizado na sequência do documento.")


def clear_runs(paragraph: Paragraph) -> None:
    for child in list(paragraph._p):
        if child.tag != qn("w:pPr"):
            paragraph._p.remove(child)


def clone_run_properties(source_run, target_run) -> None:
    if source_run is not None and source_run._r.rPr is not None:
        target_run._r.insert(0, deepcopy(source_run._r.rPr))


def set_paragraph_text(paragraph: Paragraph, text: str) -> None:
    source = paragraph.runs[0] if paragraph.runs else None
    clear_runs(paragraph)
    run = paragraph.add_run(text)
    clone_run_properties(source, run)


def set_labeled_text(paragraph: Paragraph, label: str, value: str) -> None:
    source = paragraph.runs[0] if paragraph.runs else None
    clear_runs(paragraph)
    label_run = paragraph.add_run(label)
    clone_run_properties(source, label_run)
    label_run.bold = True
    value_run = paragraph.add_run(value)
    clone_run_properties(source, value_run)
    value_run.bold = False


def set_bold_value_text(paragraph: Paragraph, label: str, value: str) -> None:
    source = paragraph.runs[0] if paragraph.runs else None
    clear_runs(paragraph)
    label_run = paragraph.add_run(label)
    clone_run_properties(source, label_run)
    label_run.bold = False
    value_run = paragraph.add_run(value)
    clone_run_properties(source, value_run)
    value_run.bold = True


def insert_paragraph_after(element, text: str = "", source: Paragraph | None = None) -> Paragraph:
    new_p = OxmlElement("w:p")
    element.addnext(new_p)
    paragraph = Paragraph(new_p, element.getparent())
    if source is not None and source._p.pPr is not None:
        paragraph._p.insert(0, deepcopy(source._p.pPr))
        num_pr = paragraph._p.pPr.find(qn("w:numPr"))
        if num_pr is not None:
            paragraph._p.pPr.remove(num_pr)
    if text:
        run = paragraph.add_run(text)
        if source is not None and source.runs:
            clone_run_properties(source.runs[0], run)
    return paragraph


def keep_only_rows(table: Table, count: int) -> None:
    while len(table.rows) > count:
        table._tbl.remove(table.rows[-1]._tr)


def ensure_columns(table: Table, count: int) -> None:
    while len(table.columns) < count:
        table.add_column(Inches(2.0))
    if len(table.columns) > count:
        fail("O modelo possui mais colunas do que o gerador espera.")


def find_table_by_headers(doc: Document, *headers: str) -> Table:
    wanted = {normalize(header) for header in headers}
    for table in doc.tables:
        if not table.rows:
            continue
        present = {normalize(cell.text) for cell in table.rows[0].cells}
        if wanted.issubset(present):
            return table
    fail(f"Tabela do modelo não encontrada: {', '.join(headers)}")


def first_table_after(doc: Document, element, columns: int | None = None) -> Table | None:
    current = element.getnext()
    while current is not None:
        if current.tag == qn("w:tbl"):
            table = Table(current, doc)
            if columns is None or len(table.columns) == columns:
                return table
        if current.tag == qn("w:p"):
            text = "".join(current.itertext()).strip()
            if text:
                return None
        current = current.getnext()
    return None


def insert_table_after_paragraph(
    doc: Document,
    paragraph: Paragraph,
    rows: int,
    columns: int,
) -> Table:
    table = doc.add_table(rows=rows, cols=columns)
    table.style = "Table Grid"
    paragraph._p.addnext(table._tbl)
    return table


def set_cell_text(cell, text: str, bold: bool = False) -> None:
    cell.text = ""
    paragraph = cell.paragraphs[0]
    run = paragraph.add_run(text)
    run.bold = bold
    cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER


def set_table_rows(
    table: Table,
    headers: list[str],
    rows: list[list[str]],
    widths: list[float] | None = None,
) -> None:
    ensure_columns(table, len(headers))
    keep_only_rows(table, 2)
    for idx, header in enumerate(headers):
        set_cell_text(table.rows[0].cells[idx], header, bold=True)
    if not rows:
        rows = [[""] * len(headers)]
    while len(table.rows) < len(rows) + 1:
        table._tbl.append(deepcopy(table.rows[-1]._tr))
    while len(table.rows) > len(rows) + 1:
        table._tbl.remove(table.rows[-1]._tr)
    for row_idx, values in enumerate(rows, 1):
        if len(values) != len(headers):
            fail("Quantidade de colunas inválida nos dados da tabela.")
        for col_idx, value in enumerate(values):
            set_cell_text(table.rows[row_idx].cells[col_idx], clean(value))
    if widths:
        set_table_geometry(table, widths)


def mark_first_row_as_header(table: Table) -> None:
    tr_pr = table.rows[0]._tr.get_or_add_trPr()
    marker = tr_pr.find(qn("w:tblHeader"))
    if marker is None:
        marker = OxmlElement("w:tblHeader")
        tr_pr.append(marker)
    marker.set(qn("w:val"), "true")


def mark_all_table_headers(doc: Document) -> None:
    # As tabelas de uma coluna são caixas de evidências com uma única linha longa.
    # Marcá-las como cabeçalho repetido impede a quebra entre páginas no LibreOffice
    # e pode ocultar prints. Somente tabelas tabulares têm cabeçalho repetível.
    for table in doc.tables:
        if len(table.columns) > 1:
            mark_first_row_as_header(table)


def set_table_geometry(table: Table, widths_inches: list[float]) -> None:
    widths = [round(width * 1440) for width in widths_inches]
    total = sum(widths)
    table.autofit = False
    tbl_pr = table._tbl.tblPr
    tbl_w = tbl_pr.find(qn("w:tblW"))
    if tbl_w is None:
        tbl_w = OxmlElement("w:tblW")
        tbl_pr.insert(0, tbl_w)
    tbl_w.set(qn("w:type"), "dxa")
    tbl_w.set(qn("w:w"), str(total))
    layout = tbl_pr.find(qn("w:tblLayout"))
    if layout is None:
        layout = OxmlElement("w:tblLayout")
        tbl_pr.append(layout)
    layout.set(qn("w:type"), "fixed")

    grid = table._tbl.tblGrid
    for child in list(grid):
        grid.remove(child)
    for width in widths:
        grid_col = OxmlElement("w:gridCol")
        grid_col.set(qn("w:w"), str(width))
        grid.append(grid_col)

    for row in table.rows:
        for index, cell in enumerate(row.cells):
            tc_pr = cell._tc.get_or_add_tcPr()
            tc_w = tc_pr.find(qn("w:tcW"))
            if tc_w is None:
                tc_w = OxmlElement("w:tcW")
                tc_pr.insert(0, tc_w)
            tc_w.set(qn("w:type"), "dxa")
            tc_w.set(qn("w:w"), str(widths[index]))
            borders = tc_pr.find(qn("w:tcBorders"))
            if borders is None:
                borders = OxmlElement("w:tcBorders")
                tc_pr.append(borders)
            for edge_name in ("top", "left", "bottom", "right"):
                edge = borders.find(qn(f"w:{edge_name}"))
                if edge is None:
                    edge = OxmlElement(f"w:{edge_name}")
                    borders.append(edge)
                edge.set(qn("w:val"), "single")
                edge.set(qn("w:sz"), "4")
                edge.set(qn("w:space"), "0")
                edge.set(qn("w:color"), "000000")


def set_image_alt(inline_shape, alt_text: str) -> None:
    doc_pr = inline_shape._inline.docPr
    doc_pr.set("descr", alt_text)
    doc_pr.set("title", alt_text)


def remove_orphaned_external_hyperlinks(doc: Document) -> None:
    referenced_rel_ids = {
        element.get(qn("r:id"))
        for element in doc.part.element.iter()
        if element.get(qn("r:id"))
    }
    for rel_id, relationship in list(doc.part.rels.items()):
        if (
            relationship.reltype == RT.HYPERLINK
            and relationship.is_external
            and rel_id not in referenced_rel_ids
        ):
            doc.part.drop_rel(rel_id)


def start_final_items_section(doc: Document) -> None:
    items = find_paragraph(doc, "ITENS DO DOCUMENTO")
    doubts = find_paragraph(doc, "DÚVIDAS")
    doubts.paragraph_format.page_break_before = True
    doubts.paragraph_format.keep_with_next = True
    doubts.paragraph_format.keep_together = True
    doc.add_section(WD_SECTION.NEW_PAGE)
    section_break_paragraph = doc.paragraphs[-1]
    items._p.addprevious(section_break_paragraph._p)


def clear_evidence_cell(cell, preserve_box_height: bool = False) -> None:
    cell.text = ""
    if preserve_box_height:
        cell.paragraphs[0].add_run("\n\n\n\n")


def prevent_row_split(row) -> None:
    tr_pr = row._tr.get_or_add_trPr()
    marker = tr_pr.find(qn("w:cantSplit"))
    if marker is None:
        marker = OxmlElement("w:cantSplit")
        tr_pr.append(marker)
    marker.set(qn("w:val"), "true")


def set_continuous_evidence_box(table: Table) -> None:
    """Mantém uma única moldura externa ao redor de todas as evidências."""
    last_index = len(table.rows) - 1
    for row_index, row in enumerate(table.rows):
        cell = row.cells[0]
        tc_pr = cell._tc.get_or_add_tcPr()
        borders = tc_pr.find(qn("w:tcBorders"))
        if borders is None:
            borders = OxmlElement("w:tcBorders")
            tc_pr.append(borders)

        edge_values = {
            "top": "single" if row_index == 0 else "nil",
            "start": "single",
            "bottom": "single" if row_index == last_index else "nil",
            "end": "single",
        }
        for edge_name, edge_value in edge_values.items():
            edge = borders.find(qn(f"w:{edge_name}"))
            if edge is None:
                edge = OxmlElement(f"w:{edge_name}")
                borders.append(edge)
            edge.attrib.clear()
            edge.set(qn("w:val"), edge_value)
            if edge_value == "single":
                edge.set(qn("w:sz"), "8")
                edge.set(qn("w:space"), "0")
                edge.set(qn("w:color"), "000000")


def add_cell_heading(cell, text: str) -> Paragraph:
    paragraph = cell.add_paragraph()
    paragraph.paragraph_format.space_before = 0
    paragraph.paragraph_format.space_after = 0
    paragraph.paragraph_format.keep_with_next = True
    run = paragraph.add_run(text)
    run.bold = True
    return paragraph


def add_cell_text(cell, text: str) -> Paragraph:
    paragraph = cell.add_paragraph(text)
    paragraph.paragraph_format.space_before = 0
    paragraph.paragraph_format.space_after = 0
    return paragraph


def set_script_instruction_text(cell, text: str) -> Paragraph:
    """Preenche instruções preservando quebras e sem criar parágrafo vazio inicial."""
    paragraph = cell.paragraphs[0]
    clear_runs(paragraph)
    run = paragraph.add_run(text)
    run.font.size = Pt(10)
    paragraph.paragraph_format.space_before = 0
    paragraph.paragraph_format.space_after = 0
    paragraph.paragraph_format.line_spacing = 1
    return paragraph


def add_cell_styled_line(
    cell,
    segments: Iterable[tuple[str, bool, RGBColor | None]],
) -> Paragraph:
    paragraph = cell.add_paragraph()
    paragraph.paragraph_format.space_before = 0
    paragraph.paragraph_format.space_after = 0
    for text, bold, color in segments:
        run = paragraph.add_run(text)
        run.bold = bold
        if color is not None:
            run.font.color.rgb = color
    return paragraph


def add_cell_blank_line(cell) -> Paragraph:
    paragraph = cell.add_paragraph()
    paragraph.paragraph_format.space_before = 0
    paragraph.paragraph_format.space_after = 0
    return paragraph


def add_esti0101_line(cell, label: str, value: Any) -> Paragraph:
    display_value = clean(value) or "<em branco>"
    return add_cell_styled_line(
        cell,
        (
            (f"{label}: ", True, ESTI0101_LABEL_COLOR),
            (display_value, False, RGBColor(0, 0, 0)),
        ),
    )


def add_esti0101_entry(
    cell,
    entry: dict[str, Any],
    images: list[Any],
    allow_placeholders: bool,
) -> None:
    change_type = clean(entry.get("change_type")) or "Alterar cadastro existente"
    header = entry.get("header") or {}
    parameters = entry.get("parameters") or []
    if not header or not parameters:
        fail(
            "Parâmetro ESTI0101 exige 'header' e ao menos um item em 'parameters'."
        )

    add_cell_heading(cell, "Manut Parâmetros Globais ESTI0101:")
    add_cell_heading(cell, f"{change_type}:")
    add_cell_heading(cell, "Cabeçalho:")
    for label, value in header.items():
        add_esti0101_line(cell, clean(label), value)

    add_cell_blank_line(cell)
    if not images and not allow_placeholders:
        fail("Parâmetro novo no ESTI0101 sem print.")
    if images:
        add_optional_images(cell, images, "Print ESTI0101", show_captions=False)
    else:
        add_cell_text(cell, "[INSERIR PRINT: ESTI0101]")

    add_cell_blank_line(cell)
    add_cell_heading(cell, "Parâmetros:")
    for index, parameter in enumerate(parameters):
        if index:
            add_cell_blank_line(cell)
        code = require_nonempty(
            parameter.get("code") or parameter.get("cod_param"),
            "código do parâmetro ESTI0101",
        )
        description = require_nonempty(
            parameter.get("description"),
            f"descrição do parâmetro ESTI0101 {code}",
        )
        if "value_1" not in parameter:
            fail(
                f"Valor 1 do parâmetro ESTI0101 {code} não informado; "
                "use uma string vazia quando o campo deva permanecer em branco."
            )
        value_1 = clean(parameter.get("value_1"))
        if "value_2" not in parameter:
            fail(
                f"Valor 2 do parâmetro ESTI0101 {code} não informado; "
                "use uma string vazia quando o campo deva permanecer em branco."
            )
        value_2 = clean(parameter.get("value_2"))
        add_esti0101_line(cell, "Cod. Param", code)
        add_esti0101_line(cell, "Descrição", description)
        add_esti0101_line(cell, "Valor 1", value_1)
        add_esti0101_line(cell, "Valor 2", value_2)


def add_cell_image(
    cell,
    image_path: Path,
    caption: str = "",
    width_inches: float = 6.0,
) -> Paragraph:
    caption_paragraph = None
    if caption:
        caption_paragraph = add_cell_text(cell, caption)
        caption_paragraph.paragraph_format.keep_with_next = True
        caption_paragraph.runs[0].italic = True
    paragraph = cell.add_paragraph()
    paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
    picture = paragraph.add_run().add_picture(
        str(image_path),
        width=Inches(width_inches),
    )
    set_image_alt(picture, caption or image_path.stem)
    return caption_paragraph or paragraph


def require_image(path_value: Any, label: str, allow_placeholders: bool) -> Path | None:
    path_text = clean(path_value)
    if not path_text:
        if allow_placeholders:
            return None
        fail(f"Print obrigatório não informado: {label}")
    path = Path(path_text).expanduser().resolve()
    if not path.is_file():
        fail(f"Arquivo de imagem não encontrado para {label}: {path}")
    return path


def add_required_image(
    cell,
    path_value: Any,
    label: str,
    allow_placeholders: bool,
    show_caption: bool = True,
) -> Paragraph | None:
    image_path = require_image(path_value, label, allow_placeholders)
    if image_path is None:
        return add_cell_text(cell, f"[INSERIR PRINT: {label}]")
    else:
        return add_cell_image(cell, image_path, label if show_caption else "")


def add_optional_images(
    cell,
    images: Iterable[Any],
    prefix: str,
    show_captions: bool = True,
) -> None:
    image_table = cell.add_table(rows=0, cols=1)
    for idx, value in enumerate(images, 1):
        path = require_image(value, f"{prefix} {idx}", allow_placeholders=False)
        row = image_table.add_row()
        prevent_row_split(row)
        image_cell = row.cells[0]
        clear_evidence_cell(image_cell)
        add_cell_image(
            image_cell,
            path,
            f"{prefix} {idx}" if show_captions else "",
            width_inches=5.7,
        )


def require_nonempty(value: Any, label: str) -> str:
    result = clean(value)
    if not result:
        fail(f"Campo obrigatório não informado: {label}")
    return result


def action_value(actions: dict[str, Any], *names: str) -> bool:
    return any(truthy(actions.get(name)) for name in names)


def fill_product(doc: Document, product: str, other_product: str) -> None:
    choices = ["Específicos", "Produto Padrão EMS2", "Produto Padrão EMS5", "Outro"]
    normalized_product = normalize(product)
    if normalized_product == normalize("Outro") and not clean(other_product):
        fail("Produto 'Outro' exige o campo other_product.")
    matched = False
    for choice in choices:
        fragment = "Outro:" if choice == "Outro" else choice
        paragraph = find_paragraph(doc, fragment)
        selected = normalize(choice) == normalized_product
        if selected:
            matched = True
        label = f"Outro: {other_product}" if choice == "Outro" and other_product else fragment
        text = f"{checkbox(selected)} {label}"
        set_paragraph_text(paragraph, text)
    if not matched:
        fail(f"Produto não reconhecido pelo formulário: {product}")


def fill_qa_environment(doc: Document, qa_environment: str) -> None:
    paragraph = find_paragraph(doc, "Base de Teste utilizada para homologação")
    set_labeled_text(
        paragraph,
        "Base de Teste utilizada para homologação: ",
        qa_environment,
    )


def fill_actions(
    doc: Document,
    *,
    deploy: bool,
    scripts: bool,
    dictionary: bool,
    registration: bool,
    pasoe: bool,
    pasoe_name: str,
    load_database: bool,
    optimizer: bool,
) -> None:
    replacements = {
        "Efetuar o transporte": f"{checkbox(deploy)} Efetuar o transporte (deploy) de programas",
        "Executar programa de acerto": f"{checkbox(scripts)} Executar programa de acerto",
        "Aplicar delta": f"{checkbox(dictionary)} Aplicar delta",
        "Efetuar load em banco": f"{checkbox(load_database)} Efetuar load em banco de dados",
        "Cadastrar ou alterar cadastro": (
            f"{checkbox(registration)} Cadastrar ou alterar cadastro de programa, procedimento, "
            "UPC ou trigger e afins"
        ),
        "Executar o otimizador": f"{checkbox(optimizer)} Executar o otimizador de performance",
        "Outro (s)": f"{checkbox(pasoe)} Outro (s):",
    }
    for fragment, text in replacements.items():
        set_paragraph_text(find_paragraph(doc, fragment), text)
    other_paragraph = find_paragraph(doc, "Outro (s)")
    if pasoe:
        pasoe_paragraph = insert_paragraph_after(other_paragraph._p, source=other_paragraph)
        set_bold_value_text(pasoe_paragraph, "Reiniciar PASOE: ", pasoe_name)


def fill_scripts(doc: Document, data: dict[str, Any], has_scripts: bool) -> None:
    scripts = data.get("scripts") or []
    if has_scripts and not scripts:
        fail("Há execução de script, mas nenhum caminho de programa foi informado.")
    question = find_paragraph(doc, "Necessária alguma execução de programa")
    paragraphs = doc.paragraphs
    q_index = paragraph_index(paragraphs, question)
    answer = next(p for p in paragraphs[q_index + 1 :] if normalize(p.text).startswith("("))
    set_paragraph_text(answer, f"{radio(has_scripts)} Sim\t\t{radio(not has_scripts)} Não")
    rows = []
    for item in scripts:
        program = require_nonempty(item.get("program") or item.get("path"), "caminho do programa de script")
        executor = require_nonempty(
            item.get("executor"),
            f"executor responsável pelo programa de acerto {program}",
        )
        rows.append([program, executor])
    executor_label = find_paragraph(doc, "Executor responsável")
    script_table = first_table_after(doc, executor_label._p, columns=2)
    if script_table is None:
        script_table = insert_table_after_paragraph(doc, executor_label, 2, 2)
    set_table_rows(script_table, ["Programa", "Executor"], rows, [3.9, 2.5])

    has_screen_input = truthy(data.get("has_screen_input")) if has_scripts else False
    info_answer = find_paragraph(doc, "Não há")
    set_paragraph_text(
        info_answer,
        f"{radio(not has_screen_input)} Não há\t\t{radio(has_screen_input)} Sim",
    )
    print_label = find_paragraph(doc, "Prints da tela do programa de acerto")
    evidence_table = first_table_after(doc, print_label._p, columns=1)
    if evidence_table is None:
        evidence_table = insert_table_after_paragraph(doc, print_label, 1, 1)
    cell = evidence_table.cell(0, 0)
    clear_evidence_cell(cell, preserve_box_height=not has_screen_input)
    if has_screen_input:
        text = require_nonempty(data.get("screen_input_text"), "informações a inserir na execução do script")
        set_script_instruction_text(cell, text)
        images = data.get("script_screen_images") or []
        if images:
            add_optional_images(cell, images, "Print da execução")


def fill_dictionary(doc: Document, data: dict[str, Any], has_dictionary: bool) -> None:
    question = find_paragraph(doc, "Pacote contém delta")
    paragraphs = doc.paragraphs
    q_index = paragraph_index(paragraphs, question)
    answer = next(p for p in paragraphs[q_index + 1 :] if normalize(p.text).startswith("("))
    set_paragraph_text(answer, f"{radio(has_dictionary)} Sim\t\t{radio(not has_dictionary)} Não")
    entries = data.get("dictionary_changes") or []
    if has_dictionary and not entries:
        fail("Há alteração de dicionário, mas banco e tabela não foram informados.")
    rows = []
    for item in entries:
        rows.append([
            require_nonempty(item.get("database") or item.get("bank"), "banco da alteração de dicionário"),
            require_nonempty(item.get("table"), "tabela da alteração de dicionário"),
        ])
    dictionary_table = find_table_by_headers(doc, "Banco", "Tabela")
    set_table_rows(dictionary_table, ["Banco", "Tabela"], rows, [3.2, 3.2])
    if has_dictionary and clean(data.get("df_path")):
        source = find_paragraph(doc, "Se possui alteração de Dicionário")
        first = insert_paragraph_after(
            dictionary_table._tbl,
            "Arquivos .df relacionados a este projeto localizados em:",
            source,
        )
        df_path = clean(data.get("df_path"))
        second = insert_paragraph_after(first._p, df_path, source)
        if second.runs:
            second.runs[0].font.color.rgb = RGBColor(255, 0, 0)


def fill_registration(doc: Document, data: dict[str, Any], has_registration: bool) -> None:
    question = find_paragraph(doc, "Necessário cadastro de novos programas")
    paragraphs = doc.paragraphs
    q_index = paragraph_index(paragraphs, question)
    answer = next(p for p in paragraphs[q_index + 1 :] if normalize(p.text).startswith("("))
    set_paragraph_text(answer, f"{radio(has_registration)} Sim\t\t{radio(not has_registration)} Não")

    programs = data.get("new_programs") or []
    rows = []
    for item in programs:
        rows.append([
            require_nonempty(item.get("program"), "programa novo"),
            require_nonempty(item.get("user_groups"), "grupos de usuário do programa novo"),
        ])
    programs_table = find_table_by_headers(doc, "Programa", "Grupo de Usuário")
    set_table_rows(
        programs_table,
        ["Programa", "Grupo de Usuário"],
        rows,
        [2.7, 3.7],
    )

    print_label = find_paragraph(doc, "Print dos cadastros necessários")
    evidence_table = first_table_after(doc, print_label._p, columns=1)
    if evidence_table is None:
        evidence_table = insert_table_after_paragraph(doc, print_label, 1, 1)
    keep_only_rows(evidence_table, 1)
    clear_evidence_cell(
        evidence_table.cell(0, 0),
        preserve_box_height=not has_registration,
    )
    if not has_registration:
        set_continuous_evidence_box(evidence_table)
        return

    allow_placeholders = truthy(data.get("allow_missing_screenshot_placeholders"))
    first_evidence_row = True

    def next_evidence_cell():
        nonlocal first_evidence_row
        if first_evidence_row:
            row = evidence_table.rows[0]
            first_evidence_row = False
        else:
            row = evidence_table.add_row()
            clear_evidence_cell(row.cells[0])
        prevent_row_split(row)
        return row.cells[0]

    if programs:
        for program_index, item in enumerate(programs):
            program = clean(item.get("program"))
            screenshots = item.get("screenshots") or {}
            details_cell = next_evidence_cell()
            if program_index == 0:
                add_cell_heading(details_cell, "Cadastro de Programas:")
            add_cell_heading(details_cell, program)
            add_required_image(
                details_cell,
                screenshots.get("details"),
                f"{program} - BAS_PROG_DTSUL Aba Detalhes",
                allow_placeholders,
            )
            options_cell = next_evidence_cell()
            add_required_image(
                options_cell,
                screenshots.get("options"),
                f"{program} - BAS_PROG_DTSUL Aba Opções",
                allow_placeholders,
            )
        for program_index, item in enumerate(programs):
            program = clean(item.get("program"))
            screenshots = item.get("screenshots") or {}
            procedure_cell = next_evidence_cell()
            if program_index == 0:
                add_cell_heading(procedure_cell, "Procedimentos:")
            add_required_image(
                procedure_cell,
                screenshots.get("procedure"),
                f"{program} - BAS_PROCEDIMENTO (campos superiores)",
                allow_placeholders,
                show_caption=False,
            )

    for entry in data.get("esti0101_parameters") or []:
        evidence_cell = next_evidence_cell()
        images = entry.get("screenshots") or []
        add_esti0101_entry(evidence_cell, entry, images, allow_placeholders)

    for entry in data.get("new_upcs") or []:
        evidence_cell = next_evidence_cell()
        add_cell_heading(evidence_cell, "Cadastro de UPC:")
        info = entry.get("information") or entry.get("fields") or {}
        if not info:
            fail("UPC nova sem informações de cadastro.")
        for key, value in info.items():
            add_cell_text(evidence_cell, f"{clean(key)}: {clean(value)}")
        images = entry.get("screenshots") or []
        if not images and not allow_placeholders:
            fail("UPC nova sem print.")
        if images:
            add_optional_images(evidence_cell, images, "Print UPC")
        else:
            add_cell_text(evidence_cell, "[INSERIR PRINT: UPC]")

    for entry in data.get("new_triggers_or_other_registrations") or []:
        evidence_cell = next_evidence_cell()
        add_cell_heading(evidence_cell, clean(entry.get("category")) or "Outros cadastros:")
        info = entry.get("information") or entry.get("fields") or {}
        if not info:
            fail("Cadastro adicional sem informações.")
        for key, value in info.items():
            add_cell_text(evidence_cell, f"{clean(key)}: {clean(value)}")
        images = entry.get("screenshots") or []
        if not images and not allow_placeholders:
            fail("Cadastro adicional sem print.")
        if images:
            add_optional_images(evidence_cell, images, "Print do cadastro")
        else:
            add_cell_text(evidence_cell, "[INSERIR PRINT: cadastro]")

    set_continuous_evidence_box(evidence_table)


def validate_changed_sources(data: dict[str, Any], deploy: bool) -> list[dict[str, str]]:
    raw_sources = data.get("changed_sources")
    no_changed_sources = bool(data.get("no_changed_sources"))
    if raw_sources and no_changed_sources:
        fail("Não use changed_sources junto com no_changed_sources=true.")
    if deploy and not raw_sources and not no_changed_sources:
        fail(
            "Release/deploy exige todos os fontes alterados ou criados com o caminho "
            "no PROPATH, ou no_changed_sources=true após confirmação explícita."
        )
    if raw_sources is None:
        return []
    if not isinstance(raw_sources, list):
        fail("changed_sources deve ser uma lista.")

    sources: list[dict[str, str]] = []
    seen_paths: set[str] = set()
    allowed_change_types = {"novo", "alterado"}
    for index, entry in enumerate(raw_sources, start=1):
        if not isinstance(entry, dict):
            fail(
                f"Fonte {index} deve ser um objeto com propath, description e change_type."
            )
        propath = require_nonempty(entry.get("propath"), f"Fonte alterado {index} / PROPATH")
        description = require_nonempty(
            entry.get("description"), f"Fonte alterado {index} / descrição"
        )
        normalized_path = propath.replace("\\", "/").lstrip("./").casefold()
        change_type = clean(entry.get("change_type")).casefold()
        if not change_type and normalized_path.startswith("scripts/"):
            change_type = "novo"
        if change_type not in allowed_change_types:
            fail(
                f"Fonte alterado {index} / change_type deve ser novo ou alterado."
            )
        if normalized_path in seen_paths:
            fail(f"Caminho de fonte duplicado em changed_sources: {propath}")
        seen_paths.add(normalized_path)
        sources.append(
            {
                "propath": propath,
                "description": description,
                "change_type": change_type,
            }
        )
    return sources


def join_portuguese(items: list[str]) -> str:
    if not items:
        return ""
    if len(items) == 1:
        return items[0]
    if len(items) == 2:
        return f"{items[0]} e {items[1]}"
    return f"{', '.join(items[:-1])} e {items[-1]}"


def format_sources_for_structure(changed_sources: list[dict[str, str]]) -> str:
    labels = {
        "novo": "Fontes novos",
        "alterado": "Fontes alterados",
    }
    parts: list[str] = []
    for change_type in ("novo", "alterado"):
        entries = [
            f"{source['propath']} ({source['description']})"
            for source in changed_sources
            if source["change_type"] == change_type
        ]
        if entries:
            parts.append(f"{labels[change_type]}: {join_portuguese(entries)}.")
    return " ".join(parts)


def fill_items(
    doc: Document,
    data: dict[str, Any],
    project_description: str,
    routine: str,
    changed_sources: list[dict[str, str]],
) -> None:
    items = data.get("document_items") or {}
    objective = clean(items.get("description")) or project_description
    item_routine = require_nonempty(items.get("routine"), "Itens do Documento / Rotina")
    structure = require_nonempty(items.get("structure"), "Itens do Documento / Estrutura")
    if changed_sources:
        source_text = format_sources_for_structure(changed_sources)
        structure = f"{source_text} {structure.lstrip()}"
    elif data.get("no_changed_sources"):
        structure = f"Fontes alterados/criados: não há. {structure.lstrip()}"
    set_labeled_text(find_paragraph(doc, "Descrição sobre o que foi elaborado"), "Descrição: ", objective)
    set_labeled_text(find_paragraph(doc, "Rotina de negócio relacionada"), "Rotina: ", item_routine)
    set_labeled_text(find_paragraph(doc, "Descrição do nome e estrutura"), "Estrutura: ", structure)


def build(data: dict[str, Any], output: Path, template: Path) -> None:
    release_reference = require_nonempty(
        data.get("release_reference") or data.get("ticket"),
        "chamado ou projeto que será liberado em produção",
    )
    project_description = require_nonempty(
        data.get("project_description"),
        "descrição do chamado ou projeto",
    )
    routine = clean(data.get("routine")) or "Totvs 12"
    product = clean(data.get("product")) or "Específicos"
    qa_environment = require_nonempty(data.get("qa_environment"), "ambiente de Testes (QA)")

    actions = data.get("actions") or {}
    scripts_data = data.get("scripts") or []
    dictionary_data = data.get("dictionary_changes") or []
    registrations_present = any(
        data.get(key)
        for key in (
            "new_programs",
            "esti0101_parameters",
            "new_upcs",
            "new_triggers_or_other_registrations",
        )
    )
    deploy = action_value(actions, "has_release_link", "deploy_programs") or bool(clean(data.get("release_link")))
    has_scripts = action_value(actions, "has_script", "execute_adjustment") or bool(scripts_data)
    has_dictionary = action_value(actions, "has_dictionary_change", "apply_delta") or bool(dictionary_data)
    has_registration = action_value(actions, "has_new_registration", "register_programs") or registrations_present
    pasoe = action_value(actions, "restart_pasoe") or bool(clean(data.get("pasoe_name")))
    changed_sources = validate_changed_sources(data, deploy)
    pasoe_name = clean(data.get("pasoe_name"))
    if pasoe and not pasoe_name:
        fail("O nome do PASOE a reiniciar é obrigatório.")

    if not template.is_file():
        fail(f"Modelo homologado não encontrado: {template}")
    output.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(template, output)
    doc = Document(output)

    description_value = project_description
    if normalize(release_reference) not in normalize(description_value):
        description_value = f"{release_reference} - {description_value}"
    set_labeled_text(find_paragraph(doc, "Descrição:"), "Descrição: ", description_value)
    fill_product(doc, product, clean(data.get("other_product")))
    fill_qa_environment(doc, qa_environment)
    fill_actions(
        doc,
        deploy=deploy,
        scripts=has_scripts,
        dictionary=has_dictionary,
        registration=has_registration,
        pasoe=pasoe,
        pasoe_name=pasoe_name,
        load_database=action_value(actions, "load_database"),
        optimizer=action_value(actions, "run_optimizer"),
    )
    fill_scripts(doc, data, has_scripts)
    fill_dictionary(doc, data, has_dictionary)
    fill_registration(doc, data, has_registration)
    fill_items(doc, data, project_description, routine, changed_sources)
    start_final_items_section(doc)
    mark_all_table_headers(doc)
    remove_orphaned_external_hyperlinks(doc)

    props = doc.core_properties
    props.title = f"Documentação GMUD Interna - {release_reference}"
    props.subject = project_description
    props.author = ""
    props.last_modified_by = ""
    props.comments = ""
    doc.save(output)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", required=True, type=Path, help="JSON UTF-8 com os dados coletados")
    parser.add_argument("--output", required=True, type=Path, help="DOCX de saída")
    parser.add_argument("--template", type=Path, default=DEFAULT_TEMPLATE, help="Modelo DOCX homologado")
    args = parser.parse_args()
    try:
        input_path = args.input.expanduser().resolve()
        data = json.loads(input_path.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            fail("A raiz do JSON deve ser um objeto.")
        resolve_evidence_paths(data, input_path.parent)
        build(data, args.output.resolve(), args.template.resolve())
    except Exception as exc:
        print(f"ERRO: {exc}", file=sys.stderr)
        return 1
    print(json.dumps({"output": str(args.output.resolve())}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

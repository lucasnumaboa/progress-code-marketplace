#!/usr/bin/env python3
"""Organiza os prints da GMUD: o que capturar, ligar os arquivos ao JSON e conferir as imagens.

Uso:
  python prints_gmud.py plano   --input entrada.json            lista as capturas necessárias
  python prints_gmud.py aplicar --input entrada.json [--pasta D] grava no JSON os prints achados
  python prints_gmud.py checar  --input entrada.json            confere as imagens referenciadas

Cada captura tem um nome de arquivo fixo (ex.: prog-esxx0001-detalhes.png). Salve o print com esse
nome na pasta do JSON (ou em --pasta) e rode "aplicar": ele preenche os campos de screenshots.
Para ESTI0101 com mais itens do que cabem numa tela, salve também ...-itens-2.png, ...-itens-3.png.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import struct
import sys
import unicodedata
from pathlib import Path
from typing import Any


def slug(texto: str) -> str:
    t = unicodedata.normalize("NFKD", str(texto)).encode("ascii", "ignore").decode().casefold()
    t = re.sub(r"[^a-z0-9]+", "-", t).strip("-")
    return t[:40] or "item"


def nome_param(entry: dict[str, Any], idx: int) -> str:
    header = entry.get("header") or {}
    for k, v in header.items():
        if slug(k).startswith("parametro") and str(v).strip():
            return slug(str(v).split(" - ")[0].split()[0])
    return f"param{idx + 1}"


def plano(dados: dict[str, Any]) -> list[dict[str, Any]]:
    caps: list[dict[str, Any]] = []
    for i, p in enumerate(dados.get("new_programs") or []):
        prog = str(p.get("program") or f"programa{i + 1}").strip()
        s = slug(prog)
        base = {"grupo": f"Programa novo {prog}"}
        caps += [
            {**base, "id": f"prog-{s}-detalhes", "tela": "BAS_PROG_DTSUL", "aba": "Detalhes",
             "posicionar": f"programa {prog}",
             "conferir": "programa, descrição, Nome Externo (PROPATH), módulo",
             "json": f"new_programs[{i}].screenshots.details"},
            {**base, "id": f"prog-{s}-opcoes", "tela": "BAS_PROG_DTSUL", "aba": "Opções",
             "posicionar": f"programa {prog}", "conferir": "opções do programa",
             "json": f"new_programs[{i}].screenshots.options"},
            {**base, "id": f"prog-{s}-procedimento", "tela": "BAS_PROCEDIMENTO", "aba": "(campos superiores)",
             "posicionar": f"procedimento {prog} (mesmo identificador do programa)",
             "conferir": "procedimento, descrição, módulo, programa associado",
             "json": f"new_programs[{i}].screenshots.procedure"},
        ]
    for i, e in enumerate(dados.get("esti0101_parameters") or []):
        s = nome_param(e, i)
        cab = e.get("header") or {}
        alvo = ", ".join(f"{k} {v}" for k, v in cab.items() if slug(k) in ("empresa", "parametro")) or f"parâmetro {i + 1}"
        caps += [
            {"grupo": f"ESTI0101 {s}", "id": f"esti0101-{s}-cabecalho", "tela": "ESTI0101", "aba": "cabeçalho",
             "posicionar": alvo + " (tabela pai es_param_global_ti)",
             "conferir": "Empresa, Parâmetro e descrição, Validade (início e fim)",
             "json": f"esti0101_parameters[{i}].screenshots[0]"},
            {"grupo": f"ESTI0101 {s}", "id": f"esti0101-{s}-itens", "tela": "ESTI0101", "aba": "browse de itens",
             "posicionar": alvo + " — itens da tabela filho es_param_global_ti_item",
             "conferir": "Cod. Param, Descrição, Valor 1 e Valor 2 dos itens: "
                         + ", ".join(str(x.get("code") or "?") for x in e.get("parameters") or []),
             "json": f"esti0101_parameters[{i}].screenshots[1..]", "continua": True},
        ]
    for i, u in enumerate(dados.get("new_upcs") or []):
        info = u.get("information") or {}
        caps.append({"grupo": f"UPC {i + 1}", "id": f"upc-{i + 1}", "tela": "cadastro de UPC (BAS_PROG_DTSUL)",
                     "aba": "UPC", "posicionar": ", ".join(f"{k} {v}" for k, v in info.items())[:120] or "UPC",
                     "conferir": "programa hospedeiro e Programa UPC", "json": f"new_upcs[{i}].screenshots[0..]",
                     "continua": True})
    for i, c in enumerate(dados.get("new_triggers_or_other_registrations") or []):
        caps.append({"grupo": f"Cadastro {i + 1}", "id": f"cadastro-{i + 1}",
                     "tela": str(c.get("category") or "cadastro"), "aba": "",
                     "posicionar": ", ".join(f"{k} {v}" for k, v in (c.get("information") or {}).items())[:120],
                     "conferir": "os campos informados no JSON",
                     "json": f"new_triggers_or_other_registrations[{i}].screenshots[0..]", "continua": True})
    if dados.get("has_screen_input"):
        caps.append({"grupo": "Programa de acerto", "id": "acerto-1", "tela": "programa de acerto",
                     "aba": "", "posicionar": "tela preenchida com as informações a inserir",
                     "conferir": "os dados que o executor deve informar", "json": "script_screen_images[0..]",
                     "continua": True, "opcional": True})
    for c in caps:
        c["arquivo"] = c["id"] + ".png"
    return caps


def arquivos_da_captura(c: dict[str, Any], pasta: Path) -> list[Path]:
    """o arquivo principal e, nas que continuam, -2, -3..."""
    achados = []
    for ext in (".png", ".jpg", ".jpeg"):
        p = pasta / (c["id"] + ext)
        if p.is_file():
            achados.append(p)
            break
    if c.get("continua"):
        n = 2
        while True:
            prox = next((pasta / f"{c['id']}-{n}{ext}" for ext in (".png", ".jpg", ".jpeg")
                         if (pasta / f"{c['id']}-{n}{ext}").is_file()), None)
            if not prox:
                break
            achados.append(prox)
            n += 1
    return achados


def rel(p: Path, base: Path) -> str:
    try:
        return os.path.relpath(p, base).replace("\\", "/")
    except ValueError:
        return str(p)


def aplicar(dados: dict[str, Any], base: Path, pasta: Path) -> tuple[list[str], list[str]]:
    feitos, faltam = [], []
    caps = plano(dados)
    for c in caps:
        arqs = arquivos_da_captura(c, pasta)
        if not arqs:
            if not c.get("opcional"):
                faltam.append(f"{c['arquivo']}  ({c['tela']} {c['aba']} — {c['posicionar']})")
            continue
        caminhos = [rel(a, base) for a in arqs]
        alvo = c["json"]
        m = re.match(r"(\w+)\[(\d+)\]\.screenshots\.(\w+)$", alvo)
        if m:
            dados[m.group(1)][int(m.group(2))].setdefault("screenshots", {})[m.group(3)] = caminhos[0]
        elif alvo.startswith("esti0101_parameters"):
            i = int(re.search(r"\[(\d+)\]", alvo).group(1))
            e = dados["esti0101_parameters"][i]
            atuais = list(e.get("screenshots") or [])
            if alvo.endswith("[0]"):
                atuais = caminhos[:1] + atuais[1:]
            else:
                atuais = (atuais[:1] or [""]) + caminhos
            e["screenshots"] = atuais
        elif alvo.startswith("script_screen_images"):
            dados["script_screen_images"] = caminhos
        else:
            chave, i = re.match(r"(\w+)\[(\d+)\]", alvo).groups()
            dados[chave][int(i)]["screenshots"] = caminhos
        feitos += caminhos
    # ESTI0101: o cabeçalho tem de ser o 1º; tira lacuna vazia que sobrou
    for e in dados.get("esti0101_parameters") or []:
        if e.get("screenshots"):
            e["screenshots"] = [s for s in e["screenshots"] if s]
    return feitos, faltam


def dimensoes(p: Path) -> tuple[int, int] | None:
    with open(p, "rb") as f:
        cab = f.read(32)
        if cab[:8] == b"\x89PNG\r\n\x1a\n":
            return struct.unpack(">II", cab[16:24])
        if cab[:2] == b"\xff\xd8":
            f.seek(2)
            while True:
                b = f.read(2)
                if len(b) < 2 or b[0] != 0xFF:
                    return None
                tam = struct.unpack(">H", f.read(2))[0]
                if b[1] in (0xC0, 0xC1, 0xC2):
                    f.read(1)
                    h, w = struct.unpack(">HH", f.read(4))
                    return w, h
                f.seek(tam - 2, 1)
    return None


def imagens_do_json(dados: dict[str, Any]) -> list[tuple[str, str]]:
    out = []
    for i, p in enumerate(dados.get("new_programs") or []):
        for k, v in (p.get("screenshots") or {}).items():
            out.append((f"new_programs[{i}].{k}", v))
    for chave in ("esti0101_parameters", "new_upcs", "new_triggers_or_other_registrations"):
        for i, e in enumerate(dados.get(chave) or []):
            for j, v in enumerate(e.get("screenshots") or []):
                out.append((f"{chave}[{i}][{j}]", v))
    for j, v in enumerate(dados.get("script_screen_images") or []):
        out.append((f"script_screen_images[{j}]", v))
    return out


def checar(dados: dict[str, Any], base: Path) -> tuple[list[str], list[str]]:
    erros, avisos = [], []
    hashes: dict[str, str] = {}
    for onde, valor in imagens_do_json(dados):
        if not valor:
            erros.append(f"{onde}: vazio")
            continue
        p = Path(valor)
        p = p if p.is_absolute() else base / p
        if not p.is_file():
            erros.append(f"{onde}: arquivo não existe ({valor})")
            continue
        nome = p.name.casefold()
        if nome.startswith("tela-") or ".duse" in str(p).casefold():
            erros.append(f"{onde}: {p.name} é a tela ANOTADA do duse (caixas numeradas) — use a captura limpa")
        dim = dimensoes(p)
        if dim is None:
            erros.append(f"{onde}: {p.name} não é PNG/JPEG válido")
        else:
            w, h = dim
            if w < 300 or h < 150:
                avisos.append(f"{onde}: {p.name} muito pequena ({w}x{h}) — fica ilegível no documento")
            if w > 3000 and h > 1600:
                avisos.append(f"{onde}: {p.name} parece a tela inteira ({w}x{h}) — recorte só a janela do programa")
        dig = hashlib.sha1(p.read_bytes()).hexdigest()
        if dig in hashes:
            avisos.append(f"{onde}: mesma imagem de {hashes[dig]} — print repetido?")
        else:
            hashes[dig] = onde
    return erros, avisos


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("comando", choices=["plano", "aplicar", "checar"])
    ap.add_argument("--input", required=True, type=Path)
    ap.add_argument("--pasta", type=Path, help="onde estão os prints (padrão: pasta do JSON)")
    a = ap.parse_args()
    entrada = a.input.resolve()
    base = entrada.parent
    dados = json.loads(entrada.read_text(encoding="utf-8"))

    if a.comando == "plano":
        caps = plano(dados)
        print(json.dumps({"pasta": str(a.pasta or base), "capturas": caps}, ensure_ascii=False, indent=1))
        return 0
    if a.comando == "aplicar":
        feitos, faltam = aplicar(dados, base, (a.pasta or base).resolve())
        shutil.copy2(entrada, entrada.with_suffix(entrada.suffix + ".bak"))
        entrada.write_text(json.dumps(dados, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
        print(json.dumps({"aplicados": feitos, "faltam": faltam, "backup": str(entrada) + ".bak"},
                         ensure_ascii=False, indent=1))
        return 0 if not faltam else 1
    erros, avisos = checar(dados, base)
    print(json.dumps({"ok": not erros, "erros": erros, "avisos": avisos}, ensure_ascii=False, indent=1))
    return 0 if not erros else 1


if __name__ == "__main__":
    raise SystemExit(main())

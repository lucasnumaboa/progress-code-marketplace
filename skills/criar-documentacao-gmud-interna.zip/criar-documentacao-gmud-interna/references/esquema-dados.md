# Esquema de dados do gerador

Crie um JSON UTF-8 temporário fora da pasta da skill (os prints ficam ao lado dele) e execute, trocando
`<pasta da skill>` pela pasta onde está o `SKILL.md` desta skill:

```
python "<pasta da skill>\scripts\gerar_documentacao_gmud.py" --input "<ENTRADA_JSON>" --output "<PASTA_DE_SAIDA>\Documentação GMUD Interna - Projeto Alfa.docx"
```

Saída de sucesso: `{"output": "<caminho do docx>"}`. Em falha, sai com código 1 e `ERRO: <o que falta>` —
pergunte ao usuário o dado indicado e rode de novo.

## Exemplo mínimo

```json
{
  "release_reference": "Projeto Alfa - Fase 2",
  "project_description": "Descrição breve do projeto",
  "routine": "Módulo / rotina afetada",
  "product": "Específicos",
  "qa_environment": "Cliente - BASE_QA",
  "actions": {
    "has_release_link": true,
    "has_script": false,
    "has_dictionary_change": false,
    "load_database": false,
    "has_new_registration": false,
    "run_optimizer": false,
    "restart_pasoe": false
  },
  "changed_sources": [
    {
      "propath": "esp/esxx0001.w",
      "description": "Descrição funcional do fonte",
      "change_type": "alterado"
    }
  ],
  "document_items": {
    "description": "Objetivo funcional da alteração.",
    "routine": "Módulo / rotina afetada.",
    "structure": "Demais componentes, parametrizações e dependências confirmadas."
  }
}
```

## Blocos condicionais

- `scripts`: lista de objetos com `program` e `executor`. O executor deve ser solicitado e confirmado para cada programa; não existe valor padrão.
- `has_screen_input`, `screen_input_text` e `script_screen_images`: dados e evidências da execução do programa de acerto.
- `dictionary_changes`: lista de `{ "database": "...", "table": "..." }`; `df_path` é opcional e só deve ser usado quando confirmado.
- `new_programs`: cada item exige `program`, `user_groups` e `screenshots.details`, `screenshots.options`, `screenshots.procedure`.
- `esti0101_parameters`: cada item exige `change_type`, `header`, ao menos um item em `parameters` e `screenshots`. Veja o bloco ESTI0101 abaixo.
- `new_upcs` e `new_triggers_or_other_registrations`: aceitam `information` e `screenshots`.
- `pasoe_name`: obrigatório quando `actions.restart_pasoe` for verdadeiro.

## ESTI0101 (Parâmetros Globais TI)

Um item de `esti0101_parameters` = **um registro pai** da tabela `es_param_global_ti` (o cabeçalho) com os
**registros filhos** dele na tabela `es_param_global_ti_item` (os parâmetros). Pai e filho se ligam por
`cod_empresa` + `cod_parametro`.

| JSON | Rótulo no documento/tela | Tabela.campo |
|---|---|---|
| `header."Empresa"` | Empresa | `es_param_global_ti.cod_empresa` |
| `header."Parâmetro"` | Parâmetro | `es_param_global_ti.cod_parametro` (+ `desc_param`, a descrição ao lado) |
| `header."Validade"` | Validade | `es_param_global_ti.dt_val_ini` a `es_param_global_ti.dt_val_fim` |
| `parameters[].code` | Cod. Param | `es_param_global_ti_item.cod_parametro_item` |
| `parameters[].description` | Descrição | `es_param_global_ti_item.desc_param_item` |
| `parameters[].value_1` | Valor 1 | `es_param_global_ti_item.val_1` |
| `parameters[].value_2` | Valor 2 | `es_param_global_ti_item.val_2` |

`header` é um objeto rótulo → valor, impresso na ordem em que aparece (inclua outros campos do cabeçalho que
estejam no print, se forem relevantes). `change_type` é o tipo da manutenção como deve aparecer no documento
(ex.: `Inclusão`, `Alteração`). `value_1`/`value_2` vazios confirmados saem como `<em branco>`.

```json
"esti0101_parameters": [
  {
    "change_type": "Inclusão",
    "header": {
      "Empresa": "1",
      "Parâmetro": "PARAM-EXEMPLO - Descrição do parâmetro",
      "Validade": "01/01/2026 a 31/12/9999"
    },
    "parameters": [
      { "code": "ITEM-1", "description": "Descrição do item", "value_1": "10", "value_2": "" }
    ],
    "screenshots": ["esti0101-cabecalho.png", "esti0101-itens.png"]
  }
]
```

## Validações

- `release_reference` é obrigatório e aceita qualquer identificador ou nome de chamado/projeto confirmado. O campo legado `ticket` continua aceito somente para compatibilidade.
- `project_description`, `qa_environment`, `document_items.routine` e `document_items.structure` são obrigatórios.
- `product` é opcional e assume `Específicos`; valores válidos: `Específicos`, `Produto Padrão EMS2`, `Produto Padrão EMS5`, `Outro`. Para `Outro`, informe `other_product`.
- Deploy exige `changed_sources` completos ou `no_changed_sources: true` após confirmação explícita.
- `change_type` aceita somente `novo` e `alterado`.
- Script exige ao menos um caminho e o respectivo executor informado; delta exige ao menos um par banco/tabela.
- Programa novo exige grupos de usuário e três prints; o modelo geral não exige aprovador.
- `value_1` e `value_2` devem existir nos itens do ESTI0101, mas podem ser vazios quando isso for confirmado.
- `allow_missing_screenshot_placeholders: true` só pode ser usado com autorização explícita do usuário.

Exemplo de programa de acerto com executor confirmado:

```json
"scripts": [
  {
    "program": "Scripts\\Projeto-Alfa\\ajuste.p",
    "executor": "EXECUTOR_CONFIRMADO"
  }
]
```

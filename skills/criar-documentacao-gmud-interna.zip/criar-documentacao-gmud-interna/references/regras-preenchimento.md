# Regras de preenchimento da Documentação GMUD Interna

## Formato das perguntas

- Faça cada rodada em uma lista numerada iniciada em `1`.
- Solicite somente uma informação ou decisão em cada número.
- Separe cada confirmação de **Sim ou Não** em seu próprio item.
- Nas perguntas condicionais, separe caminho, executor, instruções, dados de tela e evidências em itens diferentes.
- Para coleções, pergunte **quais itens** existem; não pergunte previamente **quantos**. Depois, solicite em itens separados somente os atributos que faltarem para cada elemento informado.
- Para programas, procedimentos e parâmetros `ESTI0101`, peça primeiro os prints exigidos. Leia os campos visíveis, apresente um resumo numerado e peça confirmação. Não solicite a digitação de dados já comprovados pelas imagens.
- Se um campo estiver cortado, ilegível ou ausente no print, peça somente esse campo em um item separado. Não complete o conteúdo por suposição.
- Não repita itens já confirmados; a rodada seguinte contém somente lacunas ainda aplicáveis.

## Campos principais

- **Chamado ou projeto:** pergunte qual referência será liberada em produção e preserve o identificador ou nome exatamente como confirmado. Aceite chamados, ordens, mudanças e nomes de projeto em qualquer formato; não exija prefixo `GSD-`.
- **Descrição:** solicite e preserve a descrição confirmada da liberação. No campo **Descrição** do documento, apresente `<chamado ou projeto> - <descrição>` sem duplicar a referência quando ela já fizer parte do texto.
- **Produto:** marque **Específicos** por padrão. As outras opções são **Produto Padrão EMS2**, **Produto Padrão EMS5** e **Outro**.
- **Base de Teste utilizada para homologação:** aceite o nome exato de qualquer cliente, base ou ambiente. Não normalize para códigos de ambiente de outro cliente.
- **Rotina:** use o módulo e a rotina de negócio confirmados em **ITENS DO DOCUMENTO**. `Totvs 12` pode ser usado como contexto somente quando pertinente.

## Ações em produção

| Confirmação | Se Sim | Se Não |
|---|---|---|
| Há transporte/deploy? | Marcar **Efetuar o transporte (deploy) de programas**. Confirmar somente a existência; o link não integra o formulário. Exigir todos os fontes alterados/criados e respectivos PROPATHs. | Deixar desmarcado. |
| Há programa de acerto? | Marcar a opção e **Sim** na execução após atualização. Coletar o caminho e solicitar sempre o executor responsável por cada programa, sem aplicar valor padrão. Perguntar se há dados a inserir e solicitar instruções/prints quando houver. | Marcar **Não** e **Não há**; deixar detalhes vazios. |
| Há alteração de dicionário? | Marcar **Aplicar delta** e **Sim** no bloco de dicionário. Coletar banco e tabela. Registrar a localização dos `.df` somente quando confirmada. | Marcar **Não** e deixar detalhes vazios. |
| Há load em banco? | Marcar **Efetuar load em banco de dados**. | Deixar desmarcado. |
| Há programa, procedimento, UPC, trigger, ESTI0101 ou cadastro equivalente? | Marcar a opção e **Sim** no bloco de cadastros. Coletar dados e evidências aplicáveis. | Marcar **Não** e deixar tabela/evidências vazias. |
| Há otimizador? | Marcar **Executar o otimizador de performance**. | Deixar desmarcado. |
| É preciso reiniciar PASOE? | Marcar **Outro(s)** e escrever `Reiniciar PASOE: <nome>`. | Deixar **Outro(s)** desmarcado. |

## Fontes e PROPATH

Para cada fonte novo ou alterado, registre `propath`, descrição funcional e `change_type` (`novo` ou `alterado`). Fontes de script são `novo` por padrão, salvo confirmação diferente.

- Para tela no `BAS_PROG_DTSUL`, use **Nome Externo** da aba **Detalhes** como fonte primária do caminho e a descrição do cadastro como descrição funcional.
- Para UPC, use **Programa UPC** como fonte criado/alterado. **Nome Externo** identifica o programa hospedeiro e não prova que ele foi modificado.
- Para os demais programas, peça diretório, nome e extensão no PROPATH. Não invente nenhum deles.

Em **ITENS DO DOCUMENTO > Estrutura**, apresente diretamente `<PROPATH> (<descrição>)`, agrupado em **Fontes novos** e **Fontes alterados**. Arquivos somente referenciados podem ser descritos depois, sem virar categoria de fonte.

## Programas e evidências

Para cada programa novo, solicite os prints abaixo e extraia deles nome, descrição, PROPATH, opções e procedimento. Colete por texto somente os grupos de usuário ou qualquer outro campo que não esteja visível:

- print **BAS_PROG_DTSUL - Aba Detalhes**;
- print **BAS_PROG_DTSUL - Aba Opções**;
- print **BAS_PROCEDIMENTO**, com os campos superiores necessários.

No `BAS_PROCEDIMENTO`, o identificador é sempre o mesmo do programa correspondente. Derive-o automaticamente do programa e apenas confirme a associação com o print; não faça uma pergunta separada pedindo o nome do procedimento.

O modelo geral não possui coluna de aprovador; não a exija nem a invente. Organize os dois primeiros prints em **Cadastro de Programas** e o terceiro em **Procedimentos**. Mantenha cada legenda e print juntos e preserve uma moldura externa contínua no bloco de evidências.

Para `ESTI0101`, peça os prints do cabeçalho e dos itens e extraia deles **Cabeçalho** (Empresa, Parâmetro, Validade e campos aplicáveis) e **Parâmetros** (`Cod. Param`, `Descrição`, `Valor 1`, `Valor 2`). O ESTI0101 grava em duas tabelas: o cabeçalho é a tabela **pai** `es_param_global_ti` (`cod_empresa`, `cod_parametro`, `desc_param`, `dt_val_ini`, `dt_val_fim`) e cada linha de parâmetro é um registro da tabela **filho** `es_param_global_ti_item` (`cod_parametro_item`, `desc_param_item`, `val_1`, `val_2`), ligada ao pai por `cod_empresa` + `cod_parametro`. Um mesmo cabeçalho pode ter vários itens: pergunte **quais** itens foram incluídos ou alterados naquele parâmetro, não quantos. Apresente o conteúdo extraído em itens numerados para confirmação e pergunte somente valores cortados, ilegíveis ou ausentes. No documento, mantenha título, tipo da manutenção, cabeçalho, prints e parâmetros nessa ordem. Use rótulos roxos `#8064A2`; valores vazios confirmados devem aparecer como `<em branco>`.

## Itens do documento

- **Descrição:** síntese funcional do objetivo e do comportamento implementado.
- **Rotina:** módulo e rotina afetados.
- **Estrutura:** fontes com PROPATH, procedures relevantes, referências sem alteração, parametrizações de produção e alterações de dicionário.

Não copie fatos de exemplos ou documentos anteriores. Quando um nome de programa, módulo, parâmetro ou caminho for inferido, valide-o com o usuário antes de finalizar.

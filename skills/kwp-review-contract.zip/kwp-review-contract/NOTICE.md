# Origem

Skill de especialista empacotada para o marketplace do Progress Code (id `kwp-review-contract`).

- Repositório: https://github.com/anthropics/knowledge-work-plugins
- Caminho: `legal/skills/review-contract`
- Autor: Anthropic
- Titular: Anthropic (o texto Apache-2.0 em `LICENSE` não traz linha de copyright preenchida)
- Licença: Apache-2.0 (texto completo em `LICENSE`, copiado de `legal/LICENSE` no repositório)
- Commit: `0e0fcacddcc892eb92a1b7873ff9d68159c47571` (baixado em 2026-11-22)

## Arquivos incluídos

- `SKILL.md` (de `legal/skills/review-contract/SKILL.md`)

## Mudanças feitas

1. Frontmatter: `name:` trocado de `review-contract` para `kwp-review-contract` (a descrição foi mantida).
2. Removida a linha que manda consultar `CONNECTORS.md` (regras de conectores do Cowork).
3. O passo "Step 8: CLM Routing (If Connected)" foi removido: só vale com um sistema de gestão de contratos conectado por MCP no Cowork. A numeração dos passos seguintes não muda (não havia passo 9).

O texto do especialista foi mantido em inglês, sem tradução.
Conforme a Apache-2.0 (seção 4b), este aviso registra que os arquivos acima foram modificados.

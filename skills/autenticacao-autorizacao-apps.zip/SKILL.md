---
name: autenticacao-autorizacao-apps
description: Implementa JWT, sessões, RBAC (controle de acesso por papel), MFA e SSO com Azure AD/Entra numa aplicação, evitando os erros clássicos de autenticação. Use quando o usuário pedir para "adicionar login nessa aplicação", "validar esse JWT", "implementar controle de acesso por papel", "configurar MFA", "integrar SSO com o Azure AD".
argument-hint: [tipo de aplicação] [mecanismo: JWT|sessão|SSO]
---

# Autenticação e autorização em apps

## JWT — gerar e validar
```python
import jwt
import datetime

token = jwt.encode(
    {"sub": str(usuario_id), "exp": datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(hours=1)},
    chave_secreta, algorithm="HS256",
)

try:
    dados = jwt.decode(token, chave_secreta, algorithms=["HS256"])
except jwt.ExpiredSignatureError:
    # tratar como "precisa logar de novo", nao como erro generico
    ...
except jwt.InvalidTokenError:
    # token adulterado/invalido - rejeitar, nunca tentar "consertar"
    ...
```
```
pip install pyjwt
```
**Erro clássico**: especificar `algorithms=["HS256"]` explicitamente no `decode` — sem isso, uma biblioteca antiga
ou mal configurada pode aceitar `alg: none` do próprio token (definido pelo atacante), permitindo forjar um token
sem assinatura nenhuma. Nunca deixe o algoritmo "livre" para o token decidir.

## Sessão (cookie) vs. JWT — quando usar cada um
- **Sessão com cookie httpOnly**: aplicação web tradicional (o servidor guarda o estado da sessão) — mais simples
  de revogar (apaga a sessão do lado do servidor a qualquer momento).
- **JWT**: API consumida por múltiplos clientes (app mobile, SPA, outro serviço) — stateless, mas **revogar antes do
  `exp` é difícil** (precisa de uma lista de revogação/blacklist mantida à parte, o que meio que anula a vantagem de
  ser stateless). Prefira `exp` curto (15-60 min) + refresh token para mitigar isso.

## RBAC (controle de acesso por papel)
```python
PERMISSOES_POR_PAPEL = {
    "admin": {"criar", "editar", "excluir", "ver"},
    "editor": {"criar", "editar", "ver"},
    "leitor": {"ver"},
}

def usuario_pode(usuario, acao):
    return acao in PERMISSOES_POR_PAPEL.get(usuario.papel, set())
```
Verifique permissão **no servidor, sempre**, mesmo que a interface já esconda o botão para quem não tem acesso —
esconder no frontend é UX, não segurança; qualquer um pode chamar a API direto sem passar pela tela.

## MFA (autenticação multifator)
```python
import pyotp

segredo = pyotp.random_base32()  # gerar uma vez por usuario, guardar com seguranca
totp = pyotp.TOTP(segredo)
url_qrcode = totp.provisioning_uri(name=usuario.email, issuer_name="Minha Empresa")  # usuario escaneia no Google Authenticator/Authy

# no login, validar o codigo de 6 digitos que o usuario digitou:
totp.verify(codigo_digitado)
```
```
pip install pyotp
```
Guarde o `segredo` do usuário com o mesmo cuidado de uma senha (criptografado em repouso, nunca em log).

## SSO com Azure AD / Microsoft Entra ID
Ver skill `oauth2-login-servicos` para o fluxo OAuth2/OIDC em si. Especificamente para Entra ID:
```
pip install msal
```
```python
from msal import ConfidentialClientApplication
app = ConfidentialClientApplication(client_id, authority=f"https://login.microsoftonline.com/{tenant_id}", client_credential=client_secret)
resultado = app.acquire_token_by_authorization_code(codigo, scopes=["User.Read"], redirect_uri=redirect_uri)
```
Registre a aplicação no Azure Portal (Entra ID → App registrations) antes — o `client_id`/`tenant_id` vêm de lá.

## Regras
- Nunca guarde senha em texto puro nem com hash fraco — ver skill `criptografia-aplicada` (bcrypt/argon2).
- Sempre valide permissão no servidor para toda ação sensível, nunca confie só na interface escondendo a opção.
- JWT: sempre especifique o algoritmo esperado explicitamente no decode; nunca aceite `alg: none`.
- MFA: ofereça um método de recuperação (códigos de backup) — sem isso, o usuário que perde o celular fica
  travado para sempre fora da própria conta.

## Arquivos desta skill
Nenhum script fixo — os trechos acima cobrem os casos mais comuns; adapte à aplicação real do usuário.

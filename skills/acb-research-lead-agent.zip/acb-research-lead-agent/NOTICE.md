# Origem

Skill de especialista empacotada para o marketplace do Progress Code (id `acb-research-lead-agent`).

- Repositório: https://github.com/anthropics/claude-cookbooks
- Caminho: `patterns/agents/prompts`
- Autor: Anthropic
- Detentor do copyright no arquivo de licença: Anthropic
- Licença: MIT (texto completo em `LICENSE`, copiado de `LICENSE` no repositório)
- Commit: `8ad5de647d4f0f50c95d74aabc8aa20a3f70cdd3` (baixado em 2026-11-22)

## Arquivos incluídos

- `SKILL.md` (de `patterns/agents/prompts/research_lead_agent.md`)

## Mudanças feitas

1. O arquivo original `research_lead_agent.md` não tem frontmatter; foi acrescentado um com `name: acb-research-lead-agent` e uma `description` em inglês escrita para o marketplace. O texto do prompt não foi alterado.

O texto do especialista foi mantido em inglês, sem tradução.

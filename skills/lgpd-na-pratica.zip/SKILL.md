---
name: lgpd-na-pratica
description: Identifica dados pessoais em código e banco de dados, aplica anonimização/pseudonimização, define log de acesso e prazo de retenção, e monta um relatório de impacto simplificado (RIPD). Use quando o usuário pedir para "isso está de acordo com a LGPD", "anonimizar essa base para ambiente de teste", "por quanto tempo posso guardar esse dado", "preciso de um RIPD para essa funcionalidade".
argument-hint: [sistema/funcionalidade a avaliar]
---

# LGPD na prática

## Identificar dado pessoal (mais amplo do que parece)
Dado pessoal é qualquer informação que identifica ou torna identificável uma pessoa — não é só CPF/e-mail: nome,
telefone, endereço IP, geolocalização, foto, e até um ID interno combinado com outros dados que permita
reidentificação. **Dado pessoal sensível** (categoria com regras mais rígidas) inclui origem racial/étnica,
convicção religiosa, opinião política, dado de saúde, biometria, orientação sexual — exige mais cuidado e, em
geral, consentimento específico.

## Anonimização vs. pseudonimização (a diferença importa legalmente)
- **Anonimização**: o dado é irreversivelmente descaracterizado — não há mais como voltar à pessoa original, nem
  com informação adicional. Um dado verdadeiramente anonimizado **sai do escopo da LGPD**.
- **Pseudonimização**: o dado é substituído por um identificador (ex.: hash do CPF), mas ainda é **reversível** com
  uma chave/tabela de correspondência guardada à parte — continua sendo dado pessoal para efeitos legais, só reduz
  o risco em caso de vazamento.
Para gerar uma base de **teste/desenvolvimento** a partir de dados de produção, use anonimização de verdade, não
só mascaramento parcial fácil de reverter:
```python
import hashlib
import random

def anonimizar_cpf(cpf):
    # NAO reversivel: hash sem guardar a chave de correspondencia em lugar nenhum
    return hashlib.sha256(cpf.encode()).hexdigest()[:11]

def gerar_nome_fake(seed):
    random.seed(seed)  # mesmo seed = mesmo nome fake para o mesmo registro, mas sem relacao reversivel com o nome real
    nomes = ["Ana", "Bruno", "Carla", "Diego", "Elisa"]
    sobrenomes = ["Silva", "Souza", "Costa", "Oliveira"]
    return f"{random.choice(nomes)} {random.choice(sobrenomes)}"
```
**Nunca** use só mascaramento visual (`123.***.***-**`) como "anonimização" para base de teste — isso é reversível
por quem tem acesso à lógica de mascaramento ou a outros dados relacionados, não conta como anonimização real.

## Log de acesso a dado pessoal
Registre, para dado sensível ou de grande volume: quem acessou, quando, qual registro, e por qual motivo/tela.
```python
def registrar_acesso(usuario_id, tabela, registro_id, motivo):
    log.info(f"ACESSO_DADO_PESSOAL usuario={usuario_id} tabela={tabela} registro={registro_id} motivo={motivo}")
```
Isso é necessário tanto para auditoria interna quanto para responder a uma eventual solicitação do titular do dado
("quem acessou minhas informações").

## Prazo de retenção
LGPD exige que o dado seja mantido **só pelo tempo necessário** à finalidade que justificou a coleta (ou por
obrigação legal específica, ex.: retenção fiscal de 5 anos). Isso significa: nunca guarde dado "para sempre por via
das dúvidas" — defina com o usuário/área jurídica um prazo específico por tipo de dado e finalidade, e implemente
expurgo automático:
```python
# exemplo: expurgar logs de acesso mais antigos que o prazo definido
DELETE FROM log_acesso WHERE data_acesso < DATEADD(year, -5, GETDATE())
```

## RIPD simplificado (Relatório de Impacto à Proteção de Dados)
Para uma funcionalidade nova que trata dado pessoal em volume/sensibilidade relevante, documente pelo menos:
1. Que dado é coletado e por quê (finalidade específica, não genérica).
2. Base legal (consentimento, execução de contrato, obrigação legal, legítimo interesse — cada uma tem requisitos
   diferentes).
3. Quem tem acesso e por quanto tempo é retido.
4. Medidas de segurança aplicadas (ver skills `criptografia-aplicada`, `gerenciar-segredos-windows`).
5. Riscos identificados e como são mitigados.
Isso não substitui uma avaliação jurídica formal quando o volume/sensibilidade justificar — é um ponto de partida
estruturado, não o documento final para casos de alto risco.

## Regras
- Nunca trate "anonimização" e "mascaramento visual" como sinônimos — só anonimização de verdade tira o dado do
  escopo da LGPD.
- Nunca decida sozinho a base legal ou o prazo de retenção "correto" para o negócio — isso é uma decisão jurídica/
  de negócio; ofereça as opções e as implicações de cada uma, mas confirme com o responsável.
- Vazamento de dado pessoal identificado: isso é um evento que precisa de resposta formal (possível notificação à
  ANPD e aos titulares) — trate como incidente sério, não como bug comum a corrigir silenciosamente.

## Arquivos desta skill
Nenhum script fixo — os trechos acima cobrem os casos mais comuns; adapte ao sistema/dado reais do usuário.

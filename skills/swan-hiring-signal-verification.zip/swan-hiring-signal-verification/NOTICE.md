# Aviso de terceiros (NOTICE)

Esta skill é uma cópia adaptada de material de terceiros e é redistribuída sob a licença original. O texto do especialista ficou em inglês, como no original.

- **Origem:** https://github.com/swan-gtm/gtm-skills
- **Caminho no repositório:** `skills/peter-borkovich/hiring-signal-verification`
- **Commit:** `eb0026f469f90645e1a64168d08a3e0afb59ee12` (baixado em 2026-11-22)
- **Autor:** Peter S. Borkovich (autor da skill); copyright do repositório: Swan
- **Licença:** MIT (texto completo em `LICENSE`, copiado de `LICENSE` do repositório)

## Arquivos incluídos

- `SKILL.md` (de `skills/peter-borkovich/hiring-signal-verification/SKILL.md`)
- `references/setup-checklist.md` (de `skills/peter-borkovich/hiring-signal-verification/references/setup-checklist.md`)
- `author.md` (de `skills/peter-borkovich/author.md`, crédito do autor pedido pelo repositório)
- `LICENSE`

## Mudanças feitas

- Frontmatter: `name: hiring-signal-verification` trocado por `name: swan-hiring-signal-verification` (a descrição ficou igual).

## Crédito do autor (author.md)

O repositório pede que o crédito do autor acompanhe a skill. Conteúdo do `author.md` original:

```markdown
---
name: Peter S. Borkovich
avatarUrl: "https://www.gtmskills.com/authors/peter-borkovich.jpg"
title: VP Americas Sales @ HiBob
linkedinUrl: "https://linkedin.com/in/petersborkovich"
companyDomain: hibob.com
---

Revenue leader running Americas sales at HiBob, the modern HR platform. Before HiBob he held revenue leadership roles at Vidyard and Yotpo, and he works with GTM teams as a coach, investor, and advisor — including Swan AI.
```

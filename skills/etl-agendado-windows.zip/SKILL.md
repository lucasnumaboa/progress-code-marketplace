---
name: etl-agendado-windows
description: Monta um pipeline extrair → transformar → carregar (ETL) em Python com log, reprocessamento idempotente e alerta de falha, agendado no Agendador de Tarefas do Windows (nenhum programa novo a instalar). Use quando o usuário pedir "rodar isso todo dia automaticamente", "criar um pipeline de dados agendado", "por que esse ETL rodou duas vezes/gerou dado duplicado".
argument-hint: [origem dos dados] [destino] [frequência]
---

# ETL agendado (Python + Agendador de Tarefas do Windows)

## Passo 1 — Estrutura do pipeline (extrair → transformar → carregar)
```python
import logging
from datetime import datetime

logging.basicConfig(
    filename=f"etl_{datetime.now():%Y%m%d}.log",
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(message)s",
)

def extrair():
    logging.info("Iniciando extracao")
    # ... buscar dados da origem (API, planilha, banco) ...
    return dados

def transformar(dados):
    logging.info(f"Transformando {len(dados)} registros")
    # ... limpeza, calculo, formatacao ...
    return dados_transformados

def carregar(dados):
    logging.info(f"Carregando {len(dados)} registros no destino")
    # ... gravar no banco/planilha/API de destino ...

def main():
    try:
        dados = extrair()
        dados = transformar(dados)
        carregar(dados)
        logging.info("ETL concluido com sucesso")
    except Exception:
        logging.exception("ETL falhou")
        raise  # deixa o processo terminar com erro para o Agendador registrar a falha

if __name__ == "__main__":
    main()
```

## Passo 2 — Idempotência (rodar duas vezes não pode duplicar dado)
A causa mais comum de "dado duplicado" num ETL agendado é reprocessamento acidental (a tarefa rodou de novo antes
de terminar, ou foi reexecutada manualmente depois de já ter rodado). Regras práticas:
- Ao carregar, use `UPSERT`/`INSERT ... ON CONFLICT` (ou `DELETE` da janela de datas antes de reinserir) em vez de
  `INSERT` puro — assim rodar duas vezes sobre o mesmo período substitui, não duplica.
- Registre num controle (tabela `etl_execucoes` ou arquivo) a última data/período já processado com sucesso, e
  pule se já foi feito — a menos que o usuário peça reprocessamento forçado explicitamente.

## Passo 3 — Agendar (sem instalar nada, usa o Agendador de Tarefas do Windows)
```powershell
$acao = New-ScheduledTaskAction -Execute "python.exe" -Argument "C:\etl\pipeline.py" -WorkingDirectory "C:\etl"
$gatilho = New-ScheduledTaskTrigger -Daily -At "06:00"
$config = New-ScheduledTaskSettingsSet -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 10)
Register-ScheduledTask -TaskName "ETL-Vendas" -Action $acao -Trigger $gatilho -Settings $config -User "SISTEMA" -RunLevel Highest
```
`-RestartCount`/`-RestartInterval` fazem o Windows tentar de novo automaticamente se a tarefa falhar (código de
saída diferente de 0) — combine com o `raise` do passo 1 para isso funcionar (sem `raise`, o processo termina com
sucesso mesmo tendo logado uma exceção, e o Agendador não percebe a falha).

## Passo 4 — Alerta de falha
Sem servidor de e-mail próprio, o mais simples é: no bloco `except`, enviar um e-mail via SMTP (credenciais fora do
código, em variável de ambiente) ou uma mensagem para um webhook do Teams/Slack já configurado. Nunca deixe uma
falha "só no log" se alguém precisa saber rapidamente — combine com o usuário qual canal de alerta ele já usa.

## Regras
- Sempre logue início, quantidade de registros processados e fim de cada etapa — sem isso, diagnosticar uma falha
  meses depois é adivinhação.
- Nunca faça o ETL de produção gravar direto sem antes rodar contra uma cópia/ambiente de teste pelo menos uma vez.
- Trate erro de origem indisponível (API fora do ar, arquivo não chegou ainda) como algo esperado que pode
  acontecer — decida com o usuário se a tarefa deve tentar de novo mais tarde ou só alertar e parar.

## Arquivos desta skill
Nenhum script fixo — a estrutura acima é o esqueleto; adapte à origem/destino reais do usuário.

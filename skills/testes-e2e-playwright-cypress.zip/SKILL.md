---
name: testes-e2e-playwright-cypress
description: Estrutura testes de ponta a ponta (E2E) com Playwright Test ou Cypress — fixtures, page objects, execução em CI e vídeo de falha — instalando sozinho o que faltar. Use quando o usuário pedir para "criar testes E2E para esse site", "gravar vídeo quando o teste falhar", "rodar os testes E2E no pipeline". Para automação pontual (não teste formal), prefira a skill `automatizar-navegador-playwright`.
argument-hint: [Playwright Test|Cypress] [fluxo a testar]
---

# Testes de interface web (E2E)

## Playwright Test — instalar (verifica antes, instala sozinho se faltar)
```
npx playwright --version
```
Se não existir:
```
npm init playwright@latest   # cria a estrutura do projeto, pergunta linguagem/CI, ja baixa os navegadores
```

## Estrutura de um teste Playwright Test
```javascript
import { test, expect } from '@playwright/test';

test('login com credenciais válidas', async ({ page }) => {
  await page.goto('https://exemplo.com/login');
  await page.getByLabel('E-mail').fill('usuario@exemplo.com');
  await page.getByLabel('Senha').fill('senha123');
  await page.getByRole('button', { name: 'Entrar' }).click();
  await expect(page.getByText('Bem-vindo')).toBeVisible();
});
```

## Page Objects (organizar seletores fora do teste)
```javascript
class PaginaLogin {
  constructor(page) { this.page = page; }
  async fazerLogin(email, senha) {
    await this.page.getByLabel('E-mail').fill(email);
    await this.page.getByLabel('Senha').fill(senha);
    await this.page.getByRole('button', { name: 'Entrar' }).click();
  }
}
```
Isso deixa o teste lendo como um cenário de negócio ("faz login, confirma painel") em vez de uma lista de cliques —
e centraliza o ajuste quando um seletor muda (só corrige no Page Object, não em cada teste que usa aquele fluxo).

## Fixtures (setup/teardown reutilizável)
```javascript
import { test as base } from '@playwright/test';

export const test = base.extend({
  paginaLogada: async ({ page }, use) => {
    await page.goto('https://exemplo.com/login');
    // ... fazer login ...
    await use(page);  // entrega a pagina ja logada para o teste
  },
});
```

## Vídeo/screenshot na falha (essencial para diagnosticar CI sem acesso à tela)
```javascript
// playwright.config.js
export default {
  use: {
    video: 'retain-on-failure',
    screenshot: 'only-on-failure',
    trace: 'retain-on-failure',   // trace viewer: replay completo da execucao, mais util que video sozinho
  },
};
```

## Cypress (alternativa, sintaxe diferente)
```
npm install -D cypress
npx cypress open   # abre a interface para gravar/rodar testes interativamente
```
```javascript
describe('login', () => {
  it('com credenciais válidas', () => {
    cy.visit('https://exemplo.com/login');
    cy.get('[data-testid=email]').type('usuario@exemplo.com');
    cy.get('[data-testid=senha]').type('senha123');
    cy.get('[data-testid=entrar]').click();
    cy.contains('Bem-vindo').should('be.visible');
  });
});
```
Cypress precisa de `data-testid`/seletor CSS mais explícito (não tem `get_by_role`/`get_by_label` nativo como
Playwright) — combine com o time de frontend para adicionar esses atributos se ainda não existirem.

## Rodar no CI (ver skill `cicd-pipelines` para o pipeline completo)
```yaml
- run: npx playwright install --with-deps   # instala navegadores + dependencias de sistema do runner
- run: npx playwright test
- uses: actions/upload-artifact@v4
  if: failure()
  with: { name: playwright-report, path: playwright-report/ }
```

## Regras
- Nunca teste contra produção real com dados de verdade — use ambiente de teste/staging com dados descartáveis.
- Sempre configure vídeo/trace "on failure" (não sempre, para não gerar volume desnecessário) — é o que permite
  diagnosticar uma falha de CI sem acesso direto à tela.
- Teste que falha de forma intermitente ("flaky"): não aumente o timeout como primeiro reflexo — investigue se é
  uma espera por condição errada (ver skill `automatizar-navegador-playwright`, passo 4) antes.

## Arquivos desta skill
Nenhum script fixo — os trechos acima cobrem os casos mais comuns; adapte ao fluxo/projeto real do usuário.

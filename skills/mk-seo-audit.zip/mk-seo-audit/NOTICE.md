# Origem e mudanças

- **Repositório:** https://github.com/coreyhaines31/marketingskills
- **Caminho no repositório:** `skills/seo-audit`
- **Autor:** Corey Haines
- **Licença:** MIT (texto em `LICENSE`)
- **Commit usado:** `5b2b400eec1e7e1cec76245a715d0b0d4fd2a9c1`
- **Arquivos copiados:** `SKILL.md`, `references/ai-writing-detection.md`, `references/international-seo.md`, `references/local-seo.md`, `references/rankings-push.md`, `references/title-tags.md`

## Mudanças feitas

- no cabeçalho (frontmatter), `name:` passou de `seo-audit` para `mk-seo-audit`; a descrição ficou igual
- removida a menção ao Magister, produto do próprio mantenedor do repositório (propaganda)
- nenhuma outra alteração no texto do especialista (mantido em inglês)

Empacotada para o marketplace do Progress Code em 2026-11-22.

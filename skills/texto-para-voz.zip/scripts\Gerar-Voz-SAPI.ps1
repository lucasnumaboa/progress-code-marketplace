<#
.SYNOPSIS
    Gera um arquivo .wav a partir de texto usando o SAPI (Speech API) ja embutido no Windows - sem instalar nada,
    sem precisar de internet.
.PARAMETER Texto
    Texto a ser falado. Ignorado se -ArquivoTexto for informado.
.PARAMETER ArquivoTexto
    Caminho de um .txt para ler o texto em vez de passar inline.
.PARAMETER Saida
    Caminho do arquivo .wav de saida.
.PARAMETER Voz
    Nome (ou parte do nome) da voz instalada a usar. Se omitido, usa a voz padrao do sistema.
.PARAMETER Velocidade
    -10 (mais lento) a 10 (mais rapido). Padrao 0.
.EXAMPLE
    powershell -File Gerar-Voz-SAPI.ps1 -Texto "Ola, este e um teste." -Saida "C:\temp\audio.wav"
#>
param(
    [string]$Texto,
    [string]$ArquivoTexto,
    [Parameter(Mandatory = $true)][string]$Saida,
    [string]$Voz,
    [int]$Velocidade = 0
)

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Speech

if ($ArquivoTexto) {
    $Texto = Get-Content -LiteralPath $ArquivoTexto -Raw
} elseif (-not $Texto) {
    Write-Error "Informe -Texto ou -ArquivoTexto."
    exit 1
}

$synth = New-Object System.Speech.Synthesis.SpeechSynthesizer
$synth.Rate = $Velocidade

if ($Voz) {
    $vozes = $synth.GetInstalledVoices() | Where-Object { $_.VoiceInfo.Name -imatch [regex]::Escape($Voz) }
    if ($vozes.Count -eq 0) {
        Write-Warning "Nenhuma voz instalada corresponde a '$Voz'. Vozes disponiveis:"
        $synth.GetInstalledVoices() | ForEach-Object { Write-Host "  - $($_.VoiceInfo.Name)" }
        Write-Error "Ajuste -Voz para um dos nomes acima, ou omita para usar a voz padrao."
        exit 1
    }
    $synth.SelectVoice($vozes[0].VoiceInfo.Name)
}

$pastaSaida = Split-Path -Parent $Saida
if ($pastaSaida -and -not (Test-Path $pastaSaida)) {
    New-Item -ItemType Directory -Path $pastaSaida -Force | Out-Null
}

$synth.SetOutputToWaveFile($Saida)
$synth.Speak($Texto)
$synth.Dispose()

Write-Host "Gerado: $Saida"

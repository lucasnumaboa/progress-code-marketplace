---
name: texto-para-voz
description: Gera áudio a partir de texto (TTS) usando as vozes do Windows (SAPI, já embutidas, sem instalar nada) ou vozes neurais melhores via edge-tts (biblioteca Python que usa o serviço do Microsoft Edge, sem precisar instalar programa), com controle de pausas e ênfase via SSML. Use quando o usuário pedir "transformar esse texto em áudio", "gerar narração", "ler isso em voz alta e salvar", "avisos por voz".
argument-hint: [texto ou arquivo .txt] [caminho de saída .wav/.mp3]
---

# Gerar voz a partir de texto (TTS)

## Opção 1 — Vozes do Windows (SAPI, sempre disponível, offline)
```
powershell -File Gerar-Voz-SAPI.ps1 -Texto "Ola, este e um teste." -Saida "C:\temp\audio.wav"
```
Lista vozes instaladas (varia por idioma configurado no Windows):
```
powershell -Command "Add-Type -AssemblyName System.Speech; (New-Object System.Speech.Synthesis.SpeechSynthesizer).GetInstalledVoices() | ForEach-Object { $_.VoiceInfo.Name }"
```
Qualidade robótica, mas **funciona sempre**, sem internet e sem instalar nada — bom para avisos internos rápidos.

## Opção 2 — Vozes neurais (edge-tts, melhor qualidade, precisa de internet)
```
pip install edge-tts
```
```
python -m edge_tts --voice pt-BR-FranciscaNeural --text "Ola, este e um teste." --write-media audio.mp3
```
Listar vozes pt-BR disponíveis: `python -m edge_tts --list-voices | findstr pt-BR` (vozes comuns:
`pt-BR-FranciscaNeural` feminina, `pt-BR-AntonioNeural` masculina). Isso usa o serviço de nuvem do Edge, não precisa
instalar o navegador nem um programa separado — é só uma biblioteca Python que chama um endpoint público.

## Passo — SSML para pausas e ênfase (funciona nas duas opções, com pequenas diferenças de suporte)
```xml
<speak version="1.0" xml:lang="pt-BR">
  Atenção. <break time="500ms"/>
  Este é um aviso <emphasis level="strong">importante</emphasis>.
</speak>
```
`edge-tts` aceita SSML parcial via parâmetros próprios (`--rate`, `--pitch`) em vez de tags completas em alguns
casos — teste o resultado ouvindo antes de considerar pronto; nem toda tag SSML tem efeito audível em toda voz.

## Regras
- Sempre gere um trecho curto de teste primeiro e pergunte/confirme se a voz/velocidade está adequada antes de
  processar um texto longo (evita retrabalho e uso de rede desnecessário).
- Texto muito longo: quebre em partes por parágrafo antes de mandar para a API/SAPI — synthesizers têm limite de
  tamanho de entrada e cortam ou falham silenciosamente em textos muito grandes.
- Se o texto tem números/siglas que podem ser lidos errado (ex.: "R$ 1.234,56", "CNPJ"), escreva por extenso no
  texto de entrada em vez de confiar que o sintetizador vai interpretar certo — teste antes de aceitar como pronto.

## Arquivos desta skill
- `scripts/Gerar-Voz-SAPI.ps1` — gera `.wav` com as vozes do Windows, sem internet.

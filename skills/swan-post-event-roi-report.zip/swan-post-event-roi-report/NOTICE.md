# Origem

Skill de especialista empacotada para o marketplace do Progress Code (id `swan-post-event-roi-report`).

- Repositório: https://github.com/swan-gtm/gtm-skills
- Caminho: `skills/ariel-cohen/post-event-roi-report`
- Autor: Ariel Cohen / Swan (biblioteca Swan; autoria registrada em `author.md`, copiado do repositório)
- Detentor do copyright no arquivo de licença: Swan
- Licença: MIT (texto completo em `LICENSE`, copiado de `LICENSE` no repositório)
- Commit: `eb0026f469f90645e1a64168d08a3e0afb59ee12` (baixado em 2026-11-22)

## Arquivos incluídos

- `SKILL.md` (de `skills/ariel-cohen/post-event-roi-report/SKILL.md`)
- `author.md` (de `skills/ariel-cohen/author.md`)

## Mudanças feitas

1. Frontmatter: `name:` trocado de `post-event-roi-report` para `swan-post-event-roi-report` (a descrição foi mantida).

O texto do especialista foi mantido em inglês, sem tradução.

A biblioteca swan-gtm/gtm-skills é MIT (LICENSE "Copyright (c) 2026 Swan"; CONTRIBUTING: "Contributions are MIT-licensed"). O crédito ao autor de cada skill é mantido pelo `author.md`.

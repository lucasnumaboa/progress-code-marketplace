---
name: chamar-apis-de-ia
description: Chama APIs de modelos de IA a partir de código (formato OpenAI-compatível, Anthropic, e modelos locais via Ollama/LM Studio) — streaming, tool calling, controle de custo, cache de prompt e tratamento de limite. Use quando o usuário pedir para "integrar com uma API de IA no código", "implementar streaming da resposta", "essa chamada de tool/function calling não está funcionando", "reduzir custo de tokens". Para detalhes específicos da API da Anthropic/Claude, prefira a skill `claude-api` já existente neste ambiente.
argument-hint: [provedor: OpenAI-compatível|Anthropic|local] [o que a integração precisa fazer]
---

# Chamar APIs de IA a partir de código

## Formato OpenAI-compatível (o mais replicado entre provedores)
```python
from openai import OpenAI
cliente = OpenAI(api_key=chave, base_url="https://api.provedor.com/v1")  # base_url muda conforme o provedor compativel

resposta = cliente.chat.completions.create(
    model="nome-do-modelo",
    messages=[{"role": "system", "content": "..."}, {"role": "user", "content": "..."}],
)
```
Vários provedores (incluindo modelos locais servidos via Ollama/LM Studio) expõem uma API compatível com esse
formato — o SDK `openai` funciona contra eles só trocando `base_url`. Para a API nativa da Anthropic (não o modo
compatibilidade), ver a skill `claude-api` — a estrutura de mensagens e recursos (`tool_use`, cache de prompt) tem
particularidades próprias que essa skill detalha melhor.

## Streaming (resposta chegando aos poucos, não tudo de uma vez no final)
```python
stream = cliente.chat.completions.create(model=modelo, messages=mensagens, stream=True)
for parte in stream:
    delta = parte.choices[0].delta.content
    if delta:
        print(delta, end="", flush=True)
```
Streaming melhora a percepção de latência (usuário vê algo acontecendo logo) mesmo quando o tempo total não muda —
use sempre que a resposta for exibida diretamente a um humano esperando; para processamento em lote/backend sem
humano observando em tempo real, streaming não traz benefício e complica o código sem necessidade.

## Tool calling / function calling
```python
ferramentas = [{
    "type": "function",
    "function": {
        "name": "buscar_pedido",
        "description": "Busca um pedido pelo numero",
        "parameters": {"type": "object", "properties": {"numero": {"type": "string"}}, "required": ["numero"]},
    },
}]
resposta = cliente.chat.completions.create(model=modelo, messages=mensagens, tools=ferramentas)

if resposta.choices[0].message.tool_calls:
    chamada = resposta.choices[0].message.tool_calls[0]
    argumentos = json.loads(chamada.function.arguments)
    resultado = buscar_pedido(argumentos["numero"])  # executar de verdade a funcao
    # devolver o resultado numa mensagem role="tool" e chamar de novo para o modelo continuar
```
O modelo **decide** chamar a ferramenta, mas **não a executa** — o código precisa rodar a função de verdade e
devolver o resultado numa nova mensagem antes do modelo continuar a resposta. `description` de cada parâmetro
importa tanto quanto o nome — descrição vaga leva o modelo a preencher argumento errado com mais frequência.

## Cache de prompt (reduzir custo/latência em conteúdo repetido entre chamadas)
Quando o mesmo bloco grande de contexto (system prompt longo, documento de referência) se repete em várias
chamadas, marque-o para cache (mecanismo específico de cada provedor — `cache_control` na Anthropic, cache
automático em outras) — chamadas seguintes que reusam esse prefixo pagam menos e respondem mais rápido. Ver skill
`claude-api` para os detalhes exatos do cache de prompt da Anthropic.

## Tratamento de limite (rate limit) e erro
```python
import time

def chamar_com_retry(func, tentativas=5):
    for tentativa in range(tentativas):
        try:
            return func()
        except RateLimitError as e:
            time.sleep(2 ** tentativa)
        except APIError:
            if tentativa == tentativas - 1:
                raise
            time.sleep(2 ** tentativa)
```
Mesmo padrão de retry com backoff da skill `chamar-apis-http` — rate limit de API de IA não é diferente de rate
limit de qualquer outra API nesse aspecto.

## Modelos locais (Ollama, LM Studio, llama.cpp) — precisam de instalação separada
Rodar um modelo localmente exige instalar o servidor (Ollama, LM Studio) e baixar os pesos do modelo (arquivos de
alguns GB) — confirme com o usuário antes de propor esse caminho, é uma instalação substancial comparada a só
chamar uma API de nuvem. Uma vez rodando, a maioria expõe uma API compatível com OpenAI (`http://localhost:11434/v1`
no Ollama, por exemplo) — o código de chamada é o mesmo padrão acima, só muda `base_url` e não há custo por token
(mas usa recurso de hardware local: GPU/CPU/memória).

## Regras
- Nunca deixe uma chamada de API de IA sem `timeout` — mesma regra da skill `chamar-apis-http`.
- Sempre trate o caso de `tool_calls` vir vazio (o modelo respondeu direto em texto sem usar ferramenta) como
  fluxo normal, não erro.
- Custo: para chamadas em lote/produção, sempre estime o custo aproximado (tokens de entrada × preço + tokens de
  saída × preço) antes de rodar em volume alto, e confirme com o usuário se o volume/custo esperado faz sentido.

## Arquivos desta skill
Nenhum script fixo — os trechos acima cobrem o padrão de uso; para detalhes específicos da Anthropic, use a skill
`claude-api` já existente neste ambiente.

---
name: progress-openedge-odbc-jdbc
description: Conecta no banco Progress OpenEdge via ODBC/JDBC a partir de fora do ambiente 4GL, consulta o dicionário de dados (_File, _Field), e usa proutil para exportar/importar .d e analisar logs .lg. Use quando o usuário pedir para "consultar o banco Progress de fora do ambiente 4GL", "exportar/importar dados via .d", "o que esse log .lg está dizendo", "conectar no Progress via Python/uma ferramenta de BI".
argument-hint: [banco/DSN Progress] [operação]
---

# Progress OpenEdge: banco e ODBC/JDBC

## Pré-requisito
Isso assume que o cliente/driver ODBC ou JDBC do OpenEdge já está instalado (parte da instalação padrão do
OpenEdge/Datasul neste ambiente) — esta skill não instala o driver, só usa o que já existe.

## Conectar via ODBC (de fora do 4GL — Python, Excel, Power BI)
```python
import pyodbc
conexao = pyodbc.connect(
    "DSN=meu_dsn_progress;UID=usuario;PWD=senha"
    # ou sem DSN configurado: "DRIVER={Progress OpenEdge 12.x driver};HOST=servidor;PORT=port;DB=nomedobanco;UID=..;PWD=.."
)
cursor = conexao.cursor()
cursor.execute("SELECT * FROM PUB.cliente WHERE cod_cliente = ?", codigo)
```
`PUB.` é o schema padrão para tabelas do usuário no OpenEdge SQL — sem ele, muitas consultas via ODBC falham com
"tabela não encontrada" mesmo a tabela existindo (a maior armadilha de quem vem de outro banco).

## Conectar via JDBC (Java, ou ferramentas que só suportam JDBC)
```
jdbc:datadirect:openedge://servidor:porta;databaseName=nomedobanco;user=usuario;password=senha
```
Driver JDBC geralmente já vem junto da instalação do OpenEdge (`openedge.jar` ou similar) — confirme o caminho
exato com quem administra o ambiente.

## Consultar o dicionário de dados (metadados das tabelas)
```sql
-- via SQL (ODBC/JDBC) - tabelas de sistema com _ na frente sao o dicionario
SELECT "_File-Name", "_Desc" FROM PUB."_File" WHERE "_File-Name" LIKE 'ped%';
SELECT "_Field-Name", "_Data-Type", "_Format" FROM PUB."_Field" WHERE "_File-recid" = (SELECT "_File-recid" FROM PUB."_File" WHERE "_File-Name" = 'pedido');
```
Nomes de coluna com hífen (`_File-Name`) precisam de aspas duplas em SQL padrão — sem isso, o parser SQL entende
como subtração.

## proutil — exportar/importar dados (.d)
```
proutil nomedobanco -C dump nome_tabela /caminho/saida
proutil nomedobanco -C load nome_tabela /caminho/entrada.d
```
`.d` é um dump de texto simples (um registro por linha, delimitado) — específico da estrutura da tabela no momento
do dump; carregar num schema diferente (coluna a mais/a menos) falha ou corrompe dados. Sempre confira que o schema
de origem e destino batem antes de um `load` em produção.

## Logs (.lg) — o que procurar
O log do banco (`nomedobanco.lg`) registra eventos de sistema, erros de conexão, backup, checkpoint. Procure por:
- `SYSTEM ERROR`: erro grave, geralmente com um código de erro numérico do Progress a pesquisar na base de
  conhecimento da Progress Software.
- `Lock table overflow`/`Lock table is full`: parâmetro `-L` (tamanho da tabela de locks) baixo demais para o
  volume de transações concorrentes.
- `BROKER` mensagens de início/fim de sessão de usuário — útil para correlacionar "quando o usuário X conectou/
  desconectou" com um problema relatado.

## Regras
- Nunca rode `proutil ... load` em banco de produção sem confirmar schema e ter backup recente — dump/load mal
  feito pode corromper dados sem aviso claro no momento da operação.
- Consulta via ODBC/JDBC pode ser mais lenta que 4GL nativo para operações pesadas (o SQL engine do OpenEdge não é
  o mesmo caminho de acesso do 4GL) — para relatórios pesados, avalie se vale mais rodar em 4GL nativo.
- Sempre confirme com o usuário se a operação deve ser feita no banco de produção ou num ambiente de teste antes de
  qualquer `load`/alteração via proutil.

## Arquivos desta skill
Nenhum script fixo — os comandos acima cobrem os casos mais comuns; adapte ao banco/tabela reais do usuário. Para
ler/escrever código Progress 4GL/ABL propriamente dito, use as skills `expert-progress` e `progress-admin`
(já existentes neste catálogo).

# Origem e mudanças

- **Repositório:** https://github.com/phuryn/pm-skills
- **Caminho no repositório:** `pm-marketing-growth/skills/value-prop-statements`
- **Autor:** Paweł Huryn
- **Licença:** MIT (texto em `LICENSE`)
- **Commit usado:** `9af7bfd0bc47fdad43c2eaa7a43cd13918e7aaef`
- **Arquivos copiados:** `SKILL.md`

## Mudanças feitas

- no cabeçalho (frontmatter), `name:` passou de `value-prop-statements` para `ph-value-prop-statements`; a descrição ficou igual
- nenhuma outra alteração no texto do especialista (mantido em inglês)

Empacotada para o marketplace do Progress Code em 2026-11-22.

# Origem e mudanças

- **Repositório:** https://github.com/addyosmani/web-quality-skills
- **Caminho no repositório:** `skills/web-quality-audit`
- **Autor:** Addy Osmani
- **Licença:** MIT (texto em `LICENSE`)
- **Commit usado:** `afa8da942115f2961fdbfa80807ea0b232ff6c00`
- **Arquivos copiados:** `SKILL.md`, `references/MEASUREMENT.md`

## Mudanças feitas

- no cabeçalho (frontmatter), `name:` passou de `web-quality-audit` para `addy-web-quality-audit`; a descrição ficou igual
- o link para `../performance/references/MEASUREMENT.md` (outra skill do repositório) passou a apontar para a cópia incluída em `references/MEASUREMENT.md`
- nenhuma outra alteração no texto do especialista (mantido em inglês)

## Observações

- `references/MEASUREMENT.md` foi copiado da skill `skills/performance` do mesmo repositório, porque o SKILL.md manda lê-lo

Empacotada para o marketplace do Progress Code em 2026-11-22.

# Aviso de terceiros (NOTICE)

Esta skill é uma cópia adaptada de material de terceiros e é redistribuída sob a licença original. O texto do especialista ficou em inglês, como no original.

- **Origem:** https://github.com/coreyhaines31/marketingskills
- **Caminho no repositório:** `skills/prospecting`
- **Commit:** `5b2b400eec1e7e1cec76245a715d0b0d4fd2a9c1` (baixado em 2026-11-22)
- **Autor:** Corey Haines
- **Licença:** MIT (texto completo em `LICENSE`, copiado de `LICENSE` do repositório)

## Arquivos incluídos

- `SKILL.md` (de `skills/prospecting/SKILL.md`)
- `references/account-research.md` (de `skills/prospecting/references/account-research.md`)
- `references/b2b-prospecting.md` (de `skills/prospecting/references/b2b-prospecting.md`)
- `references/compliance.md` (de `skills/prospecting/references/compliance.md`)
- `references/data-sources.md` (de `skills/prospecting/references/data-sources.md`)
- `references/demand-signals.md` (de `skills/prospecting/references/demand-signals.md`)
- `references/enrichment-playbook.md` (de `skills/prospecting/references/enrichment-playbook.md`)
- `references/local-prospecting.md` (de `skills/prospecting/references/local-prospecting.md`)
- `references/saas-prospecting.md` (de `skills/prospecting/references/saas-prospecting.md`)
- `references/signal-plays.md` (de `skills/prospecting/references/signal-plays.md`)
- `references/sourcing-and-enrichment.md` (de `skills/prospecting/references/sourcing-and-enrichment.md`)
- `LICENSE`

## Mudanças feitas

- Frontmatter: `name: prospecting` trocado por `name: mk-prospecting` (a descrição ficou igual).
- `SKILL.md`: removida a seção "## Tool Integrations" (tabela de links para o registro de ferramentas do repositório original, que não acompanha a skill, com marcações de parceiro e ferramenta do próprio mantenedor).
- `references/data-sources.md`: removida a seção "## Built into a site platform (Ploy ◆)" e a menção "Ploy ◆" na tabela inicial (ferramenta marcada no original como "Verified Partner" do repositório, ou seja, parceria comercial).

## Arquivos do original que não foram incluídos

- `evals/evals.json` (casos de teste do autor, não usados pela skill).

## Observação

O original informa que a ferramenta Truelist, citada como opção de verificação de e-mail no SKILL.md e nas referências, é feita pelo mantenedor do repositório. A citação foi mantida como no original; ela não é recomendação do Progress Code.

---
name: nfe-nfse-cte-xml
description: Lê, valida por schema e monta a estrutura de XML de NF-e/NFS-e/CT-e, consulta status na SEFAZ e gera DANFE em PDF, usando bibliotecas Python (sem instalar programa externo). Use quando o usuário pedir para "ler esse XML de nota fiscal", "validar esse XML de NF-e", "consultar o status dessa nota na SEFAZ", "gerar o DANFE dessa nota", "entender essa chave de acesso".
argument-hint: [NF-e|NFS-e|CT-e] [operação]
---

# NF-e, NFS-e e CT-e: XML e eventos

## Estrutura básica do XML de NF-e (o que procurar)
```xml
<NFe xmlns="http://www.portalfiscal.inf.br/nfe">
  <infNFe Id="NFe35260112345678000199550010000012341234567890" versao="4.00">
    <ide>...</ide>       <!-- identificacao: numero, serie, data emissao, natureza da operacao -->
    <emit>...</emit>      <!-- emitente: CNPJ, razao social, endereco -->
    <dest>...</dest>      <!-- destinatario -->
    <det nItem="1">...</det>  <!-- um por item/produto da nota -->
    <total>...</total>    <!-- valores totais e tributos -->
  </infNFe>
  <Signature>...</Signature>  <!-- assinatura digital, ver skill certificados-digitais-assinatura -->
</NFe>
```
O atributo `Id` do `infNFe` é a **chave de acesso** (44 dígitos): `UF(2) + AAMM(4) + CNPJ(14) + modelo(2) + série(3)
+ número(9) + tipo de emissão(1) + código numérico(8) + dígito verificador(1)`.

## Ler e extrair dados
```python
from lxml import etree

ns = {"nfe": "http://www.portalfiscal.inf.br/nfe"}
arvore = etree.parse("nota.xml")
chave = arvore.find(".//nfe:infNFe", ns).get("Id").replace("NFe", "")
valor_total = arvore.find(".//nfe:total/nfe:ICMSTot/nfe:vNF", ns).text
```
```
pip install lxml
```

## Validar contra o schema XSD (antes de transmitir/aceitar como válido)
```python
schema = etree.XMLSchema(etree.parse("nfe_v4.00.xsd"))  # baixar o XSD da versao correta do layout SEFAZ
if not schema.validate(arvore):
    for erro in schema.error_log:
        print(erro)
```
Os XSDs oficiais (por versão de layout) estão disponíveis no portal da NF-e — confirme a versão exata do layout
usada (`versao="4.00"` no exemplo acima) antes de validar, schema de versão errada rejeita XML válido.

## Consultar status na SEFAZ (Web Service SOAP)
```
pip install zeep
```
```python
from zeep import Client
from zeep.transports import Transport
from requests import Session

sessao = Session()
sessao.cert = ("certificado.pem", "chave_privada.pem")  # certificado A1 do emitente - obrigatorio, sem ele a SEFAZ rejeita
cliente = Client("https://.../NFeConsultaProtocolo4.asmx?wsdl", transport=Transport(session=sessao))
resposta = cliente.service.nfeConsultaNF(...)
```
A URL do web service varia por **UF** e por **ambiente** (produção vs. homologação) — usar a URL errada é o erro
mais comum ao integrar pela primeira vez; confirme ambos antes de qualquer chamada.

## Gerar DANFE (representação em PDF da nota)
```
pip install reportlab
```
Monte o layout do DANFE (não é um padrão XML, é um formato visual definido pelo Manual de Orientação do
Contribuinte) usando `reportlab` para desenhar o PDF a partir dos dados extraídos do XML — inclua o código de
barras Code128 da chave de acesso (ver skill `gerar-qrcode-codigo-barras`) e o QR Code de consulta (para NFC-e).

## NFS-e e CT-e — diferenças principais
- **NFS-e**: **não tem padrão nacional único** até a unificação em andamento (ADN NFS-e) — cada município podia ter
  seu próprio layout de XML e web service; confirme o município e a versão do layout antes de assumir que o
  código de uma prefeitura serve para outra.
- **CT-e**: estrutura similar à NF-e mas para transporte de carga — chave de acesso segue o mesmo formato de 44
  dígitos, schema e web services próprios (`CTeConsultaProtocolo`, etc.).

## Regras
- Nunca transmita um XML sem validar contra o schema correto primeiro — rejeição pela SEFAZ depois de tentar
  transmitir é mais custoso (contador de tentativas, log de erro) que validar antes localmente.
- Certificado digital (A1/A3) é obrigatório para qualquer comunicação com a SEFAZ — ver skill
  `certificados-digitais-assinatura`; nunca tente contornar essa exigência.
- Ambiente de homologação vs. produção: sempre confirme qual o usuário quer usar antes de qualquer transmissão —
  nota emitida em produção por engano tem efeito fiscal real.

## Arquivos desta skill
Nenhum script fixo — os trechos acima cobrem os casos mais comuns; adapte à UF/versão de layout reais do usuário.

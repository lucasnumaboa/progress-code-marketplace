# Aviso de terceiros (NOTICE)

Esta skill é uma cópia adaptada de material de terceiros e é redistribuída sob a licença original. O texto do especialista ficou em inglês, como no original.

- **Origem:** https://github.com/swan-gtm/gtm-skills
- **Caminho no repositório:** `skills/thomas-maitre/hiring-signal-prospecting`
- **Commit:** `eb0026f469f90645e1a64168d08a3e0afb59ee12` (baixado em 2026-11-22)
- **Autor:** Thomas Maitre (autor da skill); copyright do repositório: Swan
- **Licença:** MIT (texto completo em `LICENSE`, copiado de `LICENSE` do repositório)

## Arquivos incluídos

- `SKILL.md` (de `skills/thomas-maitre/hiring-signal-prospecting/SKILL.md`)
- `references/openers.md` (de `skills/thomas-maitre/hiring-signal-prospecting/references/openers.md`)
- `references/reading-the-posting.md` (de `skills/thomas-maitre/hiring-signal-prospecting/references/reading-the-posting.md`)
- `references/signal-table.md` (de `skills/thomas-maitre/hiring-signal-prospecting/references/signal-table.md`)
- `author.md` (de `skills/thomas-maitre/author.md`, crédito do autor pedido pelo repositório)
- `LICENSE`

## Mudanças feitas

- Frontmatter: `name: hiring-signal-prospecting` trocado por `name: swan-hiring-signal-prospecting` (a descrição ficou igual).

## Crédito do autor (author.md)

O repositório pede que o crédito do autor acompanhe a skill. Conteúdo do `author.md` original:

```markdown
---
name: Thomas Maitre
title: "Co-founder, GTM Otto"
linkedinUrl: "https://www.linkedin.com/in/thomasmaitre/"
avatarUrl: https://www.gtmskills.com/authors/thomas-maitre.jpg
companyDomain: gtmotto.com
email: contact@yourshadowai.com
---

Thomas Maitre co-founded GTM Otto, self-driving LinkedIn prospecting that finds buyers daily and warms them up from your own account. His skills encode the LinkedIn-native playbooks that came out of running it for customers: mining comments for intent, turning an ICP into a search, prospecting on hiring signals, staying inside LinkedIn's limits, and writing notes that get replies. Numbers in them are measured on real accounts, not guessed.
```

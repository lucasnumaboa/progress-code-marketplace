# Origem e mudanças

- **Repositório:** https://github.com/coreyhaines31/marketingskills
- **Caminho no repositório:** `skills/cro`
- **Autor:** Corey Haines
- **Licença:** MIT (texto em `LICENSE`)
- **Commit usado:** `5b2b400eec1e7e1cec76245a715d0b0d4fd2a9c1`
- **Arquivos copiados:** `SKILL.md`, `references/experiments.md`, `references/form.md`

## Mudanças feitas

- no cabeçalho (frontmatter), `name:` passou de `cro` para `mk-cro`; a descrição ficou igual
- nenhuma outra alteração no texto do especialista (mantido em inglês)

## Observações

- o SKILL.md cita `references/inbound-routing.md` de outra skill do autor (revops) por link absoluto do GitHub; esse arquivo não faz parte desta skill e não foi copiado

Empacotada para o marketplace do Progress Code em 2026-11-22.

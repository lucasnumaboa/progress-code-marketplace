# Origem e mudanças

- **Repositório:** https://github.com/coreyhaines31/marketingskills
- **Caminho no repositório:** `skills/product-marketing`
- **Autor:** Corey Haines
- **Licença:** MIT (texto em `LICENSE`)
- **Commit usado:** `5b2b400eec1e7e1cec76245a715d0b0d4fd2a9c1`
- **Arquivos copiados:** `SKILL.md`, `references/brand-voice.md`

## Mudanças feitas

- no cabeçalho (frontmatter), `name:` passou de `product-marketing` para `mk-product-marketing`; a descrição ficou igual
- nenhuma outra alteração no texto do especialista (mantido em inglês)

Empacotada para o marketplace do Progress Code em 2026-11-22.

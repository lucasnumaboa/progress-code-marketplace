---
name: analise-seguranca-dependencias
description: Aplica o OWASP Top 10 na revisão de código, roda scanners gratuitos de dependências (pip-audit, npm audit, Semgrep) e define política de atualização de dependências vulneráveis. Use quando o usuário pedir para "revisar isso por segurança", "checar se essas dependências têm vulnerabilidade conhecida", "essa API está exposta a algum risco comum", "criar uma política de atualização de dependências".
argument-hint: [projeto/linguagem a analisar]
---

# Análise de segurança de código e dependências

## OWASP Top 10 — aplicado, não decorado
Ao revisar código, verifique especificamente por:
- **Injeção** (SQL/comando/LDAP): qualquer concatenação de string do usuário direto numa query/comando —
  sempre parâmetros preparados (`cursor.execute(sql, params)`), nunca f-string/`.format()` montando SQL.
- **Autenticação quebrada**: ver skill `autenticacao-autorizacao-apps` (JWT sem validar algoritmo, sessão sem
  expiração, senha com hash fraco).
- **Exposição de dados sensíveis**: segredo em log, resposta de API vazando campo que não deveria (ex.: hash de
  senha, mesmo que hasheado, não precisa ir na resposta de `GET /usuario`).
- **Controle de acesso quebrado**: verificação de permissão só no frontend (ver skill anterior) ou IDOR (trocar o
  `id` na URL/parâmetro e acessar dado de outro usuário sem checagem de posse).
- **Configuração de segurança incorreta**: `DEBUG=True` em produção, CORS liberado para `*` com credenciais,
  headers de segurança ausentes (`Content-Security-Policy`, `X-Frame-Options`).
- **Componentes com vulnerabilidade conhecida**: ver scanners abaixo.
- **SSRF**: aplicação que busca uma URL fornecida pelo usuário (ex.: "baixar imagem desta URL") sem validar que não
  aponta para rede interna (`169.254.169.254`, `localhost`, IPs privados) — pode ser usado para acessar serviços
  internos que não deveriam ser expostos.

## Scanners de dependências (gratuitos, sem instalar programa pesado)
```
pip install pip-audit
pip-audit
```
```
npm audit
npm audit fix   # so aplica correcoes que NAO quebram versao major - revise antes de aceitar mesmo assim
```
```
dotnet list package --vulnerable
```
Todos comparam as dependências do projeto contra bases públicas de vulnerabilidades conhecidas (CVE) — não
detectam vulnerabilidade em código próprio, só em bibliotecas de terceiros.

## Semgrep (SAST gratuito, análise de código próprio)
```
pip install semgrep
semgrep --config auto .
```
Roda regras públicas (incluindo OWASP Top 10 e específicas por linguagem) sobre o código do projeto, procurando
padrões perigosos (SQL concatenado, uso de `eval`, criptografia fraca) sem precisar enviar o código para nuvem se
rodado com `--config` local/offline. Ferramenta leve (instala via pip), diferente de scanners DAST completos.

## DAST (testar a aplicação rodando, não só o código) — ferramenta mais pesada, confirme antes
OWASP ZAP é a opção gratuita mais conhecida para DAST, mas é uma aplicação Java separada para instalar — confirme
com o usuário antes de propor essa instalação; para a maioria das revisões de código deste contexto, SAST
(Semgrep) + scanner de dependências (acima) já cobre a maior parte do valor prático sem precisar dessa instalação
adicional.

## Política de atualização de dependências
Defina com o usuário (não invente sozinho): frequência de checagem (ex.: semanal via CI, ver skill `cicd-pipelines`
para automatizar), critério de urgência (vulnerabilidade crítica/alta = atualizar em dias, não esperar o próximo
ciclo normal), e processo de teste antes de aceitar a atualização (rodar suíte de testes, ver skill
`testes-automatizados-por-stack`, antes de subir a versão nova para produção).

## Regras
- Nunca "corrija" uma vulnerabilidade de dependência só forçando a versão mais nova sem rodar os testes depois —
  atualização de versão major pode quebrar comportamento.
- Reporte achados por severidade (crítico/alto/médio/baixo) com arquivo e linha, e uma correção sugerida — não só
  uma lista de "problemas encontrados" sem priorização.
- Nunca corrija uma vulnerabilidade real encontrada silenciosamente sem informar ao usuário o que era e por que
  importava — ele precisa saber o que estava exposto, mesmo já corrigido.

## Arquivos desta skill
Nenhum script fixo — os comandos acima cobrem os casos mais comuns; adapte à linguagem/projeto reais do usuário.

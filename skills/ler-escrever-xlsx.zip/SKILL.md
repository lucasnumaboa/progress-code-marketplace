---
name: ler-escrever-xlsx
description: Lê e escreve planilhas Excel (.xlsx) diretamente com openpyxl — fórmulas como texto (não valores), formatação condicional, gráficos, congelar painéis, validação de dados (listas suspensas) — sem precisar do Excel instalado. Use quando o usuário pedir para "gerar uma planilha", "ler esse .xlsx e extrair os dados", "adicionar formatação condicional", "criar gráfico na planilha", ou quando não há Excel disponível para abrir de verdade (nesse caso, não confundir com a skill `formulas-excel`, que abre o Excel de verdade via COM para calcular e testar fórmulas ao vivo).
argument-hint: [ler | escrever] [caminho do .xlsx]
---

# Ler e escrever Excel (.xlsx) sem abrir o Excel

## Quando usar openpyxl vs. pandas vs. `formulas-excel`
- **openpyxl** (esta skill): precisa preservar/escrever **fórmulas como texto**, formatação, gráficos, validação de
  dados, ou editar um `.xlsx` existente sem perder o que já está nele. Não calcula fórmulas — só grava o texto
  `=SOMA(A1:A10)`; quem calcula é o Excel quando o arquivo for aberto por um humano.
- **pandas** (`pd.read_excel`/`to_excel`, usa openpyxl por baixo): quando o objetivo é análise/transformação de
  dados tabulares puros, sem se importar com fórmulas ou formatação — mais rápido de escrever para esse caso.
- **`formulas-excel`** (skill separada): quando é preciso o **valor calculado de verdade** de uma fórmula, testar se
  uma função existe numa versão específica do Excel, ou automatizar o Excel de verdade na tela do usuário. Esta
  skill (`ler-escrever-xlsx`) nunca abre o Excel — só lê/escreve o arquivo `.xlsx` como dado.

## Passo 1 — Instalar
```
pip install openpyxl
```

## Passo 2 — Ler
```python
from openpyxl import load_workbook

# data_only=True le o ULTIMO VALOR CALCULADO salvo pelo Excel (fica desatualizado se
# o arquivo nunca foi aberto no Excel depois de editado por script). data_only=False
# (padrao) le a formula como texto.
wb = load_workbook("entrada.xlsx", data_only=True)
ws = wb["Plan1"]
for row in ws.iter_rows(min_row=2, values_only=True):
    print(row)
```
Arquivo grande (dezenas de milhares de linhas): use `read_only=True` em `load_workbook` — evita carregar tudo na
memória, mas desabilita escrita nesse mesmo objeto.

## Passo 3 — Escrever com fórmula, formatação e validação
Use `scripts/exemplo_openpyxl.py` como referência. Pontos-chave:
- Fórmula: `ws["D2"] = "=SOMASE(B:B,\"Sul\",C:C)"` — string começando com `=`, nomes de função em **português** se o
  Excel de destino for pt-BR (openpyxl não traduz; grave exatamente como o Excel do usuário vai exibir).
- Formatação condicional: `from openpyxl.formatting.rule import ColorScaleRule` +
  `ws.conditional_formatting.add("C2:C100", regra)`.
- Gráfico: `from openpyxl.chart import BarChart, Reference` — monte `Reference` para dados e categorias, `chart.add_data(...)`, `ws.add_chart(chart, "F2")`.
- Congelar painéis: `ws.freeze_panes = "A2"` (congela a linha 1).
- Lista suspensa (validação de dados): `from openpyxl.worksheet.datavalidation import DataValidation`,
  `dv = DataValidation(type="list", formula1='"Norte,Sul,Leste,Oeste"')`, `ws.add_data_validation(dv)`,
  `dv.add("B2:B100")`.
- Largura de coluna/altura de linha, número de formato (`cell.number_format = 'R$ #,##0.00'`), congelamento de
  cabeçalho — tudo fica em `ws.column_dimensions`/`ws.row_dimensions`/`cell.number_format`.

## Passo 4 — Editar sem destruir o que já existe
`load_workbook(caminho)` (sem `data_only`) preserva fórmulas, formatação e gráficos existentes ao salvar de volta —
mas **perde** elementos que o openpyxl não entende completamente em arquivos muito complexos (ex.: alguns recursos
de Power Query, slicers, tabelas dinâmicas avançadas). Antes de editar um `.xlsx` de produção, copie para backup
(`shutil.copy2`) e avise o usuário que recursos muito avançados podem não sobreviver ao round-trip.

## Regras
- Nunca grave um valor numérico fixo onde o usuário pediu uma fórmula — a diferença importa (fórmula recalcula se a
  origem mudar; valor fixo não). Se não tiver certeza do que o usuário quer, pergunte.
- Sempre informe ao usuário que fórmulas gravadas por este caminho **não são calculadas** até o arquivo ser aberto
  no Excel — se ele precisa do resultado numérico agora, use a skill `formulas-excel` em vez desta.
- Datas: grave como `datetime.date`/`datetime.datetime` do Python, nunca como string — openpyxl converte para o
  serial de data do Excel automaticamente só quando o valor é um objeto de data real.

## Arquivos desta skill
- `scripts/exemplo_openpyxl.py` — leitura, escrita com fórmula, formatação condicional, gráfico, validação de dados.

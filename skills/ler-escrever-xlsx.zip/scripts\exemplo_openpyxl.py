"""Exemplos de escrita de .xlsx com openpyxl: formula, formatacao condicional,
grafico, painel congelado e validacao de dados (lista suspensa).

Uso:
    python exemplo_openpyxl.py saida.xlsx
"""
import sys
from datetime import date

from openpyxl import Workbook
from openpyxl.chart import BarChart, Reference
from openpyxl.formatting.rule import ColorScaleRule
from openpyxl.worksheet.datavalidation import DataValidation


def gerar(caminho_saida):
    wb = Workbook()
    ws = wb.active
    ws.title = "Vendas"

    ws.append(["Data", "Regiao", "Valor"])
    dados = [
        (date(2026, 1, 5), "Sul", 1200),
        (date(2026, 1, 6), "Norte", 800),
        (date(2026, 1, 7), "Sul", 950),
        (date(2026, 1, 8), "Leste", 400),
    ]
    for linha in dados:
        ws.append(linha)

    # formula (nao calculada por este script - o Excel calcula ao abrir)
    ws["E1"] = "Total Sul"
    ws["E2"] = '=SOMASE(B:B,"Sul",C:C)'

    # formatacao condicional (escala de cor na coluna de valor)
    regra = ColorScaleRule(
        start_type="min", start_color="F8696B",
        end_type="max", end_color="63BE7B",
    )
    ws.conditional_formatting.add("C2:C5", regra)

    # congelar cabecalho
    ws.freeze_panes = "A2"

    # validacao de dados: lista suspensa de regiao
    dv = DataValidation(type="list", formula1='"Norte,Sul,Leste,Oeste"', allow_blank=True)
    ws.add_data_validation(dv)
    dv.add("B2:B100")

    # grafico de barras a partir dos dados
    grafico = BarChart()
    grafico.title = "Vendas por linha"
    dados_ref = Reference(ws, min_col=3, min_row=1, max_row=5)
    categorias_ref = Reference(ws, min_col=2, min_row=2, max_row=5)
    grafico.add_data(dados_ref, titles_from_data=True)
    grafico.set_categories(categorias_ref)
    ws.add_chart(grafico, "G2")

    ws.column_dimensions["A"].width = 12
    ws.column_dimensions["B"].width = 10
    ws.column_dimensions["C"].width = 12
    ws["C2"].number_format = "#,##0.00"

    wb.save(caminho_saida)
    print(f"Gerado: {caminho_saida}")
    print("Lembrete: a formula em E2 so calcula quando o arquivo for aberto no Excel.")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Uso: python exemplo_openpyxl.py saida.xlsx")
        sys.exit(1)
    gerar(sys.argv[1])

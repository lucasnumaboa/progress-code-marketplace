# Origem e mudanças

- **Repositório:** https://github.com/coreyhaines31/marketingskills
- **Caminho no repositório:** `skills/marketing-plan`
- **Autor:** Corey Haines
- **Licença:** MIT (texto em `LICENSE`)
- **Commit usado:** `5b2b400eec1e7e1cec76245a715d0b0d4fd2a9c1`
- **Arquivos copiados:** `SKILL.md`, `references/aarrr-framework.md`, `references/budget-planning.md`, `references/client-types.md`, `references/current-state-rubric.md`, `references/funding-stage-unlocks.md`, `references/growth-patterns.md`, `references/idea-cross-reference.md`, `references/market-sizing.md`, `references/methodology.md`, `references/ops-stack-mapping.md`, `references/plan-template.md`, `references/team-and-agency-model.md`

## Mudanças feitas

- no cabeçalho (frontmatter), `name:` passou de `marketing-plan` para `mk-marketing-plan`; a descrição ficou igual
- nenhuma outra alteração no texto do especialista (mantido em inglês)

Empacotada para o marketplace do Progress Code em 2026-11-22.

---
name: servicos-tarefas-agendadas-windows
description: Cria serviço do Windows, tarefa agendada com gatilhos/credenciais, configura inicialização automática, com log e diagnóstico de falhas — usando só ferramentas embutidas no Windows. Use quando o usuário pedir para "rodar isso como serviço", "fazer esse script iniciar sozinho com o Windows", "por que essa tarefa agendada não roda", "reiniciar automaticamente se cair".
argument-hint: [script/programa] [serviço ou tarefa agendada]
---

# Serviços, tarefas agendadas e inicialização

## Tarefa agendada (para scripts com horário/gatilho, não precisa ficar sempre rodando)
```powershell
$acao = New-ScheduledTaskAction -Execute "python.exe" -Argument "C:\app\rotina.py"
$gatilho = New-ScheduledTaskTrigger -Daily -At "06:00"
$config = New-ScheduledTaskSettingsSet -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 5) -StartWhenAvailable
Register-ScheduledTask -TaskName "Rotina-Diaria" -Action $acao -Trigger $gatilho -Settings $config -User "SISTEMA" -RunLevel Highest
```
`-StartWhenAvailable` roda a tarefa perdida assim que a máquina ligar, se ela estava desligada no horário agendado.
`-User "SISTEMA"` roda sem precisar de senha nem sessão logada — use uma conta de usuário real só se o script
precisar de acesso que a conta SISTEMA não tem (ex.: unidade de rede mapeada por usuário).

## Serviço do Windows (para processo que precisa ficar sempre rodando)
Um `.exe` já preparado como serviço (a maioria dos serviços .NET/Java compilados assim já funciona direto):
```powershell
New-Service -Name "MeuServico" -BinaryPathName "C:\app\servico.exe" -StartupType Automatic
Start-Service -Name "MeuServico"
```
Um script (Python/Node/PowerShell) **não** vira serviço sozinho — scripts não implementam o protocolo de controle
de serviço do Windows. Para isso, é preciso um "wrapper": `NSSM` (Non-Sucking Service Manager) é a ferramenta mais
usada, mas é um **programa externo** a instalar — confirme com o usuário antes de propor isso; a alternativa sem
instalar nada é usar uma **tarefa agendada com gatilho "ao iniciar o sistema"** em vez de um serviço de verdade
(funciona para a maioria dos casos de "rodar sempre", só não tem os recursos avançados de gerenciamento de serviço).

## Alternativa sem NSSM: tarefa agendada "sempre rodando" (gatilho de boot + reinício automático)
```powershell
$gatilho = New-ScheduledTaskTrigger -AtStartup
$config = New-ScheduledTaskSettingsSet -RestartCount 999 -RestartInterval (New-TimeSpan -Minutes 1) -ExecutionTimeLimit ([TimeSpan]::Zero)
Register-ScheduledTask -TaskName "Bot-Sempre-Ativo" -Action $acao -Trigger $gatilho -Settings $config -User "SISTEMA" -RunLevel Highest
```
`-ExecutionTimeLimit ([TimeSpan]::Zero)` remove o limite padrão de 72h de execução (sem isso, o Agendador mata a
tarefa depois de 3 dias rodando, achando que travou).

## Diagnosticar falha
```powershell
Get-ScheduledTaskInfo -TaskName "Rotina-Diaria"     # ultimo resultado de execucao (LastTaskResult 0 = sucesso)
Get-WinEvent -LogName "Microsoft-Windows-TaskScheduler/Operational" -MaxEvents 20
```
`LastTaskResult` diferente de `0` indica falha — o código específico (em hexadecimal) geralmente aponta a causa
(permissão, caminho não encontrado, timeout).

## Regras
- Sempre teste rodando a ação manualmente (`python.exe C:\app\rotina.py`) fora do Agendador antes de agendar — se
  falhar manualmente, vai falhar agendado também, e é muito mais fácil depurar sem a camada do Agendador no meio.
- Conta "SISTEMA" não tem acesso a unidades de rede mapeadas por usuário nem a alguns recursos de perfil — se o
  script precisa disso, use uma conta de usuário real com a senha guardada com segurança (Agendador de Tarefas pede
  a senha na criação, não fica em texto no script).
- Nunca configure reinício automático infinito sem um limite de tempo (`-ExecutionTimeLimit`) — um script que trava
  de verdade (não só demora) reiniciando para sempre mascara o problema em vez de alertar sobre ele.

## Arquivos desta skill
Nenhum script fixo — os comandos acima cobrem os casos mais comuns; adapte ao script/serviço real do usuário.

# Origem e mudanças

- **Repositório:** https://github.com/anthropics/knowledge-work-plugins
- **Caminho no repositório:** `sales/skills/customer-voice`
- **Autor:** Anthropic
- **Licença:** Apache-2.0 (texto em `LICENSE`)
- **Commit usado:** `0e0fcacddcc892eb92a1b7873ff9d68159c47571`
- **Arquivos copiados:** `SKILL.md`

## Mudanças feitas

- no cabeçalho (frontmatter), `name:` passou de `customer-voice` para `kwp-customer-voice`; a descrição ficou igual
- removido o bloco "Rules (apply to every step of this skill)", com as regras de conectores, links e renderização do Claude Cowork (outro produto)
- nenhuma outra alteração no texto do especialista (mantido em inglês)

Empacotada para o marketplace do Progress Code em 2026-11-22.

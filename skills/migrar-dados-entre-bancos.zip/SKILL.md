---
name: migrar-dados-entre-bancos
description: Migra dados entre bancos diferentes (mapeamento de tipos, ordem por dependências de chave estrangeira, carga em lotes, validação de contagens/amostras e plano de rollback). Use quando o usuário pedir para "migrar esses dados do banco X para o Y", "converter esse schema do SQL Server para Postgres", "carregar essa base antiga no sistema novo".
argument-hint: [banco de origem] [banco de destino]
---

# Migrar dados entre bancos

## Passo 1 — Mapear tipos de dados (a fonte mais comum de erro silencioso)
Tipos que "parecem" iguais entre bancos frequentemente não são:
| Conceito | SQL Server | PostgreSQL | MySQL | Progress OpenEdge |
|---|---|---|---|---|
| Texto curto | `varchar(n)` | `varchar(n)` | `varchar(n)` | `character` |
| Texto longo | `nvarchar(max)` | `text` | `text`/`longtext` | `clob` |
| Inteiro | `int` | `integer` | `int` | `integer` |
| Decimal exato | `decimal(p,s)` | `numeric(p,s)` | `decimal(p,s)` | `decimal` |
| Data/hora | `datetime2` | `timestamp` | `datetime` | `datetime-tz` |
| Booleano | `bit` (0/1) | `boolean` (true/false) | `tinyint(1)` (0/1) | `logical` |
Booleano é a armadilha mais comum: migrar `bit`/`tinyint(1)` para `boolean` do Postgres exige conversão explícita
(`CASE WHEN valor = 1 THEN true ELSE false END`), não é automático em toda ferramenta de migração.

## Passo 2 — Ordem de carga por dependência (chaves estrangeiras)
Carregar tabelas na ordem errada falha por violação de FK, ou (pior, se a checagem estiver desabilitada) carrega
dados órfãos silenciosamente. Monte a ordem: tabelas sem FK para outras primeiro (ex.: cadastros básicos:
categoria, país), depois as que referenciam essas, e por último as tabelas "fato" (pedido, item de pedido) que
dependem de tudo antes. Para descobrir a ordem automaticamente a partir do schema:
```sql
-- PostgreSQL: lista dependencias de FK para montar a ordem topologica manualmente
SELECT conname, conrelid::regclass AS tabela, confrelid::regclass AS referencia
FROM pg_constraint WHERE contype = 'f';
```

## Passo 3 — Carga em lotes (não tudo de uma vez)
```python
import pandas as pd

tamanho_lote = 5000
for inicio in range(0, len(df), tamanho_lote):
    lote = df.iloc[inicio:inicio + tamanho_lote]
    lote.to_sql("tabela_destino", conexao_destino, if_exists="append", index=False, method="multi")
    print(f"Carregado: {inicio + len(lote)}/{len(df)}")
```
Lotes menores facilitam retomar de onde parou se algo falhar no meio (não precisa refazer a tabela inteira) e
evitam travar o banco de destino com uma transação gigante.

## Passo 4 — Validar depois de migrar (nunca assumir que "rodou sem erro" = "migrou certo")
```python
origem_count = pd.read_sql("SELECT COUNT(*) FROM tabela_origem", conexao_origem).iloc[0, 0]
destino_count = pd.read_sql("SELECT COUNT(*) FROM tabela_destino", conexao_destino).iloc[0, 0]
assert origem_count == destino_count, f"Contagem nao bate: {origem_count} vs {destino_count}"
```
Além da contagem total, compare uma **amostra de valores** (soma de uma coluna numérica, alguns registros
específicos por chave conhecida) — contagem igual não garante que os valores migraram corretos (ex.: truncamento
de decimal, data com fuso errado).

## Passo 5 — Plano de rollback
Antes de migrar para um banco que já tem dados (não é uma carga inicial em banco vazio), garanta um jeito de
voltar atrás: backup do destino antes da carga, ou uma transação que englobe tudo (se o volume permitir) com
`ROLLBACK` disponível se a validação do passo 4 falhar.

## Regras
- Nunca migre para produção sem antes migrar para um ambiente de teste e validar completamente.
- Sempre confirme o mapeamento de tipos "estranhos" (booleano, enum, campos calculados) com o usuário antes de
  assumir uma conversão automática — é onde a maioria dos bugs de migração aparece.
- Reportar ao final: quantas linhas por tabela, quanto tempo levou, e o resultado da validação de contagem/amostra
  — não só "migração concluída".

## Arquivos desta skill
Nenhum script fixo — os trechos acima cobrem o fluxo completo; adapte ao par de bancos/schema reais do usuário.

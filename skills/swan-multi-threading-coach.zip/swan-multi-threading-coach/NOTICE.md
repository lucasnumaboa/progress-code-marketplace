# Aviso de terceiros (NOTICE)

Esta skill é uma cópia adaptada de material de terceiros e é redistribuída sob a licença original. O texto do especialista ficou em inglês, como no original.

- **Origem:** https://github.com/swan-gtm/gtm-skills
- **Caminho no repositório:** `skills/gal-aga/multi-threading-coach`
- **Commit:** `eb0026f469f90645e1a64168d08a3e0afb59ee12` (baixado em 2026-11-22)
- **Autor:** Gal Aga (autor da skill); copyright do repositório: Swan
- **Licença:** MIT (texto completo em `LICENSE`, copiado de `LICENSE` do repositório)

## Arquivos incluídos

- `SKILL.md` (de `skills/gal-aga/multi-threading-coach/SKILL.md`)
- `author.md` (de `skills/gal-aga/author.md`, crédito do autor pedido pelo repositório)
- `LICENSE`

## Mudanças feitas

- Frontmatter: `name: multi-threading-coach` trocado por `name: swan-multi-threading-coach` (a descrição ficou igual).

## Crédito do autor (author.md)

O repositório pede que o crédito do autor acompanhe a skill. Conteúdo do `author.md` original:

```markdown
---
name: Gal Aga
avatarUrl: "https://www.gtmskills.com/authors/gal-aga.jpg"
title: "Co-Founder & CEO @ Aligned"
linkedinUrl: "https://linkedin.com/in/galaga"
companyDomain: alignedup.com
---

Co-Founder & CEO of Aligned, the AI deal workspace used by 70K sellers and a million buyers a month to run B2B deals — fresh off a $60M Series B led by PeakSpan Capital ($73.8M raised in total). A serial sales leader before founding Aligned: CRO at Anagog, VP Global Sales at Syte, and Director of Sales at Sisense.
```

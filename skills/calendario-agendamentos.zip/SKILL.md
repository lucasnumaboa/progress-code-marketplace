---
name: calendario-agendamentos
description: Cria convites de calendário (.ics, funciona em qualquer cliente) com fuso horário correto e recorrência, ou usa a Graph API para ler a agenda do Outlook 365 e achar horários livres. Use quando o usuário pedir para "gerar um convite de reunião", "criar um evento recorrente", "achar um horário livre na agenda", "mandar um .ics por e-mail".
argument-hint: [participantes] [data/hora] [recorrência, se houver]
---

# Calendário e agendamentos (.ics, Graph)

## Arquivo .ics (funciona em qualquer cliente de e-mail/calendário, sem API)
```python
from icalendar import Calendar, Event
from datetime import datetime
import pytz

cal = Calendar()
cal.add("prodid", "-//Minha Empresa//Agenda//PT-BR")
cal.add("version", "2.0")

evento = Event()
evento.add("summary", "Reunião de alinhamento")
fuso = pytz.timezone("America/Sao_Paulo")
evento.add("dtstart", fuso.localize(datetime(2026, 3, 10, 14, 0)))
evento.add("dtend", fuso.localize(datetime(2026, 3, 10, 15, 0)))
evento.add("location", "Sala 3 / Teams")
evento["uid"] = "reuniao-2026-03-10-14h@minhaempresa.com"  # unico e ESTAVEL - reenviar o mesmo UID atualiza o evento existente em vez de criar um novo
cal.add_component(evento)

with open("convite.ics", "wb") as f:
    f.write(cal.to_ical())
```
```
pip install icalendar pytz
```
**Fuso horário é a causa nº 1 de reunião marcada na hora errada.** Sempre use um horário "aware" (com fuso
explícito via `pytz`/`zoneinfo`), nunca `datetime` "naive" (sem fuso) — um `.ics` sem fuso correto é interpretado
de forma diferente em cada cliente de calendário.

## Recorrência
```python
evento.add("rrule", {"freq": "weekly", "byday": ["MO", "WE"], "count": 10})
```
`RRULE` segue o padrão iCalendar (RFC 5545) — `freq` (`daily`/`weekly`/`monthly`/`yearly`), `interval`, `count` (nº
de ocorrências) ou `until` (data final), `byday` para dias da semana específicos.

## Enviar o .ics por e-mail (para aparecer como convite, não só anexo)
O `.ics` precisa ser anexado com `Content-Type: text/calendar; method=REQUEST` para o cliente de e-mail do
destinatário reconhecer como convite clicável (Aceitar/Recusar), não só um arquivo qualquer:
```python
from email.mime.text import MIMEText
parte_ics = MIMEText(cal.to_ical().decode("utf-8"), "calendar;method=REQUEST")
msg.attach(parte_ics)
```

## Graph API — ler agenda e achar horário livre (Outlook 365)
```python
resp = requests.post(
    "https://graph.microsoft.com/v1.0/me/findMeetingTimes",
    headers={"Authorization": f"Bearer {token}"},
    json={
        "attendees": [{"emailAddress": {"address": "colega@empresa.com"}}],
        "timeConstraint": {"timeslots": [{"start": {"dateTime": "2026-03-10T09:00:00", "timeZone": "E. South America Standard Time"}, "end": {"dateTime": "2026-03-10T18:00:00", "timeZone": "E. South America Standard Time"}}]},
        "meetingDuration": "PT1H",
    },
)
```
Graph usa nomes de fuso horário do Windows (`"E. South America Standard Time"` para horário de Brasília), não IANA
(`America/Sao_Paulo`) — atenção a essa diferença ao integrar com bibliotecas Python que usam IANA.

## Regras
- Sempre confirme fuso horário quando participantes estiverem em locais diferentes — nunca assuma que "14h" é óbvio
  para todos.
- `uid` do evento: gere de forma determinística e estável se a intenção é permitir atualizar o mesmo evento depois
  (reenviar com UID diferente cria um evento duplicado em vez de atualizar).
- Recorrência com `until` em vez de `count` quando a regra de negócio é "até tal data", não "por N vezes" — evita
  ter que recalcular quantas ocorrências cabem manualmente.

## Arquivos desta skill
Nenhum script fixo — os trechos acima cobrem os casos mais comuns; adapte ao evento/fuso reais do usuário.

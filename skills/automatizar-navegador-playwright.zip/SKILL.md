---
name: automatizar-navegador-playwright
description: Automatiza navegador de verdade (abrir sites, login, preencher formulários, baixar arquivos, esperar elementos, screenshots) com Playwright — instala sozinho (Python + navegadores) se ainda não estiver presente na máquina. Use quando o usuário pedir para "automatizar esse site", "fazer login e extrair dados de uma página com JavaScript pesado", "baixar um arquivo que só aparece depois de clicar em algo" — para páginas simples sem JavaScript, prefira a skill `web-scraping-estruturado` (mais leve, não precisa de navegador).
argument-hint: [site] [ação: navegar|login|preencher|baixar|screenshot]
---

# Automatizar navegador com Playwright

## Passo 0 — Verificar se já está instalado
```
python -c "import playwright; print(playwright.__version__)"
```
Se der erro (`ModuleNotFoundError`), instale automaticamente antes de continuar:
```
pip install playwright
playwright install chromium
```
`playwright install chromium` baixa só o Chromium (~150-200MB) — mais leve que baixar os três navegadores
(`playwright install` sem argumento baixa Chromium+Firefox+WebKit, ~350-400MB). Só baixe Firefox/WebKit também se
o usuário precisar testar especificamente naquele motor. Avise o usuário que essa etapa (download do navegador)
pode levar alguns minutos na primeira vez.

## Passo 1 — Abrir uma página e esperar carregar de verdade
```python
from playwright.sync_api import sync_playwright

with sync_playwright() as p:
    navegador = p.chromium.launch(headless=True)  # headless=False para acompanhar visualmente
    pagina = navegador.new_page()
    pagina.goto("https://exemplo.com", wait_until="networkidle")
    pagina.screenshot(path="tela.png")
    navegador.close()
```
`wait_until="networkidle"` espera a página parar de fazer requisições — mais confiável que `time.sleep()` fixo
para páginas que carregam conteúdo via JavaScript depois do HTML inicial.

## Passo 2 — Seletores robustos (a causa mais comum de script quebrar)
```python
# EVITE: seletor por posição/classe CSS gerada (muda a cada build do site)
pagina.click(".css-1a2b3c")

# PREFIRA: por texto visível, papel semântico, ou atributo estavel (data-testid, name, id)
pagina.get_by_role("button", name="Entrar").click()
pagina.get_by_label("E-mail").fill("usuario@exemplo.com")
pagina.locator("[data-testid='botao-salvar']").click()
```
Classes CSS geradas por ferramentas de build (`.css-1a2b3c`, `.sc-bdVaJa`) mudam a cada deploy do site — nunca
dependa delas; prefira texto visível, `role`, `label` ou atributos estáveis.

## Passo 3 — Login e reaproveitar sessão (não logar de novo a cada execução)
```python
contexto = navegador.new_context(storage_state="sessao.json" if os.path.exists("sessao.json") else None)
pagina = contexto.new_page()
if not os.path.exists("sessao.json"):
    pagina.goto("https://exemplo.com/login")
    pagina.get_by_label("Usuário").fill(usuario)
    pagina.get_by_label("Senha").fill(senha)
    pagina.get_by_role("button", name="Entrar").click()
    contexto.storage_state(path="sessao.json")  # salva cookies/sessao para reaproveitar depois
```

## Passo 4 — Esperar elemento específico (não `time.sleep` cego)
```python
pagina.wait_for_selector("text=Carregamento concluído", timeout=10000)
elemento = pagina.locator("#resultado")
elemento.wait_for(state="visible")
```

## Passo 5 — Baixar arquivo
```python
with pagina.expect_download() as download_info:
    pagina.get_by_role("button", name="Baixar relatório").click()
download = download_info.value
download.save_as("relatorio.pdf")
```

## Passo 6 — Tratamento de popups/diálogos inesperados
```python
pagina.on("dialog", lambda dialog: dialog.accept())  # aceita alert/confirm automaticamente
```

## Regras
- Nunca guarde senha em texto no script — ver skill `gerenciar-segredos-windows`.
- Sempre rode `headless=False` (visível) na primeira vez que automatizar um site novo, para conferir visualmente
  que os seletores estão certos, antes de rodar `headless=True` em produção/lote.
- Site com captcha: não tente contornar — pare e avise o usuário, é uma barreira colocada de propósito.
- `storage_state` (sessão salva) expira — trate falha de elemento esperado após login salvo como possível sessão
  vencida, refaça o login nesse caso.

## Arquivos desta skill
Nenhum script fixo — os trechos acima cobrem os casos mais comuns; adapte ao site real do usuário.

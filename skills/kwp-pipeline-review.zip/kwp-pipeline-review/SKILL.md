---
name: kwp-pipeline-review
description: Stage-by-stage pipeline health check - coverage, aging, conversion, and at-risk deals - from CRM opportunity data. Use when the user asks "review my pipeline", "pipeline health", "where's my pipeline stuck", "weekly pipeline review", "which deals should I focus on this week", "any stale or stuck deals", "which deals have past close dates", "which deals are single-threaded", or "check my pipeline coverage against my number".
argument-hint: "<segment or rep>"
---

# Pipeline Review

Analyze the user's open pipeline by stage: how
much is where, what's aging, what's at risk.

## Tools used

| Tool type | Used for | Required? |
|---|---|---|
| crm | open pipeline + 2 quarters of closed for baselines | no (files fallback: uploaded pipeline export) |

Read-only throughout; fixes hand off to the the skills that make changes (update-opportunity, log-activity and others).

## Inputs

Scope - "my pipeline" (default - current user as owner), a named rep,
or a team; period - current quarter (default) or a close-date range.

## Step 1 - Ground

Check which tools are connected (plus any org facts the user or the project instructions already gave). Ground pipeline stage definitions + exit
criteria, field names, and average deal size / cycle length (for
coverage math) from the live crm schema and org context (inferred from what is connected or uploaded; if the answer depends on a fact no one has given, ask ONE question, use the answer for this conversation and suggest adding it to the project instructions; otherwise use a clearly labeled default and continue). Link every record referenced; quote values as
read. Empty personal scope: fail fast and ask, never silently widen.

## Step 2 - Pull opportunities

From the CRM: open opps in scope closing this period (stage,
amount, close date, created date, next step, last activity, owner,
type), ordered by stage and close date. Also the last 2 quarters of
closed opps (stage, won/lost, amount, dates) for conversion baselines.

## Step 3 - Stage rollup

Per stage (using the org's own stage names): count and $ sum; average
age in stage (stage-entry history where the CRM exposes it,
created-date age otherwise - say which); count with blank next step;
count with no activity in 14+ days.

## Step 4 - Risk flags

Flag opps that hit any of:

- **Stale:** no activity in 14+ days (threshold tuned to the cycle)
- **Slipping:** close date in the past, or moved out 2+ times (if
  history is available)
- **Blank next step**
- **Stuck:** in current stage 2x longer than that stage's median
- **Single-threaded:** only one contact with activity (where contact
  roles are modeled)

Org-specific rules from org context (e.g. "no security review by late
stage") join the flag set when known.

## Step 5 - Coverage check

Total weighted pipeline vs. quota (if the user provides one or org
context carries it) or vs. same-period-last-quarter. Standard
heuristic: 3x coverage of the remaining gap; note if under.

## Step 6 - Output

One artifact (per the rendering rule above). Summary (open count and $, weighted $, coverage vs the 3x bar, at-risk
count and $); by-stage table (stage, count, $, avg age, stale count,
blank-next-step count); at-risk deals table (account, stage, $, close,
flags, suggested action, and a link that opens the deal's crm record -
working from files, the export file with its sheet and row - per the
links rule above); conversion signal from the 2-quarter baseline
(stage-to-stage rates, win rate, median cycle); and recommended focus
(highest-$ at-risk deal + action, the stage with most stuck deals,
coverage gap action if under). Fixes apply through `update-opportunity`
or the crm hygiene flow - this skill only reads.


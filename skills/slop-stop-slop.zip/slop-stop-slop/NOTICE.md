# Origem

Skill de especialista empacotada para o marketplace do Progress Code (id `slop-stop-slop`).

- Repositório: https://github.com/hardikpandya/stop-slop
- Caminho: `(raiz do repositório)`
- Autor: Hardik Pandya
- Detentor do copyright no arquivo de licença: Hardik Pandya
- Licença: MIT (texto completo em `LICENSE`, copiado de `LICENSE` no repositório)
- Commit: `8da1f030185bdfe8471220585162991eaeb970e9` (baixado em 2026-11-22)

## Arquivos incluídos

- `SKILL.md` (de `SKILL.md`)
- `references/examples.md` (de `references/examples.md`)
- `references/phrases.md` (de `references/phrases.md`)
- `references/structures.md` (de `references/structures.md`)

## Mudanças feitas

1. Frontmatter: `name:` trocado de `stop-slop` para `slop-stop-slop` (a descrição foi mantida).

O texto do especialista foi mantido em inglês, sem tradução.

## Não incluído

- `README.md` e `CHANGELOG.md` do repositório (não são usados pela skill).

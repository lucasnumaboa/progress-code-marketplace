---
name: instalar-software-ambientes
description: Instala software e gerencia ambientes de desenvolvimento no Windows via winget (já embutido no Windows moderno), com versões lado a lado (nvm, pyenv) e PATH por usuário vs. máquina. Use quando o usuário pedir para "instalar o Python/Node/Git", "preciso de duas versões do Node ao mesmo tempo", "esse programa não aparece no PATH depois de instalar".
argument-hint: [programa a instalar] [versão, se relevante]
---

# Instalar software e ambientes

## winget (já vem com Windows 10 21H2+/11 — preferir a este em vez de Chocolatey/Scoop)
```powershell
winget search nome-do-programa
winget install --id Git.Git
winget install --id Python.Python.3.12
winget upgrade --all
```
Só proponha Chocolatey (`choco`) ou Scoop se o usuário já os tiver instalados, ou se o pacote específico não
existir no repositório do winget — ambos exigem um passo de instalação próprio (bootstrap via script), então não
introduza essa dependência a mais sem necessidade.

## Confirmar que instalou e está no PATH
Depois de instalar, **abra um novo terminal** (o PATH só é recarregado em processos novos) e confirme:
```powershell
Get-Command git -ErrorAction SilentlyContinue
git --version
```
Se não achar, o instalador pode ter colocado o binário num caminho que não entrou automaticamente no PATH — some
instaladores exigem reiniciar a sessão ou até a máquina para propagar variável de ambiente de sistema.

## Versões lado a lado — Python (pyenv-win)
```powershell
winget install --id pyenv-win.pyenv-win
pyenv install 3.11.8
pyenv install 3.12.3
pyenv local 3.11.8   # define a versao para a pasta do projeto atual (grava .python-version)
```

## Versões lado a lado — Node.js (nvm-windows, não confundir com nvm do Linux/Mac, são projetos diferentes)
```powershell
winget install --id CoreyButler.NVMforWindows
nvm install 20.11.0
nvm install 18.19.0
nvm use 20.11.0
```

## PATH por usuário vs. por máquina
```powershell
[Environment]::GetEnvironmentVariable("PATH", "User")     # so para o usuario atual
[Environment]::GetEnvironmentVariable("PATH", "Machine")   # para todos os usuarios, precisa de admin para alterar
```
Alterar o PATH de "Machine" exige privilégio de administrador; alterar o de "User" não. Prefira "User" a menos que
o programa precise estar disponível para todos os usuários da máquina (ex.: serviço rodando com outra conta).

## Regras
- Sempre confirme a versão exata antes de instalar quando o usuário mencionar uma (ex.: "Python 3.11" pode
  significar qualquer patch 3.11.x — pergunte se uma versão específica importa, como para compatibilidade de
  projeto).
- Nunca rode instalador com `-y`/silencioso em algo que muda configuração do sistema sem avisar o usuário do que
  está sendo instalado.
- Depois de instalar uma ferramenta nova, sempre valide com `--version` antes de seguir para o próximo passo que
  depende dela — não assuma que a instalação funcionou só porque o comando não retornou erro.

## Arquivos desta skill
Nenhum script fixo — os comandos acima cobrem os casos mais comuns; adapte ao programa/versão reais pedidos.

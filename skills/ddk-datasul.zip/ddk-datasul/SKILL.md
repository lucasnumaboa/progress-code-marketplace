---
name: ddk-datasul
description: Referência do DDK clássico do TOTVS Datasul (Datasul Development Kit - templates AppBuilder/ADM1 e SmartObjects), levantada num framework real. Diz quais templates de tela existem e como reconhecer cada um (w-cadsim, w-cadcom, w-paifil, w-paiamb, w-incsim, w-relat, w-pesqui, d-vapara), quais includes existem e com que argumentos são chamados, as procedures internas de viewer, query, browser, containers e painéis com assinatura, os botões e ícones dos painéis (im-/ii-), tamanhos e cores padrão de tela, as variáveis globais do ut-glob.i e do i-rpvar.i com tipo, eventos e parâmetros de UPC/EPC, e as APIs utapi033 (Excel), ut-msgs, ut-acomp e ut-liter. Use sempre que for escrever, alterar ou revisar tela ou programa Progress do Datasul e surgir dúvida do tipo "qual include", "qual procedure chamar", "esse evento de UPC existe", "qual ícone", "que tamanho tem o botão", "qual o tipo dessa variável global", "como é a assinatura", em vez de responder de memória.
---

# DDK clássico do Datasul: referência

Referência para consulta, no estilo de um índice técnico: procure o item no
arquivo certo, em vez de afirmar de memória. O DDK é o motivo mais comum de
erro "plausível" em programa Datasul: nome de include quase certo, procedure
que não existe, variável global com tipo diferente do que o prefixo sugere.

## Como ler: toda informação tem origem

Os includes do DDK (`ddk/include`, `ddk/method`, `ddk/src/adm`) são
**criptografados**. Não dá para ler o que fazem. O que está aqui veio de cinco
origens, e cada arquivo diz qual usou:

| Marca | Origem | Confiança |
|---|---|---|
| **[fonte]** | Fonte legível do framework (painéis, `utapi033.p`, programas do produto) | Alta: é o código |
| **[exec]** | Objeto carregado em execução (`INTERNAL-ENTRIES`, `GET-SIGNATURE`) | Alta para nome e parâmetros; não diz o que a procedure faz |
| **[sonda]** | Sonda de compilação (existe a variável? de que tipo?) | Alta para existência e tipo; não diz o conteúdo |
| **[uso]** | Contagem de como os programas legíveis usam o item | Mostra a prática; não é norma |
| **[doc]** | Documentação pública (TDN oficial, ou cópia não oficial de manual de 2007, marcada) | Oficial: alta. Não oficial: confira |

Regra de uso: ao responder com base nesta skill, diga a origem quando ela
importa ("pela sonda, é CHARACTER"; "o manual de 2007 diz, não conferi em
execução"). Se o item não está em nenhum arquivo, **não está comprovado**:
diga isso e proponha como comprovar (seção "Como comprovar o que falta").

## Onde procurar

| Pergunta | Arquivo |
|---|---|
| Qual template é este programa? Quais existem? Que painéis cada um carrega? Como os objetos se ligam? | [templates.md](references/templates.md) |
| Este include existe? Com que argumentos é chamado? | [includes.md](references/includes.md) |
| Esta procedure existe no viewer / query / browser / container / painel? Com quais parâmetros? | [api-objetos.md](references/api-objetos.md) |
| Qual ícone usar? Quais botões tem cada painel? | [paineis-icones.md](references/paineis-icones.md) |
| Que tamanho tem janela, botão, campo? Cores, fontes, menu e atalhos? | [padroes-tela.md](references/padroes-tela.md) |
| Que variáveis globais existem e de que tipo? | [variaveis.md](references/variaveis.md) |
| Parâmetros, eventos e cadastro de UPC/EPC | [upc-eventos.md](references/upc-eventos.md) |
| `ut-msgs`, `ut-acomp`, `utapi033`, `utapi019`, `ut-liter`, login | [utilitarios.md](references/utilitarios.md) |
| O que a documentação diz: função de cada template e include, regras de relatório, zoom, nomenclatura, padrões de interface | [documentacao-publica.md](references/documentacao-publica.md) |

`documentacao-publica.md` é o maior (mais de mil linhas, com índice por
seção): procure pelo termo com busca em vez de ler inteiro. Os demais têm
tabelas; busque pelo nome do include, da procedure ou do ícone.

## Fatos que mais evitam erro

- **Fonte Datasul é CP850**, não UTF-8. [fonte]
- **`i-ep-codigo-usuario` e `v_cdn_empres_usuar` são CHARACTER**, apesar do
  nome. `c-seg-usuario` é o usuário logado. [sonda]
- **`c-dir-spool-servid-exec` não vem do `i-rpvar.i`**: quem usa precisa
  declarar como `NEW GLOBAL SHARED`. `i-num-ped-exec-rpw` vem do `ut-glob.i` e
  do `i-rpvar.i`. [sonda] [fonte]
- **`utp/ut9000.i` antes do `dispatch ('initialize')`** em `local-initialize`;
  depois dele a UPC só recebe `CHANGE-PAGE`. [doc oficial] [uso]
- **O ícone vai sem extensão e em par**: `image\im-xxx` (habilitado) e
  `image\ii-xxx` (desabilitado). Nem todo `im-` tem `ii-`. [fonte]
- **`i-rpcab.i &stream="str-rp"`**, mas **`i-rpout.i` e `i-rpclo.i`
  `&stream="stream str-rp"`**. [uso] [doc]
- **`tt-param` idêntica na tela e no `rp.p`**: é passada por `RAW-TRANSFER`.
  [doc] [uso]
- **Botão de texto `10 BY 1`; botão de ícone `4 BY 1.25`; `FILL-IN` altura
  `.88`; janela de cadastro com 90 de largura.** [uso] [doc]
- **Dois DDKs**: o clássico (`include/w-*.i`, SmartObjects) e o ThinTemplate
  (`masterdetail/`, `maintenance/`, `window/`, `report/`, `zoom/`). Veja qual o
  programa usa antes de mexer; esta referência cobre o clássico. [uso]

## Como comprovar o que falta

Quando a resposta não estiver aqui, meça em vez de supor. Os dois scripts
rodam em qualquer sessão Progress com o framework no PROPATH e os bancos
conectados (sandbox Datasul ou ambiente do cliente). Só leem e compilam.

**Uma variável existe num include? De que tipo?**
`scripts/sonda-include.p`: informe o include e um arquivo com os nomes
candidatos (um por linha). Saída `nome;tipo`. Só acha o que estiver na lista
de candidatos.

**Uma procedure existe num objeto? Com quais parâmetros?**
`scripts/entradas.p`: informe o programa (SmartObject, painel ou API
persistente). Saída `nome|assinatura`. Rode um programa por sessão.

**Que eventos um programa dispara para a UPC? Como se chamam os widgets?**
UPC de log (modelo na skill `progress-templates`,
`templates/upc/upc/estpl-upc-log.p`).

**Como um include é usado na prática?**
Procure no catálogo de fontes (skill `progress-admin`) um programa do produto
que o use; `includes.md` e `templates.md` dão nomes de exemplo.

**O que um include faz por dentro?**
Não dá: está criptografado, e o XREF da compilação não traz nada do que está
dentro dele (testado: só aparecem as entradas do fonte que o inclui). Vale a
documentação, quando existe, e o comportamento observado em teste.

## Limites desta referência

- Levantada em 20/11/2026 num framework Datasul local (OpenEdge 12.8), o mesmo
  dos sandboxes. Versão de cliente pode ter includes e procedures a mais ou a
  menos: na dúvida, rode os scripts no ambiente dele.
- Das 943 variáveis candidatas sondadas, só as que os programas legíveis usam
  entraram na lista. Não é a lista completa do que cada include define.
- Container `w-paifil`, browser de cadastro e tela `w-relat` não tiveram as
  procedures levantadas (ver o fim de `api-objetos.md`).
- A descrição "o que cada template/include faz" depende de documentação; boa
  parte vem de cópia não oficial de manual de 2007, e 48 itens não foram
  encontrados em lugar nenhum (lista no fim de `documentacao-publica.md`).
- Significado de cada ícone: só está levantado para os usados em painéis e
  nos programas lidos. O catálogo completo é só de nomes.

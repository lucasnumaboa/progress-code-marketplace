/*------------------------------------------------------------------------------
  sonda-include.p - Descobre quais variaveis um include define, e o tipo de
  cada uma, sem ler o fonte do include (que pode estar criptografado).

  Metodo: para cada nome candidato, compila um programa minimo com o include e
  uma atribuicao do nome. Compilou com o include e nao compila sem ele: a
  variavel vem do include. O tipo sai de qual atribuicao tipada compila.

  Rodar numa sessao com o include no PROPATH e os bancos de que ele depende
  conectados (o ut-glob.i precisa do emsfnd). So compila: nao grava nada alem
  dos arquivos de trabalho na pasta corrente.

  Trocar as tres variaveis abaixo, ou passar -param "include|candidatos|saida".
    cInclude    include e argumentos, como iria entre chaves
    cCandidatos arquivo texto com um nome candidato por linha
    cSaida      arquivo de resultado: "nome;tipo" por linha

  Limite: so acha nome que esta na lista de candidatos. Tipo "outro" = a
  variavel existe, mas nao e character, logical, date, handle, integer nem
  decimal (pode ser rowid, raw, memptr...).
------------------------------------------------------------------------------*/
DEFINE VARIABLE cInclude    AS CHARACTER NO-UNDO INITIAL "utp/ut-glob.i".
DEFINE VARIABLE cCandidatos AS CHARACTER NO-UNDO INITIAL "candidatos.txt".
DEFINE VARIABLE cSaida      AS CHARACTER NO-UNDO INITIAL "sonda.txt".
DEFINE VARIABLE cCand       AS CHARACTER NO-UNDO.
DEFINE VARIABLE cTipo       AS CHARACTER NO-UNDO.

DEFINE STREAM sIn.
DEFINE STREAM sOut.
DEFINE STREAM sP.

FUNCTION fnCompila RETURNS LOGICAL (INPUT pcInc AS CHARACTER, INPUT pcCorpo AS CHARACTER):
    OUTPUT STREAM sP TO VALUE("sonda-tmp.p").
    IF pcInc <> "" THEN PUT STREAM sP UNFORMATTED "~{" pcInc "~}" SKIP.
    PUT STREAM sP UNFORMATTED
        "DEFINE VARIABLE zz-c AS CHARACTER NO-UNDO." SKIP
        "DEFINE VARIABLE zz-l AS LOGICAL NO-UNDO." SKIP
        "DEFINE VARIABLE zz-d AS DATE NO-UNDO." SKIP
        "DEFINE VARIABLE zz-h AS HANDLE NO-UNDO." SKIP
        "DEFINE VARIABLE zz-i AS INTEGER NO-UNDO." SKIP
        "DEFINE VARIABLE zz-n AS DECIMAL NO-UNDO." SKIP
        pcCorpo SKIP.
    OUTPUT STREAM sP CLOSE.
    COMPILE VALUE("sonda-tmp.p") NO-ERROR.
    RETURN NOT COMPILER:ERROR.
END FUNCTION.

/* a sessao do Datasul ja tem o seu -param: so aceita o formato com dois "|" */
IF NUM-ENTRIES(SESSION:PARAMETER, "|") = 3 THEN
    ASSIGN cInclude    = ENTRY(1, SESSION:PARAMETER, "|")
           cCandidatos = ENTRY(2, SESSION:PARAMETER, "|")
           cSaida      = ENTRY(3, SESSION:PARAMETER, "|").

OUTPUT STREAM sOut TO VALUE(cSaida).

IF NOT fnCompila(cInclude, "") THEN DO:
    PUT STREAM sOut UNFORMATTED "INCLUDE NAO COMPILA SOZINHO" SKIP.
    OUTPUT STREAM sOut CLOSE.
    RETURN.
END.

INPUT STREAM sIn FROM VALUE(cCandidatos).
REPEAT:
    IMPORT STREAM sIn UNFORMATTED cCand.
    IF cCand = "" THEN NEXT.

    /* existe com o include? */
    IF NOT fnCompila(cInclude, "ASSIGN zz-c = STRING(" + cCand + ").") THEN NEXT.
    /* existe tambem sem o include? entao nao vem dele */
    IF fnCompila("", "ASSIGN zz-c = STRING(" + cCand + ").") THEN NEXT.

    ASSIGN cTipo = "outro".
    IF      fnCompila(cInclude, "ASSIGN zz-c = " + cCand + ".")          THEN cTipo = "character".
    ELSE IF fnCompila(cInclude, "ASSIGN zz-l = " + cCand + ".")          THEN cTipo = "logical".
    ELSE IF fnCompila(cInclude, "ASSIGN zz-d = " + cCand + ".")          THEN cTipo = "date".
    ELSE IF fnCompila(cInclude, "ASSIGN zz-h = " + cCand + ".")          THEN cTipo = "handle".
    ELSE IF fnCompila(cInclude, "ASSIGN zz-i = " + cCand + " MODULO 2.") THEN cTipo = "integer".
    ELSE IF fnCompila(cInclude, "ASSIGN zz-n = " + cCand + " + 0.")      THEN cTipo = "decimal".

    PUT STREAM sOut UNFORMATTED cCand ";" cTipo SKIP.
END.
INPUT STREAM sIn CLOSE.
OUTPUT STREAM sOut CLOSE.

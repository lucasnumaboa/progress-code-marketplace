/*------------------------------------------------------------------------------
  entradas.p - Lista as procedures e funcoes internas de um programa em
  execucao, com a assinatura de cada uma. Mostra tambem o que vem de include
  criptografado, porque le o objeto carregado (INTERNAL-ENTRIES e
  GET-SIGNATURE), nao o fonte.

  Serve para: saber se uma procedure existe num SmartObject, painel ou API
  antes de chamar, e com quais parametros.

  Rodar numa sessao com o programa no PROPATH e os bancos conectados. O
  programa e carregado em modo PERSISTENT e apagado em seguida. Use so com
  objeto que possa ser carregado sem parametros e sem efeito colateral:
  SmartObjects, paineis e APIs persistentes. Programa que executa algo no
  bloco principal vai executar.

  Trocar cLista (programas separados por virgula) e cSaida, ou passar
  -param "lista=a.w,b.p".

  Saida: uma linha "## programa entradas=N" e depois "nome|assinatura".
  Assinatura: TIPO,retorno,parametros (formato do GET-SIGNATURE).

  Um programa por sessao e mais seguro: se um deles derrubar a sessao (pedido
  de login, erro de classe), os outros nao se perdem.
------------------------------------------------------------------------------*/
DEFINE VARIABLE cLista AS CHARACTER NO-UNDO INITIAL "panel/p-navega.w".
DEFINE VARIABLE cSaida AS CHARACTER NO-UNDO INITIAL "entradas.txt".
DEFINE VARIABLE cEnt   AS CHARACTER NO-UNDO.
DEFINE VARIABLE i      AS INTEGER   NO-UNDO.
DEFINE VARIABLE j      AS INTEGER   NO-UNDO.
DEFINE VARIABLE h      AS HANDLE    NO-UNDO.

DEFINE STREAM s.

/* a sessao do Datasul ja tem o seu -param: so aceita com o prefixo */
IF SESSION:PARAMETER BEGINS "lista=" THEN
    ASSIGN cLista = SUBSTRING(SESSION:PARAMETER, 7).

OUTPUT STREAM s TO VALUE(cSaida).
DO i = 1 TO NUM-ENTRIES(cLista):
    ASSIGN h = ?.
    RUN VALUE(ENTRY(i, cLista)) PERSISTENT SET h NO-ERROR.
    IF NOT VALID-HANDLE(h) THEN DO:
        PUT STREAM s UNFORMATTED "## " ENTRY(i, cLista) " NAO CARREGOU: " ERROR-STATUS:GET-MESSAGE(1) SKIP.
        NEXT.
    END.
    ASSIGN cEnt = h:INTERNAL-ENTRIES.
    PUT STREAM s UNFORMATTED "## " ENTRY(i, cLista) " entradas=" NUM-ENTRIES(cEnt) SKIP.
    DO j = 1 TO NUM-ENTRIES(cEnt):
        PUT STREAM s UNFORMATTED ENTRY(j, cEnt) "|" h:GET-SIGNATURE(ENTRY(j, cEnt)) SKIP.
    END.
    DELETE PROCEDURE h NO-ERROR.
END.
OUTPUT STREAM s CLOSE.

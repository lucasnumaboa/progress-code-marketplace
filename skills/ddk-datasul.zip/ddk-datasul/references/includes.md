# Includes do DDK e do framework: como são chamados

Levantamento de 20/11/2026. Cada linha é um include **existente no framework local** e usado por pelo menos dois fontes legíveis. `cripto` = fonte criptografado (não dá para ler o conteúdo; vale o uso observado). A coluna de argumentos mostra as formas mais comuns em que o include é chamado.

Para saber o que um include **define** (variáveis), veja `variaveis.md`. Para a função descrita na documentação, veja `documentacao-publica.md`.

## Relatório (`include/i-rp*.i`)

| Include | Pasta | Fonte | Programas (padrão / projeto) | Argumentos vistos |
|---|---|---|---|---|
| `include/i-rpvar.i` | ddk | cripto | 12 / 7 | - |
| `include/i-rpcab.i` | ddk | cripto | 9 / 6 | &stream="str-rp" |
| `include/i-rpout.i` | ddk | cripto | 9 / 5 | &stream="stream str-rp" \|\| &STREAM="stream str-rp" &TOFILE=tt-param.arquivo |
| `include/i-rpclo.i` | ddk | cripto | 9 / 5 | &stream="stream str-rp" \|\| &STREAM="stream str-rp" |
| `include/i-rpexc.i` | ddk | cripto | 10 / 3 | - |
| `include/i-rptrm.i` | ddk | cripto | 10 / 3 | - |
| `include/i-rplbl.i` | ddk | cripto | 10 / 3 | - |
| `include/i-rpexa.i` | ddk | cripto | 10 / 3 | - |
| `include/i-rpexb.i` | ddk | cripto | 10 / 3 | - |
| `include/i-rparq.i` | ddk | cripto | 10 / 3 | - |
| `include/i-rprun.i` | ddk | cripto | 10 / 3 | &ProgramaRP=v-cod-prog-i-rprun \|\| men/men705rp.p \|\| men/men706rp.p |
| `include/i-rprse.i` | ddk | cripto | 10 / 3 | - |
| `include/i-rpimp.i` | ddk | cripto | 10 / 3 | - |
| `include/i-rpini.i` | ddk | cripto | 4 / 3 | - |
| `include/i-rptrp.i` | ddk | cripto | 4 / 3 | - |
| `include/i-rpmbl.i` | ddk | cripto | 3 / 3 | - |

## Importação (`include/i-im*.i`)

| Include | Pasta | Fonte | Programas (padrão / projeto) | Argumentos vistos |
|---|---|---|---|---|
| `include/i-implan.i` | ddk | cripto | 5 / 8 | <programa de implantação> <handle do browse1 de zoom> <handle do brows \|\| men/men011aa.w h_b01fn088 h_b02fn088 |

## EPC / UPC (`include/i-epc*.i`, `i_*epc*.i`)

| Include | Pasta | Fonte | Programas (padrão / projeto) | Argumentos vistos |
|---|---|---|---|---|
| `include/i-epc102.i` | fnd | cripto | 133 / 0 | proced_consult_proced \|\| agenda_rpw \|\| configur_propried |
| `include/i-epc101.i` | fnd | cripto | 131 / 0 | proced_consult_proced b_old_proced_consult_proced \|\| agenda_rpw b_old_agenda_rpw \|\| configur_propried b-old-configur_propried |
| `include/i-epc200.i` | fnd | cripto | 23 / 2 | fnc_executar_programa \|\| det_ped_exec \|\| "cd0119" |
| `include/i-epc201.i` | fnd | cripto | 16 / 0 | "detalhepedido" \|\| "Fim-Config-Pedidos" \|\| "Conexao-bases" |
| `include/i-epc200.i2` | fnd | cripto | 5 / 0 | &CodEvent = '"detalhepedido"' &CodParameter = '"numeropedido"' &ValueP \|\| &CodEvent='"Fim-Config-Pedidos"' &CodParameter='"rowid-config-pai"' &V \|\| &CodEvent='"Conexao-bases"' &CodParameter=p_cod_banco &ValueParameter= |
| `include/i-epc020.i` | ddk | cripto | 2 / 0 | - |

## ADM (`src/adm/...`)

| Include | Pasta | Fonte | Programas (padrão / projeto) | Argumentos vistos |
|---|---|---|---|---|
| `src/adm/template/row-head.i` | ddk | cripto | 115 / 63 | - |
| `src/adm/template/row-end.i` | ddk | cripto | 115 / 63 | - |
| `src/adm/method/containr.i` | ddk | cripto | 90 / 33 | - |
| `src/adm/template/windowmn.i` | ddk | cripto | 57 / 22 | - |
| `src/adm/template/snd-head.i` | ddk | cripto | 42 / 32 | - |
| `src/adm/template/snd-end.i` | ddk | cripto | 42 / 32 | - |
| `src/adm/template/snd-list.i` | ddk | cripto | 42 / 32 | "prog_dtsul" \|\| "estabelec" \|\| "procedimento" |
| `src/adm/template/bstates.i` | ddk | cripto | 25 / 11 | - |
| `src/adm/method/browser.i` | ddk | cripto | 25 / 11 | - |
| `src/adm/template/brsleave.i` | ddk | cripto | 25 / 11 | - |
| `src/adm/template/brsentry.i` | ddk | cripto | 25 / 11 | - |
| `src/adm/template/brschnge.i` | ddk | cripto | 25 / 11 | - |
| `src/adm/template/sndkytop.i` | ddk | cripto | 20 / 12 | - |
| `src/adm/template/sndkycas.i` | ddk | cripto | 20 / 12 | "idi_dtsul" "prog_dtsul" "idi_dtsul" \|\| "cod_proced" "prog_dtsul" "cod_proced" \|\| "cod_prog_dtsul" "prog_dtsul" "cod_prog_dtsul" |
| `src/adm/template/sndkyend.i` | ddk | cripto | 20 / 12 | - |
| `src/adm/template/row-get.i` | ddk | cripto | 15 / 13 | - |
| `src/adm/template/row-find.i` | ddk | cripto | 15 / 13 | "prog_dtsul" \|\| "estabelec" \|\| "item" |
| `src/adm/template/row-list.i` | ddk | cripto | 15 / 13 | "prog_dtsul" \|\| "estabelec" \|\| "item" |
| `src/adm/template/dialogmn.i` | ddk | cripto | 18 / 8 | - |
| `src/adm/template/vstates.i` | ddk | cripto | 8 / 10 | - |
| `src/adm/method/viewer.i` | ddk | cripto | 8 / 10 | - |
| `src/adm/template/qstates.i` | ddk | cripto | 3 / 10 | - |
| `src/adm/method/query.i` | ddk | cripto | 3 / 10 | - |
| `src/adm/method/panel.i` | ddk | cripto | 7 / 0 | - |
| `src/adm/template/pustates.i` | ddk | cripto | 5 / 0 | - |
| `src/adm/support/admhlp.i` | ddk | legivel | 3 / 0 | - |
| `src/adm/template/pnstates.i` | ddk | cripto | 2 / 0 | - |

## Utilitários (`utp/`)

| Include | Pasta | Fonte | Programas (padrão / projeto) | Argumentos vistos |
|---|---|---|---|---|
| `utp/ut-glob.i` | fnd | cripto | 193 / 75 | - |
| `utp/ut-liter.i` | fnd | cripto | 239 / 1 | "Mensagem_nr" * \|\| "Programa_Mensagem" * \|\| "não_encontrado" * |
| `utp/ut9000.i` | fnd | cripto | 89 / 34 | "esxx109" "3.00.00.000" \|\| "esxx109a" "3.00.00.000" \|\| "dlg_empres_usuar_configur" "2.00.00.000" |
| `utp/ut-table.i` | fnd | cripto | 25 / 8 | mguni {&TABLE-NAME \|\| movind moeda 1 \|\| emsfnd {&TableName |
| `utp/ut-field.i` | fnd | cripto | 29 / 0 | mguni {&TABLE-NAME \|\| mguni unid-feder pais 1 \|\| mguni unid-feder estado 1 |
| `utp/utlog-defs.i` | fnd | cripto | 9 / 0 | - |
| `utp/utlog-message.i` | fnd | cripto | 8 / 0 | 17 6 E \|\| 17 6 B \|\| 17 6 B YES |
| `utp/utapi009.i` | fnd | cripto | 6 / 0 | - |
| `utp/ut0666.i` | fnd | cripto | 5 / 0 | - |
| `utp/ut-rdset.i` | fnd | cripto | 4 / 0 | rs-tipo * \|\| rs-configura * \|\| rs-compr-fabric |
| `utp/ut-gerdoc.i` | fnd | cripto | 4 / 0 | - |
| `utp/ut-indicador-tabela.i` | fnd | cripto | 3 / 0 | - |
| `utp/ut-http-api.i` | fnd | cripto | 3 / 0 | - |
| `utp/ut-win.i` | fnd | legivel | 2 / 0 | - |

## Métodos e DBO (`method/`)

| Include | Pasta | Fonte | Programas (padrão / projeto) | Argumentos vistos |
|---|---|---|---|---|
| `method/dbotterr.i` | ddk | cripto | 21 / 5 | - |
| `method/dbo.i` | ddk | cripto | 24 / 0 | - |
| `method/dboqry.i` | ddk | cripto | 24 / 0 | - |
| `method/svc/errors/inserr.i` | ddk | cripto | 21 / 0 | &ErrorNumber="190" &ErrorType="EMS" &ErrorSubType="ERROR" \|\| &ErrorNumber="56274" &ErrorType="CRM" &ErrorSubType="ERROR" &ErrorPara \|\| &ErrorNumber = 4241 &ErrorType = "EMS" &ErrorSubType = "ERROR" &ErrorP |
| `method/zoomreposition.i` | ddk | cripto | 11 / 0 | &ProgramZoom="inzoom/z04in245.w" \|\| &ProgramZoom="inzoom\z27in172.w" \|\| &ProgramZoom="dizoom/z02di189.w" |
| `method/referencefields.i` | ddk | cripto | 4 / 0 | &HandleDBOLeave="h-bocx110" &FindMethod="findCodigo" &KeyValue1="integ \|\| &HandleDBOLeave="h-boin245-leave" &KeyValue1="input frame fPage2 f-cod \|\| &HandleDBOLeave="h-boin245-leave" &KeyValue1="input frame fPage2 tt-na |
| `method/showmessage.i1` | ddk | cripto | 4 / 0 | - |
| `method/showmessage.i2` | ddk | cripto | 4 / 0 | &Modal="yes" \|\| &modal="yes" |
| `method/svc/autentic/autentic.i` | ddk | cripto | 3 / 0 | &vUserCountryTax="i-pais-usuario" \|\| &vUserName="v_cod_usuar_corren" \|\| &vUserName="c-seg-usuario" |
| `method/zoomfields.i` | ddk | cripto | 3 / 0 | &ProgramZoom="inzoom/z04in245.w" &FieldZoom1="nat-operacao" &FieldScre \|\| &ProgramZoom="dizoom/z01di616.w" &FieldZoom1="cod-clas-fisc" &FieldScr \|\| &ProgramZoom="cdp/cd0620-z01.w" &FieldZoom1="cod-cfop" &FieldScreen1=" |

## Templates e SmartObjects

| Include | Pasta | Fonte | Programas (padrão / projeto) | Argumentos vistos |
|---|---|---|---|---|
| `include/c-brwzoo.i` | ddk | cripto | 19 / 8 | - |
| `include/w-cadsim.i` | ddk | cripto | 13 / 6 | - |
| `include/c-viewer.i` | ddk | cripto | 8 / 10 | - |
| `include/d-dialog.i` | ddk | cripto | 17 / 0 | - |
| `include/w-pesqui.i` | ddk | cripto | 8 / 8 | - |
| `include/c-query.i` | ddk | cripto | 3 / 10 | - |
| `include/w-relat.i` | ddk | cripto | 10 / 3 | - |
| `include/w-cadcom.i` | ddk | cripto | 11 / 0 | - |
| `include/w-incsim.i` | ddk | cripto | 8 / 2 | - |
| `include/d-vapara.i` | ddk | cripto | 1 / 8 | - |
| `include/w-window.i` | ddk | cripto | 5 / 3 | - |
| `include/w-paiamb.i` | ddk | cripto | 5 / 0 | - |
| `include/c-brows3.i` | ddk | cripto | 3 / 2 | - |
| `include/c-browse.i` | ddk | cripto | 3 / 1 | - |
| `include/w-paifil.i` | ddk | cripto | 1 / 2 | - |
| `include/w-incmdp.i` | ddk | cripto | 3 / 0 | - |
| `include/w-livre.i` | ddk | cripto | 1 / 1 | - |

## Demais includes de `include/`

| Include | Pasta | Fonte | Programas (padrão / projeto) | Argumentos vistos |
|---|---|---|---|---|
| `include/i-prgvrs.i` | fnd | cripto | 651 / 80 | V99XX999 9.99.99.999 \|\| B99XX999 9.99.99.999 \|\| Q99XX999 9.99.99.999 |
| `include/i-license-manager.i` | fnd | cripto | 197 / 45 | <programa> <módulo> \|\| esxx0108 MPD \|\| <programa> MUT |
| `include/i_dbtype.i` | fnd | cripto | 223 / 7 | - |
| `include/i_dbinst.i` | fnd | cripto | 206 / 1 | - |
| `include/i_fcldef.i` | fnd | cripto | 145 / 1 | - |
| `include/i_fclfrm.i` | fnd | cripto | 130 / 1 | f_dlg_01_des_anot_tab \|\| f_dlg_01_ac_ult_atualiz \|\| D-Dialog |
| `include/sobre5.i` | fnd | cripto | 111 / 1 | - |
| `include/title5.i` | fnd | cripto | 110 / 1 | wh_w_program \|\| f_ran_01_generic FRAME \|\| f_dlg_01_fnc_import_msg_lit FRAME |
| `include/ajuda.i` | ddk | cripto | 80 / 27 | - |
| `include/i-logfin.i` | ddk | cripto | 73 / 30 | - |
| `include/sobre.i` | ddk | cripto | 55 / 27 | - |
| `include/win-size.i` | ddk | cripto | 56 / 24 | - |
| `include/i_prdvers.i` | fnd | cripto | 45 / 0 | - |
| `include/i_fnctrad.i` | fnd | cripto | 45 / 0 | - |
| `include/i_trddef.i` | fnd | legivel | 41 / 1 | - |
| `include/i-ctrlrp5.i` | ddk | legivel | 35 / 0 | bas_plano_ccusto_fin \|\| bas_ccusto_fin \|\| sea_portador_financ_emit |
| `include/i_dbvers.i` | fnd | cripto | 30 / 1 | - |
| `include/i-vldfrm.i` | ddk | cripto | 8 / 9 | - |
| `include/i-valid.i` | ddk | cripto | 7 / 9 | - |
| `include/zoomvar.i` | fnd | cripto | 11 / 4 | &prog-zoom=adzoom/z01ad103.w &campo=tt-natur-oper.cod-esp &campozoom=c \|\| &prog-zoom=adzoom/z01ad176.w &campo=tt-natur-oper.cod-mensagem &campoz \|\| &prog-zoom=adzoom/z01ad259.w &campo=tt-natur-oper.tp-rec-desp &campozo |
| `include/i_fclwin.i` | fnd | cripto | 13 / 1 | wh_w_program \|\| wh_w_toolbar |
| `include/i-vldprg.i` | ddk | cripto | 5 / 9 | - |
| `include/i-inifld.i` | ddk | cripto | 11 / 0 | - |
| `include/i_framevers.i` | fnd | cripto | 9 / 0 | - |
| `include/i_trdmnu.i` | ddk | cripto | 7 / 1 | wh_w_program:menubar \|\| "menu m_help:handle" |
| `include/bocomver.i` | ddk | cripto | 7 / 0 | - |
| `include/bofind.i` | ddk | cripto | 7 / 0 | - |
| `include/bovaldel.i` | ddk | cripto | 7 / 0 | - |
| `include/bosetcur.i` | ddk | cripto | 7 / 0 | - |
| `include/bovalupt.i` | ddk | cripto | 7 / 0 | - |
| `include/boexedel.i` | ddk | cripto | 7 / 0 | - |
| `include/boexecre.i` | ddk | cripto | 7 / 0 | - |
| `include/bonav.i` | ddk | cripto | 7 / 0 | - |
| `include/boexeupt.i` | ddk | cripto | 7 / 0 | - |
| `include/bosersen.i` | ddk | cripto | 7 / 0 | - |
| `include/boini.i` | ddk | cripto | 7 / 0 | - |
| `include/bogetcur.i` | ddk | cripto | 7 / 0 | - |
| `include/bostrmet.i` | ddk | cripto | 7 / 0 | - |
| `include/boprebro.i` | ddk | cripto | 7 / 0 | - |
| `include/bogetver.i` | ddk | cripto | 7 / 0 | - |
| `include/boendmet.i` | ddk | cripto | 7 / 0 | - |
| `include/salvafil.i` | ddk | cripto | 5 / 2 | h_v02fn049 \|\| h_v01fn082 \|\| h_v01fn134 |
| `include/cancefil.i` | ddk | cripto | 5 / 2 | - |
| `include/okfil.i` | ddk | cripto | 5 / 2 | h_v02fn049 \|\| h_v01fn082 \|\| h_v01fn134 |
| `include/i-freeac.i` | ddk | cripto | 6 / 0 | - |
| `include/i-anykey.i` | ddk | cripto | 6 / 0 | &variavel=c-ini-pais \|\| &variavel=c-ini-uf \|\| &variavel=c-inicial |
| `include/i-license-server.i` | fnd | cripto | 5 / 0 | - |
| `include/leave.i` | ddk | cripto | 5 / 0 | &tabela=usuar_mestre &atributo-ref=nom_usuario &variavel-ref=v_nom_usu \|\| &tabela=prog_dtsul &atributo-ref=des_prog_dtsul &variavel-ref=v_des_pr \|\| &tabela=tt-pais &atributo-ref=nome-pais &variavel-ref=cDescPais &where |
| `include/boerrtab.i` | ddk | cripto | 4 / 0 | - |
| `include/i-frm010.i` | ddk | cripto | 3 / 0 | - |
| `include/i-frm185.i` | ddk | cripto | 3 / 0 | - |
| `include/i-frm167.i` | ddk | cripto | 3 / 0 | - |
| `include/i-frm157.i` | ddk | cripto | 3 / 0 | - |
| `include/i-frm165.i` | ddk | cripto | 3 / 0 | - |
| `include/i-frm170.i` | ddk | cripto | 3 / 0 | - |
| `include/i-frm020.i` | ddk | cripto | 3 / 0 | - |
| `include/i-frm180.i` | ddk | cripto | 3 / 0 | - |
| `include/i-frm175.i` | ddk | cripto | 3 / 0 | - |
| `include/i-frm160.i` | ddk | cripto | 3 / 0 | - |
| `include/logexporttospreadsheet.i` | fnd | cripto | 3 / 0 | - |
| `include/getdefinedfunction.i` | ddk | cripto | 3 / 0 | - |
| `include/i-vrtab.i` | ddk | cripto | 3 / 0 | proces_menu \|\| estabelec |
| `include/rowid.i` | ddk | cripto | 1 / 2 | - |
| `include/cancepai.i` | ddk | cripto | 3 / 0 | - |
| `include/salvapai.i` | ddk | cripto | 3 / 0 | h_v02fn003 \|\| h_v02fn088 \|\| h_v01fn143 |
| `include/okpai.i` | ddk | cripto | 3 / 0 | h_v02fn003 \|\| h_v02fn088 \|\| h_v01fn143 |
| `include/i-win.i` | ddk | cripto | 3 / 0 | - |
| `include/i_cdrel_hr.i` | ddk | cripto | 3 / 0 | - |
| `include/i-frm040.i` | ddk | cripto | 2 / 0 | - |
| `include/i-frm190.i` | ddk | cripto | 2 / 0 | - |
| `include/i-frm055.i` | ddk | cripto | 2 / 0 | - |
| `include/i-frm195.i` | ddk | cripto | 2 / 0 | - |
| `include/i-frm145.i` | ddk | cripto | 2 / 0 | - |
| `include/i-frm150.i` | ddk | cripto | 2 / 0 | - |
| `include/i-frm155.i` | ddk | cripto | 2 / 0 | - |
| `include/i_fcldef5.i` | fnd | cripto | 2 / 0 | - |
| `include/i_fclfrm5.i` | fnd | cripto | 2 / 0 | f_ran_01_generic |
| `include/i_fcldin5.i` | fnd | cripto | 2 / 0 | v_wgh_fill_in_ini \|\| v_wgh_fill_in_fim |
| `include/tt-edit.i` | ddk | cripto | 2 / 0 | - |
| `include/pdf_func.i` | fnd | legivel | 2 / 0 | h_PDFinc \|\| pCallProc |
| `include/pdfglobal.i` | fnd | legivel | 2 / 0 | "SHARED" |
| `include/i-ctrlrp.i` | fnd | cripto | 2 / 0 | fnc_prog_dtsul_ext_tip_relat \|\| fnc_prog_dtsul_ext_pdf |
| `include/confdel.i` | ddk | cripto | 2 / 0 | - |

## Outras pastas

| Include | Pasta | Fonte | Programas (padrão / projeto) | Argumentos vistos |
|---|---|---|---|---|
| `cdp/cdcfgdis.i` | fnd | cripto | 28 / 2 | - |
| `crmapi/versaocrm.i` | fnd | legivel | 17 / 0 | - |
| `cdp/cdcfgmat.i` | fnd | cripto | 16 / 0 | - |
| `cdp/cdcfgfin.i` | fnd | legivel | 14 / 0 | - |
| `varinc/var00002.i` | fnd | cripto | 14 / 0 | 07 \|\| 04 tt-param.destino |
| `crmbo/defaults.i` | fnd | cripto | 13 / 0 | - |
| `btb/btb008za.i2` | fnd | cripto | 9 / 0 | inbo/boin245.p '' {&hDBOTable \|\| inbo/boin245.p '' h-boin245-leave \|\| dibo/bodi232.p '' h-bodi232 |
| `btb/btb008za.i1` | fnd | cripto | 9 / 0 | inbo/boin245.p \|\| dibo/bodi232.p \|\| adbo/boad176.p |
| `btb/btb431za.i` | fnd | cripto | 7 / 0 | - |
| `sec/seapi004aa.i` | fnd | cripto | 7 / 0 | - |
| `fninc/i01fn103.i` | fnd | cripto | 7 / 0 | 04 2 \|\| 04 1 \|\| 04 3 |
| `btb/btb912zc.i4` | fnd | cripto | 5 / 0 | - |
| `btb/btb962za.i` | fnd | cripto | 5 / 0 | - |
| `cdp/cdapi531.i1` | fnd | legivel | 5 / 0 | "ADM025" "YES" \|\| "ADM013" "YES" \|\| "ADM035" "YES" |
| `cdp/cd0666.i` | fnd | legivel | 5 / 0 | - |
| `adecomm/okbar.i` | fnd | legivel | 5 / 0 | &TOOL = "ADM" &CONTEXT = {&SmartBrowser_Attributes_Dlg_Box \|\| &TOOL = "ADM" &CONTEXT = {&SmartNavPanel_Attributes_Dlg_Box \|\| &TOOL = "ADM" &CONTEXT = {&SmartQuery_Attributes_Dlg_Box |
| `fninc/i02fn103.i` | fnd | cripto | 4 / 0 | 04 11 \|\| 04 12 \|\| 04 13 |
| `btb/btb009za.i` | fnd | cripto | 4 / 0 | - |
| `btb/btb034aa.i` | fnd | cripto | 4 / 0 | - |
| `btb/btb912rest.i2` | fnd | cripto | 4 / 0 | - |
| `fwk/utils/errorhandler.i` | fnd | cripto | 4 / 0 | - |
| `cdp/cdcfgman.i` | fnd | legivel | 4 / 0 | - |
| `prghur/fpp/fpefd518.i` | fnd | legivel | 4 / 0 | - |
| `utils/validateminmaxlength.i` | fnd | legivel | 4 / 0 | nom_campanha 0 40 "descrição da campanha" \|\| nom_natur_operac 1 40 "nome" \|\| des_oportun_vda 0 40 "descrição da oportunidade" |
| `fwk/properties/propservices.i` | fnd | cripto | 4 / 0 | - |
| `fninc/i01fn088.i` | fnd | cripto | 4 / 0 | 03 \|\| 02 \|\| 04 tt_procedimento.int-1 |
| `men/men702dd.i` | fnd | legivel | 3 / 0 | - |
| `cdp/cd1234.i` | fnd | legivel | 3 / 0 | - |
| `cdp/cdcfgcex.i` | fnd | legivel | 3 / 0 | - |
| `cdp/cd9768.i` | fnd | legivel | 3 / 0 | - |
| `cdp/cd9043.i` | fnd | legivel | 3 / 0 | - |
| `cdp/cdapi558.i` | fnd | legivel | 3 / 0 | &ProdutoEstendido=20 &ModuloEstendido=MIM \|\| &ProdutoEstendido=20 &ModuloEstendido=MEX |
| `cdp/cdapi558.i1` | fnd | legivel | 3 / 0 | - |
| `prghur/spp/busca_parametro_progress.i` | fnd | legivel | 3 / 0 | - |
| `men/mer008.i` | fnd | legivel | 3 / 0 | - |
| `men/men906za.i` | fnd | legivel | 3 / 0 | - |
| `men/men906za.i1` | fnd | legivel | 3 / 0 | - |
| `prghur/dop/eng012.i` | fnd | cripto | 3 / 0 | - |
| `prghur/spp/smart_esocial_conexao.i` | fnd | legivel | 3 / 0 | - |
| `prghur/spp/smart_esocialtt.i` | fnd | legivel | 3 / 0 | - |
| `prghur/fpp/fpefd517-2.i` | fnd | legivel | 3 / 0 | - |
| `unbrw/b01un197.i` | fnd | cripto | 3 / 0 | 1 d01 \|\| 2 d02 \|\| 3 d03 |
| `xmlinc/eai-logger.i` | fnd | legivel | 3 / 0 | - |
| `xmlinc/ttconfig.i` | fnd | legivel | 3 / 0 | - |
| `prgtec/btb/btb912zc.i2` | fnd | cripto | 2 / 0 | - |
| `fwk/rpw/datautils.i` | fnd | cripto | 2 / 0 | - |
| `fwk/rpw/metodos_parametros.i` | fnd | cripto | 2 / 0 | - |
| `btb/jobschedulerapi.i` | fnd | cripto | 2 / 0 | - |
| `office/office.i` | fnd | legivel | 2 / 0 | Excel ch-Excel \|\| Excel v-ch-Excel |
| `cdp/cd1234.i2` | fnd | legivel | 2 / 0 | - |
| `cdp/cd9000.i` | fnd | legivel | 2 / 0 | - |
| `btb/btb008za.i0` | fnd | cripto | 2 / 0 | - |
| `adinc/i02ad049.i` | ddk | legivel | 2 / 0 | 03 p-modulo \|\| 4 cod-finalidade |
| `cdp/cdapi090def.i` | fnd | legivel | 2 / 0 | - |
| `cdp/cdapi1001.i` | fnd | legivel | 2 / 0 | - |
| `cdp/cdapi1100.i` | fnd | legivel | 2 / 0 | - |
| `adinc/i03ad209.i` | ddk | legivel | 2 / 0 | 4 tt_emitente_integr_new.modalidade \|\| 4 mgadm.emitente.modalidade \|\| 04 emitente.modalidade |
| `crmbo/bocrmvers.i` | fnd | legivel | 2 / 0 | VersionPersistent \|\| RowObject |
| `crmbo/bocrmtabpreco.i` | fnd | legivel | 2 / 0 | RowObject \|\| tt-crm_tab_preco |
| `fnbo/bofn027.i` | fnd | cripto | 2 / 0 | ttUsuarGrpUsuar \|\| RowObject |
| `fnbo/bofn069.i` | fnd | cripto | 2 / 0 | ttGrpUsuar \|\| RowObject |
| `fnbo/bofn017.i` | fnd | cripto | 2 / 0 | ttUsuarMestre \|\| RowObject |
| `fnbo/bofn030.i` | fnd | cripto | 2 / 0 | ttUsuarMestreExt \|\| RowObject |
| `fnbo/bofn167.i` | fnd | cripto | 2 / 0 | RowObject \|\| tt-idioma |
| `fninc/i01fn068.i` | fnd | legivel | 2 / 0 | 04 1 \|\| 04 prog_dtsul.idi_template \|\| 04 27 |
| `fwk/rpw/def_parametros.i` | fnd | cripto | 2 / 0 | - |
| `fwk/rpw/selecoes.i` | fnd | cripto | 2 / 0 | - |
| `men/men8750.i` | fnd | legivel | 2 / 0 | - |
| `men/men705rp.i` | fnd | legivel | 2 / 0 | - |
| `men/men706rp.i` | fnd | legivel | 2 / 0 | - |
| `men/mer010aa.i` | fnd | legivel | 2 / 0 | - |
| `prghur/fpp/fp9200.i` | fnd | cripto | 2 / 0 | - |
| `adm/support/admhlp.i` | ddk | legivel | 2 / 0 | - |
| `unbrw/b06un197.i` | fnd | cripto | 2 / 0 | 01 \|\| 02 \|\| 03 |
| `adinc/i01ad276.i` | ddk | legivel | 2 / 0 | 05 \|\| 04 iCont \|\| 04 idPaisImposto |

## Inventário: o que existe no DDK local

Nomes de arquivo, para saber se um include existe antes de usar. Existir aqui não diz o que ele faz.

**`ddk/include`** (326 arquivos): `ajuda.i`, `boautonum.i`, `bocomver.i`, `boendmet.i`, `boerrtab.i`, `boexecre.i`, `boexedel.i`, `boexeupt.i`, `bofind.i`, `bofindsh.i`, `bogetcur.i`, `bogetver.i`, `boini.i`, `bonav.i`, `boprebro.i`, `bosersen.i`, `bosetcur.i`, `bostrmet.i`, `bovaldel.i`, `bovalupt.i`, `c-broker.i`, `c-brows2.i`, `c-brows3.i`, `c-brows4.i`, `c-brows5.i`, `c-browse.i`, `c-brwfrm.i`, `c-brwupd.i`, `c-brwzoo.i`, `c-page.i`, `c-query.i`, `c-viewer.i`, `cancefil.i`, `cancepai.i`, `confdel.i`, `d-dialog.i`, `d-vapara.i`, `defttwdk.i`, `f-valid.i`, `getdefinedfunction.i`, `i-anykey.i`, `i-auxtab.i`, `i-countds.i`, `i-ctrlrp5.i`, `i-epcNNN.i` (000 a 052, 53 arquivos), `i-estab-openquery.i`, `i-estab-security.i`, `i-extra.i`, `i-fnextvers.i`, `i-freeac.i`, `i-frmNNN.i` (010 a 195, 18 arquivos), `i-func-dtype.i`, `i-func.i`, `i-getentryfield.i`, `i-imarq.i`, `i-imclo.i`, `i-imdef.i`, `i-imedl.i`, `i-iment.i`, `i-imexa.i`, `i-imexb.i`, `i-imexc.i`, `i-imimp.i`, `i-imini.i`, `i-imlbl.i`, `i-immbl.i`, `i-imout.i`, `i-implan.i`, `i-imrse.i`, `i-imrun.i`, `i-imtrm.i`, `i-imtrp.i`, `i-imvrf.i`, `i-inifld.i`, `i-inispl.i`, `i-logfin.i`, `i-logfin1.i`, `i-logini.i`, `i-mft-epc200.i`, `i-mft-epc201.i`, `i-progr.i`, `i-rparq.i`, `i-rpc255.i`, `i-rpcab.i`, `i-rpcb80.i`, `i-rpclo.i`, `i-rpent.i`, `i-rpexa.i`, `i-rpexb.i`, `i-rpexc.i`, `i-rpfch.i`, `i-rpimp.i`, `i-rpini.i`, `i-rplbl.i`, `i-rpmbl.i`, `i-rpout.i`, `i-rprcd.i`, `i-rprse.i`, `i-rprun.i`, `i-rprun2.i`, `i-rpsvd.i`, `i-rptrm.i`, `i-rptrp.i`, `i-rpvar.i`, `i-setentryfield.i`, `i-spell.i`, `i-strNNN.i` (050 a 995, 93 arquivos), `i-sysvar.i`, `i-tab.i`, `i-trdmn.i`, `i-trswin.i`, `i-ultatu.i`, `i-valid.i`, `i-vldfrm.i`, `i-vldprg.i`, `i-vrtab.i`, `i-vwent.i`, `i-wendef.i`, `i-wenreg.i`, `i-wenrgm.i`, `i-win.i`, `i-xls001.i`, `i-xls002.i`, `i-xls003.i`, `i-xls004.i`, `i-xmlquery.i`, `i_cdrel_hr.i`, `i_dbeai.i`, `i_dbtypeddk.i`, `i_trdfrm.i`, `i_trdmnu.i`, `leave.i`, `okfil.i`, `okpai.i`, `p-cadsim.i`, `pi-edit.i`, `query.i1`, `rowid.i`, `salvafil.i`, `salvapai.i`, `sobre.i`, `tt-edit.i`, `verifica_program_name.i`, `w-cadco2.i`, `w-cadcom.i`, `w-cadsi2.i`, `w-cadsi3.i`, `w-cadsim.i`, `w-concom.i`, `w-conrel.i`, `w-consim.i`, `w-digit.i`, `w-impor.i`, `w-inccom.i`, `w-incmdp.i`, `w-incsim.i`, `w-livre.i`, `w-paiamb.i`, `w-paifil.i`, `w-pesqui.i`, `w-relat.i`, `w-window.i`, `win-size.i`, `zoom.i`, `zoomvarreposition.i`

**`ddk/method`** (38 arquivos): `ShowMessage.i1`, `ShowMessage.i2`, `ShowMessage.i3`, `cgidefs.i`, `cgiutils.i`, `custom.i`, `dbo.i`, `dbodiv.i`, `dbofun.i`, `dbogen.i`, `dbonav.i`, `dboproxy11.i`, `dboqry.i`, `dbotterr.i`, `dbottinf.i`, `dbottraw.i`, `dboupd.i`, `dboverr.i`, `override.i`, `proto.i`, `referencefields.i`, `xmlapi.i`, `xmldef.i`, `xmldwb.i`, `xmlini.i`, `xmlprp.i`, `xmlrcvdef.i`, `xmlrcvdstr.i`, `xmlrcvini.i`, `xmlrcvip.i`, `xmlrcvoff.i`, `xmlrcvsndip.i`, `xmlrcvsndtt.i`, `xmlrcvtt.i`, `xmlsmrt.i`, `xmlsnd.i`, `zoomfields.i`, `zoomreposition.i`

**`ddk/src/adm/method`** (20 arquivos): `attribut.i`, `brokattr.i`, `brokcntn.i`, `broker.i`, `broksmrt.i`, `browser.i`, `containr.i`, `dispatch.i`, `get-attr.i`, `panel.i`, `panelsiz.i`, `query.i`, `record.i`, `reports.i`, `set-attr.i`, `smart.i`, `smartget.i`, `smartset.i`, `tableio.i`, `viewer.i`

**`ddk/src/adm/template`** (22 arquivos): `brschnge.i`, `brsentry.i`, `brsleave.i`, `bstates.i`, `dialogmn.i`, `find-tbl.i`, `pnstates.i`, `pustates.i`, `qstates.i`, `row-end.i`, `row-find.i`, `row-get.i`, `row-head.i`, `row-list.i`, `snd-end.i`, `snd-head.i`, `snd-list.i`, `sndkycas.i`, `sndkyend.i`, `sndkytop.i`, `vstates.i`, `windowmn.i`

**`ddk/panel`** (7 arquivos): `p-cadpai.w`, `p-cadsi2.w`, `p-cadsi3.w`, `p-cadsi4.w`, `p-cadsim.w`, `p-exihel.w`, `p-navega.w`

**`ddk/config`** (3 arquivos): `dbosvc.i`, `ddkcfg.i`, `webcfg.i`

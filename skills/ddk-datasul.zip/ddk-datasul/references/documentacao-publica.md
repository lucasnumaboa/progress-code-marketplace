# DDK clássico do TOTVS Datasul: o que a documentação pública diz

Pesquisa feita em 2026-11-20. Só entra aqui o que estava escrito em página aberta nesta pesquisa. Cada item traz a URL.

## Como ler este arquivo

**Classes de fonte**

- **[OFICIAL]**: página do TDN (tdn.totvs.com), aberta e lida.
- **[NÃO OFICIAL]**: cópia de material Datasul/TOTVS hospedada por terceiros, ou blog. O conteúdo é da Datasul, mas a hospedagem não é da TOTVS.

**Limites que afetam o resultado**

1. O TDN público não tem página com a descrição dos templates do DDK pelo nome do arquivo. A busca do TDN por `w-cadsim`, `w-paifil`, `w-cadcom`, `w-relat`, `w-pesqui`, `c-brwzoo`, `p-cadsim`, `i-rpini`, `i-rpcab`, `i-rpvar`, `ut-glob`, `zoomfields`, `zoomvarreposition.i`, `i-license-manager` (sem extensão) não retornou nada.
2. A Central de Atendimento (centraldeatendimento.totvs.com) **não abriu** neste ambiente: HTTP 403 e erro Cloudflare 1034 ("Edge IP Restricted"), em três clientes diferentes. Nenhum artigo de lá foi lido. Os títulos achados pelo buscador estão na seção "Não encontrado".
3. A principal fonte de detalhe é o **"Manual de Padrões – Programação EMS 2.0", Novembro/2007, Copyright Datasul S.A.**, lido numa cópia não oficial (link não incluído). É fonte **não oficial**. A cópia tem defeitos de extração:
   - todo texto entre `<` e `>` sumiu (marcadores de sintaxe e operadores de comparação);
   - trechos inteiros sumiram, entre eles "Preparando o Relatório para Execução no Módulo JOB EXECUTION", "Como implementar Parâmetros de Impressão", "Como implementar Botão de Filtro em Zoom", "Reposicionamento Automático do Browser de Zoom", "Como implementar ThinZoom" e "Como setar os modos de inclusão (Simple/Multiple)";
   - algumas tabelas vieram com as colunas embaralhadas.
   Onde o texto abaixo reconstrói um marcador perdido, isso está avisado.
4. Os nomes de arquivo do manual de 2007 **não batem** em todos os casos com os nomes do DDK local informados no pedido. Este arquivo registra o nome como o manual escreve e **não** faz a correspondência por dedução. Divergências estão marcadas com "CONFIRMAR NO DDK LOCAL".

URLs base usadas abaixo:

- MANUAL = "Manual de Padrões – Programação EMS 2.0", Nov/2007, Datasul S.A. (cópia não oficial; link não incluído) [NÃO OFICIAL]
- MEN012AA = https://tdn.totvs.com/pages/viewpage.action?pageId=467764464 [OFICIAL]

---

## 1. Templates de tela

### 1.0 Descrição oficial dos tipos de template (campo "Template" do cadastro de programas)

A função Manutenção de Programa (MEN012AA), pasta Opções, tem o campo "Template". A página lista os templates do produto, pelo **nome do estilo** (não pelo nome do arquivo):

| Estilo (TDN) | Descrição resumida |
|---|---|
| Cadastro Simples | Todas as funções ficam na própria tela, exceto "Vá para" e "Zoom". |
| Cadastro Simples Alteração | Menu só com as opções de atualizar. Sem Incluir/Copiar/Eliminar. |
| Cadastro Simples Inclusão | Menu só com as opções de inclusão. Sem Alterar/Copiar/Eliminar. |
| Cadastro Complexo | Igual ao Cadastro Simples. Usado quando os campos da tabela não cabem em uma única visão. |
| Cadastro Complexo Alteração | Igual ao Complexo, com alteração de visão/aba do cadastro. |
| Cadastro Pai X Filho Filho | Navega na tabela pai. A manutenção ocorre só na tabela filho. |
| Cadastro Pai X Filho Ambos | Igual ao anterior, e a atualização também ocorre no registro pai. |
| Inclui/Modifica Pai | Janela sem painéis para incluir ou alterar a tabela pai. Pode ter abas. É chamada por um programa Pai X Filho. |
| Inclui/Modifica Filho | Igual à anterior, mas a ação é na tabela filho. |
| Formação | Tem a paleta de navegação. O programa é independente. |
| Formação sem Navegação | Sem a paleta. O programa é dependente: deve ser chamado por um programa com Browser Formação. |
| Parâmetros Únicos | Segue as regras do Cadastro Simples ou Complexo. Janela tipo detalhe, sem menu de barra e moldura. |
| Pesquisa | Tela para pesquisa específica na tabela de um programa (nome, descrição, programa). Janela tipo detalhe, sem menu de barra e moldura. |
| Consulta Simples | Navegação só para consulta. Tem "Vá para" e "Zoom". |
| Consulta Complexa | Igual à Simples, com aba para as demais visões da tabela. |
| Consulta Relacionamento | Mostra os relacionamentos de uma tabela pai. |
| Relatórios | A página descreve como tela onde se consultam informações de diversos itens cadastrados no programa/produto. |
| Vá para | Reposiciona rápido o registro corrente quando o usuário sabe a chave. |
| Custom Dialog | Tela Dialog com padronização de botões. |
| Janela Detalhe | Janela filha, chamada por janela mestre. Sem menu de barra. Régua de botões embaixo. Simula dialog-box. |
| Janela Mestre | Base dos programas chamados pelo menu. Tem menu de barra, régua de botões no topo e moldura redimensionável. |
| Browse Inclui/Modifica | Tela que altera e adiciona dados usando um browse. |
| Browse Zoom | Pesquisa de dados de uma tabela, em formato de dialog. |
| Query | Procedure object com uma query de banco. Alimenta Viewer ou Browser. Responde à navegação de um SmartPanel. |
| Viewer | Procedure object que mostra campos do banco. Recebe registros de um Query ou Browser. |
| Importação/Exportação | Janela tipo detalhe com quatro folders: Layout, Seleção, Parâmetros, Log. |
| Digitação Rápida | Janela tipo detalhe, sem menu de barra e moldura. A página a descreve como janela de pesquisa onde se informam dados para buscar no banco. |
| Programas sem Interface | Cadastrado no menu só para usar a permissão de execução. |
| Relatório Gerado pelo Data Viewer | Relatório criado pelo utilitário DataViewer (gr0101). |

Fonte: https://tdn.totvs.com/pages/viewpage.action?pageId=467764464 [OFICIAL]

Observação: o tipo de template cadastrado muda o comportamento do programa. Segundo a FAQ 907, conforme o tipo de template o programa assume comportamento específico e, no caso tratado, desabilita a janela chamadora.
Fonte: https://tdn.totvs.com/pages/viewpage.action?pageId=5269129 [OFICIAL]

### 1.1 w-cadsim (Cadastro Simples)

- Nome físico no manual: `Masters/w-cadsim.w`.
- Para que serve: manutenção de uma tabela na tela base. Só o zoom e o "vá para" abrem outra tela.
- Regras: campos alinhados pelo colon, em colunas. Tabulação de cima para baixo. Menu de barra com todas as opções dos botões. Não permite alterar a chave pela função "Alterar". "Eliminar" pede confirmação.
- Composição: uma SmartQuery (estilo CustomQuery Wizard) na página 0; uma SmartViewer (estilo CustomViewer com Auto-Field) na página 0; painéis `p-navega`, `p-exihel` e `p-cadsim`.
- Atributos de instância da SmartQuery: "Programa Pesquisa" e "Programa Vá para".
- Links listados pelo manual:

| Source | Tipo | Target |
|---|---|---|
| h_p-cadsim | STATE | h_p-exihel |
| h_p-cadsim | TABLEIO | h_viewer |
| h_p-navega | NAVIGATION | h_query |
| h_p-navega | STATE | h_query |
| h_query | RECORD | h_viewer |
| h_p-exihel | STATE | h_query |

Fonte: MANUAL, cap. 5 "Cadastro Simples" e cap. 8 "Como construir um Cadastro Simples" [NÃO OFICIAL]

### 1.2 w-cadsi2 (Cadastro Simples – Alteração)

- Nome físico no manual: `Masters/w-cadsi2.w`.
- O menu de barra tem só as opções de atualizar. Não tem Incluir, Copiar, Eliminar.
- Construção: mesmos passos do Cadastro Simples.

Fonte: MANUAL, cap. 5 "Cadastro Simples - Atualiza" e cap. 8 [NÃO OFICIAL]. Descrição do estilo: MEN012AA [OFICIAL]

### 1.3 w-cadsi3 (Cadastro Simples – Inclusão)

- Nome físico no manual: `Masters/w-cadsi3.w`.
- O menu tem só as opções de inclusão.
- Uma FAQ oficial cita esse mesmo nome físico como "template de cadastro simples/inclusão".

Fonte: MANUAL, cap. 8 [NÃO OFICIAL]; https://tdn.totvs.com/pages/viewpage.action?pageId=5264077 [OFICIAL]

**Quando usar w-cadsim x w-cadsi2 x w-cadsi3:** o manual apresenta os três como variações do mesmo estilo. A escolha é pelo conjunto de funções: completo (w-cadsim), só alteração (w-cadsi2), só inclusão (w-cadsi3).
Fonte: MANUAL, cap. 8 [NÃO OFICIAL]

### 1.4 w-cadcom (Cadastro Complexo)

- Nome físico no manual: `Masters/w-cadcom.w`.
- Quando usar: sempre que os campos da tabela não cabem em uma única viewer.
- Mesmo menu do Cadastro Simples. Tem folders, com mais de uma viewer.
- Composição: SmartQuery na página 0; uma SmartViewer acima do folder (página 0); uma SmartViewer por página do folder; painéis p-navega, p-exihel, p-cadsim.
- Link extra: GROUP-ASSIGN da viewer da página 0 para cada viewer do folder. O folder liga por PAGE em THIS-PROCEDURE.

Fonte: MANUAL, cap. 5 "Cadastro Complexo" e cap. 8 "Como construir um Cadastro Complexo" [NÃO OFICIAL]

### 1.5 w-cadco2 (Cadastro Complexo – Atualiza)

- O manual grafa `Masters/w-cadcon2.w`. **CONFIRMAR NO DDK LOCAL** (o nome informado no pedido é w-cadco2).
- Mesmas características do Cadastro Simples – Atualiza, com mais de uma viewer em folders.

Fonte: MANUAL, cap. 5 e cap. 8 [NÃO OFICIAL]

### 1.6 Pai x Filho – Atualiza Filho (no pedido: w-paifil)

- O nome `w-paifil` **não aparece** na documentação lida. O manual de 2007 dá para este estilo o nome físico `Masters/w-adf.w` ("Window Cadastro Pai x Filho - Filho"). **CONFIRMAR NO DDK LOCAL.**
- Para que serve: navega na tabela pai. Incluir, Modificar e Eliminar valem só para a(s) tabela(s) filho.
- O folder seleciona os browsers das tabelas filho.
- "Incluir" e "Modificar" abrem janelas semelhantes ao Cadastro Simples ou Complexo, sem a régua.
- Composição: SmartQuery da tabela pai (página 0); SmartViewer da tabela pai acima do folder; um SmartBrowser por página do folder, criado com o estilo CustomBrowser Inclui/Modifica; painéis p-navega e p-exihel.
- Atributo de instância do SmartBrowser: nome do programa de atualização da tabela filha. Esse programa usa o template Cadastro Inclui/Modifica Filho.
- Links: RECORD da SmartQuery para a viewer e para cada browser; h_p-exihel STATE em THIS-PROCEDURE e em h_query; h_p-navega NAVIGATION e STATE em h_query.

Fonte: MANUAL, cap. 5 "Pai x Filhos - Atualiza Filho" e cap. 8 [NÃO OFICIAL]

### 1.7 w-paiamb (Pai x Filho – Atualiza Ambos)

- Nome físico no manual: `Masters/w-paiamb.w`.
- Igual ao Pai x Filho – Atualiza Filho, e a atualização também ocorre no registro pai.
- A tabela pai é mantida por um programa separado, feito com o template Cadastro Inclui/Modifica Pai.
- Atributos de instância da SmartQuery: programa de pesquisa, programa "Vá Para" e programa de Inclui/Modifica/Copia da tabela pai.
- Painéis com link STATE para a SmartQuery: p-navega, p-cadpai, p-exihel.

Fonte: MANUAL, cap. 5 "Pai x Filhos - Atualiza Ambos" e cap. 8 [NÃO OFICIAL]

**Quando usar w-paifil x w-paiamb:** "Atualiza Filho" quando só o filho recebe manutenção. "Atualiza Ambos" quando o pai também recebe (Incluir, Modificar, Eliminar e Copiar do pai, via janela Inclui/Modifica Pai).
Fonte: MANUAL, cap. 5 [NÃO OFICIAL]; MEN012AA [OFICIAL]

### 1.8 w-incmdp (Inclui/Modifica Pai)

- Nome físico no manual: `Master/w-incmdp.w` ("Window IncluiModifica Pai").
- Janela sem painéis. Pode ter folders. É chamada por um programa Pai x Filho. A mesma janela serve para inclusão, alteração e cópia.
- Quatro botões: Ok, Salvar, Cancelar, Ajuda. Na inclusão, "Salvar" grava o registro e cria um novo.
- Se os campos cabem em uma viewer, elimina-se o folder (tipo Simples). Se não cabem, dividem-se em viewers nas páginas do folder (tipo Complexo).

Fonte: MANUAL, cap. 5 "Manutenção de Pais" e cap. 8 "Como construir um Cadastro Inclui/Modifica Pai" [NÃO OFICIAL]

### 1.9 Inclui/Modifica Filho (no pedido: w-incsim, w-inccom)

- Os nomes `w-incsim` e `w-inccom` **não aparecem** na documentação lida. O manual dá para "Window Inclui/Modifica Filho" o nome físico `Masters/w-incmo3.w`. **CONFIRMAR NO DDK LOCAL.**
- Janela sem painéis, chamada por um programa Pai x Filho. Mesmos quatro botões da janela do pai.
- A mesma regra simples/complexo se aplica: com uma viewer elimina-se o folder; com várias viewers usa-se o folder.

Fonte: MANUAL, cap. 5 "Manutenção de Filhos" e cap. 8 "Como construir um Cadastro Inclui/Modifica Filho" [NÃO OFICIAL]

**w-incsim x w-incmdp x w-inccom:** a documentação lida só distingue "Inclui/Modifica Pai" de "Inclui/Modifica Filho", e "simples" (sem folder) de "complexo" (com folder) dentro do mesmo template. A diferença entre os três arquivos do DDK local não está documentada nas páginas abertas.

### 1.10 w-consim (Consulta Simples)

- Nome físico no manual: `Masters/w-consim.w`.
- Funções na tela base, só para consulta. Zoom e "Vá para" abrem outra tela.
- Construção igual ao Cadastro Simples: SmartQuery na página 0, com os atributos "Programa Pesquisa" e "Programa Vá para".

Fonte: MANUAL, cap. 5 "Consulta Cadastral Simples" e cap. 8 [NÃO OFICIAL]

### 1.11 w-concom (Consulta Complexa)

- Nome físico no manual: `Masters/w-concom.w`.
- Igual à Consulta Simples, com folder para as demais viewers da tabela. Tem o botão "Relacionamento".

Fonte: MANUAL, cap. 5 "Consulta Cadastral Complexa" e cap. 8 [NÃO OFICIAL]

### 1.12 w-conrel (Consulta Relacionamento)

- Nome físico no manual: `Masters/w-conrel.w`.
- Mostra os relacionamentos de uma tabela pai. Navegação, "Vá para" e "Pesquisa" valem para a tabela pai.
- Cada página do folder mostra uma tabela filho em um browser.
- Cada browser tem o botão "Detalhar", que chama a consulta cadastral da tabela filho. O default-action do browser (duplo clique ou barra de espaços) é atalho para "Detalhar".
- Acima do folder ficam os campos principais da tabela pai, dentro de um retângulo.

Fonte: MANUAL, cap. 5 "Consulta Relacionamento" e cap. 8 [NÃO OFICIAL]

### 1.13 w-relat (Relatórios, Cálculos, Fechamentos)

- Nome no manual: estilo "Window Relatórios/Cálculos/Fechamentos (w-relat.w)".
- Não usa SmartObjects.
- O relatório tem dois programas: `xxp/xx9999.w` (interface) e `xxp/xx9999rp.p` (geração).
- Janela tipo detalhe, sem menu de barra e moldura. Botões Executar, Fechar e Ajuda.
- Folders: Seleção (faixas), Classificação (radio-set), Parâmetros (demais informações), Digitação (browse updatable), Impressão.
- Detalhes na seção 3.

Fonte: MANUAL, cap. 5 "Relatórios, Cálculos, Fechamentos" e cap. 8 "Como construir um programa de Relatórios" [NÃO OFICIAL]

### 1.14 w-impor (Importação/Exportação)

- Nome no manual: estilo "Window Importação/Exportação (w-impor.w)". É uma variação do estilo de relatórios, sem SmartViewers e SmartFolders.
- Janela tipo detalhe. Botão "Executar" dispara a importação ou exportação.
- Quatro folders: Layout, Seleção, Parâmetros, Log. O botão "Editar Layout" abre o arquivo de layout em um editor de texto.
- Detalhes na seção 3.6.

Fonte: MANUAL, cap. 5 "Importação"/"Exportação" e cap. 8 [NÃO OFICIAL]

### 1.15 w-digit (Digitação Rápida)

- Nome físico no manual: `Masters/w-digit.w`.
- Janela tipo detalhe. "Ok" (default) efetiva a transação. "Cancelar" sai sem considerar as informações.
- As páginas iniciais guardam as informações genéricas. A última página é do browser.
- Composição: uma CustomViewerDigita na página 1 (só variáveis, sem DBFields) e um CustomBrowserDigita na página 2 (usa temp-table).
- O browse de digitação usa o estilo `Masters/b-digit.w`. Pontos de ajuste: definição da temp-table (não eliminar o campo "line"), open_query, display, `pi-salva-rel` (validações e gravação) e `pi-cria-registro` (chamada no choose do botão OK).

Fonte: MANUAL, cap. 5 "Digitação Rápida" e cap. 8 [NÃO OFICIAL]

### 1.16 w-pesqui (Pesquisa / Zoom)

- Nome físico no manual: `Masters/w-pesqui.w` ("Window Pesquisa"). A FAQ 55831 do TDN cita o mesmo nome.
- Detalhes na seção 6.

Fonte: MANUAL, cap. 8 "Como construir um programa de Pesquisa" [NÃO OFICIAL]; https://tdn.totvs.com/pages/viewpage.action?pageId=5264077 [OFICIAL]

### 1.17 d-vapara (Vá Para)

- Nome físico no manual: `Masters/d-vapara.w` ("Dialog VaPara").
- Para que serve: reposicionar rápido o registro corrente quando o usuário sabe a chave. Evita navegar ou abrir o zoom.
- Caixa de diálogo pequena com Ok, Cancelar e Ajuda. "Ok" é o default-button. Não tem zoom.
- Construção: escolher a tabela e os campos da chave. O template gera sozinho a trigger GO que faz o tratamento.
- Sugestão do manual para altura 0,88 dos campos: no AppBuilder, Options > Preferences > Grid Units, Layout Units em Pixel, valor 1.

Fonte: MANUAL, cap. 5 "Vá Para" e cap. 8 [NÃO OFICIAL]

### 1.18 Estilos documentados sem nome de arquivo confirmado

- **Formação**: tem a palette de navegação; o programa é independente. "Incluir" adiciona dados ao browse de formação. "Deletar" remove. "Modifica" chama o programa de atualização dos atributos.
- **Formação sem Navegação**: sem a palette; deve ser chamado por um programa com Browser Formação.
- **Parâmetros Únicos**: janela tipo detalhe. "Ok" é o default-button. "Cancelar" é o cancel-button. "Imprimir" chama o browse de relatórios relacionados.
- **Parâmetros Múltiplos**: segue as regras do Cadastro Simples ou Complexo. Exemplo do manual: parâmetros por estabelecimento.
- **Funções Relatórios Relacionados / Consultas Relacionadas**: abrem um browser com os relatórios ou consultas relacionados ao programa. "Executar" chama o item selecionado.

Fonte: MANUAL, cap. 5 [NÃO OFICIAL]

### 1.19 Tipos de janela

- **Janela Mestre**: base dos programas chamados pelo menu. Menu de barra, régua de botões no topo, moldura (resizeable).
- **Janela Detalhe**: chamada por janela mestre. Sem menu de barra. Régua de botões embaixo. Sem moldura (resize = no). Exemplo: programa de zoom.
- **Caixa de Diálogo**: para funções em que a interface precisa ser modal. Régua de botões embaixo.
- Aviso: não salvar uma Dialog com uma Window aberta. O menu da Window pode ser copiado para a Dialog e se perder.

Fonte: MANUAL, cap. 4 "Tipos de Telas" [NÃO OFICIAL]; MEN012AA [OFICIAL]

---

## 2. SmartObjects e painéis

### 2.1 Conceitos

- Programa DDK GUI (Smarts) é composto de vários Smart Objects (programas). Não dá para mover objetos de um Smart Object para outro.
  Fonte: https://tdn.totvs.com/display/LDT/MSO+-+Tecnologia+DDK+GUI [OFICIAL]
- Vantagem dos templates Smart (DDK GUI): reaproveitamento de código. Queries, Viewers e Browsers servem a mais de um programa. O cliente pode reusar objetos próprios e do produto.
- Thin Templates (DDK2000): separam a lógica de apresentação da lógica de negócio, com DBOs.
  Fonte: https://tdn.totvs.com/pages/viewpage.action?pageId=5254517 [OFICIAL]
- **SmartBrowser**: objeto procedure que recupera e mostra dados em um browse. Não mudar o nome padrão do browse. Manter o tamanho padrão.
- **SmartViewer**: procedure object que mostra campos do banco. Recebe registros de uma SmartQuery ou SmartBrowser. Deixar uma linha antes e uma depois em relação a outros objetos.
- **SmartQuery**: procedure object com uma query de banco. Alimenta outros SmartObjects. Responde à navegação de um SmartPanel. No Query Builder, trocar "Returned" de "All Fields" para "Fields Used".
  Fonte: MANUAL, cap. 4 "Considerações sobre os SmartObjects" [NÃO OFICIAL]

### 2.2 Estilos de objeto citados no manual

O manual de 2007 não usa os nomes `c-viewer`, `c-query`, `c-browse`... Usa os nomes abaixo. **CONFIRMAR NO DDK LOCAL** a relação com os arquivos c-*.

| Estilo (manual) | Nome físico (manual) | O que o manual diz |
|---|---|---|
| Custom Viewer com AutoField | `Masters/vieweraf.w` | Estilo para criar viewers. Três técnicas: viewer padrão, viewer sem campos de tabela, viewer só com campos chave. |
| Custom Query Wizard | `Masters/wquery.w` | Estilo para criar a SmartQuery. Seguir o wizard. Sem cláusula where, assinalar "Index Reposition" em query definitions. |
| Custom Browser Zoom Wizard | `Masters/wbrwzoo.w` | Browser para o programa de pesquisa. Ver seção 6.3. |
| CustomBrowser Inclui/Modifica | o manual repete `Master/w-incmdp.w` na tabela deste item | Browser dos filhos no Pai x Filho. Exige tabela externa igual à da query do Pai x Filho. Marcar "Indexed-Reposition". Em Options, "Returned" = "Fields Used" e marcar "Sort-ByPhrase". |
| CustomBrowserDigita | `Masters/b-digit.w` | Browse updatable da Digitação Rápida, sobre temp-table. |
| CustomViewerDigita | não informado | Viewer da Digitação Rápida. Só variáveis. |

Observação: o nome `Master/w-incmdp.w` na linha do CustomBrowser Inclui/Modifica é o mesmo do template Inclui/Modifica Pai. Pode ser erro do manual. Não confirmado.

Fonte: MANUAL, cap. 8 [NÃO OFICIAL]

### 2.3 Painéis

O capítulo "Painéis" do manual só diz que são os painéis padrão mais usados para navegação. As figuras não vieram na cópia. O papel de cada painel abaixo vem das listas de links do capítulo 8.

- **p-navega**: fonte dos links NAVIGATION e STATE para a SmartQuery. Presente em cadastros, consultas e pai x filho.
- **p-exihel**: link STATE para a SmartQuery. No Pai x Filho também liga STATE em THIS-PROCEDURE. No Cadastro Simples recebe STATE do p-cadsim.
- **p-cadsim**: link TABLEIO para a SmartViewer e STATE para o p-exihel. Presente no Cadastro Simples e no Complexo.
- **p-cadpai**: link STATE para a SmartQuery. Presente no Pai x Filho – Atualiza Ambos.

Fonte: MANUAL, cap. 5 "Painéis" e cap. 8 (listas de links) [NÃO OFICIAL]

### 2.4 Habilitar e desabilitar botões dos painéis

- As masters têm procedures internas para habilitar ou desabilitar os botões dos painéis de Cadastro e Alteração.
- Exige um link STATE entre o painel e a Window (THIS-PROCEDURE).
- A chamada fica no local-initialize da Window, depois do run dispatch.
- Sintaxe (marcadores reconstruídos, pois sumiram da cópia): `RUN enable-<função> IN <handle do painel> (INPUT <lógico>)`. "yes" habilita, "no" desabilita.
- Funções listadas: Inclui, Elimina, Modifica, Copia, Cancela, Desfaz, Salva, Va-para, Zoom, Relacionamento, Relatório.
- Para condicionar a uma validação de viewer ou browser: link STATE da Viewer/Browser para a SmartWindow; `run new-state("habilitar":U)` ou `run new-state("nao-habilitar":U)` no objeto; tratar `p-state` no state-changed da Window. Não usar "else": outros states passam por essa procedure.
- No Browse Inclui/Modifica, o state-changed recebe "no-record-available", "no-external-record-available" e "record-available". Não eliminar o código já existente.

Fonte: MANUAL, cap. 15 "Como habilitar ou desabilitar botões em painéis" e "…em Browse Inclui/Modifica" [NÃO OFICIAL]

### 2.5 FAQs oficiais sobre SmartObjects

- Página corrente em programa smart object: `RUN get-attribute IN THIS-PROCEDURE ('current-folder':U)` e ler o return-value.
  Fonte: https://tdn.totvs.com/pages/viewpage.action?pageId=5268889 [OFICIAL]
- Página corrente em programa ThinTemplate: `run getCurrentFolder in hFolder (output <variável inteira>)`. A variável hFolder já é definida internamente.
  Fonte: https://tdn.totvs.com/pages/viewpage.action?pageId=5269569 [OFICIAL]
- Criar ou eliminar página de folder em tempo de execução (template inclui/modifica): `run create-folder-page in <handle do folder> (input <página>, <label>)` e `run delete-folder-page in <handle do folder> (input <página>)`.
  Fonte: https://tdn.totvs.com/pages/viewpage.action?pageId=5268721 [OFICIAL]
- Duplo clique em linha de browse: usar a trigger default-action, não mouse-select-dblclick.
  Fonte: https://tdn.totvs.com/pages/viewpage.action?pageId=5265064 [OFICIAL]
- Páginas no AppBuilder: em programas de mídias antigas do DDK, mudar Procedure Type para SmartWindow (Tools > Procedure Settings > Advanced) habilita o "Go To Page".
  Fonte: https://tdn.totvs.com/pages/viewpage.action?pageId=5255185 [OFICIAL]
- Objetos dinâmicos (Screen Optimizer): não dá para criar objeto com atributo de extensão em frame sem tabela relacionada, como a frame do container ou a barra de ferramentas.
  Fonte: https://tdn.totvs.com/display/LDT/MSO+-+Tecnologia+DDK+GUI [OFICIAL]

---

## 3. Relatório (w-relat + rp.p)

Quase tudo desta seção vem do MANUAL [NÃO OFICIAL]. As partes oficiais estão marcadas.

### 3.1 Estrutura da tela (.w)

Tabela de páginas do estilo:

| Página | Frame | Imagem | Preprocessador |
|---|---|---|---|
| Seleção | f-pg-sel | im-pg-sel | PGSEL |
| Classificação | f-pg-cla | im-pg-cla | PGCLA |
| Parâmetros | f-pg-par | im-pg-par | PGPAR |
| Digitação | f-pg-dig | im-pg-dig | PGDIG |
| Impressão | f-pg-imp | im-pg-imp | PGIMP |

- Página não usada: eliminar a frame, eliminar a imagem da "orelha" mais à direita e limpar o preprocessador em Definitions.
- Tradução de labels, helps e screen-values é automática, por um include do estilo. Exceção: list-items de combo-box.
- Não alterar o tamanho da frame de relatório. Há risco de erro de interface com Facelift.
- Seleção: fill-ins de inicial e final para cada faixa. Sugestão: criar como Database Fields e depois converter em variável.
- Classificação: radio-set `rs-classif`.
- Digitação: temp-table `tt-digita` e browse `br-digita`. Gatilhos Display, Row-entry e Row-leave. Botões `bt-inserir` e `bt-alterar`. As validações ficam na `pi-executar`.
- Retângulos com label: usar fill-in view-as text, com o valor no initial e no private-data.

Fonte: MANUAL, cap. 8 "Como construir um programa de Relatórios" [NÃO OFICIAL]

### 3.2 Ordem dos includes e pontos de código na tela (.w)

1. **Definitions**: preprocessadores PGSEL, PGCLA, PGPAR, PGDIG, PGIMP. Definição das temp-tables `tt-param` e `tt-digita`. Preprocessador `RTF` (YES/NO).
2. **Main-block**: `{include/i-rpmbl.i}`. Se não existir a página de seleção, passar a imagem da página inicial: `{include/i-rpmbl.i im-pg-par}`.
3. **pi-executar**: validações (mensagem cadastrada, posicionar na página, foco no campo, `return error`); gravação dos parâmetros em `tt-param`; chamada de `{include/i-rprun.i}` trocando a literal `XXP/XX9999RP.P` pelo programa que imprime.

Exemplo de validação do manual: `run utp/ut-msgs.p (input "show", input 73, input " ")`, depois `apply 'mouse-select-click' to im-pg-par in frame f-relat` e `apply 'entry'` no campo.

Fonte: MANUAL, cap. 8 [NÃO OFICIAL]

### 3.3 Função de cada include i-rp*

| Include | O que a documentação diz |
|---|---|
| i-rpvar.i | Include padrão das variáveis de relatório. Substitui o `cdp/cd9500.i` do Magnus. |
| i-rpcab.i | Define a frame de cabeçalho e rodapé. Substitui o `cdp/cd9500.fl`. Recebe `&stream`. |
| i-rpcb80.i | Só citado: recebe `&stream`, junto com i-rpcab. Função não descrita no trecho lido. |
| i-rpc255.i | Só citado: recebe `&stream`, junto com i-rpcab. Função não descrita no trecho lido. |
| i-rpout.i | Include padrão de output do relatório. Substitui o `cdp/cd9520.i`. Recebe `&stream` e, na importação, `&tofile`. |
| i-rpclo.i | Fecha o output. Substitui o `cdp/cd9540.i`. Recebe `&stream`. |
| i-rpmbl.i | Chamado no Main-block da tela. Parâmetro posicional: imagem da página inicial. |
| i-rprun.i | Chamado na pi-executar da tela. Recebe o nome do programa rp.p. |
| i-rpini.i | Só aparece como exemplo de nome de include padrão ("include/i-rpini.i"). Função não descrita. |

Fonte: MANUAL, cap. 3 "Includes padrões" e cap. 8 [NÃO OFICIAL]

Dado oficial sobre o i-rpout.i: para um relatório do EMS 2 usar a impressão em escala, ele deve seguir o template padrão do DDK e usar o `include/i-rpout.i`.
Fonte: https://tdn.totvs.com/pages/viewpage.action?pageId=223162816 [OFICIAL]

### 3.4 Programa rp.p: regras e ordem

Regras:

- Programa procedural, sem interface. Exceções: a impressão e a caixa de acompanhamento (ut-acomp/ut-perc).
- Nenhum programa chamado por um rp.p pode ter interface. Validações que pedem o usuário ficam no .w.
- Copiar a definição de `tt-param` e `tt-digita` do .w. A definição de `tt-param` deve ser idêntica nos dois.
- Usar a stream padrão `STR-RP` e passar `&stream` para i-rpcab.i, i-rpcb80.i, i-rpc255.i, i-rpout.i e i-rpclo.i.
- Formas de passagem mostradas: `{include/i-rpcab.i &stream = "str-rp"}` e `{include/i-rpout.i &stream = "stream str-rp"}`.
- Nas seleções impressas, usar `|< >|` no lugar da palavra "à".
- Labels fora do dicionário: tratar com `{utp/ut-liter.i}`, `{utp/ut-field.i}` ou `{utp/ut-table.i}`.
- Todo form/frame de impressão leva a cláusula stream-io.

Ordem do exemplo de rp.p do manual:

1. `{include/i-prgvrs.i SP0014RP 1.00.00.000}` (controle de versão).
2. `&GLOBAL-DEFINE RTF YES` e `&SCOPED-DEFINE pagesize 42` (se usar RTF).
3. Definição de `tt-param` e de `tt-raw-digita`.
4. Parâmetros: `DEFINE INPUT PARAMETER raw-param AS RAW` e `DEFINE INPUT PARAMETER TABLE FOR tt-raw-digita`.
5. `CREATE tt-param.` e `RAW-TRANSFER raw-param TO tt-param.`
6. `{include/i-rpvar.i}`.
7. Variáveis e frames do relatório (stream-io).
8. `{include/i-rpout.i &STREAM="stream str-rp"}`.
9. `{include/i-rpcab.i &STREAM="str-rp"}`.
10. `ASSIGN` de `c-programa`, `c-versao`, `c-revisao`, `c-empresa`, `c-sistema`, `c-titulo-relat`.
11. `VIEW STREAM str-rp FRAME f-cabec` e `f-rodape`. Com RTF, o VIEW fica condicionado a `tt-param.l-habilitaRTF` (o operador da condição sumiu na cópia).
12. `RUN utp/ut-acomp.p PERSISTENT SET h-acomp`, `{utp/ut-liter.i Imprimindo *}` e `RUN pi-inicializar IN h-acomp (INPUT RETURN-VALUE)`.
13. Corpo do relatório.
14. `{include/i-rpclo.i &STREAM="stream str-rp"}`.
15. `RUN pi-finalizar IN h-acomp` e `RETURN "OK"`.

Fonte: MANUAL, cap. 8 "Dicas para criação do Programa RP.P de Relatório" [NÃO OFICIAL]

Confirmação oficial do padrão de parâmetros: a documentação do `crmrpw/crm047rp.p` descreve um rp com o parâmetro de entrada `raw-param` (Raw) e a tabela `tt-raw-digita`, executado por pedido de execução. O fonte começa por `{include/i-prgvrs.i CRM000RP 2.00.00.001}`.
Fonte: https://tdn.totvs.com/pages/viewpage.action?pageId=220890649 [OFICIAL]

### 3.5 Padrão da temp-table tt-param

Campos do exemplo de relatório do manual:

| Campo | Tipo |
|---|---|
| destino | integer |
| arquivo | character, formato x(35) |
| usuario | character, formato x(12) |
| data-exec | date |
| hora-exec | integer |
| classifica | integer |
| desc-classifica | character, formato x(40) |
| modelo-rtf | character, formato x(35) (arquivo modelo RTF) |
| l-habilitaRtf | logical |
| demais campos | campos das páginas de seleção e parâmetros |

- `tt-raw-digita`: um campo `raw-digita` do tipo RAW.
- No exemplo de importação, os campos são: destino, arq-destino, arq-entrada, todos, usuario, data-exec, hora-exec e os campos de seleção.

Fonte: MANUAL, cap. 8 [NÃO OFICIAL]

### 3.6 Importação e exportação (w-impor)

Tabela de páginas:

| Página | Frame | Imagem | Preprocessador |
|---|---|---|---|
| Layout | f-pg-lay | im-pg-lay | PGLAY |
| Seleção | f-pg-sel | im-pg-sel | PGSEL |
| Parâmetros | f-pg-par | im-pg-par | PGPAR |
| Log | f-pg-log | im-pg-log | PGLOG |

Includes citados:

- `i-immbl.i`: no Main-block. Parâmetro posicional: imagem da página inicial. Exemplo: `{include/i-immbl.i im-pg-par}`.
- `i-imvrf.i`: no Main-block. Parâmetros `&programa` (formato XX9999) e versão do layout (formato 999, inicial 001). O layout fica em `LAYOUT/LOXX9999.001`.
- `i-imarq.i`: no choose do `bt-arquivo-entrada`. O terceiro parâmetro, opcional, traz os filtros da system dialog. Sem ele, o padrão é `*.lst` e todos os arquivos.
- `i-imrun.i`: na pi-executar. Trocar a literal `XXP/XX9999RP.P` pelo programa que importa.
- Validação do arquivo de entrada: `run utp/ut-vlarq.p (input frame f-pg-par c-arquivo-entrada)`. O return-value "nok" indica erro.

rp.p de importação: stream própria para a importação e `STR-RP` para o log. Mesmos includes i-rpvar, i-rpout, i-rpcab e i-rpclo, para imprimir o log. No i-rpout, passar `&tofile` com o arquivo de destino.

Fonte: MANUAL, cap. 8 "Como construir um programa de Importação/Exportação" [NÃO OFICIAL]

### 3.7 Execução on-line x batch (RPW)

- **On-line**: executa na hora, ao acionar Imprime ou Executa. O processamento é local, na máquina do usuário.
- **Batch**: executa remotamente, pelo Automação de Tarefas. Libera a máquina. Pode ser agendado com data e hora.
- Ao escolher batch, abre a tela do pedido de execução: Usuário, Pedido, Servidor, Descrição, Execução (data/hora), Dependente, E-mail.
  Fonte: https://tdn.totvs.com/pages/viewpage.action?pageId=852319080 [OFICIAL]
- Destinos: Impressora (on-line ou batch), Arquivo, Terminal.
- Arquivo on-line: informar caminho e nome. Arquivo batch: só o nome; grava no Diretório Spool do servidor de execução.
- Terminal não fica habilitado em batch.
  Fonte: https://tdn.totvs.com/pages/viewpage.action?pageId=852313960 [OFICIAL]
- O cadastro do programa tem o campo "Família SO": plataforma recomendada do servidor RPW (Todas, Windows, Unix/Linux).
  Fonte: MEN012AA [OFICIAL]
- Tradução de frames de relatório: `run utp/ut-trfrrp.p (input frame f-parametros:handle)`. Traduz uma única frame. Em relatórios, um filtro do RTB insere a chamada antes do i-rpout.i ou do i-rpcab.i quando o programa não a tem.
  Fonte: MANUAL, cap. 7 "UT-TRFRRP.P" [NÃO OFICIAL]

A seção do manual sobre preparar o relatório para o módulo JOB EXECUTION sumiu da cópia lida.

---

## 4. UPC / EPC

### 4.1 Definição

UPC (User Program Call) é uma interação com um programa do Datasul EMS. O produto tem pontos de chamada dentro dos programas. Nesses pontos entram as UPCs, que alteram características padrão: criar folder, botões, fill-in, chamar programas externos.
Fonte: https://tdn.totvs.com/display/LDT/SO0700G+-+Programa+UPC [OFICIAL]

### 4.2 Como se cadastra

- Função **Manutenção de Programa (MEN012AA)**, pasta Detalhes, campo **"Programa UPC"**: caminho e nome físico do programa de customização.
- A mesma página remete ao "Guia de Customização para o Produto" e à função "Manutenção Dicionário Datasul" do módulo Básico.
  Fonte: https://tdn.totvs.com/pages/viewpage.action?pageId=467764464 [OFICIAL]
- Outra página cita o mesmo programa pelo nome físico `men/men012aa.w`.
  Fonte: https://tdn.totvs.com/pages/viewpage.action?pageId=267792684 [OFICIAL]
- UPC de dicionário de dados (tabela): programa **Manutenção Tabela Dicionário Datasul (`btb/btb006aa.w`)**. Depois de incluir ou eliminar, executar o Otimizador de Performance (módulo Básico, rotina Tarefas). Ele ativa ou desativa os gatilhos de dicionário conforme as UPCs. O produto mostra a mensagem 17.286.
  Fonte: https://tdn.totvs.com/pages/viewpage.action?pageId=5266955 [OFICIAL]
- Screen Optimizer: o botão UPC da função Otimizar Telas (SO0700) abre a janela SO0700G, que vincula uma UPC ao programa otimizado, por perfil.
  Fonte: https://tdn.totvs.com/display/LDT/SO0700G+-+Programa+UPC [OFICIAL]
- Exemplo oficial de vínculo: para o login manual, selecionar o programa de nome interno "fnc_login" (nome externo `btb/btb910za.p`) e preencher o campo "Programa UPC".
  Fonte: https://tdn.totvs.com/pages/viewpage.action?pageId=5266686 [OFICIAL]

### 4.3 Assinatura padrão

Dois exemplos oficiais trazem a mesma lista de parâmetros:

| Parâmetro | Tipo |
|---|---|
| p-ind-event | character, input |
| p-ind-object | character, input |
| p-wgh-object | handle, input |
| p-wgh-frame | widget-handle, input |
| p-cod-table | character, input |
| p-row-table | rowid, input |

- O exemplo do login começa por `{include/i-prgvrs.i btb910za_upc 2.00.00.000}` e termina com `RETURN "OK"`.
- O exemplo do WMS inclui `{include/i-epc200.i}` antes dos parâmetros e testa `p-ind-event = "btOk" AND p-ind-object = "CONTAINER"`.

Fontes: https://tdn.totvs.com/pages/viewpage.action?pageId=5266686 [OFICIAL]; https://tdn.totvs.com/pages/viewpage.action?pageId=607587916 [OFICIAL]

O **significado** de cada parâmetro não está descrito em nenhuma página aberta. Ver "Não encontrado".

Exemplo não oficial: um blog mostra a mesma assinatura e um teste `p-ind-event = "INITIALIZE"` com `p-ind-object = "CONTAINER"`, que cria um botão com `frame = p-wgh-frame`.
Fonte: https://progressparavoce.blogspot.com/2011/07/exemplo-de-uma-upc-basica.html [NÃO OFICIAL]

### 4.4 Eventos citados em páginas oficiais

Não há, nas páginas abertas, uma lista oficial completa por template. O que existe são citações soltas:

| Evento | Contexto | Fonte [OFICIAL] |
|---|---|---|
| before-initialize, after-initialize, before-display, after-display, before-enable, after-enable, before-destroy-interface, after-destroy-interface | "Pontos de customização padrões" que o EN0101 ganhou ao ser migrado de template. | https://tdn.totvs.com/pages/viewpage.action?pageId=699825541 |
| after-destroy-interface, before-destroy-interface | Chamados de "pontos de UPC padrões" no RE1001. | https://tdn.totvs.com/pages/viewpage.action?pageId=337356771 |
| CHANGE-PAGE | Único evento que aparece quando o ut9000.i é chamado no lugar errado. Ver 4.5. | https://tdn.totvs.com/pages/viewpage.action?pageId=5265497 |
| AFTER-ASSIGN | Programas com templates do DDK e BO. Recebe o ROWID do registro em criação. | https://tdn.totvs.com/pages/viewpage.action?pageId=905131991 |
| AFTER-END-UPDATE | CP0324: evento após o update, usado por UPCs de clientes. | https://tdn.totvs.com/pages/viewpage.action?pageId=951325220 |
| "Validade" (grafia da página) e "After-End-Update" | CE0206. | https://tdn.totvs.com/pages/viewpage.action?pageId=496036111 |
| BEFORE-OPEN-QUERY | CE0830. | https://tdn.totvs.com/pages/viewpage.action?pageId=271406715 |
| AFTER-INITIALIZE-INTERFACE, AFTER-DISPLAY-FIELDS | GG0108. | https://tdn.totvs.com/pages/viewpage.action?pageId=694092342 |
| after-initialize | CDAPI677 / PD1001. | https://tdn.totvs.com/pages/viewpage.action?pageId=269070467 |
| AFTER-TIMEOUT | Login manual (btb/btb910za.p). | https://tdn.totvs.com/pages/viewpage.action?pageId=5266686 |
| before-initialize | Screen Optimizer avalia a propriedade "invisível" nesse evento. | https://tdn.totvs.com/pages/viewpage.action?pageId=599050201 |
| "pontos padrões de UPC" (sem nomes) | Rotina de pesquisa de romaneio GG2003-Z01. | https://tdn.totvs.com/pages/viewpage.action?pageId=607853692 |

### 4.5 Regra de posição do ut9000.i (DDK GUI)

- Sintoma: o programa só passa o evento CHANGE-PAGE para a UPC. Os eventos padrão de tela não chegam.
- Causa: o include `utp/ut9000.i`, que define os eventos, foi chamado depois do `dispatch initialize` na procedure `local-initialize`.
- Solução: chamar `utp/ut9000.i` **antes** do `run dispatch initialize`. O include `include/win-size.i` vai depois do ut9000 e antes do dispatch.

Fonte: https://tdn.totvs.com/pages/viewpage.action?pageId=5265497 [OFICIAL]

### 4.6 EPC com temp-table tt-epc

- Em pontos de EPC de lógica, a UPC recebe o indicador do evento e a temp-table `tt-epc` como input-output.
- `tt-epc.cod-parameter` identifica o parâmetro. `tt-epc.val-parameter` leva o valor de retorno.
- Exemplo oficial: evento "Auxiliary-Field" no ft0513cl.
  Fonte: https://tdn.totvs.com/pages/viewpage.action?pageId=267792684 [OFICIAL]
- Outro exemplo: o relatório EX0165 tem um ponto EPC por layout, com eventos "Custom-Fields-tt-…" e parâmetros nomeados.
  Fonte: https://tdn.totvs.com/pages/viewpage.action?pageId=235313167 [OFICIAL]

### 4.7 Função "Desabilita execução de UPC"

Includes ajustados para a função, o que mostra onde os templates chamam UPC: `utp/ut-api.i`, `maintenance/maintenance.i`, `window/window.i`, `report/report.i`, `zoom/zoom.i`, `include/i-epc200.i`, `include/i-epc101.i`, `include/i-epc102.i`, `include/i_verify_program_epc.i`, `maintenancenonavigation/maintenancenonavigation.i`, `btb/btbcustom.i`, `masterdetail/masterdetail.i`.

Fontes: https://tdn.totvs.com/pages/viewpage.action?pageId=819058131 [OFICIAL]; https://tdn.totvs.com/pages/viewpage.action?pageId=824199790 [OFICIAL]

---

## 5. Padrões de interface e nomenclatura

Fonte de toda a seção, salvo indicação: MANUAL, cap. 3 "Nomenclatura", cap. 4 "Layout de Telas" e cap. 5 "Estilos" [NÃO OFICIAL].

### 5.1 Janela

- Máximo de 90 colunas por 17 linhas. A largura é fixa. A altura pode ser menor, sempre em número inteiro. A medida segue o limite do VGA.
- Informar em "Width" e "Height" da Property Sheet.
- As mesmas dimensões valem para MAX-WIDTH-CHARS, MIN-WIDTH-CHARS, MAX-HEIGHT-CHARS e MIN-HEIGHT-CHARS. O include `win-size.i` faz essa atribuição.
- O título da tela vem do `UT-9000.i`. O programador não intervém.

### 5.2 Botões

- Botão com label: altura 1,00 unidade de caracter. Largura 10, 15 ou 20.
- Label de ação: verbo no infinitivo (Cancelar, Incluir, Modificar, Eliminar).
- "OK" confirma e sai da tela. "Cancelar" não confirma e sai.
- "Ajuda": canto inferior direito nas janelas detalhe e caixas de diálogo.
- "Sair" e "Ajuda": canto superior direito nas janelas pai.
- Funções novas, fora da palette padrão: botão na régua do topo, antes do botão "Consultas Relacionadas", e item no menu de barra.

### 5.3 Campos

- Fill-in: altura 0,88 unidade de caracter. Combo-box: altura 1,00.
- Campos alinhados pelo colon, em colunas. Tabulação de cima para baixo, coluna por coluna.
- Radio-set: sem label. Emoldurar com retângulo e literal. Vertical quando tem mais de 4 itens. Acima de 7 itens, usar combo-box.
- Editor: sem label. Propriedade RETURN-INSERTED. Fonte "2", padrão do Progress (fonte fixa).
- Retângulos: agrupam a chave de acesso, campos do mesmo assunto, itens de radio-set e editores com label.
- Faixas no zoom: `Label do campo: [valor inicial] [valor final]`. Não usar literais "inicial" e "final".

### 5.4 Atalhos do menu de barra (Cadastro Simples)

A tabela veio embaralhada na cópia. O pareamento abaixo foi reconstruído pela ordem.

| Opção | Atalho |
|---|---|
| Primeiro | Ctrl-Home |
| Anterior | Ctrl-Left |
| Próximo | Ctrl-Right |
| Último | Ctrl-End |
| Vá Para | Ctrl-T |
| Pesquisa | Ctrl-F5 |
| Incluir | Ctrl-Ins |
| Copiar | Ctrl-C |
| Alterar | Ctrl-A |
| Eliminar | Ctrl-Del |
| Desfazer | Ctrl-U |
| Cancelar | Ctrl-F4 |
| Salvar | Ctrl-S |
| Imprimir | Ctrl-P |
| Sair | Ctrl-X |

- Menu Ajuda: Conteúdo, Sobre.
- Zoom em campo: F5 ou duplo clique (MOUSE-SELECT-DBLCLICK).
- No zoom não há botões de início e fim. Usam-se as teclas HOME e END.

### 5.5 Nomes de arquivo

- Extensão `.w` com interface, `.p` sem interface.
- Dois programas não podem ter o mesmo nome com extensões diferentes: o `.r` gerado teria o mesmo nome.
- Regra do DOS: 8 caracteres no nome, 3 na extensão. Tudo em minúsculas.

### 5.6 SmartObjects ligados a uma tabela

"xx" = sigla do banco da tabela principal. "99" = sequencial do tipo de objeto para a tabela. "xx999" = dump-name da tabela.

| Tipo | Diretório | Nomenclatura | Exemplo (tabela "item") |
|---|---|---|---|
| Browser | xxbrw | b99xx999.w | "bo01in172.w" (grafia do manual) |
| Dialog | xxdialog | d99xx999.w | d01in172.w |
| Go (Vá para) | xxgo | g99xx999.w | g01in172.w |
| Query | xxqry | q99xx999.w | q01in172.w |
| Viewer | xxvwr | v99xx999.w | v01in172.w |
| Zoom (Pesquisa) | xxzoom | z99xx999 (o manual mostra ".p" na regra e ".w" no exemplo) | z01in172.w |

Subprogramas de zoom e SmartBrowser (filtro, narrativa): `XX9NNN.W`. XX = sigla do módulo, 9 fixo, NNN sequencial no módulo.

### 5.7 Programas ligados a um módulo

"xx" = sigla do módulo. "zz" = caracteres de diferenciação.

| Tipo | Nomenclatura | Exemplo |
|---|---|---|
| API | xxapi999.p | cep/ceapi001.p |
| Container | xx9999zz.w | cep/ce0401.w |
| Subprograma de relatório | xx9999rp.p ("rp" é fixo) | cep/ce0401rp.p |
| Subprograma sem interface | xx9999zz.p | cep/ce0401a.p |

- Programas cadastrais têm numeração concordante. Exemplo: Cadastro AT0017, Consulta AT0217, Relatório AT0417.
- Faixas de numeração (o manual cita para o Datasul-HR): 0000–0099 manutenções cadastrais; 0100–0199 manutenções gerais; 0200–0299 consultas cadastrais; 0300–0399 consultas complexas/relacionamento; 0400–0499 listagens cadastrais; 0500–0699 relatórios; 0700–0799 tarefas; 0800–0899 especiais/gráficos; 0900–0999 utilitários.

### 5.8 Includes

- Nome em minúsculas. Extensões `.i`, `.i1` … `.i9`.
- Usado por um só programa: mesmo nome do programa. Exemplo: `cdp/cd0206.i`, `advwr/v01ad102.i`.
- Usado por vários programas do módulo: sigla do módulo + sequencial, em geral acima de 9000. Exemplo: `cep/ce9000.i`.
- Usado por vários módulos: "cd" + sequencial. Exemplo: `cdp/cd9500.i`.
- Includes padrão dos estilos: diretório `include`, nome iniciado por "i-". Exemplo: `include/i-rpini.i`.
- View-as de campos indicadores: `varinc/var99999.i`.

### 5.9 Prefixos

Widgets:

| Widget | Prefixo | Exemplo |
|---|---|---|
| Botão | bt- | bt-ok |
| Browse | br- | br-zoom |
| Combo-box | cb- | cb-tipo-conta |
| Fill-in | fi- | fi-texto |
| Radio-set | rs- | rs-modo-execucao |
| Retângulo | rt- | rt-moldura |
| Selection-list | ls | ls-estados |
| Slider | sl | sl-percentual |
| Toggle-box | tb | tb-ativo |

Variáveis (EMS 2):

| Tipo | Prefixo | Exemplo |
|---|---|---|
| Caracter | c- | c-conta |
| Inteiro | i- | i-contador |
| Data | da- | da-atualizacao |
| Decimal | de- | de-total-geral |
| Handle | h- | h-acomp |
| Lógico | l- | l-ativo |
| Raw | raw- | raw-param |
| Rowid | rw- | — |
| Widget-handle | wh- | wh-botao |

Outros: buffer `b-`, frame `f-`, parâmetro `p-`, stream `s-`, temp-table `tt-`.

### 5.10 Versão (i-prgvrs.i)

- Forma de chamada nos exemplos: `{include/i-prgvrs.i <PROGRAMA> <versão>}`, com a versão no formato `9.99.99.999`.
- Exemplos do manual: `{include/i-prgvrs.i SP0014RP 1.00.00.000}` e `{include/i-prgvrs.i XX9999RP 1.00.00.000}`. No mesmo exemplo: `c-versao = "1.00"` e `c-revisao = ".00.000"`.
  Fonte: MANUAL, cap. 8 [NÃO OFICIAL]
- Exemplos oficiais: `{include/i-prgvrs.i esp-demo.p 2.00.00.000}`, com o comentário de cabeçalho "VERSAO..: 2.00.00.000 - Criação"; `{include/i-prgvrs.i btb910za_upc 2.00.00.000}`; `{include/i-prgvrs.i CRM000RP 2.00.00.001}`.
  Fontes: https://tdn.totvs.com/pages/viewpage.action?pageId=269419389 [OFICIAL]; https://tdn.totvs.com/pages/viewpage.action?pageId=5266686 [OFICIAL]; https://tdn.totvs.com/pages/viewpage.action?pageId=220890649 [OFICIAL]
- O utilitário `utp/ut-vrbin.p` lê a versão de um `.r`, mas só de programas feitos nos padrões e templates da Datasul.
  Fonte: MANUAL, cap. 6 "UT-VRBIN.P" [NÃO OFICIAL]

O significado de cada segmento da versão não está descrito nas páginas abertas.

---

## 6. Zoom / pesquisa

### 6.1 Estilo "Zoom de Tabelas"

- Janela tipo detalhe, sem menu de barra e moldura.
- "OK" é o default-button e confirma a escolha. "Cancelar" volta ao chamador sem registro.
- "Implantar" chama o programa de cadastro da tabela. Pode ficar desativado conforme o chamador.
- Botões específicos (Narrativa, Filtro, Texto Livre) ficam ao lado do "Implantar". Em geral abrem caixas de diálogo.
- Um botão aplica os valores inicial e final sobre a query do browse.
- Cada folder é uma opção de classificação.

Fonte: MANUAL, cap. 5 "Zoom de Tabelas" [NÃO OFICIAL]

### 6.2 Montagem do programa de pesquisa (w-pesqui)

1. Criar a janela com o estilo "Window Pesquisa" (`Masters/w-pesqui.w`).
2. Usar um SmartBrowser por classificação. A ordem das colunas do browser é a ordem de classificação.
3. Criar cada SmartBrowser com o estilo CustomBrowserZoom Wizard, se ainda não existir.
4. Instanciar o SmartBrowser no SmartFolder.
5. Criar um SmartLink STATE do SmartBrowser para THIS-PROCEDURE.
6. Manter o mesmo tamanho nos browsers das diferentes páginas.
7. Ajustar os labels das páginas em Instance Attributes.

Links: h_browse STATE em THIS-PROCEDURE; h_folder PAGE em THIS-PROCEDURE.

Fonte: MANUAL, cap. 8 "Como construir um programa de Pesquisa" [NÃO OFICIAL]

Retorno do registro: o programa de pesquisa devolve o rowid da **primeira tabela** da query do SmartBrowser. Se o chamador espera o rowid de outra tabela, corrigir a ordem das tabelas no Query Builder do SmartBrowser.
Fonte: https://tdn.totvs.com/pages/viewpage.action?pageId=5264077 [OFICIAL]

### 6.3 Browser de zoom (Custom Browser Zoom Wizard, `Masters/wbrwzoo.w`)

- A query mostra só os registros dentro da faixa informada pelo usuário.
- Os fill-ins de faixa do template são `c-inicial` e `c-final`, na frame `f-main`, acima do browse.
- Renomear para `fi-ini-<campo>` e `fi-fin-<campo>`. Exemplo: `fi-ini-cust-num`.
- Valor inicial do início de faixa: o menor aceito (0, ou branco). Valor inicial do fim de faixa: o maior aceito (exemplo "ZZZZZZ").
- Na trigger do `bt-confirma`, trocar `c-inicial` e `c-final` pelos novos nomes.
- Label dos fill-ins de faixa: via `ut-field` ou `ut-liter`, na `local-initialize`, antes do dispatch.
- Ajustar a procedure `pi-retorna-valor` com a tabela e os campos do browser.
- Para mais campos na faixa, copiar as imagens Image-1 e Image-2.

Fonte: MANUAL, cap. 8 "Como construir um CustomBrowser Zoom Wizard" [NÃO OFICIAL]

### 6.4 Chamada do zoom em DDK GUI: include/zoomvar.i

Sintaxe (o parâmetro de procedure aparece corrompido na cópia como "¶metros"; leitura provável `&parametros`, não confirmada):

```
{include/zoomvar.i &prog-zoom=diretório/programa
                   &campo=variavel/tabela.atributo
                   &campozoom=nome-atributo
                   [&frame=nome-frame]
                   [&browse=nome-browse]
                   [&parametros="run pi-procedure in wh-pesquisa (...)"]}
```

- `&prog-zoom`: programa de zoom.
- `&campo`: campo ou variável da tela. Campo de tabela vai no formato tabela.campo.
- `&campozoom`: campo do SmartBrowser do zoom de onde vem o valor. Sem o nome da tabela.
- `&frame`: opcional. Usar quando a frame não é `{&frame-name}`. Exemplo: estilo de relatório.
- `&browse`: opcional. Usar quando o zoom parte de uma coluna de browse updatable.
- Segundo par de campos: `&campo2` e `&campozoom2`.
- A chamada fica na trigger `ON F5 OF <campo> ... OR MOUSE-SELECT-DBLCLICK OF <campo>`.
- Atende: campo chave estrangeira, variável, campo com nome diferente do campo do browse, coluna de browse.

Passagem de parâmetros para o zoom: criar na Window do zoom uma procedure que recebe os parâmetros e os repassa aos browses (exemplo `run pi-seta-inicial in h_b25in172`). Criar em cada browse uma procedure que guarda os valores em variáveis usadas no open query.

Fonte: MANUAL, cap. 15 "Como implementar Zoom e campos de referência para campos chave estrangeira" [NÃO OFICIAL]

Restrição oficial: o `zoomvar.i` define variáveis. Não pode ser chamado duas vezes na mesma procedure (erro Progress de variáveis duplicadas). Para chamar um zoom ou outro conforme uma condição, usar duas procedures, cada uma com uma chamada.
Fonte: https://tdn.totvs.com/pages/viewpage.action?pageId=5262213 [OFICIAL]

### 6.5 Campo de referência (descrição da chave estrangeira)

1. Criar variável caracter view-as fill-in ao lado do campo com zoom. Tirar a propriedade "Enable".
2. Criar a `local-display-fields` e, antes do run dispatch, carregar a variável.
3. No leave do campo: `{include/leave.i &tabela=... &atributo-ref=... &variavel-ref=... &where="..."}`.

Fonte: MANUAL, cap. 15 [NÃO OFICIAL]

### 6.6 Botão Implantar

O `ut-glob.i` define a variável global lógica `l-implanta`, usada no zoom para habilitar o botão Implanta.
Fonte: MANUAL, cap. 6 "UT-GLOB.I" [NÃO OFICIAL]

### 6.7 Zoom em ThinTemplate (DDK2000): method/zoomFields.i

```
{method/zoomFields.i &ProgramZoom="progzoom.w"
                     &FieldZoom1="cod-cliente"
                     &FieldScreen1="ttcliente.cod-cliente"
                     &Frame1="fPageX"
                     &FieldZoom2=... &FieldScreen2=... &Frame2=...}
```

- `&ProgramZoom`: programa de zoom. `&FieldZoomN`: atributo da tabela. `&FieldScreenN`: atributo de tela que recebe o retorno. `&FrameN`: frame do atributo.
- Aceita até 10 FieldZoom.
- Descrição da chave estrangeira: `{method/ReferenceFields.i &HandleDBOLeave=... &keyValue1=... &FieldName1=... &FieldScreen1=... &Frame1=...}`.
- No Main Block, trocar o ponteiro do campo: `load-mouse-pointer("image/lupa.cur":U)`.

Fonte: https://tdn.totvs.com/pages/viewpage.action?pageId=5264574 [OFICIAL]

Material de treinamento DDK2000 mostra o mesmo include na trigger F5 do campo, e `Apply "F5":U to self` na trigger de duplo clique. Mostra também que o ThinZoom gera os campos de faixa dinamicamente e usa `setConstraint<Xxx>`, `openQueryStatic`, `returnFieldPage<N>` e o botão "Implantar" por página.
Fonte: apresentação "Desenvolvimento de Programas utilizando DDK2000" (cópia não oficial; link não incluído) [NÃO OFICIAL]

FAQ oficial relacionada: chave duplicada no zoom (ThinTemplate + DBO) se resolve com o preprocessador `ROW-NUM-DEFINED` e o campo `RowNum` na temp-table de comunicação.
Fonte: https://tdn.totvs.com/pages/viewpage.action?pageId=5255483 [OFICIAL]

---

## 7. Mensagens e utilitários

### 7.1 utp/ut-msgs.p

Objetivo: mostrar ao usuário uma mensagem cadastrada no Sistema de Mensagens, ou devolver propriedades dela ao programa.

Assinatura (marcadores reconstruídos): `run utp/ut-msgs.p (input <ação>, input <número>, input <parâmetros>).`

| Ação | Resultado |
|---|---|
| "show" | Apresenta a mensagem, com o texto de ajuda no padrão do produto. |
| "msg" | Retorna o texto da mensagem. |
| "help" | Retorna o texto de ajuda. |
| "type" | Retorna o tipo (Erro, Advertência, Informação ou Questão). |
| "codtype" | Retorna o código do tipo: 0 não cadastrada, 1 erro, 2 advertência, 3 pergunta, 4 informação. |

- Parâmetros da mensagem: valores separados por `~~`. Substituem &1, &2, &3 no texto e no help. Exemplo: `input repres.cod-repres + "~~" + regiao.cod-regiao + "~~" + string(regiao.val-minimo)`.
- O retorno de "msg", "help", "type" e "codtype" vem no return-value.
- Pergunta: depois do "show", o return-value é "yes" ou "no".
- A barra de título mostra o tipo e o número. Exemplo: "Pergunta: (10)".
- Mensagem substituta: se a mensagem tem substituta, a substituta é mostrada. O título mostra os dois números.
- A caixa tem o botão "trace", que mostra a pilha de execução.
- Também serve para imprimir mensagens em logs.
- Só a Datasul cadastra mensagens (programa `utp/ut-cdmsg.p`). Clientes e parceiros usam as já cadastradas ou o comando MESSAGE.
- Atenção: um exemplo do manual escreve a ação como "msgs". A tabela e os outros exemplos usam "msg".

Fonte: MANUAL, cap. 6 "UT-MSGS.P", cap. 7 "UT-MSGS.P" e cap. 15 "Como implementar mensagens para o usuário" [NÃO OFICIAL]

Mensagens genéricas para programas específicos (oficial):

| Número | Tipo |
|---|---|
| 32278 | Erro |
| 32279 | Aviso |
| 32280 | Pergunta |
| 32281 | Informação |

- Uso: `run utp/ut-msgs.p (input "show":U, input 32278, input substitute("&1~~&2":U, "Mensagem", "Help (texto)"))`.
- Na pergunta, testar `Return-value = 'YES':U`.
- A mesma FAQ repete: a manutenção do Sistema de Mensagens é só da Datasul.

Fonte: https://tdn.totvs.com/pages/viewpage.action?pageId=5270359 [OFICIAL]

Outras mensagens genéricas citadas oficialmente: 17006 (erro, com texto e ajuda passados por parâmetro) e 19085 (informação), no modelo de programa específico de atributos automáticos.
Fonte: https://tdn.totvs.com/pages/viewpage.action?pageId=269419389 [OFICIAL]

### 7.2 utp/ut-liter.i

- Objetivo: usar o cadastro de literais do Datasul-EMS. Cadastra a literal e devolve a tradução no idioma corrente.
- Sintaxe (marcadores reconstruídos): `{utp/ut-liter.i <literal> <contexto> <alinhamento>}`.
- Literal: espaços trocados por "_". Se terminar com ":U", não é traduzida e volta sem esses dois caracteres.
- Contexto: opcional. É um módulo do produto. Omitido, vale o contexto universal `*`.
- Alinhamento: opcional. Diz onde vai o espaço extra de tradução: L esquerda, C centralizado, R direita.
- Retorno: return-value.
- Exemplo: `{utp/ut-liter.i Lista_Narrativa MCE R}` e depois atribuir o return-value ao label.
- No modelo multi-idiomas, o alinhamento não muda o resultado. Fica por compatibilidade. Forma em programa: `run utp/ut-liter.p (input "Teste", "*", "")`.

Fonte: MANUAL, cap. 6 "UT-LITER.I" e cap. 7 "UT-LITER.P" [NÃO OFICIAL]

### 7.3 Utilitários correlatos

- **utp/ut-field.i**: devolve propriedade de campo do dicionário. `{utp/ut-field.i <banco> <tabela> <campo> <n>}`. n: 1 Label, 2 Column-Label, 3 Help, 4 Format, 5 Initial, 6 Description, 7 Data Type. Retorno no return-value. Exemplo: `{utp/ut-field.i mgadm conta tipo 1}`.
  Fonte: MANUAL, cap. 6 "UT-FIELD.I" [NÃO OFICIAL]
- **utp/ut-table.i**: devolve propriedade de tabela. `{utp/ut-table.i <banco> <tabela> <n>}`. n: 1 File-Label, 2 Dump_Name, 3 Desc. Uso: label de campo calculado em browser e literais com função de label.
  Fonte: MANUAL, cap. 6 "UT-TABLE.I" [NÃO OFICIAL]
- **utp/ut-glob.i**: define as variáveis globais. Já vem dentro dos SmartObjects. Variáveis citadas: `i-ep-codigo-usuario` (empresa corrente do usuário), `l-implanta` (zoom), `c-seg-usuario` (usuário logado no menu).
  Fonte: MANUAL, cap. 6 "UT-GLOB.I" [NÃO OFICIAL]
- **utp/ut-acomp.p**: usar em processo longo ou sem total conhecido de registros. Mantém o usuário informado e evita o erro "Tempo de inatividade excedido" na Automação de Tarefas. Passos: variável handle; `RUN utp/ut-acomp.p PERSISTENT SET h-acomp`; `RUN pi-inicializar IN h-acomp (INPUT "texto")`; `RUN pi-acompanhar IN h-acomp (INPUT texto)` a cada iteração; `RUN pi-finalizar IN h-acomp`. Boa prática: compartilhar o mesmo handle entre programa chamador e chamado. Em Automação de Tarefas o utilitário grava no máximo uma vez por minuto.
  Fonte: https://tdn.totvs.com/pages/viewpage.action?pageId=880062057 [OFICIAL]
- **utp/ut9000.i**: define os eventos padrão de UPC da tela (ver 4.5) e monta o título da tela (ver 5.1).
  Fontes: https://tdn.totvs.com/pages/viewpage.action?pageId=5265497 [OFICIAL]; MANUAL, cap. 4 [NÃO OFICIAL]
- **utp/ut-vlarq.p**: valida o arquivo informado na tela de importação. Return-value "nok" indica erro.
  Fonte: MANUAL, cap. 8 [NÃO OFICIAL]
- **utp/ut-trfrrp.p**: traduz uma frame (ver 3.7).
  Fonte: MANUAL, cap. 7 [NÃO OFICIAL]
- **utp/utapi033.p**: gera planilha eletrônica sem MS Excel instalado. Gera XML no padrão Excel. Uso: `RUN utp/utapi033.p PERSISTENT SET h-handle`, depois `piColumn` (ou `piWorksheetColumn` com mais de uma aba). Parâmetros de piColumn: pColumn, pDataType (char, date, decimal, int, logical), pLabel, pFormat, pWidth.
  Fonte: https://tdn.totvs.com/pages/viewpage.action?pageId=793208144 [OFICIAL]
- **utp/utapi019.p**: API de envio de e-mail. Includes de parâmetros: `utp/utapi019.i`, `.i1`, `.i2` e `utp/ut-mail-api.i`. O `.i2` define as temp-tables passadas à API (exemplo: tt-envio2). Funciona em Windows e UNIX. Usa Blat, Outlook ou Datasul Mail Service. Em sessão batch no Windows usa sempre o Blat.
  Fonte: https://tdn.totvs.com/display/LDT/UTAPI019+-+API+de+Envio+de+E-mail [OFICIAL]
- **include/i-prgvrs.i**: ver 5.10.

---

## Não encontrado

Itens procurados e **não encontrados na documentação pública** aberta nesta pesquisa.

**Templates (pelo nome do arquivo)**

1. `w-paifil`: nome não encontrado. O manual de 2007 usa `Masters/w-adf.w` para Pai x Filho – Atualiza Filho.
2. `w-incsim`: nome não encontrado.
3. `w-inccom`: nome não encontrado. O manual usa `Masters/w-incmo3.w` para Inclui/Modifica Filho.
4. `w-livre`: não encontrado.
5. `w-window`: não encontrado.
6. `d-dialog`: nome não encontrado. O TDN só descreve o tipo "Custom Dialog".
7. `w-cadco2`: grafia não encontrada. O manual escreve `w-cadcon2.w`.

**SmartObjects (pelo nome do arquivo)**

8. `c-viewer`. 9. `c-browse`. 10. `c-brows2`. 11. `c-brows3`. 12. `c-brows4`. 13. `c-brows5`. 14. `c-brwzoo`. 15. `c-brwfrm`. 16. `c-brwupd`. 17. `c-query`. 18. `c-page`.
Nenhum desses nomes aparece. As diferenças entre c-browse e c-brows2..5 não estão documentadas. O manual só cita `vieweraf.w`, `wquery.w`, `wbrwzoo.w` e `b-digit.w`.

**Painéis**

19. `p-cadsi2`. 20. `p-cadsi3`. 21. `p-cadsi4`. Sem descrição. A seção do manual que trataria dos modos de inclusão (Simple/Multiple) não veio na cópia.
22. Descrição própria de `p-navega`, `p-exihel`, `p-cadsim` e `p-cadpai`: só existem os links. As figuras do capítulo "Painéis" não vieram.

**Relatório**

23. `i-rpini.i` (função). 24. `i-rplbl.i`. 25. `i-rpexa.i`. 26. `i-rpexb.i`. 27. `i-rpexc.i`. 28. `i-rptrm.i`. 29. `i-rptrp.i`. 30. `i-rparq.i`. 31. `i-rpimp.i`. 32. `i-rprse.i`.
33. Função de `i-rpcb80.i` e `i-rpc255.i`: só citados.
34. Preparação do relatório para RPW no código (seção "JOB EXECUTION" do manual): perdida na cópia.
35. Página de impressão e parâmetros de impressão (80/132 colunas): perdidas na cópia.

**Importação**

36. `i-imvar.i`. 37. `i-imini.i`. Não citados. Foram achados `i-immbl.i`, `i-imvrf.i`, `i-imarq.i` e `i-imrun.i`.

**UPC/EPC**

38. Lista oficial completa de eventos por tipo de template (ADD, DELETE, VALIDATE, ASSIGN, BEFORE-ASSIGN, DESTROY...). A busca do TDN por "BEFORE-ASSIGN" não retornou nada.
39. Significado de cada parâmetro (p-ind-event, p-ind-object, p-wgh-object, p-wgh-frame, p-cod-table, p-row-table). Só nomes e tipos.
40. Valores possíveis de p-ind-object além de "CONTAINER".
41. "Guia de Customização para o Produto", citado pelo TDN: não localizado em página pública.

**Interface**

42. Fontes e cores padrão (só há a fonte "2" para editores).
43. Significado de cada segmento da versão do i-prgvrs.i.

**Zoom**

44. `zoom.i` (só o nome `zoom/zoom.i` aparece numa lista de includes). 45. `zoomvarreposition.i`. 46. `method/zoomreposition.i`.
47. Botão de filtro em zoom e reposicionamento automático do browser de zoom: seções perdidas na cópia.

**Utilitários**

48. `include/i-license-manager.i`: a busca do TDN achou o nome em três páginas de API REST. Nenhuma descreve o include. Não abertas.

**Fontes que não puderam ser lidas**

- Central de Atendimento (centraldeatendimento.totvs.com): bloqueada (HTTP 403 / Cloudflare 1034). Artigos indicados pelo buscador, **não abertos**:
  - "Framework - Linha Datasul - FRW - Diferenças entre o DDK 2000 e o DDK GUI": https://centraldeatendimento.totvs.com/hc/pt-br/articles/360051402993
  - "Framework - Linha Datasul - FRW - Instalação do DDK": https://centraldeatendimento.totvs.com/hc/pt-br/articles/360051397913
  - "Framework - Linha Datasul - FRW - Criar atalho de compilação para o DDK": https://centraldeatendimento.totvs.com/hc/pt-br/articles/360040016593
  - "Framework - Linha Datasul - FRW - Uso de api's e desenvolvimento de específicos": https://centraldeatendimento.totvs.com/hc/pt-br/articles/24267946683031
- Scribd "Customização UPC" (39 páginas): texto ofuscado, ilegível. O buscador indica que ele tem tabela de eventos por template. Não confirmado. https://pt.scribd.com/document/462234594/76645284-Customizao-UPC
- ptdocz "Datasul - 0407 - DDK-GUI": a página não traz o corpo do documento. https://ptdocz.com/doc/1477508/datasul---0407---ddk-gui
- Scribd "TOTVS Datasul DDK 0408" e "Manual de Padrões Totvs DDK": não abertos.

---

## Páginas consultadas

**TDN – abertas e lidas [OFICIAL]**

- https://tdn.totvs.com/pages/viewpage.action?pageId=467764464 (Manutenção de Programa – MEN012AA)
- https://tdn.totvs.com/display/LDT/SO0700G+-+Programa+UPC
- https://tdn.totvs.com/display/LDT/MSO+-+Tecnologia+DDK+GUI
- https://tdn.totvs.com/pages/viewpage.action?pageId=5254517 (DDK2000 x DDK GUI)
- https://tdn.totvs.com/pages/viewpage.action?pageId=5265497 (FAQ 914 – eventos padrão na UPC)
- https://tdn.totvs.com/pages/viewpage.action?pageId=5266686 (FAQ 52722 – exemplo de UPC do login)
- https://tdn.totvs.com/pages/viewpage.action?pageId=5266955 (FAQ 1956 – UPC de dicionário)
- https://tdn.totvs.com/pages/viewpage.action?pageId=607587916 (WM0372a – ponto de entrada)
- https://tdn.totvs.com/pages/viewpage.action?pageId=699825541 (DT EN0101 – ponto de customização)
- https://tdn.totvs.com/pages/viewpage.action?pageId=337356771 (RE2001Z – pontos de UPC padrões)
- https://tdn.totvs.com/pages/viewpage.action?pageId=607853692 (GG2000 – pontos padrões na pesquisa)
- https://tdn.totvs.com/pages/viewpage.action?pageId=694092342 (GG0108)
- https://tdn.totvs.com/pages/viewpage.action?pageId=269070467 (MLOG-491)
- https://tdn.totvs.com/pages/viewpage.action?pageId=271406715 (CE0830 – BEFORE-OPEN-QUERY)
- https://tdn.totvs.com/pages/viewpage.action?pageId=496036111 (CE0206 – eventos UPC)
- https://tdn.totvs.com/pages/viewpage.action?pageId=951325220 (CP0324 – AFTER-END-UPDATE)
- https://tdn.totvs.com/pages/viewpage.action?pageId=905131991 (UPC – ROWID no AFTER-ASSIGN)
- https://tdn.totvs.com/pages/viewpage.action?pageId=599050201 (DFWKFOUNDATION-5006)
- https://tdn.totvs.com/pages/viewpage.action?pageId=819058131 (DFWKDATASUL-2256 – ignorar UPC)
- https://tdn.totvs.com/pages/viewpage.action?pageId=824199790 (DFWKDATASUL-2257 – ignorar UPC)
- https://tdn.totvs.com/pages/viewpage.action?pageId=267792684 (UPC na impressão de notas fiscais)
- https://tdn.totvs.com/pages/viewpage.action?pageId=235313167 (Customização via EPC – EX0165)
- https://tdn.totvs.com/pages/viewpage.action?pageId=5264077 (FAQ 55831 – programa de pesquisa DDK)
- https://tdn.totvs.com/pages/viewpage.action?pageId=5255185 (páginas no AppBuilder com DDK)
- https://tdn.totvs.com/pages/viewpage.action?pageId=5268721 (FAQ 889 – folder em tempo de execução)
- https://tdn.totvs.com/pages/viewpage.action?pageId=5268889 (FAQ 891 – página corrente smart object)
- https://tdn.totvs.com/pages/viewpage.action?pageId=5269569 (FAQ 892 – página corrente ThinTemplate)
- https://tdn.totvs.com/pages/viewpage.action?pageId=5262213 (FAQ 897 – duas chamadas da zoomvar.i)
- https://tdn.totvs.com/pages/viewpage.action?pageId=5265064 (FAQ 913 – duplo clique no browse)
- https://tdn.totvs.com/pages/viewpage.action?pageId=5269129 (FAQ 907 – tipo de template)
- https://tdn.totvs.com/pages/viewpage.action?pageId=5270359 (FAQ 40028 – mensagens em programas customizados)
- https://tdn.totvs.com/pages/viewpage.action?pageId=5264574 (FAQ 1100 – includes úteis ThinTemplate)
- https://tdn.totvs.com/pages/viewpage.action?pageId=5261835 (FAQ 1099 – procedures obrigatórias ThinTemplate)
- https://tdn.totvs.com/pages/viewpage.action?pageId=5269047 (FAQ 911 – posicionamento de query)
- https://tdn.totvs.com/pages/viewpage.action?pageId=5255483 (chave duplicada no zoom)
- https://tdn.totvs.com/pages/viewpage.action?pageId=852313960 (Destino dos Relatórios)
- https://tdn.totvs.com/pages/viewpage.action?pageId=852319080 (Execução dos Relatórios)
- https://tdn.totvs.com/pages/viewpage.action?pageId=223162816 (Impressão em escala)
- https://tdn.totvs.com/pages/viewpage.action?pageId=677028539 (Adequação include i-rpout.i)
- https://tdn.totvs.com/pages/viewpage.action?pageId=220890649 (crm047rp)
- https://tdn.totvs.com/pages/viewpage.action?pageId=269419389 (Modelo Programa Específico)
- https://tdn.totvs.com/pages/viewpage.action?pageId=880062057 (Utilitário de acompanhamento UT-ACOMP)
- https://tdn.totvs.com/pages/viewpage.action?pageId=793208144 (utapi033)
- https://tdn.totvs.com/display/LDT/UTAPI019+-+API+de+Envio+de+E-mail
- https://tdn.totvs.com/pages/viewpage.action?pageId=526996733 (versionamento do ut-msgs.p)
- https://tdn.totvs.com/pages/viewpage.action?pageId=479825599 (ut-msgs em ambiente TTY)
- https://tdn.totvs.com/pages/viewpage.action?pageId=516622632 (apresentação das mensagens)
- https://tdn.totvs.com/pages/viewpage.action?pageId=653589727 (extrato de versão no appserver)
- https://tdn.totvs.com/pages/viewpage.action?pageId=107383141 (mídia do DDK)
- https://tdn.totvs.com/pages/viewpage.action?pageId=224442171 (template de relatório ThinTemplate)

**TDN – busca e árvore de páginas**

- https://tdn.totvs.com/dosearchsite.action (dezenas de consultas, entre elas todos os nomes de template, include e utilitário do pedido)
- Árvores listadas: Framework - Documento de Referência (pageId=201731338), Documentação complementar (562955278), Utilitários - FWK/TEC (562961551), Acervo - Framework (244416838), Documentações de UTAPIs (857586913), Facilitadores - Relatórios (852313753)

**Fora do TDN [NÃO OFICIAL]**

- Manual de Padrões – Programação EMS 2.0, Nov/2007, Datasul S.A. (cópia não oficial, link não incluído; lido por trechos)
- O mesmo manual, edição Março/2006 (cópia não oficial, link não incluído; só conferidos o índice e a ausência de UPC)
- Apresentação "Desenvolvimento de Programas utilizando DDK2000", 41 páginas (cópia não oficial, link não incluído)
- https://progressparavoce.blogspot.com/2011/07/exemplo-de-uma-upc-basica.html (exemplo de UPC)

**Tentadas sem sucesso**

- https://centraldeatendimento.totvs.com/ (bloqueada)
- https://pt.scribd.com/document/462234594/76645284-Customizao-UPC (texto ilegível)
- https://ptdocz.com/doc/1477508/datasul---0407---ddk-gui (sem corpo)

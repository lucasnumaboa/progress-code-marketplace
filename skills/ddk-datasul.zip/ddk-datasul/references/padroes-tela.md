# Padrões de tela observados

Contagem feita em 20/11/2026 nos `.w` legíveis (programas do produto e de projeto). São os valores que os programas usam de fato; quando houver norma na documentação, ela está em `documentacao-publica.md` seção 5.
Medidas em unidades de caractere do AppBuilder (largura BY altura).

## Tamanho da janela por tipo de programa

| Tipo (`PROCEDURE-TYPE`) | Largura x altura (ocorrências) |
|---|---|
| `BrowserCadastro2` | 86 x 9.71 (2); 66 x 8.25 (1); 66 x 8.29 (1); 66 x 7.5 (1) |
| `Formation` | 90 x 16.5 (1) |
| `JanelaDetalhe` | 67.14 x 10.21 (1); 80 x 4.46 (1); 80 x 6.33 (1); 80 x 5.33 (1); 82 x 10 (1) |
| `Maintenance` | 89.72 x 17.71 (1); 90 x 4.08 (1); 90 x 16.75 (1); 90 x 13.25 (1) |
| `MaintenanceNoNavigation` | 90.14 x 7.13 (1); 90 x 5.92 (1) |
| `MasterDetail` | 90 x 17 (2); 93.14 x 16.75 (1); 90 x 15.83 (1); 90 x 16.38 (1); 89.86 x 15.5 (1) |
| `SmartBrowser` | 80.14 x 10.17 (8); 85 x 10.17 (4); 80.14 x 10.75 (2); 64.29 x 9.88 (2); 71.86 x 10.17 (2); 80.14 x 10.71 (1); 80.14 x 10.58 (1); 55 x 10.17 (1) |
| `SmartPanel` | 16 x 1.25 (2) |
| `SmartPanelCadastro` | 16 x 1.25 (3); 28 x 1.25 (1) |
| `SmartPanelNavega` | 24 x 1.25 (1) |
| `SmartQuery` | 22 x 1.33 (13) |
| `SmartViewer` | 88.57 x 10.25 (2); 91 x 13 (2); 88.57 x 13 (2); 97.57 x 13 (1); 92.29 x 2.75 (1); 88.57 x 5.75 (1); 79.29 x 2.5 (1); 85.86 x 9.08 (1) |
| `SmartWindow` | 90 x 17 (12); 112.43 x 20.75 (1); 71.57 x 8.46 (1); 89.86 x 16.79 (1); 89.72 x 13.08 (1); 89 x 11.83 (1); 90 x 6.54 (1); 88.14 x 18.08 (1) |
| `Window` | 90 x 17 (4); 89 x 8.42 (1); 78 x 9.13 (1); 90 x 20.92 (1); 90 x 21.46 (1); 141.14 x 21.5 (1); 92.43 x 13.58 (1); 68.43 x 3.67 (1) |
| `Zoom` | 90.43 x 15.54 (1) |
| `w-cadcom` | 90 x 17.42 (1); 86.57 x 16 (1) |
| `w-cadsim` | 90 x 12.13 (2); 90 x 13.17 (1); 90 x 6.17 (1); 89.29 x 9.38 (1); 90 x 8.54 (1); 90 x 9.54 (1); 88.14 x 10.54 (1); 90 x 9.71 (1) |
| `w-form2` | 89.86 x 14.38 (1) |
| `w-forma` | 90 x 15.96 (1) |
| `w-incmdp` | 90 x 11.83 (1); 90 x 10.21 (1); 90 x 7.67 (1) |
| `w-incmod` | 80.72 x 6.75 (2); 80.72 x 5.46 (2); 80.72 x 7.88 (1); 80 x 3.96 (1); 89.72 x 5.08 (1) |
| `w-livre` | 112.43 x 20.92 (1); 201.14 x 30.29 (1) |
| `w-paifil` | 90 x 16.75 (2) |
| `w-relat` | 81.14 x 15 (6); 81 x 17.63 (1) |
| `w-window` | 90 x 7.67 (1) |

Leitura: janela de cadastro e de consulta tem 90 de largura; `w-relat` tem 81.14 x 15; janela inclui/modifica, 80.72.

## Botões

### Botão de texto

| SIZE | Ocorrências |
|---|---|
| 10 BY 1 | 222 |
| 10 BY 1 | 155 |
| 4 BY 1.25 | 30 |
| 4 BY 1.25 | 25 |
| 4 BY 1 | 16 |
| 15 BY 1 | 14 |
| 12 BY 1.08 | 12 |
| 5.14 BY 1 | 9 |

### Botão com imagem

| SIZE | Ocorrências |
|---|---|
| 4 BY 1.25 | 129 |
| 4 BY 1.25 | 65 |
| 4 BY 1 | 25 |
| 5.14 BY 1 | 19 |
| 4 BY 1 | 12 |
| 18.43 BY 1.71 | 10 |
| 10 BY 1 | 7 |
| 4 BY 1.08 | 5 |

Leitura: botão de texto é `10 BY 1`; botão de ícone é `4 BY 1.25` (painéis) ou `4 BY 1`.

## Campos

### Altura do FILL-IN

| Altura | Ocorrências |
|---|---|
| .88 | 406 |
| 1 | 26 |
| .88 | 11 |
| .79 | 11 |
| 0.88 | 1 |
| .5 | 1 |

### Altura do TOGGLE-BOX

| Altura | Ocorrências |
|---|---|
| .83 | 193 |
| .67 | 31 |
| 1.08 | 15 |
| .75 | 8 |
| .83 | 8 |
| .71 | 5 |
| .88 | 4 |
| 1 | 4 |

Leitura: `FILL-IN` com altura `.88`; `TOGGLE-BOX` com `.83`.

## Retângulos padrão

| Nome | Tamanho e cor (ocorrências) |
|---|---|
| `rt-botoes` | 68 BY 1.5. (1) |
| `rt-buttom` | 44 BY 1.42 BGCOLOR 7 (2); 68 BY 1.42 BGCOLOR 7 (2); 78 BY 1.42 BGCOLOR 7 (2); 41 BY 1.42 BGCOLOR 7 (2); 88 BY 1.42 BGCOLOR 7 (1); 61.72 BY 1.42 BGCOLOR 7 (1); 77.72 BY 1.42 BGCOLOR 7 (1); 79.14 BY 1.42 BGCOLOR 7 (1) |
| `rt-button` | 88.57 BY 1.46 BGCOLOR 7 (21); 88 BY 1.42 BGCOLOR 7 (13); 68 BY 1.42 BGCOLOR 7 (8); 90 BY 1.46 BGCOLOR 7 (5); 80 BY 1.42 BGCOLOR 7 (3); 88.86 BY 1.46 BGCOLOR 7 (2); 88.14 BY 1.42 BGCOLOR 7 (2); 88.43 BY 1.67 BGCOLOR 7 (2) |
| `rt-folder` | 79 BY 11.38 (12); 79 BY 14 (1) |
| `rt-folder-left` | .43 BY 11.21 BGCOLOR 15 (6); .43 BY 11.19 BGCOLOR 15 (6) |
| `rt-folder-right` | .43 BY 11.17 BGCOLOR 7 (6); .43 BY 11.15 BGCOLOR 7 (6) |
| `rt-folder-top` | 78.72 BY .13 BGCOLOR 15 (6); 78.72 BY .12 BGCOLOR 15 (6) |
| `rt-key` | 88.57 BY 1.25. (3); 90 BY 2.25. (2); 80 BY 1.25. (2); 79.29 BY 1.25. (1); 92.29 BY 1.25. (1); 87 BY 9.5. (1); 71 BY 3. (1); 71 BY 4.25. (1) |
| `rt-key-parent` | 87.86 BY 1.67. (1) |
| `rt-mold` | 88.57 BY 8.67. (2); 80 BY 1.25. (2); 79.29 BY 3.75. (1); 92.29 BY 1.25. (1); 88.57 BY 4.25. (1); 79.29 BY 2.5. (1); 85.86 BY 9. (1); 85.72 BY 8.75. (1) |
| `rt-mold-2` | 79.29 BY 2.58. (1) |
| `rt-notacred` | 21.14 BY 1.88. (1) |
| `rt-source-browse` | 38.57 BY 9.5. (1); 38.57 BY 9.63. (1) |
| `rt-source-browse-2` | 38.57 BY 9.5. (1); 38.57 BY 9.63. (1) |

Leitura: `rt-button` é a régua de botões do topo (altura 1.46 ou 1.42, `BGCOLOR 7`); `rt-key` e `rt-mold` são a moldura da chave e do corpo no viewer; `rt-folder*` desenham o folder das telas `w-relat`.

## Cores e fontes

### BGCOLOR

| BGCOLOR | Ocorrências |
|---|---|
| 8 | 309 |
| 7 | 197 |
| 15 | 140 |
| 1 | 18 |

### FONT

| FONT | Ocorrências |
|---|---|
| 4 | 151 |
| 1 | 143 |
| 2 | 82 |
| 0 | 4 |
| 3 | 4 |
| 6 | 1 |

Tabela de fontes da sessão usada no levantamento (arquivo `.ini` do sandbox): 0 e 2 e 3 = Courier New 8; 1, 4 e 7 = MS Sans Serif 8; 5 = MS Sans Serif 10; 6 e 10 = MS Sans Serif 8 negrito; 8 = itálico; 9 = MS Sans Serif 6; 11 = tamanho 9; 12 = tamanho 7; 13 = Courier New 6; 14 = MS Sans Serif 10 negrito; 15 = Courier New 10. No cliente a tabela vem do `.ini` do Datasul: confira lá.

## Menu padrão do container de cadastro

| Item | Rótulo | Atalho | Ocorrências |
|---|---|---|---|
| `mi-sair` | &Sair | CTRL-X | 41 |
| `mi-imprimir` | &Relatórios | CTRL-P | 40 |
| `mi-sobre` | &Sobre... | - | 40 |
| `mi-primeiro` | &Primeiro | CTRL-HOME | 39 |
| `mi-anterior` | An&terior | CTRL-CURSOR-LEFT | 39 |
| `mi-proximo` | Pr&óximo | CTRL-CURSOR-RIGHT | 39 |
| `mi-ultimo` | &Último | CTRL-END | 39 |
| `mi-va-para` | &Vá para | CTRL-T | 39 |

Menu completo, como está no modelo de cadastro pai e filho: Arquivo (Primeiro `CTRL-HOME`, Anterior `CTRL-CURSOR-LEFT`, Próximo `CTRL-CURSOR-RIGHT`, Último `CTRL-END`, Vá para `CTRL-T`, Pesquisa `CTRL-F5`, Consultas `CTRL-L`, Relatórios `CTRL-P`, Sair `CTRL-X`) e Ajuda (Conteúdo, Sobre...).

## Frames por tipo de programa

| Tipo | Frames (ocorrências) |
|---|---|
| `BrowserCadastro2` | f-main (5) |
| `DIALOG-BOX` | attribute-dlg (3); sp-attr-dialog (2); dialog-frame (1); dbowizard (1); f-pagina-1 (1); f-pagina-2 (1); f-pagina-0 (1) |
| `Dialog-Box` | fpage0 (2); fmain (1); fpage4 (1); fpage2 (1); fpage3 (1); fpage1 (1); dialog-frame (1) |
| `Formation` | fpage0 (1); fpage1 (1); fgotorecord (1) |
| `JanelaDetalhe` | f-main (5) |
| `Maintenance` | fpage0 (4); fgotorecord (4); fpage1 (2); fpage3 (1); fpage5 (1); fpage4 (1); fpage2 (1); fparameters (1) |
| `MaintenanceNoNavigation` | fpage0 (2) |
| `MasterDetail` | fpage0 (6); fpage1 (6); fgotorecord (6); fselection (1) |
| `SmartBrowser` | f-main (31) |
| `SmartDialog` | d-dialog (12); d-narrativa (2); d-carac-tec (1); tg-oculta-inativos (1) |
| `SmartPanel` | panel-frame (2) |
| `SmartPanelCadastro` | panel-frame (4) |
| `SmartPanelNavega` | panel-frame (1) |
| `SmartVaPara` | d-vapara (9) |
| `SmartViewer` | f-main (18) |
| `SmartWindow` | f-cad (26); f-zoom (16); fpage3 (2); fpage0 (1); fpage2 (1); fpage1 (1); fpage6 (1); statement (1) |
| `Window` | fpage0 (8); fpage2 (3); default-frame (3); fpage6 (3); frame-c (2); frame-b (2); frame-a (2); fpage1 (1) |
| `Zoom` | fpage0 (1); fpage1 (1) |
| `w-cadcom` | f-cad (2) |
| `w-cadsim` | f-cad (11) |
| `w-form2` | f-formation (1) |
| `w-forma` | f-cad (1) |
| `w-incmdp` | f-cad (3) |
| `w-incmod` | f-cad (7) |
| `w-livre` | f-cad (2) |
| `w-paifil` | f-cad (2) |
| `w-relat` | f-relat (7); f-pg-imp (7); f-pg-sel (7); f-pg-par (4); f-pg-dig (1) |
| `w-window` | f-cad (1) |

Nos programas DDK clássico de projeto: container `f-cad`; viewer `f-main`; relatório `f-relat`, `f-pg-sel`, `f-pg-cla`, `f-pg-par`, `f-pg-dig`, `f-pg-imp`.

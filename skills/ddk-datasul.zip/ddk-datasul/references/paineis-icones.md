# Painéis e ícones

Levantamento de 20/11/2026.

## Como um botão com ícone é declarado

```
DEFINE BUTTON bt-sav
     IMAGE-UP FILE "image\im-sav":U
     IMAGE-INSENSITIVE FILE "image\ii-sav":U
     LABEL "" 
     SIZE 4 BY 1.25.
```

- O arquivo vai **sem extensão**. `im-` é a imagem do botão habilitado; `ii-` é a do desabilitado (mesmo nome depois do prefixo).
- Nem todo `im-` tem o par `ii-` (lista no fim). Conferir antes de usar `IMAGE-INSENSITIVE`.
- A dica do botão dos painéis vem do `HELP` na definição do frame.

## Botões dos painéis padrão

Fonte: `ddk/panel/*.w` (legível).

| Painel | Botão | Ícone | Ajuda | Procedure do painel |
|---|---|---|---|---|
| `panel/p-cadpai.w` | `bt-add` | `im-add` | Inclui nova ocorrência | `pi-incluir` |
| `panel/p-cadpai.w` | `bt-cop` | `im-copy` | Cria uma cópia da ocorrência corrente | `pi-copiar` |
| `panel/p-cadpai.w` | `bt-del` | `im-era` | Elimina ocorrência corrente | `pi-eliminar` |
| `panel/p-cadpai.w` | `bt-mod` | `im-mod` | Altera ocorrência corrente | `pi-alterar` |
| `panel/p-cadsi2.w` | `bt-can` | `im-can` | Cancela alterações | `pi-cancelar` |
| `panel/p-cadsi2.w` | `bt-mod` | `im-mod` | Altera ocorrência corrente | `pi-alterar` |
| `panel/p-cadsi2.w` | `bt-sav` | `im-sav` | Confirma alterações | `pi-salvar` |
| `panel/p-cadsi2.w` | `bt-und` | `im-undo` | Desfaz alterações | `pi-desfazer` |
| `panel/p-cadsi3.w` | `bt-add` | `im-add` | Inclui nova ocorrência | `pi-incluir` |
| `panel/p-cadsi3.w` | `bt-can` | `im-can` | Cancela alterações | `pi-cancelar` |
| `panel/p-cadsi3.w` | `bt-sav` | `im-sav` | Confirma alterações | `pi-salvar` |
| `panel/p-cadsi3.w` | `bt-und` | `im-undo` | Desfaz alterações | `pi-desfazer` |
| `panel/p-cadsi4.w` | `bt-add` | `im-add` | Inclui nova ocorrência | `pi-incluir` |
| `panel/p-cadsi4.w` | `bt-can` | `im-can` | Cancela alterações | `pi-cancelar` |
| `panel/p-cadsi4.w` | `bt-sav` | `im-sav` | Confirma alterações | `pi-salvar` |
| `panel/p-cadsi4.w` | `bt-und` | `im-undo` | Desfaz alterações | `pi-desfazer` |
| `panel/p-cadsim.w` | `bt-add` | `im-add` | Inclui nova ocorrência | `pi-incluir` |
| `panel/p-cadsim.w` | `bt-can` | `im-can` | Cancela alterações | `pi-cancelar` |
| `panel/p-cadsim.w` | `bt-cop` | `im-copy` | Cria uma cópia da ocorrência corrente | `pi-copiar` |
| `panel/p-cadsim.w` | `bt-del` | `im-era` | Elimina ocorrência corrente | `pi-eliminar` |
| `panel/p-cadsim.w` | `bt-mod` | `im-mod` | Altera ocorrência corrente | `pi-alterar` |
| `panel/p-cadsim.w` | `bt-sav` | `im-sav` | Confirma alterações | `pi-salvar` |
| `panel/p-cadsim.w` | `bt-und` | `im-undo` | Desfaz alterações | `pi-desfazer` |
| `panel/p-exihel.w` | `bt-exi` | `im-exi` | Sair | `pi-sair` |
| `panel/p-exihel.w` | `bt-hel` | `im-hel` | Ajuda | `pi-ajuda` |
| `panel/p-exihel.w` | `bt-joi` | `im-joi` | Consultas relacionadas | `pi-consulta` |
| `panel/p-exihel.w` | `bt-pri` | `im-pri` | Relatórios relacionados | `pi-imprimir` |
| `panel/p-navega.w` | `bt-fir` | `im-fir` | Primeira ocorrência | `pi-primeiro` |
| `panel/p-navega.w` | `bt-go` | `im-enter` | Vá Para | `pi-vapara` |
| `panel/p-navega.w` | `bt-las` | `im-las` | Última ocorrência | `pi-ultimo` |
| `panel/p-navega.w` | `bt-nex` | `im-nex` | Próxima ocorrência | `pi-proximo` |
| `panel/p-navega.w` | `bt-pre` | `im-pre` | Ocorrência anterior | `pi-anterior` |
| `panel/p-navega.w` | `bt-sea` | `im-sea` | Pesquisa | `pi-pesquisa` |

A coluna da procedure é a de mesmo sentido que existe no painel (nome, não leitura do gatilho). Os menus dos containers chamam essas procedures: `RUN pi-primeiro IN h_p-navega.`

Tamanho dos painéis no layout: `p-navega` 24 x 1.25; `p-exihel` e `p-cadsi*` 16 x 1.25 (`p-cadsim` 28 x 1.25).

## Ícones mais usados nos fontes legíveis

| Ícone | Usos | Em quais widgets | Texto associado (ajuda, dica ou rótulo) |
|---|---|---|---|
| `im-flddn` | 120 | load-image(120) | - |
| `im-fir` | 48 | image-1(9), btfirst(8), image-5(6) | Primeira ocorrência / Remover todos / Minimizar |
| `im-las` | 48 | btlast(8), image-2(8), image-6(6) | Última ocorrência / Adicionar todos / Minimizar |
| `im-fldup` | 46 | load-image(30), im-pg-imp(6), im-pg-sel(6) | - |
| `ii-fir` | 35 | image-1(21), btfirst(8), image-3(2) | Primeira ocorrência / Remover todos / Minimizar |
| `ii-las` | 35 | image-2(21), btlast(8), image-4(2) | Última ocorrência / Adicionar todos / Minimizar |
| `im-sav` | 30 | bt-confirma(19), btsave(5), bt-sav(5) | Button 1 / Confirma alterações / Confirma |
| `im-sea` | 27 | btsearch(8), bt-arquivo(6), bt-modelo-rtf(3) | Escolha do nome do arquivo / Pesquisa / Escolha o arquivo de modelo |
| `ii-sea` | 25 | btsearch(8), bt-arquivo(6), bt-modelo-rtf(3) | Escolha do nome do arquivo / Pesquisa / Escolha o arquivo de modelo |
| `im-can` | 17 | btcancel(10), bt-can(7) | Cancela alterações |
| `ii-sea1` | 17 | bt_can(10), btbuscaupc(1), button-1(1) | Cancela / Pesquisa / Btn 1 |
| `im-enter` | 13 | btgoto(8), btn-inicial-source(1), btn-inicial-target(1) | Vá Para / Minimizar / Enter p/ disponibilizar dados |
| `im-hel` | 13 | bthelp(11), bt-hel(1), bt-minimizar(1) | Ajuda / Help / Minimizar |
| `im-exi` | 12 | btexit(10), bt-exi(1), bt-minimizar(1) | Sair / Minimizar |
| `ii-exi` | 12 | btexit(10), bt-exi(1), bt-minimizar(1) | Sair / Minimizar |
| `ii-hel` | 12 | bthelp(10), bt-hel(1), bt-minimizar(1) | Ajuda / Minimizar |
| `im-pri` | 12 | btreportsjoins(10), bt-pri(1), bt-minimizar(1) | Relatórios relacionados / Minimizar |
| `ii-pri` | 12 | btreportsjoins(10), bt-pri(1), bt-minimizar(1) | Relatórios relacionados / Minimizar |
| `im-sea1` | 12 | bt_can(10), btbuscaupc(1), bt-minimizar(1) | Cancela / Pesquisa / Minimizar |
| `im-joi` | 11 | btqueryjoins(10), bt-joi(1) | Consultas relacionadas |
| `ii-joi` | 11 | btqueryjoins(10), bt-joi(1) | Consultas relacionadas |
| `im-add` | 11 | btadd(7), bt-add(4) | Inclui nova ocorrência |
| `ii-add` | 11 | btadd(7), bt-add(4) | Inclui nova ocorrência |
| `im-copy` | 10 | btcopy(8), bt-cop(2) | Cria uma cópia da ocorrência corrente |
| `ii-copy` | 10 | btcopy(8), bt-cop(2) | Cria uma cópia da ocorrência corrente |
| `ii-enter` | 10 | btgoto(8), bt-go(1), bt-minimizar(1) | Vá Para / Minimizar |
| `im-nex` | 10 | btnext(8), btadd(1), bt-nex(1) | Próxima ocorrência / Adicionar Selecionados |
| `ii-nex` | 10 | btnext(8), btadd(1), bt-nex(1) | Próxima ocorrência / Adicionar Selecionados |
| `im-pre` | 10 | btprev(8), btdel(1), bt-pre(1) | Ocorrência anterior / Remover selecionados |
| `ii-pre` | 10 | btprev(8), btdel(1), bt-pre(1) | Ocorrência anterior / Remover selecionados |
| `ii-sav` | 10 | btsave(5), bt-sav(5) | Confirma alterações / Localizar Processos de Pagamentos Pendentes |
| `im-mod` | 10 | btupdate(7), bt-mod(3) | Altera ocorrência corrente |
| `ii-mod` | 10 | btupdate(7), bt-mod(3) | Altera ocorrência corrente |
| `im-era` | 9 | btdelete(7), bt-del(2) | Elimina ocorrência corrente |
| `ii-era` | 9 | btdelete(7), bt-del(2) | Elimina ocorrência corrente |
| `im-undo` | 9 | btundo(5), bt-und(4) | Desfaz alterações |
| `ii-undo` | 9 | btundo(5), bt-und(4) | Desfaz alterações |
| `im-cfprt` | 9 | bt-config-impr(6), btconfigimpr(3) | Configuração da impressora |
| `im-lay` | 7 | bt-doc-localiz(3), bt-despacho(1), bt-localiz(1) | Dados Localização / Despacho a Plaza / Localização |
| `ii-lay` | 7 | bt-doc-localiz(3), bt-despacho(1), bt-localiz(1) | Dados Localização / Despacho a Plaza / Localização |
| `im-zoo` | 6 | bt_can(5), bt-minimizar(1) | Cancela / Minimizar |
| `ii-zoo` | 6 | bt_can(5), bt-minimizar(1) | Cancela / Minimizar |
| `im-chck1` | 6 | btcheck(1), btfiltrar(1), btfiltrar2(1) | Filtrar grupos / Filtrar programas / Filtrar |
| `im-sea2` | 5 | bt_can(5) | Cancela |
| `ii-sea2` | 5 | bt_can(5) | Cancela |
| `ii-chck1` | 5 | btfiltrar(1), btfiltrar2(1), btfiltrargrupo(1) | Filtrar grupos / Filtrar programas / Filtrar |
| `im-email` | 4 | bt_can(4) | Cancela |
| `im-param` | 4 | btparam(2), bt-nfse(1), btparameters(1) | Parâmetros / Configurações NFS-e TC2/TPF |
| `minimizar` | 4 | load-image(4) | - |
| `maximizar` | 4 | load-image(4) | - |
| `ii-param` | 3 | btparam(2), btparameters(1) | Parâmetros |
| `img-bt-ok-thf-small` | 3 | bt-ok(1), bt-finalizado(1), bt-sair-step-2(1) | &Ok |
| `img-bt-voltar-thf-small` | 3 | bt-voltar(1), bt-voltar-2(1), bt-voltar-5(1) | &Voltar |
| `im-hist` | 2 | bt-historico(2) | Históricos / Histórico |
| `dog` | 2 | bt-contato(2) | Contatos do Transportador |
| `veic` | 2 | button-1(2) | Veículos Transportador |
| `im-aloc1` | 2 | btnve(2) | Cadastro NVE |
| `ii-amort` | 2 | btmri(2) | MRI |
| `im-segur` | 2 | bt-seguranca(1), bt_seguranca4(1) | Grupo de Segurança |
| `ii-segur` | 2 | bt-seguranca(1), bt_seguranca4(1) | Grupo de Segurança |
| `img-bt-continuar-thf-small` | 2 | bt-ok-2(1), bt-continuar(1) | &Ok / &Continuar |
| `img-bt-nao-thf-small` | 2 | bt-nao-2(1), bt-nao-step-1(1) | &Não |
| `img-bt-sim-thf-small` | 2 | bt-sim-2(1), bt-sim-step-1(1) | &Sim |
| `img-page-identificacao` | 2 | image-27(1), image-30(1) | - |
| `im-nex1` | 2 | bt_can(1), bt-minimizar(1) | Cancela / Minimizar |
| `ii-nex1` | 2 | bt_can(1), bt-minimizar(1) | Cancela / Minimizar |
| `im-pre1` | 2 | bt_can(1), bt-minimizar(1) | Cancela / Minimizar |
| `ii-pre1` | 2 | bt_can(1), bt-minimizar(1) | Cancela / Minimizar |
| `im-excel` | 2 | load-image(2) | - |

Atenção: o mesmo ícone aparece com sentidos diferentes conforme a tela (ex.: `im-fir`/`im-las` são "primeiro/último" nos painéis e as setas de faixa "de/até" nas telas de relatório). O texto associado é o que os fontes mostram, não uma definição oficial do ícone.

`im-fldup` e `im-flddn` são as orelhas de aba (selecionada e não selecionada) das telas `w-relat`.

## Catálogo de `ddk/image`

arquivos: 2187 extensoes: {'.v$$': 1, '.bmp': 1085, '.gif': 924, '.jpg': 49, '.ico': 95, '.xls': 1, '.cur': 15, '.avi': 6, '.ini': 1, '': 4, '.bak': 1, '.b02': 1, '.bkp': 1, '.-3521737': 1, '.jbf': 1, '.db': 1}

nomes distintos: 1304 prefixos: {'im': 563, 'ii': 281, 'gr': 35, 'mab': 34, 'tv': 17, 'mip': 14, 'sfc': 14, 'aps': 13, 'db': 10, 'green': 10, 'red': 10, 'blue': 9}

### Ícones com par habilitado/desabilitado (`im-<nome>` + `ii-<nome>`)

abc abx1 acm1 acord add addall adduni agen1 agend alert alin alo amort apont aqu area ascii ativ autom bar2d bar3d bargraf barrashoriz battery bgcolor bluepert break button bxa calc calc2 calc4 calen calenclock can cance carac carg carga ccml chck1 chck2 check cla classe cllps clock clr combobox comments con-1 conc cone cop copbm copia copy copy3 cotac cq crit ctrab ctrl custo des desc dest-orig det det2 down down2 dump dw editorwgt edl elem emp enok enter envprog era era1 esto exc excel exi exp expal expan f-aps f-cad f-dc f-dv f-dw f-edi f-erp f-ibt f-ldo f-ms f-nps f-og f-pn favorites fecha ff fgcolor fil fillin fir fixed fold folder forma forne fornec gantt gera gmat grava grf grupo hel hist ini inici inl inl3 inl4 ita joi key large las lay linha lista livro lixo load local log mat mens mod modbm mov neg negoc nex nex1 nex2 ngrava notah notai npula ok open open2 orcto orig-dest pais par para parad param pause pay pcust pdf pedido pie2d pie3d ping pizz2 pizza plano play1 playprg plin pneu porte pre pre1 pre2 prep pri qtprd radioset ran ran_a raneg rea real recent rectang refre reini relo remall remuni repr2 respl restr rml rnl rpct rplc1 rstsr rt-vl run sampl sav save sea sea1 sea2 segu2 segur send seqhi servid setpr sfc1 show smfec solic stop stosr strsr stuffbox sub susp suspe tel termo teste-etq textwgt tick toggle tools total tpcpn transe trf turno txtpd undo uni up up2 usu vapra view wapadd wapdel wfile word word2 zoo

### Ícones só com a versão habilitada (`im-<nome>`, sem `ii-`)

abcfl about ajusi ajust aloc1 aloca aloci alteraitem amarelo amipr ampr3 ante appc arrob aval basuo battery2 begin bloq bloq3 bloqi branco brows bt-grupo-maq bt_cancelar bt_excluir calc1 calc3 calcu calend canc1 canc2 canc3 cancel carg2 carga2 cfprt chck3 chest chk1 chk3 cid cid2 class cldwn clean clr1 clr2 coes2 coest cofu2 cofun com con-i conci conf consulta conta contr cop2 cotof cta ctrlp dash ddk desc1 desc2 descricao desen desk det-nota dialo dicas down3 down4 downarrow dsktp dtcom dtsem dvw editok ednok edok eixo1 eixo2 eixo3 eixo4 eject email ems ems2 emsmn emsold end envia erro esp estat estri estru etiq exes2 exest exfu2 exfun expfunc exr extra extri f-ems faixa filem filem2 fin flddn flddn72 fldup fldup72 flmdn flmup fo formulacao forn foto foto1 foto2 fpv fullhand func func2 getfl gift gift2 gift3 globo-03 graycubeinside greencubeinside greengear grfcf grfcp grup1 grupo-maq helpclock hr100 idea idea2 idea3 idea4 imasc imems immag impt inf info inisp inl2 instr item led1 led2 led3 leftarrow legen lib1 lib1i liber log2 log3 lote mag manut1 max mod3 moeda moedi moon mov-i movim movto mqerr mqinf mqqst mqwar msdos nenhum netw new nex3 nf nolog notep ntwrk open3 opera operac orct1 orct2 ordr2 ordrh organ pag pagin pagina param2 paren pasta pastas pcc perfil perfilpadrao pid play plout pneug pre3 prep3 prigr profile propriedades prox ran2 ran3 ran5 ran5i ran_b rec recrd redcubeinside rede-op refr rep repri requis res res-i res-u rest rew rightarrow rightarrow2 rmtct rpcti runn sched sea1w sea3 select separ seqni seqni-disable shutd simul sist1 smabe smate solcot soluc tbasc teste thu tick1 time time1 todos top-d top-i tot trans transd tree uchk1 uchk2 uchk3 uchk4 unchk undo1 undo2 uo up3 up4 uparrow upc usr usr-i usuario verde vermelho view2 vs100 vsmag vsmagold warn wcalc wdk withlog wizau001 wizau002 wizau003 write zer-i zer-u zoom zoomd

Os nomes acima são só nomes de arquivo: o significado de cada um não foi levantado. Para escolher um ícone novo, abra a imagem em `ddk/image` do framework local e confira.

# UPC / EPC: parâmetros, eventos e cadastro

## Assinatura

Seis parâmetros de entrada, nesta ordem. Confirmado em dois exemplos oficiais
do TDN e em todas as UPCs de tela dos projetos lidos.

| Parâmetro | Tipo |
|---|---|
| `p-ind-event` | CHARACTER |
| `p-ind-object` | CHARACTER |
| `p-wgh-object` | HANDLE |
| `p-wgh-frame` | WIDGET-HANDLE |
| `p-cod-table` | CHARACTER |
| `p-row-table` | ROWID |

O significado de cada parâmetro não está descrito em página oficial aberta na
pesquisa. Pelo uso nos programas: evento, nome do objeto que chamou, handle do
objeto, frame do objeto, tabela e rowid do registro corrente. O valor de
`p-ind-object` visto em exemplos é `"CONTAINER"`; outros valores não foram
levantados: descubra com a UPC de log.

Retorno: `RETURN "OK"` ou `RETURN "NOK"`.

## Eventos

### Usados nas UPCs dos projetos

Contagem de 20/11/2026 nos fontes de projeto (`p-ind-event = "..."`):

| Evento | Ocorrências |
|---|---|
| `INITIALIZE` | 90 |
| `BEFORE-INITIALIZE` | 46 |
| `AFTER-ENABLE` | 37 |
| `VALIDATE` | 27 |
| `DISPLAY` | 26 |
| `ASSIGN` | 25 |
| `AFTER-INITIALIZE` | 20 |
| `BEFORE-DISPLAY` | 16 |
| `AFTER-DISABLE` | 15 |
| `CHOOSE` | 13 |
| `ENABLE` | 12 |
| `CHANGE-PAGE` | 12 |
| `AFTER-DISPLAY` | 10 |
| `AFTER-CHANGE-PAGE` | 10 |
| `AFTER-ASSIGN` | 9 |

Eventos próprios de um programa também aparecem: `ANTES-ESTORNO` e
`DEPOIS-ESTORNO` (CP0313), `FIM-HABILITA-CAMPOS`, `valueChangedNFe` (RE0708).

A contagem diz quais eventos os programas de projeto tratam. Não diz que todo
programa padrão dispara todos eles.

### Citados em páginas oficiais

`before-initialize`, `after-initialize`, `before-display`, `after-display`,
`before-enable`, `after-enable`, `before-destroy-interface`,
`after-destroy-interface`, `CHANGE-PAGE`, `AFTER-ASSIGN`, `AFTER-END-UPDATE`,
`BEFORE-OPEN-QUERY`, `AFTER-INITIALIZE-INTERFACE`, `AFTER-DISPLAY-FIELDS`,
`AFTER-TIMEOUT`. Cada um com a página e o programa em
`documentacao-publica.md` seção 4.4. Não existe, nas páginas abertas, uma lista
oficial completa por template.

## Quem dispara os eventos

- `utp/ut9000.i` define os eventos padrão de UPC da tela (FAQ oficial). No
  container ele fica em `local-initialize`, **antes** do
  `RUN dispatch ('initialize')`. Chamado depois, a UPC só recebe `CHANGE-PAGE`.
- Includes ajustados pela função "Desabilita execução de UPC", o que mostra
  onde há chamada de UPC: `include/i-epc200.i`, `include/i-epc101.i`,
  `include/i-epc102.i`, `include/i_verify_program_epc.i`, `utp/ut-api.i`,
  `btb/btbcustom.i` e, na família ThinTemplate, `maintenance/maintenance.i`,
  `window/window.i`, `report/report.i`, `zoom/zoom.i`,
  `masterdetail/masterdetail.i`.
- Em pontos de EPC de lógica (sem tela), a UPC recebe o evento e a temp-table
  `tt-epc` como input-output; `tt-epc.cod-parameter` identifica o parâmetro e
  `tt-epc.val-parameter` leva o valor.

Formas de chamada vistas nos programas do produto (argumentos dos includes,
de `includes.md`). Os includes são criptografados: o papel de cada argumento
abaixo é leitura do formato, não do fonte.

```
{include/i-epc200.i fnc_executar_programa}      um nome de programa/função
{include/i-epc200.i2 &CodEvent='"detalhepedido"' &CodParameter='"numeropedido"' &ValueParameter=...}
{include/i-epc201.i "detalhepedido"}            um nome de evento
{include/i-epc101.i agenda_rpw b_old_agenda_rpw}    tabela e buffer com a imagem anterior
{include/i-epc102.i agenda_rpw}                     tabela
```

`i-epc101.i` e `i-epc102.i` aparecem em mais de 130 fontes do produto, sempre
com nome de tabela.

## Cadastro

- Tela: função Manutenção de Programa (MEN012AA, `men/men012aa.w`), pasta
  Detalhes, campo "Programa UPC" (oficial). No banco:
  `prog_dtsul.nom_prog_upc` (comprovado em consulta).
- UPC de dicionário (tabela): Manutenção Tabela Dicionário Datasul
  (`btb/btb006aa.w`); depois, rodar o Otimizador de Performance (oficial).
- Screen Optimizer: botão UPC da função Otimizar Telas, janela SO0700G
  (oficial).

Consulta do que está cadastrado:

```
FIND FIRST prog_dtsul NO-LOCK WHERE prog_dtsul.cod_prog_dtsul = "<programa>" NO-ERROR.
IF AVAILABLE prog_dtsul THEN MESSAGE prog_dtsul.nom_prog_ext SKIP prog_dtsul.nom_prog_upc.
```

## Como descobrir os eventos de um programa

Não há lista confiável por programa. O caminho é medir: cadastre uma UPC de
log no ambiente de teste, repita a operação e leia o arquivo. O modelo está na
skill `progress-templates` (`templates/upc/upc/estpl-upc-log.p`); ele grava
evento, objeto, programa do objeto, frame, tabela e rowid a cada chamada, e a
árvore de widgets no `INITIALIZE`.

# Utilitários do framework: APIs e chamadas

Cada bloco diz de onde vem a informação: **[fonte]** = lido no fonte legível
do framework local; **[exec]** = lido do objeto em execução (assinatura, sem o
que faz); **[uso]** = contado nos programas; **[doc]** = documentação (detalhe
e URL em `documentacao-publica.md`).

## utp/ut-msgs.p (mensagens)

**[doc]** `run utp/ut-msgs.p (input <ação>, input <número>, input <parâmetros>).`

| Ação | Resultado |
|---|---|
| `"show"` | Mostra a mensagem |
| `"msg"` | Devolve o texto no `return-value` |
| `"help"` | Devolve o texto de ajuda |
| `"type"` | Devolve o tipo |
| `"codtype"` | Devolve o código do tipo: 0 não cadastrada, 1 erro, 2 advertência, 3 pergunta, 4 informação |

Parâmetros da mensagem separados por `~~`. Em pergunta, depois do `"show"` o
`return-value` é `"yes"` ou `"no"`.

**[uso]** Números mais usados com `"show"` nos programas de projeto:

| Número | Ocorrências | Observação |
|---|---|---|
| 7 | 761 | texto livre no terceiro parâmetro |
| 73 | 705 | usada na validação de arquivo das telas de relatório |
| 17006 | 636 | genérica de erro: `"título~~texto de ajuda"` (citada em página oficial) |
| 108 | 218 | |
| 99999 | 190 | |
| 17567 | 146 | |
| 15825 | 110 | |

**[doc]** Genéricas oficiais para programa específico: 32278 erro, 32279 aviso,
32280 pergunta, 32281 informação, com
`substitute("&1~~&2", "Mensagem", "Ajuda")`.

O texto e o tipo de 7, 73, 108, 99999, 17567 e 15825 não foram conferidos:
antes de usar um número, veja a mensagem no ambiente.

Na validação de viewer, `{include/i-vldprg.i}` vem antes do `ut-msgs.p` e o
retorno é `'ADM-ERROR'` (visto nos viewers e no comentário do próprio
template).

## utp/ut-acomp.p (janela de acompanhamento)

**[exec]** Procedures:

| Procedure | Parâmetros |
|---|---|
| `pi-inicializar` | (INPUT c-titulo CHARACTER) |
| `pi-acompanhar` | (INPUT c-par-conteudo CHARACTER) |
| `pi-finalizar` | () |
| `pi-seta-titulo` | (INPUT c-titulo CHARACTER) |
| `pi-seta-tipo` | (INPUT p-tipo INTEGER) |
| `pi-habilita-cancela` | () |
| `pi-desabilita-cancela` | () |
| `pi-retorna-status` | (OUTPUT c-status CHARACTER) |

Uso comprovado em execução em lote:

```
run utp/ut-acomp.p persistent set h-acomp.
run pi-inicializar in h-acomp (input "Título").
run pi-acompanhar  in h-acomp (input "Registro: " + chave).
run pi-finalizar   in h-acomp.
```

**[doc]** Indicado para processo longo; evita o erro de tempo de inatividade
na automação de tarefas. Os valores de `pi-seta-tipo` e o retorno de
`pi-retorna-status` não foram levantados.

## utp/utapi033.p (planilha Excel)

**[fonte]** Roda `PERSISTENT`. Procedures públicas:

| Procedure | Parâmetros |
|---|---|
| `piColumn` | (pColumn INT, pDataType CHAR, pLabel CHAR, pFormat CHAR, pWidth CHAR): coluna da aba 1 |
| `piWorksheetColumn` | (pWorksheet INT, pColumn INT, pDataType CHAR, pLabel CHAR, pFormat CHAR, pWidth CHAR) |
| `piNewWorksheet` | (pDs CHAR, pTitle CHAR): abre uma aba |
| `piNewWorksheetByTT` | (pDs CHAR, pTitle CHAR, pTable HANDLE, pField CHAR, pOrder CHAR): aba a partir de temp-table |
| `piNewLine` | (): nova linha |
| `piLine` | (pColumn INT, pCell CHAR): valor de uma célula da linha corrente |
| `piProcessa` | (INPUT-OUTPUT pFile CHAR, pProgram CHAR, pTitle CHAR): gera o arquivo; devolve `"OK"` ou `"NOK"` |
| `show` | (pParam LOGICAL): abrir a planilha ao terminar |
| `ConvertToXls` | (pParam LOGICAL): converter o XML para Excel |
| `setTTParam` | (INPUT TABLE tt-param): linhas de cabeçalho (descrição, valor) |
| `setTTDigita` | (INPUT TABLE tt-digita) |
| `setParamColumnWidth` | (INTEGER EXTENT 2) |
| `setDigitColumnWidth` | (INTEGER EXTENT 2) |
| `getRowErrors` | (OUTPUT TABLE RowErrors) |

Comportamento lido no fonte:

- `piWorksheetColumn` só cria a coluna se ela ainda não existe para a aba.
  `piNewWorksheetByTT` chama `piWorksheetColumn` para cada campo, com o
  `COLUMN-LABEL` do campo. Logo: coluna declarada antes vale; sem declarar,
  vale o `COLUMN-LABEL`.
- Em `piNewWorksheetByTT`, `pField` vazio usa todos os campos do buffer;
  `pOrder` vira `BY` da query.
- `piProcessa` troca a extensão do arquivo; no RPW (`i-num-ped-exec-rpw <> 0`)
  desliga o `show` e grava no spool (`c-dir-spool-servid-exec`) quando o
  caminho não o contém.
- Em UNIX não converte nem mostra. Com LibreOffice, a geração passa para a
  `utapi013`.
- Depende das classes `office.*` (wrapper de Excel/LibreOffice). Sem elas o
  programa não compila: foi o que impediu rodar a API no framework local.

Exemplos de uso: skill `progress-templates`, `relatorio/esp/estpl003rp.p` (uma
aba) e `utilitarios/excel-utapi033.p` (duas abas).

## utp/utapi019.p (e-mail)

**[exec]** Entradas: `pi-execute (INPUT TABLE tt-envio2, OUTPUT TABLE
tt-erros)`, `pi-execute2 (INPUT TABLE tt-envio2, INPUT TABLE tt-mensagem,
OUTPUT TABLE tt-erros)` e internas (`pi-valida`, `pi-blat`, `pi-OCX`,
`pi-exchange`, `pi-UNIX`...). **[doc]** As temp-tables vêm de
`utp/utapi019.i2`. Num programa de projeto a chamada vista é `pi-execute4`,
que não existe na versão do framework local: confira a versão do cliente antes
de usar.

## btb/btapi910za.p (login)

**[fonte]** `run btb/btapi910za.p (input <usuário>, input <senha>, output
table tt-erros)`, com `tt-erros (cod-erro integer, desc-erro character,
desc-arq character)`. Faz o login e as conexões do btb962aa. Uso no modelo
`utilitarios/login-editor.p` da skill `progress-templates`.

## utp/ut-liter.i, ut-field.i, ut-table.i (literais e dicionário)

**[doc]** `{utp/ut-liter.i <literal> <contexto> <alinhamento>}`: devolve no
`return-value` a literal traduzida. Espaço vira `_`. Contexto `*` é o
universal.

**[uso]** Formas vistas: `{utp/ut-liter.i "Mensagem_nr" *}`,
`{utp/ut-liter.i FATURAMENTO MFT}`, `{utp/ut-liter.i Impressora * r}`, seguidas
de `ASSIGN x = RETURN-VALUE`.

**[doc]** `{utp/ut-field.i <banco> <tabela> <campo> <n>}`: n = 1 label,
2 column-label, 3 help, 4 format, 5 initial, 6 description, 7 data type.
`{utp/ut-table.i <banco> <tabela> <n>}`: n = 1 file-label, 2 dump-name,
3 descrição.

## Outros vistos nos programas

| Chamada | De onde | O que se sabe |
|---|---|---|
| `run utp/ut-vlarq.p (input <arquivo>)` | [uso] tela de relatório | Valida o nome do arquivo; `return-value = "NOK"` é erro |
| `run utp/ut-trfrrp.p (input frame f:handle)` | [doc] | Traduz uma frame de relatório |
| `{include/i-logfin.i}` | [uso] `local-destroy` dos containers | Conteúdo não lido; pelo nome e pela posição, registro de fim de execução |
| `{include/win-size.i}` | [uso] `local-initialize` | Fixa os limites da janela ([doc]) |
| `{include/ajuda.i}`, `{include/sobre.i}` | [uso] | Ajuda e "Sobre" do programa |
| `{include/okfil.i h}`, `{include/salvafil.i h}`, `{include/cancefil.i}` | [uso] janela inclui/modifica | Botões OK, Salvar e Cancelar; o argumento é o handle do viewer |
| `{include/confdel.i}` | [fonte] incluído pelos painéis `p-cadsim` e `p-cadpai` | Conteúdo não lido; pelo nome, confirmação de eliminação (a documentação diz que Eliminar pede confirmação) |
| `{include/zoomvar.i &prog-zoom=... &campo=... &campozoom=...}` | [uso] | Chamada de zoom em campo |
| `{include/leave.i &tabela=... &atributo-ref=... &variavel-ref=...}` | [uso] | Busca a descrição da chave estrangeira no LEAVE |
| `{method/dbotterr.i}` | [uso] | Define a temp-table `RowErrors` |

# Procedures internas dos objetos do DDK

Obtido em 20/11/2026 carregando cada objeto em modo persistente e lendo `INTERNAL-ENTRIES` e `GET-SIGNATURE`. É a lista do que existe **em execução**, incluindo o que vem dos includes criptografados. Mostra nome e parâmetros; não mostra o que a procedure faz.

Use para: saber se uma procedure existe antes de chamar (`RUN pi-xxx IN h`), conferir a assinatura, e ver quais `local-*` o objeto já sobrescreve.

Padrão de nomes: `adm-*` é o método padrão do ADM; `local-*` é a sobrescrita do programa (ela chama `RUN dispatch ('<método>')` para executar o padrão); `pi-*` são as do DDK e do programa.

## Comuns a todos os SmartObjects e painéis do levantamento

| Procedure | Parâmetros |
|---|---|
| `adm-set-parent` | (INPUT p-parent HANDLE) |
| `adm-get-parent` | (OUTPUT p-parent HANDLE) |
| `adm-block-parent` | (INPUT p-block LOGICAL) |
| `adm-apply-entry` | () |
| `adm-destroy` | () |
| `adm-disable` | () |
| `adm-edit-attribute-list` | () |
| `adm-enable` | () |
| `adm-exit` | () |
| `adm-hide` | () |
| `adm-initialize` | () |
| `adm-show-errors` | () |
| `adm-UIB-mode` | () |
| `adm-view` | () |
| `dispatch` | (INPUT p-method-name CHARACTER) |
| `get-attribute` | (INPUT p-attr-name CHARACTER) |
| `get-attribute-list` | (OUTPUT p-attr-list CHARACTER) |
| `new-state` | (INPUT p-state CHARACTER) |
| `notify` | (INPUT p-method CHARACTER) |
| `piTooltipHelp` | (INPUT p-wh-frame HANDLE) |
| `pi_aplica_facelift` | (INPUT wg HANDLE) |
| `set-attribute-list` | (INPUT p-attr-list CHARACTER) |
| `set-position` | (INPUT p-row DECIMAL, INPUT p-col DECIMAL) |
| `disable_UI` | () |
| `state-changed` | (INPUT p-issuer-hdl HANDLE, INPUT p-state CHARACTER) |

## SmartViewer (`c-viewer.i`)

64 entradas no total; abaixo, as que não estão na lista comum.

| Procedure | Parâmetros |
|---|---|
| `adm-display-fields` | () |
| `adm-open-query` | () |
| `adm-row-changed` | () |
| `reposition-query` | (INPUT p-requestor-hdl HANDLE) |
| `adm-add-record` | () |
| `adm-assign-record` | () |
| `adm-assign-statement` | () |
| `adm-cancel-record` | () |
| `adm-copy-record` | () |
| `adm-create-record` | () |
| `adm-current-changed` | () |
| `adm-delete-record` | () |
| `adm-disable-fields` | () |
| `adm-enable-fields` | () |
| `adm-end-update` | () |
| `adm-reset-record` | () |
| `adm-update-record` | () |
| `check-modified` | (INPUT check-state CHARACTER) |
| `get-rowid` | (OUTPUT p-table ROWID) |
| `set-editors` | (INPUT p-field-setting CHARACTER) |
| `use-check-modified-all` | (INPUT p-attr-value CHARACTER) |
| `use-create-on-add` | (INPUT p-attr-value CHARACTER) |
| `use-initial-lock` | (INPUT p-attr-value CHARACTER) |
| `pi-trata-state` | (INPUT p-issuer-hdl HANDLE, INPUT p-state CHARACTER) |
| `pi-desabilita-chave` | () |
| `pi-seta-return-value` | (INPUT ret CHARACTER) |
| `adm-row-available` | () |
| `local-assign-record` | () |
| `local-disable-fields` | () |
| `local-enable-fields` | () |
| `pi-atualiza-parent` | (INPUT v-row-parent-externo ROWID) |
| `Pi-validate` | () |
| `send-records` | (INPUT p-tbl-list CHARACTER, OUTPUT p-rowid-list CHARACTER) |
| `isPartitioned` (função) | (INPUT lPartitioned LOGICAL) retorna logical |
| `setInitial` (função) | () retorna logical |

## SmartQuery (`c-query.i`)

53 entradas no total; abaixo, as que não estão na lista comum.

| Procedure | Parâmetros |
|---|---|
| `pi-seta-return-value` | (INPUT ret CHARACTER) |
| `adm-display-fields` | () |
| `adm-open-query` | () |
| `adm-row-changed` | () |
| `reposition-query` | (INPUT p-requestor-hdl HANDLE) |
| `adm-get-first` | () |
| `adm-get-last` | () |
| `adm-get-next` | () |
| `adm-get-prev` | () |
| `New-First-Record` | (INPUT rRowid ROWID) |
| `IncMod` | (INPUT p-state CHARACTER) |
| `Pesquisa` | () |
| `pi-consulta` | () |
| `pi-container` | () |
| `pi-desabilita` | () |
| `pi-habilita` | () |
| `pi-posicao-query` | (OUTPUT rw-posicao-query ROWID) |
| `pi-reposiciona-query` | (INPUT p-row-table ROWID) |
| `pi-trata-state` | (INPUT p-issuer-hdl HANDLE, INPUT p-state CHARACTER) |
| `VaPara` | () |
| `adm-open-query-cases` | () |
| `adm-row-available` | () |
| `send-key` | (INPUT pc_key-name CHARACTER, OUTPUT pc_key-value CHARACTER) |
| `send-records` | (INPUT p-tbl-list CHARACTER, OUTPUT p-rowid-list CHARACTER) |

## Browser de zoom (`c-brwzoo.i`)

72 entradas no total; abaixo, as que não estão na lista comum.

| Procedure | Parâmetros |
|---|---|
| `adm-add-record` | () |
| `adm-assign-record` | () |
| `adm-assign-statement` | () |
| `adm-cancel-record` | () |
| `adm-copy-record` | () |
| `adm-create-record` | () |
| `adm-current-changed` | () |
| `adm-delete-record` | () |
| `adm-disable-fields` | () |
| `adm-enable-fields` | () |
| `adm-end-update` | () |
| `adm-reset-record` | () |
| `adm-update-record` | () |
| `check-modified` | (INPUT check-state CHARACTER) |
| `get-rowid` | (OUTPUT p-table ROWID) |
| `set-editors` | (INPUT p-field-setting CHARACTER) |
| `use-check-modified-all` | (INPUT p-attr-value CHARACTER) |
| `use-create-on-add` | (INPUT p-attr-value CHARACTER) |
| `use-initial-lock` | (INPUT p-attr-value CHARACTER) |
| `adm-display-fields` | () |
| `adm-open-query` | () |
| `adm-row-changed` | () |
| `reposition-query` | (INPUT p-requestor-hdl HANDLE) |
| `GetSystemTime` | (OUTPUT lpSystemTime MEMPTR) |
| `ApplyFillIn` | () |
| `pi-after-initialize` | () |
| `pi-before-initialize` | () |
| `pi-close-query` | () |
| `pi-elimina` | () |
| `pi-inclui` | () |
| `pi-modifica` | () |
| `pi-reposiciona-query` | (INPUT p-row-table ROWID) |
| `pi-trata-state` | (INPUT p-issuer-hdl HANDLE, INPUT p-state CHARACTER) |
| `pi-value-changed` | () |
| `pi-seta-return-value` | (INPUT ret CHARACTER) |
| `adm-open-query-cases` | () |
| `adm-row-available` | () |
| `local-view` | () |
| `pi-retorna-valor` | (INPUT P-CAMPO CHARACTER) |
| `send-key` | (INPUT pc_key-name CHARACTER, OUTPUT pc_key-value CHARACTER) |
| `send-records` | (INPUT p-tbl-list CHARACTER, OUTPUT p-rowid-list CHARACTER) |
| `isPartitioned` (função) | (INPUT lPartitioned LOGICAL) retorna logical |
| `setInitial` (função) | () retorna logical |

## Container `w-cadsim`

53 entradas no total; abaixo, as que não estão na lista comum.

| Procedure | Parâmetros |
|---|---|
| `adm-change-page` | () |
| `delete-page` | (INPUT p-page# INTEGER) |
| `init-object` | (INPUT p-proc-name CHARACTER, INPUT p-parent-hdl HANDLE, INPUT p-attr-list CHARACTER, OUTPUT p-proc-hdl HANDLE) |
| `init-pages` | (INPUT p-page-list CHARACTER) |
| `pi-retorna-appc` | () |
| `pi-retorna-dpc` | () |
| `pi-retorna-upc` | () |
| `pi-retorna-vars-hlp` | (OUTPUT p-num-topico-hlp INTEGER, OUTPUT p-nom-manual-hlp CHARACTER) |
| `select-page` | (INPUT p-page# INTEGER) |
| `view-page` | (INPUT p-page# INTEGER) |
| `pi-after-initialize` | () |
| `pi-before-initialize` | () |
| `pi-disable-menu` | () |
| `pi-enter-go` | () |
| `pi-trad-menu` | (INPUT p-wh-menu HANDLE) |
| `pi-trata-state` | (INPUT p-issuer-hdl HANDLE, INPUT p-state CHARACTER) |
| `pi-seta-return-value` | (INPUT ret CHARACTER) |
| `adm-create-objects` | () |
| `adm-row-available` | () |
| `enable_UI` | () |
| `local-destroy` | () |
| `local-exit` | () |
| `local-initialize` | () |
| `send-records` | () |

## Janela de pesquisa `w-pesqui`

53 entradas no total; abaixo, as que não estão na lista comum.

| Procedure | Parâmetros |
|---|---|
| `adm-change-page` | () |
| `delete-page` | (INPUT p-page# INTEGER) |
| `init-object` | (INPUT p-proc-name CHARACTER, INPUT p-parent-hdl HANDLE, INPUT p-attr-list CHARACTER, OUTPUT p-proc-hdl HANDLE) |
| `init-pages` | (INPUT p-page-list CHARACTER) |
| `pi-retorna-appc` | () |
| `pi-retorna-dpc` | () |
| `pi-retorna-upc` | () |
| `pi-retorna-vars-hlp` | (OUTPUT p-num-topico-hlp INTEGER, OUTPUT p-nom-manual-hlp CHARACTER) |
| `select-page` | (INPUT p-page# INTEGER) |
| `view-page` | (INPUT p-page# INTEGER) |
| `pi-entry` | () |
| `pi-entry-atributos-chave` | () |
| `pi-go` | () |
| `pi-mostra-atributos-chave` | () |
| `pi-seta-atributos-chave` | (INPUT p-lista-atributos-chave CHARACTER) |
| `pi-trata-state` | (INPUT p-issuer-hdl HANDLE, INPUT p-state CHARACTER) |
| `pi-seta-return-value` | (INPUT ret CHARACTER) |
| `adm-create-objects` | () |
| `adm-row-available` | () |
| `enable_UI` | () |
| `local-destroy` | () |
| `local-exit` | () |
| `local-initialize` | () |
| `send-records` | () |

## Painel `panel/p-navega.w`

41 entradas no total; abaixo, as que não estão na lista comum.

| Procedure | Parâmetros |
|---|---|
| `count-buttons` | () |
| `use-edge-pixels` | (INPUT attr-value CHARACTER) |
| `enable-va-para` | (INPUT p-log-enable LOGICAL) |
| `enable-zoom` | (INPUT p-log-enable LOGICAL) |
| `get-button-enable` | (OUTPUT p-button-enable CHARACTER) |
| `local-enable` | () |
| `local-initialize` | () |
| `pi-anterior` | () |
| `pi-disable-all` | () |
| `pi-enable-all` | () |
| `pi-pesquisa` | () |
| `pi-primeiro` | () |
| `pi-proximo` | () |
| `pi-ultimo` | () |
| `pi-vapara` | () |
| `set-buttons` | (INPUT first-last CHARACTER) |

## Painel `panel/p-exihel.w`

40 entradas no total; abaixo, as que não estão na lista comum.

| Procedure | Parâmetros |
|---|---|
| `count-buttons` | () |
| `use-edge-pixels` | (INPUT attr-value CHARACTER) |
| `enable-relacionamento` | (INPUT p-log-enable LOGICAL) |
| `enable-relatorio` | (INPUT p-log-enable LOGICAL) |
| `get-button-enable` | (OUTPUT p-button-enable CHARACTER) |
| `local-enable` | () |
| `local-initialize` | () |
| `pi-ajuda` | () |
| `pi-consulta` | () |
| `pi-container` | (OUTPUT nome-container CHARACTER) |
| `pi-imprimir` | () |
| `pi-sair` | () |
| `set-button-enable` | (INPUT p-button-enable CHARACTER) |
| `set-buttons` | (INPUT first-last CHARACTER) |
| `set-prog-parent` | (INPUT p-programa CHARACTER) |

## Painel `panel/p-cadsim.w`

47 entradas no total; abaixo, as que não estão na lista comum.

| Procedure | Parâmetros |
|---|---|
| `count-buttons` | () |
| `use-edge-pixels` | (INPUT attr-value CHARACTER) |
| `enable-cancela` | (INPUT p-log-enable LOGICAL) |
| `enable-copia` | (INPUT p-log-enable LOGICAL) |
| `enable-desfaz` | (INPUT p-log-enable LOGICAL) |
| `enable-elimina` | (INPUT p-log-enable LOGICAL) |
| `enable-inclui` | (INPUT p-log-enable LOGICAL) |
| `enable-modifica` | (INPUT p-log-enable LOGICAL) |
| `enable-salva` | (INPUT p-log-enable LOGICAL) |
| `get-button-enable` | (OUTPUT p-button-enable CHARACTER) |
| `local-enable` | () |
| `local-initialize` | () |
| `pi-alterar` | () |
| `pi-cancelar` | () |
| `pi-copiar` | () |
| `pi-desfazer` | () |
| `pi-eliminar` | () |
| `pi-imprimir` | () |
| `pi-incluir` | () |
| `pi-salvar` | () |
| `set-buttons` | (INPUT panel-state CHARACTER) |
| `set-label` | (INPUT label-string CHARACTER) |

## Painel `panel/p-cadsi2.w`

44 entradas no total; abaixo, as que não estão na lista comum.

| Procedure | Parâmetros |
|---|---|
| `count-buttons` | () |
| `use-edge-pixels` | (INPUT attr-value CHARACTER) |
| `enable-cancela` | (INPUT p-log-enable LOGICAL) |
| `enable-desfaz` | (INPUT p-log-enable LOGICAL) |
| `enable-modifica` | (INPUT p-log-enable LOGICAL) |
| `enable-salva` | (INPUT p-log-enable LOGICAL) |
| `get-button-enable` | (OUTPUT p-button-enable CHARACTER) |
| `local-enable` | () |
| `local-initialize` | () |
| `pi-alterar` | () |
| `pi-cancelar` | () |
| `pi-copiar` | () |
| `pi-desfazer` | () |
| `pi-eliminar` | () |
| `pi-imprimir` | () |
| `pi-incluir` | () |
| `pi-salvar` | () |
| `set-buttons` | (INPUT panel-state CHARACTER) |
| `set-label` | (INPUT label-string CHARACTER) |

## Painel `panel/p-cadpai.w`

41 entradas no total; abaixo, as que não estão na lista comum.

| Procedure | Parâmetros |
|---|---|
| `count-buttons` | () |
| `use-edge-pixels` | (INPUT attr-value CHARACTER) |
| `enable-copia` | (INPUT p-log-enable LOGICAL) |
| `enable-elimina` | (INPUT p-log-enable LOGICAL) |
| `enable-inclui` | (INPUT p-log-enable LOGICAL) |
| `enable-modifica` | (INPUT p-log-enable LOGICAL) |
| `get-button-enable` | (OUTPUT p-button-enable CHARACTER) |
| `local-enable` | () |
| `local-initialize` | () |
| `pi-alterar` | () |
| `pi-copiar` | () |
| `pi-eliminar` | () |
| `pi-imprimir` | () |
| `pi-incluir` | () |
| `set-buttons` | (INPUT panel-state CHARACTER) |
| `set-label` | (INPUT label-string CHARACTER) |

## Folder `adm/objects/folder.w`

37 entradas.

| Procedure | Parâmetros |
|---|---|
| `adm-set-parent` | (INPUT p-parent HANDLE) |
| `adm-get-parent` | (OUTPUT p-parent HANDLE) |
| `adm-block-parent` | (INPUT p-block LOGICAL) |
| `adm-apply-entry` | () |
| `adm-destroy` | () |
| `adm-disable` | () |
| `adm-edit-attribute-list` | () |
| `adm-enable` | () |
| `adm-exit` | () |
| `adm-hide` | () |
| `adm-initialize` | () |
| `adm-show-errors` | () |
| `adm-UIB-mode` | () |
| `adm-view` | () |
| `dispatch` | (INPUT p-method-name CHARACTER) |
| `get-attribute` | (INPUT p-attr-name CHARACTER) |
| `get-attribute-list` | (OUTPUT p-attr-list CHARACTER) |
| `new-state` | (INPUT p-state CHARACTER) |
| `notify` | (INPUT p-method CHARACTER) |
| `piTooltipHelp` | (INPUT p-wh-frame HANDLE) |
| `pi_aplica_facelift` | (INPUT wg HANDLE) |
| `set-attribute-list` | (INPUT p-attr-list CHARACTER) |
| `set-position` | (INPUT p-row DECIMAL, INPUT p-col DECIMAL) |
| `change-folder-page` | () |
| `create-folder-label` | (INPUT p-page# INTEGER, INPUT p-page-label CHARACTER) |
| `create-folder-page` | (INPUT p-page# INTEGER, INPUT p-new-label CHARACTER) |
| `delete-folder-page` | (INPUT p-page# INTEGER) |
| `disable-folder-page` | (INPUT p-page# INTEGER) |
| `disable_UI` | () |
| `enable-folder-page` | (INPUT p-page# INTEGER) |
| `initialize-folder` | () |
| `label-trigger` | (INPUT p-page# INTEGER) |
| `local-initialize` | () |
| `pi-state-folder` | (INPUT p-page# INTEGER) |
| `set-size` | (INPUT p-height DECIMAL, INPUT p-width DECIMAL) |
| `show-current-page` | (INPUT page# INTEGER) |
| `state-changed` | (INPUT p-issuer-hdl HANDLE, INPUT p-state CHARACTER) |

## `utp/ut-acomp.p`

14 entradas.

| Procedure | Parâmetros |
|---|---|
| `pi-inicializar` | (INPUT c-titulo CHARACTER) |
| `pi-acompanhar` | (INPUT c-par-conteudo CHARACTER) |
| `pi-finalizar` | () |
| `pi-seta-tipo` | (INPUT p-tipo INTEGER) |
| `pi-habilita-cancela` | () |
| `pi-desabilita-cancela` | () |
| `pi-retorna-status` | (OUTPUT c-status CHARACTER) |
| `pi-seta-titulo` | (INPUT c-titulo CHARACTER) |
| `f-timeRestart` (função) | () retorna logical |
| `f-time` (função) | () retorna integer |

## `utp/utapi019.p`

17 entradas.

| Procedure | Parâmetros |
|---|---|
| `pi-execute` | (INPUT TABLE tt-envio2, OUTPUT TABLE tt-erros) |
| `pi-execute2` | (INPUT TABLE tt-envio2, INPUT TABLE tt-mensagem, OUTPUT TABLE tt-erros) |
| `pi-valida` | () |
| `pi-wsendmail` | () |
| `pi-exchange2` | () |
| `pi-exchange` | () |
| `pi-OCX` | () |
| `pi-blat` | () |
| `pi-UNIX` | () |
| `pi-criar-erros` | (INPUT i-erro INTEGER, INPUT c-erro CHARACTER, INPUT c-arq CHARACTER) |
| `serv-mail` | () |
| `porta-mail` | () |
| `ms-serv` | () |

## `utp/utapi013.p`

20 entradas.

| Procedure | Parâmetros |
|---|---|
| `pi-execute` | (INPUT-OUTPUT TABLE tt-configuracao2, INPUT-OUTPUT TABLE tt-planilha, INPUT-OUTPUT TABLE tt-dados, INPUT-OUTPUT TABLE tt-grafico2, INPUT-OUTPUT TABLE tt-erros) |
| `pi-execute2` | (INPUT-OUTPUT TABLE tt-configuracao2, INPUT-OUTPUT TABLE tt-planilha2, INPUT-OUTPUT TABLE tt-dados, INPUT-OUTPUT TABLE tt-formatar-faixa, INPUT-OUTPUT TABLE tt-grafico2, INPUT-OUTPUT TABLE tt-erros) |
| `pi-verificar-dados` | () |
| `pi-construcao-planilha-8` | () |
| `pi-construcao-grafico-8` | (INPUT i-arquivo-num INTEGER) |
| `pi-gravar-erros` | (INPUT p-erro INTEGER, INPUT p-erro-log CHARACTER, INPUT p-erro-local CHARACTER, INPUT p-msg-param CHARACTER) |
| `pi-contagem` | (OUTPUT p-total INTEGER) |
| `WinExec` | (INPUT prog_name CHARACTER, INPUT visual_style INTEGER) |
| `PI-CONVERTE` | (INPUT i-linha INTEGER, INPUT i-coluna INTEGER, INPUT c-valor CHARACTER, INPUT c-formato CHARACTER) |
| `pi-add-line-series` | (INPUT iType INTEGER, INPUT iForward INTEGER, INPUT iBackward INTEGER, INPUT lDisplayEquation LOGICAL, INPUT lDisplayRSquared LOGICAL, INPUT cName CHARACTER, INPUT iSerieNumber INTEGER, INPUT iArquivo-num INTEGER, INPUT iOrder INTEGER, INPUT iPeriod INTEGER, INPUT lIntercept LOGICAL, INPUT iLineColor INTEGER) |
| `createFileTXT` | (INPUT iArqNum INTEGER, INPUT iPlanNum INTEGER, OUTPUT cArqName CHARACTER) |
| `importToExcel` | (INPUT cArqName CHARACTER, INPUT iPlanNum INTEGER) |
| `pi-inicializa-parametros` | (OUTPUT p-colunas CHARACTER) |
| `pi-cria-novo-sheet` | (INPUT p-cabec CHARACTER, INPUT p-formato CHARACTER, INPUT p-colunas CHARACTER, INPUT p-delim-ex CHARACTER) |
| `pi-seta-imagem` | (INPUT iArquivoNum INTEGER, INPUT iPlanilhaNum INTEGER, INPUT iCelulaColuna INTEGER, INPUT iCelulaLinha INTEGER, INPUT cPathArq CHARACTER) |
| `pi-insert-images` | (INPUT iArquivoNum INTEGER) |
| `pi-redim-cols` | () |
| `SetColumnFormula` | (INPUT iCelulaLinha INTEGER, INPUT iCelulaColuna INTEGER, INPUT cCelulaFormula CHARACTER, INPUT cCelulaValor CHARACTER) |
| `getDate2` (função) | () retorna character |
| `RetornaExtensao` (função) | (INPUT cPathCompleto CHARACTER) retorna character |

## Não obtido

- Container `w-paifil`, browser de cadastro (`c-brows3.i`), browser e janela de pesquisa do pai: ao carregar, o DDK pediu login (sessão sem usuário logado).
- Tela `w-relat`: a sessão em lote caiu ao montar a janela.
- Vá-para (`d-vapara.i`) e janela inclui/modifica (`w-incsim.i`): exigem parâmetros de quem chama.

Para repetir o levantamento com login, use `scripts/entradas.p` (ver `SKILL.md`).

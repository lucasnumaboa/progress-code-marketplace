# Templates de tela e SmartObjects do DDK clássico

Levantamento de 20/11/2026 nos fontes legíveis de um framework Datasul local ({'padrao': 976, 'especifico': 97}: `padrao` = programas do produto, `especifico` = programas de projeto).

O include de cada template está criptografado: o que há aqui é o que os programas que o usam mostram.
A coluna **Nome** é a descrição do estilo conforme a documentação (ver `documentacao-publica.md`) ou, quando ela não cita o arquivo, o nome usual: confirme antes de afirmar.

## Como reconhecer o template de um programa

Abra o `.w` e procure, no bloco *Included-Libraries*, o par de includes:

```
{src/adm/method/containr.i}     biblioteca ADM do tipo de objeto
{include/w-paifil.i}            template DDK
{utp/ut-glob.i}                 globais da sessão
```

e a linha `&Scoped-define PROCEDURE-TYPE <tipo>`.

## Templates com uso observado

| Include | Nome | PROCEDURE-TYPE (vezes) | Lib ADM | Painéis e objetos que carrega | Programas (padrão / projeto) | Exemplos |
|---|---|---|---|---|---|---|
| `include/c-brwzoo.i` | Browser de zoom | SmartBrowser(27) | browser.i(27) | - | 19 / 8 | b01fn068.w b01fn088.w b01fn116.w b02fn068.w b02fn088.w b02fn116.w |
| `include/w-cadsim.i` | Cadastro simples | w-cadsim(11), SmartWindow(8) | containr.i(19) | panel/p-cadsim.w(19), panel/p-navega.w(19), panel/p-exihel.w(19) | 13 / 6 | cd0103.w cd0109.w cd0181.w cd0203.w cd0401b.w cd0405.w |
| `include/c-viewer.i` | SmartViewer | SmartViewer(18) | viewer.i(18) | - | 8 / 10 | v01fn017a.w v01fn068.w v01fn088.w v01fn225.w v02fn068.w v03fn017a.w |
| `include/d-dialog.i` | Diálogo | SmartDialog(17) | containr.i(17) | - | 17 / 0 | btb004aa.w btb012ta.w btb901zs.w btb901zt.w btb911zc.p cd0204i.w |
| `include/w-pesqui.i` | Pesquisa (zoom) | SmartWindow(16) | containr.i(16) | adm/objects/folder.w(15) | 8 / 8 | z01fn068.w z01fn088.w z01fn183.w z02fn116.w z01un005.w z01un006.w |
| `include/c-query.i` | SmartQuery | SmartQuery(13) | query.i(13) | - | 3 / 10 | q01fn068.w q01fn088.w q01fn225.w esxx002-q01.w esxx0106-q01.w esxx0107-q01.w |
| `include/w-relat.i` | Relatório, cálculo, fechamento | w-relat(7) | containr.i(13) | - | 10 / 3 | men705aa.w men706aa.w mer001aa.w mer002aa.w mer003a.w mer004aa.w |
| `include/w-cadcom.i` | Cadastro complexo (com abas) | SmartWindow(9), w-cadcom(2) | containr.i(11) | panel/p-cadsim.w(11), panel/p-navega.w(11), adm/objects/folder.w(11), panel/p-exihel.w(11) | 11 / 0 | cd0182.w cd0204.w cd0401.w cd0402.w cd0403.w cd0404.w |
| `include/w-incsim.i` | Janela inclui/modifica (simples) | w-incmod(7), SmartWindow(3) | containr.i(10) | - | 8 / 2 | btb962ad.w men003mb.w men011da.w men011dz.w men012za.w men012ze.w |
| `include/d-vapara.i` | Vá para | SmartVaPara(9) | containr.i(9) | - | 1 / 8 | g01fn068.w esxx002-g01.w esxx0106-g01.w esxx0107-g01.w esxx0111-g01.w esxx0203g.w |
| `include/w-window.i` | Janela (detalhe) | JanelaDetalhe(5), w-form2(2), w-window(1) | containr.i(8) | - | 5 / 3 | btb012gr.p cd0119a.w men013ba.w men013cb.w sec000ac.w esxx109a.w |
| `include/w-paiamb.i` | Pai x filho - atualiza ambos | SmartWindow(5) | containr.i(5) | panel/p-cadpai.w(5), panel/p-navega.w(5), adm/objects/folder.w(5), panel/p-exihel.w(5) | 5 / 0 | btb962aa.w men002aa.w men011aa.w men013aa.w sec000aa.w |
| `include/c-brows3.i` | Browser de cadastro (inclui/modifica/elimina) | BrowserCadastro2(5) | browser.i(5) | - | 3 / 2 | b01fn082.w b01fn134.w b01fn225.w esxx0203bf.w estpl002bf.w |
| `include/c-browse.i` | SmartBrowser | SmartBrowser(4) | browser.i(4) | - | 3 / 1 | b05un197.w b06un197.w b07un197.w esxx109-b02.w |
| `include/w-paifil.i` | Pai x filho - atualiza filho | w-paifil(2), SmartWindow(1) | containr.i(3) | panel/p-navega.w(3), adm/objects/folder.w(3), panel/p-exihel.w(3) | 1 / 2 | cd0705.w esxx0203.w estpl002.w |
| `include/w-incmdp.i` | Janela inclui/modifica pai | w-incmdp(3) | containr.i(3) | - | 3 / 0 | men002ca.w men011ca.w men013ca.w |
| `include/w-livre.i` | Janela livre | w-livre(2) | containr.i(2) | panel/p-exihel.w(2) | 1 / 1 | men707aa.w esxx0104.w |
| `include/w-consim.i` | Consulta simples | w-forma(1) | containr.i(1) | panel/p-navega.w(1), panel/p-exihel.w(1) | 1 / 0 | sec400aa.w |

## Templates que existem no DDK local sem programa legível que os use

Existem em `ddk/include`, mas nenhum fonte legível do levantamento os inclui. Não há fato observado sobre eles:

`include/c-broker.i`, `include/c-brows2.i`, `include/c-brows4.i`, `include/c-brows5.i`, `include/c-brwfrm.i`, `include/c-brwupd.i`, `include/c-page.i`, `include/w-cadco2.i`, `include/w-cadsi2.i`, `include/w-cadsi3.i`, `include/w-concom.i`, `include/w-conrel.i`, `include/w-digit.i`, `include/w-impor.i`, `include/w-inccom.i`

## Como os objetos se ligam (observado nos programas)

No container, `adm-create-objects` cria cada objeto com `init-object` e liga com `add-link`:

```
RUN init-object IN THIS-PROCEDURE (INPUT 'esp/xxx-v01.w':U, INPUT FRAME f-cad:HANDLE,
                                  INPUT 'Layout = ':U, OUTPUT h_xxx-v01).
RUN set-position IN h_xxx-v01 (2.67, 1.00) NO-ERROR.
RUN add-link IN adm-broker-hdl (h_xxx-q01, 'Record':U, h_xxx-v01).
```

Links vistos no cadastro pai e filho (`w-paifil`):

| Origem | Tipo | Destino |
|---|---|---|
| query do pai | Record | viewer do pai |
| query do pai | Record | browser dos filhos |
| p-navega | Navigation | query do pai |
| p-navega | State | query do pai |
| p-exihel | State | container (THIS-PROCEDURE) |
| p-exihel | State | query do pai |
| folder | Page | container |

Atributos passados no `init-object`:

| Objeto | Atributos vistos |
|---|---|
| Painéis `p-navega`, `p-exihel` | `Edge-Pixels = 0, SmartPanelType = NAV-ICON, Right-to-Left = First-On-Left` |
| SmartQuery | `ProgPesquisa`, `ProgVaPara`, `ProgIncMod`, `Implantar` |
| Browser de cadastro | `Initial-Lock`, `Hide-on-Init`, `Disable-on-Init`, `Layout`, `Create-On-Add`, `ProgAtributo`, `ProgIncMod`, `MessageNum`, `MessageParam` |
| Folder (`adm/objects/folder.w`) | `FOLDER-LABELS`, `FOLDER-TAB-TYPE` |

## O que o container precisa ter

Visto em todos os containers DDK do levantamento:

- `{include/i-prgvrs.i <programa> <versão>}` no início e `{include/i-license-manager.i <programa> <módulo>}` dentro de `&IF "{&EMSFND_VERSION}" >= "1.00"`.
- `local-initialize`: `{include/win-size.i}`, `run pi-before-initialize`, `{utp/ut9000.i "<programa>" "<versão>"}`, `RUN dispatch ('initialize')`, `run pi-after-initialize`. O `ut9000.i` vem **antes** do dispatch: depois dele, a UPC só recebe `CHANGE-PAGE` (FAQ oficial, ver `documentacao-publica.md` 4.5).
- `local-destroy`: `RUN dispatch ('destroy')` e `{include/i-logfin.i}`.
- `state-changed`: repassa para `pi-trata-state (p-issuer-hdl, p-state)`.
- Gatilhos de menu chamando as procedures dos painéis (`pi-primeiro IN h_p-navega`, `pi-sair IN h_p-exihel`...).
- `{include/sobre.i}` no item Sobre e `{include/ajuda.i}` na ajuda.

## Família ThinTemplate (não é o DDK clássico)

Programas do produto mais novos usam outra família de includes, que não existe no framework local (por isso não compilam nem rodam nele):

| Include | Programas (padrão / projeto) | Argumentos vistos |
|---|---|---|
| `masterdetail/mainblock.i` | 6 / 0 |  |
| `masterdetail/addson.i` | 6 / 0 | &ProgramSon="cdp/cd1507c.w" &PageNumber="1" \|\| &ProgramSon="cdp/cd1508b.w" &PageNumber="1" \|\| &ProgramSon="cdp/cd2554b.w" &PageNumber="1" |
| `masterdetail/openqueriesson.i` | 6 / 0 | &Parent="tab-finan" &Query="TabFinan" &PageNumber="1" \|\| &Parent="tb-preco" &Query="ToTbPreco" &PageNumber="1" \|\| &Parent="tt-inco-cx" &Query="CodDesp" &PageNumber="1" &QueryConstraint |
| `masterdetail/masterdetail.i` | 6 / 0 |  |
| `window/window.i` | 5 / 0 |  |
| `window/mainblock.i` | 5 / 0 |  |
| `maintenance/maintenance.i` | 5 / 0 |  |
| `maintenance/mainblock.i` | 5 / 0 |  |
| `masterdetail/updateson.i` | 5 / 0 | &ProgramSon="cdp/cd1507c.w" &PageNumber="1" \|\| &ProgramSon="cdp/cd1508b.w" &PageNumber="1" \|\| &ProgramSon="cdp/cd2567b.w" */ /* &PageNumber="1" |
| `masterdetail/deleteson.i` | 4 / 0 | &PageNumber="1" |
| `masterdetail/copyson.i` | 3 / 0 | &ProgramSon="cdp/cd1507c.w" &PageNumber="1" \|\| &ProgramSon="cdp/cd1508b.w" &PageNumber="1" \|\| &ProgramSon="<ProgramName>" */ /* &PageNumber="1" |
| `report/rpexa.i` | 0 / 3 |  |
| `report/rpimp.i` | 0 / 3 |  |
| `report/rprse.i` | 0 / 3 |  |
| `report/logfin.i` | 0 / 3 |  |
| `report/rparq.i` | 0 / 3 |  |
| `report/rpexc.i` | 0 / 3 |  |
| `report/rpexb.i` | 0 / 3 |  |
| `report/rprun.i` | 0 / 3 | esp/esxx0108rp.p \|\| esp/esxx0109rp.p |
| `report/mainblock.i` | 0 / 3 |  |
| `report/rptrm.i` | 0 / 3 |  |
| `report/report.i` | 0 / 3 |  |
| `maintenancenonavigation/mainblock.i` | 2 / 0 |  |
| `maintenancenonavigation/maintenancenonavigation.i` | 2 / 0 |  |

Tipos (`PROCEDURE-TYPE`) dessa família vistos: `Maintenance`, `MaintenanceNoNavigation`, `MasterDetail`, `Window`, `Zoom`, `Formation`. Frames: `fPage0`, `fPage1`..., `fGoToRecord`.

# Variáveis definidas pelos includes (sonda de compilação)

Levantamento de 20/11/2026. Os includes são criptografados, então as variáveis foram descobertas compilando: para cada nome candidato (tirado dos programas legíveis), compila-se um programa mínimo com o include e uma atribuição do nome; se compila com o include e não compila sem ele, a variável vem do include. O tipo sai de qual atribuição tipada compila.

Limite do método: só acha nomes que estavam na lista de candidatos (943 nomes). Variável que nenhum programa legível usa não aparece. A lista é **do que existe**, não de tudo o que existe.

Para sondar outro include ou outros nomes: `scripts/sonda-include.p` (ver `SKILL.md`).

## `{utp/ut-glob.i}`

Globais da sessão do usuário.

| Variável | Tipo | Observação |
|---|---|---|
| `v_cod_usuar_corren` | character | usuário corrente |
| `v_cod_empres_usuar` | character | empresa do usuário |
| `v_cod_grp_usuar_lst` | character |  |
| `v_cod_idiom_usuar` | character |  |
| `v_cod_usuar_corren_criptog` | character |  |
| `c-seg-usuario` | character | usuário logado (o mais usado nos programas de projeto) |
| `i-ep-codigo-usuario` | character | empresa do usuário. **É CHARACTER**, apesar do prefixo `i-` |
| `i-pais-impto-usuario` | integer |  |
| `v_cdn_empres_usuar` | character | empresa do usuário. **É CHARACTER**, apesar do `cdn` |
| `l-implanta` | logical | citada na documentação como controle do botão Implantar do zoom |
| `i-num-ped-exec-rpw` | integer | número do pedido de execução; diferente de zero quando roda no RPW |
| `v_num_tip_aces_usuar` | integer |  |
| `c-arquivo-log` | character |  |
| `v_nom_razao_social` | character |  |
| `h-prog` | handle |  |
| `h_prog_segur_estab` | handle |  |
| `rw-log-exec` | outro | tipo não identificado pela sonda (o nome sugere ROWID) |
| `l-rpc` | logical |  |

## `{include/i-rpvar.i}`

Variáveis do relatório (rp.p).

| Variável | Tipo | Observação |
|---|---|---|
| `c-programa` | character | nome do programa no cabeçalho/rodapé |
| `c-versao` | character | versão |
| `v_num_count` | integer |  |
| `i-num-ped-exec-rpw` | integer | número do pedido de execução; diferente de zero quando roda no RPW |
| `c-revisao` | character | revisão |
| `c-titulo-relat` | character | título do relatório |
| `c-empresa` | character | nome da empresa no cabeçalho |
| `c-sistema` | character | sistema/módulo no rodapé |
| `c-rodape` | character | linha do rodapé |
| `i-numper-x` | integer |  |
| `da-iniper-x` | date |  |
| `da-fimper-x` | date |  |
| `c-impressora` | character |  |
| `c-layout` | character |  |
| `i-page-size-rel` | integer |  |
| `c-arq-control` | character |  |

## `{include/i-prgvrs.i <programa> <versão>}`

Controle de versão.

| Variável | Tipo | Observação |
|---|---|---|
| `c-prg-vrs` | character | versão do programa |
| `c-arquivo-log` | character |  |
| `c-prg-obj` | character | nome do programa |

As observações da última coluna vêm do uso nos programas ou do nome; não são leitura do include. Antes de depender do **conteúdo** de uma variável, confira em execução.

## Outras globais comprovadas no fonte

| Variável | Onde | Definição |
|---|---|---|
| `i-num-ped-exec-rpw` | `utp/utapi033.p` (legível) | `DEFINE NEW GLOBAL SHARED VARIABLE ... AS INTEGER` |
| `c-dir-spool-servid-exec` | `utp/utapi033.p` (legível) | `DEFINE NEW GLOBAL SHARED VARIABLE ... AS CHARACTER`: pasta de spool do servidor de execução. Não vem do `i-rpvar.i`: quem usa precisa declarar |
| `adm-broker-hdl` | XREF dos containers | `SHARED`; handle do broker ADM, usado em `add-link` |

## Não sondado

- `{include/i-imvar.i}` não compila sozinho (depende de outras definições).
- Includes de template (`w-*.i`, `c-*.i`): dependem do frame e das definições do programa.

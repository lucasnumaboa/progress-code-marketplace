---
name: automatizar-office-com
description: Automatiza Excel, Word e Outlook de verdade via COM (pywin32/PowerShell) — abrir arquivos, rodar macros, ler e enviar e-mails, controlar o Office já instalado na máquina do usuário. Use quando o usuário pedir para "automatizar o Outlook", "rodar essa macro do Excel", "ler os e-mails da caixa de entrada", "gerar um e-mail com anexo pelo Outlook" — para só ler/escrever fórmulas do Excel sem essa camada completa de automação, veja a skill `formulas-excel` (mais focada) ou `ler-escrever-xlsx` (sem abrir o Excel).
argument-hint: [Excel|Word|Outlook] [ação desejada]
---

# Automatizar Excel/Outlook/Word via COM

## Pré-requisito
O Office (Excel/Word/Outlook) precisa **já estar instalado** na máquina — esta skill não instala nada, só controla
o que já existe. Sem o programa instalado, essas operações não funcionam (nem por Python nem por PowerShell).

## Passo 1 — Python (pywin32) ou PowerShell — quando usar qual
- **PowerShell**: scripts curtos, uma automação pontual, sem precisar de lógica Python complexa em volta.
- **Python (pywin32)**: quando a automação faz parte de um pipeline maior já em Python (ex.: gerar relatório com
  pandas e depois mandar por Outlook).
```
pip install pywin32
```

## Passo 2 — Excel: rodar uma macro existente
```python
import win32com.client as win32

excel = win32.gencache.EnsureDispatch("Excel.Application")
excel.Visible = True
wb = excel.Workbooks.Open(r"C:\caminho\planilha.xlsm")
excel.Application.Run("NomeDoModulo.NomeDaMacro")
wb.Save()
wb.Close()
excel.Quit()
```
`Visible = True` deixa o usuário acompanhar — só use `False` se a automação for realmente headless e o usuário
souber disso (uma instância invisível travada é confusa de diagnosticar).

## Passo 3 — Outlook: ler e-mails da caixa de entrada
```python
outlook = win32.Dispatch("Outlook.Application").GetNamespace("MAPI")
caixa_entrada = outlook.GetDefaultFolder(6)  # 6 = olFolderInbox
for item in list(caixa_entrada.Items)[:20]:
    print(item.Subject, item.SenderName, item.ReceivedTime)
```
`list(...)[:20]` materializa antes de fatiar — iterar direto na coleção COM com fatiamento pode se comportar de
forma inesperada dependendo da versão do Outlook.

## Passo 4 — Outlook: enviar e-mail com anexo
```python
mail = outlook_app.CreateItem(0)  # 0 = olMailItem
mail.To = "destinatario@empresa.com"
mail.Subject = "Relatório mensal"
mail.Body = "Segue em anexo."
mail.Attachments.Add(r"C:\caminho\relatorio.pdf")
mail.Save()   # salva em Rascunhos - NUNCA envie automaticamente sem confirmação
# mail.Send()  # so descomente depois de o usuario confirmar o conteudo
```
**Nunca chame `.Send()` sem o usuário ter revisado o conteúdo antes** — sempre `.Save()` (fica em Rascunhos) ou
`.Display()` (abre a janela de composição para o usuário revisar e clicar Enviar ele mesmo) como padrão.

## Passo 5 — Word: abrir, atualizar campos, salvar como PDF
Ver a skill `criar-editar-docx`, passo 5 — mesma técnica de automação COM.

## Regras
- Nunca envie e-mail (`.Send()`) sem confirmação explícita do usuário sobre o conteúdo — e-mail enviado não tem
  "desfazer".
- Sempre feche a aplicação COM (`.Quit()`) ao final, mesmo em caso de erro (`try/finally`) — instâncias do
  Excel/Word/Outlook "zumbis" (sem janela visível, mas o processo continua rodando) acumulam e consomem memória.
- Rodar macro de um arquivo `.xlsm`/`.docm` de origem desconhecida: confirme com o usuário antes — macro pode
  conter qualquer código VBA, inclusive malicioso.

## Arquivos desta skill
Nenhum script fixo — os trechos acima cobrem os casos mais comuns; adapte à automação real pedida.

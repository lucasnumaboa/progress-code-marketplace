# Origem

Skill de especialista empacotada para o marketplace do Progress Code (id `kwp-vendor-review`).

- Repositório: https://github.com/anthropics/knowledge-work-plugins
- Caminho: `operations/skills/vendor-review`
- Autor: Anthropic
- Titular: Anthropic (o texto Apache-2.0 em `LICENSE` não traz linha de copyright preenchida)
- Licença: Apache-2.0 (texto completo em `LICENSE`, copiado de `LICENSE` no repositório)
- Commit: `0e0fcacddcc892eb92a1b7873ff9d68159c47571` (baixado em 2026-11-22)

## Arquivos incluídos

- `SKILL.md` (de `operations/skills/vendor-review/SKILL.md`)

## Mudanças feitas

1. Frontmatter: `name:` trocado de `vendor-review` para `kwp-vendor-review` (a descrição foi mantida).
2. Removida a linha que manda consultar `CONNECTORS.md` (regras de conectores do Cowork).
3. Removida a seção "If Connectors Available" (regras de conectores do Cowork).

O texto do especialista foi mantido em inglês, sem tradução.
Conforme a Apache-2.0 (seção 4b), este aviso registra que os arquivos acima foram modificados.

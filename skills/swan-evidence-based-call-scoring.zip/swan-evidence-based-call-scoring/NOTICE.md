# Aviso de terceiros (NOTICE)

Esta skill é uma cópia adaptada de material de terceiros e é redistribuída sob a licença original. O texto do especialista ficou em inglês, como no original.

- **Origem:** https://github.com/swan-gtm/gtm-skills
- **Caminho no repositório:** `skills/ryan-iyengar/evidence-based-call-scoring`
- **Commit:** `eb0026f469f90645e1a64168d08a3e0afb59ee12` (baixado em 2026-11-22)
- **Autor:** Ryan Iyengar (autor da skill); copyright do repositório: Swan
- **Licença:** MIT (texto completo em `LICENSE`, copiado de `LICENSE` do repositório)

## Arquivos incluídos

- `SKILL.md` (de `skills/ryan-iyengar/evidence-based-call-scoring/SKILL.md`)
- `references/call-rubric.md` (de `skills/ryan-iyengar/evidence-based-call-scoring/references/call-rubric.md`)
- `references/worked-scorecard.md` (de `skills/ryan-iyengar/evidence-based-call-scoring/references/worked-scorecard.md`)
- `author.md` (de `skills/ryan-iyengar/author.md`, crédito do autor pedido pelo repositório)
- `LICENSE`

## Mudanças feitas

- Frontmatter: `name: evidence-based-call-scoring` trocado por `name: swan-evidence-based-call-scoring` (a descrição ficou igual).

## Crédito do autor (author.md)

O repositório pede que o crédito do autor acompanhe a skill. Conteúdo do `author.md` original:

```markdown
---
name: Ryan Iyengar
avatarUrl: "https://www.gtmskills.com/authors/ryan-iyengar.jpg"
title: CEO & Founder, Full Stack GTM
linkedinUrl: https://www.linkedin.com/in/ryaniyengar
companyDomain: fullstackgtm.com
email: ryan@fullstackgtm.com
---

Ryan Iyengar is the CEO and founder of Full Stack GTM. He previously led go-to-market organizations as a CMO, CRO, and President, most recently as President of Helium 10, and now builds governed data and AI systems for GTM teams. He shares open-source work on [GitHub](https://github.com/ryanfsgtm).
```

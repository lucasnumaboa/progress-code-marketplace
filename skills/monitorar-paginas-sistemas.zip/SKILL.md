---
name: monitorar-paginas-sistemas
description: Monitora disponibilidade e tempo de resposta de páginas/sistemas via HTTP, com histórico em SQLite e alerta por e-mail/Teams quando algo muda ou fica fora do ar — sem instalar programa de monitoramento separado. Use quando o usuário pedir para "avisar se esse site cair", "monitorar se a API está no ar", "ver se o conteúdo dessa página mudou".
argument-hint: [URL a monitorar] [frequência] [canal de alerta]
---

# Monitorar páginas e sistemas

## Passo 1 — Checagem básica (disponibilidade + tempo de resposta)
```python
import requests
import time

def checar(url, timeout=10):
    inicio = time.monotonic()
    try:
        resp = requests.get(url, timeout=timeout)
        duracao = time.monotonic() - inicio
        return {"ok": resp.status_code < 400, "status": resp.status_code, "duracao_s": round(duracao, 2)}
    except requests.exceptions.RequestException as e:
        return {"ok": False, "status": None, "duracao_s": None, "erro": str(e)}
```

## Passo 2 — Histórico em SQLite (ver skill `sqlite-local` para detalhes)
```python
con.execute("""
    CREATE TABLE IF NOT EXISTS checagens (
        url TEXT, quando TEXT, ok INTEGER, status INTEGER, duracao_s REAL, erro TEXT
    )
""")
```
Guardar histórico permite responder "desde quando está fora do ar" e "o tempo de resposta está piorando aos
poucos" — não só o estado atual.

## Passo 3 — Detectar mudança de conteúdo (não só disponibilidade)
```python
import hashlib
hash_atual = hashlib.sha256(resp.content).hexdigest()
# compare com o ultimo hash salvo para essa URL; diferente = pagina mudou
```
Útil para monitorar uma página que não tem API (ex.: aviso de edital, tabela de preços) sem precisar reler o
conteúdo inteiro toda vez para saber se mudou.

## Passo 4 — Alertar só na transição de estado (não a cada checagem)
```python
estava_ok = ultimo_estado_salvo.get(url, True)
esta_ok = resultado["ok"]
if estava_ok and not esta_ok:
    alertar(f"{url} caiu! Status: {resultado.get('status')}, erro: {resultado.get('erro')}")
elif not estava_ok and esta_ok:
    alertar(f"{url} voltou ao normal.")
```
Alertar a cada checagem (ex.: a cada 5 minutos enquanto o site estiver fora do ar) satura o canal e faz o alerta
real se perder em ruído — alerte só na **mudança** de estado (ok→falha, falha→ok).

## Passo 5 — Agendar (ver skill `etl-agendado-windows` para o padrão de agendamento no Windows)
Frequência sugerida: a cada 1-5 minutos para sistemas críticos, 15-60 minutos para monitoramento não urgente —
confirme com o usuário qual frequência faz sentido para o caso (checagem excessiva sobrecarrega o sistema
monitorado sem necessidade).

## Regras
- Sempre defina um `timeout` curto (5-10s) — sem isso, um sistema travado (não caído, só sem responder) trava
  também o monitor.
- Nunca alerte a cada checagem com falha contínua — só na transição de estado (passo 4), com um resumo periódico
  (ex.: "ainda fora do ar há 2 horas") se o usuário quiser esse tipo de lembrete.
- Confirme com o usuário o canal de alerta antes de configurar (e-mail, Teams, Slack) — ver as skills específicas de
  cada canal para o envio em si.

## Arquivos desta skill
Nenhum script fixo — os trechos acima cobrem o fluxo completo; adapte à URL/canal de alerta reais do usuário.

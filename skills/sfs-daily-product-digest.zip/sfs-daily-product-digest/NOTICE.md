# Origem e licença

Esta skill é uma cópia, com as alterações listadas abaixo, de material de especialista com licença aberta.

- **Fonte:** https://github.com/shawnpang/startup-founder-skills
- **Arquivos de origem:** `skills/daily-product-digest/SKILL.md`
- **Autor:** Shawn Pang
- **Licença:** MIT (texto completo em `LICENSE`)
- **Commit:** `4ad31b43eef3ae3755cc57ec7e435dab4699ab44` (baixado em 2026-11-22)

## Alterações feitas

- `name:` do frontmatter trocado de `daily-product-digest` para `sfs-daily-product-digest`.
- Fora isso, o texto do especialista está como no original (em inglês).

# Origem e mudanças

- **Repositório:** https://github.com/coreyhaines31/marketingskills
- **Caminho no repositório:** `skills/reverse-engineer-marketing`
- **Autor:** Corey Haines
- **Licença:** MIT (texto em `LICENSE`)
- **Commit usado:** `5b2b400eec1e7e1cec76245a715d0b0d4fd2a9c1`
- **Arquivos copiados:** `SKILL.md`, `references/content-teardown.md`, `references/data-sources.md`, `references/funnel-hack.md`, `references/go-inside.md`, `references/hidden-signals.md`, `references/industries/agencies-b2b-services.md`, `references/industries/automotive.md`, `references/industries/care-services.md`, `references/industries/consumer-hardware.md`, `references/industries/cpg-food-beverage.md`, `references/industries/crypto-web3.md`, `references/industries/ecommerce-dtc.md`, `references/industries/education.md`, `references/industries/events-entertainment.md`, `references/industries/finance.md`, `references/industries/fitness-wellness.md`, `references/industries/franchising.md`, `references/industries/gambling-betting.md`, `references/industries/games-pc-console.md`, `references/industries/govtech-public-sector.md`, `references/industries/healthcare.md`, `references/industries/hospitality-travel.md`, `references/industries/insurance.md`, `references/industries/legal-professional-services.md`, `references/industries/local-services.md`, `references/industries/logistics-transportation.md`, `references/industries/manufacturing-industrial.md`, `references/industries/marketplaces.md`, `references/industries/media-creators.md`, `references/industries/mobile-apps-games.md`, `references/industries/nonprofit.md`, `references/industries/real-estate.md`, `references/industries/regulated-goods.md`, `references/industries/retail.md`, `references/industries/saas.md`, `references/industries/solar-home-energy.md`, `references/landscape.md`, `references/play-routing.md`, `references/playbook-template.md`, `references/team-voices.md`, `references/timeline-analysis.md`, `references/weak-spots.md`, `scripts/teardown.mjs`

## Mudanças feitas

- no cabeçalho (frontmatter), `name:` passou de `reverse-engineer-marketing` para `mk-reverse-engineer-marketing`; a descrição ficou igual
- removida a menção ao Magister, produto do próprio mantenedor do repositório (propaganda) (em `references/data-sources.md`)
- links relativos para `tools/integrations/` (pasta não incluída) trocados por links absolutos do GitHub do autor
- nenhuma outra alteração no texto do especialista (mantido em inglês)

## Observações

- incluído `scripts/teardown.mjs` (Node, sem dependências): usa fontes públicas e gratuitas; só o comando opcional de busca de anúncios por API pede uma chave ScrapeCreators, que não é configurada aqui

Empacotada para o marketplace do Progress Code em 2026-11-22.

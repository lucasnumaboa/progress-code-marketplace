# Origem e licença

Esta skill é uma cópia, com as alterações listadas abaixo, de material de especialista com licença aberta.

- **Fonte:** https://github.com/Sloydai/game-art-skills
- **Arquivos de origem:** `skills/art-director/SKILL.md`, `skills/art-director/references/style-bible-template.md`, `skills/art-director/references/style-decisions.md`
- **Autor:** Sloyd
- **Licença:** MIT (texto completo em `LICENSE`)
- **Commit:** `395a5326876243a1675251fd31cbb7e0fb87cddc` (baixado em 2026-11-22)

## Alterações feitas

- `name:` do frontmatter trocado de `art-director` para `sloyd-art-director`.
- Acrescentada logo após o frontmatter uma nota explicando que as chamadas da API Sloyd não existem no Progress Code e como aplicar o método com outra ferramenta de imagem.
- Fora isso, o texto do especialista está como no original (em inglês).

## Arquivos da skill original que não vieram

- As outras skills do "Game Art Department" (concept-artist, modeler, asset-pack-builder, sloyd-api etc.): dependem da API paga da Sloyd.

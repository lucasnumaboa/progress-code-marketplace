---
name: electron-desktop-apps
description: Estrutura um app Electron (processo principal vs. renderer, IPC seguro com preload, contextIsolation), empacota com electron-builder, configura auto-update e assinatura de código. Use quando o usuário pedir para "criar um app desktop com Electron", "esse IPC não está funcionando", "empacotar o Electron como instalador", "configurar atualização automática".
argument-hint: [o que o app Electron precisa fazer]
---

# Electron

## Pré-requisito
Precisa de Node.js instalado (ver skill `nodejs-typescript`). `electron-builder` baixa binários adicionais
(Electron runtime para cada plataforma-alvo) na primeira execução — avise o usuário que o primeiro build demora
mais e usa mais espaço em disco/rede que builds seguintes.

## Estrutura: processo principal vs. renderer (a base de tudo em Electron)
- **Processo principal** (`main.js`): roda Node.js completo, cria janelas, acessa sistema de arquivos, menus.
- **Processo renderer** (o HTML/JS de cada janela): roda como uma página web comum — **não** deve ter acesso direto
  a Node.js/sistema de arquivos por segurança (`contextIsolation: true`, `nodeIntegration: false` — configuração
  padrão recomendada desde Electron 12+, nunca desative isso sem um motivo muito específico e entendido).

```javascript
// main.js
const { app, BrowserWindow } = require('electron');

function criarJanela() {
  const janela = new BrowserWindow({
    webPreferences: {
      preload: require('path').join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });
  janela.loadFile('index.html');
}
app.whenReady().then(criarJanela);
```

## IPC seguro via preload (a forma correta de renderer falar com main)
```javascript
// preload.js - unica ponte exposta ao renderer, com API restrita e explicita
const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('api', {
  salvarArquivo: (conteudo) => ipcRenderer.invoke('salvar-arquivo', conteudo),
});
```
```javascript
// main.js
const { ipcMain } = require('electron');
ipcMain.handle('salvar-arquivo', async (event, conteudo) => {
  // validar 'conteudo' aqui - o renderer NAO e confiavel, mesmo sendo seu proprio codigo
  return require('fs').promises.writeFile(caminho, conteudo);
});
```
```javascript
// no renderer (HTML/JS) - so tem acesso ao que foi explicitamente exposto acima
await window.api.salvarArquivo("conteudo do arquivo");
```
Nunca exponha `ipcRenderer` inteiro (`contextBridge.exposeInMainWorld('ipcRenderer', ipcRenderer)`) — isso dá ao
renderer (que pode carregar conteúdo remoto/de terceiros em alguns apps) acesso a qualquer canal IPC, anulando o
propósito do `contextIsolation`. Exponha só funções específicas com nomes claros, como no exemplo.

## Empacotar com electron-builder
```
npm install -D electron-builder
```
```json
{
  "build": {
    "appId": "com.empresa.meuapp",
    "win": { "target": "nsis" }
  },
  "scripts": { "dist": "electron-builder" }
}
```
```
npm run dist
```
Gera um instalador `.exe` (NSIS) em `dist/` — o primeiro build baixa o Electron runtime correspondente, pode
demorar alguns minutos dependendo da conexão.

## Auto-update
```
npm install electron-updater
```
```javascript
const { autoUpdater } = require('electron-updater');
app.whenReady().then(() => autoUpdater.checkForUpdatesAndNotify());
```
Precisa de um servidor/local de publicação das releases (GitHub Releases é o mais simples de configurar) — o
`electron-builder` já sabe publicar lá com a configuração certa (`"publish"` no `package.json`).

## Assinatura de código (Windows)
Sem assinatura, o instalador gerado dispara aviso do SmartScreen ("Editor desconhecido") — para remover isso,
precisa de um certificado de assinatura de código (comprado de uma CA, não é algo que se gera sozinho de graça) e
configurar `"certificateFile"`/`"certificatePassword"` no `electron-builder`. Confirme com o usuário se ele já tem
um certificado antes de tentar configurar isso.

## Regras
- Nunca desative `contextIsolation` ou ative `nodeIntegration: true` sem um motivo muito específico — é a
  configuração que protege o app de execução de código arbitrário via conteúdo do renderer.
- Sempre valide/sanitize dados vindos do renderer no lado do main (IPC handlers) — trate como entrada não confiável,
  mesmo sendo seu próprio código de renderer.
- `npm run dist` na primeira vez pode falhar por falta de espaço/rede (download do Electron runtime) — trate isso
  como esperado, não como bug do projeto.

## Arquivos desta skill
Nenhum script fixo — os trechos acima cobrem a estrutura básica; adapte ao app real do usuário.

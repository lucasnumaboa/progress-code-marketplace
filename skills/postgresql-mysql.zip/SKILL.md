---
name: postgresql-mysql
description: Conecta, consulta, faz dump/restore, gerencia usuários e índices, e lê EXPLAIN de PostgreSQL e MySQL via bibliotecas Python (psycopg2/pymysql), sem depender dos clientes psql/mysql instalados. Use quando o usuário pedir para "conectar nesse Postgres/MySQL", "fazer dump/restore desse banco", "por que essa consulta está lenta no Postgres/MySQL", "criar usuário e permissão".
argument-hint: [PostgreSQL|MySQL] [operação]
---

# PostgreSQL e MySQL

## Conectar (via Python, sem precisar do cliente `psql`/`mysql` instalado)
```
pip install psycopg2-binary pymysql sqlalchemy
```
```python
import psycopg2
conexao = psycopg2.connect(host="servidor", dbname="meubanco", user="usuario", password="senha", port=5432)

import pymysql
conexao = pymysql.connect(host="servidor", database="meubanco", user="usuario", password="senha", port=3306)
```
Se o cliente de linha de comando (`psql`/`mysql`) já estiver instalado, ele é mais conveniente para consulta
interativa pontual — mas não é necessário instalá-lo só para automação em Python.

## Dump e restore
```
pg_dump -h servidor -U usuario -d meubanco -F c -f backup.dump   # -F c = formato customizado, comprimido
pg_restore -h servidor -U usuario -d meubanco_novo backup.dump

mysqldump -h servidor -u usuario -p meubanco > backup.sql
mysql -h servidor -u usuario -p meubanco_novo < backup.sql
```
Esses utilitários (`pg_dump`/`mysqldump`) vêm junto do cliente do banco — se não estiverem instalados, confirme com
o usuário antes de propor instalar (client tools do Postgres/MySQL); a alternativa sem instalar nada é fazer
dump via Python linha a linha com `COPY`/`SELECT INTO OUTFILE`, mais lento e menos robusto para bancos grandes.

## Usuários e permissões
```sql
-- PostgreSQL
CREATE USER app_readonly WITH PASSWORD 'senha-forte';
GRANT SELECT ON ALL TABLES IN SCHEMA public TO app_readonly;

-- MySQL
CREATE USER 'app_readonly'@'%' IDENTIFIED BY 'senha-forte';
GRANT SELECT ON meubanco.* TO 'app_readonly'@'%';
FLUSH PRIVILEGES;
```
Prefira usuário com o menor privilégio necessário (`SELECT` apenas quando só leitura é preciso) em vez de reusar um
usuário administrador em aplicações.

## Índices
```sql
CREATE INDEX idx_clientes_cpf ON clientes(cpf);                           -- Postgres e MySQL, sintaxe igual
CREATE INDEX idx_pedidos_cliente_data ON pedidos(cliente_id, data_pedido); -- indice composto
```

## EXPLAIN — por que a consulta está lenta
```sql
-- PostgreSQL (ANALYZE executa de verdade, nao so estima - cuidado com UPDATE/DELETE em EXPLAIN ANALYZE)
EXPLAIN ANALYZE SELECT * FROM pedidos WHERE cliente_id = 123;

-- MySQL
EXPLAIN SELECT * FROM pedidos WHERE cliente_id = 123;
```
PostgreSQL: procure `Seq Scan` numa tabela grande (indica falta de índice usável) e compare `actual time` com o
estimado. MySQL: procure `type: ALL` (varredura completa da tabela) na coluna do plano — sinal claro de falta de
índice na condição usada.

## Regras
- Nunca rode `EXPLAIN ANALYZE` (Postgres) em uma consulta de escrita (`UPDATE`/`DELETE`/`INSERT`) em produção sem
  entender que ela **executa de verdade** a operação, não só simula — diferente de `EXPLAIN` puro.
- Ao criar usuário, confirme o escopo mínimo de acesso necessário com o usuário antes de conceder privilégios.
- Dump antes de qualquer alteração estrutural (`ALTER TABLE`) significativa em produção.

## Arquivos desta skill
Nenhum script fixo — os trechos acima cobrem os casos mais comuns; adapte ao servidor/banco reais do usuário.

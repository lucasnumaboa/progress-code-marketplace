---
name: mala-direta-documentos
description: Gera dezenas/centenas de documentos Word a partir de um modelo com marcadores {{campo}} e uma planilha de dados, com regra de nome de arquivo e conversão em lote para PDF. Use quando o usuário pedir "mala direta", "gerar um documento para cada linha da planilha", "gerar contratos/declarações/certificados em massa".
argument-hint: [modelo .docx] [planilha de dados] [pasta de saída]
---

# Mala direta e geração de documentos em lote

Esta skill combina duas outras: `criar-editar-docx` (preenchimento de marcadores `{{campo}}`) e `ler-escrever-xlsx`
(ler a planilha de dados). Leia-as primeiro se ainda não conhece os detalhes de cada parte.

## Passo 1 — Ler a planilha de dados
```python
import openpyxl
wb = openpyxl.load_workbook("dados.xlsx", data_only=True)
ws = wb.active
cabecalho = [c.value for c in ws[1]]
linhas = [dict(zip(cabecalho, [c.value for c in row])) for row in ws.iter_rows(min_row=2)]
```
Confirme com o usuário: os nomes de coluna da planilha batem exatamente com os marcadores `{{campo}}` do modelo
(sensível a maiúsculas/minúsculas e espaços)? Se não bater, PARE e pergunte antes de gerar 200 documentos errados.

## Passo 2 — Regra de nome de arquivo
Sempre pergunte (ou confirme, se já foi dito) qual coluna vira o nome do arquivo (ex.: `{{nome}}` ou `{{numero}}`).
Sanitize antes de usar como nome de arquivo real (remova `\ / : * ? " < > |`, troncar tamanho, e resolver colisão de
nomes repetidos adicionando um sufixo numérico).

## Passo 3 — Gerar um `.docx` por linha
Reaproveite a função de preenchimento de `criar-editar-docx/scripts/preencher_modelo.py` dentro de um laço:
```python
from pathlib import Path
for linha in linhas:
    nome_arquivo = sanitizar(str(linha["nome"])) + ".docx"
    preencher_modelo(modelo="modelo.docx", dados=linha, saida=Path(pasta_saida) / nome_arquivo)
```
Trate erro por linha individualmente — se uma linha falhar (campo faltando, valor inesperado), registre no relatório
final e continue as demais; não pare o lote inteiro por causa de uma linha.

## Passo 4 — Converter o lote para PDF (Word instalado)
Abra o Word **uma única vez** via COM e reaproveite a mesma instância para todos os arquivos (abrir/fechar o Word
centenas de vezes é lento e pode travar):
```powershell
$word = New-Object -ComObject Word.Application
$word.Visible = $false
Get-ChildItem "$pasta_saida\*.docx" | ForEach-Object {
    $doc = $word.Documents.Open($_.FullName)
    $doc.SaveAs([ref]($_.FullName -replace '\.docx$', '.pdf'), [ref]17)
    $doc.Close()
}
$word.Quit()
```

## Passo 5 — Relatório final
Sempre entregue um resumo: quantos documentos gerados com sucesso, quantos falharam e por quê (com o nome da linha
identificadora de cada falha), e o caminho da pasta de saída.

## Regras
- Nunca gere o lote inteiro sem antes gerar **1 documento de teste** e mostrar/confirmar com o usuário que o
  preenchimento saiu certo.
- Planilhas grandes (milhares de linhas): pergunte se o usuário realmente quer gerar todos de uma vez ou só uma
  amostra/filtro primeiro.
- Dados sensíveis (CPF, endereço) nos documentos gerados: não hospede a pasta de saída em nenhum lugar público;
  mantenha local a menos que o usuário peça explicitamente para enviar/publicar.

## Arquivos desta skill
Reaproveita os scripts de `criar-editar-docx` (`preencher_modelo.py`) e `ler-escrever-xlsx`. Nenhum script novo é
necessário além do laço de geração descrito acima, escrito sob medida conforme as colunas reais da planilha do
usuário.
